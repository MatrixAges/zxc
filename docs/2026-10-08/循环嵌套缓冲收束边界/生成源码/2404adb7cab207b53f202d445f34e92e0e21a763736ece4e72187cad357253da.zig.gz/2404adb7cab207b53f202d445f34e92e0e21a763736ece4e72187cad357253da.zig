const std = @import("std");

const zx_native_0 = @import("zxc_standard");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .scalar, };

const zx_shape_13 = .{ .kind = .scalar, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .end = zx_shape_5, .start = zx_shape_5, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .dollar = zx_shape_1, .kind = zx_shape_12, .line_break = zx_shape_1, .span = zx_shape_14, .symbol = zx_shape_13, .word = zx_shape_11, }, };

const zx_shape_16 = .{ .kind = .scalar, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .end = zx_shape_5, .last_byte = zx_shape_2, .phase = zx_shape_16, .separators_valid = zx_shape_1, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .diagnostic = zx_shape_10, .end = zx_shape_5, }, };

const zx_shape_19 = .{ .kind = .scalar, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .code = zx_shape_10, .end = zx_shape_5, .message = zx_shape_10, .start = zx_shape_5, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .braces = zx_shape_5, .depth = zx_shape_5, .mode = zx_shape_19, .start = zx_shape_5, }, };

const zx_shape_22 = .{ .kind = .list, .child = zx_shape_21, };

const zx_shape_23 = .{ .kind = .list, .child = zx_shape_15, };

const zx_shape_24 = .{ .kind = .list, .child = zx_shape_14, };

const zx_shape_25 = .{ .kind = .object, .fields = .{ .ahead_one = zx_shape_2, .ahead_two = zx_shape_2, .braces = zx_shape_5, .comments = zx_shape_24, .depth = zx_shape_5, .diagnostic = zx_shape_20, .dollar = zx_shape_1, .frames = zx_shape_22, .keyword_state = zx_shape_5, .line_break = zx_shape_1, .mode = zx_shape_19, .number = zx_shape_17, .offset = zx_shape_5, .skip_until = zx_shape_5, .source_length = zx_shape_5, .start = zx_shape_5, .symbol = zx_shape_13, .tokens = zx_shape_23, .warmed = zx_shape_2, }, };

const zx_shape_26 = .{ .kind = .object, .fields = .{ .after = zx_shape_2, .byte = zx_shape_2, .has_after = zx_shape_1, .has_next = zx_shape_1, .next = zx_shape_2, .state = zx_shape_25, }, };

const zx_shape_27 = .{ .kind = .object, .fields = .{ .comments = zx_shape_24, .diagnostic = zx_shape_20, .tokens = zx_shape_23, }, };

const zx_shape_28 = .{ .kind = .scalar, };

const zx_shape_29 = .{ .kind = .scalar, };

const zx_shape_30 = .{ .kind = .object, .fields = .{ .child = zx_shape_5, .count = zx_shape_5, .head = zx_shape_5, .kind = zx_shape_28, .name = zx_shape_14, }, };

const zx_shape_31 = .{ .kind = .object, .fields = .{ .name = zx_shape_14, .previous = zx_shape_5, .value = zx_shape_5, }, };

const zx_shape_32 = .{ .kind = .object, .fields = .{ .previous = zx_shape_5, .value = zx_shape_5, }, };

const zx_shape_33 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .fields = zx_shape_33, .heads = zx_shape_33, .items = zx_shape_33, }, };

const zx_shape_35 = .{ .kind = .list, .child = zx_shape_30, };

const zx_shape_36 = .{ .kind = .list, .child = zx_shape_31, };

const zx_shape_37 = .{ .kind = .list, .child = zx_shape_32, };

const zx_shape_38 = .{ .kind = .object, .fields = .{ .fields = zx_shape_36, .items = zx_shape_37, .nodes = zx_shape_35, }, };

const zx_shape_39 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .field = zx_shape_14, .head = zx_shape_5, .kind = zx_shape_28, .name = zx_shape_14, .optional = zx_shape_1, }, };

const zx_shape_40 = .{ .kind = .object, .fields = .{ .depth = zx_shape_5, .diagnostic = zx_shape_20, .index = zx_shape_5, .name = zx_shape_14, .phase = zx_shape_29, .result = zx_shape_5, .start = zx_shape_5, .token = zx_shape_15, }, };

const zx_shape_41 = .{ .kind = .list, .child = zx_shape_39, };

const zx_shape_42 = .{ .kind = .object, .fields = .{ .control = zx_shape_40, .frames = zx_shape_41, .tree = zx_shape_38, }, };

const zx_shape_43 = .{ .kind = .scalar, };

const zx_shape_44 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .enumeration = zx_shape_1, .first = zx_shape_5, .name = zx_shape_14, .span = zx_shape_14, .value = zx_shape_5, }, };

const zx_shape_45 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .depth = zx_shape_5, .diagnostic = zx_shape_20, .enumeration = zx_shape_1, .first = zx_shape_5, .index = zx_shape_5, .last_end = zx_shape_5, .name = zx_shape_14, .opening = zx_shape_5, .opening_index = zx_shape_5, .phase = zx_shape_43, .start = zx_shape_5, .token = zx_shape_15, .type_diagnostic = zx_shape_1, }, };

const zx_shape_46 = .{ .kind = .list, .child = zx_shape_44, };

const zx_shape_47 = .{ .kind = .object, .fields = .{ .control = zx_shape_45, .declarations = zx_shape_46, .members = zx_shape_24, .types = zx_shape_42, }, };

const zx_shape_48 = .{ .kind = .scalar, };

const zx_shape_49 = .{ .kind = .object, .fields = .{ .end = zx_shape_5, .start = zx_shape_5, .text = zx_shape_10, }, };

const zx_shape_50 = .{ .kind = .object, .fields = .{ .enumeration = zx_shape_1, .index = zx_shape_5, }, };

const zx_shape_51 = .{ .kind = .object, .fields = .{ .child = zx_shape_50, .count = zx_shape_5, .kind = zx_shape_48, .name = zx_shape_49, .position = zx_shape_5, }, };

const zx_shape_52 = .{ .kind = .object, .fields = .{ .name = zx_shape_49, .next = zx_shape_5, .value = zx_shape_50, }, };

const zx_shape_53 = .{ .kind = .object, .fields = .{ .next = zx_shape_5, .value = zx_shape_50, }, };

const zx_shape_54 = .{ .kind = .object, .fields = .{ .name = zx_shape_49, .value = zx_shape_50, }, };

const zx_shape_55 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, }, };

const zx_shape_56 = .{ .kind = .list, .child = zx_shape_51, };

const zx_shape_57 = .{ .kind = .list, .child = zx_shape_52, };

const zx_shape_58 = .{ .kind = .list, .child = zx_shape_53, };

const zx_shape_59 = .{ .kind = .list, .child = zx_shape_54, };

const zx_shape_60 = .{ .kind = .list, .child = zx_shape_55, };

const zx_shape_61 = .{ .kind = .list, .child = zx_shape_49, };

const zx_shape_62 = .{ .kind = .object, .fields = .{ .declarations = zx_shape_59, .enumerations = zx_shape_60, .fields = zx_shape_57, .items = zx_shape_58, .members = zx_shape_61, .nodes = zx_shape_56, }, };

const zx_shape_63 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_64 = .{ .kind = .object, .fields = .{ .bytes = zx_shape_63, .declarations = zx_shape_46, .members = zx_shape_24, .order = zx_shape_34, .types = zx_shape_38, }, };

const zx_shape_65 = .{ .kind = .optional, .child = zx_shape_62, };

const zx_shape_66 = .{ .kind = .object, .fields = .{ .indexed = zx_shape_64, .native = zx_shape_65, }, };

const zx_shape_67 = .{ .kind = .scalar, };

const zx_shape_68 = .{ .kind = .object, .fields = .{ .allocator_argument = zx_shape_1, .concurrent = zx_shape_1, .count = zx_shape_5, .error_count = zx_shape_5, .errors_present = zx_shape_1, .fallible = zx_shape_1, .first_error = zx_shape_5, .first_parameter = zx_shape_5, .io_argument = zx_shape_1, .name = zx_shape_14, .output = zx_shape_5, .process_argument = zx_shape_1, }, };

const zx_shape_69 = .{ .kind = .object, .fields = .{ .name = zx_shape_14, .value = zx_shape_5, }, };

const zx_shape_70 = .{ .kind = .object, .fields = .{ .current = zx_shape_68, .diagnostic = zx_shape_20, .index = zx_shape_5, .injected = zx_shape_5, .parameter = zx_shape_14, .phase = zx_shape_67, }, };

const zx_shape_71 = .{ .kind = .list, .child = zx_shape_68, };

const zx_shape_72 = .{ .kind = .list, .child = zx_shape_69, };

const zx_shape_73 = .{ .kind = .object, .fields = .{ .control = zx_shape_70, .declarations = zx_shape_47, .errors = zx_shape_24, .functions = zx_shape_71, .lexed = zx_shape_27, .parameters = zx_shape_72, }, };

const zx_shape_74 = .{ .kind = .object, .fields = .{ .declarations = zx_shape_46, .diagnostic = zx_shape_20, .errors = zx_shape_24, .functions = zx_shape_71, .members = zx_shape_24, .parameters = zx_shape_72, .type_order = zx_shape_34, .types = zx_shape_38, }, };

const zx_shape_75 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, .parameters = zx_shape_72, .source = zx_shape_66, }, };

const zx_shape_76 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_77 = .{ .kind = .optional, .child = zx_shape_10, };

const zx_shape_78 = .{ .kind = .list, .child = zx_shape_77, };

const zx_shape_79 = .{ .kind = .object, .fields = .{ .aliases = zx_shape_78, .enumerations = zx_shape_76, .nodes = zx_shape_33, }, };

const zx_shape_80 = .{ .kind = .object, .fields = .{ .names = zx_shape_78, .source = zx_shape_66, .valid = zx_shape_1, .work = zx_shape_79, }, };

const zx_shape_81 = .{ .kind = .object, .fields = .{ .names = zx_shape_78, .valid = zx_shape_1, }, };

const zx_shape_82 = .{ .kind = .object, .fields = .{ .aliases = zx_shape_78, .enumerations = zx_shape_76, .input = zx_shape_75, .nodes = zx_shape_33, .remaining = zx_shape_5, }, };

const zx_shape_83 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_33, .@"1" = zx_shape_0, }, };

const zx_shape_84 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_76, .@"1" = zx_shape_0, }, };

const zx_shape_85 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_78, .@"1" = zx_shape_0, }, };

const zx_shape_86 = .{ .kind = .object, .fields = .{ .source = zx_shape_63, .span = zx_shape_14, }, };

const zx_shape_87 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_63, .@"1" = zx_shape_63, }, };

const zx_shape_88 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .source = zx_shape_66, }, };

const zx_shape_89 = .{ .kind = .object, .fields = .{ .limit = zx_shape_5, .name = zx_shape_10, .source = zx_shape_66, }, };

const zx_shape_90 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .index = zx_shape_5, }, };

const zx_shape_91 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .index = zx_shape_5, .limit = zx_shape_5, .name = zx_shape_10, .selected = zx_shape_5, .source = zx_shape_66, }, };

const zx_shape_92 = .{ .kind = .object, .fields = .{ .reference = zx_shape_50, .source = zx_shape_66, }, };

const zx_shape_93 = .{ .kind = .object, .fields = .{ .active = zx_shape_1, .reference = zx_shape_50, .source = zx_shape_66, .valid = zx_shape_1, }, };

const zx_shape_94 = .{ .kind = .object, .fields = .{ .position = zx_shape_5, .source = zx_shape_66, }, };

const zx_shape_95 = .{ .kind = .object, .fields = .{ .left = zx_shape_10, .right = zx_shape_10, }, };

const zx_shape_96 = .{ .kind = .object, .fields = .{ .equal = zx_shape_1, .index = zx_shape_5, .left = zx_shape_10, .limit = zx_shape_5, .right = zx_shape_10, }, };

const zx_shape_97 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .object = zx_shape_1, .position = zx_shape_5, .source = zx_shape_66, }, };

const zx_shape_98 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_99 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .input = zx_shape_97, .names = zx_shape_98, .position = zx_shape_5, .positions = zx_shape_33, }, };

const zx_shape_100 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_98, .@"1" = zx_shape_0, }, };

const zx_shape_101 = .{ .kind = .object, .fields = .{ .building = zx_shape_1, .count = zx_shape_5, .names = zx_shape_98, .positions = zx_shape_33, .remaining = zx_shape_5, .root = zx_shape_5, .sifting = zx_shape_1, }, };

const zx_shape_102 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .object = zx_shape_1, .position = zx_shape_5, .state = zx_shape_80, }, };

const zx_shape_103 = .{ .kind = .object, .fields = .{ .object = zx_shape_1, .positions = zx_shape_33, .remaining = zx_shape_5, .state = zx_shape_80, }, };

const zx_shape_104 = .{ .kind = .optional, .child = zx_shape_5, };

const zx_shape_105 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_33, .@"1" = zx_shape_104, }, };

const zx_shape_106 = .{ .kind = .optional, .child = zx_shape_1, };

const zx_shape_107 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_76, .@"1" = zx_shape_106, }, };

const zx_shape_108 = .{ .kind = .optional, .child = zx_shape_77, };

const zx_shape_109 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_78, .@"1" = zx_shape_108, }, };

const zx_shape_110 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_75, }, };

const zx_shape_111 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_75, .@"1" = zx_shape_80, }, };

const zx_shape_112 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_75, .@"1" = zx_shape_80, .@"2" = zx_shape_81, }, };

pub const input_shape = zx_shape_75;

pub const output_shape = zx_shape_81;

pub const Input = *const (zx_abi).zx_type_75;

pub const Output = *const (zx_abi).zx_type_81;

fn function_0(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_75) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_80 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = block_86: {
        break :block_86 (try (allocator).dupe(u64, (&[_]u64{})));
    };
    const value_2: []const bool = block_85: {
        break :block_85 (try (allocator).dupe(bool, (&[_]bool{})));
    };
    const value_3: []const ?[]const u8 = block_84: {
        break :block_84 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{})));
    };
    const value_4: []const ?[]const u8 = (if (((in).count == @as(u64, 1))) block_81: {
        break :block_81 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{})));
    } else block_83: {
        const operand_82 = @as(?[]const u8, null);

        break :block_83 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{operand_82, })));
    });
    const value_16: *const (zx_abi).zx_type_82 = block_80: {
        const operand_23 = block_22: {
            const operand_15 = in;
            const operand_16 = value_1;
            const operand_17 = value_2;
            const operand_18 = value_3;
            const operand_19 = (in).count;

            break :block_22 block_21: {
                const operand_20 = (try (allocator).create((zx_abi).zx_type_82));

                (operand_20).* = @as((zx_abi).zx_type_82, (zx_abi).zx_type_82{ .input = operand_15, .nodes = operand_16, .enumerations = operand_17, .aliases = operand_18, .remaining = operand_19, });

                break :block_21 @as(*const (zx_abi).zx_type_82, operand_20);
            };
        };

        var state_capacity_25: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_26 = false;

        defer (state_capacity_25).deinit(allocator);

        var state_capacity_27: (std).ArrayList(bool) = .empty;

        var state_capacity_started_28 = false;

        defer (state_capacity_27).deinit(allocator);

        var state_capacity_29: (std).ArrayList(u64) = .empty;

        var state_capacity_started_30 = false;

        defer (state_capacity_29).deinit(allocator);

        const state_type_31 = struct {
            fields: []const u64,
            heads: []const u64,
            items: []const u64,
        };
        const state_type_32 = struct {
            fields: []const *const (zx_abi).zx_type_31,
            items: []const *const (zx_abi).zx_type_32,
            nodes: []const *const (zx_abi).zx_type_30,
        };
        const state_type_33 = struct {
            bytes: []const u8,
            declarations: []const *const (zx_abi).zx_type_44,
            members: []const *const (zx_abi).zx_type_14,
            order: state_type_31,
            types: state_type_32,
        };
        const state_type_34 = struct {
            declarations: []const *const (zx_abi).zx_type_54,
            enumerations: []const *const (zx_abi).zx_type_55,
            fields: []const *const (zx_abi).zx_type_52,
            items: []const *const (zx_abi).zx_type_53,
            members: []const *const (zx_abi).zx_type_49,
            nodes: []const *const (zx_abi).zx_type_51,
        };
        const state_type_35 = struct {
            indexed: state_type_33,
            native: ?state_type_34,
        };
        const state_type_36 = struct {
            count: u64,
            first: u64,
            parameters: []const *const (zx_abi).zx_type_69,
            source: state_type_35,
        };
        const state_type_37 = struct {
            aliases: []const ?[]const u8,
            enumerations: []const bool,
            input: state_type_36,
            nodes: []const u64,
            remaining: u64,
        };
        const state_type_38 = struct { []const ?[]const u8, void, };
        const state_type_43 = struct { []const bool, void, };
        const state_type_48 = struct { []const u64, void, };
        const state_type_54 = struct {
            end: u64,
            start: u64,
        };
        const state_type_55 = struct {
            name: state_type_54,
            value: u64,
        };

        var state_14: state_type_37 = state_type_37{ .aliases = (operand_23).aliases, .enumerations = (operand_23).enumerations, .input = state_type_36{ .count = ((operand_23).input).count, .first = ((operand_23).input).first, .parameters = ((operand_23).input).parameters, .source = state_type_35{ .indexed = state_type_33{ .bytes = ((((operand_23).input).source).indexed).bytes, .declarations = ((((operand_23).input).source).indexed).declarations, .members = ((((operand_23).input).source).indexed).members, .order = state_type_31{ .fields = (((((operand_23).input).source).indexed).order).fields, .heads = (((((operand_23).input).source).indexed).order).heads, .items = (((((operand_23).input).source).indexed).order).items, }, .types = state_type_32{ .fields = (((((operand_23).input).source).indexed).types).fields, .items = (((((operand_23).input).source).indexed).types).items, .nodes = (((((operand_23).input).source).indexed).types).nodes, }, }, .native = @as(?state_type_34, (if (((((operand_23).input).source).native != null)) state_type_34{ .declarations = ((((operand_23).input).source).native.?).declarations, .enumerations = ((((operand_23).input).source).native.?).enumerations, .fields = ((((operand_23).input).source).native.?).fields, .items = ((((operand_23).input).source).native.?).items, .members = ((((operand_23).input).source).native.?).members, .nodes = ((((operand_23).input).source).native.?).nodes, } else null)), }, }, .nodes = (operand_23).nodes, .remaining = (operand_23).remaining, };

        var state_changed_24 = false;

        while (((state_14).remaining != @as(u64, 0))) {
            state_14 = block_61: {
                const value_7: state_type_37 = state_14;
                const value_8: u64 = (value_7).remaining;
                const value_9: state_type_37 = block_60: {
                    break :block_60 state_type_37{ .aliases = (value_7).aliases, .enumerations = (value_7).enumerations, .input = (value_7).input, .nodes = (value_7).nodes, .remaining = (value_8 - @as(u64, 1)), };
                };
                const value_10: state_type_37 = value_9;
                const value_11: state_type_37 = block_59: {
                    break :block_59 state_type_37{ .aliases = (value_10).aliases, .enumerations = (value_10).enumerations, .input = (value_10).input, .nodes = (block_58: {
                        const operand_49 = (value_9).nodes;
                        const operand_57 = (block_56: {
                            const operand_53 = block_52: {
                                const operand_50 = ((value_9).input).parameters;
                                const operand_51 = (((value_9).input).first + (value_9).remaining);

                                if ((operand_51 >= (operand_50).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_52 (operand_50)[@intCast(operand_51)];
                            };

                            break :block_56 state_type_55{ .name = state_type_54{ .end = ((operand_53).name).end, .start = ((operand_53).name).start, }, .value = (operand_53).value, };
                        }).value;

                        _ = (try ((std).math).add(usize, (operand_49).len, 1));

                        if ((!state_capacity_started_30)) {
                            (try (state_capacity_29).appendSlice(allocator, operand_49));

                            state_capacity_started_30 = true;
                        } else {
                            ((state_capacity_29).items).len = (operand_49).len;
                        }

                        (try (state_capacity_29).append(allocator, operand_57));

                        break :block_58 @as(state_type_48, .{ (state_capacity_29).items, {}, });
                    }).@"0", .remaining = (value_10).remaining, };
                };
                const value_12: state_type_37 = value_11;
                const value_13: state_type_37 = block_47: {
                    break :block_47 state_type_37{ .aliases = (value_12).aliases, .enumerations = (block_46: {
                        const operand_44 = (value_11).enumerations;
                        const operand_45 = false;

                        _ = (try ((std).math).add(usize, (operand_44).len, 1));

                        if ((!state_capacity_started_28)) {
                            (try (state_capacity_27).appendSlice(allocator, operand_44));

                            state_capacity_started_28 = true;
                        } else {
                            ((state_capacity_27).items).len = (operand_44).len;
                        }

                        (try (state_capacity_27).append(allocator, operand_45));

                        break :block_46 @as(state_type_43, .{ (state_capacity_27).items, {}, });
                    }).@"0", .input = (value_12).input, .nodes = (value_12).nodes, .remaining = (value_12).remaining, };
                };
                const value_14: state_type_37 = value_13;
                const value_15: state_type_37 = block_42: {
                    break :block_42 state_type_37{ .aliases = (block_41: {
                        const operand_39 = (value_13).aliases;
                        const operand_40 = @as(?[]const u8, null);

                        _ = (try ((std).math).add(usize, (operand_39).len, 1));

                        if ((!state_capacity_started_26)) {
                            (try (state_capacity_25).appendSlice(allocator, operand_39));

                            state_capacity_started_26 = true;
                        } else {
                            ((state_capacity_25).items).len = (operand_39).len;
                        }

                        (try (state_capacity_25).append(allocator, operand_40));

                        break :block_41 @as(state_type_38, .{ (state_capacity_25).items, {}, });
                    }).@"0", .enumerations = (value_14).enumerations, .input = (value_14).input, .nodes = (value_14).nodes, .remaining = (value_14).remaining, };
                };

                break :block_61 value_15;
            };

            state_changed_24 = true;
        }

        var state_owned_62: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_62);

        if (state_capacity_started_26) {
            ((state_capacity_25).items).len = ((state_14).aliases).len;

            state_owned_62 = (try (state_capacity_25).toOwnedSlice(allocator));
        }

        if (state_capacity_started_26) {
            (state_14).aliases = state_owned_62;
        }

        var state_owned_63: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_63);

        if (state_capacity_started_28) {
            ((state_capacity_27).items).len = ((state_14).enumerations).len;

            state_owned_63 = (try (state_capacity_27).toOwnedSlice(allocator));
        }

        if (state_capacity_started_28) {
            (state_14).enumerations = state_owned_63;
        }

        var state_owned_64: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_64);

        if (state_capacity_started_30) {
            ((state_capacity_29).items).len = ((state_14).nodes).len;

            state_owned_64 = (try (state_capacity_29).toOwnedSlice(allocator));
        }

        if (state_capacity_started_30) {
            (state_14).nodes = state_owned_64;
        }

        break :block_80 (if (state_changed_24) block_79: {
            const operand_78 = (try (allocator).create((zx_abi).zx_type_82));

            (operand_78).* = @as((zx_abi).zx_type_82, (zx_abi).zx_type_82{ .aliases = (state_14).aliases, .enumerations = (state_14).enumerations, .input = block_77: {
                const operand_76 = (try (allocator).create((zx_abi).zx_type_75));

                (operand_76).* = @as((zx_abi).zx_type_75, (zx_abi).zx_type_75{ .count = ((state_14).input).count, .first = ((state_14).input).first, .parameters = ((state_14).input).parameters, .source = block_75: {
                    const operand_74 = (try (allocator).create((zx_abi).zx_type_66));

                    (operand_74).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_71: {
                        const operand_70 = (try (allocator).create((zx_abi).zx_type_64));

                        (operand_70).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = ((((state_14).input).source).indexed).bytes, .declarations = ((((state_14).input).source).indexed).declarations, .members = ((((state_14).input).source).indexed).members, .order = block_67: {
                            const operand_66 = (try (allocator).create((zx_abi).zx_type_34));

                            (operand_66).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .fields = (((((state_14).input).source).indexed).order).fields, .heads = (((((state_14).input).source).indexed).order).heads, .items = (((((state_14).input).source).indexed).order).items, });

                            break :block_67 @as(*const (zx_abi).zx_type_34, operand_66);
                        }, .types = block_69: {
                            const operand_68 = (try (allocator).create((zx_abi).zx_type_38));

                            (operand_68).* = @as((zx_abi).zx_type_38, (zx_abi).zx_type_38{ .fields = (((((state_14).input).source).indexed).types).fields, .items = (((((state_14).input).source).indexed).types).items, .nodes = (((((state_14).input).source).indexed).types).nodes, });

                            break :block_69 @as(*const (zx_abi).zx_type_38, operand_68);
                        }, });

                        break :block_71 @as(*const (zx_abi).zx_type_64, operand_70);
                    }, .native = @as(?*const (zx_abi).zx_type_62, (if (((((state_14).input).source).native != null)) block_73: {
                        const operand_72 = (try (allocator).create((zx_abi).zx_type_62));

                        (operand_72).* = @as((zx_abi).zx_type_62, (zx_abi).zx_type_62{ .declarations = ((((state_14).input).source).native.?).declarations, .enumerations = ((((state_14).input).source).native.?).enumerations, .fields = ((((state_14).input).source).native.?).fields, .items = ((((state_14).input).source).native.?).items, .members = ((((state_14).input).source).native.?).members, .nodes = ((((state_14).input).source).native.?).nodes, });

                        break :block_73 @as(*const (zx_abi).zx_type_62, operand_72);
                    } else null)), });

                    break :block_75 @as(*const (zx_abi).zx_type_66, operand_74);
                }, });

                break :block_77 @as(*const (zx_abi).zx_type_75, operand_76);
            }, .nodes = (state_14).nodes, .remaining = (state_14).remaining, });

            break :block_79 @as(*const (zx_abi).zx_type_82, operand_78);
        } else operand_23);
    };

    return block_13: {
        const operand_1 = (in).source;
        const operand_2 = block_8: {
            const operand_3 = (value_16).nodes;
            const operand_4 = (value_16).enumerations;
            const operand_5 = (value_16).aliases;

            break :block_8 block_7: {
                const operand_6 = (try (allocator).create((zx_abi).zx_type_79));

                (operand_6).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_3, .enumerations = operand_4, .aliases = operand_5, });

                break :block_7 @as(*const (zx_abi).zx_type_79, operand_6);
            };
        };
        const operand_9 = value_4;
        const operand_10 = true;

        break :block_13 block_12: {
            const operand_11 = (try (allocator).create((zx_abi).zx_type_80));

            (operand_11).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .source = operand_1, .work = operand_2, .names = operand_9, .valid = operand_10, });

            break :block_12 @as(*const (zx_abi).zx_type_80, operand_11);
        };
    };
}

fn function_0_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_75_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = block_143: {
        break :block_143 (try (allocator).dupe(u64, (&[_]u64{})));
    };
    const value_2: []const bool = block_142: {
        break :block_142 (try (allocator).dupe(bool, (&[_]bool{})));
    };
    const value_3: []const ?[]const u8 = block_141: {
        break :block_141 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{})));
    };
    const value_4: []const ?[]const u8 = (if (((in).count == @as(u64, 1))) block_138: {
        break :block_138 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{})));
    } else block_140: {
        const operand_139 = @as(?[]const u8, null);

        break :block_140 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{operand_139, })));
    });
    const value_16: (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = block_137: {
        const operand_107 = block_106: {
            const operand_98 = in;
            const operand_99 = block_100: {
                break :block_100 value_1;
            };
            const operand_101 = block_102: {
                break :block_102 value_2;
            };
            const operand_103 = block_104: {
                break :block_104 value_3;
            };
            const operand_105 = (in).count;

            break :block_106 @as((zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87{ .input = operand_98, .nodes = operand_99, .enumerations = operand_101, .aliases = operand_103, .remaining = operand_105, });
        };

        var state_capacity_109: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_110 = false;

        defer (state_capacity_109).deinit(allocator);

        var state_capacity_111: (std).ArrayList(bool) = .empty;

        var state_capacity_started_112 = false;

        defer (state_capacity_111).deinit(allocator);

        var state_capacity_113: (std).ArrayList(u64) = .empty;

        var state_capacity_started_114 = false;

        defer (state_capacity_113).deinit(allocator);

        var state_97: (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = operand_107;

        var state_changed_108 = false;

        while (((state_97).remaining != @as(u64, 0))) {
            state_97 = block_132: {
                const value_7: (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = state_97;
                const value_8: u64 = (value_7).remaining;
                const value_9: (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = block_131: {
                    break :block_131 @as((zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87{ .aliases = (value_7).aliases, .enumerations = (value_7).enumerations, .input = (value_7).input, .nodes = (value_7).nodes, .remaining = (block_130: {
                        break :block_130 value_8;
                    } - @as(u64, 1)), });
                };
                const value_10: (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = value_9;
                const value_11: (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = block_129: {
                    break :block_129 @as((zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87{ .aliases = (value_10).aliases, .enumerations = (value_10).enumerations, .input = (value_10).input, .nodes = (block_128: {
                        const operand_123 = (value_9).nodes;
                        const operand_127 = (block_126: {
                            const operand_124 = ((value_9).input).parameters;
                            const operand_125 = (((value_9).input).first + (value_9).remaining);

                            if ((operand_125 >= (operand_124).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_126 (operand_124)[@intCast(operand_125)];
                        }).value;

                        _ = (try ((std).math).add(usize, (operand_123).len, 1));

                        if ((!state_capacity_started_114)) {
                            (try (state_capacity_113).appendSlice(allocator, operand_123));

                            state_capacity_started_114 = true;
                        } else {
                            ((state_capacity_113).items).len = (operand_123).len;
                        }

                        (try (state_capacity_113).append(allocator, operand_127));

                        break :block_128 @as((zx_abi).value_zx_type_83_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_113).items, {}, null, });
                    }).@"0", .remaining = (value_10).remaining, });
                };
                const value_12: (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = value_11;
                const value_13: (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = block_122: {
                    break :block_122 @as((zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87{ .aliases = (value_12).aliases, .enumerations = (block_121: {
                        const operand_119 = (value_11).enumerations;
                        const operand_120 = false;

                        _ = (try ((std).math).add(usize, (operand_119).len, 1));

                        if ((!state_capacity_started_112)) {
                            (try (state_capacity_111).appendSlice(allocator, operand_119));

                            state_capacity_started_112 = true;
                        } else {
                            ((state_capacity_111).items).len = (operand_119).len;
                        }

                        (try (state_capacity_111).append(allocator, operand_120));

                        break :block_121 @as((zx_abi).value_zx_type_84_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_111).items, {}, null, });
                    }).@"0", .input = (value_12).input, .nodes = (value_12).nodes, .remaining = (value_12).remaining, });
                };
                const value_14: (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = value_13;
                const value_15: (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = block_118: {
                    break :block_118 @as((zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87{ .aliases = (block_117: {
                        const operand_115 = (value_13).aliases;
                        const operand_116 = @as(?[]const u8, null);

                        _ = (try ((std).math).add(usize, (operand_115).len, 1));

                        if ((!state_capacity_started_110)) {
                            (try (state_capacity_109).appendSlice(allocator, operand_115));

                            state_capacity_started_110 = true;
                        } else {
                            ((state_capacity_109).items).len = (operand_115).len;
                        }

                        (try (state_capacity_109).append(allocator, operand_116));

                        break :block_117 @as((zx_abi).value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_109).items, {}, null, });
                    }).@"0", .enumerations = (value_14).enumerations, .input = (value_14).input, .nodes = (value_14).nodes, .remaining = (value_14).remaining, });
                };

                break :block_132 value_15;
            };

            state_changed_108 = true;
        }

        var state_owned_133: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_133);

        if (state_capacity_started_110) {
            ((state_capacity_109).items).len = ((state_97).aliases).len;

            state_owned_133 = (try (state_capacity_109).toOwnedSlice(allocator));
        }

        if (state_capacity_started_110) {
            state_97 = (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87{ .aliases = state_owned_133, .enumerations = (state_97).enumerations, .input = (state_97).input, .nodes = (state_97).nodes, .remaining = (state_97).remaining, };
        }

        var state_owned_134: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_134);

        if (state_capacity_started_112) {
            ((state_capacity_111).items).len = ((state_97).enumerations).len;

            state_owned_134 = (try (state_capacity_111).toOwnedSlice(allocator));
        }

        if (state_capacity_started_112) {
            state_97 = (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87{ .aliases = (state_97).aliases, .enumerations = state_owned_134, .input = (state_97).input, .nodes = (state_97).nodes, .remaining = (state_97).remaining, };
        }

        var state_owned_135: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_135);

        if (state_capacity_started_114) {
            ((state_capacity_113).items).len = ((state_97).nodes).len;

            state_owned_135 = (try (state_capacity_113).toOwnedSlice(allocator));
        }

        if (state_capacity_started_114) {
            state_97 = (zx_abi).value_zx_type_82_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87{ .aliases = (state_97).aliases, .enumerations = (state_97).enumerations, .input = (state_97).input, .nodes = state_owned_135, .remaining = (state_97).remaining, };
        }

        break :block_137 (if (state_changed_108) state_97 else operand_107);
    };

    return block_96: {
        const operand_87 = (in).source;
        const operand_88 = block_92: {
            const operand_89 = (value_16).nodes;
            const operand_90 = (value_16).enumerations;
            const operand_91 = (value_16).aliases;

            break :block_92 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_89, .enumerations = operand_90, .aliases = operand_91, });
        };
        const operand_93 = block_94: {
            break :block_94 value_4;
        };
        const operand_95 = true;

        break :block_96 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .source = operand_87, .work = operand_88, .names = operand_93, .valid = operand_95, });
    };
}

fn function_1(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_66) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: ?*const (zx_abi).zx_type_62 = (in).native;

    return (if ((value_1 != null)) @as(u64, ((value_1.?).declarations).len) else @as(u64, (((in).indexed).declarations).len));
}

fn function_2(allocator: ((std).mem).Allocator, in: []const u8) error{ OutOfMemory, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).encodeBase64(allocator, in));

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: []const u8) error{ InvalidCharacter, InvalidPadding, NoSpaceLeft, OutOfMemory, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).decodeBase64(allocator, in));

    return native_result;
}

fn function_4(allocator: ((std).mem).Allocator, in: []const u8) error{ OutOfMemory, Overflow, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).encodeHex(allocator, in));

    return native_result;
}

fn function_5(allocator: ((std).mem).Allocator, in: []const u8) error{ InvalidCharacter, InvalidHex, InvalidLength, NoSpaceLeft, OutOfMemory, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).decodeHex(allocator, in));

    return native_result;
}

fn function_6(allocator: ((std).mem).Allocator, in: []const u8) error{ InvalidUtf8, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).encodeUtf8(in));

    _ = allocator;

    return native_result;
}

fn function_7(allocator: ((std).mem).Allocator, in: []const u8) error{ InvalidUtf8, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).decodeUtf8(in));

    _ = allocator;

    return native_result;
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_86) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_49 {
    @setRuntimeSafety(true);

    const value_1: []const u8 = (try function_7(allocator, block_14: {
        const operand_7 = (in).source;
        const operand_8 = ((in).span).start;
        const operand_9 = (((in).span).end - ((in).span).start);
        const operand_11 = block_10: {
            break :block_10 (try (allocator).dupe(u8, (&[_]u8{})));
        };

        if (((operand_8 > (operand_7).len) or (operand_9 > ((operand_7).len - operand_8)))) {
            return error.IndexOutOfBounds;
        }

        const operand_12 = @as(usize, @intCast(operand_8));
        const operand_13 = @as(usize, @intCast(operand_9));

        _ = (try ((std).math).add(usize, ((operand_7).len - operand_13), (operand_11).len));

        break :block_14 (operand_7)[operand_12..(operand_12 + operand_13)];
    }));

    return block_6: {
        const operand_1 = value_1;
        const operand_2 = ((in).span).start;
        const operand_3 = ((in).span).end;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create((zx_abi).zx_type_49));

            (operand_4).* = @as((zx_abi).zx_type_49, (zx_abi).zx_type_49{ .text = operand_1, .start = operand_2, .end = operand_3, });

            break :block_5 @as(*const (zx_abi).zx_type_49, operand_4);
        };
    };
}

fn function_8_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_86) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).zx_type_49 {
    @setRuntimeSafety(true);

    const value_1: []const u8 = (try function_7(allocator, block_26: {
        const operand_19 = (in).source;
        const operand_20 = ((in).span).start;
        const operand_21 = (((in).span).end - ((in).span).start);
        const operand_23 = block_22: {
            break :block_22 (try (allocator).dupe(u8, (&[_]u8{})));
        };

        if (((operand_20 > (operand_19).len) or (operand_21 > ((operand_19).len - operand_20)))) {
            return error.IndexOutOfBounds;
        }

        const operand_24 = @as(usize, @intCast(operand_20));
        const operand_25 = @as(usize, @intCast(operand_21));

        _ = (try ((std).math).add(usize, ((operand_19).len - operand_25), (operand_23).len));

        break :block_26 (operand_19)[operand_24..(operand_24 + operand_25)];
    }));

    return block_18: {
        const operand_15 = value_1;
        const operand_16 = ((in).span).start;
        const operand_17 = ((in).span).end;

        break :block_18 (zx_abi).zx_type_49{ .text = operand_15, .start = operand_16, .end = operand_17, };
    };
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_88) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_54 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return block_25: {
            const operand_23 = (value_1.?).declarations;
            const operand_24 = (in).index;

            if ((operand_24 >= (operand_23).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_25 (operand_23)[@intCast(operand_24)];
        };
    }

    const value_2: *const (zx_abi).zx_type_44 = block_22: {
        const operand_20 = (((in).source).indexed).declarations;
        const operand_21 = (in).index;

        if ((operand_21 >= (operand_20).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_22 (operand_20)[@intCast(operand_21)];
    };

    return block_19: {
        const operand_1 = block_10: {
            const operand_7 = (try function_8_value(allocator, block_6: {
                const operand_2 = (((in).source).indexed).bytes;
                const operand_3 = (value_2).name;

                break :block_6 block_5: {
                    const operand_4 = (try (allocator).create((zx_abi).zx_type_86));

                    (operand_4).* = @as((zx_abi).zx_type_86, (zx_abi).zx_type_86{ .source = operand_2, .span = operand_3, });

                    break :block_5 @as(*const (zx_abi).zx_type_86, operand_4);
                };
            }));

            break :block_10 block_9: {
                const operand_8 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_8).* = @as((zx_abi).zx_type_49, operand_7);

                break :block_9 @as(*const (zx_abi).zx_type_49, operand_8);
            };
        };
        const operand_11 = block_16: {
            const operand_12 = (value_2).enumeration;
            const operand_13 = (if ((value_2).enumeration) (in).index else (value_2).value);

            break :block_16 block_15: {
                const operand_14 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_14).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_12, .index = operand_13, });

                break :block_15 @as(*const (zx_abi).zx_type_50, operand_14);
            };
        };

        break :block_19 block_18: {
            const operand_17 = (try (allocator).create((zx_abi).zx_type_54));

            (operand_17).* = @as((zx_abi).zx_type_54, (zx_abi).zx_type_54{ .name = operand_1, .value = operand_11, });

            break :block_18 @as(*const (zx_abi).zx_type_54, operand_17);
        };
    };
}

fn function_9_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_88) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).zx_type_54 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return (block_48: {
            const operand_46 = (value_1.?).declarations;
            const operand_47 = (in).index;

            if ((operand_47 >= (operand_46).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_48 (operand_46)[@intCast(operand_47)];
        }).*;
    }

    const value_2: (zx_abi).zx_type_44 = (block_45: {
        const operand_43 = (((in).source).indexed).declarations;
        const operand_44 = (in).index;

        if ((operand_44 >= (operand_43).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_45 (operand_43)[@intCast(operand_44)];
    }).*;

    return block_42: {
        const operand_26 = block_35: {
            const operand_32 = (try function_8_value(allocator, block_31: {
                const operand_27 = (((in).source).indexed).bytes;
                const operand_28 = ((&value_2)).name;

                break :block_31 block_30: {
                    const operand_29 = (try (allocator).create((zx_abi).zx_type_86));

                    (operand_29).* = @as((zx_abi).zx_type_86, (zx_abi).zx_type_86{ .source = operand_27, .span = operand_28, });

                    break :block_30 @as(*const (zx_abi).zx_type_86, operand_29);
                };
            }));

            break :block_35 block_34: {
                const operand_33 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_33).* = @as((zx_abi).zx_type_49, operand_32);

                break :block_34 @as(*const (zx_abi).zx_type_49, operand_33);
            };
        };
        const operand_36 = block_41: {
            const operand_37 = ((&value_2)).enumeration;
            const operand_38 = (if (((&value_2)).enumeration) (in).index else ((&value_2)).value);

            break :block_41 block_40: {
                const operand_39 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_39).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_37, .index = operand_38, });

                break :block_40 @as(*const (zx_abi).zx_type_50, operand_39);
            };
        };

        break :block_42 (zx_abi).zx_type_54{ .name = operand_26, .value = operand_36, };
    };
}

fn function_10(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_89) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_90 {
    @setRuntimeSafety(true);

    const value_11: *const (zx_abi).zx_type_91 = block_35: {
        var state_6: *const (zx_abi).zx_type_91 = block_15: {
            const operand_7 = (in).source;
            const operand_8 = (in).name;
            const operand_9 = (in).limit;
            const operand_10 = @as(u64, 0);
            const operand_11 = false;
            const operand_12 = @as(u64, 0);

            break :block_15 block_14: {
                const operand_13 = (try (allocator).create((zx_abi).zx_type_91));

                (operand_13).* = @as((zx_abi).zx_type_91, (zx_abi).zx_type_91{ .source = operand_7, .name = operand_8, .limit = operand_9, .index = operand_10, .found = operand_11, .selected = operand_12, });

                break :block_14 @as(*const (zx_abi).zx_type_91, operand_13);
            };
        };

        while (((!(state_6).found) and ((state_6).index < (state_6).limit))) {
            state_6 = block_33: {
                const value_3: *const (zx_abi).zx_type_54 = (try function_9(allocator, block_32: {
                    const operand_28 = (state_6).source;
                    const operand_29 = (state_6).index;

                    break :block_32 block_31: {
                        const operand_30 = (try (allocator).create((zx_abi).zx_type_88));

                        (operand_30).* = @as((zx_abi).zx_type_88, (zx_abi).zx_type_88{ .source = operand_28, .index = operand_29, });

                        break :block_31 @as(*const (zx_abi).zx_type_88, operand_30);
                    };
                }));
                const value_4: *const (zx_abi).zx_type_91 = state_6;
                const value_5: *const (zx_abi).zx_type_91 = block_27: {
                    break :block_27 block_26: {
                        const operand_25 = (try (allocator).create((zx_abi).zx_type_91));

                        (operand_25).* = @as((zx_abi).zx_type_91, (zx_abi).zx_type_91{ .found = block_24: {
                            const operand_22 = ((value_3).name).text;
                            const operand_23 = (state_6).name;

                            break :block_24 ((std).mem).eql(u8, operand_22, operand_23);
                        }, .index = (value_4).index, .limit = (value_4).limit, .name = (value_4).name, .selected = (value_4).selected, .source = (value_4).source, });

                        break :block_26 @as(*const (zx_abi).zx_type_91, operand_25);
                    };
                };
                const value_6: *const (zx_abi).zx_type_91 = value_5;
                const value_7: *const (zx_abi).zx_type_91 = block_21: {
                    break :block_21 block_20: {
                        const operand_19 = (try (allocator).create((zx_abi).zx_type_91));

                        (operand_19).* = @as((zx_abi).zx_type_91, (zx_abi).zx_type_91{ .found = (value_6).found, .index = (value_6).index, .limit = (value_6).limit, .name = (value_6).name, .selected = (value_5).index, .source = (value_6).source, });

                        break :block_20 @as(*const (zx_abi).zx_type_91, operand_19);
                    };
                };
                const value_8: *const (zx_abi).zx_type_91 = value_7;
                const value_9: u64 = (value_8).index;
                const value_10: *const (zx_abi).zx_type_91 = block_18: {
                    break :block_18 block_17: {
                        const operand_16 = (try (allocator).create((zx_abi).zx_type_91));

                        (operand_16).* = @as((zx_abi).zx_type_91, (zx_abi).zx_type_91{ .found = (value_8).found, .index = (value_9 + @as(u64, 1)), .limit = (value_8).limit, .name = (value_8).name, .selected = (value_8).selected, .source = (value_8).source, });

                        break :block_17 @as(*const (zx_abi).zx_type_91, operand_16);
                    };
                };

                break :block_33 value_10;
            };
        }

        break :block_35 state_6;
    };

    return block_5: {
        const operand_1 = (value_11).found;
        const operand_2 = (value_11).selected;

        break :block_5 block_4: {
            const operand_3 = (try (allocator).create((zx_abi).zx_type_90));

            (operand_3).* = @as((zx_abi).zx_type_90, (zx_abi).zx_type_90{ .found = operand_1, .index = operand_2, });

            break :block_4 @as(*const (zx_abi).zx_type_90, operand_3);
        };
    };
}

fn function_10_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_89_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_90_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_11: (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_66: {
        const operand_47 = block_46: {
            const operand_40 = (in).source;
            const operand_41 = (in).name;
            const operand_42 = (in).limit;
            const operand_43 = @as(u64, 0);
            const operand_44 = false;
            const operand_45 = @as(u64, 0);

            break :block_46 @as((zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .source = operand_40, .name = operand_41, .limit = operand_42, .index = operand_43, .found = operand_44, .selected = operand_45, });
        };

        var state_39: (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = operand_47;

        var state_changed_48 = false;

        while (((!(state_39).found) and ((state_39).index < (state_39).limit))) {
            state_39 = block_64: {
                const value_3: *const (zx_abi).zx_type_54 = block_63: {
                    const operand_60 = block_59: {
                        const operand_57 = (state_39).source;
                        const operand_58 = (state_39).index;

                        break :block_59 @as((zx_abi).value_zx_type_88_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_88_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_57, .index = operand_58, });
                    };

                    break :block_63 (try function_9(allocator, (if (((operand_60).zx_origin != null)) (operand_60).zx_origin.? else block_62: {
                        const operand_61 = (try (allocator).create((zx_abi).zx_type_88));

                        (operand_61).* = (zx_abi).zx_type_88{ .index = (operand_60).index, .source = (operand_60).source, };

                        break :block_62 @as(*const (zx_abi).zx_type_88, operand_61);
                    })));
                };
                const value_4: (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = state_39;
                const value_5: (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_56: {
                    break :block_56 @as((zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .found = block_55: {
                        const operand_53 = ((block_52: {
                            break :block_52 value_3;
                        }).name).text;
                        const operand_54 = (state_39).name;

                        break :block_55 ((std).mem).eql(u8, operand_53, operand_54);
                    }, .index = (value_4).index, .limit = (value_4).limit, .name = (value_4).name, .selected = (value_4).selected, .source = (value_4).source, });
                };
                const value_6: (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = value_5;
                const value_7: (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_51: {
                    break :block_51 @as((zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .found = (value_6).found, .index = (value_6).index, .limit = (value_6).limit, .name = (value_6).name, .selected = (value_5).index, .source = (value_6).source, });
                };
                const value_8: (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = value_7;
                const value_9: u64 = (value_8).index;
                const value_10: (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_50: {
                    break :block_50 @as((zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_91_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .found = (value_8).found, .index = (block_49: {
                        break :block_49 value_9;
                    } + @as(u64, 1)), .limit = (value_8).limit, .name = (value_8).name, .selected = (value_8).selected, .source = (value_8).source, });
                };

                break :block_64 value_10;
            };

            state_changed_48 = true;
        }

        break :block_66 (if (state_changed_48) state_39 else operand_47);
    };

    return block_38: {
        const operand_36 = (value_11).found;
        const operand_37 = (value_11).selected;

        break :block_38 @as((zx_abi).value_zx_type_90_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_90_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .found = operand_36, .index = operand_37, });
    };
}

fn function_11(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_92) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_51 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if (((in).reference).enumeration) {
        const value_2: u64 = (if ((value_1 != null)) (block_55: {
            const operand_53 = (value_1.?).enumerations;
            const operand_54 = ((in).reference).index;

            if ((operand_54 >= (operand_53).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_55 (operand_53)[@intCast(operand_54)];
        }).count else (block_58: {
            const operand_56 = (((in).source).indexed).declarations;
            const operand_57 = ((in).reference).index;

            if ((operand_57 >= (operand_56).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_58 (operand_56)[@intCast(operand_57)];
        }).count);

        return block_52: {
            const operand_34 = @as((zx_abi).zx_type_48, .Enumeration);
            const operand_35 = block_41: {
                const operand_36 = @as([]const u8, "");
                const operand_37 = @as(u64, 0);
                const operand_38 = @as(u64, 0);

                break :block_41 block_40: {
                    const operand_39 = (try (allocator).create((zx_abi).zx_type_49));

                    (operand_39).* = @as((zx_abi).zx_type_49, (zx_abi).zx_type_49{ .text = operand_36, .start = operand_37, .end = operand_38, });

                    break :block_40 @as(*const (zx_abi).zx_type_49, operand_39);
                };
            };
            const operand_42 = block_47: {
                const operand_43 = false;
                const operand_44 = @as(u64, 0);

                break :block_47 block_46: {
                    const operand_45 = (try (allocator).create((zx_abi).zx_type_50));

                    (operand_45).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_43, .index = operand_44, });

                    break :block_46 @as(*const (zx_abi).zx_type_50, operand_45);
                };
            };
            const operand_48 = value_2;
            const operand_49 = @as(u64, 0);

            break :block_52 block_51: {
                const operand_50 = (try (allocator).create((zx_abi).zx_type_51));

                (operand_50).* = @as((zx_abi).zx_type_51, (zx_abi).zx_type_51{ .kind = operand_34, .name = operand_35, .child = operand_42, .count = operand_48, .position = operand_49, });

                break :block_51 @as(*const (zx_abi).zx_type_51, operand_50);
            };
        };
    }

    if ((value_1 != null)) {
        return block_33: {
            const operand_31 = (value_1.?).nodes;
            const operand_32 = ((in).reference).index;

            if ((operand_32 >= (operand_31).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_33 (operand_31)[@intCast(operand_32)];
        };
    }

    const value_3: *const (zx_abi).zx_type_30 = block_30: {
        const operand_28 = ((((in).source).indexed).types).nodes;
        const operand_29 = ((in).reference).index;

        if ((operand_29 >= (operand_28).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_30 (operand_28)[@intCast(operand_29)];
    };
    const value_4: (zx_abi).zx_type_48 = block_27: {
        const operand_26 = (value_3).kind;

        break :block_27 (if ((operand_26 == @as((zx_abi).zx_type_28, .Named))) @as((zx_abi).zx_type_48, .Named) else (if ((operand_26 == @as((zx_abi).zx_type_28, .Object))) @as((zx_abi).zx_type_48, .Object) else (if ((operand_26 == @as((zx_abi).zx_type_28, .Optional))) @as((zx_abi).zx_type_48, .Optional) else (if ((operand_26 == @as((zx_abi).zx_type_28, .List))) @as((zx_abi).zx_type_48, .List) else (if ((operand_26 == @as((zx_abi).zx_type_28, .Tuple))) @as((zx_abi).zx_type_48, .Tuple) else @as((zx_abi).zx_type_48, .Application))))));
    };

    return block_25: {
        const operand_1 = value_4;
        const operand_2 = block_11: {
            const operand_8 = (try function_8_value(allocator, block_7: {
                const operand_3 = (((in).source).indexed).bytes;
                const operand_4 = (value_3).name;

                break :block_7 block_6: {
                    const operand_5 = (try (allocator).create((zx_abi).zx_type_86));

                    (operand_5).* = @as((zx_abi).zx_type_86, (zx_abi).zx_type_86{ .source = operand_3, .span = operand_4, });

                    break :block_6 @as(*const (zx_abi).zx_type_86, operand_5);
                };
            }));

            break :block_11 block_10: {
                const operand_9 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_9).* = @as((zx_abi).zx_type_49, operand_8);

                break :block_10 @as(*const (zx_abi).zx_type_49, operand_9);
            };
        };
        const operand_12 = block_17: {
            const operand_13 = false;
            const operand_14 = (value_3).child;

            break :block_17 block_16: {
                const operand_15 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_15).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_13, .index = operand_14, });

                break :block_16 @as(*const (zx_abi).zx_type_50, operand_15);
            };
        };
        const operand_18 = (value_3).count;
        const operand_19 = block_22: {
            const operand_20 = ((((in).source).indexed).order).heads;
            const operand_21 = ((in).reference).index;

            if ((operand_21 >= (operand_20).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_22 (operand_20)[@intCast(operand_21)];
        };

        break :block_25 block_24: {
            const operand_23 = (try (allocator).create((zx_abi).zx_type_51));

            (operand_23).* = @as((zx_abi).zx_type_51, (zx_abi).zx_type_51{ .kind = operand_1, .name = operand_2, .child = operand_12, .count = operand_18, .position = operand_19, });

            break :block_24 @as(*const (zx_abi).zx_type_51, operand_23);
        };
    };
}

fn function_11_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_92) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).zx_type_51 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if (((in).reference).enumeration) {
        const value_2: u64 = (if ((value_1 != null)) (block_109: {
            const operand_107 = (value_1.?).enumerations;
            const operand_108 = ((in).reference).index;

            if ((operand_108 >= (operand_107).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_109 (operand_107)[@intCast(operand_108)];
        }).count else (block_112: {
            const operand_110 = (((in).source).indexed).declarations;
            const operand_111 = ((in).reference).index;

            if ((operand_111 >= (operand_110).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_112 (operand_110)[@intCast(operand_111)];
        }).count);

        return block_106: {
            const operand_90 = @as((zx_abi).zx_type_48, .Enumeration);
            const operand_91 = block_97: {
                const operand_92 = @as([]const u8, "");
                const operand_93 = @as(u64, 0);
                const operand_94 = @as(u64, 0);

                break :block_97 block_96: {
                    const operand_95 = (try (allocator).create((zx_abi).zx_type_49));

                    (operand_95).* = @as((zx_abi).zx_type_49, (zx_abi).zx_type_49{ .text = operand_92, .start = operand_93, .end = operand_94, });

                    break :block_96 @as(*const (zx_abi).zx_type_49, operand_95);
                };
            };
            const operand_98 = block_103: {
                const operand_99 = false;
                const operand_100 = @as(u64, 0);

                break :block_103 block_102: {
                    const operand_101 = (try (allocator).create((zx_abi).zx_type_50));

                    (operand_101).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_99, .index = operand_100, });

                    break :block_102 @as(*const (zx_abi).zx_type_50, operand_101);
                };
            };
            const operand_104 = value_2;
            const operand_105 = @as(u64, 0);

            break :block_106 (zx_abi).zx_type_51{ .kind = operand_90, .name = operand_91, .child = operand_98, .count = operand_104, .position = operand_105, };
        };
    }

    if ((value_1 != null)) {
        return (block_89: {
            const operand_87 = (value_1.?).nodes;
            const operand_88 = ((in).reference).index;

            if ((operand_88 >= (operand_87).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_89 (operand_87)[@intCast(operand_88)];
        }).*;
    }

    const value_3: (zx_abi).zx_type_30 = (block_86: {
        const operand_84 = ((((in).source).indexed).types).nodes;
        const operand_85 = ((in).reference).index;

        if ((operand_85 >= (operand_84).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_86 (operand_84)[@intCast(operand_85)];
    }).*;
    const value_4: (zx_abi).zx_type_48 = block_83: {
        const operand_82 = ((&value_3)).kind;

        break :block_83 (if ((operand_82 == @as((zx_abi).zx_type_28, .Named))) @as((zx_abi).zx_type_48, .Named) else (if ((operand_82 == @as((zx_abi).zx_type_28, .Object))) @as((zx_abi).zx_type_48, .Object) else (if ((operand_82 == @as((zx_abi).zx_type_28, .Optional))) @as((zx_abi).zx_type_48, .Optional) else (if ((operand_82 == @as((zx_abi).zx_type_28, .List))) @as((zx_abi).zx_type_48, .List) else (if ((operand_82 == @as((zx_abi).zx_type_28, .Tuple))) @as((zx_abi).zx_type_48, .Tuple) else @as((zx_abi).zx_type_48, .Application))))));
    };

    return block_81: {
        const operand_59 = value_4;
        const operand_60 = block_69: {
            const operand_66 = (try function_8_value(allocator, block_65: {
                const operand_61 = (((in).source).indexed).bytes;
                const operand_62 = ((&value_3)).name;

                break :block_65 block_64: {
                    const operand_63 = (try (allocator).create((zx_abi).zx_type_86));

                    (operand_63).* = @as((zx_abi).zx_type_86, (zx_abi).zx_type_86{ .source = operand_61, .span = operand_62, });

                    break :block_64 @as(*const (zx_abi).zx_type_86, operand_63);
                };
            }));

            break :block_69 block_68: {
                const operand_67 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_67).* = @as((zx_abi).zx_type_49, operand_66);

                break :block_68 @as(*const (zx_abi).zx_type_49, operand_67);
            };
        };
        const operand_70 = block_75: {
            const operand_71 = false;
            const operand_72 = ((&value_3)).child;

            break :block_75 block_74: {
                const operand_73 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_73).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_71, .index = operand_72, });

                break :block_74 @as(*const (zx_abi).zx_type_50, operand_73);
            };
        };
        const operand_76 = ((&value_3)).count;
        const operand_77 = block_80: {
            const operand_78 = ((((in).source).indexed).order).heads;
            const operand_79 = ((in).reference).index;

            if ((operand_79 >= (operand_78).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_80 (operand_78)[@intCast(operand_79)];
        };

        break :block_81 (zx_abi).zx_type_51{ .kind = operand_59, .name = operand_60, .child = operand_70, .count = operand_76, .position = operand_77, };
    };
}

fn function_12(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_92) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    return block_26: {
        const operand_7 = block_6: {
            const operand_2 = (in).source;
            const operand_3 = (in).reference;
            const operand_4 = true;
            const operand_5 = false;

            break :block_6 (zx_abi).zx_type_93{ .source = operand_2, .reference = operand_3, .active = operand_4, .valid = operand_5, };
        };

        var state_1: (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .active = (operand_7).active, .reference = (operand_7).reference, .source = (operand_7).source, .valid = (operand_7).valid, .zx_origin = (&operand_7), };

        while ((state_1).active) {
            state_1 = block_25: {
                const value_3: *const (zx_abi).zx_type_51 = block_24: {
                    const operand_21 = block_20: {
                        const operand_18 = (state_1).source;
                        const operand_19 = (state_1).reference;

                        break :block_20 @as((zx_abi).value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_18, .reference = operand_19, });
                    };

                    break :block_24 (try function_11(allocator, (if (((operand_21).zx_origin != null)) (operand_21).zx_origin.? else block_23: {
                        const operand_22 = (try (allocator).create((zx_abi).zx_type_92));

                        (operand_22).* = (zx_abi).zx_type_92{ .reference = (operand_21).reference, .source = (operand_21).source, };

                        break :block_23 @as(*const (zx_abi).zx_type_92, operand_22);
                    })));
                };
                const value_10: (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if (((((block_8: {
                    break :block_8 value_3;
                }).kind == @as((zx_abi).zx_type_48, .Optional)) or ((block_9: {
                    break :block_9 value_3;
                }).kind == @as((zx_abi).zx_type_48, .List))) or ((block_10: {
                    break :block_10 value_3;
                }).kind == @as((zx_abi).zx_type_48, .Application)))) block_13: {
                    const value_4: (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = state_1;
                    const value_5: (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_12: {
                        break :block_12 @as((zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .active = (value_4).active, .reference = (block_11: {
                            break :block_11 value_3;
                        }).child, .source = (value_4).source, .valid = (value_4).valid, });
                    };

                    break :block_13 value_5;
                } else block_17: {
                    const value_6: (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = state_1;
                    const value_7: (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_16: {
                        break :block_16 @as((zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .active = (value_6).active, .reference = (value_6).reference, .source = (value_6).source, .valid = ((block_15: {
                            break :block_15 value_3;
                        }).kind == @as((zx_abi).zx_type_48, .Named)), });
                    };
                    const value_8: (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = value_7;
                    const value_9: (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_14: {
                        break :block_14 @as((zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_93_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .active = false, .reference = (value_8).reference, .source = (value_8).source, .valid = (value_8).valid, });
                    };

                    break :block_17 value_9;
                });

                break :block_25 value_10;
            };
        }

        break :block_26 (state_1).valid;
    };
}

fn function_13(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_94) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_52 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return block_29: {
            const operand_27 = (value_1.?).fields;
            const operand_28 = ((in).position - @as(u64, 1));

            if ((operand_28 >= (operand_27).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_29 (operand_27)[@intCast(operand_28)];
        };
    }

    const value_2: *const (zx_abi).zx_type_31 = block_26: {
        const operand_24 = ((((in).source).indexed).types).fields;
        const operand_25 = ((in).position - @as(u64, 1));

        if ((operand_25 >= (operand_24).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_26 (operand_24)[@intCast(operand_25)];
    };

    return block_23: {
        const operand_1 = block_10: {
            const operand_7 = (try function_8_value(allocator, block_6: {
                const operand_2 = (((in).source).indexed).bytes;
                const operand_3 = (value_2).name;

                break :block_6 block_5: {
                    const operand_4 = (try (allocator).create((zx_abi).zx_type_86));

                    (operand_4).* = @as((zx_abi).zx_type_86, (zx_abi).zx_type_86{ .source = operand_2, .span = operand_3, });

                    break :block_5 @as(*const (zx_abi).zx_type_86, operand_4);
                };
            }));

            break :block_10 block_9: {
                const operand_8 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_8).* = @as((zx_abi).zx_type_49, operand_7);

                break :block_9 @as(*const (zx_abi).zx_type_49, operand_8);
            };
        };
        const operand_11 = block_16: {
            const operand_12 = false;
            const operand_13 = (value_2).value;

            break :block_16 block_15: {
                const operand_14 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_14).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_12, .index = operand_13, });

                break :block_15 @as(*const (zx_abi).zx_type_50, operand_14);
            };
        };
        const operand_17 = block_20: {
            const operand_18 = ((((in).source).indexed).order).fields;
            const operand_19 = ((in).position - @as(u64, 1));

            if ((operand_19 >= (operand_18).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_20 (operand_18)[@intCast(operand_19)];
        };

        break :block_23 block_22: {
            const operand_21 = (try (allocator).create((zx_abi).zx_type_52));

            (operand_21).* = @as((zx_abi).zx_type_52, (zx_abi).zx_type_52{ .name = operand_1, .value = operand_11, .next = operand_17, });

            break :block_22 @as(*const (zx_abi).zx_type_52, operand_21);
        };
    };
}

fn function_13_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_94) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).zx_type_52 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return (block_56: {
            const operand_54 = (value_1.?).fields;
            const operand_55 = ((in).position - @as(u64, 1));

            if ((operand_55 >= (operand_54).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_56 (operand_54)[@intCast(operand_55)];
        }).*;
    }

    const value_2: (zx_abi).zx_type_31 = (block_53: {
        const operand_51 = ((((in).source).indexed).types).fields;
        const operand_52 = ((in).position - @as(u64, 1));

        if ((operand_52 >= (operand_51).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_53 (operand_51)[@intCast(operand_52)];
    }).*;

    return block_50: {
        const operand_30 = block_39: {
            const operand_36 = (try function_8_value(allocator, block_35: {
                const operand_31 = (((in).source).indexed).bytes;
                const operand_32 = ((&value_2)).name;

                break :block_35 block_34: {
                    const operand_33 = (try (allocator).create((zx_abi).zx_type_86));

                    (operand_33).* = @as((zx_abi).zx_type_86, (zx_abi).zx_type_86{ .source = operand_31, .span = operand_32, });

                    break :block_34 @as(*const (zx_abi).zx_type_86, operand_33);
                };
            }));

            break :block_39 block_38: {
                const operand_37 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_37).* = @as((zx_abi).zx_type_49, operand_36);

                break :block_38 @as(*const (zx_abi).zx_type_49, operand_37);
            };
        };
        const operand_40 = block_45: {
            const operand_41 = false;
            const operand_42 = ((&value_2)).value;

            break :block_45 block_44: {
                const operand_43 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_43).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_41, .index = operand_42, });

                break :block_44 @as(*const (zx_abi).zx_type_50, operand_43);
            };
        };
        const operand_46 = block_49: {
            const operand_47 = ((((in).source).indexed).order).fields;
            const operand_48 = ((in).position - @as(u64, 1));

            if ((operand_48 >= (operand_47).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_49 (operand_47)[@intCast(operand_48)];
        };

        break :block_50 (zx_abi).zx_type_52{ .name = operand_30, .value = operand_40, .next = operand_46, };
    };
}

fn function_14(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_94) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_53 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return block_19: {
            const operand_17 = (value_1.?).items;
            const operand_18 = ((in).position - @as(u64, 1));

            if ((operand_18 >= (operand_17).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_19 (operand_17)[@intCast(operand_18)];
        };
    }

    return block_16: {
        const operand_1 = block_9: {
            const operand_2 = false;
            const operand_3 = (block_6: {
                const operand_4 = ((((in).source).indexed).types).items;
                const operand_5 = ((in).position - @as(u64, 1));

                if ((operand_5 >= (operand_4).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_6 (operand_4)[@intCast(operand_5)];
            }).value;

            break :block_9 block_8: {
                const operand_7 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_7).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_2, .index = operand_3, });

                break :block_8 @as(*const (zx_abi).zx_type_50, operand_7);
            };
        };
        const operand_10 = block_13: {
            const operand_11 = ((((in).source).indexed).order).items;
            const operand_12 = ((in).position - @as(u64, 1));

            if ((operand_12 >= (operand_11).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_13 (operand_11)[@intCast(operand_12)];
        };

        break :block_16 block_15: {
            const operand_14 = (try (allocator).create((zx_abi).zx_type_53));

            (operand_14).* = @as((zx_abi).zx_type_53, (zx_abi).zx_type_53{ .value = operand_1, .next = operand_10, });

            break :block_15 @as(*const (zx_abi).zx_type_53, operand_14);
        };
    };
}

fn function_14_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_94) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).zx_type_53 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return (block_36: {
            const operand_34 = (value_1.?).items;
            const operand_35 = ((in).position - @as(u64, 1));

            if ((operand_35 >= (operand_34).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_36 (operand_34)[@intCast(operand_35)];
        }).*;
    }

    return block_33: {
        const operand_20 = block_28: {
            const operand_21 = false;
            const operand_22 = (block_25: {
                const operand_23 = ((((in).source).indexed).types).items;
                const operand_24 = ((in).position - @as(u64, 1));

                if ((operand_24 >= (operand_23).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_25 (operand_23)[@intCast(operand_24)];
            }).value;

            break :block_28 block_27: {
                const operand_26 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_26).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_21, .index = operand_22, });

                break :block_27 @as(*const (zx_abi).zx_type_50, operand_26);
            };
        };
        const operand_29 = block_32: {
            const operand_30 = ((((in).source).indexed).order).items;
            const operand_31 = ((in).position - @as(u64, 1));

            if ((operand_31 >= (operand_30).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_32 (operand_30)[@intCast(operand_31)];
        };

        break :block_33 (zx_abi).zx_type_53{ .value = operand_20, .next = operand_29, };
    };
}

fn function_15(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_95) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: u64 = (if ((@as(u64, ((in).left).len) < @as(u64, ((in).right).len))) @as(u64, ((in).left).len) else @as(u64, ((in).right).len));
    const value_10: (zx_abi).zx_type_96 = block_28: {
        const operand_14 = block_13: {
            const operand_8 = (in).left;
            const operand_9 = (in).right;
            const operand_10 = @as(u64, 0);
            const operand_11 = value_1;
            const operand_12 = true;

            break :block_13 (zx_abi).zx_type_96{ .left = operand_8, .right = operand_9, .index = operand_10, .limit = operand_11, .equal = operand_12, };
        };

        var state_7: (zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = (zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .equal = (operand_14).equal, .index = (operand_14).index, .left = (operand_14).left, .limit = (operand_14).limit, .right = (operand_14).right, .zx_origin = (&operand_14), };

        while (((state_7).equal and ((state_7).index < (state_7).limit))) {
            state_7 = block_25: {
                const value_4: (zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = state_7;
                const value_5: (zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_24: {
                    break :block_24 @as((zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .equal = (block_20: {
                        const operand_18 = (state_7).left;
                        const operand_19 = (state_7).index;

                        if ((operand_19 >= (operand_18).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_20 (operand_18)[@intCast(operand_19)];
                    } == block_23: {
                        const operand_21 = (state_7).right;
                        const operand_22 = (state_7).index;

                        if ((operand_22 >= (operand_21).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_23 (operand_21)[@intCast(operand_22)];
                    }), .index = (value_4).index, .left = (value_4).left, .limit = (value_4).limit, .right = (value_4).right, });
                };
                const value_9: (zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = (if ((value_5).equal) block_17: {
                    const value_6: (zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = value_5;
                    const value_7: u64 = (value_6).index;
                    const value_8: (zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_16: {
                        break :block_16 @as((zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .equal = (value_6).equal, .index = (block_15: {
                            break :block_15 value_7;
                        } + @as(u64, 1)), .left = (value_6).left, .limit = (value_6).limit, .right = (value_6).right, });
                    };

                    break :block_17 value_8;
                } else value_5);

                break :block_25 value_9;
            };
        }

        break :block_28 block_27: {
            break :block_27 (if (((state_7).zx_origin != null)) ((state_7).zx_origin.?).* else block_26: {
                break :block_26 (zx_abi).zx_type_96{ .equal = (state_7).equal, .index = (state_7).index, .left = (state_7).left, .limit = (state_7).limit, .right = (state_7).right, };
            });
        };
    };

    return (if ((((&value_10)).index == ((&value_10)).limit)) (@as(u64, (((&value_10)).left).len) < @as(u64, (((&value_10)).right).len)) else (block_3: {
        const operand_1 = ((&value_10)).left;
        const operand_2 = ((&value_10)).index;

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    } < block_6: {
        const operand_4 = ((&value_10)).right;
        const operand_5 = ((&value_10)).index;

        if ((operand_5 >= (operand_4).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_6 (operand_4)[@intCast(operand_5)];
    }));
}

fn function_16(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_97) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }![]const u64 {
    @setRuntimeSafety(true);

    const value_1: []const []const u8 = block_211: {
        break :block_211 (try (allocator).dupe([]const u8, (&[_][]const u8{})));
    };
    const value_2: []const u64 = block_210: {
        break :block_210 (try (allocator).dupe(u64, (&[_]u64{})));
    };
    const value_19: *const (zx_abi).zx_type_99 = block_209: {
        var state_163: *const (zx_abi).zx_type_99 = block_171: {
            const operand_164 = in;
            const operand_165 = (in).position;
            const operand_166 = @as(u64, 0);
            const operand_167 = value_1;
            const operand_168 = value_2;

            break :block_171 block_170: {
                const operand_169 = (try (allocator).create((zx_abi).zx_type_99));

                (operand_169).* = @as((zx_abi).zx_type_99, (zx_abi).zx_type_99{ .input = operand_164, .position = operand_165, .index = operand_166, .names = operand_167, .positions = operand_168, });

                break :block_170 @as(*const (zx_abi).zx_type_99, operand_169);
            };
        };

        while (((state_163).index < ((state_163).input).count)) {
            state_163 = block_207: {
                const value_5: *const (zx_abi).zx_type_99 = state_163;
                const value_6: *const (zx_abi).zx_type_99 = block_206: {
                    break :block_206 block_205: {
                        const operand_204 = (try (allocator).create((zx_abi).zx_type_99));

                        (operand_204).* = @as((zx_abi).zx_type_99, (zx_abi).zx_type_99{ .index = (value_5).index, .input = (value_5).input, .names = (value_5).names, .position = (value_5).position, .positions = (block_203: {
                            const operand_200 = (state_163).positions;
                            const operand_201 = (state_163).position;
                            const operand_202 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_200).len, 1))));

                            @memcpy((operand_202)[0..(operand_200).len], operand_200);

                            (operand_202)[(operand_200).len] = operand_201;

                            break :block_203 @as((zx_abi).zx_type_83, .{ operand_202, {}, });
                        }).@"0", });

                        break :block_205 @as(*const (zx_abi).zx_type_99, operand_204);
                    };
                };
                const value_15: *const (zx_abi).zx_type_99 = (if (((value_6).input).object) block_190: {
                    const value_7: *const (zx_abi).zx_type_52 = (try function_13(allocator, block_189: {
                        const operand_185 = ((value_6).input).source;
                        const operand_186 = (value_6).position;

                        break :block_189 block_188: {
                            const operand_187 = (try (allocator).create((zx_abi).zx_type_94));

                            (operand_187).* = @as((zx_abi).zx_type_94, (zx_abi).zx_type_94{ .source = operand_185, .position = operand_186, });

                            break :block_188 @as(*const (zx_abi).zx_type_94, operand_187);
                        };
                    }));
                    const value_8: *const (zx_abi).zx_type_99 = value_6;
                    const value_9: *const (zx_abi).zx_type_99 = block_184: {
                        break :block_184 block_183: {
                            const operand_182 = (try (allocator).create((zx_abi).zx_type_99));

                            (operand_182).* = @as((zx_abi).zx_type_99, (zx_abi).zx_type_99{ .index = (value_8).index, .input = (value_8).input, .names = (block_181: {
                                const operand_178 = (value_6).names;
                                const operand_179 = ((value_7).name).text;
                                const operand_180 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_178).len, 1))));

                                @memcpy((operand_180)[0..(operand_178).len], operand_178);

                                (operand_180)[(operand_178).len] = operand_179;

                                break :block_181 @as((zx_abi).zx_type_100, .{ operand_180, {}, });
                            }).@"0", .position = (value_8).position, .positions = (value_8).positions, });

                            break :block_183 @as(*const (zx_abi).zx_type_99, operand_182);
                        };
                    };
                    const value_10: *const (zx_abi).zx_type_99 = value_9;
                    const value_11: *const (zx_abi).zx_type_99 = block_177: {
                        break :block_177 block_176: {
                            const operand_175 = (try (allocator).create((zx_abi).zx_type_99));

                            (operand_175).* = @as((zx_abi).zx_type_99, (zx_abi).zx_type_99{ .index = (value_10).index, .input = (value_10).input, .names = (value_10).names, .position = (value_7).next, .positions = (value_10).positions, });

                            break :block_176 @as(*const (zx_abi).zx_type_99, operand_175);
                        };
                    };

                    break :block_190 value_11;
                } else block_199: {
                    const value_12: *const (zx_abi).zx_type_53 = (try function_14(allocator, block_198: {
                        const operand_194 = ((value_6).input).source;
                        const operand_195 = (value_6).position;

                        break :block_198 block_197: {
                            const operand_196 = (try (allocator).create((zx_abi).zx_type_94));

                            (operand_196).* = @as((zx_abi).zx_type_94, (zx_abi).zx_type_94{ .source = operand_194, .position = operand_195, });

                            break :block_197 @as(*const (zx_abi).zx_type_94, operand_196);
                        };
                    }));
                    const value_13: *const (zx_abi).zx_type_99 = value_6;
                    const value_14: *const (zx_abi).zx_type_99 = block_193: {
                        break :block_193 block_192: {
                            const operand_191 = (try (allocator).create((zx_abi).zx_type_99));

                            (operand_191).* = @as((zx_abi).zx_type_99, (zx_abi).zx_type_99{ .index = (value_13).index, .input = (value_13).input, .names = (value_13).names, .position = (value_12).next, .positions = (value_13).positions, });

                            break :block_192 @as(*const (zx_abi).zx_type_99, operand_191);
                        };
                    };

                    break :block_199 value_14;
                });
                const value_16: *const (zx_abi).zx_type_99 = value_15;
                const value_17: u64 = (value_16).index;
                const value_18: *const (zx_abi).zx_type_99 = block_174: {
                    break :block_174 block_173: {
                        const operand_172 = (try (allocator).create((zx_abi).zx_type_99));

                        (operand_172).* = @as((zx_abi).zx_type_99, (zx_abi).zx_type_99{ .index = (value_17 + @as(u64, 1)), .input = (value_16).input, .names = (value_16).names, .position = (value_16).position, .positions = (value_16).positions, });

                        break :block_173 @as(*const (zx_abi).zx_type_99, operand_172);
                    };
                };

                break :block_207 value_18;
            };
        }

        break :block_209 state_163;
    };

    if (((!(in).object) or ((in).count < @as(u64, 2)))) {
        return (value_19).positions;
    }

    return block_162: {
        const operand_10 = block_9: {
            const operand_2 = (value_19).names;
            const operand_3 = (value_19).positions;
            const operand_4 = (in).count;
            const operand_5 = @divTrunc((in).count, @as(u64, 2));
            const operand_6 = @as(u64, 0);
            const operand_7 = true;
            const operand_8 = false;

            break :block_9 (zx_abi).zx_type_101{ .names = operand_2, .positions = operand_3, .count = operand_4, .remaining = operand_5, .root = operand_6, .building = operand_7, .sifting = operand_8, };
        };

        var state_items_11: [][]const u8 = undefined;

        var state_items_started_12 = false;

        var state_items_13: []u64 = undefined;

        var state_items_started_14 = false;

        var state_1: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (operand_10).building, .count = (operand_10).count, .names = (operand_10).names, .positions = (operand_10).positions, .remaining = (operand_10).remaining, .root = (operand_10).root, .sifting = (operand_10).sifting, .zx_origin = (&operand_10), };

        while ((((state_1).building or ((state_1).count > @as(u64, 1))) or (state_1).sifting)) {
            state_1 = block_161: {
                const value_87: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if ((state_1).sifting) block_100: {
                    const value_50: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if (((state_1).root >= @divTrunc((state_1).count, @as(u64, 2)))) block_16: {
                        const value_22: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = state_1;
                        const value_23: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_15: {
                            break :block_15 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_22).building, .count = (value_22).count, .names = (value_22).names, .positions = (value_22).positions, .remaining = (value_22).remaining, .root = (value_22).root, .sifting = false, });
                        };

                        break :block_16 value_23;
                    } else block_99: {
                        const value_24: u64 = (((state_1).root * @as(u64, 2)) + @as(u64, 1));
                        const value_25: u64 = (block_98: {
                            break :block_98 value_24;
                        } + @as(u64, 1));
                        const value_26: u64 = (if (((block_83: {
                            break :block_83 value_25;
                        } < (state_1).count) and block_95: {
                            const operand_88 = block_87: {
                                const operand_85 = (state_1).names;
                                const operand_86 = block_84: {
                                    break :block_84 value_24;
                                };

                                if ((operand_86 >= (operand_85).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_87 (operand_85)[@intCast(operand_86)];
                            };
                            const operand_93 = block_92: {
                                const operand_90 = (state_1).names;
                                const operand_91 = block_89: {
                                    break :block_89 value_25;
                                };

                                if ((operand_91 >= (operand_90).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_92 (operand_90)[@intCast(operand_91)];
                            };
                            const operand_94 = (zx_abi).zx_type_95{ .left = operand_88, .right = operand_93, };

                            break :block_95 (try function_15(allocator, (&operand_94)));
                        })) block_96: {
                            break :block_96 value_25;
                        } else block_97: {
                            break :block_97 value_24;
                        });
                        const value_49: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if (block_27: {
                            const operand_20 = block_19: {
                                const operand_17 = (state_1).names;
                                const operand_18 = (state_1).root;

                                if ((operand_18 >= (operand_17).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_19 (operand_17)[@intCast(operand_18)];
                            };
                            const operand_25 = block_24: {
                                const operand_22 = (state_1).names;
                                const operand_23 = block_21: {
                                    break :block_21 value_26;
                                };

                                if ((operand_23 >= (operand_22).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_24 (operand_22)[@intCast(operand_23)];
                            };
                            const operand_26 = (zx_abi).zx_type_95{ .left = operand_20, .right = operand_25, };

                            break :block_27 (try function_15(allocator, (&operand_26)));
                        }) block_80: {
                            const value_27: []const u8 = block_79: {
                                const operand_77 = (state_1).names;
                                const operand_78 = (state_1).root;

                                if ((operand_78 >= (operand_77).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_79 (operand_77)[@intCast(operand_78)];
                            };
                            const value_28: u64 = block_76: {
                                const operand_74 = (state_1).positions;
                                const operand_75 = (state_1).root;

                                if ((operand_75 >= (operand_74).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_76 (operand_74)[@intCast(operand_75)];
                            };
                            const value_29: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = state_1;
                            const value_30: []const []const u8 = (value_29).names;
                            const value_31: u64 = (state_1).root;
                            const value_32: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_73: {
                                break :block_73 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_29).building, .count = (value_29).count, .names = block_72: {
                                    const operand_63 = block_62: {
                                        break :block_62 value_30;
                                    };
                                    const operand_65 = block_64: {
                                        break :block_64 value_31;
                                    };

                                    if ((operand_65 >= (operand_63).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    const operand_70 = block_69: {
                                        const operand_67 = (state_1).names;
                                        const operand_68 = block_66: {
                                            break :block_66 value_26;
                                        };

                                        if ((operand_68 >= (operand_67).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_69 (operand_67)[@intCast(operand_68)];
                                    };

                                    break :block_72 block_71: {
                                        if ((!state_items_started_12)) {
                                            state_items_11 = (try (allocator).dupe([]const u8, operand_63));

                                            state_items_started_12 = true;
                                        }

                                        (state_items_11)[@intCast(operand_65)] = operand_70;

                                        break :block_71 state_items_11;
                                    };
                                }, .positions = (value_29).positions, .remaining = (value_29).remaining, .root = (value_29).root, .sifting = (value_29).sifting, });
                            };
                            const value_33: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_32;
                            const value_34: []const u64 = (value_33).positions;
                            const value_35: u64 = (value_32).root;
                            const value_36: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_61: {
                                break :block_61 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_33).building, .count = (value_33).count, .names = (value_33).names, .positions = block_60: {
                                    const operand_51 = block_50: {
                                        break :block_50 value_34;
                                    };
                                    const operand_53 = block_52: {
                                        break :block_52 value_35;
                                    };

                                    if ((operand_53 >= (operand_51).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    const operand_58 = block_57: {
                                        const operand_55 = (value_32).positions;
                                        const operand_56 = block_54: {
                                            break :block_54 value_26;
                                        };

                                        if ((operand_56 >= (operand_55).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_57 (operand_55)[@intCast(operand_56)];
                                    };

                                    break :block_60 block_59: {
                                        if ((!state_items_started_14)) {
                                            state_items_13 = (try (allocator).dupe(u64, operand_51));

                                            state_items_started_14 = true;
                                        }

                                        (state_items_13)[@intCast(operand_53)] = operand_58;

                                        break :block_59 state_items_13;
                                    };
                                }, .remaining = (value_33).remaining, .root = (value_33).root, .sifting = (value_33).sifting, });
                            };
                            const value_37: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_36;
                            const value_38: []const []const u8 = (value_37).names;
                            const value_39: u64 = block_49: {
                                break :block_49 value_26;
                            };
                            const value_40: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_48: {
                                break :block_48 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_37).building, .count = (value_37).count, .names = block_47: {
                                    const operand_41 = block_40: {
                                        break :block_40 value_38;
                                    };
                                    const operand_43 = block_42: {
                                        break :block_42 value_39;
                                    };

                                    if ((operand_43 >= (operand_41).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    const operand_45 = block_44: {
                                        break :block_44 value_27;
                                    };

                                    break :block_47 block_46: {
                                        if ((!state_items_started_12)) {
                                            state_items_11 = (try (allocator).dupe([]const u8, operand_41));

                                            state_items_started_12 = true;
                                        }

                                        (state_items_11)[@intCast(operand_43)] = operand_45;

                                        break :block_46 state_items_11;
                                    };
                                }, .positions = (value_37).positions, .remaining = (value_37).remaining, .root = (value_37).root, .sifting = (value_37).sifting, });
                            };
                            const value_41: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_40;
                            const value_42: []const u64 = (value_41).positions;
                            const value_43: u64 = block_39: {
                                break :block_39 value_26;
                            };
                            const value_44: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_38: {
                                break :block_38 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_41).building, .count = (value_41).count, .names = (value_41).names, .positions = block_37: {
                                    const operand_31 = block_30: {
                                        break :block_30 value_42;
                                    };
                                    const operand_33 = block_32: {
                                        break :block_32 value_43;
                                    };

                                    if ((operand_33 >= (operand_31).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    const operand_35 = block_34: {
                                        break :block_34 value_28;
                                    };

                                    break :block_37 block_36: {
                                        if ((!state_items_started_14)) {
                                            state_items_13 = (try (allocator).dupe(u64, operand_31));

                                            state_items_started_14 = true;
                                        }

                                        (state_items_13)[@intCast(operand_33)] = operand_35;

                                        break :block_36 state_items_13;
                                    };
                                }, .remaining = (value_41).remaining, .root = (value_41).root, .sifting = (value_41).sifting, });
                            };
                            const value_45: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_44;
                            const value_46: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_29: {
                                break :block_29 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_45).building, .count = (value_45).count, .names = (value_45).names, .positions = (value_45).positions, .remaining = (value_45).remaining, .root = block_28: {
                                    break :block_28 value_26;
                                }, .sifting = (value_45).sifting, });
                            };

                            break :block_80 value_46;
                        } else block_82: {
                            const value_47: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = state_1;
                            const value_48: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_81: {
                                break :block_81 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_47).building, .count = (value_47).count, .names = (value_47).names, .positions = (value_47).positions, .remaining = (value_47).remaining, .root = (value_47).root, .sifting = false, });
                            };

                            break :block_82 value_48;
                        });

                        break :block_99 value_49;
                    });

                    break :block_100 value_50;
                } else block_160: {
                    const value_86: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if ((state_1).building) block_108: {
                        const value_60: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if (((state_1).remaining == @as(u64, 0))) block_102: {
                            const value_51: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = state_1;
                            const value_52: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_101: {
                                break :block_101 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = false, .count = (value_51).count, .names = (value_51).names, .positions = (value_51).positions, .remaining = (value_51).remaining, .root = (value_51).root, .sifting = (value_51).sifting, });
                            };

                            break :block_102 value_52;
                        } else block_107: {
                            const value_53: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = state_1;
                            const value_54: u64 = (value_53).remaining;
                            const value_55: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_106: {
                                break :block_106 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_53).building, .count = (value_53).count, .names = (value_53).names, .positions = (value_53).positions, .remaining = (block_105: {
                                    break :block_105 value_54;
                                } - @as(u64, 1)), .root = (value_53).root, .sifting = (value_53).sifting, });
                            };
                            const value_56: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_55;
                            const value_57: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_104: {
                                break :block_104 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_56).building, .count = (value_56).count, .names = (value_56).names, .positions = (value_56).positions, .remaining = (value_56).remaining, .root = (value_55).remaining, .sifting = (value_56).sifting, });
                            };
                            const value_58: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_57;
                            const value_59: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_103: {
                                break :block_103 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_58).building, .count = (value_58).count, .names = (value_58).names, .positions = (value_58).positions, .remaining = (value_58).remaining, .root = (value_58).root, .sifting = true, });
                            };

                            break :block_107 value_59;
                        });

                        break :block_108 value_60;
                    } else block_159: {
                        const value_61: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = state_1;
                        const value_62: u64 = (value_61).count;
                        const value_63: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_158: {
                            break :block_158 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_61).building, .count = (block_157: {
                                break :block_157 value_62;
                            } - @as(u64, 1)), .names = (value_61).names, .positions = (value_61).positions, .remaining = (value_61).remaining, .root = (value_61).root, .sifting = (value_61).sifting, });
                        };
                        const value_64: []const u8 = block_156: {
                            const operand_154 = (value_63).names;
                            const operand_155 = @as(u64, 0);

                            if ((operand_155 >= (operand_154).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_156 (operand_154)[@intCast(operand_155)];
                        };
                        const value_65: u64 = block_153: {
                            const operand_151 = (value_63).positions;
                            const operand_152 = @as(u64, 0);

                            if ((operand_152 >= (operand_151).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_153 (operand_151)[@intCast(operand_152)];
                        };
                        const value_66: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_63;
                        const value_67: []const []const u8 = (value_66).names;
                        const value_68: u64 = @as(u64, 0);
                        const value_69: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_150: {
                            break :block_150 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_66).building, .count = (value_66).count, .names = block_149: {
                                const operand_141 = block_140: {
                                    break :block_140 value_67;
                                };
                                const operand_143 = block_142: {
                                    break :block_142 value_68;
                                };

                                if ((operand_143 >= (operand_141).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_147 = block_146: {
                                    const operand_144 = (value_63).names;
                                    const operand_145 = (value_63).count;

                                    if ((operand_145 >= (operand_144).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_146 (operand_144)[@intCast(operand_145)];
                                };

                                break :block_149 block_148: {
                                    if ((!state_items_started_12)) {
                                        state_items_11 = (try (allocator).dupe([]const u8, operand_141));

                                        state_items_started_12 = true;
                                    }

                                    (state_items_11)[@intCast(operand_143)] = operand_147;

                                    break :block_148 state_items_11;
                                };
                            }, .positions = (value_66).positions, .remaining = (value_66).remaining, .root = (value_66).root, .sifting = (value_66).sifting, });
                        };
                        const value_70: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_69;
                        const value_71: []const u64 = (value_70).positions;
                        const value_72: u64 = @as(u64, 0);
                        const value_73: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_139: {
                            break :block_139 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_70).building, .count = (value_70).count, .names = (value_70).names, .positions = block_138: {
                                const operand_130 = block_129: {
                                    break :block_129 value_71;
                                };
                                const operand_132 = block_131: {
                                    break :block_131 value_72;
                                };

                                if ((operand_132 >= (operand_130).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_136 = block_135: {
                                    const operand_133 = (value_69).positions;
                                    const operand_134 = (value_69).count;

                                    if ((operand_134 >= (operand_133).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_135 (operand_133)[@intCast(operand_134)];
                                };

                                break :block_138 block_137: {
                                    if ((!state_items_started_14)) {
                                        state_items_13 = (try (allocator).dupe(u64, operand_130));

                                        state_items_started_14 = true;
                                    }

                                    (state_items_13)[@intCast(operand_132)] = operand_136;

                                    break :block_137 state_items_13;
                                };
                            }, .remaining = (value_70).remaining, .root = (value_70).root, .sifting = (value_70).sifting, });
                        };
                        const value_74: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_73;
                        const value_75: []const []const u8 = (value_74).names;
                        const value_76: u64 = (value_73).count;
                        const value_77: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_128: {
                            break :block_128 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_74).building, .count = (value_74).count, .names = block_127: {
                                const operand_121 = block_120: {
                                    break :block_120 value_75;
                                };
                                const operand_123 = block_122: {
                                    break :block_122 value_76;
                                };

                                if ((operand_123 >= (operand_121).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_125 = block_124: {
                                    break :block_124 value_64;
                                };

                                break :block_127 block_126: {
                                    if ((!state_items_started_12)) {
                                        state_items_11 = (try (allocator).dupe([]const u8, operand_121));

                                        state_items_started_12 = true;
                                    }

                                    (state_items_11)[@intCast(operand_123)] = operand_125;

                                    break :block_126 state_items_11;
                                };
                            }, .positions = (value_74).positions, .remaining = (value_74).remaining, .root = (value_74).root, .sifting = (value_74).sifting, });
                        };
                        const value_78: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_77;
                        const value_79: []const u64 = (value_78).positions;
                        const value_80: u64 = (value_77).count;
                        const value_81: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_119: {
                            break :block_119 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_78).building, .count = (value_78).count, .names = (value_78).names, .positions = block_118: {
                                const operand_112 = block_111: {
                                    break :block_111 value_79;
                                };
                                const operand_114 = block_113: {
                                    break :block_113 value_80;
                                };

                                if ((operand_114 >= (operand_112).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_116 = block_115: {
                                    break :block_115 value_65;
                                };

                                break :block_118 block_117: {
                                    if ((!state_items_started_14)) {
                                        state_items_13 = (try (allocator).dupe(u64, operand_112));

                                        state_items_started_14 = true;
                                    }

                                    (state_items_13)[@intCast(operand_114)] = operand_116;

                                    break :block_117 state_items_13;
                                };
                            }, .remaining = (value_78).remaining, .root = (value_78).root, .sifting = (value_78).sifting, });
                        };
                        const value_82: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_81;
                        const value_83: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_110: {
                            break :block_110 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_82).building, .count = (value_82).count, .names = (value_82).names, .positions = (value_82).positions, .remaining = (value_82).remaining, .root = @as(u64, 0), .sifting = (value_82).sifting, });
                        };
                        const value_84: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_83;
                        const value_85: (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_109: {
                            break :block_109 @as((zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_101_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_84).building, .count = (value_84).count, .names = (value_84).names, .positions = (value_84).positions, .remaining = (value_84).remaining, .root = (value_84).root, .sifting = true, });
                        };

                        break :block_159 value_85;
                    });

                    break :block_160 value_86;
                });

                break :block_161 value_87;
            };
        }

        break :block_162 (state_1).positions;
    };
}

fn function_17(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_102) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_80 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = (try function_16(allocator, block_73: {
        const operand_67 = ((in).state).source;
        const operand_68 = (in).position;
        const operand_69 = (in).count;
        const operand_70 = (in).object;

        break :block_73 block_72: {
            const operand_71 = (try (allocator).create((zx_abi).zx_type_97));

            (operand_71).* = @as((zx_abi).zx_type_97, (zx_abi).zx_type_97{ .source = operand_67, .position = operand_68, .count = operand_69, .object = operand_70, });

            break :block_72 @as(*const (zx_abi).zx_type_97, operand_71);
        };
    }));
    const value_21: *const (zx_abi).zx_type_103 = block_66: {
        var state_1: *const (zx_abi).zx_type_103 = block_8: {
            const operand_2 = (in).state;
            const operand_3 = value_1;
            const operand_4 = @as(u64, (value_1).len);
            const operand_5 = (in).object;

            break :block_8 block_7: {
                const operand_6 = (try (allocator).create((zx_abi).zx_type_103));

                (operand_6).* = @as((zx_abi).zx_type_103, (zx_abi).zx_type_103{ .state = operand_2, .positions = operand_3, .remaining = operand_4, .object = operand_5, });

                break :block_7 @as(*const (zx_abi).zx_type_103, operand_6);
            };
        };

        while (((state_1).remaining != @as(u64, 0))) {
            state_1 = block_64: {
                const value_4: *const (zx_abi).zx_type_103 = state_1;
                const value_5: u64 = (value_4).remaining;
                const value_6: *const (zx_abi).zx_type_103 = block_63: {
                    break :block_63 block_62: {
                        const operand_61 = (try (allocator).create((zx_abi).zx_type_103));

                        (operand_61).* = @as((zx_abi).zx_type_103, (zx_abi).zx_type_103{ .object = (value_4).object, .positions = (value_4).positions, .remaining = (value_5 - @as(u64, 1)), .state = (value_4).state, });

                        break :block_62 @as(*const (zx_abi).zx_type_103, operand_61);
                    };
                };
                const value_7: u64 = block_60: {
                    const operand_58 = (value_6).positions;
                    const operand_59 = (value_6).remaining;

                    if ((operand_59 >= (operand_58).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_60 (operand_58)[@intCast(operand_59)];
                };
                const value_8: *const (zx_abi).zx_type_50 = (if ((value_6).object) (block_52: {
                    const operand_51 = block_50: {
                        const operand_48 = ((value_6).state).source;
                        const operand_49 = value_7;

                        break :block_50 (zx_abi).zx_type_94{ .source = operand_48, .position = operand_49, };
                    };

                    break :block_52 (try function_13_value(allocator, (&operand_51)));
                }).value else (block_57: {
                    const operand_56 = block_55: {
                        const operand_53 = ((value_6).state).source;
                        const operand_54 = value_7;

                        break :block_55 (zx_abi).zx_type_94{ .source = operand_53, .position = operand_54, };
                    };

                    break :block_57 (try function_14_value(allocator, (&operand_56)));
                }).value);
                const value_9: *const (zx_abi).zx_type_103 = value_6;
                const value_10: *const (zx_abi).zx_type_80 = (value_9).state;
                const value_11: *const (zx_abi).zx_type_79 = (value_10).work;
                const value_12: *const (zx_abi).zx_type_103 = block_47: {
                    break :block_47 block_46: {
                        const operand_45 = (try (allocator).create((zx_abi).zx_type_103));

                        (operand_45).* = @as((zx_abi).zx_type_103, (zx_abi).zx_type_103{ .object = (value_9).object, .positions = (value_9).positions, .remaining = (value_9).remaining, .state = block_44: {
                            break :block_44 block_43: {
                                const operand_42 = (try (allocator).create((zx_abi).zx_type_80));

                                (operand_42).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (value_10).names, .source = (value_10).source, .valid = (value_10).valid, .work = block_41: {
                                    break :block_41 block_40: {
                                        const operand_39 = (try (allocator).create((zx_abi).zx_type_79));

                                        (operand_39).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .aliases = (value_11).aliases, .enumerations = (value_11).enumerations, .nodes = (block_38: {
                                            const operand_35 = (((value_6).state).work).nodes;
                                            const operand_36 = (value_8).index;
                                            const operand_37 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_35).len, 1))));

                                            @memcpy((operand_37)[0..(operand_35).len], operand_35);

                                            (operand_37)[(operand_35).len] = operand_36;

                                            break :block_38 @as((zx_abi).zx_type_83, .{ operand_37, {}, });
                                        }).@"0", });

                                        break :block_40 @as(*const (zx_abi).zx_type_79, operand_39);
                                    };
                                }, });

                                break :block_43 @as(*const (zx_abi).zx_type_80, operand_42);
                            };
                        }, });

                        break :block_46 @as(*const (zx_abi).zx_type_103, operand_45);
                    };
                };
                const value_13: *const (zx_abi).zx_type_103 = value_12;
                const value_14: *const (zx_abi).zx_type_80 = (value_13).state;
                const value_15: *const (zx_abi).zx_type_79 = (value_14).work;
                const value_16: *const (zx_abi).zx_type_103 = block_34: {
                    break :block_34 block_33: {
                        const operand_32 = (try (allocator).create((zx_abi).zx_type_103));

                        (operand_32).* = @as((zx_abi).zx_type_103, (zx_abi).zx_type_103{ .object = (value_13).object, .positions = (value_13).positions, .remaining = (value_13).remaining, .state = block_31: {
                            break :block_31 block_30: {
                                const operand_29 = (try (allocator).create((zx_abi).zx_type_80));

                                (operand_29).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (value_14).names, .source = (value_14).source, .valid = (value_14).valid, .work = block_28: {
                                    break :block_28 block_27: {
                                        const operand_26 = (try (allocator).create((zx_abi).zx_type_79));

                                        (operand_26).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .aliases = (value_15).aliases, .enumerations = (block_25: {
                                            const operand_22 = (((value_12).state).work).enumerations;
                                            const operand_23 = (value_8).enumeration;
                                            const operand_24 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_22).len, 1))));

                                            @memcpy((operand_24)[0..(operand_22).len], operand_22);

                                            (operand_24)[(operand_22).len] = operand_23;

                                            break :block_25 @as((zx_abi).zx_type_84, .{ operand_24, {}, });
                                        }).@"0", .nodes = (value_15).nodes, });

                                        break :block_27 @as(*const (zx_abi).zx_type_79, operand_26);
                                    };
                                }, });

                                break :block_30 @as(*const (zx_abi).zx_type_80, operand_29);
                            };
                        }, });

                        break :block_33 @as(*const (zx_abi).zx_type_103, operand_32);
                    };
                };
                const value_17: *const (zx_abi).zx_type_103 = value_16;
                const value_18: *const (zx_abi).zx_type_80 = (value_17).state;
                const value_19: *const (zx_abi).zx_type_79 = (value_18).work;
                const value_20: *const (zx_abi).zx_type_103 = block_21: {
                    break :block_21 block_20: {
                        const operand_19 = (try (allocator).create((zx_abi).zx_type_103));

                        (operand_19).* = @as((zx_abi).zx_type_103, (zx_abi).zx_type_103{ .object = (value_17).object, .positions = (value_17).positions, .remaining = (value_17).remaining, .state = block_18: {
                            break :block_18 block_17: {
                                const operand_16 = (try (allocator).create((zx_abi).zx_type_80));

                                (operand_16).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (value_18).names, .source = (value_18).source, .valid = (value_18).valid, .work = block_15: {
                                    break :block_15 block_14: {
                                        const operand_13 = (try (allocator).create((zx_abi).zx_type_79));

                                        (operand_13).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .aliases = (block_12: {
                                            const operand_9 = (((value_16).state).work).aliases;
                                            const operand_10 = @as(?[]const u8, null);
                                            const operand_11 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_9).len, 1))));

                                            @memcpy((operand_11)[0..(operand_9).len], operand_9);

                                            (operand_11)[(operand_9).len] = operand_10;

                                            break :block_12 @as((zx_abi).zx_type_85, .{ operand_11, {}, });
                                        }).@"0", .enumerations = (value_19).enumerations, .nodes = (value_19).nodes, });

                                        break :block_14 @as(*const (zx_abi).zx_type_79, operand_13);
                                    };
                                }, });

                                break :block_17 @as(*const (zx_abi).zx_type_80, operand_16);
                            };
                        }, });

                        break :block_20 @as(*const (zx_abi).zx_type_103, operand_19);
                    };
                };

                break :block_64 value_20;
            };
        }

        break :block_66 state_1;
    };

    return (value_21).state;
}

fn function_17_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_102_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = block_143: {
        const operand_140 = block_139: {
            const operand_135 = ((in).state).source;
            const operand_136 = (in).position;
            const operand_137 = (in).count;
            const operand_138 = (in).object;

            break :block_139 @as((zx_abi).value_zx_type_97_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_97_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .source = operand_135, .position = operand_136, .count = operand_137, .object = operand_138, });
        };

        break :block_143 (try function_16(allocator, (if (((operand_140).zx_origin != null)) (operand_140).zx_origin.? else block_142: {
            const operand_141 = (try (allocator).create((zx_abi).zx_type_97));

            (operand_141).* = (zx_abi).zx_type_97{ .count = (operand_140).count, .object = (operand_140).object, .position = (operand_140).position, .source = (operand_140).source, };

            break :block_142 @as(*const (zx_abi).zx_type_97, operand_141);
        })));
    };
    const value_21: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = block_134: {
        const operand_82 = block_81: {
            const operand_75 = (in).state;
            const operand_76 = block_77: {
                break :block_77 value_1;
            };
            const operand_78 = @as(u64, (block_79: {
                break :block_79 value_1;
            }).len);
            const operand_80 = (in).object;

            break :block_81 @as((zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .state = operand_75, .positions = operand_76, .remaining = operand_78, .object = operand_80, });
        };

        var state_capacity_84: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_85 = false;

        defer (state_capacity_84).deinit(allocator);

        var state_capacity_86: (std).ArrayList(bool) = .empty;

        var state_capacity_started_87 = false;

        defer (state_capacity_86).deinit(allocator);

        var state_capacity_88: (std).ArrayList(u64) = .empty;

        var state_capacity_started_89 = false;

        defer (state_capacity_88).deinit(allocator);

        var state_74: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = operand_82;

        var state_changed_83 = false;

        while (((state_74).remaining != @as(u64, 0))) {
            state_74 = block_129: {
                const value_4: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = state_74;
                const value_5: u64 = (value_4).remaining;
                const value_6: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = block_128: {
                    break :block_128 @as((zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (value_4).object, .positions = (value_4).positions, .remaining = (block_127: {
                        break :block_127 value_5;
                    } - @as(u64, 1)), .state = (value_4).state, });
                };
                const value_7: u64 = block_126: {
                    const operand_124 = (value_6).positions;
                    const operand_125 = (value_6).remaining;

                    if ((operand_125 >= (operand_124).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_126 (operand_124)[@intCast(operand_125)];
                };
                const value_8: (zx_abi).zx_type_50 = (if ((value_6).object) ((block_116: {
                    const operand_114 = block_113: {
                        const operand_110 = ((value_6).state).source;
                        const operand_111 = block_112: {
                            break :block_112 value_7;
                        };

                        break :block_113 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_110, .position = operand_111, });
                    };

                    var state_borrow_115: (zx_abi).zx_type_94 = undefined;

                    state_borrow_115 = (zx_abi).zx_type_94{ .position = (operand_114).position, .source = (operand_114).source, };

                    break :block_116 (try function_13_value(allocator, ((operand_114).zx_origin orelse (&state_borrow_115))));
                }).value).* else ((block_123: {
                    const operand_121 = block_120: {
                        const operand_117 = ((value_6).state).source;
                        const operand_118 = block_119: {
                            break :block_119 value_7;
                        };

                        break :block_120 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_117, .position = operand_118, });
                    };

                    var state_borrow_122: (zx_abi).zx_type_94 = undefined;

                    state_borrow_122 = (zx_abi).zx_type_94{ .position = (operand_121).position, .source = (operand_121).source, };

                    break :block_123 (try function_14_value(allocator, ((operand_121).zx_origin orelse (&state_borrow_122))));
                }).value).*);
                const value_9: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = value_6;
                const value_10: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = (value_9).state;
                const value_11: (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (value_10).work;
                const value_12: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = block_109: {
                    break :block_109 @as((zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (value_9).object, .positions = (value_9).positions, .remaining = (value_9).remaining, .state = block_108: {
                        break :block_108 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (value_10).names, .source = (value_10).source, .valid = (value_10).valid, .work = block_107: {
                            break :block_107 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (value_11).aliases, .enumerations = (value_11).enumerations, .nodes = (block_106: {
                                const operand_103 = (((value_6).state).work).nodes;
                                const operand_105 = (block_104: {
                                    break :block_104 (&value_8);
                                }).index;

                                _ = (try ((std).math).add(usize, (operand_103).len, 1));

                                if ((!state_capacity_started_89)) {
                                    (try (state_capacity_88).appendSlice(allocator, operand_103));

                                    state_capacity_started_89 = true;
                                } else {
                                    ((state_capacity_88).items).len = (operand_103).len;
                                }

                                (try (state_capacity_88).append(allocator, operand_105));

                                break :block_106 @as((zx_abi).value_zx_type_83_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_88).items, {}, null, });
                            }).@"0", });
                        }, });
                    }, });
                };
                const value_13: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = value_12;
                const value_14: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = (value_13).state;
                const value_15: (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (value_14).work;
                const value_16: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = block_102: {
                    break :block_102 @as((zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (value_13).object, .positions = (value_13).positions, .remaining = (value_13).remaining, .state = block_101: {
                        break :block_101 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (value_14).names, .source = (value_14).source, .valid = (value_14).valid, .work = block_100: {
                            break :block_100 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (value_15).aliases, .enumerations = (block_99: {
                                const operand_96 = (((value_12).state).work).enumerations;
                                const operand_98 = (block_97: {
                                    break :block_97 (&value_8);
                                }).enumeration;

                                _ = (try ((std).math).add(usize, (operand_96).len, 1));

                                if ((!state_capacity_started_87)) {
                                    (try (state_capacity_86).appendSlice(allocator, operand_96));

                                    state_capacity_started_87 = true;
                                } else {
                                    ((state_capacity_86).items).len = (operand_96).len;
                                }

                                (try (state_capacity_86).append(allocator, operand_98));

                                break :block_99 @as((zx_abi).value_zx_type_84_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_86).items, {}, null, });
                            }).@"0", .nodes = (value_15).nodes, });
                        }, });
                    }, });
                };
                const value_17: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = value_16;
                const value_18: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = (value_17).state;
                const value_19: (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (value_18).work;
                const value_20: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = block_95: {
                    break :block_95 @as((zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (value_17).object, .positions = (value_17).positions, .remaining = (value_17).remaining, .state = block_94: {
                        break :block_94 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (value_18).names, .source = (value_18).source, .valid = (value_18).valid, .work = block_93: {
                            break :block_93 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (block_92: {
                                const operand_90 = (((value_16).state).work).aliases;
                                const operand_91 = @as(?[]const u8, null);

                                _ = (try ((std).math).add(usize, (operand_90).len, 1));

                                if ((!state_capacity_started_85)) {
                                    (try (state_capacity_84).appendSlice(allocator, operand_90));

                                    state_capacity_started_85 = true;
                                } else {
                                    ((state_capacity_84).items).len = (operand_90).len;
                                }

                                (try (state_capacity_84).append(allocator, operand_91));

                                break :block_92 @as((zx_abi).value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_84).items, {}, null, });
                            }).@"0", .enumerations = (value_19).enumerations, .nodes = (value_19).nodes, });
                        }, });
                    }, });
                };

                break :block_129 value_20;
            };

            state_changed_83 = true;
        }

        var state_owned_130: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_130);

        if (state_capacity_started_85) {
            ((state_capacity_84).items).len = ((((state_74).state).work).aliases).len;

            state_owned_130 = (try (state_capacity_84).toOwnedSlice(allocator));
        }

        if (state_capacity_started_85) {
            state_74 = (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (state_74).object, .positions = (state_74).positions, .remaining = (state_74).remaining, .state = @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = ((state_74).state).names, .source = ((state_74).state).source, .valid = ((state_74).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_130, .enumerations = (((state_74).state).work).enumerations, .nodes = (((state_74).state).work).nodes, }), }), };
        }

        var state_owned_131: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_131);

        if (state_capacity_started_87) {
            ((state_capacity_86).items).len = ((((state_74).state).work).enumerations).len;

            state_owned_131 = (try (state_capacity_86).toOwnedSlice(allocator));
        }

        if (state_capacity_started_87) {
            state_74 = (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (state_74).object, .positions = (state_74).positions, .remaining = (state_74).remaining, .state = @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = ((state_74).state).names, .source = ((state_74).state).source, .valid = ((state_74).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_74).state).work).aliases, .enumerations = state_owned_131, .nodes = (((state_74).state).work).nodes, }), }), };
        }

        var state_owned_132: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_132);

        if (state_capacity_started_89) {
            ((state_capacity_88).items).len = ((((state_74).state).work).nodes).len;

            state_owned_132 = (try (state_capacity_88).toOwnedSlice(allocator));
        }

        if (state_capacity_started_89) {
            state_74 = (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (state_74).object, .positions = (state_74).positions, .remaining = (state_74).remaining, .state = @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = ((state_74).state).names, .source = ((state_74).state).source, .valid = ((state_74).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_74).state).work).aliases, .enumerations = (((state_74).state).work).enumerations, .nodes = state_owned_132, }), }), };
        }

        break :block_134 (if (state_changed_83) state_74 else operand_82);
    };

    return (value_21).state;
}

fn function_17_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_102_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_44),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_14),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_31),
        started: *bool,
    },
    lane_8: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_32),
        started: *bool,
    },
    lane_9: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_30),
        started: *bool,
    },
    lane_10: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_11: ?struct {
        buffer: *(std).ArrayList(bool),
        started: *bool,
    },
    lane_12: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
}) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = block_224: {
        const operand_221 = block_220: {
            const operand_216 = ((in).state).source;
            const operand_217 = (in).position;
            const operand_218 = (in).count;
            const operand_219 = (in).object;

            break :block_220 @as((zx_abi).value_zx_type_97_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_97_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .source = operand_216, .position = operand_217, .count = operand_218, .object = operand_219, });
        };

        break :block_224 (try function_16(allocator, (if (((operand_221).zx_origin != null)) (operand_221).zx_origin.? else block_223: {
            const operand_222 = (try (allocator).create((zx_abi).zx_type_97));

            (operand_222).* = (zx_abi).zx_type_97{ .count = (operand_221).count, .object = (operand_221).object, .position = (operand_221).position, .source = (operand_221).source, };

            break :block_223 @as(*const (zx_abi).zx_type_97, operand_222);
        })));
    };
    const value_21: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = block_215: {
        const operand_152 = block_151: {
            const operand_145 = (in).state;
            const operand_146 = block_147: {
                break :block_147 value_1;
            };
            const operand_148 = @as(u64, (block_149: {
                break :block_149 value_1;
            }).len);
            const operand_150 = (in).object;

            break :block_151 @as((zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .state = operand_145, .positions = operand_146, .remaining = operand_148, .object = operand_150, });
        };

        var state_capacity_154: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_155 = false;

        defer (state_capacity_154).deinit(allocator);

        var state_capacity_156: (std).ArrayList(bool) = .empty;

        var state_capacity_started_157 = false;

        defer (state_capacity_156).deinit(allocator);

        var state_capacity_158: (std).ArrayList(u64) = .empty;

        var state_capacity_started_159 = false;

        defer (state_capacity_158).deinit(allocator);

        var state_144: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = operand_152;

        var state_changed_153 = false;

        while (((state_144).remaining != @as(u64, 0))) {
            state_144 = block_210: {
                const value_4: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = state_144;
                const value_5: u64 = (value_4).remaining;
                const value_6: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = block_209: {
                    break :block_209 @as((zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (value_4).object, .positions = (value_4).positions, .remaining = (block_208: {
                        break :block_208 value_5;
                    } - @as(u64, 1)), .state = (value_4).state, });
                };
                const value_7: u64 = block_207: {
                    const operand_205 = (value_6).positions;
                    const operand_206 = (value_6).remaining;

                    if ((operand_206 >= (operand_205).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_207 (operand_205)[@intCast(operand_206)];
                };
                const value_8: (zx_abi).zx_type_50 = (if ((value_6).object) ((block_197: {
                    const operand_195 = block_194: {
                        const operand_191 = ((value_6).state).source;
                        const operand_192 = block_193: {
                            break :block_193 value_7;
                        };

                        break :block_194 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_191, .position = operand_192, });
                    };

                    var state_borrow_196: (zx_abi).zx_type_94 = undefined;

                    state_borrow_196 = (zx_abi).zx_type_94{ .position = (operand_195).position, .source = (operand_195).source, };

                    break :block_197 (try function_13_value(allocator, ((operand_195).zx_origin orelse (&state_borrow_196))));
                }).value).* else ((block_204: {
                    const operand_202 = block_201: {
                        const operand_198 = ((value_6).state).source;
                        const operand_199 = block_200: {
                            break :block_200 value_7;
                        };

                        break :block_201 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_198, .position = operand_199, });
                    };

                    var state_borrow_203: (zx_abi).zx_type_94 = undefined;

                    state_borrow_203 = (zx_abi).zx_type_94{ .position = (operand_202).position, .source = (operand_202).source, };

                    break :block_204 (try function_14_value(allocator, ((operand_202).zx_origin orelse (&state_borrow_203))));
                }).value).*);
                const value_9: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = value_6;
                const value_10: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = (value_9).state;
                const value_11: (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (value_10).work;
                const value_12: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = block_190: {
                    break :block_190 @as((zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (value_9).object, .positions = (value_9).positions, .remaining = (value_9).remaining, .state = block_189: {
                        break :block_189 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (value_10).names, .source = (value_10).source, .valid = (value_10).valid, .work = block_188: {
                            break :block_188 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (value_11).aliases, .enumerations = (value_11).enumerations, .nodes = @as([]const u64, (if (((buffers).lane_12 != null)) block_183: {
                                const operand_180 = (((value_6).state).work).nodes;
                                const operand_182 = (block_181: {
                                    break :block_181 (&value_8);
                                }).index;

                                _ = (try ((std).math).add(usize, (operand_180).len, 1));

                                if ((!(((buffers).lane_12.?).started).*)) {
                                    (try ((((buffers).lane_12.?).buffer).*).appendSlice(allocator, operand_180));

                                    (((buffers).lane_12.?).started).* = true;
                                } else {
                                    (((((buffers).lane_12.?).buffer).*).items).len = (operand_180).len;
                                }

                                (try ((((buffers).lane_12.?).buffer).*).append(allocator, operand_182));

                                break :block_183 ((((buffers).lane_12.?).buffer).*).items;
                            } else (block_187: {
                                const operand_184 = (((value_6).state).work).nodes;
                                const operand_186 = (block_185: {
                                    break :block_185 (&value_8);
                                }).index;

                                _ = (try ((std).math).add(usize, (operand_184).len, 1));

                                if ((!state_capacity_started_159)) {
                                    (try (state_capacity_158).appendSlice(allocator, operand_184));

                                    state_capacity_started_159 = true;
                                } else {
                                    ((state_capacity_158).items).len = (operand_184).len;
                                }

                                (try (state_capacity_158).append(allocator, operand_186));

                                break :block_187 @as((zx_abi).value_zx_type_83_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_158).items, {}, null, });
                            }).@"0")), });
                        }, });
                    }, });
                };
                const value_13: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = value_12;
                const value_14: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = (value_13).state;
                const value_15: (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (value_14).work;
                const value_16: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = block_179: {
                    break :block_179 @as((zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (value_13).object, .positions = (value_13).positions, .remaining = (value_13).remaining, .state = block_178: {
                        break :block_178 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (value_14).names, .source = (value_14).source, .valid = (value_14).valid, .work = block_177: {
                            break :block_177 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (value_15).aliases, .enumerations = @as([]const bool, (if (((buffers).lane_11 != null)) block_172: {
                                const operand_169 = (((value_12).state).work).enumerations;
                                const operand_171 = (block_170: {
                                    break :block_170 (&value_8);
                                }).enumeration;

                                _ = (try ((std).math).add(usize, (operand_169).len, 1));

                                if ((!(((buffers).lane_11.?).started).*)) {
                                    (try ((((buffers).lane_11.?).buffer).*).appendSlice(allocator, operand_169));

                                    (((buffers).lane_11.?).started).* = true;
                                } else {
                                    (((((buffers).lane_11.?).buffer).*).items).len = (operand_169).len;
                                }

                                (try ((((buffers).lane_11.?).buffer).*).append(allocator, operand_171));

                                break :block_172 ((((buffers).lane_11.?).buffer).*).items;
                            } else (block_176: {
                                const operand_173 = (((value_12).state).work).enumerations;
                                const operand_175 = (block_174: {
                                    break :block_174 (&value_8);
                                }).enumeration;

                                _ = (try ((std).math).add(usize, (operand_173).len, 1));

                                if ((!state_capacity_started_157)) {
                                    (try (state_capacity_156).appendSlice(allocator, operand_173));

                                    state_capacity_started_157 = true;
                                } else {
                                    ((state_capacity_156).items).len = (operand_173).len;
                                }

                                (try (state_capacity_156).append(allocator, operand_175));

                                break :block_176 @as((zx_abi).value_zx_type_84_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_156).items, {}, null, });
                            }).@"0")), .nodes = (value_15).nodes, });
                        }, });
                    }, });
                };
                const value_17: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = value_16;
                const value_18: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = (value_17).state;
                const value_19: (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (value_18).work;
                const value_20: (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52 = block_168: {
                    break :block_168 @as((zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (value_17).object, .positions = (value_17).positions, .remaining = (value_17).remaining, .state = block_167: {
                        break :block_167 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (value_18).names, .source = (value_18).source, .valid = (value_18).valid, .work = block_166: {
                            break :block_166 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = @as([]const ?[]const u8, (if (((buffers).lane_10 != null)) block_162: {
                                const operand_160 = (((value_16).state).work).aliases;
                                const operand_161 = @as(?[]const u8, null);

                                _ = (try ((std).math).add(usize, (operand_160).len, 1));

                                if ((!(((buffers).lane_10.?).started).*)) {
                                    (try ((((buffers).lane_10.?).buffer).*).appendSlice(allocator, operand_160));

                                    (((buffers).lane_10.?).started).* = true;
                                } else {
                                    (((((buffers).lane_10.?).buffer).*).items).len = (operand_160).len;
                                }

                                (try ((((buffers).lane_10.?).buffer).*).append(allocator, operand_161));

                                break :block_162 ((((buffers).lane_10.?).buffer).*).items;
                            } else (block_165: {
                                const operand_163 = (((value_16).state).work).aliases;
                                const operand_164 = @as(?[]const u8, null);

                                _ = (try ((std).math).add(usize, (operand_163).len, 1));

                                if ((!state_capacity_started_155)) {
                                    (try (state_capacity_154).appendSlice(allocator, operand_163));

                                    state_capacity_started_155 = true;
                                } else {
                                    ((state_capacity_154).items).len = (operand_163).len;
                                }

                                (try (state_capacity_154).append(allocator, operand_164));

                                break :block_165 @as((zx_abi).value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_154).items, {}, null, });
                            }).@"0")), .enumerations = (value_19).enumerations, .nodes = (value_19).nodes, });
                        }, });
                    }, });
                };

                break :block_210 value_20;
            };

            state_changed_153 = true;
        }

        var state_owned_211: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_211);

        if (state_capacity_started_155) {
            ((state_capacity_154).items).len = ((((state_144).state).work).aliases).len;

            state_owned_211 = (try (state_capacity_154).toOwnedSlice(allocator));
        }

        if (state_capacity_started_155) {
            state_144 = (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (state_144).object, .positions = (state_144).positions, .remaining = (state_144).remaining, .state = @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = ((state_144).state).names, .source = ((state_144).state).source, .valid = ((state_144).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_211, .enumerations = (((state_144).state).work).enumerations, .nodes = (((state_144).state).work).nodes, }), }), };
        }

        var state_owned_212: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_212);

        if (state_capacity_started_157) {
            ((state_capacity_156).items).len = ((((state_144).state).work).enumerations).len;

            state_owned_212 = (try (state_capacity_156).toOwnedSlice(allocator));
        }

        if (state_capacity_started_157) {
            state_144 = (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (state_144).object, .positions = (state_144).positions, .remaining = (state_144).remaining, .state = @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = ((state_144).state).names, .source = ((state_144).state).source, .valid = ((state_144).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_144).state).work).aliases, .enumerations = state_owned_212, .nodes = (((state_144).state).work).nodes, }), }), };
        }

        var state_owned_213: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_213);

        if (state_capacity_started_159) {
            ((state_capacity_158).items).len = ((((state_144).state).work).nodes).len;

            state_owned_213 = (try (state_capacity_158).toOwnedSlice(allocator));
        }

        if (state_capacity_started_159) {
            state_144 = (zx_abi).value_zx_type_103_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .object = (state_144).object, .positions = (state_144).positions, .remaining = (state_144).remaining, .state = @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = ((state_144).state).names, .source = ((state_144).state).source, .valid = ((state_144).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_144).state).work).aliases, .enumerations = (((state_144).state).work).enumerations, .nodes = state_owned_213, }), }), };
        }

        break :block_215 (if (state_changed_153) state_144 else operand_152);
    };

    return (value_21).state;
}

fn function_18(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_80) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_80 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, (((in).work).nodes).len) - @as(u64, 1));
    const value_2: *const (zx_abi).zx_type_51 = (try function_11(allocator, block_133: {
        const operand_118 = (in).source;
        const operand_119 = block_130: {
            const operand_120 = block_123: {
                const operand_121 = ((in).work).enumerations;
                const operand_122 = value_1;

                if ((operand_122 >= (operand_121).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_123 (operand_121)[@intCast(operand_122)];
            };
            const operand_124 = block_127: {
                const operand_125 = ((in).work).nodes;
                const operand_126 = value_1;

                if ((operand_126 >= (operand_125).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_127 (operand_125)[@intCast(operand_126)];
            };

            break :block_130 block_129: {
                const operand_128 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_128).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_120, .index = operand_124, });

                break :block_129 @as(*const (zx_abi).zx_type_50, operand_128);
            };
        };

        break :block_133 block_132: {
            const operand_131 = (try (allocator).create((zx_abi).zx_type_92));

            (operand_131).* = @as((zx_abi).zx_type_92, (zx_abi).zx_type_92{ .source = operand_118, .reference = operand_119, });

            break :block_132 @as(*const (zx_abi).zx_type_92, operand_131);
        };
    }));
    const value_3: ?[]const u8 = block_117: {
        const operand_115 = ((in).work).aliases;
        const operand_116 = value_1;

        if ((operand_116 >= (operand_115).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_117 (operand_115)[@intCast(operand_116)];
    };

    if (((value_2).kind == @as((zx_abi).zx_type_48, .Named))) {
        const value_4: *const (zx_abi).zx_type_90 = block_114: {
            const operand_110 = block_109: {
                const operand_104 = (in).source;
                const operand_105 = ((value_2).name).text;
                const operand_106 = (try function_1(allocator, (in).source));

                break :block_109 block_108: {
                    const operand_107 = (try (allocator).create((zx_abi).zx_type_89));

                    (operand_107).* = @as((zx_abi).zx_type_89, (zx_abi).zx_type_89{ .source = operand_104, .name = operand_105, .limit = operand_106, });

                    break :block_108 @as(*const (zx_abi).zx_type_89, operand_107);
                };
            };
            const operand_111 = (try function_10_value(allocator, (zx_abi).value_zx_type_89_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .limit = (operand_110).limit, .name = (operand_110).name, .source = (operand_110).source, .zx_origin = operand_110, }));

            break :block_114 (if (((operand_111).zx_origin != null)) (operand_111).zx_origin.? else block_113: {
                const operand_112 = (try (allocator).create((zx_abi).zx_type_90));

                (operand_112).* = (zx_abi).zx_type_90{ .found = (operand_111).found, .index = (operand_111).index, };

                break :block_113 @as(*const (zx_abi).zx_type_90, operand_112);
            });
        };

        if ((value_4).found) {
            const value_5: *const (zx_abi).zx_type_54 = (try function_9(allocator, block_103: {
                const operand_99 = (in).source;
                const operand_100 = (value_4).index;

                break :block_103 block_102: {
                    const operand_101 = (try (allocator).create((zx_abi).zx_type_88));

                    (operand_101).* = @as((zx_abi).zx_type_88, (zx_abi).zx_type_88{ .source = operand_99, .index = operand_100, });

                    break :block_102 @as(*const (zx_abi).zx_type_88, operand_101);
                };
            }));

            return block_98: {
                const operand_70 = in;
                const operand_71 = block_95: {
                    const operand_72 = (block_78: {
                        const operand_75 = (block_74: {
                            const operand_73 = ((in).work).nodes;

                            break :block_74 @as((zx_abi).zx_type_105, (if (((operand_73).len == 0)) .{ operand_73, null, } else .{ (operand_73)[0..((operand_73).len - 1)], (operand_73)[((operand_73).len - 1)], }));
                        }).@"0";
                        const operand_76 = ((value_5).value).index;
                        const operand_77 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_75).len, 1))));

                        @memcpy((operand_77)[0..(operand_75).len], operand_75);

                        (operand_77)[(operand_75).len] = operand_76;

                        break :block_78 @as((zx_abi).zx_type_83, .{ operand_77, {}, });
                    }).@"0";
                    const operand_79 = (block_85: {
                        const operand_82 = (block_81: {
                            const operand_80 = ((in).work).enumerations;

                            break :block_81 @as((zx_abi).zx_type_107, (if (((operand_80).len == 0)) .{ operand_80, null, } else .{ (operand_80)[0..((operand_80).len - 1)], (operand_80)[((operand_80).len - 1)], }));
                        }).@"0";
                        const operand_83 = ((value_5).value).enumeration;
                        const operand_84 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_82).len, 1))));

                        @memcpy((operand_84)[0..(operand_82).len], operand_82);

                        (operand_84)[(operand_82).len] = operand_83;

                        break :block_85 @as((zx_abi).zx_type_84, .{ operand_84, {}, });
                    }).@"0";
                    const operand_86 = (block_92: {
                        const operand_89 = (block_88: {
                            const operand_87 = ((in).work).aliases;

                            break :block_88 @as((zx_abi).zx_type_109, (if (((operand_87).len == 0)) .{ operand_87, null, } else .{ (operand_87)[0..((operand_87).len - 1)], (operand_87)[((operand_87).len - 1)], }));
                        }).@"0";
                        const operand_90 = (if ((value_3 != null)) @as(?[]const u8, value_3.?) else @as(?[]const u8, ((value_2).name).text));
                        const operand_91 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_89).len, 1))));

                        @memcpy((operand_91)[0..(operand_89).len], operand_89);

                        (operand_91)[(operand_89).len] = operand_90;

                        break :block_92 @as((zx_abi).zx_type_85, .{ operand_91, {}, });
                    }).@"0";

                    break :block_95 block_94: {
                        const operand_93 = (try (allocator).create((zx_abi).zx_type_79));

                        (operand_93).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_72, .enumerations = operand_79, .aliases = operand_86, });

                        break :block_94 @as(*const (zx_abi).zx_type_79, operand_93);
                    };
                };

                break :block_98 block_97: {
                    const operand_96 = (try (allocator).create((zx_abi).zx_type_80));

                    (operand_96).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (operand_70).names, .source = (operand_70).source, .valid = (operand_70).valid, .work = operand_71, });

                    break :block_97 @as(*const (zx_abi).zx_type_80, operand_96);
                };
            };
        }
    }

    if (((((value_2).kind == @as((zx_abi).zx_type_48, .List)) or ((value_2).kind == @as((zx_abi).zx_type_48, .Application))) and (!(try function_12(allocator, block_64: {
        const operand_60 = (in).source;
        const operand_61 = (value_2).child;

        break :block_64 block_63: {
            const operand_62 = (try (allocator).create((zx_abi).zx_type_92));

            (operand_62).* = @as((zx_abi).zx_type_92, (zx_abi).zx_type_92{ .source = operand_60, .reference = operand_61, });

            break :block_63 @as(*const (zx_abi).zx_type_92, operand_62);
        };
    }))))) {
        return block_69: {
            const operand_65 = in;
            const operand_66 = false;

            break :block_69 block_68: {
                const operand_67 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_67).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (operand_65).names, .source = (operand_65).source, .valid = operand_66, .work = (operand_65).work, });

                break :block_68 @as(*const (zx_abi).zx_type_80, operand_67);
            };
        };
    }

    const value_6: *const (zx_abi).zx_type_80 = block_59: {
        const operand_38 = in;
        const operand_39 = (block_43: {
            const operand_40 = (in).names;
            const operand_41 = value_3;
            const operand_42 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_40).len, 1))));

            @memcpy((operand_42)[0..(operand_40).len], operand_40);

            (operand_42)[(operand_40).len] = operand_41;

            break :block_43 @as((zx_abi).zx_type_85, .{ operand_42, {}, });
        }).@"0";
        const operand_44 = block_56: {
            const operand_45 = (block_47: {
                const operand_46 = ((in).work).nodes;

                break :block_47 @as((zx_abi).zx_type_105, (if (((operand_46).len == 0)) .{ operand_46, null, } else .{ (operand_46)[0..((operand_46).len - 1)], (operand_46)[((operand_46).len - 1)], }));
            }).@"0";
            const operand_48 = (block_50: {
                const operand_49 = ((in).work).enumerations;

                break :block_50 @as((zx_abi).zx_type_107, (if (((operand_49).len == 0)) .{ operand_49, null, } else .{ (operand_49)[0..((operand_49).len - 1)], (operand_49)[((operand_49).len - 1)], }));
            }).@"0";
            const operand_51 = (block_53: {
                const operand_52 = ((in).work).aliases;

                break :block_53 @as((zx_abi).zx_type_109, (if (((operand_52).len == 0)) .{ operand_52, null, } else .{ (operand_52)[0..((operand_52).len - 1)], (operand_52)[((operand_52).len - 1)], }));
            }).@"0";

            break :block_56 block_55: {
                const operand_54 = (try (allocator).create((zx_abi).zx_type_79));

                (operand_54).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_45, .enumerations = operand_48, .aliases = operand_51, });

                break :block_55 @as(*const (zx_abi).zx_type_79, operand_54);
            };
        };

        break :block_59 block_58: {
            const operand_57 = (try (allocator).create((zx_abi).zx_type_80));

            (operand_57).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = operand_39, .source = (operand_38).source, .valid = (operand_38).valid, .work = operand_44, });

            break :block_58 @as(*const (zx_abi).zx_type_80, operand_57);
        };
    };

    if (((((value_2).kind == @as((zx_abi).zx_type_48, .Optional)) or ((value_2).kind == @as((zx_abi).zx_type_48, .List))) or ((value_2).kind == @as((zx_abi).zx_type_48, .Application)))) {
        return block_37: {
            const operand_15 = value_6;
            const operand_16 = block_34: {
                const operand_17 = (block_21: {
                    const operand_18 = ((value_6).work).nodes;
                    const operand_19 = ((value_2).child).index;
                    const operand_20 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_18).len, 1))));

                    @memcpy((operand_20)[0..(operand_18).len], operand_18);

                    (operand_20)[(operand_18).len] = operand_19;

                    break :block_21 @as((zx_abi).zx_type_83, .{ operand_20, {}, });
                }).@"0";
                const operand_22 = (block_26: {
                    const operand_23 = ((value_6).work).enumerations;
                    const operand_24 = ((value_2).child).enumeration;
                    const operand_25 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_23).len, 1))));

                    @memcpy((operand_25)[0..(operand_23).len], operand_23);

                    (operand_25)[(operand_23).len] = operand_24;

                    break :block_26 @as((zx_abi).zx_type_84, .{ operand_25, {}, });
                }).@"0";
                const operand_27 = (block_31: {
                    const operand_28 = ((value_6).work).aliases;
                    const operand_29 = @as(?[]const u8, null);
                    const operand_30 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_28).len, 1))));

                    @memcpy((operand_30)[0..(operand_28).len], operand_28);

                    (operand_30)[(operand_28).len] = operand_29;

                    break :block_31 @as((zx_abi).zx_type_85, .{ operand_30, {}, });
                }).@"0";

                break :block_34 block_33: {
                    const operand_32 = (try (allocator).create((zx_abi).zx_type_79));

                    (operand_32).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_17, .enumerations = operand_22, .aliases = operand_27, });

                    break :block_33 @as(*const (zx_abi).zx_type_79, operand_32);
                };
            };

            break :block_37 block_36: {
                const operand_35 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_35).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (operand_15).names, .source = (operand_15).source, .valid = (operand_15).valid, .work = operand_16, });

                break :block_36 @as(*const (zx_abi).zx_type_80, operand_35);
            };
        };
    }

    if ((((value_2).kind == @as((zx_abi).zx_type_48, .Object)) or ((value_2).kind == @as((zx_abi).zx_type_48, .Tuple)))) {
        return block_14: {
            const operand_8 = block_7: {
                const operand_1 = value_6;
                const operand_2 = (value_2).position;
                const operand_3 = (value_2).count;
                const operand_4 = ((value_2).kind == @as((zx_abi).zx_type_48, .Object));

                break :block_7 block_6: {
                    const operand_5 = (try (allocator).create((zx_abi).zx_type_102));

                    (operand_5).* = @as((zx_abi).zx_type_102, (zx_abi).zx_type_102{ .state = operand_1, .position = operand_2, .count = operand_3, .object = operand_4, });

                    break :block_6 @as(*const (zx_abi).zx_type_102, operand_5);
                };
            };
            const operand_9 = (try function_17_value(allocator, (zx_abi).value_zx_type_102_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .count = (operand_8).count, .object = (operand_8).object, .position = (operand_8).position, .state = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = ((operand_8).state).names, .source = ((operand_8).state).source, .valid = ((operand_8).state).valid, .work = (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((operand_8).state).work).aliases, .enumerations = (((operand_8).state).work).enumerations, .nodes = (((operand_8).state).work).nodes, .zx_origin = ((operand_8).state).work, }, .zx_origin = (operand_8).state, }, .zx_origin = operand_8, }));

            break :block_14 (if (((operand_9).zx_origin != null)) (operand_9).zx_origin.? else block_13: {
                const operand_12 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_12).* = (zx_abi).zx_type_80{ .names = (operand_9).names, .source = (operand_9).source, .valid = (operand_9).valid, .work = (if ((((operand_9).work).zx_origin != null)) ((operand_9).work).zx_origin.? else block_11: {
                    const operand_10 = (try (allocator).create((zx_abi).zx_type_79));

                    (operand_10).* = (zx_abi).zx_type_79{ .aliases = ((operand_9).work).aliases, .enumerations = ((operand_9).work).enumerations, .nodes = ((operand_9).work).nodes, };

                    break :block_11 @as(*const (zx_abi).zx_type_79, operand_10);
                }), };

                break :block_13 @as(*const (zx_abi).zx_type_80, operand_12);
            });
        };
    }

    return value_6;
}

fn function_18_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, (((in).work).nodes).len) - @as(u64, 1));
    const value_2: *const (zx_abi).zx_type_51 = block_270: {
        const operand_267 = block_266: {
            const operand_251 = (in).source;
            const operand_252 = block_265: {
                const operand_253 = block_257: {
                    const operand_255 = ((in).work).enumerations;
                    const operand_256 = block_254: {
                        break :block_254 value_1;
                    };

                    if ((operand_256 >= (operand_255).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_257 (operand_255)[@intCast(operand_256)];
                };
                const operand_258 = block_262: {
                    const operand_260 = ((in).work).nodes;
                    const operand_261 = block_259: {
                        break :block_259 value_1;
                    };

                    if ((operand_261 >= (operand_260).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_262 (operand_260)[@intCast(operand_261)];
                };

                break :block_265 block_264: {
                    const operand_263 = (try (allocator).create((zx_abi).zx_type_50));

                    (operand_263).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_253, .index = operand_258, });

                    break :block_264 @as(*const (zx_abi).zx_type_50, operand_263);
                };
            };

            break :block_266 @as((zx_abi).value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_251, .reference = operand_252, });
        };

        break :block_270 (try function_11(allocator, (if (((operand_267).zx_origin != null)) (operand_267).zx_origin.? else block_269: {
            const operand_268 = (try (allocator).create((zx_abi).zx_type_92));

            (operand_268).* = (zx_abi).zx_type_92{ .reference = (operand_267).reference, .source = (operand_267).source, };

            break :block_269 @as(*const (zx_abi).zx_type_92, operand_268);
        })));
    };
    const value_3: ?[]const u8 = block_250: {
        const operand_248 = ((in).work).aliases;
        const operand_249 = block_247: {
            break :block_247 value_1;
        };

        if ((operand_249 >= (operand_248).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_250 (operand_248)[@intCast(operand_249)];
    };

    if (((block_201: {
        break :block_201 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Named))) {
        const value_4: (zx_abi).value_zx_type_90_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_246: {
            break :block_246 (try function_10_value(allocator, block_245: {
                const operand_239 = (in).source;
                const operand_240 = ((block_241: {
                    break :block_241 value_2;
                }).name).text;
                const operand_242 = block_244: {
                    const operand_243 = (in).source;

                    break :block_244 (try function_1(allocator, operand_243));
                };

                break :block_245 @as((zx_abi).value_zx_type_89_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_89_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .source = operand_239, .name = operand_240, .limit = operand_242, });
            }));
        };

        if ((value_4).found) {
            const value_5: *const (zx_abi).zx_type_54 = block_238: {
                const operand_235 = block_234: {
                    const operand_232 = (in).source;
                    const operand_233 = (value_4).index;

                    break :block_234 @as((zx_abi).value_zx_type_88_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_88_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_232, .index = operand_233, });
                };

                break :block_238 (try function_9(allocator, (if (((operand_235).zx_origin != null)) (operand_235).zx_origin.? else block_237: {
                    const operand_236 = (try (allocator).create((zx_abi).zx_type_88));

                    (operand_236).* = (zx_abi).zx_type_88{ .index = (operand_235).index, .source = (operand_235).source, };

                    break :block_237 @as(*const (zx_abi).zx_type_88, operand_236);
                })));
            };

            return block_231: {
                const operand_202 = in;
                const operand_203 = block_230: {
                    const operand_204 = (block_211: {
                        const operand_207 = (block_206: {
                            const operand_205 = ((in).work).nodes;

                            break :block_206 @as((zx_abi).value_zx_type_105_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_205).len == 0)) .{ operand_205, null, null, } else .{ (operand_205)[0..((operand_205).len - 1)], (operand_205)[((operand_205).len - 1)], null, }));
                        }).@"0";
                        const operand_209 = ((block_208: {
                            break :block_208 value_5;
                        }).value).index;
                        const operand_210 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_207).len, 1))));

                        @memcpy((operand_210)[0..(operand_207).len], operand_207);

                        (operand_210)[(operand_207).len] = operand_209;

                        break :block_211 @as((zx_abi).value_zx_type_83_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_210, {}, null, });
                    }).@"0";
                    const operand_212 = (block_219: {
                        const operand_215 = (block_214: {
                            const operand_213 = ((in).work).enumerations;

                            break :block_214 @as((zx_abi).value_zx_type_107_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_213).len == 0)) .{ operand_213, null, null, } else .{ (operand_213)[0..((operand_213).len - 1)], (operand_213)[((operand_213).len - 1)], null, }));
                        }).@"0";
                        const operand_217 = ((block_216: {
                            break :block_216 value_5;
                        }).value).enumeration;
                        const operand_218 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_215).len, 1))));

                        @memcpy((operand_218)[0..(operand_215).len], operand_215);

                        (operand_218)[(operand_215).len] = operand_217;

                        break :block_219 @as((zx_abi).value_zx_type_84_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_218, {}, null, });
                    }).@"0";
                    const operand_220 = (block_229: {
                        const operand_223 = (block_222: {
                            const operand_221 = ((in).work).aliases;

                            break :block_222 @as((zx_abi).value_zx_type_109_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec, (if (((operand_221).len == 0)) .{ operand_221, null, null, } else .{ (operand_221)[0..((operand_221).len - 1)], (operand_221)[((operand_221).len - 1)], null, }));
                        }).@"0";
                        const operand_227 = (if ((block_224: {
                            break :block_224 value_3;
                        } != null)) @as(?[]const u8, block_225: {
                            break :block_225 value_3;
                        }.?) else @as(?[]const u8, ((block_226: {
                            break :block_226 value_2;
                        }).name).text));
                        const operand_228 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_223).len, 1))));

                        @memcpy((operand_228)[0..(operand_223).len], operand_223);

                        (operand_228)[(operand_223).len] = operand_227;

                        break :block_229 @as((zx_abi).value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_228, {}, null, });
                    }).@"0";

                    break :block_230 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_204, .enumerations = operand_212, .aliases = operand_220, });
                };

                break :block_231 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (operand_202).names, .source = (operand_202).source, .valid = (operand_202).valid, .work = operand_203, });
            };
        }
    }

    if (((((block_188: {
        break :block_188 value_2;
    }).kind == @as((zx_abi).zx_type_48, .List)) or ((block_189: {
        break :block_189 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Application))) and (!block_197: {
        const operand_194 = block_193: {
            const operand_190 = (in).source;
            const operand_191 = (block_192: {
                break :block_192 value_2;
            }).child;

            break :block_193 @as((zx_abi).value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_190, .reference = operand_191, });
        };

        break :block_197 (try function_12(allocator, (if (((operand_194).zx_origin != null)) (operand_194).zx_origin.? else block_196: {
            const operand_195 = (try (allocator).create((zx_abi).zx_type_92));

            (operand_195).* = (zx_abi).zx_type_92{ .reference = (operand_194).reference, .source = (operand_194).source, };

            break :block_196 @as(*const (zx_abi).zx_type_92, operand_195);
        })));
    }))) {
        return block_200: {
            const operand_198 = in;
            const operand_199 = false;

            break :block_200 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (operand_198).names, .source = (operand_198).source, .valid = operand_199, .work = (operand_198).work, });
        };
    }

    const value_6: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = block_187: {
        const operand_169 = in;
        const operand_170 = (block_175: {
            const operand_171 = (in).names;
            const operand_173 = block_172: {
                break :block_172 value_3;
            };
            const operand_174 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_171).len, 1))));

            @memcpy((operand_174)[0..(operand_171).len], operand_171);

            (operand_174)[(operand_171).len] = operand_173;

            break :block_175 @as((zx_abi).value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_174, {}, null, });
        }).@"0";
        const operand_176 = block_186: {
            const operand_177 = (block_179: {
                const operand_178 = ((in).work).nodes;

                break :block_179 @as((zx_abi).value_zx_type_105_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_178).len == 0)) .{ operand_178, null, null, } else .{ (operand_178)[0..((operand_178).len - 1)], (operand_178)[((operand_178).len - 1)], null, }));
            }).@"0";
            const operand_180 = (block_182: {
                const operand_181 = ((in).work).enumerations;

                break :block_182 @as((zx_abi).value_zx_type_107_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_181).len == 0)) .{ operand_181, null, null, } else .{ (operand_181)[0..((operand_181).len - 1)], (operand_181)[((operand_181).len - 1)], null, }));
            }).@"0";
            const operand_183 = (block_185: {
                const operand_184 = ((in).work).aliases;

                break :block_185 @as((zx_abi).value_zx_type_109_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec, (if (((operand_184).len == 0)) .{ operand_184, null, null, } else .{ (operand_184)[0..((operand_184).len - 1)], (operand_184)[((operand_184).len - 1)], null, }));
            }).@"0";

            break :block_186 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_177, .enumerations = operand_180, .aliases = operand_183, });
        };

        break :block_187 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = operand_170, .source = (operand_169).source, .valid = (operand_169).valid, .work = operand_176, });
    };

    if (((((block_145: {
        break :block_145 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Optional)) or ((block_146: {
        break :block_146 value_2;
    }).kind == @as((zx_abi).zx_type_48, .List))) or ((block_147: {
        break :block_147 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Application)))) {
        return block_168: {
            const operand_148 = value_6;
            const operand_149 = block_167: {
                const operand_150 = (block_155: {
                    const operand_151 = ((value_6).work).nodes;
                    const operand_153 = ((block_152: {
                        break :block_152 value_2;
                    }).child).index;
                    const operand_154 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_151).len, 1))));

                    @memcpy((operand_154)[0..(operand_151).len], operand_151);

                    (operand_154)[(operand_151).len] = operand_153;

                    break :block_155 @as((zx_abi).value_zx_type_83_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_154, {}, null, });
                }).@"0";
                const operand_156 = (block_161: {
                    const operand_157 = ((value_6).work).enumerations;
                    const operand_159 = ((block_158: {
                        break :block_158 value_2;
                    }).child).enumeration;
                    const operand_160 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_157).len, 1))));

                    @memcpy((operand_160)[0..(operand_157).len], operand_157);

                    (operand_160)[(operand_157).len] = operand_159;

                    break :block_161 @as((zx_abi).value_zx_type_84_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_160, {}, null, });
                }).@"0";
                const operand_162 = (block_166: {
                    const operand_163 = ((value_6).work).aliases;
                    const operand_164 = @as(?[]const u8, null);
                    const operand_165 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_163).len, 1))));

                    @memcpy((operand_165)[0..(operand_163).len], operand_163);

                    (operand_165)[(operand_163).len] = operand_164;

                    break :block_166 @as((zx_abi).value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_165, {}, null, });
                }).@"0";

                break :block_167 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_150, .enumerations = operand_156, .aliases = operand_162, });
            };

            break :block_168 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (operand_148).names, .source = (operand_148).source, .valid = (operand_148).valid, .work = operand_149, });
        };
    }

    if ((((block_134: {
        break :block_134 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Object)) or ((block_135: {
        break :block_135 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Tuple)))) {
        return block_144: {
            break :block_144 (try function_17_value(allocator, block_143: {
                const operand_136 = value_6;
                const operand_137 = (block_138: {
                    break :block_138 value_2;
                }).position;
                const operand_139 = (block_140: {
                    break :block_140 value_2;
                }).count;
                const operand_141 = ((block_142: {
                    break :block_142 value_2;
                }).kind == @as((zx_abi).zx_type_48, .Object));

                break :block_143 @as((zx_abi).value_zx_type_102_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_102_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .state = operand_136, .position = operand_137, .count = operand_139, .object = operand_141, });
            }));
        };
    }

    return value_6;
}

fn function_18_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_44),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_14),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_31),
        started: *bool,
    },
    lane_8: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_32),
        started: *bool,
    },
    lane_9: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_30),
        started: *bool,
    },
    lane_10: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_11: ?struct {
        buffer: *(std).ArrayList(bool),
        started: *bool,
    },
    lane_12: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
}) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, (((in).work).nodes).len) - @as(u64, 1));
    const value_2: *const (zx_abi).zx_type_51 = block_442: {
        const operand_439 = block_438: {
            const operand_423 = (in).source;
            const operand_424 = block_437: {
                const operand_425 = block_429: {
                    const operand_427 = ((in).work).enumerations;
                    const operand_428 = block_426: {
                        break :block_426 value_1;
                    };

                    if ((operand_428 >= (operand_427).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_429 (operand_427)[@intCast(operand_428)];
                };
                const operand_430 = block_434: {
                    const operand_432 = ((in).work).nodes;
                    const operand_433 = block_431: {
                        break :block_431 value_1;
                    };

                    if ((operand_433 >= (operand_432).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_434 (operand_432)[@intCast(operand_433)];
                };

                break :block_437 block_436: {
                    const operand_435 = (try (allocator).create((zx_abi).zx_type_50));

                    (operand_435).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_425, .index = operand_430, });

                    break :block_436 @as(*const (zx_abi).zx_type_50, operand_435);
                };
            };

            break :block_438 @as((zx_abi).value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_423, .reference = operand_424, });
        };

        break :block_442 (try function_11(allocator, (if (((operand_439).zx_origin != null)) (operand_439).zx_origin.? else block_441: {
            const operand_440 = (try (allocator).create((zx_abi).zx_type_92));

            (operand_440).* = (zx_abi).zx_type_92{ .reference = (operand_439).reference, .source = (operand_439).source, };

            break :block_441 @as(*const (zx_abi).zx_type_92, operand_440);
        })));
    };
    const value_3: ?[]const u8 = block_422: {
        const operand_420 = ((in).work).aliases;
        const operand_421 = block_419: {
            break :block_419 value_1;
        };

        if ((operand_421 >= (operand_420).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_422 (operand_420)[@intCast(operand_421)];
    };

    if (((block_353: {
        break :block_353 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Named))) {
        const value_4: (zx_abi).value_zx_type_90_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_418: {
            break :block_418 (try function_10_value(allocator, block_417: {
                const operand_411 = (in).source;
                const operand_412 = ((block_413: {
                    break :block_413 value_2;
                }).name).text;
                const operand_414 = block_416: {
                    const operand_415 = (in).source;

                    break :block_416 (try function_1(allocator, operand_415));
                };

                break :block_417 @as((zx_abi).value_zx_type_89_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_89_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .source = operand_411, .name = operand_412, .limit = operand_414, });
            }));
        };

        if ((value_4).found) {
            const value_5: *const (zx_abi).zx_type_54 = block_410: {
                const operand_407 = block_406: {
                    const operand_404 = (in).source;
                    const operand_405 = (value_4).index;

                    break :block_406 @as((zx_abi).value_zx_type_88_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_88_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_404, .index = operand_405, });
                };

                break :block_410 (try function_9(allocator, (if (((operand_407).zx_origin != null)) (operand_407).zx_origin.? else block_409: {
                    const operand_408 = (try (allocator).create((zx_abi).zx_type_88));

                    (operand_408).* = (zx_abi).zx_type_88{ .index = (operand_407).index, .source = (operand_407).source, };

                    break :block_409 @as(*const (zx_abi).zx_type_88, operand_408);
                })));
            };

            return block_403: {
                const operand_354 = in;
                const operand_355 = block_402: {
                    const operand_356 = @as([]const u64, (if (((buffers).lane_12 != null)) block_362: {
                        const operand_359 = (block_358: {
                            const operand_357 = ((in).work).nodes;

                            break :block_358 @as((zx_abi).value_zx_type_105_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_357).len == 0)) .{ operand_357, null, null, } else .{ (operand_357)[0..((operand_357).len - 1)], (operand_357)[((operand_357).len - 1)], null, }));
                        }).@"0";
                        const operand_361 = ((block_360: {
                            break :block_360 value_5;
                        }).value).index;

                        _ = (try ((std).math).add(usize, (operand_359).len, 1));

                        if ((!(((buffers).lane_12.?).started).*)) {
                            (try ((((buffers).lane_12.?).buffer).*).appendSlice(allocator, operand_359));

                            (((buffers).lane_12.?).started).* = true;
                        } else {
                            (((((buffers).lane_12.?).buffer).*).items).len = (operand_359).len;
                        }

                        (try ((((buffers).lane_12.?).buffer).*).append(allocator, operand_361));

                        break :block_362 ((((buffers).lane_12.?).buffer).*).items;
                    } else (block_369: {
                        const operand_365 = (block_364: {
                            const operand_363 = ((in).work).nodes;

                            break :block_364 @as((zx_abi).value_zx_type_105_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_363).len == 0)) .{ operand_363, null, null, } else .{ (operand_363)[0..((operand_363).len - 1)], (operand_363)[((operand_363).len - 1)], null, }));
                        }).@"0";
                        const operand_367 = ((block_366: {
                            break :block_366 value_5;
                        }).value).index;
                        const operand_368 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_365).len, 1))));

                        @memcpy((operand_368)[0..(operand_365).len], operand_365);

                        (operand_368)[(operand_365).len] = operand_367;

                        break :block_369 @as((zx_abi).value_zx_type_83_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_368, {}, null, });
                    }).@"0"));
                    const operand_370 = @as([]const bool, (if (((buffers).lane_11 != null)) block_376: {
                        const operand_373 = (block_372: {
                            const operand_371 = ((in).work).enumerations;

                            break :block_372 @as((zx_abi).value_zx_type_107_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_371).len == 0)) .{ operand_371, null, null, } else .{ (operand_371)[0..((operand_371).len - 1)], (operand_371)[((operand_371).len - 1)], null, }));
                        }).@"0";
                        const operand_375 = ((block_374: {
                            break :block_374 value_5;
                        }).value).enumeration;

                        _ = (try ((std).math).add(usize, (operand_373).len, 1));

                        if ((!(((buffers).lane_11.?).started).*)) {
                            (try ((((buffers).lane_11.?).buffer).*).appendSlice(allocator, operand_373));

                            (((buffers).lane_11.?).started).* = true;
                        } else {
                            (((((buffers).lane_11.?).buffer).*).items).len = (operand_373).len;
                        }

                        (try ((((buffers).lane_11.?).buffer).*).append(allocator, operand_375));

                        break :block_376 ((((buffers).lane_11.?).buffer).*).items;
                    } else (block_383: {
                        const operand_379 = (block_378: {
                            const operand_377 = ((in).work).enumerations;

                            break :block_378 @as((zx_abi).value_zx_type_107_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_377).len == 0)) .{ operand_377, null, null, } else .{ (operand_377)[0..((operand_377).len - 1)], (operand_377)[((operand_377).len - 1)], null, }));
                        }).@"0";
                        const operand_381 = ((block_380: {
                            break :block_380 value_5;
                        }).value).enumeration;
                        const operand_382 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_379).len, 1))));

                        @memcpy((operand_382)[0..(operand_379).len], operand_379);

                        (operand_382)[(operand_379).len] = operand_381;

                        break :block_383 @as((zx_abi).value_zx_type_84_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_382, {}, null, });
                    }).@"0"));
                    const operand_384 = @as([]const ?[]const u8, (if (((buffers).lane_10 != null)) block_392: {
                        const operand_387 = (block_386: {
                            const operand_385 = ((in).work).aliases;

                            break :block_386 @as((zx_abi).value_zx_type_109_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec, (if (((operand_385).len == 0)) .{ operand_385, null, null, } else .{ (operand_385)[0..((operand_385).len - 1)], (operand_385)[((operand_385).len - 1)], null, }));
                        }).@"0";
                        const operand_391 = (if ((block_388: {
                            break :block_388 value_3;
                        } != null)) @as(?[]const u8, block_389: {
                            break :block_389 value_3;
                        }.?) else @as(?[]const u8, ((block_390: {
                            break :block_390 value_2;
                        }).name).text));

                        _ = (try ((std).math).add(usize, (operand_387).len, 1));

                        if ((!(((buffers).lane_10.?).started).*)) {
                            (try ((((buffers).lane_10.?).buffer).*).appendSlice(allocator, operand_387));

                            (((buffers).lane_10.?).started).* = true;
                        } else {
                            (((((buffers).lane_10.?).buffer).*).items).len = (operand_387).len;
                        }

                        (try ((((buffers).lane_10.?).buffer).*).append(allocator, operand_391));

                        break :block_392 ((((buffers).lane_10.?).buffer).*).items;
                    } else (block_401: {
                        const operand_395 = (block_394: {
                            const operand_393 = ((in).work).aliases;

                            break :block_394 @as((zx_abi).value_zx_type_109_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec, (if (((operand_393).len == 0)) .{ operand_393, null, null, } else .{ (operand_393)[0..((operand_393).len - 1)], (operand_393)[((operand_393).len - 1)], null, }));
                        }).@"0";
                        const operand_399 = (if ((block_396: {
                            break :block_396 value_3;
                        } != null)) @as(?[]const u8, block_397: {
                            break :block_397 value_3;
                        }.?) else @as(?[]const u8, ((block_398: {
                            break :block_398 value_2;
                        }).name).text));
                        const operand_400 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_395).len, 1))));

                        @memcpy((operand_400)[0..(operand_395).len], operand_395);

                        (operand_400)[(operand_395).len] = operand_399;

                        break :block_401 @as((zx_abi).value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_400, {}, null, });
                    }).@"0"));

                    break :block_402 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_356, .enumerations = operand_370, .aliases = operand_384, });
                };

                break :block_403 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (operand_354).names, .source = (operand_354).source, .valid = (operand_354).valid, .work = operand_355, });
            };
        }
    }

    if (((((block_340: {
        break :block_340 value_2;
    }).kind == @as((zx_abi).zx_type_48, .List)) or ((block_341: {
        break :block_341 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Application))) and (!block_349: {
        const operand_346 = block_345: {
            const operand_342 = (in).source;
            const operand_343 = (block_344: {
                break :block_344 value_2;
            }).child;

            break :block_345 @as((zx_abi).value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .source = operand_342, .reference = operand_343, });
        };

        break :block_349 (try function_12(allocator, (if (((operand_346).zx_origin != null)) (operand_346).zx_origin.? else block_348: {
            const operand_347 = (try (allocator).create((zx_abi).zx_type_92));

            (operand_347).* = (zx_abi).zx_type_92{ .reference = (operand_346).reference, .source = (operand_346).source, };

            break :block_348 @as(*const (zx_abi).zx_type_92, operand_347);
        })));
    }))) {
        return block_352: {
            const operand_350 = in;
            const operand_351 = false;

            break :block_352 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (operand_350).names, .source = (operand_350).source, .valid = operand_351, .work = (operand_350).work, });
        };
    }

    const value_6: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = block_339: {
        const operand_317 = in;
        const operand_318 = @as([]const ?[]const u8, (if (((buffers).lane_0 != null)) block_322: {
            const operand_319 = (in).names;
            const operand_321 = block_320: {
                break :block_320 value_3;
            };

            _ = (try ((std).math).add(usize, (operand_319).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_319));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_319).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_321));

            break :block_322 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_327: {
            const operand_323 = (in).names;
            const operand_325 = block_324: {
                break :block_324 value_3;
            };
            const operand_326 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_323).len, 1))));

            @memcpy((operand_326)[0..(operand_323).len], operand_323);

            (operand_326)[(operand_323).len] = operand_325;

            break :block_327 @as((zx_abi).value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_326, {}, null, });
        }).@"0"));
        const operand_328 = block_338: {
            const operand_329 = (block_331: {
                const operand_330 = ((in).work).nodes;

                break :block_331 @as((zx_abi).value_zx_type_105_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_330).len == 0)) .{ operand_330, null, null, } else .{ (operand_330)[0..((operand_330).len - 1)], (operand_330)[((operand_330).len - 1)], null, }));
            }).@"0";
            const operand_332 = (block_334: {
                const operand_333 = ((in).work).enumerations;

                break :block_334 @as((zx_abi).value_zx_type_107_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_333).len == 0)) .{ operand_333, null, null, } else .{ (operand_333)[0..((operand_333).len - 1)], (operand_333)[((operand_333).len - 1)], null, }));
            }).@"0";
            const operand_335 = (block_337: {
                const operand_336 = ((in).work).aliases;

                break :block_337 @as((zx_abi).value_zx_type_109_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec, (if (((operand_336).len == 0)) .{ operand_336, null, null, } else .{ (operand_336)[0..((operand_336).len - 1)], (operand_336)[((operand_336).len - 1)], null, }));
            }).@"0";

            break :block_338 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_329, .enumerations = operand_332, .aliases = operand_335, });
        };

        break :block_339 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = operand_318, .source = (operand_317).source, .valid = (operand_317).valid, .work = operand_328, });
    };

    if (((((block_282: {
        break :block_282 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Optional)) or ((block_283: {
        break :block_283 value_2;
    }).kind == @as((zx_abi).zx_type_48, .List))) or ((block_284: {
        break :block_284 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Application)))) {
        return block_316: {
            const operand_285 = value_6;
            const operand_286 = block_315: {
                const operand_287 = @as([]const u64, (if (((buffers).lane_12 != null)) block_291: {
                    const operand_288 = ((value_6).work).nodes;
                    const operand_290 = ((block_289: {
                        break :block_289 value_2;
                    }).child).index;

                    _ = (try ((std).math).add(usize, (operand_288).len, 1));

                    if ((!(((buffers).lane_12.?).started).*)) {
                        (try ((((buffers).lane_12.?).buffer).*).appendSlice(allocator, operand_288));

                        (((buffers).lane_12.?).started).* = true;
                    } else {
                        (((((buffers).lane_12.?).buffer).*).items).len = (operand_288).len;
                    }

                    (try ((((buffers).lane_12.?).buffer).*).append(allocator, operand_290));

                    break :block_291 ((((buffers).lane_12.?).buffer).*).items;
                } else (block_296: {
                    const operand_292 = ((value_6).work).nodes;
                    const operand_294 = ((block_293: {
                        break :block_293 value_2;
                    }).child).index;
                    const operand_295 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_292).len, 1))));

                    @memcpy((operand_295)[0..(operand_292).len], operand_292);

                    (operand_295)[(operand_292).len] = operand_294;

                    break :block_296 @as((zx_abi).value_zx_type_83_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_295, {}, null, });
                }).@"0"));
                const operand_297 = @as([]const bool, (if (((buffers).lane_11 != null)) block_301: {
                    const operand_298 = ((value_6).work).enumerations;
                    const operand_300 = ((block_299: {
                        break :block_299 value_2;
                    }).child).enumeration;

                    _ = (try ((std).math).add(usize, (operand_298).len, 1));

                    if ((!(((buffers).lane_11.?).started).*)) {
                        (try ((((buffers).lane_11.?).buffer).*).appendSlice(allocator, operand_298));

                        (((buffers).lane_11.?).started).* = true;
                    } else {
                        (((((buffers).lane_11.?).buffer).*).items).len = (operand_298).len;
                    }

                    (try ((((buffers).lane_11.?).buffer).*).append(allocator, operand_300));

                    break :block_301 ((((buffers).lane_11.?).buffer).*).items;
                } else (block_306: {
                    const operand_302 = ((value_6).work).enumerations;
                    const operand_304 = ((block_303: {
                        break :block_303 value_2;
                    }).child).enumeration;
                    const operand_305 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_302).len, 1))));

                    @memcpy((operand_305)[0..(operand_302).len], operand_302);

                    (operand_305)[(operand_302).len] = operand_304;

                    break :block_306 @as((zx_abi).value_zx_type_84_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_305, {}, null, });
                }).@"0"));
                const operand_307 = @as([]const ?[]const u8, (if (((buffers).lane_10 != null)) block_310: {
                    const operand_308 = ((value_6).work).aliases;
                    const operand_309 = @as(?[]const u8, null);

                    _ = (try ((std).math).add(usize, (operand_308).len, 1));

                    if ((!(((buffers).lane_10.?).started).*)) {
                        (try ((((buffers).lane_10.?).buffer).*).appendSlice(allocator, operand_308));

                        (((buffers).lane_10.?).started).* = true;
                    } else {
                        (((((buffers).lane_10.?).buffer).*).items).len = (operand_308).len;
                    }

                    (try ((((buffers).lane_10.?).buffer).*).append(allocator, operand_309));

                    break :block_310 ((((buffers).lane_10.?).buffer).*).items;
                } else (block_314: {
                    const operand_311 = ((value_6).work).aliases;
                    const operand_312 = @as(?[]const u8, null);
                    const operand_313 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_311).len, 1))));

                    @memcpy((operand_313)[0..(operand_311).len], operand_311);

                    (operand_313)[(operand_311).len] = operand_312;

                    break :block_314 @as((zx_abi).value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_313, {}, null, });
                }).@"0"));

                break :block_315 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_287, .enumerations = operand_297, .aliases = operand_307, });
            };

            break :block_316 @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (operand_285).names, .source = (operand_285).source, .valid = (operand_285).valid, .work = operand_286, });
        };
    }

    if ((((block_271: {
        break :block_271 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Object)) or ((block_272: {
        break :block_272 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Tuple)))) {
        return @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, block_281: {
            break :block_281 (try function_17_buffered(allocator, block_280: {
                const operand_273 = value_6;
                const operand_274 = (block_275: {
                    break :block_275 value_2;
                }).position;
                const operand_276 = (block_277: {
                    break :block_277 value_2;
                }).count;
                const operand_278 = ((block_279: {
                    break :block_279 value_2;
                }).kind == @as((zx_abi).zx_type_48, .Object));

                break :block_280 @as((zx_abi).value_zx_type_102_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52, (zx_abi).value_zx_type_102_5b2a02a1b2fe3bb9ad7e9fa638273a39c44e470b2bf4f81a8e42378cdb9d8f52{ .state = operand_273, .position = operand_274, .count = operand_276, .object = operand_278, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), .lane_3 = (if (((buffers).lane_3 != null)) .{ .buffer = (&(((buffers).lane_3.?).buffer).*), .started = (&(((buffers).lane_3.?).started).*), } else null), .lane_4 = (if (((buffers).lane_4 != null)) .{ .buffer = (&(((buffers).lane_4.?).buffer).*), .started = (&(((buffers).lane_4.?).started).*), } else null), .lane_5 = (if (((buffers).lane_5 != null)) .{ .buffer = (&(((buffers).lane_5.?).buffer).*), .started = (&(((buffers).lane_5.?).started).*), } else null), .lane_6 = (if (((buffers).lane_6 != null)) .{ .buffer = (&(((buffers).lane_6.?).buffer).*), .started = (&(((buffers).lane_6.?).started).*), } else null), .lane_7 = (if (((buffers).lane_7 != null)) .{ .buffer = (&(((buffers).lane_7.?).buffer).*), .started = (&(((buffers).lane_7.?).started).*), } else null), .lane_8 = (if (((buffers).lane_8 != null)) .{ .buffer = (&(((buffers).lane_8.?).buffer).*), .started = (&(((buffers).lane_8.?).started).*), } else null), .lane_9 = (if (((buffers).lane_9 != null)) .{ .buffer = (&(((buffers).lane_9.?).buffer).*), .started = (&(((buffers).lane_9.?).started).*), } else null), .lane_10 = (if (((buffers).lane_10 != null)) .{ .buffer = (&(((buffers).lane_10.?).buffer).*), .started = (&(((buffers).lane_10.?).started).*), } else null), .lane_11 = (if (((buffers).lane_11 != null)) .{ .buffer = (&(((buffers).lane_11.?).buffer).*), .started = (&(((buffers).lane_11.?).started).*), } else null), .lane_12 = (if (((buffers).lane_12 != null)) .{ .buffer = (&(((buffers).lane_12.?).buffer).*), .started = (&(((buffers).lane_12.?).started).*), } else null), }));
        });
    }

    return value_6;
}

fn function_19(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_80) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_81 {
    @setRuntimeSafety(true);

    const value_4: *const (zx_abi).zx_type_80 = block_95: {
        const operand_7 = in;

        var state_capacity_9: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_10 = false;

        defer (state_capacity_9).deinit(allocator);

        var state_capacity_11: (std).ArrayList(*const (zx_abi).zx_type_44) = .empty;

        var state_capacity_started_12 = false;

        defer (state_capacity_11).deinit(allocator);

        var state_capacity_13: (std).ArrayList(*const (zx_abi).zx_type_14) = .empty;

        var state_capacity_started_14 = false;

        defer (state_capacity_13).deinit(allocator);

        var state_capacity_15: (std).ArrayList(u64) = .empty;

        var state_capacity_started_16 = false;

        defer (state_capacity_15).deinit(allocator);

        var state_capacity_17: (std).ArrayList(u64) = .empty;

        var state_capacity_started_18 = false;

        defer (state_capacity_17).deinit(allocator);

        var state_capacity_19: (std).ArrayList(u64) = .empty;

        var state_capacity_started_20 = false;

        defer (state_capacity_19).deinit(allocator);

        var state_capacity_21: (std).ArrayList(*const (zx_abi).zx_type_31) = .empty;

        var state_capacity_started_22 = false;

        defer (state_capacity_21).deinit(allocator);

        var state_capacity_23: (std).ArrayList(*const (zx_abi).zx_type_32) = .empty;

        var state_capacity_started_24 = false;

        defer (state_capacity_23).deinit(allocator);

        var state_capacity_25: (std).ArrayList(*const (zx_abi).zx_type_30) = .empty;

        var state_capacity_started_26 = false;

        defer (state_capacity_25).deinit(allocator);

        var state_capacity_27: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_28 = false;

        defer (state_capacity_27).deinit(allocator);

        var state_capacity_29: (std).ArrayList(bool) = .empty;

        var state_capacity_started_30 = false;

        defer (state_capacity_29).deinit(allocator);

        var state_capacity_31: (std).ArrayList(u64) = .empty;

        var state_capacity_started_32 = false;

        defer (state_capacity_31).deinit(allocator);

        var state_6: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (operand_7).names, .source = (operand_7).source, .valid = (operand_7).valid, .work = (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((operand_7).work).aliases, .enumerations = ((operand_7).work).enumerations, .nodes = ((operand_7).work).nodes, .zx_origin = (operand_7).work, }, .zx_origin = operand_7, };

        var state_changed_8 = false;

        while (((state_6).valid and (@as(u64, (((state_6).work).nodes).len) != @as(u64, 0)))) {
            state_6 = @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, block_33: {
                break :block_33 (try function_18_buffered(allocator, state_6, .{ .lane_0 = .{ .buffer = (&state_capacity_9), .started = (&state_capacity_started_10), }, .lane_2 = .{ .buffer = (&state_capacity_11), .started = (&state_capacity_started_12), }, .lane_3 = .{ .buffer = (&state_capacity_13), .started = (&state_capacity_started_14), }, .lane_4 = .{ .buffer = (&state_capacity_15), .started = (&state_capacity_started_16), }, .lane_5 = .{ .buffer = (&state_capacity_17), .started = (&state_capacity_started_18), }, .lane_6 = .{ .buffer = (&state_capacity_19), .started = (&state_capacity_started_20), }, .lane_7 = .{ .buffer = (&state_capacity_21), .started = (&state_capacity_started_22), }, .lane_8 = .{ .buffer = (&state_capacity_23), .started = (&state_capacity_started_24), }, .lane_9 = .{ .buffer = (&state_capacity_25), .started = (&state_capacity_started_26), }, .lane_10 = .{ .buffer = (&state_capacity_27), .started = (&state_capacity_started_28), }, .lane_11 = .{ .buffer = (&state_capacity_29), .started = (&state_capacity_started_30), }, .lane_12 = .{ .buffer = (&state_capacity_31), .started = (&state_capacity_started_32), }, }));
            });

            state_changed_8 = true;
        }

        var state_owned_34: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_34);

        if (state_capacity_started_10) {
            ((state_capacity_9).items).len = ((state_6).names).len;

            state_owned_34 = (try (state_capacity_9).toOwnedSlice(allocator));
        }

        if (state_capacity_started_10) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = state_owned_34, .source = (state_6).source, .valid = (state_6).valid, .work = (state_6).work, };
        }

        var state_owned_35: []const *const (zx_abi).zx_type_44 = (&[_]*const (zx_abi).zx_type_44{});

        errdefer (allocator).free(state_owned_35);

        if (state_capacity_started_12) {
            ((state_capacity_11).items).len = ((((state_6).source).indexed).declarations).len;

            state_owned_35 = (try (state_capacity_11).toOwnedSlice(allocator));
        }

        if (state_capacity_started_12) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = block_39: {
                const operand_38 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_38).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_37: {
                    const operand_36 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_36).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_6).source).indexed).bytes, .declarations = state_owned_35, .members = (((state_6).source).indexed).members, .order = (((state_6).source).indexed).order, .types = (((state_6).source).indexed).types, });

                    break :block_37 @as(*const (zx_abi).zx_type_64, operand_36);
                }, .native = ((state_6).source).native, });

                break :block_39 @as(*const (zx_abi).zx_type_66, operand_38);
            }, .valid = (state_6).valid, .work = (state_6).work, };
        }

        var state_owned_40: []const *const (zx_abi).zx_type_14 = (&[_]*const (zx_abi).zx_type_14{});

        errdefer (allocator).free(state_owned_40);

        if (state_capacity_started_14) {
            ((state_capacity_13).items).len = ((((state_6).source).indexed).members).len;

            state_owned_40 = (try (state_capacity_13).toOwnedSlice(allocator));
        }

        if (state_capacity_started_14) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = block_44: {
                const operand_43 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_43).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_42: {
                    const operand_41 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_41).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_6).source).indexed).bytes, .declarations = (((state_6).source).indexed).declarations, .members = state_owned_40, .order = (((state_6).source).indexed).order, .types = (((state_6).source).indexed).types, });

                    break :block_42 @as(*const (zx_abi).zx_type_64, operand_41);
                }, .native = ((state_6).source).native, });

                break :block_44 @as(*const (zx_abi).zx_type_66, operand_43);
            }, .valid = (state_6).valid, .work = (state_6).work, };
        }

        var state_owned_45: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_45);

        if (state_capacity_started_16) {
            ((state_capacity_15).items).len = (((((state_6).source).indexed).order).fields).len;

            state_owned_45 = (try (state_capacity_15).toOwnedSlice(allocator));
        }

        if (state_capacity_started_16) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = block_51: {
                const operand_50 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_50).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_49: {
                    const operand_48 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_48).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_6).source).indexed).bytes, .declarations = (((state_6).source).indexed).declarations, .members = (((state_6).source).indexed).members, .order = block_47: {
                        const operand_46 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_46).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .fields = state_owned_45, .heads = ((((state_6).source).indexed).order).heads, .items = ((((state_6).source).indexed).order).items, });

                        break :block_47 @as(*const (zx_abi).zx_type_34, operand_46);
                    }, .types = (((state_6).source).indexed).types, });

                    break :block_49 @as(*const (zx_abi).zx_type_64, operand_48);
                }, .native = ((state_6).source).native, });

                break :block_51 @as(*const (zx_abi).zx_type_66, operand_50);
            }, .valid = (state_6).valid, .work = (state_6).work, };
        }

        var state_owned_52: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_52);

        if (state_capacity_started_18) {
            ((state_capacity_17).items).len = (((((state_6).source).indexed).order).heads).len;

            state_owned_52 = (try (state_capacity_17).toOwnedSlice(allocator));
        }

        if (state_capacity_started_18) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = block_58: {
                const operand_57 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_57).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_56: {
                    const operand_55 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_55).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_6).source).indexed).bytes, .declarations = (((state_6).source).indexed).declarations, .members = (((state_6).source).indexed).members, .order = block_54: {
                        const operand_53 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_53).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .fields = ((((state_6).source).indexed).order).fields, .heads = state_owned_52, .items = ((((state_6).source).indexed).order).items, });

                        break :block_54 @as(*const (zx_abi).zx_type_34, operand_53);
                    }, .types = (((state_6).source).indexed).types, });

                    break :block_56 @as(*const (zx_abi).zx_type_64, operand_55);
                }, .native = ((state_6).source).native, });

                break :block_58 @as(*const (zx_abi).zx_type_66, operand_57);
            }, .valid = (state_6).valid, .work = (state_6).work, };
        }

        var state_owned_59: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_59);

        if (state_capacity_started_20) {
            ((state_capacity_19).items).len = (((((state_6).source).indexed).order).items).len;

            state_owned_59 = (try (state_capacity_19).toOwnedSlice(allocator));
        }

        if (state_capacity_started_20) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = block_65: {
                const operand_64 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_64).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_63: {
                    const operand_62 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_62).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_6).source).indexed).bytes, .declarations = (((state_6).source).indexed).declarations, .members = (((state_6).source).indexed).members, .order = block_61: {
                        const operand_60 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_60).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .fields = ((((state_6).source).indexed).order).fields, .heads = ((((state_6).source).indexed).order).heads, .items = state_owned_59, });

                        break :block_61 @as(*const (zx_abi).zx_type_34, operand_60);
                    }, .types = (((state_6).source).indexed).types, });

                    break :block_63 @as(*const (zx_abi).zx_type_64, operand_62);
                }, .native = ((state_6).source).native, });

                break :block_65 @as(*const (zx_abi).zx_type_66, operand_64);
            }, .valid = (state_6).valid, .work = (state_6).work, };
        }

        var state_owned_66: []const *const (zx_abi).zx_type_31 = (&[_]*const (zx_abi).zx_type_31{});

        errdefer (allocator).free(state_owned_66);

        if (state_capacity_started_22) {
            ((state_capacity_21).items).len = (((((state_6).source).indexed).types).fields).len;

            state_owned_66 = (try (state_capacity_21).toOwnedSlice(allocator));
        }

        if (state_capacity_started_22) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = block_72: {
                const operand_71 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_71).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_70: {
                    const operand_69 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_69).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_6).source).indexed).bytes, .declarations = (((state_6).source).indexed).declarations, .members = (((state_6).source).indexed).members, .order = (((state_6).source).indexed).order, .types = block_68: {
                        const operand_67 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_67).* = @as((zx_abi).zx_type_38, (zx_abi).zx_type_38{ .fields = state_owned_66, .items = ((((state_6).source).indexed).types).items, .nodes = ((((state_6).source).indexed).types).nodes, });

                        break :block_68 @as(*const (zx_abi).zx_type_38, operand_67);
                    }, });

                    break :block_70 @as(*const (zx_abi).zx_type_64, operand_69);
                }, .native = ((state_6).source).native, });

                break :block_72 @as(*const (zx_abi).zx_type_66, operand_71);
            }, .valid = (state_6).valid, .work = (state_6).work, };
        }

        var state_owned_73: []const *const (zx_abi).zx_type_32 = (&[_]*const (zx_abi).zx_type_32{});

        errdefer (allocator).free(state_owned_73);

        if (state_capacity_started_24) {
            ((state_capacity_23).items).len = (((((state_6).source).indexed).types).items).len;

            state_owned_73 = (try (state_capacity_23).toOwnedSlice(allocator));
        }

        if (state_capacity_started_24) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = block_79: {
                const operand_78 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_78).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_77: {
                    const operand_76 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_76).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_6).source).indexed).bytes, .declarations = (((state_6).source).indexed).declarations, .members = (((state_6).source).indexed).members, .order = (((state_6).source).indexed).order, .types = block_75: {
                        const operand_74 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_74).* = @as((zx_abi).zx_type_38, (zx_abi).zx_type_38{ .fields = ((((state_6).source).indexed).types).fields, .items = state_owned_73, .nodes = ((((state_6).source).indexed).types).nodes, });

                        break :block_75 @as(*const (zx_abi).zx_type_38, operand_74);
                    }, });

                    break :block_77 @as(*const (zx_abi).zx_type_64, operand_76);
                }, .native = ((state_6).source).native, });

                break :block_79 @as(*const (zx_abi).zx_type_66, operand_78);
            }, .valid = (state_6).valid, .work = (state_6).work, };
        }

        var state_owned_80: []const *const (zx_abi).zx_type_30 = (&[_]*const (zx_abi).zx_type_30{});

        errdefer (allocator).free(state_owned_80);

        if (state_capacity_started_26) {
            ((state_capacity_25).items).len = (((((state_6).source).indexed).types).nodes).len;

            state_owned_80 = (try (state_capacity_25).toOwnedSlice(allocator));
        }

        if (state_capacity_started_26) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = block_86: {
                const operand_85 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_85).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_84: {
                    const operand_83 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_83).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_6).source).indexed).bytes, .declarations = (((state_6).source).indexed).declarations, .members = (((state_6).source).indexed).members, .order = (((state_6).source).indexed).order, .types = block_82: {
                        const operand_81 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_81).* = @as((zx_abi).zx_type_38, (zx_abi).zx_type_38{ .fields = ((((state_6).source).indexed).types).fields, .items = ((((state_6).source).indexed).types).items, .nodes = state_owned_80, });

                        break :block_82 @as(*const (zx_abi).zx_type_38, operand_81);
                    }, });

                    break :block_84 @as(*const (zx_abi).zx_type_64, operand_83);
                }, .native = ((state_6).source).native, });

                break :block_86 @as(*const (zx_abi).zx_type_66, operand_85);
            }, .valid = (state_6).valid, .work = (state_6).work, };
        }

        var state_owned_87: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_87);

        if (state_capacity_started_28) {
            ((state_capacity_27).items).len = (((state_6).work).aliases).len;

            state_owned_87 = (try (state_capacity_27).toOwnedSlice(allocator));
        }

        if (state_capacity_started_28) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = (state_6).source, .valid = (state_6).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_87, .enumerations = ((state_6).work).enumerations, .nodes = ((state_6).work).nodes, }), };
        }

        var state_owned_88: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_88);

        if (state_capacity_started_30) {
            ((state_capacity_29).items).len = (((state_6).work).enumerations).len;

            state_owned_88 = (try (state_capacity_29).toOwnedSlice(allocator));
        }

        if (state_capacity_started_30) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = (state_6).source, .valid = (state_6).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_6).work).aliases, .enumerations = state_owned_88, .nodes = ((state_6).work).nodes, }), };
        }

        var state_owned_89: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_89);

        if (state_capacity_started_32) {
            ((state_capacity_31).items).len = (((state_6).work).nodes).len;

            state_owned_89 = (try (state_capacity_31).toOwnedSlice(allocator));
        }

        if (state_capacity_started_32) {
            state_6 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_6).names, .source = (state_6).source, .valid = (state_6).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_6).work).aliases, .enumerations = ((state_6).work).enumerations, .nodes = state_owned_89, }), };
        }

        break :block_95 (if (state_changed_8) block_94: {
            break :block_94 (if (((state_6).zx_origin != null)) (state_6).zx_origin.? else block_93: {
                const operand_92 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_92).* = (zx_abi).zx_type_80{ .names = (state_6).names, .source = (state_6).source, .valid = (state_6).valid, .work = (if ((((state_6).work).zx_origin != null)) ((state_6).work).zx_origin.? else block_91: {
                    const operand_90 = (try (allocator).create((zx_abi).zx_type_79));

                    (operand_90).* = (zx_abi).zx_type_79{ .aliases = ((state_6).work).aliases, .enumerations = ((state_6).work).enumerations, .nodes = ((state_6).work).nodes, };

                    break :block_91 @as(*const (zx_abi).zx_type_79, operand_90);
                }), };

                break :block_93 @as(*const (zx_abi).zx_type_80, operand_92);
            });
        } else operand_7);
    };

    return block_5: {
        const operand_1 = (value_4).names;
        const operand_2 = (value_4).valid;

        break :block_5 block_4: {
            const operand_3 = (try (allocator).create((zx_abi).zx_type_81));

            (operand_3).* = @as((zx_abi).zx_type_81, (zx_abi).zx_type_81{ .names = operand_1, .valid = operand_2, });

            break :block_4 @as(*const (zx_abi).zx_type_81, operand_3);
        };
    };
}

fn function_19_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_4: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = block_184: {
        const operand_100 = in;

        var state_capacity_102: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_103 = false;

        defer (state_capacity_102).deinit(allocator);

        var state_capacity_104: (std).ArrayList(*const (zx_abi).zx_type_44) = .empty;

        var state_capacity_started_105 = false;

        defer (state_capacity_104).deinit(allocator);

        var state_capacity_106: (std).ArrayList(*const (zx_abi).zx_type_14) = .empty;

        var state_capacity_started_107 = false;

        defer (state_capacity_106).deinit(allocator);

        var state_capacity_108: (std).ArrayList(u64) = .empty;

        var state_capacity_started_109 = false;

        defer (state_capacity_108).deinit(allocator);

        var state_capacity_110: (std).ArrayList(u64) = .empty;

        var state_capacity_started_111 = false;

        defer (state_capacity_110).deinit(allocator);

        var state_capacity_112: (std).ArrayList(u64) = .empty;

        var state_capacity_started_113 = false;

        defer (state_capacity_112).deinit(allocator);

        var state_capacity_114: (std).ArrayList(*const (zx_abi).zx_type_31) = .empty;

        var state_capacity_started_115 = false;

        defer (state_capacity_114).deinit(allocator);

        var state_capacity_116: (std).ArrayList(*const (zx_abi).zx_type_32) = .empty;

        var state_capacity_started_117 = false;

        defer (state_capacity_116).deinit(allocator);

        var state_capacity_118: (std).ArrayList(*const (zx_abi).zx_type_30) = .empty;

        var state_capacity_started_119 = false;

        defer (state_capacity_118).deinit(allocator);

        var state_capacity_120: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_121 = false;

        defer (state_capacity_120).deinit(allocator);

        var state_capacity_122: (std).ArrayList(bool) = .empty;

        var state_capacity_started_123 = false;

        defer (state_capacity_122).deinit(allocator);

        var state_capacity_124: (std).ArrayList(u64) = .empty;

        var state_capacity_started_125 = false;

        defer (state_capacity_124).deinit(allocator);

        var state_99: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = operand_100;

        var state_changed_101 = false;

        while (((state_99).valid and (@as(u64, (((state_99).work).nodes).len) != @as(u64, 0)))) {
            state_99 = @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, block_126: {
                break :block_126 (try function_18_buffered(allocator, state_99, .{ .lane_0 = .{ .buffer = (&state_capacity_102), .started = (&state_capacity_started_103), }, .lane_2 = .{ .buffer = (&state_capacity_104), .started = (&state_capacity_started_105), }, .lane_3 = .{ .buffer = (&state_capacity_106), .started = (&state_capacity_started_107), }, .lane_4 = .{ .buffer = (&state_capacity_108), .started = (&state_capacity_started_109), }, .lane_5 = .{ .buffer = (&state_capacity_110), .started = (&state_capacity_started_111), }, .lane_6 = .{ .buffer = (&state_capacity_112), .started = (&state_capacity_started_113), }, .lane_7 = .{ .buffer = (&state_capacity_114), .started = (&state_capacity_started_115), }, .lane_8 = .{ .buffer = (&state_capacity_116), .started = (&state_capacity_started_117), }, .lane_9 = .{ .buffer = (&state_capacity_118), .started = (&state_capacity_started_119), }, .lane_10 = .{ .buffer = (&state_capacity_120), .started = (&state_capacity_started_121), }, .lane_11 = .{ .buffer = (&state_capacity_122), .started = (&state_capacity_started_123), }, .lane_12 = .{ .buffer = (&state_capacity_124), .started = (&state_capacity_started_125), }, }));
            });

            state_changed_101 = true;
        }

        var state_owned_127: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_127);

        if (state_capacity_started_103) {
            ((state_capacity_102).items).len = ((state_99).names).len;

            state_owned_127 = (try (state_capacity_102).toOwnedSlice(allocator));
        }

        if (state_capacity_started_103) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = state_owned_127, .source = (state_99).source, .valid = (state_99).valid, .work = (state_99).work, };
        }

        var state_owned_128: []const *const (zx_abi).zx_type_44 = (&[_]*const (zx_abi).zx_type_44{});

        errdefer (allocator).free(state_owned_128);

        if (state_capacity_started_105) {
            ((state_capacity_104).items).len = ((((state_99).source).indexed).declarations).len;

            state_owned_128 = (try (state_capacity_104).toOwnedSlice(allocator));
        }

        if (state_capacity_started_105) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = block_132: {
                const operand_131 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_131).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_130: {
                    const operand_129 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_129).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_99).source).indexed).bytes, .declarations = state_owned_128, .members = (((state_99).source).indexed).members, .order = (((state_99).source).indexed).order, .types = (((state_99).source).indexed).types, });

                    break :block_130 @as(*const (zx_abi).zx_type_64, operand_129);
                }, .native = ((state_99).source).native, });

                break :block_132 @as(*const (zx_abi).zx_type_66, operand_131);
            }, .valid = (state_99).valid, .work = (state_99).work, };
        }

        var state_owned_133: []const *const (zx_abi).zx_type_14 = (&[_]*const (zx_abi).zx_type_14{});

        errdefer (allocator).free(state_owned_133);

        if (state_capacity_started_107) {
            ((state_capacity_106).items).len = ((((state_99).source).indexed).members).len;

            state_owned_133 = (try (state_capacity_106).toOwnedSlice(allocator));
        }

        if (state_capacity_started_107) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = block_137: {
                const operand_136 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_136).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_135: {
                    const operand_134 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_134).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_99).source).indexed).bytes, .declarations = (((state_99).source).indexed).declarations, .members = state_owned_133, .order = (((state_99).source).indexed).order, .types = (((state_99).source).indexed).types, });

                    break :block_135 @as(*const (zx_abi).zx_type_64, operand_134);
                }, .native = ((state_99).source).native, });

                break :block_137 @as(*const (zx_abi).zx_type_66, operand_136);
            }, .valid = (state_99).valid, .work = (state_99).work, };
        }

        var state_owned_138: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_138);

        if (state_capacity_started_109) {
            ((state_capacity_108).items).len = (((((state_99).source).indexed).order).fields).len;

            state_owned_138 = (try (state_capacity_108).toOwnedSlice(allocator));
        }

        if (state_capacity_started_109) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = block_144: {
                const operand_143 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_143).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_142: {
                    const operand_141 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_141).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_99).source).indexed).bytes, .declarations = (((state_99).source).indexed).declarations, .members = (((state_99).source).indexed).members, .order = block_140: {
                        const operand_139 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_139).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .fields = state_owned_138, .heads = ((((state_99).source).indexed).order).heads, .items = ((((state_99).source).indexed).order).items, });

                        break :block_140 @as(*const (zx_abi).zx_type_34, operand_139);
                    }, .types = (((state_99).source).indexed).types, });

                    break :block_142 @as(*const (zx_abi).zx_type_64, operand_141);
                }, .native = ((state_99).source).native, });

                break :block_144 @as(*const (zx_abi).zx_type_66, operand_143);
            }, .valid = (state_99).valid, .work = (state_99).work, };
        }

        var state_owned_145: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_145);

        if (state_capacity_started_111) {
            ((state_capacity_110).items).len = (((((state_99).source).indexed).order).heads).len;

            state_owned_145 = (try (state_capacity_110).toOwnedSlice(allocator));
        }

        if (state_capacity_started_111) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = block_151: {
                const operand_150 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_150).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_149: {
                    const operand_148 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_148).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_99).source).indexed).bytes, .declarations = (((state_99).source).indexed).declarations, .members = (((state_99).source).indexed).members, .order = block_147: {
                        const operand_146 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_146).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .fields = ((((state_99).source).indexed).order).fields, .heads = state_owned_145, .items = ((((state_99).source).indexed).order).items, });

                        break :block_147 @as(*const (zx_abi).zx_type_34, operand_146);
                    }, .types = (((state_99).source).indexed).types, });

                    break :block_149 @as(*const (zx_abi).zx_type_64, operand_148);
                }, .native = ((state_99).source).native, });

                break :block_151 @as(*const (zx_abi).zx_type_66, operand_150);
            }, .valid = (state_99).valid, .work = (state_99).work, };
        }

        var state_owned_152: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_152);

        if (state_capacity_started_113) {
            ((state_capacity_112).items).len = (((((state_99).source).indexed).order).items).len;

            state_owned_152 = (try (state_capacity_112).toOwnedSlice(allocator));
        }

        if (state_capacity_started_113) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = block_158: {
                const operand_157 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_157).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_156: {
                    const operand_155 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_155).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_99).source).indexed).bytes, .declarations = (((state_99).source).indexed).declarations, .members = (((state_99).source).indexed).members, .order = block_154: {
                        const operand_153 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_153).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .fields = ((((state_99).source).indexed).order).fields, .heads = ((((state_99).source).indexed).order).heads, .items = state_owned_152, });

                        break :block_154 @as(*const (zx_abi).zx_type_34, operand_153);
                    }, .types = (((state_99).source).indexed).types, });

                    break :block_156 @as(*const (zx_abi).zx_type_64, operand_155);
                }, .native = ((state_99).source).native, });

                break :block_158 @as(*const (zx_abi).zx_type_66, operand_157);
            }, .valid = (state_99).valid, .work = (state_99).work, };
        }

        var state_owned_159: []const *const (zx_abi).zx_type_31 = (&[_]*const (zx_abi).zx_type_31{});

        errdefer (allocator).free(state_owned_159);

        if (state_capacity_started_115) {
            ((state_capacity_114).items).len = (((((state_99).source).indexed).types).fields).len;

            state_owned_159 = (try (state_capacity_114).toOwnedSlice(allocator));
        }

        if (state_capacity_started_115) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = block_165: {
                const operand_164 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_164).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_163: {
                    const operand_162 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_162).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_99).source).indexed).bytes, .declarations = (((state_99).source).indexed).declarations, .members = (((state_99).source).indexed).members, .order = (((state_99).source).indexed).order, .types = block_161: {
                        const operand_160 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_160).* = @as((zx_abi).zx_type_38, (zx_abi).zx_type_38{ .fields = state_owned_159, .items = ((((state_99).source).indexed).types).items, .nodes = ((((state_99).source).indexed).types).nodes, });

                        break :block_161 @as(*const (zx_abi).zx_type_38, operand_160);
                    }, });

                    break :block_163 @as(*const (zx_abi).zx_type_64, operand_162);
                }, .native = ((state_99).source).native, });

                break :block_165 @as(*const (zx_abi).zx_type_66, operand_164);
            }, .valid = (state_99).valid, .work = (state_99).work, };
        }

        var state_owned_166: []const *const (zx_abi).zx_type_32 = (&[_]*const (zx_abi).zx_type_32{});

        errdefer (allocator).free(state_owned_166);

        if (state_capacity_started_117) {
            ((state_capacity_116).items).len = (((((state_99).source).indexed).types).items).len;

            state_owned_166 = (try (state_capacity_116).toOwnedSlice(allocator));
        }

        if (state_capacity_started_117) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = block_172: {
                const operand_171 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_171).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_170: {
                    const operand_169 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_169).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_99).source).indexed).bytes, .declarations = (((state_99).source).indexed).declarations, .members = (((state_99).source).indexed).members, .order = (((state_99).source).indexed).order, .types = block_168: {
                        const operand_167 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_167).* = @as((zx_abi).zx_type_38, (zx_abi).zx_type_38{ .fields = ((((state_99).source).indexed).types).fields, .items = state_owned_166, .nodes = ((((state_99).source).indexed).types).nodes, });

                        break :block_168 @as(*const (zx_abi).zx_type_38, operand_167);
                    }, });

                    break :block_170 @as(*const (zx_abi).zx_type_64, operand_169);
                }, .native = ((state_99).source).native, });

                break :block_172 @as(*const (zx_abi).zx_type_66, operand_171);
            }, .valid = (state_99).valid, .work = (state_99).work, };
        }

        var state_owned_173: []const *const (zx_abi).zx_type_30 = (&[_]*const (zx_abi).zx_type_30{});

        errdefer (allocator).free(state_owned_173);

        if (state_capacity_started_119) {
            ((state_capacity_118).items).len = (((((state_99).source).indexed).types).nodes).len;

            state_owned_173 = (try (state_capacity_118).toOwnedSlice(allocator));
        }

        if (state_capacity_started_119) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = block_179: {
                const operand_178 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_178).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_177: {
                    const operand_176 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_176).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_99).source).indexed).bytes, .declarations = (((state_99).source).indexed).declarations, .members = (((state_99).source).indexed).members, .order = (((state_99).source).indexed).order, .types = block_175: {
                        const operand_174 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_174).* = @as((zx_abi).zx_type_38, (zx_abi).zx_type_38{ .fields = ((((state_99).source).indexed).types).fields, .items = ((((state_99).source).indexed).types).items, .nodes = state_owned_173, });

                        break :block_175 @as(*const (zx_abi).zx_type_38, operand_174);
                    }, });

                    break :block_177 @as(*const (zx_abi).zx_type_64, operand_176);
                }, .native = ((state_99).source).native, });

                break :block_179 @as(*const (zx_abi).zx_type_66, operand_178);
            }, .valid = (state_99).valid, .work = (state_99).work, };
        }

        var state_owned_180: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_180);

        if (state_capacity_started_121) {
            ((state_capacity_120).items).len = (((state_99).work).aliases).len;

            state_owned_180 = (try (state_capacity_120).toOwnedSlice(allocator));
        }

        if (state_capacity_started_121) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = (state_99).source, .valid = (state_99).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_180, .enumerations = ((state_99).work).enumerations, .nodes = ((state_99).work).nodes, }), };
        }

        var state_owned_181: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_181);

        if (state_capacity_started_123) {
            ((state_capacity_122).items).len = (((state_99).work).enumerations).len;

            state_owned_181 = (try (state_capacity_122).toOwnedSlice(allocator));
        }

        if (state_capacity_started_123) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = (state_99).source, .valid = (state_99).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_99).work).aliases, .enumerations = state_owned_181, .nodes = ((state_99).work).nodes, }), };
        }

        var state_owned_182: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_182);

        if (state_capacity_started_125) {
            ((state_capacity_124).items).len = (((state_99).work).nodes).len;

            state_owned_182 = (try (state_capacity_124).toOwnedSlice(allocator));
        }

        if (state_capacity_started_125) {
            state_99 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_99).names, .source = (state_99).source, .valid = (state_99).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_99).work).aliases, .enumerations = ((state_99).work).enumerations, .nodes = state_owned_182, }), };
        }

        break :block_184 (if (state_changed_101) state_99 else operand_100);
    };

    return block_98: {
        const operand_96 = (value_4).names;
        const operand_97 = (value_4).valid;

        break :block_98 @as((zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = operand_96, .valid = operand_97, });
    };
}

fn function_19_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
}) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_4: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = block_270: {
        const operand_189 = in;

        var state_capacity_191: (std).ArrayList(*const (zx_abi).zx_type_44) = .empty;

        var state_capacity_started_192 = false;

        defer (state_capacity_191).deinit(allocator);

        var state_capacity_193: (std).ArrayList(*const (zx_abi).zx_type_14) = .empty;

        var state_capacity_started_194 = false;

        defer (state_capacity_193).deinit(allocator);

        var state_capacity_195: (std).ArrayList(u64) = .empty;

        var state_capacity_started_196 = false;

        defer (state_capacity_195).deinit(allocator);

        var state_capacity_197: (std).ArrayList(u64) = .empty;

        var state_capacity_started_198 = false;

        defer (state_capacity_197).deinit(allocator);

        var state_capacity_199: (std).ArrayList(u64) = .empty;

        var state_capacity_started_200 = false;

        defer (state_capacity_199).deinit(allocator);

        var state_capacity_201: (std).ArrayList(*const (zx_abi).zx_type_31) = .empty;

        var state_capacity_started_202 = false;

        defer (state_capacity_201).deinit(allocator);

        var state_capacity_203: (std).ArrayList(*const (zx_abi).zx_type_32) = .empty;

        var state_capacity_started_204 = false;

        defer (state_capacity_203).deinit(allocator);

        var state_capacity_205: (std).ArrayList(*const (zx_abi).zx_type_30) = .empty;

        var state_capacity_started_206 = false;

        defer (state_capacity_205).deinit(allocator);

        var state_capacity_207: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_208 = false;

        defer (state_capacity_207).deinit(allocator);

        var state_capacity_209: (std).ArrayList(bool) = .empty;

        var state_capacity_started_210 = false;

        defer (state_capacity_209).deinit(allocator);

        var state_capacity_211: (std).ArrayList(u64) = .empty;

        var state_capacity_started_212 = false;

        defer (state_capacity_211).deinit(allocator);

        var state_188: (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002 = operand_189;

        var state_changed_190 = false;

        while (((state_188).valid and (@as(u64, (((state_188).work).nodes).len) != @as(u64, 0)))) {
            state_188 = @as((zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002, block_213: {
                break :block_213 (try function_18_buffered(allocator, state_188, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_2 = .{ .buffer = (&state_capacity_191), .started = (&state_capacity_started_192), }, .lane_3 = .{ .buffer = (&state_capacity_193), .started = (&state_capacity_started_194), }, .lane_4 = .{ .buffer = (&state_capacity_195), .started = (&state_capacity_started_196), }, .lane_5 = .{ .buffer = (&state_capacity_197), .started = (&state_capacity_started_198), }, .lane_6 = .{ .buffer = (&state_capacity_199), .started = (&state_capacity_started_200), }, .lane_7 = .{ .buffer = (&state_capacity_201), .started = (&state_capacity_started_202), }, .lane_8 = .{ .buffer = (&state_capacity_203), .started = (&state_capacity_started_204), }, .lane_9 = .{ .buffer = (&state_capacity_205), .started = (&state_capacity_started_206), }, .lane_10 = .{ .buffer = (&state_capacity_207), .started = (&state_capacity_started_208), }, .lane_11 = .{ .buffer = (&state_capacity_209), .started = (&state_capacity_started_210), }, .lane_12 = .{ .buffer = (&state_capacity_211), .started = (&state_capacity_started_212), }, }));
            });

            state_changed_190 = true;
        }

        var state_owned_214: []const *const (zx_abi).zx_type_44 = (&[_]*const (zx_abi).zx_type_44{});

        errdefer (allocator).free(state_owned_214);

        if (state_capacity_started_192) {
            ((state_capacity_191).items).len = ((((state_188).source).indexed).declarations).len;

            state_owned_214 = (try (state_capacity_191).toOwnedSlice(allocator));
        }

        if (state_capacity_started_192) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = block_218: {
                const operand_217 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_217).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_216: {
                    const operand_215 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_215).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_188).source).indexed).bytes, .declarations = state_owned_214, .members = (((state_188).source).indexed).members, .order = (((state_188).source).indexed).order, .types = (((state_188).source).indexed).types, });

                    break :block_216 @as(*const (zx_abi).zx_type_64, operand_215);
                }, .native = ((state_188).source).native, });

                break :block_218 @as(*const (zx_abi).zx_type_66, operand_217);
            }, .valid = (state_188).valid, .work = (state_188).work, };
        }

        var state_owned_219: []const *const (zx_abi).zx_type_14 = (&[_]*const (zx_abi).zx_type_14{});

        errdefer (allocator).free(state_owned_219);

        if (state_capacity_started_194) {
            ((state_capacity_193).items).len = ((((state_188).source).indexed).members).len;

            state_owned_219 = (try (state_capacity_193).toOwnedSlice(allocator));
        }

        if (state_capacity_started_194) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = block_223: {
                const operand_222 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_222).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_221: {
                    const operand_220 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_220).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_188).source).indexed).bytes, .declarations = (((state_188).source).indexed).declarations, .members = state_owned_219, .order = (((state_188).source).indexed).order, .types = (((state_188).source).indexed).types, });

                    break :block_221 @as(*const (zx_abi).zx_type_64, operand_220);
                }, .native = ((state_188).source).native, });

                break :block_223 @as(*const (zx_abi).zx_type_66, operand_222);
            }, .valid = (state_188).valid, .work = (state_188).work, };
        }

        var state_owned_224: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_224);

        if (state_capacity_started_196) {
            ((state_capacity_195).items).len = (((((state_188).source).indexed).order).fields).len;

            state_owned_224 = (try (state_capacity_195).toOwnedSlice(allocator));
        }

        if (state_capacity_started_196) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = block_230: {
                const operand_229 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_229).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_228: {
                    const operand_227 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_227).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_188).source).indexed).bytes, .declarations = (((state_188).source).indexed).declarations, .members = (((state_188).source).indexed).members, .order = block_226: {
                        const operand_225 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_225).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .fields = state_owned_224, .heads = ((((state_188).source).indexed).order).heads, .items = ((((state_188).source).indexed).order).items, });

                        break :block_226 @as(*const (zx_abi).zx_type_34, operand_225);
                    }, .types = (((state_188).source).indexed).types, });

                    break :block_228 @as(*const (zx_abi).zx_type_64, operand_227);
                }, .native = ((state_188).source).native, });

                break :block_230 @as(*const (zx_abi).zx_type_66, operand_229);
            }, .valid = (state_188).valid, .work = (state_188).work, };
        }

        var state_owned_231: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_231);

        if (state_capacity_started_198) {
            ((state_capacity_197).items).len = (((((state_188).source).indexed).order).heads).len;

            state_owned_231 = (try (state_capacity_197).toOwnedSlice(allocator));
        }

        if (state_capacity_started_198) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = block_237: {
                const operand_236 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_236).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_235: {
                    const operand_234 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_234).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_188).source).indexed).bytes, .declarations = (((state_188).source).indexed).declarations, .members = (((state_188).source).indexed).members, .order = block_233: {
                        const operand_232 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_232).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .fields = ((((state_188).source).indexed).order).fields, .heads = state_owned_231, .items = ((((state_188).source).indexed).order).items, });

                        break :block_233 @as(*const (zx_abi).zx_type_34, operand_232);
                    }, .types = (((state_188).source).indexed).types, });

                    break :block_235 @as(*const (zx_abi).zx_type_64, operand_234);
                }, .native = ((state_188).source).native, });

                break :block_237 @as(*const (zx_abi).zx_type_66, operand_236);
            }, .valid = (state_188).valid, .work = (state_188).work, };
        }

        var state_owned_238: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_238);

        if (state_capacity_started_200) {
            ((state_capacity_199).items).len = (((((state_188).source).indexed).order).items).len;

            state_owned_238 = (try (state_capacity_199).toOwnedSlice(allocator));
        }

        if (state_capacity_started_200) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = block_244: {
                const operand_243 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_243).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_242: {
                    const operand_241 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_241).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_188).source).indexed).bytes, .declarations = (((state_188).source).indexed).declarations, .members = (((state_188).source).indexed).members, .order = block_240: {
                        const operand_239 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_239).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .fields = ((((state_188).source).indexed).order).fields, .heads = ((((state_188).source).indexed).order).heads, .items = state_owned_238, });

                        break :block_240 @as(*const (zx_abi).zx_type_34, operand_239);
                    }, .types = (((state_188).source).indexed).types, });

                    break :block_242 @as(*const (zx_abi).zx_type_64, operand_241);
                }, .native = ((state_188).source).native, });

                break :block_244 @as(*const (zx_abi).zx_type_66, operand_243);
            }, .valid = (state_188).valid, .work = (state_188).work, };
        }

        var state_owned_245: []const *const (zx_abi).zx_type_31 = (&[_]*const (zx_abi).zx_type_31{});

        errdefer (allocator).free(state_owned_245);

        if (state_capacity_started_202) {
            ((state_capacity_201).items).len = (((((state_188).source).indexed).types).fields).len;

            state_owned_245 = (try (state_capacity_201).toOwnedSlice(allocator));
        }

        if (state_capacity_started_202) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = block_251: {
                const operand_250 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_250).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_249: {
                    const operand_248 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_248).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_188).source).indexed).bytes, .declarations = (((state_188).source).indexed).declarations, .members = (((state_188).source).indexed).members, .order = (((state_188).source).indexed).order, .types = block_247: {
                        const operand_246 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_246).* = @as((zx_abi).zx_type_38, (zx_abi).zx_type_38{ .fields = state_owned_245, .items = ((((state_188).source).indexed).types).items, .nodes = ((((state_188).source).indexed).types).nodes, });

                        break :block_247 @as(*const (zx_abi).zx_type_38, operand_246);
                    }, });

                    break :block_249 @as(*const (zx_abi).zx_type_64, operand_248);
                }, .native = ((state_188).source).native, });

                break :block_251 @as(*const (zx_abi).zx_type_66, operand_250);
            }, .valid = (state_188).valid, .work = (state_188).work, };
        }

        var state_owned_252: []const *const (zx_abi).zx_type_32 = (&[_]*const (zx_abi).zx_type_32{});

        errdefer (allocator).free(state_owned_252);

        if (state_capacity_started_204) {
            ((state_capacity_203).items).len = (((((state_188).source).indexed).types).items).len;

            state_owned_252 = (try (state_capacity_203).toOwnedSlice(allocator));
        }

        if (state_capacity_started_204) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = block_258: {
                const operand_257 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_257).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_256: {
                    const operand_255 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_255).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_188).source).indexed).bytes, .declarations = (((state_188).source).indexed).declarations, .members = (((state_188).source).indexed).members, .order = (((state_188).source).indexed).order, .types = block_254: {
                        const operand_253 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_253).* = @as((zx_abi).zx_type_38, (zx_abi).zx_type_38{ .fields = ((((state_188).source).indexed).types).fields, .items = state_owned_252, .nodes = ((((state_188).source).indexed).types).nodes, });

                        break :block_254 @as(*const (zx_abi).zx_type_38, operand_253);
                    }, });

                    break :block_256 @as(*const (zx_abi).zx_type_64, operand_255);
                }, .native = ((state_188).source).native, });

                break :block_258 @as(*const (zx_abi).zx_type_66, operand_257);
            }, .valid = (state_188).valid, .work = (state_188).work, };
        }

        var state_owned_259: []const *const (zx_abi).zx_type_30 = (&[_]*const (zx_abi).zx_type_30{});

        errdefer (allocator).free(state_owned_259);

        if (state_capacity_started_206) {
            ((state_capacity_205).items).len = (((((state_188).source).indexed).types).nodes).len;

            state_owned_259 = (try (state_capacity_205).toOwnedSlice(allocator));
        }

        if (state_capacity_started_206) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = block_265: {
                const operand_264 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_264).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .indexed = block_263: {
                    const operand_262 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_262).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .bytes = (((state_188).source).indexed).bytes, .declarations = (((state_188).source).indexed).declarations, .members = (((state_188).source).indexed).members, .order = (((state_188).source).indexed).order, .types = block_261: {
                        const operand_260 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_260).* = @as((zx_abi).zx_type_38, (zx_abi).zx_type_38{ .fields = ((((state_188).source).indexed).types).fields, .items = ((((state_188).source).indexed).types).items, .nodes = state_owned_259, });

                        break :block_261 @as(*const (zx_abi).zx_type_38, operand_260);
                    }, });

                    break :block_263 @as(*const (zx_abi).zx_type_64, operand_262);
                }, .native = ((state_188).source).native, });

                break :block_265 @as(*const (zx_abi).zx_type_66, operand_264);
            }, .valid = (state_188).valid, .work = (state_188).work, };
        }

        var state_owned_266: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_266);

        if (state_capacity_started_208) {
            ((state_capacity_207).items).len = (((state_188).work).aliases).len;

            state_owned_266 = (try (state_capacity_207).toOwnedSlice(allocator));
        }

        if (state_capacity_started_208) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = (state_188).source, .valid = (state_188).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_266, .enumerations = ((state_188).work).enumerations, .nodes = ((state_188).work).nodes, }), };
        }

        var state_owned_267: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_267);

        if (state_capacity_started_210) {
            ((state_capacity_209).items).len = (((state_188).work).enumerations).len;

            state_owned_267 = (try (state_capacity_209).toOwnedSlice(allocator));
        }

        if (state_capacity_started_210) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = (state_188).source, .valid = (state_188).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_188).work).aliases, .enumerations = state_owned_267, .nodes = ((state_188).work).nodes, }), };
        }

        var state_owned_268: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_268);

        if (state_capacity_started_212) {
            ((state_capacity_211).items).len = (((state_188).work).nodes).len;

            state_owned_268 = (try (state_capacity_211).toOwnedSlice(allocator));
        }

        if (state_capacity_started_212) {
            state_188 = (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (state_188).names, .source = (state_188).source, .valid = (state_188).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_188).work).aliases, .enumerations = ((state_188).work).enumerations, .nodes = state_owned_268, }), };
        }

        break :block_270 (if (state_changed_190) state_188 else operand_189);
    };

    return block_187: {
        const operand_185 = (value_4).names;
        const operand_186 = (value_4).valid;

        break :block_187 @as((zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = operand_185, .valid = operand_186, });
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_75) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_81 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: *const (zx_abi).zx_type_80 = block_12: {
        const operand_6 = in;
        const operand_7 = (try function_0_value(allocator, (zx_abi).value_zx_type_75_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (operand_6).count, .first = (operand_6).first, .parameters = (operand_6).parameters, .source = (operand_6).source, .zx_origin = operand_6, }));

        break :block_12 (if (((operand_7).zx_origin != null)) (operand_7).zx_origin.? else block_11: {
            const operand_10 = (try (allocator).create((zx_abi).zx_type_80));

            (operand_10).* = (zx_abi).zx_type_80{ .names = (operand_7).names, .source = (operand_7).source, .valid = (operand_7).valid, .work = (if ((((operand_7).work).zx_origin != null)) ((operand_7).work).zx_origin.? else block_9: {
                const operand_8 = (try (allocator).create((zx_abi).zx_type_79));

                (operand_8).* = (zx_abi).zx_type_79{ .aliases = ((operand_7).work).aliases, .enumerations = ((operand_7).work).enumerations, .nodes = ((operand_7).work).nodes, };

                break :block_9 @as(*const (zx_abi).zx_type_79, operand_8);
            }), };

            break :block_11 @as(*const (zx_abi).zx_type_80, operand_10);
        });
    };
    const value_2: *const (zx_abi).zx_type_81 = block_5: {
        const operand_1 = value_1;
        const operand_2 = (try function_19_value(allocator, (zx_abi).value_zx_type_80_091beb0cbabebaa353d11f5c9a23d3fe2a3e7841fbcd3b9274b5417f1632d002{ .names = (operand_1).names, .source = (operand_1).source, .valid = (operand_1).valid, .work = (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((operand_1).work).aliases, .enumerations = ((operand_1).work).enumerations, .nodes = ((operand_1).work).nodes, .zx_origin = (operand_1).work, }, .zx_origin = operand_1, }));

        break :block_5 (if (((operand_2).zx_origin != null)) (operand_2).zx_origin.? else block_4: {
            const operand_3 = (try (allocator).create((zx_abi).zx_type_81));

            (operand_3).* = (zx_abi).zx_type_81{ .names = (operand_2).names, .valid = (operand_2).valid, };

            break :block_4 @as(*const (zx_abi).zx_type_81, operand_3);
        });
    };

    return value_2;
}

