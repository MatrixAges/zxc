import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { createContext, Script } from 'node:vm'

const [upstream, candidate_path] = process.argv.slice(2)
const candidates = JSON.parse(readFileSync(candidate_path, 'utf8'))
const hash = value => createHash('sha256').update(value).digest('hex')
const harness = ['sta.js', 'assert.js'].map(name => ({ name, text: readFileSync(upstream + '/harness/' + name, 'utf8') }))
const executions = []

for (const candidate of candidates) {
    const text = readFileSync(upstream + '/' + candidate.path, 'utf8')

    if (hash(text) !== candidate.sha256) throw new Error('Original source changed: ' + candidate.path)

    for (const mode of ['sloppy', 'strict']) {
        const context = createContext({})

        for (const item of harness) new Script(item.text, { filename: 'harness/' + item.name }).runInContext(context)

        new Script((mode === 'strict' ? '"use strict";\n' : '') + text, { filename: candidate.path }).runInContext(context)
        executions.push({ path: candidate.path, sha256: candidate.sha256, mode, result: 'passed' })
    }
}

console.log(JSON.stringify({ executions, harness: harness.map(item => ({ path: 'harness/' + item.name, sha256: hash(item.text) })), unique_originals: candidates.length, original_assertions_per_mode: candidates.reduce((count, candidate) => count + candidate.original_assertions, 0) }, null, 4))
