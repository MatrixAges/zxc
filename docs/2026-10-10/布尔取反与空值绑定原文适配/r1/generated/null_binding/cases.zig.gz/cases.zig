const check = @import("support").check;

test "language/types/null/binding/original_completion" {
    try check(@import("program"), null, .{ .value = null });
}
