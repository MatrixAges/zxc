const std = @import("std");

pub const Input = ?u64;

pub const Output = ?u64;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .optional, .child = zx_shape_5, };

pub const input_shape = zx_shape_11;

pub const output_shape = zx_shape_11;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: ?u64) error{ }!?u64 {
    @setRuntimeSafety(true);

    _ = arena;

    _ = in;

    const value_1: ?u64 = @as(?u64, null);

    return value_1;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: ?u64) error{ }!?u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    _ = in;

    const value_1: ?u64 = @as(?u64, null);

    return value_1;
}

