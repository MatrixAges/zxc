const check = @import("support").check;

test "language/types/boolean/negation/original" {
    try check(@import("program"), false, .{ .value = &.{.strict_false = true, .abstract_false = true, .strict_true = true, .abstract_true = true, .negated_input = true} });
}

test "language/types/boolean/negation/true_control" {
    try check(@import("program"), true, .{ .value = &.{.strict_false = true, .abstract_false = true, .strict_true = true, .abstract_true = true, .negated_input = false} });
}
