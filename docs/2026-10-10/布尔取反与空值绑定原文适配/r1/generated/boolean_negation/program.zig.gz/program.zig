const std = @import("std");

const zx_type_11 = struct {
    abstract_false: bool,
    abstract_true: bool,
    negated_input: bool,
    strict_false: bool,
    strict_true: bool,
};

const value_zx_type_11_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    abstract_false: bool,
    abstract_true: bool,
    negated_input: bool,
    strict_false: bool,
    strict_true: bool,
    zx_origin: ?*const zx_type_11 = null,
};

pub const Input = bool;

pub const Output = *const zx_type_11;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .object, .fields = .{ .abstract_false = zx_shape_1, .abstract_true = zx_shape_1, .negated_input = zx_shape_1, .strict_false = zx_shape_1, .strict_true = zx_shape_1, }, };

pub const input_shape = zx_shape_1;

pub const output_shape = zx_shape_11;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: bool) error{ OutOfMemory, }!*const zx_type_11 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();

    return block_8: {
        const operand_1 = ((!false) == true);
        const operand_2 = ((!false) == true);
        const operand_3 = ((!true) == false);
        const operand_4 = ((!true) == false);
        const operand_5 = (!in);

        break :block_8 block_7: {
            const operand_6 = (try (allocator).create(zx_type_11));

            (operand_6).* = @as(zx_type_11, zx_type_11{ .strict_false = operand_1, .abstract_false = operand_2, .strict_true = operand_3, .abstract_true = operand_4, .negated_input = operand_5, });

            break :block_7 @as(*const zx_type_11, operand_6);
        };
    };
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: bool) error{ OutOfMemory, }!value_zx_type_11_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_14: {
        const operand_9 = ((!false) == true);
        const operand_10 = ((!false) == true);
        const operand_11 = ((!true) == false);
        const operand_12 = ((!true) == false);
        const operand_13 = (!in);

        break :block_14 @as(value_zx_type_11_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_11_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .strict_false = operand_9, .abstract_false = operand_10, .strict_true = operand_11, .abstract_true = operand_12, .negated_input = operand_13, });
    };
}

