const std = @import("std");

const zx_type_11 = struct {
    high: u8,
    low: u8,
    remaining: u8,
    valid: bool,
};

const zx_type_12 = struct {
    byte: u8,
    state: *const zx_type_11,
};

const zx_type_14 = enum { Root, Dead, UpperInput, UpperOutput, Underscore, Allocator, Async, Await, Break, Cancel, Case, Concurrent, Const, Declare, Default, Delete, Do, Else, Ensures, Enum, Export, False, For, From, Function, If, Import, In, Insert, Io, Let, Loop, Match, New, Next, Null, Process, QueryMany, QueryOne, Requires, Return, Store, Switch, Throw, Throws, Transaction, True, Try, Type, Update, Var, While, };

const zx_type_15 = enum { Identifier, Keyword, Number, String, Template, Punctuation, Eof, };

const zx_type_16 = enum { None, OpenBrace, CloseBrace, OpenParen, CloseParen, OpenBracket, CloseBracket, Colon, Semicolon, Comma, Dot, Question, Plus, Minus, Star, Slash, Percent, Less, Greater, Assign, Not, Ampersand, Pipe, Arrow, Equal, NotEqual, LessEqual, GreaterEqual, Coalesce, And, Or, Spread, };

const zx_type_17 = struct {
    end: u64,
    start: u64,
};

const zx_type_18 = struct {
    dollar: bool,
    kind: zx_type_15,
    line_break: bool,
    span: *const zx_type_17,
    symbol: zx_type_16,
    word: zx_type_14,
};

const zx_type_19 = enum { Integer, FractionStart, Fraction, ExponentStart, ExponentDigits, Done, };

const zx_type_20 = struct {
    end: u64,
    last_byte: u8,
    phase: zx_type_19,
    separators_valid: bool,
};

const zx_type_21 = struct {
    diagnostic: []const u8,
    end: u64,
};

const zx_type_22 = enum { Idle, Identifier, Number, String, StringEscape, LineComment, BlockComment, Template, TemplateEscape, Interpolation, InterpolationString, InterpolationStringEscape, InterpolationLineComment, InterpolationBlockComment, };

const zx_type_23 = struct {
    code: []const u8,
    end: u64,
    message: []const u8,
    start: u64,
};

const zx_type_24 = struct {
    braces: u64,
    depth: u64,
    mode: zx_type_22,
    start: u64,
};

const zx_type_28 = struct {
    ahead_one: u8,
    ahead_two: u8,
    braces: u64,
    comments: []const *const zx_type_17,
    depth: u64,
    diagnostic: *const zx_type_23,
    dollar: bool,
    frames: []const *const zx_type_24,
    keyword_state: u64,
    line_break: bool,
    mode: zx_type_22,
    number: *const zx_type_20,
    offset: u64,
    skip_until: u64,
    source_length: u64,
    start: u64,
    symbol: zx_type_16,
    tokens: []const *const zx_type_18,
    warmed: u8,
};

const zx_type_29 = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    state: *const zx_type_28,
};

const zx_type_30 = struct {
    comments: []const *const zx_type_17,
    diagnostic: *const zx_type_23,
    tokens: []const *const zx_type_18,
};

const zx_type_31 = struct {
    comment: bool,
    end: u64,
    kind: []const u8,
    start: u64,
    state: *const zx_type_28,
};

const zx_type_32 = struct {
    code: []const u8,
    end: u64,
    message: []const u8,
    start: u64,
    state: *const zx_type_28,
};

const zx_type_33 = struct {
    byte: u8,
    state: u64,
};

const zx_type_34 = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
};

const zx_type_35 = struct {
    byte: u8,
    length: u64,
    next: u8,
};

const zx_type_36 = struct {
    byte: u8,
    state: *const zx_type_20,
};

const zx_type_37 = struct {
    byte: u8,
    state: *const zx_type_28,
};

const zx_type_38 = struct {
    source: []const u8,
    state: *const zx_type_28,
};

const zx_type_39 = struct {
    index: u64,
    result: *const zx_type_11,
    source: []const u8,
};

const zx_type_40 = struct { []const *const zx_type_17, void, };

const zx_type_41 = struct { []const *const zx_type_18, void, };

const zx_type_42 = struct { []const *const zx_type_24, void, };

const zx_type_44 = struct { []const *const zx_type_24, ?*const zx_type_24, };

const zx_type_45 = struct {
    index: u64,
    result: *const zx_type_28,
    source: []const u8,
};

const zx_type_46 = struct { []const u8, };

const zx_type_47 = struct { []const u8, bool, };

const zx_type_48 = struct { []const u8, bool, *const zx_type_28, };

const zx_type_49 = struct { []const u8, bool, *const zx_type_28, *const zx_type_28, };

const zx_type_50 = struct { []const u8, bool, *const zx_type_28, *const zx_type_28, *const zx_type_28, };

const zx_type_51 = struct { []const u8, bool, *const zx_type_28, *const zx_type_28, *const zx_type_28, *const zx_type_28, };

const zx_type_52 = struct { []const u8, bool, *const zx_type_28, *const zx_type_28, *const zx_type_28, *const zx_type_28, *const zx_type_30, };

const zx_type_53 = struct { []const u8, bool, *const zx_type_30, };

const value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    high: u8,
    low: u8,
    remaining: u8,
    valid: bool,
    zx_origin: ?*const zx_type_11 = null,
};

const value_zx_type_12_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = struct {
    byte: u8,
    state: value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    end: u64,
    last_byte: u8,
    phase: zx_type_19,
    separators_valid: bool,
    zx_origin: ?*const zx_type_20 = null,
};

const value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    diagnostic: []const u8,
    end: u64,
    zx_origin: ?*const zx_type_21 = null,
};

const value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    code: []const u8,
    end: u64,
    message: []const u8,
    start: u64,
    zx_origin: ?*const zx_type_23 = null,
};

const value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = struct {
    ahead_one: u8,
    ahead_two: u8,
    braces: u64,
    comments: []const *const zx_type_17,
    depth: u64,
    diagnostic: value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    dollar: bool,
    frames: []const *const zx_type_24,
    keyword_state: u64,
    line_break: bool,
    mode: zx_type_22,
    number: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    offset: u64,
    skip_until: u64,
    source_length: u64,
    start: u64,
    symbol: zx_type_16,
    tokens: []const *const zx_type_18,
    warmed: u8,
    zx_origin: ?*const zx_type_28 = null,
};

const value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    state: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955,
    zx_origin: ?*const zx_type_29 = null,
};

const value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = struct {
    comments: []const *const zx_type_17,
    diagnostic: value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    tokens: []const *const zx_type_18,
    zx_origin: ?*const zx_type_30 = null,
};

const value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b = struct {
    comment: bool,
    end: u64,
    kind: []const u8,
    start: u64,
    state: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955,
    zx_origin: ?*const zx_type_31 = null,
};

const value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b = struct {
    code: []const u8,
    end: u64,
    message: []const u8,
    start: u64,
    state: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955,
    zx_origin: ?*const zx_type_32 = null,
};

const value_zx_type_33_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    byte: u8,
    state: u64,
    zx_origin: ?*const zx_type_33 = null,
};

const value_zx_type_34_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    zx_origin: ?*const zx_type_34 = null,
};

const value_zx_type_35_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    byte: u8,
    length: u64,
    next: u8,
    zx_origin: ?*const zx_type_35 = null,
};

const value_zx_type_36_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = struct {
    byte: u8,
    state: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_36 = null,
};

const value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b = struct {
    byte: u8,
    state: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955,
    zx_origin: ?*const zx_type_37 = null,
};

const value_zx_type_38_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b = struct {
    source: []const u8,
    state: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955,
    zx_origin: ?*const zx_type_38 = null,
};

const value_zx_type_39_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = struct {
    index: u64,
    result: value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    source: []const u8,
    zx_origin: ?*const zx_type_39 = null,
};

const value_zx_type_40_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_17, void, ?*const zx_type_40, };

const value_zx_type_41_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_18, void, ?*const zx_type_41, };

const value_zx_type_42_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_24, void, ?*const zx_type_42, };

const value_zx_type_44_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_24, ?*const zx_type_24, ?*const zx_type_44, };

const value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512 = struct {
    index: u64,
    result: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955,
    source: []const u8,
    zx_origin: ?*const zx_type_45 = null,
};

const value_zx_type_46_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = struct { []const u8, ?*const zx_type_46, };

const value_zx_type_47_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, bool, ?*const zx_type_47, };

const value_zx_type_48_1c81afa37bd48fe2363fa6489308f39d53c6b8f757991878c72e6b3ab8a79b02 = struct { []const u8, bool, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, ?*const zx_type_48, };

const value_zx_type_49_a19e70c84272c6d7a8068547735a394edbc53829f5ad083209029ef0007f3274 = struct { []const u8, bool, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, ?*const zx_type_49, };

const value_zx_type_50_b68934cc0d3ed598e71433b374eb90d49c19dc0aa3bf65481c8083cd87a18b1b = struct { []const u8, bool, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, ?*const zx_type_50, };

const value_zx_type_51_ebc2867745d305bac999b03a2ea4f44dd978af9c83476feee087a4760309d456 = struct { []const u8, bool, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, ?*const zx_type_51, };

const value_zx_type_52_e73420fe2ab16aae3c006b7494851f2135cde9ac636816c1e1a21a912b332260 = struct { []const u8, bool, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb, ?*const zx_type_52, };

const value_zx_type_53_bd952e13421deed3c1e9a612c65e48706d2509b52cfd652c33b74a284c0547fc = struct { []const u8, bool, value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb, ?*const zx_type_53, };

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .object, .fields = .{ .high = zx_shape_2, .low = zx_shape_2, .remaining = zx_shape_2, .valid = zx_shape_1, }, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .byte = zx_shape_2, .state = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_14 = .{ .kind = .scalar, };

const zx_shape_15 = .{ .kind = .scalar, };

const zx_shape_16 = .{ .kind = .scalar, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .end = zx_shape_5, .start = zx_shape_5, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .dollar = zx_shape_1, .kind = zx_shape_15, .line_break = zx_shape_1, .span = zx_shape_17, .symbol = zx_shape_16, .word = zx_shape_14, }, };

const zx_shape_19 = .{ .kind = .scalar, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .end = zx_shape_5, .last_byte = zx_shape_2, .phase = zx_shape_19, .separators_valid = zx_shape_1, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .diagnostic = zx_shape_10, .end = zx_shape_5, }, };

const zx_shape_22 = .{ .kind = .scalar, };

const zx_shape_23 = .{ .kind = .object, .fields = .{ .code = zx_shape_10, .end = zx_shape_5, .message = zx_shape_10, .start = zx_shape_5, }, };

const zx_shape_24 = .{ .kind = .object, .fields = .{ .braces = zx_shape_5, .depth = zx_shape_5, .mode = zx_shape_22, .start = zx_shape_5, }, };

const zx_shape_25 = .{ .kind = .list, .child = zx_shape_24, };

const zx_shape_26 = .{ .kind = .list, .child = zx_shape_18, };

const zx_shape_27 = .{ .kind = .list, .child = zx_shape_17, };

const zx_shape_28 = .{ .kind = .object, .fields = .{ .ahead_one = zx_shape_2, .ahead_two = zx_shape_2, .braces = zx_shape_5, .comments = zx_shape_27, .depth = zx_shape_5, .diagnostic = zx_shape_23, .dollar = zx_shape_1, .frames = zx_shape_25, .keyword_state = zx_shape_5, .line_break = zx_shape_1, .mode = zx_shape_22, .number = zx_shape_20, .offset = zx_shape_5, .skip_until = zx_shape_5, .source_length = zx_shape_5, .start = zx_shape_5, .symbol = zx_shape_16, .tokens = zx_shape_26, .warmed = zx_shape_2, }, };

const zx_shape_29 = .{ .kind = .object, .fields = .{ .after = zx_shape_2, .byte = zx_shape_2, .has_after = zx_shape_1, .has_next = zx_shape_1, .next = zx_shape_2, .state = zx_shape_28, }, };

const zx_shape_30 = .{ .kind = .object, .fields = .{ .comments = zx_shape_27, .diagnostic = zx_shape_23, .tokens = zx_shape_26, }, };

const zx_shape_31 = .{ .kind = .object, .fields = .{ .comment = zx_shape_1, .end = zx_shape_5, .kind = zx_shape_10, .start = zx_shape_5, .state = zx_shape_28, }, };

const zx_shape_32 = .{ .kind = .object, .fields = .{ .code = zx_shape_10, .end = zx_shape_5, .message = zx_shape_10, .start = zx_shape_5, .state = zx_shape_28, }, };

const zx_shape_33 = .{ .kind = .object, .fields = .{ .byte = zx_shape_2, .state = zx_shape_5, }, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .after = zx_shape_2, .byte = zx_shape_2, .has_after = zx_shape_1, .has_next = zx_shape_1, .next = zx_shape_2, }, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .byte = zx_shape_2, .length = zx_shape_5, .next = zx_shape_2, }, };

const zx_shape_36 = .{ .kind = .object, .fields = .{ .byte = zx_shape_2, .state = zx_shape_20, }, };

const zx_shape_37 = .{ .kind = .object, .fields = .{ .byte = zx_shape_2, .state = zx_shape_28, }, };

const zx_shape_38 = .{ .kind = .object, .fields = .{ .source = zx_shape_13, .state = zx_shape_28, }, };

const zx_shape_39 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_11, .source = zx_shape_13, }, };

const zx_shape_40 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_27, .@"1" = zx_shape_0, }, };

const zx_shape_41 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_26, .@"1" = zx_shape_0, }, };

const zx_shape_42 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_25, .@"1" = zx_shape_0, }, };

const zx_shape_43 = .{ .kind = .optional, .child = zx_shape_24, };

const zx_shape_44 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_25, .@"1" = zx_shape_43, }, };

const zx_shape_45 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_28, .source = zx_shape_13, }, };

const zx_shape_46 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_13, }, };

const zx_shape_47 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_13, .@"1" = zx_shape_1, }, };

const zx_shape_48 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_13, .@"1" = zx_shape_1, .@"2" = zx_shape_28, }, };

const zx_shape_49 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_13, .@"1" = zx_shape_1, .@"2" = zx_shape_28, .@"3" = zx_shape_28, }, };

const zx_shape_50 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_13, .@"1" = zx_shape_1, .@"2" = zx_shape_28, .@"3" = zx_shape_28, .@"4" = zx_shape_28, }, };

const zx_shape_51 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_13, .@"1" = zx_shape_1, .@"2" = zx_shape_28, .@"3" = zx_shape_28, .@"4" = zx_shape_28, .@"5" = zx_shape_28, }, };

const zx_shape_52 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_13, .@"1" = zx_shape_1, .@"2" = zx_shape_28, .@"3" = zx_shape_28, .@"4" = zx_shape_28, .@"5" = zx_shape_28, .@"6" = zx_shape_30, }, };

const zx_shape_53 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_13, .@"1" = zx_shape_1, .@"2" = zx_shape_30, }, };

pub const input_shape = zx_shape_13;

pub const output_shape = zx_shape_30;

pub const Input = []const u8;

pub const Output = *const zx_type_30;

fn function_0(allocator: ((std).mem).Allocator, in: *const zx_type_12) error{ OutOfMemory, }!*const zx_type_11 {
    @setRuntimeSafety(true);

    if ((!((in).state).valid)) {
        return (in).state;
    }

    if ((((in).state).remaining > @as(u8, 0))) {
        return block_33: {
            const operand_27 = (((in).byte >= ((in).state).low) and ((in).byte <= ((in).state).high));
            const operand_28 = (((in).state).remaining - @as(u8, 1));
            const operand_29 = @as(u8, 128);
            const operand_30 = @as(u8, 191);

            break :block_33 block_32: {
                const operand_31 = (try (allocator).create(zx_type_11));

                (operand_31).* = @as(zx_type_11, zx_type_11{ .valid = operand_27, .remaining = operand_28, .low = operand_29, .high = operand_30, });

                break :block_32 @as(*const zx_type_11, operand_31);
            };
        };
    }

    if (((in).byte < @as(u8, 128))) {
        return (in).state;
    }

    if ((((in).byte >= @as(u8, 194)) and ((in).byte <= @as(u8, 223)))) {
        return block_26: {
            const operand_20 = true;
            const operand_21 = @as(u8, 1);
            const operand_22 = @as(u8, 128);
            const operand_23 = @as(u8, 191);

            break :block_26 block_25: {
                const operand_24 = (try (allocator).create(zx_type_11));

                (operand_24).* = @as(zx_type_11, zx_type_11{ .valid = operand_20, .remaining = operand_21, .low = operand_22, .high = operand_23, });

                break :block_25 @as(*const zx_type_11, operand_24);
            };
        };
    }

    if ((((in).byte >= @as(u8, 224)) and ((in).byte <= @as(u8, 239)))) {
        return block_19: {
            const operand_13 = true;
            const operand_14 = @as(u8, 2);
            const operand_15 = (if (((in).byte == @as(u8, 224))) @as(u8, 160) else @as(u8, 128));
            const operand_16 = (if (((in).byte == @as(u8, 237))) @as(u8, 159) else @as(u8, 191));

            break :block_19 block_18: {
                const operand_17 = (try (allocator).create(zx_type_11));

                (operand_17).* = @as(zx_type_11, zx_type_11{ .valid = operand_13, .remaining = operand_14, .low = operand_15, .high = operand_16, });

                break :block_18 @as(*const zx_type_11, operand_17);
            };
        };
    }

    if ((((in).byte >= @as(u8, 240)) and ((in).byte <= @as(u8, 244)))) {
        return block_12: {
            const operand_6 = true;
            const operand_7 = @as(u8, 3);
            const operand_8 = (if (((in).byte == @as(u8, 240))) @as(u8, 144) else @as(u8, 128));
            const operand_9 = (if (((in).byte == @as(u8, 244))) @as(u8, 143) else @as(u8, 191));

            break :block_12 block_11: {
                const operand_10 = (try (allocator).create(zx_type_11));

                (operand_10).* = @as(zx_type_11, zx_type_11{ .valid = operand_6, .remaining = operand_7, .low = operand_8, .high = operand_9, });

                break :block_11 @as(*const zx_type_11, operand_10);
            };
        };
    }

    return block_5: {
        const operand_1 = (in).state;
        const operand_2 = false;

        break :block_5 block_4: {
            const operand_3 = (try (allocator).create(zx_type_11));

            (operand_3).* = @as(zx_type_11, zx_type_11{ .high = (operand_1).high, .low = (operand_1).low, .remaining = (operand_1).remaining, .valid = operand_2, });

            break :block_4 @as(*const zx_type_11, operand_3);
        };
    };
}

fn function_0_value(allocator: ((std).mem).Allocator, in: value_zx_type_12_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b) error{ OutOfMemory, }!value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    _ = allocator;

    if ((!((in).state).valid)) {
        return (in).state;
    }

    if ((((in).state).remaining > @as(u8, 0))) {
        return block_56: {
            const operand_52 = (((in).byte >= ((in).state).low) and ((in).byte <= ((in).state).high));
            const operand_53 = (((in).state).remaining - @as(u8, 1));
            const operand_54 = @as(u8, 128);
            const operand_55 = @as(u8, 191);

            break :block_56 @as(value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .valid = operand_52, .remaining = operand_53, .low = operand_54, .high = operand_55, });
        };
    }

    if (((in).byte < @as(u8, 128))) {
        return (in).state;
    }

    if ((((in).byte >= @as(u8, 194)) and ((in).byte <= @as(u8, 223)))) {
        return block_51: {
            const operand_47 = true;
            const operand_48 = @as(u8, 1);
            const operand_49 = @as(u8, 128);
            const operand_50 = @as(u8, 191);

            break :block_51 @as(value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .valid = operand_47, .remaining = operand_48, .low = operand_49, .high = operand_50, });
        };
    }

    if ((((in).byte >= @as(u8, 224)) and ((in).byte <= @as(u8, 239)))) {
        return block_46: {
            const operand_42 = true;
            const operand_43 = @as(u8, 2);
            const operand_44 = (if (((in).byte == @as(u8, 224))) @as(u8, 160) else @as(u8, 128));
            const operand_45 = (if (((in).byte == @as(u8, 237))) @as(u8, 159) else @as(u8, 191));

            break :block_46 @as(value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .valid = operand_42, .remaining = operand_43, .low = operand_44, .high = operand_45, });
        };
    }

    if ((((in).byte >= @as(u8, 240)) and ((in).byte <= @as(u8, 244)))) {
        return block_41: {
            const operand_37 = true;
            const operand_38 = @as(u8, 3);
            const operand_39 = (if (((in).byte == @as(u8, 240))) @as(u8, 144) else @as(u8, 128));
            const operand_40 = (if (((in).byte == @as(u8, 244))) @as(u8, 143) else @as(u8, 191));

            break :block_41 @as(value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .valid = operand_37, .remaining = operand_38, .low = operand_39, .high = operand_40, });
        };
    }

    return block_36: {
        const operand_34 = (in).state;
        const operand_35 = false;

        break :block_36 @as(value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .high = (operand_34).high, .low = (operand_34).low, .remaining = (operand_34).remaining, .valid = operand_35, });
    };
}

fn function_1(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: zx_type_11 = block_31: {
        const operand_27 = true;
        const operand_28 = @as(u8, 0);
        const operand_29 = @as(u8, 128);
        const operand_30 = @as(u8, 191);

        break :block_31 zx_type_11{ .valid = operand_27, .remaining = operand_28, .low = operand_29, .high = operand_30, };
    };
    const value_10: zx_type_11 = block_26: {
        const value_4: []const u8 = in;
        const value_9: zx_type_39 = block_25: {
            const operand_6 = block_5: {
                const operand_2 = value_4;
                const operand_3 = @as(u64, 0);
                const operand_4 = (&value_1);

                break :block_5 zx_type_39{ .index = operand_3, .result = operand_4, .source = operand_2, };
            };

            var state_1: value_zx_type_39_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = value_zx_type_39_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb{ .index = (operand_6).index, .result = value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .high = ((operand_6).result).high, .low = ((operand_6).result).low, .remaining = ((operand_6).result).remaining, .valid = ((operand_6).result).valid, .zx_origin = (operand_6).result, }, .source = (operand_6).source, .zx_origin = (&operand_6), };

            while (((state_1).index < @as(u64, ((state_1).source).len))) {
                state_1 = block_20: {
                    const value_7: u8 = block_19: {
                        const operand_17 = (state_1).source;
                        const operand_18 = (state_1).index;

                        if ((operand_18 >= (operand_17).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_19 (operand_17)[@intCast(operand_18)];
                    };
                    const value_2: value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (state_1).result;
                    const value_3: u8 = block_16: {
                        break :block_16 value_7;
                    };
                    const value_8: value_zx_type_11_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_15: {
                        break :block_15 (try function_0_value(allocator, block_14: {
                            const operand_11 = block_12: {
                                break :block_12 value_3;
                            };
                            const operand_13 = value_2;

                            break :block_14 @as(value_zx_type_12_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b, value_zx_type_12_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b{ .byte = operand_11, .state = operand_13, });
                        }));
                    };

                    break :block_20 block_10: {
                        const operand_7 = (state_1).source;
                        const operand_8 = ((state_1).index + @as(u64, 1));
                        const operand_9 = value_8;

                        break :block_10 @as(value_zx_type_39_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb, value_zx_type_39_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb{ .index = operand_8, .result = operand_9, .source = operand_7, });
                    };
                };
            }

            break :block_25 block_24: {
                break :block_24 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_23: {
                    break :block_23 zx_type_39{ .index = (state_1).index, .result = (if ((((state_1).result).zx_origin != null)) ((state_1).result).zx_origin.? else block_22: {
                        const operand_21 = (try (allocator).create(zx_type_11));

                        (operand_21).* = zx_type_11{ .high = ((state_1).result).high, .low = ((state_1).result).low, .remaining = ((state_1).result).remaining, .valid = ((state_1).result).valid, };

                        break :block_22 @as(*const zx_type_11, operand_21);
                    }), .source = (state_1).source, };
                });
            };
        };

        break :block_26 (((&value_9)).result).*;
    };

    return (((&value_10)).valid and (((&value_10)).remaining == @as(u8, 0)));
}

fn function_2(allocator: ((std).mem).Allocator, in: *const zx_type_17) error{ OutOfMemory, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: []const *const zx_type_18 = block_39: {
        break :block_39 (try (allocator).dupe(*const zx_type_18, (&[_]*const zx_type_18{})));
    };
    const value_2: []const *const zx_type_17 = block_38: {
        break :block_38 (try (allocator).dupe(*const zx_type_17, (&[_]*const zx_type_17{})));
    };
    const value_3: []const *const zx_type_24 = block_37: {
        break :block_37 (try (allocator).dupe(*const zx_type_24, (&[_]*const zx_type_24{})));
    };

    return block_36: {
        const operand_1 = (in).end;
        const operand_2 = @as(u8, 0);
        const operand_3 = @as(u8, 0);
        const operand_4 = @as(u8, 0);
        const operand_5 = @as(u64, 0);
        const operand_6 = @as(zx_type_16, .None);
        const operand_7 = false;
        const operand_8 = false;
        const operand_9 = (in).start;
        const operand_10 = (in).start;
        const operand_11 = @as(zx_type_22, .Idle);
        const operand_12 = (in).start;
        const operand_13 = @as(u64, 0);
        const operand_14 = @as(u64, 0);
        const operand_15 = value_3;
        const operand_16 = block_23: {
            const operand_17 = @as(u64, 0);
            const operand_18 = @as(zx_type_19, .Integer);
            const operand_19 = @as(u8, 0);
            const operand_20 = true;

            break :block_23 block_22: {
                const operand_21 = (try (allocator).create(zx_type_20));

                (operand_21).* = @as(zx_type_20, zx_type_20{ .end = operand_17, .phase = operand_18, .last_byte = operand_19, .separators_valid = operand_20, });

                break :block_22 @as(*const zx_type_20, operand_21);
            };
        };
        const operand_24 = value_1;
        const operand_25 = value_2;
        const operand_26 = block_33: {
            const operand_27 = @as([]const u8, "");
            const operand_28 = @as(u64, 0);
            const operand_29 = @as(u64, 0);
            const operand_30 = @as([]const u8, "");

            break :block_33 block_32: {
                const operand_31 = (try (allocator).create(zx_type_23));

                (operand_31).* = @as(zx_type_23, zx_type_23{ .code = operand_27, .start = operand_28, .end = operand_29, .message = operand_30, });

                break :block_32 @as(*const zx_type_23, operand_31);
            };
        };

        break :block_36 block_35: {
            const operand_34 = (try (allocator).create(zx_type_28));

            (operand_34).* = @as(zx_type_28, zx_type_28{ .source_length = operand_1, .warmed = operand_2, .ahead_one = operand_3, .ahead_two = operand_4, .keyword_state = operand_5, .symbol = operand_6, .line_break = operand_7, .dollar = operand_8, .offset = operand_9, .skip_until = operand_10, .mode = operand_11, .start = operand_12, .braces = operand_13, .depth = operand_14, .frames = operand_15, .number = operand_16, .tokens = operand_24, .comments = operand_25, .diagnostic = operand_26, });

            break :block_35 @as(*const zx_type_28, operand_34);
        };
    };
}

fn function_2_value(allocator: ((std).mem).Allocator, in: *const zx_type_17) error{ OutOfMemory, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: []const *const zx_type_18 = block_75: {
        break :block_75 (try (allocator).dupe(*const zx_type_18, (&[_]*const zx_type_18{})));
    };
    const value_2: []const *const zx_type_17 = block_74: {
        break :block_74 (try (allocator).dupe(*const zx_type_17, (&[_]*const zx_type_17{})));
    };
    const value_3: []const *const zx_type_24 = block_73: {
        break :block_73 (try (allocator).dupe(*const zx_type_24, (&[_]*const zx_type_24{})));
    };

    return block_72: {
        const operand_40 = (in).end;
        const operand_41 = @as(u8, 0);
        const operand_42 = @as(u8, 0);
        const operand_43 = @as(u8, 0);
        const operand_44 = @as(u64, 0);
        const operand_45 = @as(zx_type_16, .None);
        const operand_46 = false;
        const operand_47 = false;
        const operand_48 = (in).start;
        const operand_49 = (in).start;
        const operand_50 = @as(zx_type_22, .Idle);
        const operand_51 = (in).start;
        const operand_52 = @as(u64, 0);
        const operand_53 = @as(u64, 0);
        const operand_54 = block_55: {
            break :block_55 value_3;
        };
        const operand_56 = block_61: {
            const operand_57 = @as(u64, 0);
            const operand_58 = @as(zx_type_19, .Integer);
            const operand_59 = @as(u8, 0);
            const operand_60 = true;

            break :block_61 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = operand_57, .phase = operand_58, .last_byte = operand_59, .separators_valid = operand_60, });
        };
        const operand_62 = block_63: {
            break :block_63 value_1;
        };
        const operand_64 = block_65: {
            break :block_65 value_2;
        };
        const operand_66 = block_71: {
            const operand_67 = @as([]const u8, "");
            const operand_68 = @as(u64, 0);
            const operand_69 = @as(u64, 0);
            const operand_70 = @as([]const u8, "");

            break :block_71 @as(value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = operand_67, .start = operand_68, .end = operand_69, .message = operand_70, });
        };

        break :block_72 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_40, .warmed = operand_41, .ahead_one = operand_42, .ahead_two = operand_43, .keyword_state = operand_44, .symbol = operand_45, .line_break = operand_46, .dollar = operand_47, .offset = operand_48, .skip_until = operand_49, .mode = operand_50, .start = operand_51, .braces = operand_52, .depth = operand_53, .frames = operand_54, .number = operand_56, .tokens = operand_62, .comments = operand_64, .diagnostic = operand_66, });
    };
}

fn function_3(allocator: ((std).mem).Allocator, in: u64) error{ }!zx_type_14 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = in;

    if ((switch_1 == @as(u64, 0))) {
        return @as(zx_type_14, .Root);
    } else {
        if ((switch_1 == @as(u64, 6))) {
            return @as(zx_type_14, .UpperInput);
        } else {
            if ((switch_1 == @as(u64, 12))) {
                return @as(zx_type_14, .UpperOutput);
            } else {
                if ((switch_1 == @as(u64, 13))) {
                    return @as(zx_type_14, .Underscore);
                } else {
                    if ((switch_1 == @as(u64, 22))) {
                        return @as(zx_type_14, .Allocator);
                    } else {
                        if ((switch_1 == @as(u64, 26))) {
                            return @as(zx_type_14, .Async);
                        } else {
                            if ((switch_1 == @as(u64, 30))) {
                                return @as(zx_type_14, .Await);
                            } else {
                                if ((switch_1 == @as(u64, 35))) {
                                    return @as(zx_type_14, .Break);
                                } else {
                                    if ((switch_1 == @as(u64, 41))) {
                                        return @as(zx_type_14, .Cancel);
                                    } else {
                                        if ((switch_1 == @as(u64, 43))) {
                                            return @as(zx_type_14, .Case);
                                        } else {
                                            if ((switch_1 == @as(u64, 52))) {
                                                return @as(zx_type_14, .Concurrent);
                                            } else {
                                                if ((switch_1 == @as(u64, 54))) {
                                                    return @as(zx_type_14, .Const);
                                                } else {
                                                    if ((switch_1 == @as(u64, 61))) {
                                                        return @as(zx_type_14, .Declare);
                                                    } else {
                                                        if ((switch_1 == @as(u64, 66))) {
                                                            return @as(zx_type_14, .Default);
                                                        } else {
                                                            if ((switch_1 == @as(u64, 70))) {
                                                                return @as(zx_type_14, .Delete);
                                                            } else {
                                                                if ((switch_1 == @as(u64, 71))) {
                                                                    return @as(zx_type_14, .Do);
                                                                } else {
                                                                    if ((switch_1 == @as(u64, 75))) {
                                                                        return @as(zx_type_14, .Else);
                                                                    } else {
                                                                        if ((switch_1 == @as(u64, 81))) {
                                                                            return @as(zx_type_14, .Ensures);
                                                                        } else {
                                                                            if ((switch_1 == @as(u64, 83))) {
                                                                                return @as(zx_type_14, .Enum);
                                                                            } else {
                                                                                if ((switch_1 == @as(u64, 88))) {
                                                                                    return @as(zx_type_14, .Export);
                                                                                } else {
                                                                                    if ((switch_1 == @as(u64, 93))) {
                                                                                        return @as(zx_type_14, .False);
                                                                                    } else {
                                                                                        if ((switch_1 == @as(u64, 95))) {
                                                                                            return @as(zx_type_14, .For);
                                                                                        } else {
                                                                                            if ((switch_1 == @as(u64, 98))) {
                                                                                                return @as(zx_type_14, .From);
                                                                                            } else {
                                                                                                if ((switch_1 == @as(u64, 105))) {
                                                                                                    return @as(zx_type_14, .Function);
                                                                                                } else {
                                                                                                    if ((switch_1 == @as(u64, 107))) {
                                                                                                        return @as(zx_type_14, .If);
                                                                                                    } else {
                                                                                                        if ((switch_1 == @as(u64, 112))) {
                                                                                                            return @as(zx_type_14, .Import);
                                                                                                        } else {
                                                                                                            if ((switch_1 == @as(u64, 113))) {
                                                                                                                return @as(zx_type_14, .In);
                                                                                                            } else {
                                                                                                                if ((switch_1 == @as(u64, 117))) {
                                                                                                                    return @as(zx_type_14, .Insert);
                                                                                                                } else {
                                                                                                                    if ((switch_1 == @as(u64, 118))) {
                                                                                                                        return @as(zx_type_14, .Io);
                                                                                                                    } else {
                                                                                                                        if ((switch_1 == @as(u64, 121))) {
                                                                                                                            return @as(zx_type_14, .Let);
                                                                                                                        } else {
                                                                                                                            if ((switch_1 == @as(u64, 124))) {
                                                                                                                                return @as(zx_type_14, .Loop);
                                                                                                                            } else {
                                                                                                                                if ((switch_1 == @as(u64, 129))) {
                                                                                                                                    return @as(zx_type_14, .Match);
                                                                                                                                } else {
                                                                                                                                    if ((switch_1 == @as(u64, 132))) {
                                                                                                                                        return @as(zx_type_14, .New);
                                                                                                                                    } else {
                                                                                                                                        if ((switch_1 == @as(u64, 134))) {
                                                                                                                                            return @as(zx_type_14, .Next);
                                                                                                                                        } else {
                                                                                                                                            if ((switch_1 == @as(u64, 137))) {
                                                                                                                                                return @as(zx_type_14, .Null);
                                                                                                                                            } else {
                                                                                                                                                if ((switch_1 == @as(u64, 144))) {
                                                                                                                                                    return @as(zx_type_14, .Process);
                                                                                                                                                } else {
                                                                                                                                                    if ((switch_1 == @as(u64, 153))) {
                                                                                                                                                        return @as(zx_type_14, .QueryMany);
                                                                                                                                                    } else {
                                                                                                                                                        if ((switch_1 == @as(u64, 156))) {
                                                                                                                                                            return @as(zx_type_14, .QueryOne);
                                                                                                                                                        } else {
                                                                                                                                                            if ((switch_1 == @as(u64, 164))) {
                                                                                                                                                                return @as(zx_type_14, .Requires);
                                                                                                                                                            } else {
                                                                                                                                                                if ((switch_1 == @as(u64, 168))) {
                                                                                                                                                                    return @as(zx_type_14, .Return);
                                                                                                                                                                } else {
                                                                                                                                                                    if ((switch_1 == @as(u64, 173))) {
                                                                                                                                                                        return @as(zx_type_14, .Store);
                                                                                                                                                                    } else {
                                                                                                                                                                        if ((switch_1 == @as(u64, 178))) {
                                                                                                                                                                            return @as(zx_type_14, .Switch);
                                                                                                                                                                        } else {
                                                                                                                                                                            if ((switch_1 == @as(u64, 183))) {
                                                                                                                                                                                return @as(zx_type_14, .Throw);
                                                                                                                                                                            } else {
                                                                                                                                                                                if ((switch_1 == @as(u64, 184))) {
                                                                                                                                                                                    return @as(zx_type_14, .Throws);
                                                                                                                                                                                } else {
                                                                                                                                                                                    if ((switch_1 == @as(u64, 194))) {
                                                                                                                                                                                        return @as(zx_type_14, .Transaction);
                                                                                                                                                                                    } else {
                                                                                                                                                                                        if ((switch_1 == @as(u64, 196))) {
                                                                                                                                                                                            return @as(zx_type_14, .True);
                                                                                                                                                                                        } else {
                                                                                                                                                                                            if ((switch_1 == @as(u64, 197))) {
                                                                                                                                                                                                return @as(zx_type_14, .Try);
                                                                                                                                                                                            } else {
                                                                                                                                                                                                if ((switch_1 == @as(u64, 200))) {
                                                                                                                                                                                                    return @as(zx_type_14, .Type);
                                                                                                                                                                                                } else {
                                                                                                                                                                                                    if ((switch_1 == @as(u64, 206))) {
                                                                                                                                                                                                        return @as(zx_type_14, .Update);
                                                                                                                                                                                                    } else {
                                                                                                                                                                                                        if ((switch_1 == @as(u64, 209))) {
                                                                                                                                                                                                            return @as(zx_type_14, .Var);
                                                                                                                                                                                                        } else {
                                                                                                                                                                                                            if ((switch_1 == @as(u64, 214))) {
                                                                                                                                                                                                                return @as(zx_type_14, .While);
                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                return @as(zx_type_14, .Dead);
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }
                                                                                                                                                                                                    }
                                                                                                                                                                                                }
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_4(allocator: ((std).mem).Allocator, in: []const u8) error{ }!zx_type_15 {
    @setRuntimeSafety(true);

    _ = allocator;

    return (if (block_18: {
        const operand_16 = in;
        const operand_17 = @as([]const u8, "identifier");

        break :block_18 ((std).mem).eql(u8, operand_16, operand_17);
    }) @as(zx_type_15, .Identifier) else (if (block_15: {
        const operand_13 = in;
        const operand_14 = @as([]const u8, "keyword");

        break :block_15 ((std).mem).eql(u8, operand_13, operand_14);
    }) @as(zx_type_15, .Keyword) else (if (block_12: {
        const operand_10 = in;
        const operand_11 = @as([]const u8, "number");

        break :block_12 ((std).mem).eql(u8, operand_10, operand_11);
    }) @as(zx_type_15, .Number) else (if (block_9: {
        const operand_7 = in;
        const operand_8 = @as([]const u8, "string");

        break :block_9 ((std).mem).eql(u8, operand_7, operand_8);
    }) @as(zx_type_15, .String) else (if (block_6: {
        const operand_4 = in;
        const operand_5 = @as([]const u8, "template");

        break :block_6 ((std).mem).eql(u8, operand_4, operand_5);
    }) @as(zx_type_15, .Template) else (if (block_3: {
        const operand_1 = in;
        const operand_2 = @as([]const u8, "punctuation");

        break :block_3 ((std).mem).eql(u8, operand_1, operand_2);
    }) @as(zx_type_15, .Punctuation) else @as(zx_type_15, .Eof)))))));
}

fn function_5(allocator: ((std).mem).Allocator, in: *const zx_type_31) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: *const zx_type_17 = block_72: {
        const operand_68 = (in).start;
        const operand_69 = (in).end;

        break :block_72 block_71: {
            const operand_70 = (try (allocator).create(zx_type_17));

            (operand_70).* = @as(zx_type_17, zx_type_17{ .start = operand_68, .end = operand_69, });

            break :block_71 @as(*const zx_type_17, operand_70);
        };
    };

    if ((in).comment) {
        return block_67: {
            const operand_42 = ((in).state).source_length;
            const operand_43 = ((in).state).warmed;
            const operand_44 = ((in).state).ahead_one;
            const operand_45 = ((in).state).ahead_two;
            const operand_46 = ((in).state).keyword_state;
            const operand_47 = ((in).state).symbol;
            const operand_48 = ((in).state).line_break;
            const operand_49 = ((in).state).dollar;
            const operand_50 = ((in).state).offset;
            const operand_51 = ((in).state).skip_until;
            const operand_52 = ((in).state).mode;
            const operand_53 = ((in).state).start;
            const operand_54 = ((in).state).braces;
            const operand_55 = ((in).state).depth;
            const operand_56 = ((in).state).frames;
            const operand_57 = ((in).state).number;
            const operand_58 = ((in).state).tokens;
            const operand_59 = (block_63: {
                const operand_60 = ((in).state).comments;
                const operand_61 = value_1;
                const operand_62 = (try (allocator).alloc(*const zx_type_17, (try ((std).math).add(usize, (operand_60).len, 1))));

                @memcpy((operand_62)[0..(operand_60).len], operand_60);

                (operand_62)[(operand_60).len] = operand_61;

                break :block_63 @as(zx_type_40, .{ operand_62, {}, });
            }).@"0";
            const operand_64 = ((in).state).diagnostic;

            break :block_67 block_66: {
                const operand_65 = (try (allocator).create(zx_type_28));

                (operand_65).* = @as(zx_type_28, zx_type_28{ .source_length = operand_42, .warmed = operand_43, .ahead_one = operand_44, .ahead_two = operand_45, .keyword_state = operand_46, .symbol = operand_47, .line_break = operand_48, .dollar = operand_49, .offset = operand_50, .skip_until = operand_51, .mode = operand_52, .start = operand_53, .braces = operand_54, .depth = operand_55, .frames = operand_56, .number = operand_57, .tokens = operand_58, .comments = operand_59, .diagnostic = operand_64, });

                break :block_66 @as(*const zx_type_28, operand_65);
            };
        };
    }

    const value_2: zx_type_14 = (if ((block_38: {
        const operand_36 = (in).kind;
        const operand_37 = @as([]const u8, "identifier");

        break :block_38 ((std).mem).eql(u8, operand_36, operand_37);
    } or block_41: {
        const operand_39 = (in).kind;
        const operand_40 = @as([]const u8, "keyword");

        break :block_41 ((std).mem).eql(u8, operand_39, operand_40);
    })) (try function_3(allocator, ((in).state).keyword_state)) else @as(zx_type_14, .Root));
    const value_3: zx_type_15 = (try function_4(allocator, (in).kind));
    const value_4: *const zx_type_18 = block_35: {
        const operand_27 = value_3;
        const operand_28 = value_2;
        const operand_29 = ((in).state).symbol;
        const operand_30 = value_1;
        const operand_31 = ((@as(u64, (((in).state).tokens).len) != @as(u64, 0)) and ((in).state).line_break);
        const operand_32 = ((in).state).dollar;

        break :block_35 block_34: {
            const operand_33 = (try (allocator).create(zx_type_18));

            (operand_33).* = @as(zx_type_18, zx_type_18{ .kind = operand_27, .word = operand_28, .symbol = operand_29, .span = operand_30, .line_break = operand_31, .dollar = operand_32, });

            break :block_34 @as(*const zx_type_18, operand_33);
        };
    };

    return block_26: {
        const operand_1 = ((in).state).source_length;
        const operand_2 = ((in).state).warmed;
        const operand_3 = ((in).state).ahead_one;
        const operand_4 = ((in).state).ahead_two;
        const operand_5 = ((in).state).keyword_state;
        const operand_6 = @as(zx_type_16, .None);
        const operand_7 = false;
        const operand_8 = false;
        const operand_9 = ((in).state).offset;
        const operand_10 = ((in).state).skip_until;
        const operand_11 = ((in).state).mode;
        const operand_12 = ((in).state).start;
        const operand_13 = ((in).state).braces;
        const operand_14 = ((in).state).depth;
        const operand_15 = ((in).state).frames;
        const operand_16 = ((in).state).number;
        const operand_17 = (block_21: {
            const operand_18 = ((in).state).tokens;
            const operand_19 = value_4;
            const operand_20 = (try (allocator).alloc(*const zx_type_18, (try ((std).math).add(usize, (operand_18).len, 1))));

            @memcpy((operand_20)[0..(operand_18).len], operand_18);

            (operand_20)[(operand_18).len] = operand_19;

            break :block_21 @as(zx_type_41, .{ operand_20, {}, });
        }).@"0";
        const operand_22 = ((in).state).comments;
        const operand_23 = ((in).state).diagnostic;

        break :block_26 block_25: {
            const operand_24 = (try (allocator).create(zx_type_28));

            (operand_24).* = @as(zx_type_28, zx_type_28{ .source_length = operand_1, .warmed = operand_2, .ahead_one = operand_3, .ahead_two = operand_4, .keyword_state = operand_5, .symbol = operand_6, .line_break = operand_7, .dollar = operand_8, .offset = operand_9, .skip_until = operand_10, .mode = operand_11, .start = operand_12, .braces = operand_13, .depth = operand_14, .frames = operand_15, .number = operand_16, .tokens = operand_17, .comments = operand_22, .diagnostic = operand_23, });

            break :block_25 @as(*const zx_type_28, operand_24);
        };
    };
}

fn function_5_value(allocator: ((std).mem).Allocator, in: value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: *const zx_type_17 = block_145: {
        const operand_141 = (in).start;
        const operand_142 = (in).end;

        break :block_145 block_144: {
            const operand_143 = (try (allocator).create(zx_type_17));

            (operand_143).* = @as(zx_type_17, zx_type_17{ .start = operand_141, .end = operand_142, });

            break :block_144 @as(*const zx_type_17, operand_143);
        };
    };

    if ((in).comment) {
        return block_140: {
            const operand_116 = ((in).state).source_length;
            const operand_117 = ((in).state).warmed;
            const operand_118 = ((in).state).ahead_one;
            const operand_119 = ((in).state).ahead_two;
            const operand_120 = ((in).state).keyword_state;
            const operand_121 = ((in).state).symbol;
            const operand_122 = ((in).state).line_break;
            const operand_123 = ((in).state).dollar;
            const operand_124 = ((in).state).offset;
            const operand_125 = ((in).state).skip_until;
            const operand_126 = ((in).state).mode;
            const operand_127 = ((in).state).start;
            const operand_128 = ((in).state).braces;
            const operand_129 = ((in).state).depth;
            const operand_130 = ((in).state).frames;
            const operand_131 = ((in).state).number;
            const operand_132 = ((in).state).tokens;
            const operand_133 = (block_138: {
                const operand_134 = ((in).state).comments;
                const operand_136 = block_135: {
                    break :block_135 value_1;
                };
                const operand_137 = (try (allocator).alloc(*const zx_type_17, (try ((std).math).add(usize, (operand_134).len, 1))));

                @memcpy((operand_137)[0..(operand_134).len], operand_134);

                (operand_137)[(operand_134).len] = operand_136;

                break :block_138 @as(value_zx_type_40_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_137, {}, null, });
            }).@"0";
            const operand_139 = ((in).state).diagnostic;

            break :block_140 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_116, .warmed = operand_117, .ahead_one = operand_118, .ahead_two = operand_119, .keyword_state = operand_120, .symbol = operand_121, .line_break = operand_122, .dollar = operand_123, .offset = operand_124, .skip_until = operand_125, .mode = operand_126, .start = operand_127, .braces = operand_128, .depth = operand_129, .frames = operand_130, .number = operand_131, .tokens = operand_132, .comments = operand_133, .diagnostic = operand_139, });
        };
    }

    const value_2: zx_type_14 = (if ((block_112: {
        const operand_110 = (in).kind;
        const operand_111 = @as([]const u8, "identifier");

        break :block_112 ((std).mem).eql(u8, operand_110, operand_111);
    } or block_115: {
        const operand_113 = (in).kind;
        const operand_114 = @as([]const u8, "keyword");

        break :block_115 ((std).mem).eql(u8, operand_113, operand_114);
    })) (try function_3(allocator, ((in).state).keyword_state)) else @as(zx_type_14, .Root));
    const value_3: zx_type_15 = (try function_4(allocator, (in).kind));
    const value_4: *const zx_type_18 = block_109: {
        const operand_98 = block_99: {
            break :block_99 value_3;
        };
        const operand_100 = block_101: {
            break :block_101 value_2;
        };
        const operand_102 = ((in).state).symbol;
        const operand_103 = block_104: {
            break :block_104 value_1;
        };
        const operand_105 = ((@as(u64, (((in).state).tokens).len) != @as(u64, 0)) and ((in).state).line_break);
        const operand_106 = ((in).state).dollar;

        break :block_109 block_108: {
            const operand_107 = (try (allocator).create(zx_type_18));

            (operand_107).* = @as(zx_type_18, zx_type_18{ .kind = operand_98, .word = operand_100, .symbol = operand_102, .span = operand_103, .line_break = operand_105, .dollar = operand_106, });

            break :block_108 @as(*const zx_type_18, operand_107);
        };
    };

    return block_97: {
        const operand_73 = ((in).state).source_length;
        const operand_74 = ((in).state).warmed;
        const operand_75 = ((in).state).ahead_one;
        const operand_76 = ((in).state).ahead_two;
        const operand_77 = ((in).state).keyword_state;
        const operand_78 = @as(zx_type_16, .None);
        const operand_79 = false;
        const operand_80 = false;
        const operand_81 = ((in).state).offset;
        const operand_82 = ((in).state).skip_until;
        const operand_83 = ((in).state).mode;
        const operand_84 = ((in).state).start;
        const operand_85 = ((in).state).braces;
        const operand_86 = ((in).state).depth;
        const operand_87 = ((in).state).frames;
        const operand_88 = ((in).state).number;
        const operand_89 = (block_94: {
            const operand_90 = ((in).state).tokens;
            const operand_92 = block_91: {
                break :block_91 value_4;
            };
            const operand_93 = (try (allocator).alloc(*const zx_type_18, (try ((std).math).add(usize, (operand_90).len, 1))));

            @memcpy((operand_93)[0..(operand_90).len], operand_90);

            (operand_93)[(operand_90).len] = operand_92;

            break :block_94 @as(value_zx_type_41_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_93, {}, null, });
        }).@"0";
        const operand_95 = ((in).state).comments;
        const operand_96 = ((in).state).diagnostic;

        break :block_97 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_73, .warmed = operand_74, .ahead_one = operand_75, .ahead_two = operand_76, .keyword_state = operand_77, .symbol = operand_78, .line_break = operand_79, .dollar = operand_80, .offset = operand_81, .skip_until = operand_82, .mode = operand_83, .start = operand_84, .braces = operand_85, .depth = operand_86, .frames = operand_87, .number = operand_88, .tokens = operand_89, .comments = operand_95, .diagnostic = operand_96, });
    };
}

fn function_5_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: *const zx_type_17 = block_226: {
        const operand_222 = (in).start;
        const operand_223 = (in).end;

        break :block_226 block_225: {
            const operand_224 = (try (allocator).create(zx_type_17));

            (operand_224).* = @as(zx_type_17, zx_type_17{ .start = operand_222, .end = operand_223, });

            break :block_225 @as(*const zx_type_17, operand_224);
        };
    };

    if ((in).comment) {
        return block_221: {
            const operand_193 = ((in).state).source_length;
            const operand_194 = ((in).state).warmed;
            const operand_195 = ((in).state).ahead_one;
            const operand_196 = ((in).state).ahead_two;
            const operand_197 = ((in).state).keyword_state;
            const operand_198 = ((in).state).symbol;
            const operand_199 = ((in).state).line_break;
            const operand_200 = ((in).state).dollar;
            const operand_201 = ((in).state).offset;
            const operand_202 = ((in).state).skip_until;
            const operand_203 = ((in).state).mode;
            const operand_204 = ((in).state).start;
            const operand_205 = ((in).state).braces;
            const operand_206 = ((in).state).depth;
            const operand_207 = ((in).state).frames;
            const operand_208 = ((in).state).number;
            const operand_209 = ((in).state).tokens;
            const operand_210 = @as([]const *const zx_type_17, (if (((buffers).lane_0 != null)) block_214: {
                const operand_211 = ((in).state).comments;
                const operand_213 = block_212: {
                    break :block_212 value_1;
                };

                _ = (try ((std).math).add(usize, (operand_211).len, 1));

                if ((!(((buffers).lane_0.?).started).*)) {
                    (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_211));

                    (((buffers).lane_0.?).started).* = true;
                } else {
                    (((((buffers).lane_0.?).buffer).*).items).len = (operand_211).len;
                }

                (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_213));

                break :block_214 ((((buffers).lane_0.?).buffer).*).items;
            } else (block_219: {
                const operand_215 = ((in).state).comments;
                const operand_217 = block_216: {
                    break :block_216 value_1;
                };
                const operand_218 = (try (allocator).alloc(*const zx_type_17, (try ((std).math).add(usize, (operand_215).len, 1))));

                @memcpy((operand_218)[0..(operand_215).len], operand_215);

                (operand_218)[(operand_215).len] = operand_217;

                break :block_219 @as(value_zx_type_40_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_218, {}, null, });
            }).@"0"));
            const operand_220 = ((in).state).diagnostic;

            break :block_221 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_193, .warmed = operand_194, .ahead_one = operand_195, .ahead_two = operand_196, .keyword_state = operand_197, .symbol = operand_198, .line_break = operand_199, .dollar = operand_200, .offset = operand_201, .skip_until = operand_202, .mode = operand_203, .start = operand_204, .braces = operand_205, .depth = operand_206, .frames = operand_207, .number = operand_208, .tokens = operand_209, .comments = operand_210, .diagnostic = operand_220, });
        };
    }

    const value_2: zx_type_14 = (if ((block_189: {
        const operand_187 = (in).kind;
        const operand_188 = @as([]const u8, "identifier");

        break :block_189 ((std).mem).eql(u8, operand_187, operand_188);
    } or block_192: {
        const operand_190 = (in).kind;
        const operand_191 = @as([]const u8, "keyword");

        break :block_192 ((std).mem).eql(u8, operand_190, operand_191);
    })) (try function_3(allocator, ((in).state).keyword_state)) else @as(zx_type_14, .Root));
    const value_3: zx_type_15 = (try function_4(allocator, (in).kind));
    const value_4: *const zx_type_18 = block_186: {
        const operand_175 = block_176: {
            break :block_176 value_3;
        };
        const operand_177 = block_178: {
            break :block_178 value_2;
        };
        const operand_179 = ((in).state).symbol;
        const operand_180 = block_181: {
            break :block_181 value_1;
        };
        const operand_182 = ((@as(u64, (((in).state).tokens).len) != @as(u64, 0)) and ((in).state).line_break);
        const operand_183 = ((in).state).dollar;

        break :block_186 block_185: {
            const operand_184 = (try (allocator).create(zx_type_18));

            (operand_184).* = @as(zx_type_18, zx_type_18{ .kind = operand_175, .word = operand_177, .symbol = operand_179, .span = operand_180, .line_break = operand_182, .dollar = operand_183, });

            break :block_185 @as(*const zx_type_18, operand_184);
        };
    };

    return block_174: {
        const operand_146 = ((in).state).source_length;
        const operand_147 = ((in).state).warmed;
        const operand_148 = ((in).state).ahead_one;
        const operand_149 = ((in).state).ahead_two;
        const operand_150 = ((in).state).keyword_state;
        const operand_151 = @as(zx_type_16, .None);
        const operand_152 = false;
        const operand_153 = false;
        const operand_154 = ((in).state).offset;
        const operand_155 = ((in).state).skip_until;
        const operand_156 = ((in).state).mode;
        const operand_157 = ((in).state).start;
        const operand_158 = ((in).state).braces;
        const operand_159 = ((in).state).depth;
        const operand_160 = ((in).state).frames;
        const operand_161 = ((in).state).number;
        const operand_162 = @as([]const *const zx_type_18, (if (((buffers).lane_2 != null)) block_166: {
            const operand_163 = ((in).state).tokens;
            const operand_165 = block_164: {
                break :block_164 value_4;
            };

            _ = (try ((std).math).add(usize, (operand_163).len, 1));

            if ((!(((buffers).lane_2.?).started).*)) {
                (try ((((buffers).lane_2.?).buffer).*).appendSlice(allocator, operand_163));

                (((buffers).lane_2.?).started).* = true;
            } else {
                (((((buffers).lane_2.?).buffer).*).items).len = (operand_163).len;
            }

            (try ((((buffers).lane_2.?).buffer).*).append(allocator, operand_165));

            break :block_166 ((((buffers).lane_2.?).buffer).*).items;
        } else (block_171: {
            const operand_167 = ((in).state).tokens;
            const operand_169 = block_168: {
                break :block_168 value_4;
            };
            const operand_170 = (try (allocator).alloc(*const zx_type_18, (try ((std).math).add(usize, (operand_167).len, 1))));

            @memcpy((operand_170)[0..(operand_167).len], operand_167);

            (operand_170)[(operand_167).len] = operand_169;

            break :block_171 @as(value_zx_type_41_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_170, {}, null, });
        }).@"0"));
        const operand_172 = ((in).state).comments;
        const operand_173 = ((in).state).diagnostic;

        break :block_174 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_146, .warmed = operand_147, .ahead_one = operand_148, .ahead_two = operand_149, .keyword_state = operand_150, .symbol = operand_151, .line_break = operand_152, .dollar = operand_153, .offset = operand_154, .skip_until = operand_155, .mode = operand_156, .start = operand_157, .braces = operand_158, .depth = operand_159, .frames = operand_160, .number = operand_161, .tokens = operand_162, .comments = operand_172, .diagnostic = operand_173, });
    };
}

fn function_5_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_31, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: *const zx_type_17 = block_304: {
        const operand_300 = (in).start;
        const operand_301 = (in).end;

        break :block_304 block_303: {
            const operand_302 = (try (allocator).create(zx_type_17));

            (operand_302).* = @as(zx_type_17, zx_type_17{ .start = operand_300, .end = operand_301, });

            break :block_303 @as(*const zx_type_17, operand_302);
        };
    };

    if ((in).comment) {
        return block_299: {
            const operand_271 = ((in).state).source_length;
            const operand_272 = ((in).state).warmed;
            const operand_273 = ((in).state).ahead_one;
            const operand_274 = ((in).state).ahead_two;
            const operand_275 = ((in).state).keyword_state;
            const operand_276 = ((in).state).symbol;
            const operand_277 = ((in).state).line_break;
            const operand_278 = ((in).state).dollar;
            const operand_279 = ((in).state).offset;
            const operand_280 = ((in).state).skip_until;
            const operand_281 = ((in).state).mode;
            const operand_282 = ((in).state).start;
            const operand_283 = ((in).state).braces;
            const operand_284 = ((in).state).depth;
            const operand_285 = ((in).state).frames;
            const operand_286 = ((in).state).number;
            const operand_287 = ((in).state).tokens;
            const operand_288 = @as([]const *const zx_type_17, (if (((buffers).lane_0 != null)) block_291: {
                const operand_289 = ((in).state).comments;
                const operand_290 = value_1;

                _ = (try ((std).math).add(usize, (operand_289).len, 1));

                if ((!(((buffers).lane_0.?).started).*)) {
                    (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_289));

                    (((buffers).lane_0.?).started).* = true;
                } else {
                    (((((buffers).lane_0.?).buffer).*).items).len = (operand_289).len;
                }

                (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_290));

                break :block_291 ((((buffers).lane_0.?).buffer).*).items;
            } else (block_295: {
                const operand_292 = ((in).state).comments;
                const operand_293 = value_1;
                const operand_294 = (try (allocator).alloc(*const zx_type_17, (try ((std).math).add(usize, (operand_292).len, 1))));

                @memcpy((operand_294)[0..(operand_292).len], operand_292);

                (operand_294)[(operand_292).len] = operand_293;

                break :block_295 @as(zx_type_40, .{ operand_294, {}, });
            }).@"0"));
            const operand_296 = ((in).state).diagnostic;

            break :block_299 block_298: {
                const operand_297 = (try (allocator).create(zx_type_28));

                (operand_297).* = @as(zx_type_28, zx_type_28{ .source_length = operand_271, .warmed = operand_272, .ahead_one = operand_273, .ahead_two = operand_274, .keyword_state = operand_275, .symbol = operand_276, .line_break = operand_277, .dollar = operand_278, .offset = operand_279, .skip_until = operand_280, .mode = operand_281, .start = operand_282, .braces = operand_283, .depth = operand_284, .frames = operand_285, .number = operand_286, .tokens = operand_287, .comments = operand_288, .diagnostic = operand_296, });

                break :block_298 @as(*const zx_type_28, operand_297);
            };
        };
    }

    const value_2: zx_type_14 = (if ((block_267: {
        const operand_265 = (in).kind;
        const operand_266 = @as([]const u8, "identifier");

        break :block_267 ((std).mem).eql(u8, operand_265, operand_266);
    } or block_270: {
        const operand_268 = (in).kind;
        const operand_269 = @as([]const u8, "keyword");

        break :block_270 ((std).mem).eql(u8, operand_268, operand_269);
    })) (try function_3(allocator, ((in).state).keyword_state)) else @as(zx_type_14, .Root));
    const value_3: zx_type_15 = (try function_4(allocator, (in).kind));
    const value_4: *const zx_type_18 = block_264: {
        const operand_256 = value_3;
        const operand_257 = value_2;
        const operand_258 = ((in).state).symbol;
        const operand_259 = value_1;
        const operand_260 = ((@as(u64, (((in).state).tokens).len) != @as(u64, 0)) and ((in).state).line_break);
        const operand_261 = ((in).state).dollar;

        break :block_264 block_263: {
            const operand_262 = (try (allocator).create(zx_type_18));

            (operand_262).* = @as(zx_type_18, zx_type_18{ .kind = operand_256, .word = operand_257, .symbol = operand_258, .span = operand_259, .line_break = operand_260, .dollar = operand_261, });

            break :block_263 @as(*const zx_type_18, operand_262);
        };
    };

    return block_255: {
        const operand_227 = ((in).state).source_length;
        const operand_228 = ((in).state).warmed;
        const operand_229 = ((in).state).ahead_one;
        const operand_230 = ((in).state).ahead_two;
        const operand_231 = ((in).state).keyword_state;
        const operand_232 = @as(zx_type_16, .None);
        const operand_233 = false;
        const operand_234 = false;
        const operand_235 = ((in).state).offset;
        const operand_236 = ((in).state).skip_until;
        const operand_237 = ((in).state).mode;
        const operand_238 = ((in).state).start;
        const operand_239 = ((in).state).braces;
        const operand_240 = ((in).state).depth;
        const operand_241 = ((in).state).frames;
        const operand_242 = ((in).state).number;
        const operand_243 = @as([]const *const zx_type_18, (if (((buffers).lane_2 != null)) block_246: {
            const operand_244 = ((in).state).tokens;
            const operand_245 = value_4;

            _ = (try ((std).math).add(usize, (operand_244).len, 1));

            if ((!(((buffers).lane_2.?).started).*)) {
                (try ((((buffers).lane_2.?).buffer).*).appendSlice(allocator, operand_244));

                (((buffers).lane_2.?).started).* = true;
            } else {
                (((((buffers).lane_2.?).buffer).*).items).len = (operand_244).len;
            }

            (try ((((buffers).lane_2.?).buffer).*).append(allocator, operand_245));

            break :block_246 ((((buffers).lane_2.?).buffer).*).items;
        } else (block_250: {
            const operand_247 = ((in).state).tokens;
            const operand_248 = value_4;
            const operand_249 = (try (allocator).alloc(*const zx_type_18, (try ((std).math).add(usize, (operand_247).len, 1))));

            @memcpy((operand_249)[0..(operand_247).len], operand_247);

            (operand_249)[(operand_247).len] = operand_248;

            break :block_250 @as(zx_type_41, .{ operand_249, {}, });
        }).@"0"));
        const operand_251 = ((in).state).comments;
        const operand_252 = ((in).state).diagnostic;

        break :block_255 block_254: {
            const operand_253 = (try (allocator).create(zx_type_28));

            (operand_253).* = @as(zx_type_28, zx_type_28{ .source_length = operand_227, .warmed = operand_228, .ahead_one = operand_229, .ahead_two = operand_230, .keyword_state = operand_231, .symbol = operand_232, .line_break = operand_233, .dollar = operand_234, .offset = operand_235, .skip_until = operand_236, .mode = operand_237, .start = operand_238, .braces = operand_239, .depth = operand_240, .frames = operand_241, .number = operand_242, .tokens = operand_243, .comments = operand_251, .diagnostic = operand_252, });

            break :block_254 @as(*const zx_type_28, operand_253);
        };
    };
}

fn function_6(allocator: ((std).mem).Allocator, in: *const zx_type_32) error{ OutOfMemory, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    return block_12: {
        const operand_1 = (in).state;
        const operand_2 = block_9: {
            const operand_3 = (in).code;
            const operand_4 = (in).start;
            const operand_5 = (in).end;
            const operand_6 = (in).message;

            break :block_9 block_8: {
                const operand_7 = (try (allocator).create(zx_type_23));

                (operand_7).* = @as(zx_type_23, zx_type_23{ .code = operand_3, .start = operand_4, .end = operand_5, .message = operand_6, });

                break :block_8 @as(*const zx_type_23, operand_7);
            };
        };

        break :block_12 block_11: {
            const operand_10 = (try (allocator).create(zx_type_28));

            (operand_10).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_1).ahead_one, .ahead_two = (operand_1).ahead_two, .braces = (operand_1).braces, .comments = (operand_1).comments, .depth = (operand_1).depth, .diagnostic = operand_2, .dollar = (operand_1).dollar, .frames = (operand_1).frames, .keyword_state = (operand_1).keyword_state, .line_break = (operand_1).line_break, .mode = (operand_1).mode, .number = (operand_1).number, .offset = (operand_1).offset, .skip_until = (operand_1).skip_until, .source_length = (operand_1).source_length, .start = (operand_1).start, .symbol = (operand_1).symbol, .tokens = (operand_1).tokens, .warmed = (operand_1).warmed, });

            break :block_11 @as(*const zx_type_28, operand_10);
        };
    };
}

fn function_6_value(allocator: ((std).mem).Allocator, in: value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b) error{ OutOfMemory, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_20: {
        const operand_13 = (in).state;
        const operand_14 = block_19: {
            const operand_15 = (in).code;
            const operand_16 = (in).start;
            const operand_17 = (in).end;
            const operand_18 = (in).message;

            break :block_19 @as(value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = operand_15, .start = operand_16, .end = operand_17, .message = operand_18, });
        };

        break :block_20 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_13).ahead_one, .ahead_two = (operand_13).ahead_two, .braces = (operand_13).braces, .comments = (operand_13).comments, .depth = (operand_13).depth, .diagnostic = operand_14, .dollar = (operand_13).dollar, .frames = (operand_13).frames, .keyword_state = (operand_13).keyword_state, .line_break = (operand_13).line_break, .mode = (operand_13).mode, .number = (operand_13).number, .offset = (operand_13).offset, .skip_until = (operand_13).skip_until, .source_length = (operand_13).source_length, .start = (operand_13).start, .symbol = (operand_13).symbol, .tokens = (operand_13).tokens, .warmed = (operand_13).warmed, });
    };
}

fn function_6_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    _ = allocator;

    _ = buffers;

    return block_28: {
        const operand_21 = (in).state;
        const operand_22 = block_27: {
            const operand_23 = (in).code;
            const operand_24 = (in).start;
            const operand_25 = (in).end;
            const operand_26 = (in).message;

            break :block_27 @as(value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = operand_23, .start = operand_24, .end = operand_25, .message = operand_26, });
        };

        break :block_28 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_21).ahead_one, .ahead_two = (operand_21).ahead_two, .braces = (operand_21).braces, .comments = (operand_21).comments, .depth = (operand_21).depth, .diagnostic = operand_22, .dollar = (operand_21).dollar, .frames = (operand_21).frames, .keyword_state = (operand_21).keyword_state, .line_break = (operand_21).line_break, .mode = (operand_21).mode, .number = (operand_21).number, .offset = (operand_21).offset, .skip_until = (operand_21).skip_until, .source_length = (operand_21).source_length, .start = (operand_21).start, .symbol = (operand_21).symbol, .tokens = (operand_21).tokens, .warmed = (operand_21).warmed, });
    };
}

fn function_6_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_32, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    _ = buffers;

    return block_40: {
        const operand_29 = (in).state;
        const operand_30 = block_37: {
            const operand_31 = (in).code;
            const operand_32 = (in).start;
            const operand_33 = (in).end;
            const operand_34 = (in).message;

            break :block_37 block_36: {
                const operand_35 = (try (allocator).create(zx_type_23));

                (operand_35).* = @as(zx_type_23, zx_type_23{ .code = operand_31, .start = operand_32, .end = operand_33, .message = operand_34, });

                break :block_36 @as(*const zx_type_23, operand_35);
            };
        };

        break :block_40 block_39: {
            const operand_38 = (try (allocator).create(zx_type_28));

            (operand_38).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_29).ahead_one, .ahead_two = (operand_29).ahead_two, .braces = (operand_29).braces, .comments = (operand_29).comments, .depth = (operand_29).depth, .diagnostic = operand_30, .dollar = (operand_29).dollar, .frames = (operand_29).frames, .keyword_state = (operand_29).keyword_state, .line_break = (operand_29).line_break, .mode = (operand_29).mode, .number = (operand_29).number, .offset = (operand_29).offset, .skip_until = (operand_29).skip_until, .source_length = (operand_29).source_length, .start = (operand_29).start, .symbol = (operand_29).symbol, .tokens = (operand_29).tokens, .warmed = (operand_29).warmed, });

            break :block_39 @as(*const zx_type_28, operand_38);
        };
    };
}

fn function_7(allocator: ((std).mem).Allocator, in: u8) error{ }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    return (((in >= @as(u8, 65)) and (in <= @as(u8, 90))) or ((in >= @as(u8, 97)) and (in <= @as(u8, 122))));
}

fn function_8(allocator: ((std).mem).Allocator, in: u8) error{ }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    return ((((((((((((((((((((((in == @as(u8, 123)) or (in == @as(u8, 125))) or (in == @as(u8, 40))) or (in == @as(u8, 41))) or (in == @as(u8, 58))) or (in == @as(u8, 59))) or (in == @as(u8, 44))) or (in == @as(u8, 46))) or (in == @as(u8, 63))) or (in == @as(u8, 91))) or (in == @as(u8, 93))) or (in == @as(u8, 43))) or (in == @as(u8, 45))) or (in == @as(u8, 42))) or (in == @as(u8, 47))) or (in == @as(u8, 37))) or (in == @as(u8, 60))) or (in == @as(u8, 62))) or (in == @as(u8, 61))) or (in == @as(u8, 33))) or (in == @as(u8, 38))) or (in == @as(u8, 124)));
}

fn function_9(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 14))) {
        return (if (((in).byte == @as(u8, 108))) @as(u64, 15) else (if (((in).byte == @as(u8, 115))) @as(u64, 23) else (if (((in).byte == @as(u8, 119))) @as(u64, 27) else @as(u64, 1))));
    } else {
        if ((switch_1 == @as(u64, 15))) {
            return (if (((in).byte == @as(u8, 108))) @as(u64, 16) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 16))) {
                return (if (((in).byte == @as(u8, 111))) @as(u64, 17) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 17))) {
                    return (if (((in).byte == @as(u8, 99))) @as(u64, 18) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 18))) {
                        return (if (((in).byte == @as(u8, 97))) @as(u64, 19) else @as(u64, 1));
                    } else {
                        if ((switch_1 == @as(u64, 19))) {
                            return (if (((in).byte == @as(u8, 116))) @as(u64, 20) else @as(u64, 1));
                        } else {
                            if ((switch_1 == @as(u64, 20))) {
                                return (if (((in).byte == @as(u8, 111))) @as(u64, 21) else @as(u64, 1));
                            } else {
                                if ((switch_1 == @as(u64, 21))) {
                                    return (if (((in).byte == @as(u8, 114))) @as(u64, 22) else @as(u64, 1));
                                } else {
                                    if ((switch_1 == @as(u64, 23))) {
                                        return (if (((in).byte == @as(u8, 121))) @as(u64, 24) else @as(u64, 1));
                                    } else {
                                        if ((switch_1 == @as(u64, 24))) {
                                            return (if (((in).byte == @as(u8, 110))) @as(u64, 25) else @as(u64, 1));
                                        } else {
                                            if ((switch_1 == @as(u64, 25))) {
                                                return (if (((in).byte == @as(u8, 99))) @as(u64, 26) else @as(u64, 1));
                                            } else {
                                                if ((switch_1 == @as(u64, 27))) {
                                                    return (if (((in).byte == @as(u8, 97))) @as(u64, 28) else @as(u64, 1));
                                                } else {
                                                    if ((switch_1 == @as(u64, 28))) {
                                                        return (if (((in).byte == @as(u8, 105))) @as(u64, 29) else @as(u64, 1));
                                                    } else {
                                                        if ((switch_1 == @as(u64, 29))) {
                                                            return (if (((in).byte == @as(u8, 116))) @as(u64, 30) else @as(u64, 1));
                                                        } else {
                                                            return @as(u64, 1);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_10(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 31))) {
        return (if (((in).byte == @as(u8, 114))) @as(u64, 32) else @as(u64, 1));
    } else {
        if ((switch_1 == @as(u64, 32))) {
            return (if (((in).byte == @as(u8, 101))) @as(u64, 33) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 33))) {
                return (if (((in).byte == @as(u8, 97))) @as(u64, 34) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 34))) {
                    return (if (((in).byte == @as(u8, 107))) @as(u64, 35) else @as(u64, 1));
                } else {
                    return @as(u64, 1);
                }
            }
        }
    }
}

fn function_11(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 36))) {
        return (if (((in).byte == @as(u8, 97))) @as(u64, 37) else (if (((in).byte == @as(u8, 111))) @as(u64, 44) else @as(u64, 1)));
    } else {
        if ((switch_1 == @as(u64, 37))) {
            return (if (((in).byte == @as(u8, 110))) @as(u64, 38) else (if (((in).byte == @as(u8, 115))) @as(u64, 42) else @as(u64, 1)));
        } else {
            if ((switch_1 == @as(u64, 38))) {
                return (if (((in).byte == @as(u8, 99))) @as(u64, 39) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 39))) {
                    return (if (((in).byte == @as(u8, 101))) @as(u64, 40) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 40))) {
                        return (if (((in).byte == @as(u8, 108))) @as(u64, 41) else @as(u64, 1));
                    } else {
                        if ((switch_1 == @as(u64, 42))) {
                            return (if (((in).byte == @as(u8, 101))) @as(u64, 43) else @as(u64, 1));
                        } else {
                            if ((switch_1 == @as(u64, 44))) {
                                return (if (((in).byte == @as(u8, 110))) @as(u64, 45) else @as(u64, 1));
                            } else {
                                if ((switch_1 == @as(u64, 45))) {
                                    return (if (((in).byte == @as(u8, 99))) @as(u64, 46) else (if (((in).byte == @as(u8, 115))) @as(u64, 53) else @as(u64, 1)));
                                } else {
                                    if ((switch_1 == @as(u64, 46))) {
                                        return (if (((in).byte == @as(u8, 117))) @as(u64, 47) else @as(u64, 1));
                                    } else {
                                        if ((switch_1 == @as(u64, 47))) {
                                            return (if (((in).byte == @as(u8, 114))) @as(u64, 48) else @as(u64, 1));
                                        } else {
                                            if ((switch_1 == @as(u64, 48))) {
                                                return (if (((in).byte == @as(u8, 114))) @as(u64, 49) else @as(u64, 1));
                                            } else {
                                                if ((switch_1 == @as(u64, 49))) {
                                                    return (if (((in).byte == @as(u8, 101))) @as(u64, 50) else @as(u64, 1));
                                                } else {
                                                    if ((switch_1 == @as(u64, 50))) {
                                                        return (if (((in).byte == @as(u8, 110))) @as(u64, 51) else @as(u64, 1));
                                                    } else {
                                                        if ((switch_1 == @as(u64, 51))) {
                                                            return (if (((in).byte == @as(u8, 116))) @as(u64, 52) else @as(u64, 1));
                                                        } else {
                                                            if ((switch_1 == @as(u64, 53))) {
                                                                return (if (((in).byte == @as(u8, 116))) @as(u64, 54) else @as(u64, 1));
                                                            } else {
                                                                return @as(u64, 1);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_12(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 55))) {
        return (if (((in).byte == @as(u8, 101))) @as(u64, 56) else (if (((in).byte == @as(u8, 111))) @as(u64, 71) else @as(u64, 1)));
    } else {
        if ((switch_1 == @as(u64, 56))) {
            return (if (((in).byte == @as(u8, 99))) @as(u64, 57) else (if (((in).byte == @as(u8, 102))) @as(u64, 62) else (if (((in).byte == @as(u8, 108))) @as(u64, 67) else @as(u64, 1))));
        } else {
            if ((switch_1 == @as(u64, 57))) {
                return (if (((in).byte == @as(u8, 108))) @as(u64, 58) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 58))) {
                    return (if (((in).byte == @as(u8, 97))) @as(u64, 59) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 59))) {
                        return (if (((in).byte == @as(u8, 114))) @as(u64, 60) else @as(u64, 1));
                    } else {
                        if ((switch_1 == @as(u64, 60))) {
                            return (if (((in).byte == @as(u8, 101))) @as(u64, 61) else @as(u64, 1));
                        } else {
                            if ((switch_1 == @as(u64, 62))) {
                                return (if (((in).byte == @as(u8, 97))) @as(u64, 63) else @as(u64, 1));
                            } else {
                                if ((switch_1 == @as(u64, 63))) {
                                    return (if (((in).byte == @as(u8, 117))) @as(u64, 64) else @as(u64, 1));
                                } else {
                                    if ((switch_1 == @as(u64, 64))) {
                                        return (if (((in).byte == @as(u8, 108))) @as(u64, 65) else @as(u64, 1));
                                    } else {
                                        if ((switch_1 == @as(u64, 65))) {
                                            return (if (((in).byte == @as(u8, 116))) @as(u64, 66) else @as(u64, 1));
                                        } else {
                                            if ((switch_1 == @as(u64, 67))) {
                                                return (if (((in).byte == @as(u8, 101))) @as(u64, 68) else @as(u64, 1));
                                            } else {
                                                if ((switch_1 == @as(u64, 68))) {
                                                    return (if (((in).byte == @as(u8, 116))) @as(u64, 69) else @as(u64, 1));
                                                } else {
                                                    if ((switch_1 == @as(u64, 69))) {
                                                        return (if (((in).byte == @as(u8, 101))) @as(u64, 70) else @as(u64, 1));
                                                    } else {
                                                        return @as(u64, 1);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_13(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 72))) {
        return (if (((in).byte == @as(u8, 108))) @as(u64, 73) else (if (((in).byte == @as(u8, 110))) @as(u64, 76) else (if (((in).byte == @as(u8, 120))) @as(u64, 84) else @as(u64, 1))));
    } else {
        if ((switch_1 == @as(u64, 73))) {
            return (if (((in).byte == @as(u8, 115))) @as(u64, 74) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 74))) {
                return (if (((in).byte == @as(u8, 101))) @as(u64, 75) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 76))) {
                    return (if (((in).byte == @as(u8, 115))) @as(u64, 77) else (if (((in).byte == @as(u8, 117))) @as(u64, 82) else @as(u64, 1)));
                } else {
                    if ((switch_1 == @as(u64, 77))) {
                        return (if (((in).byte == @as(u8, 117))) @as(u64, 78) else @as(u64, 1));
                    } else {
                        if ((switch_1 == @as(u64, 78))) {
                            return (if (((in).byte == @as(u8, 114))) @as(u64, 79) else @as(u64, 1));
                        } else {
                            if ((switch_1 == @as(u64, 79))) {
                                return (if (((in).byte == @as(u8, 101))) @as(u64, 80) else @as(u64, 1));
                            } else {
                                if ((switch_1 == @as(u64, 80))) {
                                    return (if (((in).byte == @as(u8, 115))) @as(u64, 81) else @as(u64, 1));
                                } else {
                                    if ((switch_1 == @as(u64, 82))) {
                                        return (if (((in).byte == @as(u8, 109))) @as(u64, 83) else @as(u64, 1));
                                    } else {
                                        if ((switch_1 == @as(u64, 84))) {
                                            return (if (((in).byte == @as(u8, 112))) @as(u64, 85) else @as(u64, 1));
                                        } else {
                                            if ((switch_1 == @as(u64, 85))) {
                                                return (if (((in).byte == @as(u8, 111))) @as(u64, 86) else @as(u64, 1));
                                            } else {
                                                if ((switch_1 == @as(u64, 86))) {
                                                    return (if (((in).byte == @as(u8, 114))) @as(u64, 87) else @as(u64, 1));
                                                } else {
                                                    if ((switch_1 == @as(u64, 87))) {
                                                        return (if (((in).byte == @as(u8, 116))) @as(u64, 88) else @as(u64, 1));
                                                    } else {
                                                        return @as(u64, 1);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_14(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 89))) {
        return (if (((in).byte == @as(u8, 97))) @as(u64, 90) else (if (((in).byte == @as(u8, 111))) @as(u64, 94) else (if (((in).byte == @as(u8, 114))) @as(u64, 96) else (if (((in).byte == @as(u8, 117))) @as(u64, 99) else @as(u64, 1)))));
    } else {
        if ((switch_1 == @as(u64, 90))) {
            return (if (((in).byte == @as(u8, 108))) @as(u64, 91) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 91))) {
                return (if (((in).byte == @as(u8, 115))) @as(u64, 92) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 92))) {
                    return (if (((in).byte == @as(u8, 101))) @as(u64, 93) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 94))) {
                        return (if (((in).byte == @as(u8, 114))) @as(u64, 95) else @as(u64, 1));
                    } else {
                        if ((switch_1 == @as(u64, 96))) {
                            return (if (((in).byte == @as(u8, 111))) @as(u64, 97) else @as(u64, 1));
                        } else {
                            if ((switch_1 == @as(u64, 97))) {
                                return (if (((in).byte == @as(u8, 109))) @as(u64, 98) else @as(u64, 1));
                            } else {
                                if ((switch_1 == @as(u64, 99))) {
                                    return (if (((in).byte == @as(u8, 110))) @as(u64, 100) else @as(u64, 1));
                                } else {
                                    if ((switch_1 == @as(u64, 100))) {
                                        return (if (((in).byte == @as(u8, 99))) @as(u64, 101) else @as(u64, 1));
                                    } else {
                                        if ((switch_1 == @as(u64, 101))) {
                                            return (if (((in).byte == @as(u8, 116))) @as(u64, 102) else @as(u64, 1));
                                        } else {
                                            if ((switch_1 == @as(u64, 102))) {
                                                return (if (((in).byte == @as(u8, 105))) @as(u64, 103) else @as(u64, 1));
                                            } else {
                                                if ((switch_1 == @as(u64, 103))) {
                                                    return (if (((in).byte == @as(u8, 111))) @as(u64, 104) else @as(u64, 1));
                                                } else {
                                                    if ((switch_1 == @as(u64, 104))) {
                                                        return (if (((in).byte == @as(u8, 110))) @as(u64, 105) else @as(u64, 1));
                                                    } else {
                                                        return @as(u64, 1);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_15(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 106))) {
        return (if (((in).byte == @as(u8, 102))) @as(u64, 107) else (if (((in).byte == @as(u8, 109))) @as(u64, 108) else (if (((in).byte == @as(u8, 110))) @as(u64, 113) else (if (((in).byte == @as(u8, 111))) @as(u64, 118) else @as(u64, 1)))));
    } else {
        if ((switch_1 == @as(u64, 108))) {
            return (if (((in).byte == @as(u8, 112))) @as(u64, 109) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 109))) {
                return (if (((in).byte == @as(u8, 111))) @as(u64, 110) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 110))) {
                    return (if (((in).byte == @as(u8, 114))) @as(u64, 111) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 111))) {
                        return (if (((in).byte == @as(u8, 116))) @as(u64, 112) else @as(u64, 1));
                    } else {
                        if ((switch_1 == @as(u64, 113))) {
                            return (if (((in).byte == @as(u8, 115))) @as(u64, 114) else @as(u64, 1));
                        } else {
                            if ((switch_1 == @as(u64, 114))) {
                                return (if (((in).byte == @as(u8, 101))) @as(u64, 115) else @as(u64, 1));
                            } else {
                                if ((switch_1 == @as(u64, 115))) {
                                    return (if (((in).byte == @as(u8, 114))) @as(u64, 116) else @as(u64, 1));
                                } else {
                                    if ((switch_1 == @as(u64, 116))) {
                                        return (if (((in).byte == @as(u8, 116))) @as(u64, 117) else @as(u64, 1));
                                    } else {
                                        return @as(u64, 1);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_16(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 119))) {
        return (if (((in).byte == @as(u8, 101))) @as(u64, 120) else (if (((in).byte == @as(u8, 111))) @as(u64, 122) else @as(u64, 1)));
    } else {
        if ((switch_1 == @as(u64, 120))) {
            return (if (((in).byte == @as(u8, 116))) @as(u64, 121) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 122))) {
                return (if (((in).byte == @as(u8, 111))) @as(u64, 123) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 123))) {
                    return (if (((in).byte == @as(u8, 112))) @as(u64, 124) else @as(u64, 1));
                } else {
                    return @as(u64, 1);
                }
            }
        }
    }
}

fn function_17(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 125))) {
        return (if (((in).byte == @as(u8, 97))) @as(u64, 126) else @as(u64, 1));
    } else {
        if ((switch_1 == @as(u64, 126))) {
            return (if (((in).byte == @as(u8, 116))) @as(u64, 127) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 127))) {
                return (if (((in).byte == @as(u8, 99))) @as(u64, 128) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 128))) {
                    return (if (((in).byte == @as(u8, 104))) @as(u64, 129) else @as(u64, 1));
                } else {
                    return @as(u64, 1);
                }
            }
        }
    }
}

fn function_18(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 2))) {
        return (if (((in).byte == @as(u8, 110))) @as(u64, 3) else @as(u64, 1));
    } else {
        if ((switch_1 == @as(u64, 3))) {
            return (if (((in).byte == @as(u8, 112))) @as(u64, 4) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 4))) {
                return (if (((in).byte == @as(u8, 117))) @as(u64, 5) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 5))) {
                    return (if (((in).byte == @as(u8, 116))) @as(u64, 6) else @as(u64, 1));
                } else {
                    return @as(u64, 1);
                }
            }
        }
    }
}

fn function_19(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 7))) {
        return (if (((in).byte == @as(u8, 117))) @as(u64, 8) else @as(u64, 1));
    } else {
        if ((switch_1 == @as(u64, 8))) {
            return (if (((in).byte == @as(u8, 116))) @as(u64, 9) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 9))) {
                return (if (((in).byte == @as(u8, 112))) @as(u64, 10) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 10))) {
                    return (if (((in).byte == @as(u8, 117))) @as(u64, 11) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 11))) {
                        return (if (((in).byte == @as(u8, 116))) @as(u64, 12) else @as(u64, 1));
                    } else {
                        return @as(u64, 1);
                    }
                }
            }
        }
    }
}

fn function_20(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    if ((((in).state >= @as(u64, 2)) and ((in).state <= @as(u64, 6)))) {
        return (try function_18(allocator, in));
    }

    if ((((in).state >= @as(u64, 7)) and ((in).state <= @as(u64, 12)))) {
        return (try function_19(allocator, in));
    }

    if ((((in).state >= @as(u64, 14)) and ((in).state <= @as(u64, 30)))) {
        return (try function_9(allocator, in));
    }

    if ((((in).state >= @as(u64, 31)) and ((in).state <= @as(u64, 35)))) {
        return (try function_10(allocator, in));
    }

    if ((((in).state >= @as(u64, 36)) and ((in).state <= @as(u64, 54)))) {
        return (try function_11(allocator, in));
    }

    if ((((in).state >= @as(u64, 55)) and ((in).state <= @as(u64, 71)))) {
        return (try function_12(allocator, in));
    }

    if ((((in).state >= @as(u64, 72)) and ((in).state <= @as(u64, 88)))) {
        return (try function_13(allocator, in));
    }

    if ((((in).state >= @as(u64, 89)) and ((in).state <= @as(u64, 105)))) {
        return (try function_14(allocator, in));
    }

    if ((((in).state >= @as(u64, 106)) and ((in).state <= @as(u64, 118)))) {
        return (try function_15(allocator, in));
    }

    if ((((in).state >= @as(u64, 119)) and ((in).state <= @as(u64, 124)))) {
        return (try function_16(allocator, in));
    }

    if ((((in).state >= @as(u64, 125)) and ((in).state <= @as(u64, 129)))) {
        return (try function_17(allocator, in));
    }

    return @as(u64, 1);
}

fn function_21(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 130))) {
        return (if (((in).byte == @as(u8, 101))) @as(u64, 131) else (if (((in).byte == @as(u8, 117))) @as(u64, 135) else @as(u64, 1)));
    } else {
        if ((switch_1 == @as(u64, 131))) {
            return (if (((in).byte == @as(u8, 119))) @as(u64, 132) else (if (((in).byte == @as(u8, 120))) @as(u64, 133) else @as(u64, 1)));
        } else {
            if ((switch_1 == @as(u64, 133))) {
                return (if (((in).byte == @as(u8, 116))) @as(u64, 134) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 135))) {
                    return (if (((in).byte == @as(u8, 108))) @as(u64, 136) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 136))) {
                        return (if (((in).byte == @as(u8, 108))) @as(u64, 137) else @as(u64, 1));
                    } else {
                        return @as(u64, 1);
                    }
                }
            }
        }
    }
}

fn function_22(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 138))) {
        return (if (((in).byte == @as(u8, 114))) @as(u64, 139) else @as(u64, 1));
    } else {
        if ((switch_1 == @as(u64, 139))) {
            return (if (((in).byte == @as(u8, 111))) @as(u64, 140) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 140))) {
                return (if (((in).byte == @as(u8, 99))) @as(u64, 141) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 141))) {
                    return (if (((in).byte == @as(u8, 101))) @as(u64, 142) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 142))) {
                        return (if (((in).byte == @as(u8, 115))) @as(u64, 143) else @as(u64, 1));
                    } else {
                        if ((switch_1 == @as(u64, 143))) {
                            return (if (((in).byte == @as(u8, 115))) @as(u64, 144) else @as(u64, 1));
                        } else {
                            return @as(u64, 1);
                        }
                    }
                }
            }
        }
    }
}

fn function_23(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 145))) {
        return (if (((in).byte == @as(u8, 117))) @as(u64, 146) else @as(u64, 1));
    } else {
        if ((switch_1 == @as(u64, 146))) {
            return (if (((in).byte == @as(u8, 101))) @as(u64, 147) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 147))) {
                return (if (((in).byte == @as(u8, 114))) @as(u64, 148) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 148))) {
                    return (if (((in).byte == @as(u8, 121))) @as(u64, 149) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 149))) {
                        return (if (((in).byte == @as(u8, 77))) @as(u64, 150) else (if (((in).byte == @as(u8, 79))) @as(u64, 154) else @as(u64, 1)));
                    } else {
                        if ((switch_1 == @as(u64, 150))) {
                            return (if (((in).byte == @as(u8, 97))) @as(u64, 151) else @as(u64, 1));
                        } else {
                            if ((switch_1 == @as(u64, 151))) {
                                return (if (((in).byte == @as(u8, 110))) @as(u64, 152) else @as(u64, 1));
                            } else {
                                if ((switch_1 == @as(u64, 152))) {
                                    return (if (((in).byte == @as(u8, 121))) @as(u64, 153) else @as(u64, 1));
                                } else {
                                    if ((switch_1 == @as(u64, 154))) {
                                        return (if (((in).byte == @as(u8, 110))) @as(u64, 155) else @as(u64, 1));
                                    } else {
                                        if ((switch_1 == @as(u64, 155))) {
                                            return (if (((in).byte == @as(u8, 101))) @as(u64, 156) else @as(u64, 1));
                                        } else {
                                            return @as(u64, 1);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_24(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 157))) {
        return (if (((in).byte == @as(u8, 101))) @as(u64, 158) else @as(u64, 1));
    } else {
        if ((switch_1 == @as(u64, 158))) {
            return (if (((in).byte == @as(u8, 113))) @as(u64, 159) else (if (((in).byte == @as(u8, 116))) @as(u64, 165) else @as(u64, 1)));
        } else {
            if ((switch_1 == @as(u64, 159))) {
                return (if (((in).byte == @as(u8, 117))) @as(u64, 160) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 160))) {
                    return (if (((in).byte == @as(u8, 105))) @as(u64, 161) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 161))) {
                        return (if (((in).byte == @as(u8, 114))) @as(u64, 162) else @as(u64, 1));
                    } else {
                        if ((switch_1 == @as(u64, 162))) {
                            return (if (((in).byte == @as(u8, 101))) @as(u64, 163) else @as(u64, 1));
                        } else {
                            if ((switch_1 == @as(u64, 163))) {
                                return (if (((in).byte == @as(u8, 115))) @as(u64, 164) else @as(u64, 1));
                            } else {
                                if ((switch_1 == @as(u64, 165))) {
                                    return (if (((in).byte == @as(u8, 117))) @as(u64, 166) else @as(u64, 1));
                                } else {
                                    if ((switch_1 == @as(u64, 166))) {
                                        return (if (((in).byte == @as(u8, 114))) @as(u64, 167) else @as(u64, 1));
                                    } else {
                                        if ((switch_1 == @as(u64, 167))) {
                                            return (if (((in).byte == @as(u8, 110))) @as(u64, 168) else @as(u64, 1));
                                        } else {
                                            return @as(u64, 1);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_25(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 169))) {
        return (if (((in).byte == @as(u8, 116))) @as(u64, 170) else (if (((in).byte == @as(u8, 119))) @as(u64, 174) else @as(u64, 1)));
    } else {
        if ((switch_1 == @as(u64, 170))) {
            return (if (((in).byte == @as(u8, 111))) @as(u64, 171) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 171))) {
                return (if (((in).byte == @as(u8, 114))) @as(u64, 172) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 172))) {
                    return (if (((in).byte == @as(u8, 101))) @as(u64, 173) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 174))) {
                        return (if (((in).byte == @as(u8, 105))) @as(u64, 175) else @as(u64, 1));
                    } else {
                        if ((switch_1 == @as(u64, 175))) {
                            return (if (((in).byte == @as(u8, 116))) @as(u64, 176) else @as(u64, 1));
                        } else {
                            if ((switch_1 == @as(u64, 176))) {
                                return (if (((in).byte == @as(u8, 99))) @as(u64, 177) else @as(u64, 1));
                            } else {
                                if ((switch_1 == @as(u64, 177))) {
                                    return (if (((in).byte == @as(u8, 104))) @as(u64, 178) else @as(u64, 1));
                                } else {
                                    return @as(u64, 1);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_26(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 179))) {
        return (if (((in).byte == @as(u8, 104))) @as(u64, 180) else (if (((in).byte == @as(u8, 114))) @as(u64, 185) else (if (((in).byte == @as(u8, 121))) @as(u64, 198) else @as(u64, 1))));
    } else {
        if ((switch_1 == @as(u64, 180))) {
            return (if (((in).byte == @as(u8, 114))) @as(u64, 181) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 181))) {
                return (if (((in).byte == @as(u8, 111))) @as(u64, 182) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 182))) {
                    return (if (((in).byte == @as(u8, 119))) @as(u64, 183) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 183))) {
                        return (if (((in).byte == @as(u8, 115))) @as(u64, 184) else @as(u64, 1));
                    } else {
                        if ((switch_1 == @as(u64, 185))) {
                            return (if (((in).byte == @as(u8, 97))) @as(u64, 186) else (if (((in).byte == @as(u8, 117))) @as(u64, 195) else (if (((in).byte == @as(u8, 121))) @as(u64, 197) else @as(u64, 1))));
                        } else {
                            if ((switch_1 == @as(u64, 186))) {
                                return (if (((in).byte == @as(u8, 110))) @as(u64, 187) else @as(u64, 1));
                            } else {
                                if ((switch_1 == @as(u64, 187))) {
                                    return (if (((in).byte == @as(u8, 115))) @as(u64, 188) else @as(u64, 1));
                                } else {
                                    if ((switch_1 == @as(u64, 188))) {
                                        return (if (((in).byte == @as(u8, 97))) @as(u64, 189) else @as(u64, 1));
                                    } else {
                                        if ((switch_1 == @as(u64, 189))) {
                                            return (if (((in).byte == @as(u8, 99))) @as(u64, 190) else @as(u64, 1));
                                        } else {
                                            if ((switch_1 == @as(u64, 190))) {
                                                return (if (((in).byte == @as(u8, 116))) @as(u64, 191) else @as(u64, 1));
                                            } else {
                                                if ((switch_1 == @as(u64, 191))) {
                                                    return (if (((in).byte == @as(u8, 105))) @as(u64, 192) else @as(u64, 1));
                                                } else {
                                                    if ((switch_1 == @as(u64, 192))) {
                                                        return (if (((in).byte == @as(u8, 111))) @as(u64, 193) else @as(u64, 1));
                                                    } else {
                                                        if ((switch_1 == @as(u64, 193))) {
                                                            return (if (((in).byte == @as(u8, 110))) @as(u64, 194) else @as(u64, 1));
                                                        } else {
                                                            if ((switch_1 == @as(u64, 195))) {
                                                                return (if (((in).byte == @as(u8, 101))) @as(u64, 196) else @as(u64, 1));
                                                            } else {
                                                                if ((switch_1 == @as(u64, 198))) {
                                                                    return (if (((in).byte == @as(u8, 112))) @as(u64, 199) else @as(u64, 1));
                                                                } else {
                                                                    if ((switch_1 == @as(u64, 199))) {
                                                                        return (if (((in).byte == @as(u8, 101))) @as(u64, 200) else @as(u64, 1));
                                                                    } else {
                                                                        return @as(u64, 1);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_27(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 201))) {
        return (if (((in).byte == @as(u8, 112))) @as(u64, 202) else @as(u64, 1));
    } else {
        if ((switch_1 == @as(u64, 202))) {
            return (if (((in).byte == @as(u8, 100))) @as(u64, 203) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 203))) {
                return (if (((in).byte == @as(u8, 97))) @as(u64, 204) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 204))) {
                    return (if (((in).byte == @as(u8, 116))) @as(u64, 205) else @as(u64, 1));
                } else {
                    if ((switch_1 == @as(u64, 205))) {
                        return (if (((in).byte == @as(u8, 101))) @as(u64, 206) else @as(u64, 1));
                    } else {
                        return @as(u64, 1);
                    }
                }
            }
        }
    }
}

fn function_28(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 207))) {
        return (if (((in).byte == @as(u8, 97))) @as(u64, 208) else @as(u64, 1));
    } else {
        if ((switch_1 == @as(u64, 208))) {
            return (if (((in).byte == @as(u8, 114))) @as(u64, 209) else @as(u64, 1));
        } else {
            return @as(u64, 1);
        }
    }
}

fn function_29(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 210))) {
        return (if (((in).byte == @as(u8, 104))) @as(u64, 211) else @as(u64, 1));
    } else {
        if ((switch_1 == @as(u64, 211))) {
            return (if (((in).byte == @as(u8, 105))) @as(u64, 212) else @as(u64, 1));
        } else {
            if ((switch_1 == @as(u64, 212))) {
                return (if (((in).byte == @as(u8, 108))) @as(u64, 213) else @as(u64, 1));
            } else {
                if ((switch_1 == @as(u64, 213))) {
                    return (if (((in).byte == @as(u8, 101))) @as(u64, 214) else @as(u64, 1));
                } else {
                    return @as(u64, 1);
                }
            }
        }
    }
}

fn function_30(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    if ((((in).state >= @as(u64, 130)) and ((in).state <= @as(u64, 137)))) {
        return (try function_21(allocator, in));
    }

    if ((((in).state >= @as(u64, 138)) and ((in).state <= @as(u64, 144)))) {
        return (try function_22(allocator, in));
    }

    if ((((in).state >= @as(u64, 145)) and ((in).state <= @as(u64, 156)))) {
        return (try function_23(allocator, in));
    }

    if ((((in).state >= @as(u64, 157)) and ((in).state <= @as(u64, 168)))) {
        return (try function_24(allocator, in));
    }

    if ((((in).state >= @as(u64, 169)) and ((in).state <= @as(u64, 178)))) {
        return (try function_25(allocator, in));
    }

    if ((((in).state >= @as(u64, 179)) and ((in).state <= @as(u64, 200)))) {
        return (try function_26(allocator, in));
    }

    if ((((in).state >= @as(u64, 201)) and ((in).state <= @as(u64, 206)))) {
        return (try function_27(allocator, in));
    }

    if ((((in).state >= @as(u64, 207)) and ((in).state <= @as(u64, 209)))) {
        return (try function_28(allocator, in));
    }

    if ((((in).state >= @as(u64, 210)) and ((in).state <= @as(u64, 214)))) {
        return (try function_29(allocator, in));
    }

    return @as(u64, 1);
}

fn function_31(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = (in).state;

    if ((switch_1 == @as(u64, 0))) {
        return (if (((in).byte == @as(u8, 73))) @as(u64, 2) else (if (((in).byte == @as(u8, 79))) @as(u64, 7) else (if (((in).byte == @as(u8, 95))) @as(u64, 13) else (if (((in).byte == @as(u8, 97))) @as(u64, 14) else (if (((in).byte == @as(u8, 98))) @as(u64, 31) else (if (((in).byte == @as(u8, 99))) @as(u64, 36) else (if (((in).byte == @as(u8, 100))) @as(u64, 55) else (if (((in).byte == @as(u8, 101))) @as(u64, 72) else (if (((in).byte == @as(u8, 102))) @as(u64, 89) else (if (((in).byte == @as(u8, 105))) @as(u64, 106) else (if (((in).byte == @as(u8, 108))) @as(u64, 119) else (if (((in).byte == @as(u8, 109))) @as(u64, 125) else (if (((in).byte == @as(u8, 110))) @as(u64, 130) else (if (((in).byte == @as(u8, 112))) @as(u64, 138) else (if (((in).byte == @as(u8, 113))) @as(u64, 145) else (if (((in).byte == @as(u8, 114))) @as(u64, 157) else (if (((in).byte == @as(u8, 115))) @as(u64, 169) else (if (((in).byte == @as(u8, 116))) @as(u64, 179) else (if (((in).byte == @as(u8, 117))) @as(u64, 201) else (if (((in).byte == @as(u8, 118))) @as(u64, 207) else (if (((in).byte == @as(u8, 119))) @as(u64, 210) else @as(u64, 1))))))))))))))))))))));
    } else {
        return @as(u64, 1);
    }
}

fn function_32(allocator: ((std).mem).Allocator, in: *const zx_type_33) error{ }!u64 {
    @setRuntimeSafety(true);

    if (((in).state == @as(u64, 0))) {
        return (try function_31(allocator, in));
    }

    return (if (((in).state <= @as(u64, 129))) (try function_20(allocator, in)) else (try function_30(allocator, in)));
}

fn function_33(allocator: ((std).mem).Allocator, in: u8) error{ }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    return ((in >= @as(u8, 48)) and (in <= @as(u8, 57)));
}

fn function_34(allocator: ((std).mem).Allocator, in: *const zx_type_34) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    if ((((((in).byte == @as(u8, 46)) and (in).has_after) and ((in).next == @as(u8, 46))) and ((in).after == @as(u8, 46)))) {
        return @as(u64, 3);
    }

    if (((in).has_next and (((((in).byte == @as(u8, 61)) and ((in).next == @as(u8, 62))) or (((in).next == @as(u8, 61)) and (((((in).byte == @as(u8, 61)) or ((in).byte == @as(u8, 33))) or ((in).byte == @as(u8, 60))) or ((in).byte == @as(u8, 62))))) or (((in).byte == (in).next) and ((((in).byte == @as(u8, 63)) or ((in).byte == @as(u8, 38))) or ((in).byte == @as(u8, 124))))))) {
        return @as(u64, 2);
    }

    return @as(u64, 1);
}

fn function_35(allocator: ((std).mem).Allocator, in: *const zx_type_35) error{ }!zx_type_16 {
    @setRuntimeSafety(true);

    _ = allocator;

    if (((in).length == @as(u64, 3))) {
        return @as(zx_type_16, .Spread);
    }

    if (((in).length == @as(u64, 2))) {
        return (if ((((in).byte == @as(u8, 61)) and ((in).next == @as(u8, 62)))) @as(zx_type_16, .Arrow) else (if (((in).byte == @as(u8, 61))) @as(zx_type_16, .Equal) else (if (((in).byte == @as(u8, 33))) @as(zx_type_16, .NotEqual) else (if (((in).byte == @as(u8, 60))) @as(zx_type_16, .LessEqual) else (if (((in).byte == @as(u8, 62))) @as(zx_type_16, .GreaterEqual) else (if (((in).byte == @as(u8, 63))) @as(zx_type_16, .Coalesce) else (if (((in).byte == @as(u8, 38))) @as(zx_type_16, .And) else @as(zx_type_16, .Or))))))));
    }

    return (if (((in).byte == @as(u8, 123))) @as(zx_type_16, .OpenBrace) else (if (((in).byte == @as(u8, 125))) @as(zx_type_16, .CloseBrace) else (if (((in).byte == @as(u8, 40))) @as(zx_type_16, .OpenParen) else (if (((in).byte == @as(u8, 41))) @as(zx_type_16, .CloseParen) else (if (((in).byte == @as(u8, 91))) @as(zx_type_16, .OpenBracket) else (if (((in).byte == @as(u8, 93))) @as(zx_type_16, .CloseBracket) else (if (((in).byte == @as(u8, 58))) @as(zx_type_16, .Colon) else (if (((in).byte == @as(u8, 59))) @as(zx_type_16, .Semicolon) else (if (((in).byte == @as(u8, 44))) @as(zx_type_16, .Comma) else (if (((in).byte == @as(u8, 46))) @as(zx_type_16, .Dot) else (if (((in).byte == @as(u8, 63))) @as(zx_type_16, .Question) else (if (((in).byte == @as(u8, 43))) @as(zx_type_16, .Plus) else (if (((in).byte == @as(u8, 45))) @as(zx_type_16, .Minus) else (if (((in).byte == @as(u8, 42))) @as(zx_type_16, .Star) else (if (((in).byte == @as(u8, 47))) @as(zx_type_16, .Slash) else (if (((in).byte == @as(u8, 37))) @as(zx_type_16, .Percent) else (if (((in).byte == @as(u8, 60))) @as(zx_type_16, .Less) else (if (((in).byte == @as(u8, 62))) @as(zx_type_16, .Greater) else (if (((in).byte == @as(u8, 61))) @as(zx_type_16, .Assign) else (if (((in).byte == @as(u8, 33))) @as(zx_type_16, .Not) else (if (((in).byte == @as(u8, 38))) @as(zx_type_16, .Ampersand) else @as(zx_type_16, .Pipe))))))))))))))))))))));
}

fn function_36(allocator: ((std).mem).Allocator, in: *const zx_type_28) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if (((in).mode == @as(zx_type_22, .Idle))) {
        const value_1: u64 = (in).offset;

        return block_58: {
            const operand_51 = in;
            const operand_52 = @as(zx_type_22, .Template);
            const operand_53 = value_1;
            const operand_54 = @as(u64, 0);
            const operand_55 = @as(u64, 0);

            break :block_58 block_57: {
                const operand_56 = (try (allocator).create(zx_type_28));

                (operand_56).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_51).ahead_one, .ahead_two = (operand_51).ahead_two, .braces = operand_54, .comments = (operand_51).comments, .depth = operand_55, .diagnostic = (operand_51).diagnostic, .dollar = (operand_51).dollar, .frames = (operand_51).frames, .keyword_state = (operand_51).keyword_state, .line_break = (operand_51).line_break, .mode = operand_52, .number = (operand_51).number, .offset = (operand_51).offset, .skip_until = (operand_51).skip_until, .source_length = (operand_51).source_length, .start = operand_53, .symbol = (operand_51).symbol, .tokens = (operand_51).tokens, .warmed = (operand_51).warmed, });

                break :block_57 @as(*const zx_type_28, operand_56);
            };
        };
    }

    if ((((in).depth + @as(u64, 1)) > @as(u64, 256))) {
        return block_50: {
            const operand_42 = block_41: {
                const operand_34 = @as([]const u8, "syntax");
                const operand_35 = (in).offset;
                const operand_36 = ((in).offset + @as(u64, 1));
                const operand_37 = @as([]const u8, "template nesting exceeds 256 levels");
                const operand_38 = in;

                break :block_41 block_40: {
                    const operand_39 = (try (allocator).create(zx_type_32));

                    (operand_39).* = @as(zx_type_32, zx_type_32{ .code = operand_34, .start = operand_35, .end = operand_36, .message = operand_37, .state = operand_38, });

                    break :block_40 @as(*const zx_type_32, operand_39);
                };
            };
            const operand_43 = (try function_6_value(allocator, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = (operand_42).code, .end = (operand_42).end, .message = (operand_42).message, .start = (operand_42).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_42).state).ahead_one, .ahead_two = ((operand_42).state).ahead_two, .braces = ((operand_42).state).braces, .comments = ((operand_42).state).comments, .depth = ((operand_42).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_42).state).diagnostic).code, .end = (((operand_42).state).diagnostic).end, .message = (((operand_42).state).diagnostic).message, .start = (((operand_42).state).diagnostic).start, .zx_origin = ((operand_42).state).diagnostic, }, .dollar = ((operand_42).state).dollar, .frames = ((operand_42).state).frames, .keyword_state = ((operand_42).state).keyword_state, .line_break = ((operand_42).state).line_break, .mode = ((operand_42).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_42).state).number).end, .last_byte = (((operand_42).state).number).last_byte, .phase = (((operand_42).state).number).phase, .separators_valid = (((operand_42).state).number).separators_valid, .zx_origin = ((operand_42).state).number, }, .offset = ((operand_42).state).offset, .skip_until = ((operand_42).state).skip_until, .source_length = ((operand_42).state).source_length, .start = ((operand_42).state).start, .symbol = ((operand_42).state).symbol, .tokens = ((operand_42).state).tokens, .warmed = ((operand_42).state).warmed, .zx_origin = (operand_42).state, }, .zx_origin = operand_42, }));

            break :block_50 (if (((operand_43).zx_origin != null)) (operand_43).zx_origin.? else block_49: {
                const operand_48 = (try (allocator).create(zx_type_28));

                (operand_48).* = zx_type_28{ .ahead_one = (operand_43).ahead_one, .ahead_two = (operand_43).ahead_two, .braces = (operand_43).braces, .comments = (operand_43).comments, .depth = (operand_43).depth, .diagnostic = (if ((((operand_43).diagnostic).zx_origin != null)) ((operand_43).diagnostic).zx_origin.? else block_45: {
                    const operand_44 = (try (allocator).create(zx_type_23));

                    (operand_44).* = zx_type_23{ .code = ((operand_43).diagnostic).code, .end = ((operand_43).diagnostic).end, .message = ((operand_43).diagnostic).message, .start = ((operand_43).diagnostic).start, };

                    break :block_45 @as(*const zx_type_23, operand_44);
                }), .dollar = (operand_43).dollar, .frames = (operand_43).frames, .keyword_state = (operand_43).keyword_state, .line_break = (operand_43).line_break, .mode = (operand_43).mode, .number = (if ((((operand_43).number).zx_origin != null)) ((operand_43).number).zx_origin.? else block_47: {
                    const operand_46 = (try (allocator).create(zx_type_20));

                    (operand_46).* = zx_type_20{ .end = ((operand_43).number).end, .last_byte = ((operand_43).number).last_byte, .phase = ((operand_43).number).phase, .separators_valid = ((operand_43).number).separators_valid, };

                    break :block_47 @as(*const zx_type_20, operand_46);
                }), .offset = (operand_43).offset, .skip_until = (operand_43).skip_until, .source_length = (operand_43).source_length, .start = (operand_43).start, .symbol = (operand_43).symbol, .tokens = (operand_43).tokens, .warmed = (operand_43).warmed, };

                break :block_49 @as(*const zx_type_28, operand_48);
            });
        };
    }

    const value_2: *const zx_type_24 = block_33: {
        const operand_27 = (in).mode;
        const operand_28 = (in).start;
        const operand_29 = (in).braces;
        const operand_30 = (in).depth;

        break :block_33 block_32: {
            const operand_31 = (try (allocator).create(zx_type_24));

            (operand_31).* = @as(zx_type_24, zx_type_24{ .mode = operand_27, .start = operand_28, .braces = operand_29, .depth = operand_30, });

            break :block_32 @as(*const zx_type_24, operand_31);
        };
    };
    const value_3: []const *const zx_type_24 = (block_26: {
        const operand_23 = (in).frames;
        const operand_24 = value_2;
        const operand_25 = (try (allocator).alloc(*const zx_type_24, (try ((std).math).add(usize, (operand_23).len, 1))));

        @memcpy((operand_25)[0..(operand_23).len], operand_23);

        (operand_25)[(operand_23).len] = operand_24;

        break :block_26 @as(zx_type_42, .{ operand_25, {}, });
    }).@"0";

    return block_22: {
        const operand_1 = (in).source_length;
        const operand_2 = (in).warmed;
        const operand_3 = (in).ahead_one;
        const operand_4 = (in).ahead_two;
        const operand_5 = (in).keyword_state;
        const operand_6 = (in).symbol;
        const operand_7 = (in).line_break;
        const operand_8 = (in).dollar;
        const operand_9 = (in).offset;
        const operand_10 = (in).skip_until;
        const operand_11 = @as(zx_type_22, .Template);
        const operand_12 = (in).offset;
        const operand_13 = @as(u64, 0);
        const operand_14 = ((in).depth + @as(u64, 1));
        const operand_15 = value_3;
        const operand_16 = (in).number;
        const operand_17 = (in).tokens;
        const operand_18 = (in).comments;
        const operand_19 = (in).diagnostic;

        break :block_22 block_21: {
            const operand_20 = (try (allocator).create(zx_type_28));

            (operand_20).* = @as(zx_type_28, zx_type_28{ .source_length = operand_1, .warmed = operand_2, .ahead_one = operand_3, .ahead_two = operand_4, .keyword_state = operand_5, .symbol = operand_6, .line_break = operand_7, .dollar = operand_8, .offset = operand_9, .skip_until = operand_10, .mode = operand_11, .start = operand_12, .braces = operand_13, .depth = operand_14, .frames = operand_15, .number = operand_16, .tokens = operand_17, .comments = operand_18, .diagnostic = operand_19, });

            break :block_21 @as(*const zx_type_28, operand_20);
        };
    };
}

fn function_36_value(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if (((in).mode == @as(zx_type_22, .Idle))) {
        const value_1: u64 = (in).offset;

        return block_105: {
            const operand_99 = in;
            const operand_100 = @as(zx_type_22, .Template);
            const operand_101 = block_102: {
                break :block_102 value_1;
            };
            const operand_103 = @as(u64, 0);
            const operand_104 = @as(u64, 0);

            break :block_105 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_99).ahead_one, .ahead_two = (operand_99).ahead_two, .braces = operand_103, .comments = (operand_99).comments, .depth = operand_104, .diagnostic = (operand_99).diagnostic, .dollar = (operand_99).dollar, .frames = (operand_99).frames, .keyword_state = (operand_99).keyword_state, .line_break = (operand_99).line_break, .mode = operand_100, .number = (operand_99).number, .offset = (operand_99).offset, .skip_until = (operand_99).skip_until, .source_length = (operand_99).source_length, .start = operand_101, .symbol = (operand_99).symbol, .tokens = (operand_99).tokens, .warmed = (operand_99).warmed, });
        };
    }

    if ((((in).depth + @as(u64, 1)) > @as(u64, 256))) {
        return block_98: {
            break :block_98 (try function_6_value(allocator, block_97: {
                const operand_92 = @as([]const u8, "syntax");
                const operand_93 = (in).offset;
                const operand_94 = ((in).offset + @as(u64, 1));
                const operand_95 = @as([]const u8, "template nesting exceeds 256 levels");
                const operand_96 = in;

                break :block_97 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_92, .start = operand_93, .end = operand_94, .message = operand_95, .state = operand_96, });
            }));
        };
    }

    const value_2: *const zx_type_24 = block_91: {
        const operand_85 = (in).mode;
        const operand_86 = (in).start;
        const operand_87 = (in).braces;
        const operand_88 = (in).depth;

        break :block_91 block_90: {
            const operand_89 = (try (allocator).create(zx_type_24));

            (operand_89).* = @as(zx_type_24, zx_type_24{ .mode = operand_85, .start = operand_86, .braces = operand_87, .depth = operand_88, });

            break :block_90 @as(*const zx_type_24, operand_89);
        };
    };
    const value_3: []const *const zx_type_24 = (block_84: {
        const operand_80 = (in).frames;
        const operand_82 = block_81: {
            break :block_81 value_2;
        };
        const operand_83 = (try (allocator).alloc(*const zx_type_24, (try ((std).math).add(usize, (operand_80).len, 1))));

        @memcpy((operand_83)[0..(operand_80).len], operand_80);

        (operand_83)[(operand_80).len] = operand_82;

        break :block_84 @as(value_zx_type_42_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_83, {}, null, });
    }).@"0";

    return block_79: {
        const operand_59 = (in).source_length;
        const operand_60 = (in).warmed;
        const operand_61 = (in).ahead_one;
        const operand_62 = (in).ahead_two;
        const operand_63 = (in).keyword_state;
        const operand_64 = (in).symbol;
        const operand_65 = (in).line_break;
        const operand_66 = (in).dollar;
        const operand_67 = (in).offset;
        const operand_68 = (in).skip_until;
        const operand_69 = @as(zx_type_22, .Template);
        const operand_70 = (in).offset;
        const operand_71 = @as(u64, 0);
        const operand_72 = ((in).depth + @as(u64, 1));
        const operand_73 = block_74: {
            break :block_74 value_3;
        };
        const operand_75 = (in).number;
        const operand_76 = (in).tokens;
        const operand_77 = (in).comments;
        const operand_78 = (in).diagnostic;

        break :block_79 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_59, .warmed = operand_60, .ahead_one = operand_61, .ahead_two = operand_62, .keyword_state = operand_63, .symbol = operand_64, .line_break = operand_65, .dollar = operand_66, .offset = operand_67, .skip_until = operand_68, .mode = operand_69, .start = operand_70, .braces = operand_71, .depth = operand_72, .frames = operand_73, .number = operand_75, .tokens = operand_76, .comments = operand_77, .diagnostic = operand_78, });
    };
}

fn function_36_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if (((in).mode == @as(zx_type_22, .Idle))) {
        const value_1: u64 = (in).offset;

        return block_156: {
            const operand_150 = in;
            const operand_151 = @as(zx_type_22, .Template);
            const operand_152 = block_153: {
                break :block_153 value_1;
            };
            const operand_154 = @as(u64, 0);
            const operand_155 = @as(u64, 0);

            break :block_156 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_150).ahead_one, .ahead_two = (operand_150).ahead_two, .braces = operand_154, .comments = (operand_150).comments, .depth = operand_155, .diagnostic = (operand_150).diagnostic, .dollar = (operand_150).dollar, .frames = (operand_150).frames, .keyword_state = (operand_150).keyword_state, .line_break = (operand_150).line_break, .mode = operand_151, .number = (operand_150).number, .offset = (operand_150).offset, .skip_until = (operand_150).skip_until, .source_length = (operand_150).source_length, .start = operand_152, .symbol = (operand_150).symbol, .tokens = (operand_150).tokens, .warmed = (operand_150).warmed, });
        };
    }

    if ((((in).depth + @as(u64, 1)) > @as(u64, 256))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_149: {
            break :block_149 (try function_6_buffered(allocator, block_148: {
                const operand_143 = @as([]const u8, "syntax");
                const operand_144 = (in).offset;
                const operand_145 = ((in).offset + @as(u64, 1));
                const operand_146 = @as([]const u8, "template nesting exceeds 256 levels");
                const operand_147 = in;

                break :block_148 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_143, .start = operand_144, .end = operand_145, .message = operand_146, .state = operand_147, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    const value_2: *const zx_type_24 = block_142: {
        const operand_136 = (in).mode;
        const operand_137 = (in).start;
        const operand_138 = (in).braces;
        const operand_139 = (in).depth;

        break :block_142 block_141: {
            const operand_140 = (try (allocator).create(zx_type_24));

            (operand_140).* = @as(zx_type_24, zx_type_24{ .mode = operand_136, .start = operand_137, .braces = operand_138, .depth = operand_139, });

            break :block_141 @as(*const zx_type_24, operand_140);
        };
    };
    const value_3: []const *const zx_type_24 = @as([]const *const zx_type_24, (if (((buffers).lane_1 != null)) block_130: {
        const operand_127 = (in).frames;
        const operand_129 = block_128: {
            break :block_128 value_2;
        };

        _ = (try ((std).math).add(usize, (operand_127).len, 1));

        if ((!(((buffers).lane_1.?).started).*)) {
            (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_127));

            (((buffers).lane_1.?).started).* = true;
        } else {
            (((((buffers).lane_1.?).buffer).*).items).len = (operand_127).len;
        }

        (try ((((buffers).lane_1.?).buffer).*).append(allocator, operand_129));

        break :block_130 ((((buffers).lane_1.?).buffer).*).items;
    } else (block_135: {
        const operand_131 = (in).frames;
        const operand_133 = block_132: {
            break :block_132 value_2;
        };
        const operand_134 = (try (allocator).alloc(*const zx_type_24, (try ((std).math).add(usize, (operand_131).len, 1))));

        @memcpy((operand_134)[0..(operand_131).len], operand_131);

        (operand_134)[(operand_131).len] = operand_133;

        break :block_135 @as(value_zx_type_42_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_134, {}, null, });
    }).@"0"));

    return block_126: {
        const operand_106 = (in).source_length;
        const operand_107 = (in).warmed;
        const operand_108 = (in).ahead_one;
        const operand_109 = (in).ahead_two;
        const operand_110 = (in).keyword_state;
        const operand_111 = (in).symbol;
        const operand_112 = (in).line_break;
        const operand_113 = (in).dollar;
        const operand_114 = (in).offset;
        const operand_115 = (in).skip_until;
        const operand_116 = @as(zx_type_22, .Template);
        const operand_117 = (in).offset;
        const operand_118 = @as(u64, 0);
        const operand_119 = ((in).depth + @as(u64, 1));
        const operand_120 = block_121: {
            break :block_121 value_3;
        };
        const operand_122 = (in).number;
        const operand_123 = (in).tokens;
        const operand_124 = (in).comments;
        const operand_125 = (in).diagnostic;

        break :block_126 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_106, .warmed = operand_107, .ahead_one = operand_108, .ahead_two = operand_109, .keyword_state = operand_110, .symbol = operand_111, .line_break = operand_112, .dollar = operand_113, .offset = operand_114, .skip_until = operand_115, .mode = operand_116, .start = operand_117, .braces = operand_118, .depth = operand_119, .frames = operand_120, .number = operand_122, .tokens = operand_123, .comments = operand_124, .diagnostic = operand_125, });
    };
}

fn function_36_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_28, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if (((in).mode == @as(zx_type_22, .Idle))) {
        const value_1: u64 = (in).offset;

        return block_208: {
            const operand_201 = in;
            const operand_202 = @as(zx_type_22, .Template);
            const operand_203 = value_1;
            const operand_204 = @as(u64, 0);
            const operand_205 = @as(u64, 0);

            break :block_208 block_207: {
                const operand_206 = (try (allocator).create(zx_type_28));

                (operand_206).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_201).ahead_one, .ahead_two = (operand_201).ahead_two, .braces = operand_204, .comments = (operand_201).comments, .depth = operand_205, .diagnostic = (operand_201).diagnostic, .dollar = (operand_201).dollar, .frames = (operand_201).frames, .keyword_state = (operand_201).keyword_state, .line_break = (operand_201).line_break, .mode = operand_202, .number = (operand_201).number, .offset = (operand_201).offset, .skip_until = (operand_201).skip_until, .source_length = (operand_201).source_length, .start = operand_203, .symbol = (operand_201).symbol, .tokens = (operand_201).tokens, .warmed = (operand_201).warmed, });

                break :block_207 @as(*const zx_type_28, operand_206);
            };
        };
    }

    if ((((in).depth + @as(u64, 1)) > @as(u64, 256))) {
        return (try function_6_buffered_pointer(allocator, block_200: {
            const operand_193 = @as([]const u8, "syntax");
            const operand_194 = (in).offset;
            const operand_195 = ((in).offset + @as(u64, 1));
            const operand_196 = @as([]const u8, "template nesting exceeds 256 levels");
            const operand_197 = in;

            break :block_200 block_199: {
                const operand_198 = (try (allocator).create(zx_type_32));

                (operand_198).* = @as(zx_type_32, zx_type_32{ .code = operand_193, .start = operand_194, .end = operand_195, .message = operand_196, .state = operand_197, });

                break :block_199 @as(*const zx_type_32, operand_198);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    const value_2: *const zx_type_24 = block_192: {
        const operand_186 = (in).mode;
        const operand_187 = (in).start;
        const operand_188 = (in).braces;
        const operand_189 = (in).depth;

        break :block_192 block_191: {
            const operand_190 = (try (allocator).create(zx_type_24));

            (operand_190).* = @as(zx_type_24, zx_type_24{ .mode = operand_186, .start = operand_187, .braces = operand_188, .depth = operand_189, });

            break :block_191 @as(*const zx_type_24, operand_190);
        };
    };
    const value_3: []const *const zx_type_24 = @as([]const *const zx_type_24, (if (((buffers).lane_1 != null)) block_181: {
        const operand_179 = (in).frames;
        const operand_180 = value_2;

        _ = (try ((std).math).add(usize, (operand_179).len, 1));

        if ((!(((buffers).lane_1.?).started).*)) {
            (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_179));

            (((buffers).lane_1.?).started).* = true;
        } else {
            (((((buffers).lane_1.?).buffer).*).items).len = (operand_179).len;
        }

        (try ((((buffers).lane_1.?).buffer).*).append(allocator, operand_180));

        break :block_181 ((((buffers).lane_1.?).buffer).*).items;
    } else (block_185: {
        const operand_182 = (in).frames;
        const operand_183 = value_2;
        const operand_184 = (try (allocator).alloc(*const zx_type_24, (try ((std).math).add(usize, (operand_182).len, 1))));

        @memcpy((operand_184)[0..(operand_182).len], operand_182);

        (operand_184)[(operand_182).len] = operand_183;

        break :block_185 @as(zx_type_42, .{ operand_184, {}, });
    }).@"0"));

    return block_178: {
        const operand_157 = (in).source_length;
        const operand_158 = (in).warmed;
        const operand_159 = (in).ahead_one;
        const operand_160 = (in).ahead_two;
        const operand_161 = (in).keyword_state;
        const operand_162 = (in).symbol;
        const operand_163 = (in).line_break;
        const operand_164 = (in).dollar;
        const operand_165 = (in).offset;
        const operand_166 = (in).skip_until;
        const operand_167 = @as(zx_type_22, .Template);
        const operand_168 = (in).offset;
        const operand_169 = @as(u64, 0);
        const operand_170 = ((in).depth + @as(u64, 1));
        const operand_171 = value_3;
        const operand_172 = (in).number;
        const operand_173 = (in).tokens;
        const operand_174 = (in).comments;
        const operand_175 = (in).diagnostic;

        break :block_178 block_177: {
            const operand_176 = (try (allocator).create(zx_type_28));

            (operand_176).* = @as(zx_type_28, zx_type_28{ .source_length = operand_157, .warmed = operand_158, .ahead_one = operand_159, .ahead_two = operand_160, .keyword_state = operand_161, .symbol = operand_162, .line_break = operand_163, .dollar = operand_164, .offset = operand_165, .skip_until = operand_166, .mode = operand_167, .start = operand_168, .braces = operand_169, .depth = operand_170, .frames = operand_171, .number = operand_172, .tokens = operand_173, .comments = operand_174, .diagnostic = operand_175, });

            break :block_177 @as(*const zx_type_28, operand_176);
        };
    };
}

fn function_37(allocator: ((std).mem).Allocator, in: *const zx_type_29) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((in).state).line_break or ((in).byte == @as(u8, 10))) or ((in).byte == @as(u8, 13)));
    const value_2: u64 = ((in).state).offset;

    if ((((in).byte == @as(u8, 32)) or (((in).byte >= @as(u8, 9)) and ((in).byte <= @as(u8, 13))))) {
        return block_105: {
            const operand_101 = (in).state;
            const operand_102 = value_1;

            break :block_105 block_104: {
                const operand_103 = (try (allocator).create(zx_type_28));

                (operand_103).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_101).ahead_one, .ahead_two = (operand_101).ahead_two, .braces = (operand_101).braces, .comments = (operand_101).comments, .depth = (operand_101).depth, .diagnostic = (operand_101).diagnostic, .dollar = (operand_101).dollar, .frames = (operand_101).frames, .keyword_state = (operand_101).keyword_state, .line_break = operand_102, .mode = (operand_101).mode, .number = (operand_101).number, .offset = (operand_101).offset, .skip_until = (operand_101).skip_until, .source_length = (operand_101).source_length, .start = (operand_101).start, .symbol = (operand_101).symbol, .tokens = (operand_101).tokens, .warmed = (operand_101).warmed, });

                break :block_104 @as(*const zx_type_28, operand_103);
            };
        };
    }

    if ((((in).byte == @as(u8, 47)) and (in).has_next)) {
        const value_3: u8 = (in).next;

        if (((value_3 == @as(u8, 47)) or (value_3 == @as(u8, 42)))) {
            const value_4: u64 = (value_2 + @as(u64, 2));

            return block_100: {
                const operand_94 = (in).state;
                const operand_95 = value_4;
                const operand_96 = (if ((value_3 == @as(u8, 47))) @as(zx_type_22, .LineComment) else @as(zx_type_22, .BlockComment));
                const operand_97 = value_2;

                break :block_100 block_99: {
                    const operand_98 = (try (allocator).create(zx_type_28));

                    (operand_98).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_94).ahead_one, .ahead_two = (operand_94).ahead_two, .braces = (operand_94).braces, .comments = (operand_94).comments, .depth = (operand_94).depth, .diagnostic = (operand_94).diagnostic, .dollar = (operand_94).dollar, .frames = (operand_94).frames, .keyword_state = (operand_94).keyword_state, .line_break = (operand_94).line_break, .mode = operand_96, .number = (operand_94).number, .offset = (operand_94).offset, .skip_until = operand_95, .source_length = (operand_94).source_length, .start = operand_97, .symbol = (operand_94).symbol, .tokens = (operand_94).tokens, .warmed = (operand_94).warmed, });

                    break :block_99 @as(*const zx_type_28, operand_98);
                };
            };
        }
    }

    if ((((try function_7(allocator, (in).byte)) or ((in).byte == @as(u8, 95))) or ((in).byte == @as(u8, 36)))) {
        return block_93: {
            const operand_82 = (in).state;
            const operand_83 = block_87: {
                const operand_84 = @as(u64, 0);
                const operand_85 = (in).byte;
                const operand_86 = zx_type_33{ .state = operand_84, .byte = operand_85, };

                break :block_87 (try function_32(allocator, (&operand_86)));
            };
            const operand_88 = ((in).byte == @as(u8, 36));
            const operand_89 = @as(zx_type_22, .Identifier);
            const operand_90 = value_2;

            break :block_93 block_92: {
                const operand_91 = (try (allocator).create(zx_type_28));

                (operand_91).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_82).ahead_one, .ahead_two = (operand_82).ahead_two, .braces = (operand_82).braces, .comments = (operand_82).comments, .depth = (operand_82).depth, .diagnostic = (operand_82).diagnostic, .dollar = operand_88, .frames = (operand_82).frames, .keyword_state = operand_83, .line_break = (operand_82).line_break, .mode = operand_89, .number = (operand_82).number, .offset = (operand_82).offset, .skip_until = (operand_82).skip_until, .source_length = (operand_82).source_length, .start = operand_90, .symbol = (operand_82).symbol, .tokens = (operand_82).tokens, .warmed = (operand_82).warmed, });

                break :block_92 @as(*const zx_type_28, operand_91);
            };
        };
    }

    if ((try function_33(allocator, (in).byte))) {
        return block_81: {
            const operand_68 = (in).state;
            const operand_69 = @as(zx_type_22, .Number);
            const operand_70 = value_2;
            const operand_71 = block_78: {
                const operand_72 = @as(u64, 1);
                const operand_73 = @as(zx_type_19, .Integer);
                const operand_74 = (in).byte;
                const operand_75 = true;

                break :block_78 block_77: {
                    const operand_76 = (try (allocator).create(zx_type_20));

                    (operand_76).* = @as(zx_type_20, zx_type_20{ .end = operand_72, .phase = operand_73, .last_byte = operand_74, .separators_valid = operand_75, });

                    break :block_77 @as(*const zx_type_20, operand_76);
                };
            };

            break :block_81 block_80: {
                const operand_79 = (try (allocator).create(zx_type_28));

                (operand_79).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_68).ahead_one, .ahead_two = (operand_68).ahead_two, .braces = (operand_68).braces, .comments = (operand_68).comments, .depth = (operand_68).depth, .diagnostic = (operand_68).diagnostic, .dollar = (operand_68).dollar, .frames = (operand_68).frames, .keyword_state = (operand_68).keyword_state, .line_break = (operand_68).line_break, .mode = operand_69, .number = operand_71, .offset = (operand_68).offset, .skip_until = (operand_68).skip_until, .source_length = (operand_68).source_length, .start = operand_70, .symbol = (operand_68).symbol, .tokens = (operand_68).tokens, .warmed = (operand_68).warmed, });

                break :block_80 @as(*const zx_type_28, operand_79);
            };
        };
    }

    if (((in).byte == @as(u8, 34))) {
        return block_67: {
            const operand_62 = (in).state;
            const operand_63 = @as(zx_type_22, .String);
            const operand_64 = value_2;

            break :block_67 block_66: {
                const operand_65 = (try (allocator).create(zx_type_28));

                (operand_65).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_62).ahead_one, .ahead_two = (operand_62).ahead_two, .braces = (operand_62).braces, .comments = (operand_62).comments, .depth = (operand_62).depth, .diagnostic = (operand_62).diagnostic, .dollar = (operand_62).dollar, .frames = (operand_62).frames, .keyword_state = (operand_62).keyword_state, .line_break = (operand_62).line_break, .mode = operand_63, .number = (operand_62).number, .offset = (operand_62).offset, .skip_until = (operand_62).skip_until, .source_length = (operand_62).source_length, .start = operand_64, .symbol = (operand_62).symbol, .tokens = (operand_62).tokens, .warmed = (operand_62).warmed, });

                break :block_66 @as(*const zx_type_28, operand_65);
            };
        };
    }

    if (((in).byte == @as(u8, 96))) {
        return block_61: {
            const operand_53 = (in).state;
            const operand_54 = (try function_36_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_53).ahead_one, .ahead_two = (operand_53).ahead_two, .braces = (operand_53).braces, .comments = (operand_53).comments, .depth = (operand_53).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_53).diagnostic).code, .end = ((operand_53).diagnostic).end, .message = ((operand_53).diagnostic).message, .start = ((operand_53).diagnostic).start, .zx_origin = (operand_53).diagnostic, }, .dollar = (operand_53).dollar, .frames = (operand_53).frames, .keyword_state = (operand_53).keyword_state, .line_break = (operand_53).line_break, .mode = (operand_53).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_53).number).end, .last_byte = ((operand_53).number).last_byte, .phase = ((operand_53).number).phase, .separators_valid = ((operand_53).number).separators_valid, .zx_origin = (operand_53).number, }, .offset = (operand_53).offset, .skip_until = (operand_53).skip_until, .source_length = (operand_53).source_length, .start = (operand_53).start, .symbol = (operand_53).symbol, .tokens = (operand_53).tokens, .warmed = (operand_53).warmed, .zx_origin = operand_53, }));

            break :block_61 (if (((operand_54).zx_origin != null)) (operand_54).zx_origin.? else block_60: {
                const operand_59 = (try (allocator).create(zx_type_28));

                (operand_59).* = zx_type_28{ .ahead_one = (operand_54).ahead_one, .ahead_two = (operand_54).ahead_two, .braces = (operand_54).braces, .comments = (operand_54).comments, .depth = (operand_54).depth, .diagnostic = (if ((((operand_54).diagnostic).zx_origin != null)) ((operand_54).diagnostic).zx_origin.? else block_56: {
                    const operand_55 = (try (allocator).create(zx_type_23));

                    (operand_55).* = zx_type_23{ .code = ((operand_54).diagnostic).code, .end = ((operand_54).diagnostic).end, .message = ((operand_54).diagnostic).message, .start = ((operand_54).diagnostic).start, };

                    break :block_56 @as(*const zx_type_23, operand_55);
                }), .dollar = (operand_54).dollar, .frames = (operand_54).frames, .keyword_state = (operand_54).keyword_state, .line_break = (operand_54).line_break, .mode = (operand_54).mode, .number = (if ((((operand_54).number).zx_origin != null)) ((operand_54).number).zx_origin.? else block_58: {
                    const operand_57 = (try (allocator).create(zx_type_20));

                    (operand_57).* = zx_type_20{ .end = ((operand_54).number).end, .last_byte = ((operand_54).number).last_byte, .phase = ((operand_54).number).phase, .separators_valid = ((operand_54).number).separators_valid, };

                    break :block_58 @as(*const zx_type_20, operand_57);
                }), .offset = (operand_54).offset, .skip_until = (operand_54).skip_until, .source_length = (operand_54).source_length, .start = (operand_54).start, .symbol = (operand_54).symbol, .tokens = (operand_54).tokens, .warmed = (operand_54).warmed, };

                break :block_60 @as(*const zx_type_28, operand_59);
            });
        };
    }

    if ((!(try function_8(allocator, (in).byte)))) {
        return block_52: {
            const operand_44 = block_43: {
                const operand_36 = @as([]const u8, "lexical");
                const operand_37 = value_2;
                const operand_38 = (value_2 + @as(u64, 1));
                const operand_39 = @as([]const u8, "unexpected character");
                const operand_40 = (in).state;

                break :block_43 block_42: {
                    const operand_41 = (try (allocator).create(zx_type_32));

                    (operand_41).* = @as(zx_type_32, zx_type_32{ .code = operand_36, .start = operand_37, .end = operand_38, .message = operand_39, .state = operand_40, });

                    break :block_42 @as(*const zx_type_32, operand_41);
                };
            };
            const operand_45 = (try function_6_value(allocator, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = (operand_44).code, .end = (operand_44).end, .message = (operand_44).message, .start = (operand_44).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_44).state).ahead_one, .ahead_two = ((operand_44).state).ahead_two, .braces = ((operand_44).state).braces, .comments = ((operand_44).state).comments, .depth = ((operand_44).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_44).state).diagnostic).code, .end = (((operand_44).state).diagnostic).end, .message = (((operand_44).state).diagnostic).message, .start = (((operand_44).state).diagnostic).start, .zx_origin = ((operand_44).state).diagnostic, }, .dollar = ((operand_44).state).dollar, .frames = ((operand_44).state).frames, .keyword_state = ((operand_44).state).keyword_state, .line_break = ((operand_44).state).line_break, .mode = ((operand_44).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_44).state).number).end, .last_byte = (((operand_44).state).number).last_byte, .phase = (((operand_44).state).number).phase, .separators_valid = (((operand_44).state).number).separators_valid, .zx_origin = ((operand_44).state).number, }, .offset = ((operand_44).state).offset, .skip_until = ((operand_44).state).skip_until, .source_length = ((operand_44).state).source_length, .start = ((operand_44).state).start, .symbol = ((operand_44).state).symbol, .tokens = ((operand_44).state).tokens, .warmed = ((operand_44).state).warmed, .zx_origin = (operand_44).state, }, .zx_origin = operand_44, }));

            break :block_52 (if (((operand_45).zx_origin != null)) (operand_45).zx_origin.? else block_51: {
                const operand_50 = (try (allocator).create(zx_type_28));

                (operand_50).* = zx_type_28{ .ahead_one = (operand_45).ahead_one, .ahead_two = (operand_45).ahead_two, .braces = (operand_45).braces, .comments = (operand_45).comments, .depth = (operand_45).depth, .diagnostic = (if ((((operand_45).diagnostic).zx_origin != null)) ((operand_45).diagnostic).zx_origin.? else block_47: {
                    const operand_46 = (try (allocator).create(zx_type_23));

                    (operand_46).* = zx_type_23{ .code = ((operand_45).diagnostic).code, .end = ((operand_45).diagnostic).end, .message = ((operand_45).diagnostic).message, .start = ((operand_45).diagnostic).start, };

                    break :block_47 @as(*const zx_type_23, operand_46);
                }), .dollar = (operand_45).dollar, .frames = (operand_45).frames, .keyword_state = (operand_45).keyword_state, .line_break = (operand_45).line_break, .mode = (operand_45).mode, .number = (if ((((operand_45).number).zx_origin != null)) ((operand_45).number).zx_origin.? else block_49: {
                    const operand_48 = (try (allocator).create(zx_type_20));

                    (operand_48).* = zx_type_20{ .end = ((operand_45).number).end, .last_byte = ((operand_45).number).last_byte, .phase = ((operand_45).number).phase, .separators_valid = ((operand_45).number).separators_valid, };

                    break :block_49 @as(*const zx_type_20, operand_48);
                }), .offset = (operand_45).offset, .skip_until = (operand_45).skip_until, .source_length = (operand_45).source_length, .start = (operand_45).start, .symbol = (operand_45).symbol, .tokens = (operand_45).tokens, .warmed = (operand_45).warmed, };

                break :block_51 @as(*const zx_type_28, operand_50);
            });
        };
    }

    const value_5: u64 = block_35: {
        const operand_29 = (in).byte;
        const operand_30 = (in).next;
        const operand_31 = (in).after;
        const operand_32 = (in).has_next;
        const operand_33 = (in).has_after;
        const operand_34 = zx_type_34{ .byte = operand_29, .next = operand_30, .after = operand_31, .has_next = operand_32, .has_after = operand_33, };

        break :block_35 (try function_34(allocator, (&operand_34)));
    };
    const value_6: zx_type_16 = block_28: {
        const operand_24 = (in).byte;
        const operand_25 = (in).next;
        const operand_26 = value_5;
        const operand_27 = zx_type_35{ .byte = operand_24, .next = operand_25, .length = operand_26, };

        break :block_28 (try function_35(allocator, (&operand_27)));
    };
    const value_7: u64 = (value_2 + value_5);

    return block_23: {
        const operand_15 = block_14: {
            const operand_1 = @as([]const u8, "punctuation");
            const operand_2 = value_2;
            const operand_3 = (value_2 + value_5);
            const operand_4 = false;
            const operand_5 = block_11: {
                const operand_6 = (in).state;
                const operand_7 = value_6;
                const operand_8 = value_7;

                break :block_11 block_10: {
                    const operand_9 = (try (allocator).create(zx_type_28));

                    (operand_9).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_6).ahead_one, .ahead_two = (operand_6).ahead_two, .braces = (operand_6).braces, .comments = (operand_6).comments, .depth = (operand_6).depth, .diagnostic = (operand_6).diagnostic, .dollar = (operand_6).dollar, .frames = (operand_6).frames, .keyword_state = (operand_6).keyword_state, .line_break = (operand_6).line_break, .mode = (operand_6).mode, .number = (operand_6).number, .offset = (operand_6).offset, .skip_until = operand_8, .source_length = (operand_6).source_length, .start = (operand_6).start, .symbol = operand_7, .tokens = (operand_6).tokens, .warmed = (operand_6).warmed, });

                    break :block_10 @as(*const zx_type_28, operand_9);
                };
            };

            break :block_14 block_13: {
                const operand_12 = (try (allocator).create(zx_type_31));

                (operand_12).* = @as(zx_type_31, zx_type_31{ .kind = operand_1, .start = operand_2, .end = operand_3, .comment = operand_4, .state = operand_5, });

                break :block_13 @as(*const zx_type_31, operand_12);
            };
        };
        const operand_16 = (try function_5_value(allocator, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .comment = (operand_15).comment, .end = (operand_15).end, .kind = (operand_15).kind, .start = (operand_15).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_15).state).ahead_one, .ahead_two = ((operand_15).state).ahead_two, .braces = ((operand_15).state).braces, .comments = ((operand_15).state).comments, .depth = ((operand_15).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_15).state).diagnostic).code, .end = (((operand_15).state).diagnostic).end, .message = (((operand_15).state).diagnostic).message, .start = (((operand_15).state).diagnostic).start, .zx_origin = ((operand_15).state).diagnostic, }, .dollar = ((operand_15).state).dollar, .frames = ((operand_15).state).frames, .keyword_state = ((operand_15).state).keyword_state, .line_break = ((operand_15).state).line_break, .mode = ((operand_15).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_15).state).number).end, .last_byte = (((operand_15).state).number).last_byte, .phase = (((operand_15).state).number).phase, .separators_valid = (((operand_15).state).number).separators_valid, .zx_origin = ((operand_15).state).number, }, .offset = ((operand_15).state).offset, .skip_until = ((operand_15).state).skip_until, .source_length = ((operand_15).state).source_length, .start = ((operand_15).state).start, .symbol = ((operand_15).state).symbol, .tokens = ((operand_15).state).tokens, .warmed = ((operand_15).state).warmed, .zx_origin = (operand_15).state, }, .zx_origin = operand_15, }));

        break :block_23 (if (((operand_16).zx_origin != null)) (operand_16).zx_origin.? else block_22: {
            const operand_21 = (try (allocator).create(zx_type_28));

            (operand_21).* = zx_type_28{ .ahead_one = (operand_16).ahead_one, .ahead_two = (operand_16).ahead_two, .braces = (operand_16).braces, .comments = (operand_16).comments, .depth = (operand_16).depth, .diagnostic = (if ((((operand_16).diagnostic).zx_origin != null)) ((operand_16).diagnostic).zx_origin.? else block_18: {
                const operand_17 = (try (allocator).create(zx_type_23));

                (operand_17).* = zx_type_23{ .code = ((operand_16).diagnostic).code, .end = ((operand_16).diagnostic).end, .message = ((operand_16).diagnostic).message, .start = ((operand_16).diagnostic).start, };

                break :block_18 @as(*const zx_type_23, operand_17);
            }), .dollar = (operand_16).dollar, .frames = (operand_16).frames, .keyword_state = (operand_16).keyword_state, .line_break = (operand_16).line_break, .mode = (operand_16).mode, .number = (if ((((operand_16).number).zx_origin != null)) ((operand_16).number).zx_origin.? else block_20: {
                const operand_19 = (try (allocator).create(zx_type_20));

                (operand_19).* = zx_type_20{ .end = ((operand_16).number).end, .last_byte = ((operand_16).number).last_byte, .phase = ((operand_16).number).phase, .separators_valid = ((operand_16).number).separators_valid, };

                break :block_20 @as(*const zx_type_20, operand_19);
            }), .offset = (operand_16).offset, .skip_until = (operand_16).skip_until, .source_length = (operand_16).source_length, .start = (operand_16).start, .symbol = (operand_16).symbol, .tokens = (operand_16).tokens, .warmed = (operand_16).warmed, };

            break :block_22 @as(*const zx_type_28, operand_21);
        });
    };
}

fn function_37_value(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((in).state).line_break or ((in).byte == @as(u8, 10))) or ((in).byte == @as(u8, 13)));
    const value_2: u64 = ((in).state).offset;

    if ((((in).byte == @as(u8, 32)) or (((in).byte >= @as(u8, 9)) and ((in).byte <= @as(u8, 13))))) {
        return block_188: {
            const operand_185 = (in).state;
            const operand_186 = block_187: {
                break :block_187 value_1;
            };

            break :block_188 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_185).ahead_one, .ahead_two = (operand_185).ahead_two, .braces = (operand_185).braces, .comments = (operand_185).comments, .depth = (operand_185).depth, .diagnostic = (operand_185).diagnostic, .dollar = (operand_185).dollar, .frames = (operand_185).frames, .keyword_state = (operand_185).keyword_state, .line_break = operand_186, .mode = (operand_185).mode, .number = (operand_185).number, .offset = (operand_185).offset, .skip_until = (operand_185).skip_until, .source_length = (operand_185).source_length, .start = (operand_185).start, .symbol = (operand_185).symbol, .tokens = (operand_185).tokens, .warmed = (operand_185).warmed, });
        };
    }

    if ((((in).byte == @as(u8, 47)) and (in).has_next)) {
        const value_3: u8 = (in).next;

        if (((block_174: {
            break :block_174 value_3;
        } == @as(u8, 47)) or (block_175: {
            break :block_175 value_3;
        } == @as(u8, 42)))) {
            const value_4: u64 = (block_184: {
                break :block_184 value_2;
            } + @as(u64, 2));

            return block_183: {
                const operand_176 = (in).state;
                const operand_177 = block_178: {
                    break :block_178 value_4;
                };
                const operand_179 = (if ((block_180: {
                    break :block_180 value_3;
                } == @as(u8, 47))) @as(zx_type_22, .LineComment) else @as(zx_type_22, .BlockComment));
                const operand_181 = block_182: {
                    break :block_182 value_2;
                };

                break :block_183 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_176).ahead_one, .ahead_two = (operand_176).ahead_two, .braces = (operand_176).braces, .comments = (operand_176).comments, .depth = (operand_176).depth, .diagnostic = (operand_176).diagnostic, .dollar = (operand_176).dollar, .frames = (operand_176).frames, .keyword_state = (operand_176).keyword_state, .line_break = (operand_176).line_break, .mode = operand_179, .number = (operand_176).number, .offset = (operand_176).offset, .skip_until = operand_177, .source_length = (operand_176).source_length, .start = operand_181, .symbol = (operand_176).symbol, .tokens = (operand_176).tokens, .warmed = (operand_176).warmed, });
            };
        }
    }

    if ((((try function_7(allocator, (in).byte)) or ((in).byte == @as(u8, 95))) or ((in).byte == @as(u8, 36)))) {
        return block_173: {
            const operand_163 = (in).state;
            const operand_164 = block_168: {
                const operand_165 = @as(u64, 0);
                const operand_166 = (in).byte;
                const operand_167 = zx_type_33{ .state = operand_165, .byte = operand_166, };

                break :block_168 (try function_32(allocator, (&operand_167)));
            };
            const operand_169 = ((in).byte == @as(u8, 36));
            const operand_170 = @as(zx_type_22, .Identifier);
            const operand_171 = block_172: {
                break :block_172 value_2;
            };

            break :block_173 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_163).ahead_one, .ahead_two = (operand_163).ahead_two, .braces = (operand_163).braces, .comments = (operand_163).comments, .depth = (operand_163).depth, .diagnostic = (operand_163).diagnostic, .dollar = operand_169, .frames = (operand_163).frames, .keyword_state = operand_164, .line_break = (operand_163).line_break, .mode = operand_170, .number = (operand_163).number, .offset = (operand_163).offset, .skip_until = (operand_163).skip_until, .source_length = (operand_163).source_length, .start = operand_171, .symbol = (operand_163).symbol, .tokens = (operand_163).tokens, .warmed = (operand_163).warmed, });
        };
    }

    if ((try function_33(allocator, (in).byte))) {
        return block_162: {
            const operand_152 = (in).state;
            const operand_153 = @as(zx_type_22, .Number);
            const operand_154 = block_155: {
                break :block_155 value_2;
            };
            const operand_156 = block_161: {
                const operand_157 = @as(u64, 1);
                const operand_158 = @as(zx_type_19, .Integer);
                const operand_159 = (in).byte;
                const operand_160 = true;

                break :block_161 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = operand_157, .phase = operand_158, .last_byte = operand_159, .separators_valid = operand_160, });
            };

            break :block_162 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_152).ahead_one, .ahead_two = (operand_152).ahead_two, .braces = (operand_152).braces, .comments = (operand_152).comments, .depth = (operand_152).depth, .diagnostic = (operand_152).diagnostic, .dollar = (operand_152).dollar, .frames = (operand_152).frames, .keyword_state = (operand_152).keyword_state, .line_break = (operand_152).line_break, .mode = operand_153, .number = operand_156, .offset = (operand_152).offset, .skip_until = (operand_152).skip_until, .source_length = (operand_152).source_length, .start = operand_154, .symbol = (operand_152).symbol, .tokens = (operand_152).tokens, .warmed = (operand_152).warmed, });
        };
    }

    if (((in).byte == @as(u8, 34))) {
        return block_151: {
            const operand_147 = (in).state;
            const operand_148 = @as(zx_type_22, .String);
            const operand_149 = block_150: {
                break :block_150 value_2;
            };

            break :block_151 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_147).ahead_one, .ahead_two = (operand_147).ahead_two, .braces = (operand_147).braces, .comments = (operand_147).comments, .depth = (operand_147).depth, .diagnostic = (operand_147).diagnostic, .dollar = (operand_147).dollar, .frames = (operand_147).frames, .keyword_state = (operand_147).keyword_state, .line_break = (operand_147).line_break, .mode = operand_148, .number = (operand_147).number, .offset = (operand_147).offset, .skip_until = (operand_147).skip_until, .source_length = (operand_147).source_length, .start = operand_149, .symbol = (operand_147).symbol, .tokens = (operand_147).tokens, .warmed = (operand_147).warmed, });
        };
    }

    if (((in).byte == @as(u8, 96))) {
        return block_146: {
            break :block_146 (try function_36_value(allocator, (in).state));
        };
    }

    if ((!(try function_8(allocator, (in).byte)))) {
        return block_145: {
            break :block_145 (try function_6_value(allocator, block_144: {
                const operand_137 = @as([]const u8, "lexical");
                const operand_138 = block_139: {
                    break :block_139 value_2;
                };
                const operand_140 = (block_141: {
                    break :block_141 value_2;
                } + @as(u64, 1));
                const operand_142 = @as([]const u8, "unexpected character");
                const operand_143 = (in).state;

                break :block_144 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_137, .start = operand_138, .end = operand_140, .message = operand_142, .state = operand_143, });
            }));
        };
    }

    const value_5: u64 = block_136: {
        const operand_130 = (in).byte;
        const operand_131 = (in).next;
        const operand_132 = (in).after;
        const operand_133 = (in).has_next;
        const operand_134 = (in).has_after;
        const operand_135 = zx_type_34{ .byte = operand_130, .next = operand_131, .after = operand_132, .has_next = operand_133, .has_after = operand_134, };

        break :block_136 (try function_34(allocator, (&operand_135)));
    };
    const value_6: zx_type_16 = block_129: {
        const operand_124 = (in).byte;
        const operand_125 = (in).next;
        const operand_127 = block_126: {
            break :block_126 value_5;
        };
        const operand_128 = zx_type_35{ .byte = operand_124, .next = operand_125, .length = operand_127, };

        break :block_129 (try function_35(allocator, (&operand_128)));
    };
    const value_7: u64 = (block_122: {
        break :block_122 value_2;
    } + block_123: {
        break :block_123 value_5;
    });

    return block_121: {
        break :block_121 (try function_5_value(allocator, block_120: {
            const operand_106 = @as([]const u8, "punctuation");
            const operand_107 = block_108: {
                break :block_108 value_2;
            };
            const operand_109 = (block_110: {
                break :block_110 value_2;
            } + block_111: {
                break :block_111 value_5;
            });
            const operand_112 = false;
            const operand_113 = block_119: {
                const operand_114 = (in).state;
                const operand_115 = block_116: {
                    break :block_116 value_6;
                };
                const operand_117 = block_118: {
                    break :block_118 value_7;
                };

                break :block_119 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_114).ahead_one, .ahead_two = (operand_114).ahead_two, .braces = (operand_114).braces, .comments = (operand_114).comments, .depth = (operand_114).depth, .diagnostic = (operand_114).diagnostic, .dollar = (operand_114).dollar, .frames = (operand_114).frames, .keyword_state = (operand_114).keyword_state, .line_break = (operand_114).line_break, .mode = (operand_114).mode, .number = (operand_114).number, .offset = (operand_114).offset, .skip_until = operand_117, .source_length = (operand_114).source_length, .start = (operand_114).start, .symbol = operand_115, .tokens = (operand_114).tokens, .warmed = (operand_114).warmed, });
            };

            break :block_120 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_106, .start = operand_107, .end = operand_109, .comment = operand_112, .state = operand_113, });
        }));
    };
}

fn function_37_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((in).state).line_break or ((in).byte == @as(u8, 10))) or ((in).byte == @as(u8, 13)));
    const value_2: u64 = ((in).state).offset;

    if ((((in).byte == @as(u8, 32)) or (((in).byte >= @as(u8, 9)) and ((in).byte <= @as(u8, 13))))) {
        return block_271: {
            const operand_268 = (in).state;
            const operand_269 = block_270: {
                break :block_270 value_1;
            };

            break :block_271 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_268).ahead_one, .ahead_two = (operand_268).ahead_two, .braces = (operand_268).braces, .comments = (operand_268).comments, .depth = (operand_268).depth, .diagnostic = (operand_268).diagnostic, .dollar = (operand_268).dollar, .frames = (operand_268).frames, .keyword_state = (operand_268).keyword_state, .line_break = operand_269, .mode = (operand_268).mode, .number = (operand_268).number, .offset = (operand_268).offset, .skip_until = (operand_268).skip_until, .source_length = (operand_268).source_length, .start = (operand_268).start, .symbol = (operand_268).symbol, .tokens = (operand_268).tokens, .warmed = (operand_268).warmed, });
        };
    }

    if ((((in).byte == @as(u8, 47)) and (in).has_next)) {
        const value_3: u8 = (in).next;

        if (((block_257: {
            break :block_257 value_3;
        } == @as(u8, 47)) or (block_258: {
            break :block_258 value_3;
        } == @as(u8, 42)))) {
            const value_4: u64 = (block_267: {
                break :block_267 value_2;
            } + @as(u64, 2));

            return block_266: {
                const operand_259 = (in).state;
                const operand_260 = block_261: {
                    break :block_261 value_4;
                };
                const operand_262 = (if ((block_263: {
                    break :block_263 value_3;
                } == @as(u8, 47))) @as(zx_type_22, .LineComment) else @as(zx_type_22, .BlockComment));
                const operand_264 = block_265: {
                    break :block_265 value_2;
                };

                break :block_266 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_259).ahead_one, .ahead_two = (operand_259).ahead_two, .braces = (operand_259).braces, .comments = (operand_259).comments, .depth = (operand_259).depth, .diagnostic = (operand_259).diagnostic, .dollar = (operand_259).dollar, .frames = (operand_259).frames, .keyword_state = (operand_259).keyword_state, .line_break = (operand_259).line_break, .mode = operand_262, .number = (operand_259).number, .offset = (operand_259).offset, .skip_until = operand_260, .source_length = (operand_259).source_length, .start = operand_264, .symbol = (operand_259).symbol, .tokens = (operand_259).tokens, .warmed = (operand_259).warmed, });
            };
        }
    }

    if ((((try function_7(allocator, (in).byte)) or ((in).byte == @as(u8, 95))) or ((in).byte == @as(u8, 36)))) {
        return block_256: {
            const operand_246 = (in).state;
            const operand_247 = block_251: {
                const operand_248 = @as(u64, 0);
                const operand_249 = (in).byte;
                const operand_250 = zx_type_33{ .state = operand_248, .byte = operand_249, };

                break :block_251 (try function_32(allocator, (&operand_250)));
            };
            const operand_252 = ((in).byte == @as(u8, 36));
            const operand_253 = @as(zx_type_22, .Identifier);
            const operand_254 = block_255: {
                break :block_255 value_2;
            };

            break :block_256 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_246).ahead_one, .ahead_two = (operand_246).ahead_two, .braces = (operand_246).braces, .comments = (operand_246).comments, .depth = (operand_246).depth, .diagnostic = (operand_246).diagnostic, .dollar = operand_252, .frames = (operand_246).frames, .keyword_state = operand_247, .line_break = (operand_246).line_break, .mode = operand_253, .number = (operand_246).number, .offset = (operand_246).offset, .skip_until = (operand_246).skip_until, .source_length = (operand_246).source_length, .start = operand_254, .symbol = (operand_246).symbol, .tokens = (operand_246).tokens, .warmed = (operand_246).warmed, });
        };
    }

    if ((try function_33(allocator, (in).byte))) {
        return block_245: {
            const operand_235 = (in).state;
            const operand_236 = @as(zx_type_22, .Number);
            const operand_237 = block_238: {
                break :block_238 value_2;
            };
            const operand_239 = block_244: {
                const operand_240 = @as(u64, 1);
                const operand_241 = @as(zx_type_19, .Integer);
                const operand_242 = (in).byte;
                const operand_243 = true;

                break :block_244 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = operand_240, .phase = operand_241, .last_byte = operand_242, .separators_valid = operand_243, });
            };

            break :block_245 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_235).ahead_one, .ahead_two = (operand_235).ahead_two, .braces = (operand_235).braces, .comments = (operand_235).comments, .depth = (operand_235).depth, .diagnostic = (operand_235).diagnostic, .dollar = (operand_235).dollar, .frames = (operand_235).frames, .keyword_state = (operand_235).keyword_state, .line_break = (operand_235).line_break, .mode = operand_236, .number = operand_239, .offset = (operand_235).offset, .skip_until = (operand_235).skip_until, .source_length = (operand_235).source_length, .start = operand_237, .symbol = (operand_235).symbol, .tokens = (operand_235).tokens, .warmed = (operand_235).warmed, });
        };
    }

    if (((in).byte == @as(u8, 34))) {
        return block_234: {
            const operand_230 = (in).state;
            const operand_231 = @as(zx_type_22, .String);
            const operand_232 = block_233: {
                break :block_233 value_2;
            };

            break :block_234 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_230).ahead_one, .ahead_two = (operand_230).ahead_two, .braces = (operand_230).braces, .comments = (operand_230).comments, .depth = (operand_230).depth, .diagnostic = (operand_230).diagnostic, .dollar = (operand_230).dollar, .frames = (operand_230).frames, .keyword_state = (operand_230).keyword_state, .line_break = (operand_230).line_break, .mode = operand_231, .number = (operand_230).number, .offset = (operand_230).offset, .skip_until = (operand_230).skip_until, .source_length = (operand_230).source_length, .start = operand_232, .symbol = (operand_230).symbol, .tokens = (operand_230).tokens, .warmed = (operand_230).warmed, });
        };
    }

    if (((in).byte == @as(u8, 96))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_229: {
            break :block_229 (try function_36_buffered(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if ((!(try function_8(allocator, (in).byte)))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_228: {
            break :block_228 (try function_6_buffered(allocator, block_227: {
                const operand_220 = @as([]const u8, "lexical");
                const operand_221 = block_222: {
                    break :block_222 value_2;
                };
                const operand_223 = (block_224: {
                    break :block_224 value_2;
                } + @as(u64, 1));
                const operand_225 = @as([]const u8, "unexpected character");
                const operand_226 = (in).state;

                break :block_227 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_220, .start = operand_221, .end = operand_223, .message = operand_225, .state = operand_226, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    const value_5: u64 = block_219: {
        const operand_213 = (in).byte;
        const operand_214 = (in).next;
        const operand_215 = (in).after;
        const operand_216 = (in).has_next;
        const operand_217 = (in).has_after;
        const operand_218 = zx_type_34{ .byte = operand_213, .next = operand_214, .after = operand_215, .has_next = operand_216, .has_after = operand_217, };

        break :block_219 (try function_34(allocator, (&operand_218)));
    };
    const value_6: zx_type_16 = block_212: {
        const operand_207 = (in).byte;
        const operand_208 = (in).next;
        const operand_210 = block_209: {
            break :block_209 value_5;
        };
        const operand_211 = zx_type_35{ .byte = operand_207, .next = operand_208, .length = operand_210, };

        break :block_212 (try function_35(allocator, (&operand_211)));
    };
    const value_7: u64 = (block_205: {
        break :block_205 value_2;
    } + block_206: {
        break :block_206 value_5;
    });

    return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_204: {
        break :block_204 (try function_5_buffered(allocator, block_203: {
            const operand_189 = @as([]const u8, "punctuation");
            const operand_190 = block_191: {
                break :block_191 value_2;
            };
            const operand_192 = (block_193: {
                break :block_193 value_2;
            } + block_194: {
                break :block_194 value_5;
            });
            const operand_195 = false;
            const operand_196 = block_202: {
                const operand_197 = (in).state;
                const operand_198 = block_199: {
                    break :block_199 value_6;
                };
                const operand_200 = block_201: {
                    break :block_201 value_7;
                };

                break :block_202 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_197).ahead_one, .ahead_two = (operand_197).ahead_two, .braces = (operand_197).braces, .comments = (operand_197).comments, .depth = (operand_197).depth, .diagnostic = (operand_197).diagnostic, .dollar = (operand_197).dollar, .frames = (operand_197).frames, .keyword_state = (operand_197).keyword_state, .line_break = (operand_197).line_break, .mode = (operand_197).mode, .number = (operand_197).number, .offset = (operand_197).offset, .skip_until = operand_200, .source_length = (operand_197).source_length, .start = (operand_197).start, .symbol = operand_198, .tokens = (operand_197).tokens, .warmed = (operand_197).warmed, });
            };

            break :block_203 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_189, .start = operand_190, .end = operand_192, .comment = operand_195, .state = operand_196, });
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    });
}

fn function_37_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_29, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((in).state).line_break or ((in).byte == @as(u8, 10))) or ((in).byte == @as(u8, 13)));
    const value_2: u64 = ((in).state).offset;

    if ((((in).byte == @as(u8, 32)) or (((in).byte >= @as(u8, 9)) and ((in).byte <= @as(u8, 13))))) {
        return block_349: {
            const operand_345 = (in).state;
            const operand_346 = value_1;

            break :block_349 block_348: {
                const operand_347 = (try (allocator).create(zx_type_28));

                (operand_347).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_345).ahead_one, .ahead_two = (operand_345).ahead_two, .braces = (operand_345).braces, .comments = (operand_345).comments, .depth = (operand_345).depth, .diagnostic = (operand_345).diagnostic, .dollar = (operand_345).dollar, .frames = (operand_345).frames, .keyword_state = (operand_345).keyword_state, .line_break = operand_346, .mode = (operand_345).mode, .number = (operand_345).number, .offset = (operand_345).offset, .skip_until = (operand_345).skip_until, .source_length = (operand_345).source_length, .start = (operand_345).start, .symbol = (operand_345).symbol, .tokens = (operand_345).tokens, .warmed = (operand_345).warmed, });

                break :block_348 @as(*const zx_type_28, operand_347);
            };
        };
    }

    if ((((in).byte == @as(u8, 47)) and (in).has_next)) {
        const value_3: u8 = (in).next;

        if (((value_3 == @as(u8, 47)) or (value_3 == @as(u8, 42)))) {
            const value_4: u64 = (value_2 + @as(u64, 2));

            return block_344: {
                const operand_338 = (in).state;
                const operand_339 = value_4;
                const operand_340 = (if ((value_3 == @as(u8, 47))) @as(zx_type_22, .LineComment) else @as(zx_type_22, .BlockComment));
                const operand_341 = value_2;

                break :block_344 block_343: {
                    const operand_342 = (try (allocator).create(zx_type_28));

                    (operand_342).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_338).ahead_one, .ahead_two = (operand_338).ahead_two, .braces = (operand_338).braces, .comments = (operand_338).comments, .depth = (operand_338).depth, .diagnostic = (operand_338).diagnostic, .dollar = (operand_338).dollar, .frames = (operand_338).frames, .keyword_state = (operand_338).keyword_state, .line_break = (operand_338).line_break, .mode = operand_340, .number = (operand_338).number, .offset = (operand_338).offset, .skip_until = operand_339, .source_length = (operand_338).source_length, .start = operand_341, .symbol = (operand_338).symbol, .tokens = (operand_338).tokens, .warmed = (operand_338).warmed, });

                    break :block_343 @as(*const zx_type_28, operand_342);
                };
            };
        }
    }

    if ((((try function_7(allocator, (in).byte)) or ((in).byte == @as(u8, 95))) or ((in).byte == @as(u8, 36)))) {
        return block_337: {
            const operand_326 = (in).state;
            const operand_327 = block_331: {
                const operand_328 = @as(u64, 0);
                const operand_329 = (in).byte;
                const operand_330 = zx_type_33{ .state = operand_328, .byte = operand_329, };

                break :block_331 (try function_32(allocator, (&operand_330)));
            };
            const operand_332 = ((in).byte == @as(u8, 36));
            const operand_333 = @as(zx_type_22, .Identifier);
            const operand_334 = value_2;

            break :block_337 block_336: {
                const operand_335 = (try (allocator).create(zx_type_28));

                (operand_335).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_326).ahead_one, .ahead_two = (operand_326).ahead_two, .braces = (operand_326).braces, .comments = (operand_326).comments, .depth = (operand_326).depth, .diagnostic = (operand_326).diagnostic, .dollar = operand_332, .frames = (operand_326).frames, .keyword_state = operand_327, .line_break = (operand_326).line_break, .mode = operand_333, .number = (operand_326).number, .offset = (operand_326).offset, .skip_until = (operand_326).skip_until, .source_length = (operand_326).source_length, .start = operand_334, .symbol = (operand_326).symbol, .tokens = (operand_326).tokens, .warmed = (operand_326).warmed, });

                break :block_336 @as(*const zx_type_28, operand_335);
            };
        };
    }

    if ((try function_33(allocator, (in).byte))) {
        return block_325: {
            const operand_312 = (in).state;
            const operand_313 = @as(zx_type_22, .Number);
            const operand_314 = value_2;
            const operand_315 = block_322: {
                const operand_316 = @as(u64, 1);
                const operand_317 = @as(zx_type_19, .Integer);
                const operand_318 = (in).byte;
                const operand_319 = true;

                break :block_322 block_321: {
                    const operand_320 = (try (allocator).create(zx_type_20));

                    (operand_320).* = @as(zx_type_20, zx_type_20{ .end = operand_316, .phase = operand_317, .last_byte = operand_318, .separators_valid = operand_319, });

                    break :block_321 @as(*const zx_type_20, operand_320);
                };
            };

            break :block_325 block_324: {
                const operand_323 = (try (allocator).create(zx_type_28));

                (operand_323).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_312).ahead_one, .ahead_two = (operand_312).ahead_two, .braces = (operand_312).braces, .comments = (operand_312).comments, .depth = (operand_312).depth, .diagnostic = (operand_312).diagnostic, .dollar = (operand_312).dollar, .frames = (operand_312).frames, .keyword_state = (operand_312).keyword_state, .line_break = (operand_312).line_break, .mode = operand_313, .number = operand_315, .offset = (operand_312).offset, .skip_until = (operand_312).skip_until, .source_length = (operand_312).source_length, .start = operand_314, .symbol = (operand_312).symbol, .tokens = (operand_312).tokens, .warmed = (operand_312).warmed, });

                break :block_324 @as(*const zx_type_28, operand_323);
            };
        };
    }

    if (((in).byte == @as(u8, 34))) {
        return block_311: {
            const operand_306 = (in).state;
            const operand_307 = @as(zx_type_22, .String);
            const operand_308 = value_2;

            break :block_311 block_310: {
                const operand_309 = (try (allocator).create(zx_type_28));

                (operand_309).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_306).ahead_one, .ahead_two = (operand_306).ahead_two, .braces = (operand_306).braces, .comments = (operand_306).comments, .depth = (operand_306).depth, .diagnostic = (operand_306).diagnostic, .dollar = (operand_306).dollar, .frames = (operand_306).frames, .keyword_state = (operand_306).keyword_state, .line_break = (operand_306).line_break, .mode = operand_307, .number = (operand_306).number, .offset = (operand_306).offset, .skip_until = (operand_306).skip_until, .source_length = (operand_306).source_length, .start = operand_308, .symbol = (operand_306).symbol, .tokens = (operand_306).tokens, .warmed = (operand_306).warmed, });

                break :block_310 @as(*const zx_type_28, operand_309);
            };
        };
    }

    if (((in).byte == @as(u8, 96))) {
        return (try function_36_buffered_pointer(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if ((!(try function_8(allocator, (in).byte)))) {
        return (try function_6_buffered_pointer(allocator, block_305: {
            const operand_298 = @as([]const u8, "lexical");
            const operand_299 = value_2;
            const operand_300 = (value_2 + @as(u64, 1));
            const operand_301 = @as([]const u8, "unexpected character");
            const operand_302 = (in).state;

            break :block_305 block_304: {
                const operand_303 = (try (allocator).create(zx_type_32));

                (operand_303).* = @as(zx_type_32, zx_type_32{ .code = operand_298, .start = operand_299, .end = operand_300, .message = operand_301, .state = operand_302, });

                break :block_304 @as(*const zx_type_32, operand_303);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    const value_5: u64 = block_297: {
        const operand_291 = (in).byte;
        const operand_292 = (in).next;
        const operand_293 = (in).after;
        const operand_294 = (in).has_next;
        const operand_295 = (in).has_after;
        const operand_296 = zx_type_34{ .byte = operand_291, .next = operand_292, .after = operand_293, .has_next = operand_294, .has_after = operand_295, };

        break :block_297 (try function_34(allocator, (&operand_296)));
    };
    const value_6: zx_type_16 = block_290: {
        const operand_286 = (in).byte;
        const operand_287 = (in).next;
        const operand_288 = value_5;
        const operand_289 = zx_type_35{ .byte = operand_286, .next = operand_287, .length = operand_288, };

        break :block_290 (try function_35(allocator, (&operand_289)));
    };
    const value_7: u64 = (value_2 + value_5);

    return (try function_5_buffered_pointer(allocator, block_285: {
        const operand_272 = @as([]const u8, "punctuation");
        const operand_273 = value_2;
        const operand_274 = (value_2 + value_5);
        const operand_275 = false;
        const operand_276 = block_282: {
            const operand_277 = (in).state;
            const operand_278 = value_6;
            const operand_279 = value_7;

            break :block_282 block_281: {
                const operand_280 = (try (allocator).create(zx_type_28));

                (operand_280).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_277).ahead_one, .ahead_two = (operand_277).ahead_two, .braces = (operand_277).braces, .comments = (operand_277).comments, .depth = (operand_277).depth, .diagnostic = (operand_277).diagnostic, .dollar = (operand_277).dollar, .frames = (operand_277).frames, .keyword_state = (operand_277).keyword_state, .line_break = (operand_277).line_break, .mode = (operand_277).mode, .number = (operand_277).number, .offset = (operand_277).offset, .skip_until = operand_279, .source_length = (operand_277).source_length, .start = (operand_277).start, .symbol = operand_278, .tokens = (operand_277).tokens, .warmed = (operand_277).warmed, });

                break :block_281 @as(*const zx_type_28, operand_280);
            };
        };

        break :block_285 block_284: {
            const operand_283 = (try (allocator).create(zx_type_31));

            (operand_283).* = @as(zx_type_31, zx_type_31{ .kind = operand_272, .start = operand_273, .end = operand_274, .comment = operand_275, .state = operand_276, });

            break :block_284 @as(*const zx_type_31, operand_283);
        };
    }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
}

fn function_38(allocator: ((std).mem).Allocator, in: *const zx_type_29) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((in).state).line_break or ((in).byte == @as(u8, 10))) or ((in).byte == @as(u8, 13)));

    if (((((in).state).mode == @as(zx_type_22, .LineComment)) and (((in).byte == @as(u8, 10)) or ((in).byte == @as(u8, 13))))) {
        return block_51: {
            const operand_43 = block_42: {
                const operand_29 = @as([]const u8, "");
                const operand_30 = ((in).state).start;
                const operand_31 = ((in).state).offset;
                const operand_32 = true;
                const operand_33 = block_39: {
                    const operand_34 = (in).state;
                    const operand_35 = @as(zx_type_22, .Idle);
                    const operand_36 = true;

                    break :block_39 block_38: {
                        const operand_37 = (try (allocator).create(zx_type_28));

                        (operand_37).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_34).ahead_one, .ahead_two = (operand_34).ahead_two, .braces = (operand_34).braces, .comments = (operand_34).comments, .depth = (operand_34).depth, .diagnostic = (operand_34).diagnostic, .dollar = (operand_34).dollar, .frames = (operand_34).frames, .keyword_state = (operand_34).keyword_state, .line_break = operand_36, .mode = operand_35, .number = (operand_34).number, .offset = (operand_34).offset, .skip_until = (operand_34).skip_until, .source_length = (operand_34).source_length, .start = (operand_34).start, .symbol = (operand_34).symbol, .tokens = (operand_34).tokens, .warmed = (operand_34).warmed, });

                        break :block_38 @as(*const zx_type_28, operand_37);
                    };
                };

                break :block_42 block_41: {
                    const operand_40 = (try (allocator).create(zx_type_31));

                    (operand_40).* = @as(zx_type_31, zx_type_31{ .kind = operand_29, .start = operand_30, .end = operand_31, .comment = operand_32, .state = operand_33, });

                    break :block_41 @as(*const zx_type_31, operand_40);
                };
            };
            const operand_44 = (try function_5_value(allocator, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .comment = (operand_43).comment, .end = (operand_43).end, .kind = (operand_43).kind, .start = (operand_43).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_43).state).ahead_one, .ahead_two = ((operand_43).state).ahead_two, .braces = ((operand_43).state).braces, .comments = ((operand_43).state).comments, .depth = ((operand_43).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_43).state).diagnostic).code, .end = (((operand_43).state).diagnostic).end, .message = (((operand_43).state).diagnostic).message, .start = (((operand_43).state).diagnostic).start, .zx_origin = ((operand_43).state).diagnostic, }, .dollar = ((operand_43).state).dollar, .frames = ((operand_43).state).frames, .keyword_state = ((operand_43).state).keyword_state, .line_break = ((operand_43).state).line_break, .mode = ((operand_43).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_43).state).number).end, .last_byte = (((operand_43).state).number).last_byte, .phase = (((operand_43).state).number).phase, .separators_valid = (((operand_43).state).number).separators_valid, .zx_origin = ((operand_43).state).number, }, .offset = ((operand_43).state).offset, .skip_until = ((operand_43).state).skip_until, .source_length = ((operand_43).state).source_length, .start = ((operand_43).state).start, .symbol = ((operand_43).state).symbol, .tokens = ((operand_43).state).tokens, .warmed = ((operand_43).state).warmed, .zx_origin = (operand_43).state, }, .zx_origin = operand_43, }));

            break :block_51 (if (((operand_44).zx_origin != null)) (operand_44).zx_origin.? else block_50: {
                const operand_49 = (try (allocator).create(zx_type_28));

                (operand_49).* = zx_type_28{ .ahead_one = (operand_44).ahead_one, .ahead_two = (operand_44).ahead_two, .braces = (operand_44).braces, .comments = (operand_44).comments, .depth = (operand_44).depth, .diagnostic = (if ((((operand_44).diagnostic).zx_origin != null)) ((operand_44).diagnostic).zx_origin.? else block_46: {
                    const operand_45 = (try (allocator).create(zx_type_23));

                    (operand_45).* = zx_type_23{ .code = ((operand_44).diagnostic).code, .end = ((operand_44).diagnostic).end, .message = ((operand_44).diagnostic).message, .start = ((operand_44).diagnostic).start, };

                    break :block_46 @as(*const zx_type_23, operand_45);
                }), .dollar = (operand_44).dollar, .frames = (operand_44).frames, .keyword_state = (operand_44).keyword_state, .line_break = (operand_44).line_break, .mode = (operand_44).mode, .number = (if ((((operand_44).number).zx_origin != null)) ((operand_44).number).zx_origin.? else block_48: {
                    const operand_47 = (try (allocator).create(zx_type_20));

                    (operand_47).* = zx_type_20{ .end = ((operand_44).number).end, .last_byte = ((operand_44).number).last_byte, .phase = ((operand_44).number).phase, .separators_valid = ((operand_44).number).separators_valid, };

                    break :block_48 @as(*const zx_type_20, operand_47);
                }), .offset = (operand_44).offset, .skip_until = (operand_44).skip_until, .source_length = (operand_44).source_length, .start = (operand_44).start, .symbol = (operand_44).symbol, .tokens = (operand_44).tokens, .warmed = (operand_44).warmed, };

                break :block_50 @as(*const zx_type_28, operand_49);
            });
        };
    }

    if (((((((in).state).mode == @as(zx_type_22, .BlockComment)) and ((in).byte == @as(u8, 42))) and (in).has_next) and ((in).next == @as(u8, 47)))) {
        const value_2: u64 = (((in).state).offset + @as(u64, 2));

        return block_28: {
            const operand_20 = block_19: {
                const operand_6 = @as([]const u8, "");
                const operand_7 = ((in).state).start;
                const operand_8 = (((in).state).offset + @as(u64, 2));
                const operand_9 = true;
                const operand_10 = block_16: {
                    const operand_11 = (in).state;
                    const operand_12 = value_2;
                    const operand_13 = @as(zx_type_22, .Idle);

                    break :block_16 block_15: {
                        const operand_14 = (try (allocator).create(zx_type_28));

                        (operand_14).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_11).ahead_one, .ahead_two = (operand_11).ahead_two, .braces = (operand_11).braces, .comments = (operand_11).comments, .depth = (operand_11).depth, .diagnostic = (operand_11).diagnostic, .dollar = (operand_11).dollar, .frames = (operand_11).frames, .keyword_state = (operand_11).keyword_state, .line_break = (operand_11).line_break, .mode = operand_13, .number = (operand_11).number, .offset = (operand_11).offset, .skip_until = operand_12, .source_length = (operand_11).source_length, .start = (operand_11).start, .symbol = (operand_11).symbol, .tokens = (operand_11).tokens, .warmed = (operand_11).warmed, });

                        break :block_15 @as(*const zx_type_28, operand_14);
                    };
                };

                break :block_19 block_18: {
                    const operand_17 = (try (allocator).create(zx_type_31));

                    (operand_17).* = @as(zx_type_31, zx_type_31{ .kind = operand_6, .start = operand_7, .end = operand_8, .comment = operand_9, .state = operand_10, });

                    break :block_18 @as(*const zx_type_31, operand_17);
                };
            };
            const operand_21 = (try function_5_value(allocator, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .comment = (operand_20).comment, .end = (operand_20).end, .kind = (operand_20).kind, .start = (operand_20).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_20).state).ahead_one, .ahead_two = ((operand_20).state).ahead_two, .braces = ((operand_20).state).braces, .comments = ((operand_20).state).comments, .depth = ((operand_20).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_20).state).diagnostic).code, .end = (((operand_20).state).diagnostic).end, .message = (((operand_20).state).diagnostic).message, .start = (((operand_20).state).diagnostic).start, .zx_origin = ((operand_20).state).diagnostic, }, .dollar = ((operand_20).state).dollar, .frames = ((operand_20).state).frames, .keyword_state = ((operand_20).state).keyword_state, .line_break = ((operand_20).state).line_break, .mode = ((operand_20).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_20).state).number).end, .last_byte = (((operand_20).state).number).last_byte, .phase = (((operand_20).state).number).phase, .separators_valid = (((operand_20).state).number).separators_valid, .zx_origin = ((operand_20).state).number, }, .offset = ((operand_20).state).offset, .skip_until = ((operand_20).state).skip_until, .source_length = ((operand_20).state).source_length, .start = ((operand_20).state).start, .symbol = ((operand_20).state).symbol, .tokens = ((operand_20).state).tokens, .warmed = ((operand_20).state).warmed, .zx_origin = (operand_20).state, }, .zx_origin = operand_20, }));

            break :block_28 (if (((operand_21).zx_origin != null)) (operand_21).zx_origin.? else block_27: {
                const operand_26 = (try (allocator).create(zx_type_28));

                (operand_26).* = zx_type_28{ .ahead_one = (operand_21).ahead_one, .ahead_two = (operand_21).ahead_two, .braces = (operand_21).braces, .comments = (operand_21).comments, .depth = (operand_21).depth, .diagnostic = (if ((((operand_21).diagnostic).zx_origin != null)) ((operand_21).diagnostic).zx_origin.? else block_23: {
                    const operand_22 = (try (allocator).create(zx_type_23));

                    (operand_22).* = zx_type_23{ .code = ((operand_21).diagnostic).code, .end = ((operand_21).diagnostic).end, .message = ((operand_21).diagnostic).message, .start = ((operand_21).diagnostic).start, };

                    break :block_23 @as(*const zx_type_23, operand_22);
                }), .dollar = (operand_21).dollar, .frames = (operand_21).frames, .keyword_state = (operand_21).keyword_state, .line_break = (operand_21).line_break, .mode = (operand_21).mode, .number = (if ((((operand_21).number).zx_origin != null)) ((operand_21).number).zx_origin.? else block_25: {
                    const operand_24 = (try (allocator).create(zx_type_20));

                    (operand_24).* = zx_type_20{ .end = ((operand_21).number).end, .last_byte = ((operand_21).number).last_byte, .phase = ((operand_21).number).phase, .separators_valid = ((operand_21).number).separators_valid, };

                    break :block_25 @as(*const zx_type_20, operand_24);
                }), .offset = (operand_21).offset, .skip_until = (operand_21).skip_until, .source_length = (operand_21).source_length, .start = (operand_21).start, .symbol = (operand_21).symbol, .tokens = (operand_21).tokens, .warmed = (operand_21).warmed, };

                break :block_27 @as(*const zx_type_28, operand_26);
            });
        };
    }

    return block_5: {
        const operand_1 = (in).state;
        const operand_2 = value_1;

        break :block_5 block_4: {
            const operand_3 = (try (allocator).create(zx_type_28));

            (operand_3).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_1).ahead_one, .ahead_two = (operand_1).ahead_two, .braces = (operand_1).braces, .comments = (operand_1).comments, .depth = (operand_1).depth, .diagnostic = (operand_1).diagnostic, .dollar = (operand_1).dollar, .frames = (operand_1).frames, .keyword_state = (operand_1).keyword_state, .line_break = operand_2, .mode = (operand_1).mode, .number = (operand_1).number, .offset = (operand_1).offset, .skip_until = (operand_1).skip_until, .source_length = (operand_1).source_length, .start = (operand_1).start, .symbol = (operand_1).symbol, .tokens = (operand_1).tokens, .warmed = (operand_1).warmed, });

            break :block_4 @as(*const zx_type_28, operand_3);
        };
    };
}

fn function_38_value(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((in).state).line_break or ((in).byte == @as(u8, 10))) or ((in).byte == @as(u8, 13)));

    if (((((in).state).mode == @as(zx_type_22, .LineComment)) and (((in).byte == @as(u8, 10)) or ((in).byte == @as(u8, 13))))) {
        return block_78: {
            break :block_78 (try function_5_value(allocator, block_77: {
                const operand_68 = @as([]const u8, "");
                const operand_69 = ((in).state).start;
                const operand_70 = ((in).state).offset;
                const operand_71 = true;
                const operand_72 = block_76: {
                    const operand_73 = (in).state;
                    const operand_74 = @as(zx_type_22, .Idle);
                    const operand_75 = true;

                    break :block_76 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_73).ahead_one, .ahead_two = (operand_73).ahead_two, .braces = (operand_73).braces, .comments = (operand_73).comments, .depth = (operand_73).depth, .diagnostic = (operand_73).diagnostic, .dollar = (operand_73).dollar, .frames = (operand_73).frames, .keyword_state = (operand_73).keyword_state, .line_break = operand_75, .mode = operand_74, .number = (operand_73).number, .offset = (operand_73).offset, .skip_until = (operand_73).skip_until, .source_length = (operand_73).source_length, .start = (operand_73).start, .symbol = (operand_73).symbol, .tokens = (operand_73).tokens, .warmed = (operand_73).warmed, });
                };

                break :block_77 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_68, .start = operand_69, .end = operand_70, .comment = operand_71, .state = operand_72, });
            }));
        };
    }

    if (((((((in).state).mode == @as(zx_type_22, .BlockComment)) and ((in).byte == @as(u8, 42))) and (in).has_next) and ((in).next == @as(u8, 47)))) {
        const value_2: u64 = (((in).state).offset + @as(u64, 2));

        return block_67: {
            break :block_67 (try function_5_value(allocator, block_66: {
                const operand_56 = @as([]const u8, "");
                const operand_57 = ((in).state).start;
                const operand_58 = (((in).state).offset + @as(u64, 2));
                const operand_59 = true;
                const operand_60 = block_65: {
                    const operand_61 = (in).state;
                    const operand_62 = block_63: {
                        break :block_63 value_2;
                    };
                    const operand_64 = @as(zx_type_22, .Idle);

                    break :block_65 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_61).ahead_one, .ahead_two = (operand_61).ahead_two, .braces = (operand_61).braces, .comments = (operand_61).comments, .depth = (operand_61).depth, .diagnostic = (operand_61).diagnostic, .dollar = (operand_61).dollar, .frames = (operand_61).frames, .keyword_state = (operand_61).keyword_state, .line_break = (operand_61).line_break, .mode = operand_64, .number = (operand_61).number, .offset = (operand_61).offset, .skip_until = operand_62, .source_length = (operand_61).source_length, .start = (operand_61).start, .symbol = (operand_61).symbol, .tokens = (operand_61).tokens, .warmed = (operand_61).warmed, });
                };

                break :block_66 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_56, .start = operand_57, .end = operand_58, .comment = operand_59, .state = operand_60, });
            }));
        };
    }

    return block_55: {
        const operand_52 = (in).state;
        const operand_53 = block_54: {
            break :block_54 value_1;
        };

        break :block_55 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_52).ahead_one, .ahead_two = (operand_52).ahead_two, .braces = (operand_52).braces, .comments = (operand_52).comments, .depth = (operand_52).depth, .diagnostic = (operand_52).diagnostic, .dollar = (operand_52).dollar, .frames = (operand_52).frames, .keyword_state = (operand_52).keyword_state, .line_break = operand_53, .mode = (operand_52).mode, .number = (operand_52).number, .offset = (operand_52).offset, .skip_until = (operand_52).skip_until, .source_length = (operand_52).source_length, .start = (operand_52).start, .symbol = (operand_52).symbol, .tokens = (operand_52).tokens, .warmed = (operand_52).warmed, });
    };
}

fn function_38_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((in).state).line_break or ((in).byte == @as(u8, 10))) or ((in).byte == @as(u8, 13)));

    if (((((in).state).mode == @as(zx_type_22, .LineComment)) and (((in).byte == @as(u8, 10)) or ((in).byte == @as(u8, 13))))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_105: {
            break :block_105 (try function_5_buffered(allocator, block_104: {
                const operand_95 = @as([]const u8, "");
                const operand_96 = ((in).state).start;
                const operand_97 = ((in).state).offset;
                const operand_98 = true;
                const operand_99 = block_103: {
                    const operand_100 = (in).state;
                    const operand_101 = @as(zx_type_22, .Idle);
                    const operand_102 = true;

                    break :block_103 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_100).ahead_one, .ahead_two = (operand_100).ahead_two, .braces = (operand_100).braces, .comments = (operand_100).comments, .depth = (operand_100).depth, .diagnostic = (operand_100).diagnostic, .dollar = (operand_100).dollar, .frames = (operand_100).frames, .keyword_state = (operand_100).keyword_state, .line_break = operand_102, .mode = operand_101, .number = (operand_100).number, .offset = (operand_100).offset, .skip_until = (operand_100).skip_until, .source_length = (operand_100).source_length, .start = (operand_100).start, .symbol = (operand_100).symbol, .tokens = (operand_100).tokens, .warmed = (operand_100).warmed, });
                };

                break :block_104 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_95, .start = operand_96, .end = operand_97, .comment = operand_98, .state = operand_99, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if (((((((in).state).mode == @as(zx_type_22, .BlockComment)) and ((in).byte == @as(u8, 42))) and (in).has_next) and ((in).next == @as(u8, 47)))) {
        const value_2: u64 = (((in).state).offset + @as(u64, 2));

        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_94: {
            break :block_94 (try function_5_buffered(allocator, block_93: {
                const operand_83 = @as([]const u8, "");
                const operand_84 = ((in).state).start;
                const operand_85 = (((in).state).offset + @as(u64, 2));
                const operand_86 = true;
                const operand_87 = block_92: {
                    const operand_88 = (in).state;
                    const operand_89 = block_90: {
                        break :block_90 value_2;
                    };
                    const operand_91 = @as(zx_type_22, .Idle);

                    break :block_92 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_88).ahead_one, .ahead_two = (operand_88).ahead_two, .braces = (operand_88).braces, .comments = (operand_88).comments, .depth = (operand_88).depth, .diagnostic = (operand_88).diagnostic, .dollar = (operand_88).dollar, .frames = (operand_88).frames, .keyword_state = (operand_88).keyword_state, .line_break = (operand_88).line_break, .mode = operand_91, .number = (operand_88).number, .offset = (operand_88).offset, .skip_until = operand_89, .source_length = (operand_88).source_length, .start = (operand_88).start, .symbol = (operand_88).symbol, .tokens = (operand_88).tokens, .warmed = (operand_88).warmed, });
                };

                break :block_93 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_83, .start = operand_84, .end = operand_85, .comment = operand_86, .state = operand_87, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    return block_82: {
        const operand_79 = (in).state;
        const operand_80 = block_81: {
            break :block_81 value_1;
        };

        break :block_82 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_79).ahead_one, .ahead_two = (operand_79).ahead_two, .braces = (operand_79).braces, .comments = (operand_79).comments, .depth = (operand_79).depth, .diagnostic = (operand_79).diagnostic, .dollar = (operand_79).dollar, .frames = (operand_79).frames, .keyword_state = (operand_79).keyword_state, .line_break = operand_80, .mode = (operand_79).mode, .number = (operand_79).number, .offset = (operand_79).offset, .skip_until = (operand_79).skip_until, .source_length = (operand_79).source_length, .start = (operand_79).start, .symbol = (operand_79).symbol, .tokens = (operand_79).tokens, .warmed = (operand_79).warmed, });
    };
}

fn function_38_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_29, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((in).state).line_break or ((in).byte == @as(u8, 10))) or ((in).byte == @as(u8, 13)));

    if (((((in).state).mode == @as(zx_type_22, .LineComment)) and (((in).byte == @as(u8, 10)) or ((in).byte == @as(u8, 13))))) {
        return (try function_5_buffered_pointer(allocator, block_138: {
            const operand_125 = @as([]const u8, "");
            const operand_126 = ((in).state).start;
            const operand_127 = ((in).state).offset;
            const operand_128 = true;
            const operand_129 = block_135: {
                const operand_130 = (in).state;
                const operand_131 = @as(zx_type_22, .Idle);
                const operand_132 = true;

                break :block_135 block_134: {
                    const operand_133 = (try (allocator).create(zx_type_28));

                    (operand_133).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_130).ahead_one, .ahead_two = (operand_130).ahead_two, .braces = (operand_130).braces, .comments = (operand_130).comments, .depth = (operand_130).depth, .diagnostic = (operand_130).diagnostic, .dollar = (operand_130).dollar, .frames = (operand_130).frames, .keyword_state = (operand_130).keyword_state, .line_break = operand_132, .mode = operand_131, .number = (operand_130).number, .offset = (operand_130).offset, .skip_until = (operand_130).skip_until, .source_length = (operand_130).source_length, .start = (operand_130).start, .symbol = (operand_130).symbol, .tokens = (operand_130).tokens, .warmed = (operand_130).warmed, });

                    break :block_134 @as(*const zx_type_28, operand_133);
                };
            };

            break :block_138 block_137: {
                const operand_136 = (try (allocator).create(zx_type_31));

                (operand_136).* = @as(zx_type_31, zx_type_31{ .kind = operand_125, .start = operand_126, .end = operand_127, .comment = operand_128, .state = operand_129, });

                break :block_137 @as(*const zx_type_31, operand_136);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if (((((((in).state).mode == @as(zx_type_22, .BlockComment)) and ((in).byte == @as(u8, 42))) and (in).has_next) and ((in).next == @as(u8, 47)))) {
        const value_2: u64 = (((in).state).offset + @as(u64, 2));

        return (try function_5_buffered_pointer(allocator, block_124: {
            const operand_111 = @as([]const u8, "");
            const operand_112 = ((in).state).start;
            const operand_113 = (((in).state).offset + @as(u64, 2));
            const operand_114 = true;
            const operand_115 = block_121: {
                const operand_116 = (in).state;
                const operand_117 = value_2;
                const operand_118 = @as(zx_type_22, .Idle);

                break :block_121 block_120: {
                    const operand_119 = (try (allocator).create(zx_type_28));

                    (operand_119).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_116).ahead_one, .ahead_two = (operand_116).ahead_two, .braces = (operand_116).braces, .comments = (operand_116).comments, .depth = (operand_116).depth, .diagnostic = (operand_116).diagnostic, .dollar = (operand_116).dollar, .frames = (operand_116).frames, .keyword_state = (operand_116).keyword_state, .line_break = (operand_116).line_break, .mode = operand_118, .number = (operand_116).number, .offset = (operand_116).offset, .skip_until = operand_117, .source_length = (operand_116).source_length, .start = (operand_116).start, .symbol = (operand_116).symbol, .tokens = (operand_116).tokens, .warmed = (operand_116).warmed, });

                    break :block_120 @as(*const zx_type_28, operand_119);
                };
            };

            break :block_124 block_123: {
                const operand_122 = (try (allocator).create(zx_type_31));

                (operand_122).* = @as(zx_type_31, zx_type_31{ .kind = operand_111, .start = operand_112, .end = operand_113, .comment = operand_114, .state = operand_115, });

                break :block_123 @as(*const zx_type_31, operand_122);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    return block_110: {
        const operand_106 = (in).state;
        const operand_107 = value_1;

        break :block_110 block_109: {
            const operand_108 = (try (allocator).create(zx_type_28));

            (operand_108).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_106).ahead_one, .ahead_two = (operand_106).ahead_two, .braces = (operand_106).braces, .comments = (operand_106).comments, .depth = (operand_106).depth, .diagnostic = (operand_106).diagnostic, .dollar = (operand_106).dollar, .frames = (operand_106).frames, .keyword_state = (operand_106).keyword_state, .line_break = operand_107, .mode = (operand_106).mode, .number = (operand_106).number, .offset = (operand_106).offset, .skip_until = (operand_106).skip_until, .source_length = (operand_106).source_length, .start = (operand_106).start, .symbol = (operand_106).symbol, .tokens = (operand_106).tokens, .warmed = (operand_106).warmed, });

            break :block_109 @as(*const zx_type_28, operand_108);
        };
    };
}

fn function_39(allocator: ((std).mem).Allocator, in: zx_type_14) error{ }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    return (((((((((((((((((((((((((((in == @as(zx_type_14, .Export)) or (in == @as(zx_type_14, .Type))) or (in == @as(zx_type_14, .Default))) or (in == @as(zx_type_14, .Function))) or (in == @as(zx_type_14, .Const))) or (in == @as(zx_type_14, .If))) or (in == @as(zx_type_14, .Else))) or (in == @as(zx_type_14, .Return))) or (in == @as(zx_type_14, .True))) or (in == @as(zx_type_14, .False))) or (in == @as(zx_type_14, .Import))) or (in == @as(zx_type_14, .Enum))) or (in == @as(zx_type_14, .Switch))) or (in == @as(zx_type_14, .Null))) or (in == @as(zx_type_14, .Let))) or (in == @as(zx_type_14, .Var))) or (in == @as(zx_type_14, .For))) or (in == @as(zx_type_14, .While))) or (in == @as(zx_type_14, .New))) or (in == @as(zx_type_14, .Throw))) or (in == @as(zx_type_14, .Async))) or (in == @as(zx_type_14, .Await))) or (in == @as(zx_type_14, .Case))) or (in == @as(zx_type_14, .Break))) or (in == @as(zx_type_14, .Match))) or (in == @as(zx_type_14, .Try))) or (in == @as(zx_type_14, .Cancel)));
}

fn function_40(allocator: ((std).mem).Allocator, in: *const zx_type_28) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: []const u8 = (if ((try function_39(allocator, (try function_3(allocator, (in).keyword_state))))) @as([]const u8, "keyword") else @as([]const u8, "identifier"));

    return block_22: {
        const operand_14 = block_13: {
            const operand_1 = value_1;
            const operand_2 = (in).start;
            const operand_3 = (in).offset;
            const operand_4 = false;
            const operand_5 = block_10: {
                const operand_6 = in;
                const operand_7 = @as(zx_type_22, .Idle);

                break :block_10 block_9: {
                    const operand_8 = (try (allocator).create(zx_type_28));

                    (operand_8).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_6).ahead_one, .ahead_two = (operand_6).ahead_two, .braces = (operand_6).braces, .comments = (operand_6).comments, .depth = (operand_6).depth, .diagnostic = (operand_6).diagnostic, .dollar = (operand_6).dollar, .frames = (operand_6).frames, .keyword_state = (operand_6).keyword_state, .line_break = (operand_6).line_break, .mode = operand_7, .number = (operand_6).number, .offset = (operand_6).offset, .skip_until = (operand_6).skip_until, .source_length = (operand_6).source_length, .start = (operand_6).start, .symbol = (operand_6).symbol, .tokens = (operand_6).tokens, .warmed = (operand_6).warmed, });

                    break :block_9 @as(*const zx_type_28, operand_8);
                };
            };

            break :block_13 block_12: {
                const operand_11 = (try (allocator).create(zx_type_31));

                (operand_11).* = @as(zx_type_31, zx_type_31{ .kind = operand_1, .start = operand_2, .end = operand_3, .comment = operand_4, .state = operand_5, });

                break :block_12 @as(*const zx_type_31, operand_11);
            };
        };
        const operand_15 = (try function_5_value(allocator, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .comment = (operand_14).comment, .end = (operand_14).end, .kind = (operand_14).kind, .start = (operand_14).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_14).state).ahead_one, .ahead_two = ((operand_14).state).ahead_two, .braces = ((operand_14).state).braces, .comments = ((operand_14).state).comments, .depth = ((operand_14).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_14).state).diagnostic).code, .end = (((operand_14).state).diagnostic).end, .message = (((operand_14).state).diagnostic).message, .start = (((operand_14).state).diagnostic).start, .zx_origin = ((operand_14).state).diagnostic, }, .dollar = ((operand_14).state).dollar, .frames = ((operand_14).state).frames, .keyword_state = ((operand_14).state).keyword_state, .line_break = ((operand_14).state).line_break, .mode = ((operand_14).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_14).state).number).end, .last_byte = (((operand_14).state).number).last_byte, .phase = (((operand_14).state).number).phase, .separators_valid = (((operand_14).state).number).separators_valid, .zx_origin = ((operand_14).state).number, }, .offset = ((operand_14).state).offset, .skip_until = ((operand_14).state).skip_until, .source_length = ((operand_14).state).source_length, .start = ((operand_14).state).start, .symbol = ((operand_14).state).symbol, .tokens = ((operand_14).state).tokens, .warmed = ((operand_14).state).warmed, .zx_origin = (operand_14).state, }, .zx_origin = operand_14, }));

        break :block_22 (if (((operand_15).zx_origin != null)) (operand_15).zx_origin.? else block_21: {
            const operand_20 = (try (allocator).create(zx_type_28));

            (operand_20).* = zx_type_28{ .ahead_one = (operand_15).ahead_one, .ahead_two = (operand_15).ahead_two, .braces = (operand_15).braces, .comments = (operand_15).comments, .depth = (operand_15).depth, .diagnostic = (if ((((operand_15).diagnostic).zx_origin != null)) ((operand_15).diagnostic).zx_origin.? else block_17: {
                const operand_16 = (try (allocator).create(zx_type_23));

                (operand_16).* = zx_type_23{ .code = ((operand_15).diagnostic).code, .end = ((operand_15).diagnostic).end, .message = ((operand_15).diagnostic).message, .start = ((operand_15).diagnostic).start, };

                break :block_17 @as(*const zx_type_23, operand_16);
            }), .dollar = (operand_15).dollar, .frames = (operand_15).frames, .keyword_state = (operand_15).keyword_state, .line_break = (operand_15).line_break, .mode = (operand_15).mode, .number = (if ((((operand_15).number).zx_origin != null)) ((operand_15).number).zx_origin.? else block_19: {
                const operand_18 = (try (allocator).create(zx_type_20));

                (operand_18).* = zx_type_20{ .end = ((operand_15).number).end, .last_byte = ((operand_15).number).last_byte, .phase = ((operand_15).number).phase, .separators_valid = ((operand_15).number).separators_valid, };

                break :block_19 @as(*const zx_type_20, operand_18);
            }), .offset = (operand_15).offset, .skip_until = (operand_15).skip_until, .source_length = (operand_15).source_length, .start = (operand_15).start, .symbol = (operand_15).symbol, .tokens = (operand_15).tokens, .warmed = (operand_15).warmed, };

            break :block_21 @as(*const zx_type_28, operand_20);
        });
    };
}

fn function_40_value(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: []const u8 = (if ((try function_39(allocator, (try function_3(allocator, (in).keyword_state))))) @as([]const u8, "keyword") else @as([]const u8, "identifier"));

    return block_33: {
        break :block_33 (try function_5_value(allocator, block_32: {
            const operand_23 = block_24: {
                break :block_24 value_1;
            };
            const operand_25 = (in).start;
            const operand_26 = (in).offset;
            const operand_27 = false;
            const operand_28 = block_31: {
                const operand_29 = in;
                const operand_30 = @as(zx_type_22, .Idle);

                break :block_31 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_29).ahead_one, .ahead_two = (operand_29).ahead_two, .braces = (operand_29).braces, .comments = (operand_29).comments, .depth = (operand_29).depth, .diagnostic = (operand_29).diagnostic, .dollar = (operand_29).dollar, .frames = (operand_29).frames, .keyword_state = (operand_29).keyword_state, .line_break = (operand_29).line_break, .mode = operand_30, .number = (operand_29).number, .offset = (operand_29).offset, .skip_until = (operand_29).skip_until, .source_length = (operand_29).source_length, .start = (operand_29).start, .symbol = (operand_29).symbol, .tokens = (operand_29).tokens, .warmed = (operand_29).warmed, });
            };

            break :block_32 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_23, .start = operand_25, .end = operand_26, .comment = operand_27, .state = operand_28, });
        }));
    };
}

fn function_40_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: []const u8 = (if ((try function_39(allocator, (try function_3(allocator, (in).keyword_state))))) @as([]const u8, "keyword") else @as([]const u8, "identifier"));

    return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_44: {
        break :block_44 (try function_5_buffered(allocator, block_43: {
            const operand_34 = block_35: {
                break :block_35 value_1;
            };
            const operand_36 = (in).start;
            const operand_37 = (in).offset;
            const operand_38 = false;
            const operand_39 = block_42: {
                const operand_40 = in;
                const operand_41 = @as(zx_type_22, .Idle);

                break :block_42 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_40).ahead_one, .ahead_two = (operand_40).ahead_two, .braces = (operand_40).braces, .comments = (operand_40).comments, .depth = (operand_40).depth, .diagnostic = (operand_40).diagnostic, .dollar = (operand_40).dollar, .frames = (operand_40).frames, .keyword_state = (operand_40).keyword_state, .line_break = (operand_40).line_break, .mode = operand_41, .number = (operand_40).number, .offset = (operand_40).offset, .skip_until = (operand_40).skip_until, .source_length = (operand_40).source_length, .start = (operand_40).start, .symbol = (operand_40).symbol, .tokens = (operand_40).tokens, .warmed = (operand_40).warmed, });
            };

            break :block_43 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_34, .start = operand_36, .end = operand_37, .comment = operand_38, .state = operand_39, });
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    });
}

fn function_40_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_28, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: []const u8 = (if ((try function_39(allocator, (try function_3(allocator, (in).keyword_state))))) @as([]const u8, "keyword") else @as([]const u8, "identifier"));

    return (try function_5_buffered_pointer(allocator, block_57: {
        const operand_45 = value_1;
        const operand_46 = (in).start;
        const operand_47 = (in).offset;
        const operand_48 = false;
        const operand_49 = block_54: {
            const operand_50 = in;
            const operand_51 = @as(zx_type_22, .Idle);

            break :block_54 block_53: {
                const operand_52 = (try (allocator).create(zx_type_28));

                (operand_52).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_50).ahead_one, .ahead_two = (operand_50).ahead_two, .braces = (operand_50).braces, .comments = (operand_50).comments, .depth = (operand_50).depth, .diagnostic = (operand_50).diagnostic, .dollar = (operand_50).dollar, .frames = (operand_50).frames, .keyword_state = (operand_50).keyword_state, .line_break = (operand_50).line_break, .mode = operand_51, .number = (operand_50).number, .offset = (operand_50).offset, .skip_until = (operand_50).skip_until, .source_length = (operand_50).source_length, .start = (operand_50).start, .symbol = (operand_50).symbol, .tokens = (operand_50).tokens, .warmed = (operand_50).warmed, });

                break :block_53 @as(*const zx_type_28, operand_52);
            };
        };

        break :block_57 block_56: {
            const operand_55 = (try (allocator).create(zx_type_31));

            (operand_55).* = @as(zx_type_31, zx_type_31{ .kind = operand_45, .start = operand_46, .end = operand_47, .comment = operand_48, .state = operand_49, });

            break :block_56 @as(*const zx_type_31, operand_55);
        };
    }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
}

fn function_41(allocator: ((std).mem).Allocator, in: *const zx_type_20) error{ OutOfMemory, }!*const zx_type_21 {
    @setRuntimeSafety(true);

    if (((!(in).separators_valid) or ((in).last_byte == @as(u8, 95)))) {
        return block_15: {
            const operand_11 = (in).end;
            const operand_12 = @as([]const u8, "digit separators must occur between digits");

            break :block_15 block_14: {
                const operand_13 = (try (allocator).create(zx_type_21));

                (operand_13).* = @as(zx_type_21, zx_type_21{ .end = operand_11, .diagnostic = operand_12, });

                break :block_14 @as(*const zx_type_21, operand_13);
            };
        };
    }

    if ((!(try function_33(allocator, (in).last_byte)))) {
        return block_10: {
            const operand_6 = (in).end;
            const operand_7 = @as([]const u8, "an exponent requires at least one digit");

            break :block_10 block_9: {
                const operand_8 = (try (allocator).create(zx_type_21));

                (operand_8).* = @as(zx_type_21, zx_type_21{ .end = operand_6, .diagnostic = operand_7, });

                break :block_9 @as(*const zx_type_21, operand_8);
            };
        };
    }

    return block_5: {
        const operand_1 = (in).end;
        const operand_2 = @as([]const u8, "");

        break :block_5 block_4: {
            const operand_3 = (try (allocator).create(zx_type_21));

            (operand_3).* = @as(zx_type_21, zx_type_21{ .end = operand_1, .diagnostic = operand_2, });

            break :block_4 @as(*const zx_type_21, operand_3);
        };
    };
}

fn function_41_value(allocator: ((std).mem).Allocator, in: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165) error{ OutOfMemory, }!value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    if (((!(in).separators_valid) or ((in).last_byte == @as(u8, 95)))) {
        return block_24: {
            const operand_22 = (in).end;
            const operand_23 = @as([]const u8, "digit separators must occur between digits");

            break :block_24 @as(value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .end = operand_22, .diagnostic = operand_23, });
        };
    }

    if ((!(try function_33(allocator, (in).last_byte)))) {
        return block_21: {
            const operand_19 = (in).end;
            const operand_20 = @as([]const u8, "an exponent requires at least one digit");

            break :block_21 @as(value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .end = operand_19, .diagnostic = operand_20, });
        };
    }

    return block_18: {
        const operand_16 = (in).end;
        const operand_17 = @as([]const u8, "");

        break :block_18 @as(value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .end = operand_16, .diagnostic = operand_17, });
    };
}

fn function_42(allocator: ((std).mem).Allocator, in: *const zx_type_28) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: *const zx_type_21 = block_47: {
        const operand_43 = (in).number;
        const operand_44 = (try function_41_value(allocator, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (operand_43).end, .last_byte = (operand_43).last_byte, .phase = (operand_43).phase, .separators_valid = (operand_43).separators_valid, .zx_origin = operand_43, }));

        break :block_47 (if (((operand_44).zx_origin != null)) (operand_44).zx_origin.? else block_46: {
            const operand_45 = (try (allocator).create(zx_type_21));

            (operand_45).* = zx_type_21{ .diagnostic = (operand_44).diagnostic, .end = (operand_44).end, };

            break :block_46 @as(*const zx_type_21, operand_45);
        });
    };

    if ((!block_25: {
        const operand_23 = (value_1).diagnostic;
        const operand_24 = @as([]const u8, "");

        break :block_25 ((std).mem).eql(u8, operand_23, operand_24);
    })) {
        return block_42: {
            const operand_34 = block_33: {
                const operand_26 = @as([]const u8, "lexical");
                const operand_27 = (in).start;
                const operand_28 = ((in).start + (value_1).end);
                const operand_29 = (value_1).diagnostic;
                const operand_30 = in;

                break :block_33 block_32: {
                    const operand_31 = (try (allocator).create(zx_type_32));

                    (operand_31).* = @as(zx_type_32, zx_type_32{ .code = operand_26, .start = operand_27, .end = operand_28, .message = operand_29, .state = operand_30, });

                    break :block_32 @as(*const zx_type_32, operand_31);
                };
            };
            const operand_35 = (try function_6_value(allocator, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = (operand_34).code, .end = (operand_34).end, .message = (operand_34).message, .start = (operand_34).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_34).state).ahead_one, .ahead_two = ((operand_34).state).ahead_two, .braces = ((operand_34).state).braces, .comments = ((operand_34).state).comments, .depth = ((operand_34).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_34).state).diagnostic).code, .end = (((operand_34).state).diagnostic).end, .message = (((operand_34).state).diagnostic).message, .start = (((operand_34).state).diagnostic).start, .zx_origin = ((operand_34).state).diagnostic, }, .dollar = ((operand_34).state).dollar, .frames = ((operand_34).state).frames, .keyword_state = ((operand_34).state).keyword_state, .line_break = ((operand_34).state).line_break, .mode = ((operand_34).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_34).state).number).end, .last_byte = (((operand_34).state).number).last_byte, .phase = (((operand_34).state).number).phase, .separators_valid = (((operand_34).state).number).separators_valid, .zx_origin = ((operand_34).state).number, }, .offset = ((operand_34).state).offset, .skip_until = ((operand_34).state).skip_until, .source_length = ((operand_34).state).source_length, .start = ((operand_34).state).start, .symbol = ((operand_34).state).symbol, .tokens = ((operand_34).state).tokens, .warmed = ((operand_34).state).warmed, .zx_origin = (operand_34).state, }, .zx_origin = operand_34, }));

            break :block_42 (if (((operand_35).zx_origin != null)) (operand_35).zx_origin.? else block_41: {
                const operand_40 = (try (allocator).create(zx_type_28));

                (operand_40).* = zx_type_28{ .ahead_one = (operand_35).ahead_one, .ahead_two = (operand_35).ahead_two, .braces = (operand_35).braces, .comments = (operand_35).comments, .depth = (operand_35).depth, .diagnostic = (if ((((operand_35).diagnostic).zx_origin != null)) ((operand_35).diagnostic).zx_origin.? else block_37: {
                    const operand_36 = (try (allocator).create(zx_type_23));

                    (operand_36).* = zx_type_23{ .code = ((operand_35).diagnostic).code, .end = ((operand_35).diagnostic).end, .message = ((operand_35).diagnostic).message, .start = ((operand_35).diagnostic).start, };

                    break :block_37 @as(*const zx_type_23, operand_36);
                }), .dollar = (operand_35).dollar, .frames = (operand_35).frames, .keyword_state = (operand_35).keyword_state, .line_break = (operand_35).line_break, .mode = (operand_35).mode, .number = (if ((((operand_35).number).zx_origin != null)) ((operand_35).number).zx_origin.? else block_39: {
                    const operand_38 = (try (allocator).create(zx_type_20));

                    (operand_38).* = zx_type_20{ .end = ((operand_35).number).end, .last_byte = ((operand_35).number).last_byte, .phase = ((operand_35).number).phase, .separators_valid = ((operand_35).number).separators_valid, };

                    break :block_39 @as(*const zx_type_20, operand_38);
                }), .offset = (operand_35).offset, .skip_until = (operand_35).skip_until, .source_length = (operand_35).source_length, .start = (operand_35).start, .symbol = (operand_35).symbol, .tokens = (operand_35).tokens, .warmed = (operand_35).warmed, };

                break :block_41 @as(*const zx_type_28, operand_40);
            });
        };
    }

    return block_22: {
        const operand_14 = block_13: {
            const operand_1 = @as([]const u8, "number");
            const operand_2 = (in).start;
            const operand_3 = ((in).start + (value_1).end);
            const operand_4 = false;
            const operand_5 = block_10: {
                const operand_6 = in;
                const operand_7 = @as(zx_type_22, .Idle);

                break :block_10 block_9: {
                    const operand_8 = (try (allocator).create(zx_type_28));

                    (operand_8).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_6).ahead_one, .ahead_two = (operand_6).ahead_two, .braces = (operand_6).braces, .comments = (operand_6).comments, .depth = (operand_6).depth, .diagnostic = (operand_6).diagnostic, .dollar = (operand_6).dollar, .frames = (operand_6).frames, .keyword_state = (operand_6).keyword_state, .line_break = (operand_6).line_break, .mode = operand_7, .number = (operand_6).number, .offset = (operand_6).offset, .skip_until = (operand_6).skip_until, .source_length = (operand_6).source_length, .start = (operand_6).start, .symbol = (operand_6).symbol, .tokens = (operand_6).tokens, .warmed = (operand_6).warmed, });

                    break :block_9 @as(*const zx_type_28, operand_8);
                };
            };

            break :block_13 block_12: {
                const operand_11 = (try (allocator).create(zx_type_31));

                (operand_11).* = @as(zx_type_31, zx_type_31{ .kind = operand_1, .start = operand_2, .end = operand_3, .comment = operand_4, .state = operand_5, });

                break :block_12 @as(*const zx_type_31, operand_11);
            };
        };
        const operand_15 = (try function_5_value(allocator, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .comment = (operand_14).comment, .end = (operand_14).end, .kind = (operand_14).kind, .start = (operand_14).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_14).state).ahead_one, .ahead_two = ((operand_14).state).ahead_two, .braces = ((operand_14).state).braces, .comments = ((operand_14).state).comments, .depth = ((operand_14).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_14).state).diagnostic).code, .end = (((operand_14).state).diagnostic).end, .message = (((operand_14).state).diagnostic).message, .start = (((operand_14).state).diagnostic).start, .zx_origin = ((operand_14).state).diagnostic, }, .dollar = ((operand_14).state).dollar, .frames = ((operand_14).state).frames, .keyword_state = ((operand_14).state).keyword_state, .line_break = ((operand_14).state).line_break, .mode = ((operand_14).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_14).state).number).end, .last_byte = (((operand_14).state).number).last_byte, .phase = (((operand_14).state).number).phase, .separators_valid = (((operand_14).state).number).separators_valid, .zx_origin = ((operand_14).state).number, }, .offset = ((operand_14).state).offset, .skip_until = ((operand_14).state).skip_until, .source_length = ((operand_14).state).source_length, .start = ((operand_14).state).start, .symbol = ((operand_14).state).symbol, .tokens = ((operand_14).state).tokens, .warmed = ((operand_14).state).warmed, .zx_origin = (operand_14).state, }, .zx_origin = operand_14, }));

        break :block_22 (if (((operand_15).zx_origin != null)) (operand_15).zx_origin.? else block_21: {
            const operand_20 = (try (allocator).create(zx_type_28));

            (operand_20).* = zx_type_28{ .ahead_one = (operand_15).ahead_one, .ahead_two = (operand_15).ahead_two, .braces = (operand_15).braces, .comments = (operand_15).comments, .depth = (operand_15).depth, .diagnostic = (if ((((operand_15).diagnostic).zx_origin != null)) ((operand_15).diagnostic).zx_origin.? else block_17: {
                const operand_16 = (try (allocator).create(zx_type_23));

                (operand_16).* = zx_type_23{ .code = ((operand_15).diagnostic).code, .end = ((operand_15).diagnostic).end, .message = ((operand_15).diagnostic).message, .start = ((operand_15).diagnostic).start, };

                break :block_17 @as(*const zx_type_23, operand_16);
            }), .dollar = (operand_15).dollar, .frames = (operand_15).frames, .keyword_state = (operand_15).keyword_state, .line_break = (operand_15).line_break, .mode = (operand_15).mode, .number = (if ((((operand_15).number).zx_origin != null)) ((operand_15).number).zx_origin.? else block_19: {
                const operand_18 = (try (allocator).create(zx_type_20));

                (operand_18).* = zx_type_20{ .end = ((operand_15).number).end, .last_byte = ((operand_15).number).last_byte, .phase = ((operand_15).number).phase, .separators_valid = ((operand_15).number).separators_valid, };

                break :block_19 @as(*const zx_type_20, operand_18);
            }), .offset = (operand_15).offset, .skip_until = (operand_15).skip_until, .source_length = (operand_15).source_length, .start = (operand_15).start, .symbol = (operand_15).symbol, .tokens = (operand_15).tokens, .warmed = (operand_15).warmed, };

            break :block_21 @as(*const zx_type_28, operand_20);
        });
    };
}

fn function_42_value(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_68: {
        break :block_68 (try function_41_value(allocator, (in).number));
    };

    if ((!block_60: {
        const operand_58 = (value_1).diagnostic;
        const operand_59 = @as([]const u8, "");

        break :block_60 ((std).mem).eql(u8, operand_58, operand_59);
    })) {
        return block_67: {
            break :block_67 (try function_6_value(allocator, block_66: {
                const operand_61 = @as([]const u8, "lexical");
                const operand_62 = (in).start;
                const operand_63 = ((in).start + (value_1).end);
                const operand_64 = (value_1).diagnostic;
                const operand_65 = in;

                break :block_66 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_61, .start = operand_62, .end = operand_63, .message = operand_64, .state = operand_65, });
            }));
        };
    }

    return block_57: {
        break :block_57 (try function_5_value(allocator, block_56: {
            const operand_48 = @as([]const u8, "number");
            const operand_49 = (in).start;
            const operand_50 = ((in).start + (value_1).end);
            const operand_51 = false;
            const operand_52 = block_55: {
                const operand_53 = in;
                const operand_54 = @as(zx_type_22, .Idle);

                break :block_55 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_53).ahead_one, .ahead_two = (operand_53).ahead_two, .braces = (operand_53).braces, .comments = (operand_53).comments, .depth = (operand_53).depth, .diagnostic = (operand_53).diagnostic, .dollar = (operand_53).dollar, .frames = (operand_53).frames, .keyword_state = (operand_53).keyword_state, .line_break = (operand_53).line_break, .mode = operand_54, .number = (operand_53).number, .offset = (operand_53).offset, .skip_until = (operand_53).skip_until, .source_length = (operand_53).source_length, .start = (operand_53).start, .symbol = (operand_53).symbol, .tokens = (operand_53).tokens, .warmed = (operand_53).warmed, });
            };

            break :block_56 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_48, .start = operand_49, .end = operand_50, .comment = operand_51, .state = operand_52, });
        }));
    };
}

fn function_42_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_89: {
        break :block_89 (try function_41_value(allocator, (in).number));
    };

    if ((!block_81: {
        const operand_79 = (value_1).diagnostic;
        const operand_80 = @as([]const u8, "");

        break :block_81 ((std).mem).eql(u8, operand_79, operand_80);
    })) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_88: {
            break :block_88 (try function_6_buffered(allocator, block_87: {
                const operand_82 = @as([]const u8, "lexical");
                const operand_83 = (in).start;
                const operand_84 = ((in).start + (value_1).end);
                const operand_85 = (value_1).diagnostic;
                const operand_86 = in;

                break :block_87 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_82, .start = operand_83, .end = operand_84, .message = operand_85, .state = operand_86, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_78: {
        break :block_78 (try function_5_buffered(allocator, block_77: {
            const operand_69 = @as([]const u8, "number");
            const operand_70 = (in).start;
            const operand_71 = ((in).start + (value_1).end);
            const operand_72 = false;
            const operand_73 = block_76: {
                const operand_74 = in;
                const operand_75 = @as(zx_type_22, .Idle);

                break :block_76 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_74).ahead_one, .ahead_two = (operand_74).ahead_two, .braces = (operand_74).braces, .comments = (operand_74).comments, .depth = (operand_74).depth, .diagnostic = (operand_74).diagnostic, .dollar = (operand_74).dollar, .frames = (operand_74).frames, .keyword_state = (operand_74).keyword_state, .line_break = (operand_74).line_break, .mode = operand_75, .number = (operand_74).number, .offset = (operand_74).offset, .skip_until = (operand_74).skip_until, .source_length = (operand_74).source_length, .start = (operand_74).start, .symbol = (operand_74).symbol, .tokens = (operand_74).tokens, .warmed = (operand_74).warmed, });
            };

            break :block_77 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_69, .start = operand_70, .end = operand_71, .comment = operand_72, .state = operand_73, });
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    });
}

fn function_42_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_28, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: *const zx_type_21 = block_118: {
        const operand_114 = (in).number;
        const operand_115 = (try function_41_value(allocator, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (operand_114).end, .last_byte = (operand_114).last_byte, .phase = (operand_114).phase, .separators_valid = (operand_114).separators_valid, .zx_origin = operand_114, }));

        break :block_118 (if (((operand_115).zx_origin != null)) (operand_115).zx_origin.? else block_117: {
            const operand_116 = (try (allocator).create(zx_type_21));

            (operand_116).* = zx_type_21{ .diagnostic = (operand_115).diagnostic, .end = (operand_115).end, };

            break :block_117 @as(*const zx_type_21, operand_116);
        });
    };

    if ((!block_105: {
        const operand_103 = (value_1).diagnostic;
        const operand_104 = @as([]const u8, "");

        break :block_105 ((std).mem).eql(u8, operand_103, operand_104);
    })) {
        return (try function_6_buffered_pointer(allocator, block_113: {
            const operand_106 = @as([]const u8, "lexical");
            const operand_107 = (in).start;
            const operand_108 = ((in).start + (value_1).end);
            const operand_109 = (value_1).diagnostic;
            const operand_110 = in;

            break :block_113 block_112: {
                const operand_111 = (try (allocator).create(zx_type_32));

                (operand_111).* = @as(zx_type_32, zx_type_32{ .code = operand_106, .start = operand_107, .end = operand_108, .message = operand_109, .state = operand_110, });

                break :block_112 @as(*const zx_type_32, operand_111);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    return (try function_5_buffered_pointer(allocator, block_102: {
        const operand_90 = @as([]const u8, "number");
        const operand_91 = (in).start;
        const operand_92 = ((in).start + (value_1).end);
        const operand_93 = false;
        const operand_94 = block_99: {
            const operand_95 = in;
            const operand_96 = @as(zx_type_22, .Idle);

            break :block_99 block_98: {
                const operand_97 = (try (allocator).create(zx_type_28));

                (operand_97).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_95).ahead_one, .ahead_two = (operand_95).ahead_two, .braces = (operand_95).braces, .comments = (operand_95).comments, .depth = (operand_95).depth, .diagnostic = (operand_95).diagnostic, .dollar = (operand_95).dollar, .frames = (operand_95).frames, .keyword_state = (operand_95).keyword_state, .line_break = (operand_95).line_break, .mode = operand_96, .number = (operand_95).number, .offset = (operand_95).offset, .skip_until = (operand_95).skip_until, .source_length = (operand_95).source_length, .start = (operand_95).start, .symbol = (operand_95).symbol, .tokens = (operand_95).tokens, .warmed = (operand_95).warmed, });

                break :block_98 @as(*const zx_type_28, operand_97);
            };
        };

        break :block_102 block_101: {
            const operand_100 = (try (allocator).create(zx_type_31));

            (operand_100).* = @as(zx_type_31, zx_type_31{ .kind = operand_90, .start = operand_91, .end = operand_92, .comment = operand_93, .state = operand_94, });

            break :block_101 @as(*const zx_type_31, operand_100);
        };
    }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
}

fn function_43(allocator: ((std).mem).Allocator, in: *const zx_type_36) error{ OutOfMemory, }!*const zx_type_20 {
    @setRuntimeSafety(true);

    if ((((in).state).phase == @as(zx_type_19, .Done))) {
        return block_60: {
            const operand_54 = ((in).state).end;
            const operand_55 = ((in).state).phase;
            const operand_56 = ((in).state).last_byte;
            const operand_57 = ((in).state).separators_valid;

            break :block_60 block_59: {
                const operand_58 = (try (allocator).create(zx_type_20));

                (operand_58).* = @as(zx_type_20, zx_type_20{ .end = operand_54, .phase = operand_55, .last_byte = operand_56, .separators_valid = operand_57, });

                break :block_59 @as(*const zx_type_20, operand_58);
            };
        };
    }

    if ((((in).state).phase == @as(zx_type_19, .FractionStart))) {
        if ((try function_33(allocator, (in).byte))) {
            return block_53: {
                const operand_46 = (in).state;
                const operand_47 = (((in).state).end + @as(u64, 2));
                const operand_48 = @as(zx_type_19, .Fraction);
                const operand_49 = (in).byte;
                const operand_50 = (((in).state).separators_valid and (((in).state).last_byte != @as(u8, 95)));

                _ = operand_46;

                break :block_53 block_52: {
                    const operand_51 = (try (allocator).create(zx_type_20));

                    (operand_51).* = @as(zx_type_20, zx_type_20{ .end = operand_47, .last_byte = operand_49, .phase = operand_48, .separators_valid = operand_50, });

                    break :block_52 @as(*const zx_type_20, operand_51);
                };
            };
        }

        return block_45: {
            const operand_41 = (in).state;
            const operand_42 = @as(zx_type_19, .Done);

            break :block_45 block_44: {
                const operand_43 = (try (allocator).create(zx_type_20));

                (operand_43).* = @as(zx_type_20, zx_type_20{ .end = (operand_41).end, .last_byte = (operand_41).last_byte, .phase = operand_42, .separators_valid = (operand_41).separators_valid, });

                break :block_44 @as(*const zx_type_20, operand_43);
            };
        };
    }

    if ((try function_33(allocator, (in).byte))) {
        return block_40: {
            const operand_34 = (in).state;
            const operand_35 = (((in).state).end + @as(u64, 1));
            const operand_36 = (if ((((in).state).phase == @as(zx_type_19, .ExponentStart))) @as(zx_type_19, .ExponentDigits) else ((in).state).phase);
            const operand_37 = (in).byte;

            break :block_40 block_39: {
                const operand_38 = (try (allocator).create(zx_type_20));

                (operand_38).* = @as(zx_type_20, zx_type_20{ .end = operand_35, .last_byte = operand_37, .phase = operand_36, .separators_valid = (operand_34).separators_valid, });

                break :block_39 @as(*const zx_type_20, operand_38);
            };
        };
    }

    if (((in).byte == @as(u8, 95))) {
        return block_33: {
            const operand_26 = (in).state;
            const operand_27 = (((in).state).end + @as(u64, 1));
            const operand_28 = (if ((((in).state).phase == @as(zx_type_19, .ExponentStart))) @as(zx_type_19, .ExponentDigits) else ((in).state).phase);
            const operand_29 = (in).byte;
            const operand_30 = (((in).state).separators_valid and (try function_33(allocator, ((in).state).last_byte)));

            _ = operand_26;

            break :block_33 block_32: {
                const operand_31 = (try (allocator).create(zx_type_20));

                (operand_31).* = @as(zx_type_20, zx_type_20{ .end = operand_27, .last_byte = operand_29, .phase = operand_28, .separators_valid = operand_30, });

                break :block_32 @as(*const zx_type_20, operand_31);
            };
        };
    }

    if (((((in).state).phase == @as(zx_type_19, .Integer)) and ((in).byte == @as(u8, 46)))) {
        return block_25: {
            const operand_21 = (in).state;
            const operand_22 = @as(zx_type_19, .FractionStart);

            break :block_25 block_24: {
                const operand_23 = (try (allocator).create(zx_type_20));

                (operand_23).* = @as(zx_type_20, zx_type_20{ .end = (operand_21).end, .last_byte = (operand_21).last_byte, .phase = operand_22, .separators_valid = (operand_21).separators_valid, });

                break :block_24 @as(*const zx_type_20, operand_23);
            };
        };
    }

    if ((((((in).state).phase == @as(zx_type_19, .Integer)) or (((in).state).phase == @as(zx_type_19, .Fraction))) and (((in).byte == @as(u8, 101)) or ((in).byte == @as(u8, 69))))) {
        return block_20: {
            const operand_13 = (in).state;
            const operand_14 = (((in).state).end + @as(u64, 1));
            const operand_15 = @as(zx_type_19, .ExponentStart);
            const operand_16 = (in).byte;
            const operand_17 = (((in).state).separators_valid and (((in).state).last_byte != @as(u8, 95)));

            _ = operand_13;

            break :block_20 block_19: {
                const operand_18 = (try (allocator).create(zx_type_20));

                (operand_18).* = @as(zx_type_20, zx_type_20{ .end = operand_14, .last_byte = operand_16, .phase = operand_15, .separators_valid = operand_17, });

                break :block_19 @as(*const zx_type_20, operand_18);
            };
        };
    }

    if (((((in).state).phase == @as(zx_type_19, .ExponentStart)) and (((in).byte == @as(u8, 43)) or ((in).byte == @as(u8, 45))))) {
        return block_12: {
            const operand_6 = (in).state;
            const operand_7 = (((in).state).end + @as(u64, 1));
            const operand_8 = @as(zx_type_19, .ExponentDigits);
            const operand_9 = (in).byte;

            break :block_12 block_11: {
                const operand_10 = (try (allocator).create(zx_type_20));

                (operand_10).* = @as(zx_type_20, zx_type_20{ .end = operand_7, .last_byte = operand_9, .phase = operand_8, .separators_valid = (operand_6).separators_valid, });

                break :block_11 @as(*const zx_type_20, operand_10);
            };
        };
    }

    return block_5: {
        const operand_1 = (in).state;
        const operand_2 = @as(zx_type_19, .Done);

        break :block_5 block_4: {
            const operand_3 = (try (allocator).create(zx_type_20));

            (operand_3).* = @as(zx_type_20, zx_type_20{ .end = (operand_1).end, .last_byte = (operand_1).last_byte, .phase = operand_2, .separators_valid = (operand_1).separators_valid, });

            break :block_4 @as(*const zx_type_20, operand_3);
        };
    };
}

fn function_43_value(allocator: ((std).mem).Allocator, in: value_zx_type_36_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b) error{ OutOfMemory, }!value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    if ((((in).state).phase == @as(zx_type_19, .Done))) {
        return block_102: {
            const operand_98 = ((in).state).end;
            const operand_99 = ((in).state).phase;
            const operand_100 = ((in).state).last_byte;
            const operand_101 = ((in).state).separators_valid;

            break :block_102 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = operand_98, .phase = operand_99, .last_byte = operand_100, .separators_valid = operand_101, });
        };
    }

    if ((((in).state).phase == @as(zx_type_19, .FractionStart))) {
        if ((try function_33(allocator, (in).byte))) {
            return block_97: {
                const operand_92 = (in).state;
                const operand_93 = (((in).state).end + @as(u64, 2));
                const operand_94 = @as(zx_type_19, .Fraction);
                const operand_95 = (in).byte;
                const operand_96 = (((in).state).separators_valid and (((in).state).last_byte != @as(u8, 95)));

                _ = operand_92;

                break :block_97 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = operand_93, .last_byte = operand_95, .phase = operand_94, .separators_valid = operand_96, });
            };
        }

        return block_91: {
            const operand_89 = (in).state;
            const operand_90 = @as(zx_type_19, .Done);

            break :block_91 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (operand_89).end, .last_byte = (operand_89).last_byte, .phase = operand_90, .separators_valid = (operand_89).separators_valid, });
        };
    }

    if ((try function_33(allocator, (in).byte))) {
        return block_88: {
            const operand_84 = (in).state;
            const operand_85 = (((in).state).end + @as(u64, 1));
            const operand_86 = (if ((((in).state).phase == @as(zx_type_19, .ExponentStart))) @as(zx_type_19, .ExponentDigits) else ((in).state).phase);
            const operand_87 = (in).byte;

            break :block_88 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = operand_85, .last_byte = operand_87, .phase = operand_86, .separators_valid = (operand_84).separators_valid, });
        };
    }

    if (((in).byte == @as(u8, 95))) {
        return block_83: {
            const operand_78 = (in).state;
            const operand_79 = (((in).state).end + @as(u64, 1));
            const operand_80 = (if ((((in).state).phase == @as(zx_type_19, .ExponentStart))) @as(zx_type_19, .ExponentDigits) else ((in).state).phase);
            const operand_81 = (in).byte;
            const operand_82 = (((in).state).separators_valid and (try function_33(allocator, ((in).state).last_byte)));

            _ = operand_78;

            break :block_83 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = operand_79, .last_byte = operand_81, .phase = operand_80, .separators_valid = operand_82, });
        };
    }

    if (((((in).state).phase == @as(zx_type_19, .Integer)) and ((in).byte == @as(u8, 46)))) {
        return block_77: {
            const operand_75 = (in).state;
            const operand_76 = @as(zx_type_19, .FractionStart);

            break :block_77 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (operand_75).end, .last_byte = (operand_75).last_byte, .phase = operand_76, .separators_valid = (operand_75).separators_valid, });
        };
    }

    if ((((((in).state).phase == @as(zx_type_19, .Integer)) or (((in).state).phase == @as(zx_type_19, .Fraction))) and (((in).byte == @as(u8, 101)) or ((in).byte == @as(u8, 69))))) {
        return block_74: {
            const operand_69 = (in).state;
            const operand_70 = (((in).state).end + @as(u64, 1));
            const operand_71 = @as(zx_type_19, .ExponentStart);
            const operand_72 = (in).byte;
            const operand_73 = (((in).state).separators_valid and (((in).state).last_byte != @as(u8, 95)));

            _ = operand_69;

            break :block_74 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = operand_70, .last_byte = operand_72, .phase = operand_71, .separators_valid = operand_73, });
        };
    }

    if (((((in).state).phase == @as(zx_type_19, .ExponentStart)) and (((in).byte == @as(u8, 43)) or ((in).byte == @as(u8, 45))))) {
        return block_68: {
            const operand_64 = (in).state;
            const operand_65 = (((in).state).end + @as(u64, 1));
            const operand_66 = @as(zx_type_19, .ExponentDigits);
            const operand_67 = (in).byte;

            break :block_68 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = operand_65, .last_byte = operand_67, .phase = operand_66, .separators_valid = (operand_64).separators_valid, });
        };
    }

    return block_63: {
        const operand_61 = (in).state;
        const operand_62 = @as(zx_type_19, .Done);

        break :block_63 @as(value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (operand_61).end, .last_byte = (operand_61).last_byte, .phase = operand_62, .separators_valid = (operand_61).separators_valid, });
    };
}

fn function_44(allocator: ((std).mem).Allocator, in: *const zx_type_29) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((((in).state).number).phase == @as(zx_type_19, .Integer)) and ((in).byte == @as(u8, 46))) and ((!(in).has_next) or (!(try function_33(allocator, (in).next)))));
    const value_2: *const zx_type_20 = block_45: {
        const operand_41 = block_40: {
            const operand_36 = (in).byte;
            const operand_37 = ((in).state).number;

            break :block_40 block_39: {
                const operand_38 = (try (allocator).create(zx_type_36));

                (operand_38).* = @as(zx_type_36, zx_type_36{ .byte = operand_36, .state = operand_37, });

                break :block_39 @as(*const zx_type_36, operand_38);
            };
        };
        const operand_42 = (try function_43_value(allocator, value_zx_type_36_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b{ .byte = (operand_41).byte, .state = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_41).state).end, .last_byte = ((operand_41).state).last_byte, .phase = ((operand_41).state).phase, .separators_valid = ((operand_41).state).separators_valid, .zx_origin = (operand_41).state, }, .zx_origin = operand_41, }));

        break :block_45 (if (((operand_42).zx_origin != null)) (operand_42).zx_origin.? else block_44: {
            const operand_43 = (try (allocator).create(zx_type_20));

            (operand_43).* = zx_type_20{ .end = (operand_42).end, .last_byte = (operand_42).last_byte, .phase = (operand_42).phase, .separators_valid = (operand_42).separators_valid, };

            break :block_44 @as(*const zx_type_20, operand_43);
        });
    };

    if ((value_1 or ((value_2).phase == @as(zx_type_19, .Done)))) {
        const value_3: *const zx_type_28 = block_35: {
            const operand_27 = (in).state;
            const operand_28 = (try function_42_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_27).ahead_one, .ahead_two = (operand_27).ahead_two, .braces = (operand_27).braces, .comments = (operand_27).comments, .depth = (operand_27).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_27).diagnostic).code, .end = ((operand_27).diagnostic).end, .message = ((operand_27).diagnostic).message, .start = ((operand_27).diagnostic).start, .zx_origin = (operand_27).diagnostic, }, .dollar = (operand_27).dollar, .frames = (operand_27).frames, .keyword_state = (operand_27).keyword_state, .line_break = (operand_27).line_break, .mode = (operand_27).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_27).number).end, .last_byte = ((operand_27).number).last_byte, .phase = ((operand_27).number).phase, .separators_valid = ((operand_27).number).separators_valid, .zx_origin = (operand_27).number, }, .offset = (operand_27).offset, .skip_until = (operand_27).skip_until, .source_length = (operand_27).source_length, .start = (operand_27).start, .symbol = (operand_27).symbol, .tokens = (operand_27).tokens, .warmed = (operand_27).warmed, .zx_origin = operand_27, }));

            break :block_35 (if (((operand_28).zx_origin != null)) (operand_28).zx_origin.? else block_34: {
                const operand_33 = (try (allocator).create(zx_type_28));

                (operand_33).* = zx_type_28{ .ahead_one = (operand_28).ahead_one, .ahead_two = (operand_28).ahead_two, .braces = (operand_28).braces, .comments = (operand_28).comments, .depth = (operand_28).depth, .diagnostic = (if ((((operand_28).diagnostic).zx_origin != null)) ((operand_28).diagnostic).zx_origin.? else block_30: {
                    const operand_29 = (try (allocator).create(zx_type_23));

                    (operand_29).* = zx_type_23{ .code = ((operand_28).diagnostic).code, .end = ((operand_28).diagnostic).end, .message = ((operand_28).diagnostic).message, .start = ((operand_28).diagnostic).start, };

                    break :block_30 @as(*const zx_type_23, operand_29);
                }), .dollar = (operand_28).dollar, .frames = (operand_28).frames, .keyword_state = (operand_28).keyword_state, .line_break = (operand_28).line_break, .mode = (operand_28).mode, .number = (if ((((operand_28).number).zx_origin != null)) ((operand_28).number).zx_origin.? else block_32: {
                    const operand_31 = (try (allocator).create(zx_type_20));

                    (operand_31).* = zx_type_20{ .end = ((operand_28).number).end, .last_byte = ((operand_28).number).last_byte, .phase = ((operand_28).number).phase, .separators_valid = ((operand_28).number).separators_valid, };

                    break :block_32 @as(*const zx_type_20, operand_31);
                }), .offset = (operand_28).offset, .skip_until = (operand_28).skip_until, .source_length = (operand_28).source_length, .start = (operand_28).start, .symbol = (operand_28).symbol, .tokens = (operand_28).tokens, .warmed = (operand_28).warmed, };

                break :block_34 @as(*const zx_type_28, operand_33);
            });
        };

        if ((!block_26: {
            const operand_24 = ((value_3).diagnostic).message;
            const operand_25 = @as([]const u8, "");

            break :block_26 ((std).mem).eql(u8, operand_24, operand_25);
        })) {
            return value_3;
        }

        return block_23: {
            const operand_15 = block_14: {
                const operand_6 = (in).byte;
                const operand_7 = (in).next;
                const operand_8 = (in).after;
                const operand_9 = (in).has_next;
                const operand_10 = (in).has_after;
                const operand_11 = value_3;

                break :block_14 block_13: {
                    const operand_12 = (try (allocator).create(zx_type_29));

                    (operand_12).* = @as(zx_type_29, zx_type_29{ .byte = operand_6, .next = operand_7, .after = operand_8, .has_next = operand_9, .has_after = operand_10, .state = operand_11, });

                    break :block_13 @as(*const zx_type_29, operand_12);
                };
            };
            const operand_16 = (try function_37_value(allocator, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .after = (operand_15).after, .byte = (operand_15).byte, .has_after = (operand_15).has_after, .has_next = (operand_15).has_next, .next = (operand_15).next, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_15).state).ahead_one, .ahead_two = ((operand_15).state).ahead_two, .braces = ((operand_15).state).braces, .comments = ((operand_15).state).comments, .depth = ((operand_15).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_15).state).diagnostic).code, .end = (((operand_15).state).diagnostic).end, .message = (((operand_15).state).diagnostic).message, .start = (((operand_15).state).diagnostic).start, .zx_origin = ((operand_15).state).diagnostic, }, .dollar = ((operand_15).state).dollar, .frames = ((operand_15).state).frames, .keyword_state = ((operand_15).state).keyword_state, .line_break = ((operand_15).state).line_break, .mode = ((operand_15).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_15).state).number).end, .last_byte = (((operand_15).state).number).last_byte, .phase = (((operand_15).state).number).phase, .separators_valid = (((operand_15).state).number).separators_valid, .zx_origin = ((operand_15).state).number, }, .offset = ((operand_15).state).offset, .skip_until = ((operand_15).state).skip_until, .source_length = ((operand_15).state).source_length, .start = ((operand_15).state).start, .symbol = ((operand_15).state).symbol, .tokens = ((operand_15).state).tokens, .warmed = ((operand_15).state).warmed, .zx_origin = (operand_15).state, }, .zx_origin = operand_15, }));

            break :block_23 (if (((operand_16).zx_origin != null)) (operand_16).zx_origin.? else block_22: {
                const operand_21 = (try (allocator).create(zx_type_28));

                (operand_21).* = zx_type_28{ .ahead_one = (operand_16).ahead_one, .ahead_two = (operand_16).ahead_two, .braces = (operand_16).braces, .comments = (operand_16).comments, .depth = (operand_16).depth, .diagnostic = (if ((((operand_16).diagnostic).zx_origin != null)) ((operand_16).diagnostic).zx_origin.? else block_18: {
                    const operand_17 = (try (allocator).create(zx_type_23));

                    (operand_17).* = zx_type_23{ .code = ((operand_16).diagnostic).code, .end = ((operand_16).diagnostic).end, .message = ((operand_16).diagnostic).message, .start = ((operand_16).diagnostic).start, };

                    break :block_18 @as(*const zx_type_23, operand_17);
                }), .dollar = (operand_16).dollar, .frames = (operand_16).frames, .keyword_state = (operand_16).keyword_state, .line_break = (operand_16).line_break, .mode = (operand_16).mode, .number = (if ((((operand_16).number).zx_origin != null)) ((operand_16).number).zx_origin.? else block_20: {
                    const operand_19 = (try (allocator).create(zx_type_20));

                    (operand_19).* = zx_type_20{ .end = ((operand_16).number).end, .last_byte = ((operand_16).number).last_byte, .phase = ((operand_16).number).phase, .separators_valid = ((operand_16).number).separators_valid, };

                    break :block_20 @as(*const zx_type_20, operand_19);
                }), .offset = (operand_16).offset, .skip_until = (operand_16).skip_until, .source_length = (operand_16).source_length, .start = (operand_16).start, .symbol = (operand_16).symbol, .tokens = (operand_16).tokens, .warmed = (operand_16).warmed, };

                break :block_22 @as(*const zx_type_28, operand_21);
            });
        };
    }

    return block_5: {
        const operand_1 = (in).state;
        const operand_2 = value_2;

        break :block_5 block_4: {
            const operand_3 = (try (allocator).create(zx_type_28));

            (operand_3).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_1).ahead_one, .ahead_two = (operand_1).ahead_two, .braces = (operand_1).braces, .comments = (operand_1).comments, .depth = (operand_1).depth, .diagnostic = (operand_1).diagnostic, .dollar = (operand_1).dollar, .frames = (operand_1).frames, .keyword_state = (operand_1).keyword_state, .line_break = (operand_1).line_break, .mode = (operand_1).mode, .number = operand_2, .offset = (operand_1).offset, .skip_until = (operand_1).skip_until, .source_length = (operand_1).source_length, .start = (operand_1).start, .symbol = (operand_1).symbol, .tokens = (operand_1).tokens, .warmed = (operand_1).warmed, });

            break :block_4 @as(*const zx_type_28, operand_3);
        };
    };
}

fn function_44_value(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((((in).state).number).phase == @as(zx_type_19, .Integer)) and ((in).byte == @as(u8, 46))) and ((!(in).has_next) or (!(try function_33(allocator, (in).next)))));
    const value_2: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_65: {
        break :block_65 (try function_43_value(allocator, block_64: {
            const operand_62 = (in).byte;
            const operand_63 = ((in).state).number;

            break :block_64 @as(value_zx_type_36_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b, value_zx_type_36_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b{ .byte = operand_62, .state = operand_63, });
        }));
    };

    if ((block_49: {
        break :block_49 value_1;
    } or ((value_2).phase == @as(zx_type_19, .Done)))) {
        const value_3: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_61: {
            break :block_61 (try function_42_value(allocator, (in).state));
        };

        if ((!block_60: {
            const operand_58 = ((value_3).diagnostic).message;
            const operand_59 = @as([]const u8, "");

            break :block_60 ((std).mem).eql(u8, operand_58, operand_59);
        })) {
            return value_3;
        }

        return block_57: {
            break :block_57 (try function_37_value(allocator, block_56: {
                const operand_50 = (in).byte;
                const operand_51 = (in).next;
                const operand_52 = (in).after;
                const operand_53 = (in).has_next;
                const operand_54 = (in).has_after;
                const operand_55 = value_3;

                break :block_56 @as(value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .byte = operand_50, .next = operand_51, .after = operand_52, .has_next = operand_53, .has_after = operand_54, .state = operand_55, });
            }));
        };
    }

    return block_48: {
        const operand_46 = (in).state;
        const operand_47 = value_2;

        break :block_48 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_46).ahead_one, .ahead_two = (operand_46).ahead_two, .braces = (operand_46).braces, .comments = (operand_46).comments, .depth = (operand_46).depth, .diagnostic = (operand_46).diagnostic, .dollar = (operand_46).dollar, .frames = (operand_46).frames, .keyword_state = (operand_46).keyword_state, .line_break = (operand_46).line_break, .mode = (operand_46).mode, .number = operand_47, .offset = (operand_46).offset, .skip_until = (operand_46).skip_until, .source_length = (operand_46).source_length, .start = (operand_46).start, .symbol = (operand_46).symbol, .tokens = (operand_46).tokens, .warmed = (operand_46).warmed, });
    };
}

fn function_44_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((((in).state).number).phase == @as(zx_type_19, .Integer)) and ((in).byte == @as(u8, 46))) and ((!(in).has_next) or (!(try function_33(allocator, (in).next)))));
    const value_2: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_85: {
        break :block_85 (try function_43_value(allocator, block_84: {
            const operand_82 = (in).byte;
            const operand_83 = ((in).state).number;

            break :block_84 @as(value_zx_type_36_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b, value_zx_type_36_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b{ .byte = operand_82, .state = operand_83, });
        }));
    };

    if ((block_69: {
        break :block_69 value_1;
    } or ((value_2).phase == @as(zx_type_19, .Done)))) {
        const value_3: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_81: {
            break :block_81 (try function_42_buffered(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });

        if ((!block_80: {
            const operand_78 = ((value_3).diagnostic).message;
            const operand_79 = @as([]const u8, "");

            break :block_80 ((std).mem).eql(u8, operand_78, operand_79);
        })) {
            return value_3;
        }

        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_77: {
            break :block_77 (try function_37_buffered(allocator, block_76: {
                const operand_70 = (in).byte;
                const operand_71 = (in).next;
                const operand_72 = (in).after;
                const operand_73 = (in).has_next;
                const operand_74 = (in).has_after;
                const operand_75 = value_3;

                break :block_76 @as(value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .byte = operand_70, .next = operand_71, .after = operand_72, .has_next = operand_73, .has_after = operand_74, .state = operand_75, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    return block_68: {
        const operand_66 = (in).state;
        const operand_67 = value_2;

        break :block_68 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_66).ahead_one, .ahead_two = (operand_66).ahead_two, .braces = (operand_66).braces, .comments = (operand_66).comments, .depth = (operand_66).depth, .diagnostic = (operand_66).diagnostic, .dollar = (operand_66).dollar, .frames = (operand_66).frames, .keyword_state = (operand_66).keyword_state, .line_break = (operand_66).line_break, .mode = (operand_66).mode, .number = operand_67, .offset = (operand_66).offset, .skip_until = (operand_66).skip_until, .source_length = (operand_66).source_length, .start = (operand_66).start, .symbol = (operand_66).symbol, .tokens = (operand_66).tokens, .warmed = (operand_66).warmed, });
    };
}

fn function_44_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_29, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: bool = ((((((in).state).number).phase == @as(zx_type_19, .Integer)) and ((in).byte == @as(u8, 46))) and ((!(in).has_next) or (!(try function_33(allocator, (in).next)))));
    const value_2: *const zx_type_20 = block_112: {
        const operand_108 = block_107: {
            const operand_103 = (in).byte;
            const operand_104 = ((in).state).number;

            break :block_107 block_106: {
                const operand_105 = (try (allocator).create(zx_type_36));

                (operand_105).* = @as(zx_type_36, zx_type_36{ .byte = operand_103, .state = operand_104, });

                break :block_106 @as(*const zx_type_36, operand_105);
            };
        };
        const operand_109 = (try function_43_value(allocator, value_zx_type_36_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b{ .byte = (operand_108).byte, .state = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_108).state).end, .last_byte = ((operand_108).state).last_byte, .phase = ((operand_108).state).phase, .separators_valid = ((operand_108).state).separators_valid, .zx_origin = (operand_108).state, }, .zx_origin = operand_108, }));

        break :block_112 (if (((operand_109).zx_origin != null)) (operand_109).zx_origin.? else block_111: {
            const operand_110 = (try (allocator).create(zx_type_20));

            (operand_110).* = zx_type_20{ .end = (operand_109).end, .last_byte = (operand_109).last_byte, .phase = (operand_109).phase, .separators_valid = (operand_109).separators_valid, };

            break :block_111 @as(*const zx_type_20, operand_110);
        });
    };

    if ((value_1 or ((value_2).phase == @as(zx_type_19, .Done)))) {
        const value_3: *const zx_type_28 = (try function_42_buffered_pointer(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));

        if ((!block_102: {
            const operand_100 = ((value_3).diagnostic).message;
            const operand_101 = @as([]const u8, "");

            break :block_102 ((std).mem).eql(u8, operand_100, operand_101);
        })) {
            return value_3;
        }

        return (try function_37_buffered_pointer(allocator, block_99: {
            const operand_91 = (in).byte;
            const operand_92 = (in).next;
            const operand_93 = (in).after;
            const operand_94 = (in).has_next;
            const operand_95 = (in).has_after;
            const operand_96 = value_3;

            break :block_99 block_98: {
                const operand_97 = (try (allocator).create(zx_type_29));

                (operand_97).* = @as(zx_type_29, zx_type_29{ .byte = operand_91, .next = operand_92, .after = operand_93, .has_next = operand_94, .has_after = operand_95, .state = operand_96, });

                break :block_98 @as(*const zx_type_29, operand_97);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    return block_90: {
        const operand_86 = (in).state;
        const operand_87 = value_2;

        break :block_90 block_89: {
            const operand_88 = (try (allocator).create(zx_type_28));

            (operand_88).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_86).ahead_one, .ahead_two = (operand_86).ahead_two, .braces = (operand_86).braces, .comments = (operand_86).comments, .depth = (operand_86).depth, .diagnostic = (operand_86).diagnostic, .dollar = (operand_86).dollar, .frames = (operand_86).frames, .keyword_state = (operand_86).keyword_state, .line_break = (operand_86).line_break, .mode = (operand_86).mode, .number = operand_87, .offset = (operand_86).offset, .skip_until = (operand_86).skip_until, .source_length = (operand_86).source_length, .start = (operand_86).start, .symbol = (operand_86).symbol, .tokens = (operand_86).tokens, .warmed = (operand_86).warmed, });

            break :block_89 @as(*const zx_type_28, operand_88);
        };
    };
}

fn function_45(allocator: ((std).mem).Allocator, in: *const zx_type_29) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if ((((in).state).mode == @as(zx_type_22, .StringEscape))) {
        if (((((((in).byte != @as(u8, 34)) and ((in).byte != @as(u8, 92))) and ((in).byte != @as(u8, 110))) and ((in).byte != @as(u8, 114))) and ((in).byte != @as(u8, 116)))) {
            return block_66: {
                const operand_58 = block_57: {
                    const operand_50 = @as([]const u8, "lexical");
                    const operand_51 = (((in).state).offset - @as(u64, 1));
                    const operand_52 = (((in).state).offset + @as(u64, 1));
                    const operand_53 = @as([]const u8, "unsupported string escape");
                    const operand_54 = (in).state;

                    break :block_57 block_56: {
                        const operand_55 = (try (allocator).create(zx_type_32));

                        (operand_55).* = @as(zx_type_32, zx_type_32{ .code = operand_50, .start = operand_51, .end = operand_52, .message = operand_53, .state = operand_54, });

                        break :block_56 @as(*const zx_type_32, operand_55);
                    };
                };
                const operand_59 = (try function_6_value(allocator, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = (operand_58).code, .end = (operand_58).end, .message = (operand_58).message, .start = (operand_58).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_58).state).ahead_one, .ahead_two = ((operand_58).state).ahead_two, .braces = ((operand_58).state).braces, .comments = ((operand_58).state).comments, .depth = ((operand_58).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_58).state).diagnostic).code, .end = (((operand_58).state).diagnostic).end, .message = (((operand_58).state).diagnostic).message, .start = (((operand_58).state).diagnostic).start, .zx_origin = ((operand_58).state).diagnostic, }, .dollar = ((operand_58).state).dollar, .frames = ((operand_58).state).frames, .keyword_state = ((operand_58).state).keyword_state, .line_break = ((operand_58).state).line_break, .mode = ((operand_58).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_58).state).number).end, .last_byte = (((operand_58).state).number).last_byte, .phase = (((operand_58).state).number).phase, .separators_valid = (((operand_58).state).number).separators_valid, .zx_origin = ((operand_58).state).number, }, .offset = ((operand_58).state).offset, .skip_until = ((operand_58).state).skip_until, .source_length = ((operand_58).state).source_length, .start = ((operand_58).state).start, .symbol = ((operand_58).state).symbol, .tokens = ((operand_58).state).tokens, .warmed = ((operand_58).state).warmed, .zx_origin = (operand_58).state, }, .zx_origin = operand_58, }));

                break :block_66 (if (((operand_59).zx_origin != null)) (operand_59).zx_origin.? else block_65: {
                    const operand_64 = (try (allocator).create(zx_type_28));

                    (operand_64).* = zx_type_28{ .ahead_one = (operand_59).ahead_one, .ahead_two = (operand_59).ahead_two, .braces = (operand_59).braces, .comments = (operand_59).comments, .depth = (operand_59).depth, .diagnostic = (if ((((operand_59).diagnostic).zx_origin != null)) ((operand_59).diagnostic).zx_origin.? else block_61: {
                        const operand_60 = (try (allocator).create(zx_type_23));

                        (operand_60).* = zx_type_23{ .code = ((operand_59).diagnostic).code, .end = ((operand_59).diagnostic).end, .message = ((operand_59).diagnostic).message, .start = ((operand_59).diagnostic).start, };

                        break :block_61 @as(*const zx_type_23, operand_60);
                    }), .dollar = (operand_59).dollar, .frames = (operand_59).frames, .keyword_state = (operand_59).keyword_state, .line_break = (operand_59).line_break, .mode = (operand_59).mode, .number = (if ((((operand_59).number).zx_origin != null)) ((operand_59).number).zx_origin.? else block_63: {
                        const operand_62 = (try (allocator).create(zx_type_20));

                        (operand_62).* = zx_type_20{ .end = ((operand_59).number).end, .last_byte = ((operand_59).number).last_byte, .phase = ((operand_59).number).phase, .separators_valid = ((operand_59).number).separators_valid, };

                        break :block_63 @as(*const zx_type_20, operand_62);
                    }), .offset = (operand_59).offset, .skip_until = (operand_59).skip_until, .source_length = (operand_59).source_length, .start = (operand_59).start, .symbol = (operand_59).symbol, .tokens = (operand_59).tokens, .warmed = (operand_59).warmed, };

                    break :block_65 @as(*const zx_type_28, operand_64);
                });
            };
        }

        return block_49: {
            const operand_45 = (in).state;
            const operand_46 = @as(zx_type_22, .String);

            break :block_49 block_48: {
                const operand_47 = (try (allocator).create(zx_type_28));

                (operand_47).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_45).ahead_one, .ahead_two = (operand_45).ahead_two, .braces = (operand_45).braces, .comments = (operand_45).comments, .depth = (operand_45).depth, .diagnostic = (operand_45).diagnostic, .dollar = (operand_45).dollar, .frames = (operand_45).frames, .keyword_state = (operand_45).keyword_state, .line_break = (operand_45).line_break, .mode = operand_46, .number = (operand_45).number, .offset = (operand_45).offset, .skip_until = (operand_45).skip_until, .source_length = (operand_45).source_length, .start = (operand_45).start, .symbol = (operand_45).symbol, .tokens = (operand_45).tokens, .warmed = (operand_45).warmed, });

                break :block_48 @as(*const zx_type_28, operand_47);
            };
        };
    }

    if (((in).byte == @as(u8, 34))) {
        return block_44: {
            const operand_36 = block_35: {
                const operand_23 = @as([]const u8, "string");
                const operand_24 = ((in).state).start;
                const operand_25 = (((in).state).offset + @as(u64, 1));
                const operand_26 = false;
                const operand_27 = block_32: {
                    const operand_28 = (in).state;
                    const operand_29 = @as(zx_type_22, .Idle);

                    break :block_32 block_31: {
                        const operand_30 = (try (allocator).create(zx_type_28));

                        (operand_30).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_28).ahead_one, .ahead_two = (operand_28).ahead_two, .braces = (operand_28).braces, .comments = (operand_28).comments, .depth = (operand_28).depth, .diagnostic = (operand_28).diagnostic, .dollar = (operand_28).dollar, .frames = (operand_28).frames, .keyword_state = (operand_28).keyword_state, .line_break = (operand_28).line_break, .mode = operand_29, .number = (operand_28).number, .offset = (operand_28).offset, .skip_until = (operand_28).skip_until, .source_length = (operand_28).source_length, .start = (operand_28).start, .symbol = (operand_28).symbol, .tokens = (operand_28).tokens, .warmed = (operand_28).warmed, });

                        break :block_31 @as(*const zx_type_28, operand_30);
                    };
                };

                break :block_35 block_34: {
                    const operand_33 = (try (allocator).create(zx_type_31));

                    (operand_33).* = @as(zx_type_31, zx_type_31{ .kind = operand_23, .start = operand_24, .end = operand_25, .comment = operand_26, .state = operand_27, });

                    break :block_34 @as(*const zx_type_31, operand_33);
                };
            };
            const operand_37 = (try function_5_value(allocator, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .comment = (operand_36).comment, .end = (operand_36).end, .kind = (operand_36).kind, .start = (operand_36).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_36).state).ahead_one, .ahead_two = ((operand_36).state).ahead_two, .braces = ((operand_36).state).braces, .comments = ((operand_36).state).comments, .depth = ((operand_36).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_36).state).diagnostic).code, .end = (((operand_36).state).diagnostic).end, .message = (((operand_36).state).diagnostic).message, .start = (((operand_36).state).diagnostic).start, .zx_origin = ((operand_36).state).diagnostic, }, .dollar = ((operand_36).state).dollar, .frames = ((operand_36).state).frames, .keyword_state = ((operand_36).state).keyword_state, .line_break = ((operand_36).state).line_break, .mode = ((operand_36).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_36).state).number).end, .last_byte = (((operand_36).state).number).last_byte, .phase = (((operand_36).state).number).phase, .separators_valid = (((operand_36).state).number).separators_valid, .zx_origin = ((operand_36).state).number, }, .offset = ((operand_36).state).offset, .skip_until = ((operand_36).state).skip_until, .source_length = ((operand_36).state).source_length, .start = ((operand_36).state).start, .symbol = ((operand_36).state).symbol, .tokens = ((operand_36).state).tokens, .warmed = ((operand_36).state).warmed, .zx_origin = (operand_36).state, }, .zx_origin = operand_36, }));

            break :block_44 (if (((operand_37).zx_origin != null)) (operand_37).zx_origin.? else block_43: {
                const operand_42 = (try (allocator).create(zx_type_28));

                (operand_42).* = zx_type_28{ .ahead_one = (operand_37).ahead_one, .ahead_two = (operand_37).ahead_two, .braces = (operand_37).braces, .comments = (operand_37).comments, .depth = (operand_37).depth, .diagnostic = (if ((((operand_37).diagnostic).zx_origin != null)) ((operand_37).diagnostic).zx_origin.? else block_39: {
                    const operand_38 = (try (allocator).create(zx_type_23));

                    (operand_38).* = zx_type_23{ .code = ((operand_37).diagnostic).code, .end = ((operand_37).diagnostic).end, .message = ((operand_37).diagnostic).message, .start = ((operand_37).diagnostic).start, };

                    break :block_39 @as(*const zx_type_23, operand_38);
                }), .dollar = (operand_37).dollar, .frames = (operand_37).frames, .keyword_state = (operand_37).keyword_state, .line_break = (operand_37).line_break, .mode = (operand_37).mode, .number = (if ((((operand_37).number).zx_origin != null)) ((operand_37).number).zx_origin.? else block_41: {
                    const operand_40 = (try (allocator).create(zx_type_20));

                    (operand_40).* = zx_type_20{ .end = ((operand_37).number).end, .last_byte = ((operand_37).number).last_byte, .phase = ((operand_37).number).phase, .separators_valid = ((operand_37).number).separators_valid, };

                    break :block_41 @as(*const zx_type_20, operand_40);
                }), .offset = (operand_37).offset, .skip_until = (operand_37).skip_until, .source_length = (operand_37).source_length, .start = (operand_37).start, .symbol = (operand_37).symbol, .tokens = (operand_37).tokens, .warmed = (operand_37).warmed, };

                break :block_43 @as(*const zx_type_28, operand_42);
            });
        };
    }

    if (((in).byte < @as(u8, 32))) {
        return block_22: {
            const operand_14 = block_13: {
                const operand_6 = @as([]const u8, "lexical");
                const operand_7 = ((in).state).start;
                const operand_8 = (((in).state).offset + @as(u64, 1));
                const operand_9 = @as([]const u8, "control characters must be escaped in strings");
                const operand_10 = (in).state;

                break :block_13 block_12: {
                    const operand_11 = (try (allocator).create(zx_type_32));

                    (operand_11).* = @as(zx_type_32, zx_type_32{ .code = operand_6, .start = operand_7, .end = operand_8, .message = operand_9, .state = operand_10, });

                    break :block_12 @as(*const zx_type_32, operand_11);
                };
            };
            const operand_15 = (try function_6_value(allocator, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = (operand_14).code, .end = (operand_14).end, .message = (operand_14).message, .start = (operand_14).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_14).state).ahead_one, .ahead_two = ((operand_14).state).ahead_two, .braces = ((operand_14).state).braces, .comments = ((operand_14).state).comments, .depth = ((operand_14).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_14).state).diagnostic).code, .end = (((operand_14).state).diagnostic).end, .message = (((operand_14).state).diagnostic).message, .start = (((operand_14).state).diagnostic).start, .zx_origin = ((operand_14).state).diagnostic, }, .dollar = ((operand_14).state).dollar, .frames = ((operand_14).state).frames, .keyword_state = ((operand_14).state).keyword_state, .line_break = ((operand_14).state).line_break, .mode = ((operand_14).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_14).state).number).end, .last_byte = (((operand_14).state).number).last_byte, .phase = (((operand_14).state).number).phase, .separators_valid = (((operand_14).state).number).separators_valid, .zx_origin = ((operand_14).state).number, }, .offset = ((operand_14).state).offset, .skip_until = ((operand_14).state).skip_until, .source_length = ((operand_14).state).source_length, .start = ((operand_14).state).start, .symbol = ((operand_14).state).symbol, .tokens = ((operand_14).state).tokens, .warmed = ((operand_14).state).warmed, .zx_origin = (operand_14).state, }, .zx_origin = operand_14, }));

            break :block_22 (if (((operand_15).zx_origin != null)) (operand_15).zx_origin.? else block_21: {
                const operand_20 = (try (allocator).create(zx_type_28));

                (operand_20).* = zx_type_28{ .ahead_one = (operand_15).ahead_one, .ahead_two = (operand_15).ahead_two, .braces = (operand_15).braces, .comments = (operand_15).comments, .depth = (operand_15).depth, .diagnostic = (if ((((operand_15).diagnostic).zx_origin != null)) ((operand_15).diagnostic).zx_origin.? else block_17: {
                    const operand_16 = (try (allocator).create(zx_type_23));

                    (operand_16).* = zx_type_23{ .code = ((operand_15).diagnostic).code, .end = ((operand_15).diagnostic).end, .message = ((operand_15).diagnostic).message, .start = ((operand_15).diagnostic).start, };

                    break :block_17 @as(*const zx_type_23, operand_16);
                }), .dollar = (operand_15).dollar, .frames = (operand_15).frames, .keyword_state = (operand_15).keyword_state, .line_break = (operand_15).line_break, .mode = (operand_15).mode, .number = (if ((((operand_15).number).zx_origin != null)) ((operand_15).number).zx_origin.? else block_19: {
                    const operand_18 = (try (allocator).create(zx_type_20));

                    (operand_18).* = zx_type_20{ .end = ((operand_15).number).end, .last_byte = ((operand_15).number).last_byte, .phase = ((operand_15).number).phase, .separators_valid = ((operand_15).number).separators_valid, };

                    break :block_19 @as(*const zx_type_20, operand_18);
                }), .offset = (operand_15).offset, .skip_until = (operand_15).skip_until, .source_length = (operand_15).source_length, .start = (operand_15).start, .symbol = (operand_15).symbol, .tokens = (operand_15).tokens, .warmed = (operand_15).warmed, };

                break :block_21 @as(*const zx_type_28, operand_20);
            });
        };
    }

    return block_5: {
        const operand_1 = (in).state;
        const operand_2 = (if (((in).byte == @as(u8, 92))) @as(zx_type_22, .StringEscape) else @as(zx_type_22, .String));

        break :block_5 block_4: {
            const operand_3 = (try (allocator).create(zx_type_28));

            (operand_3).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_1).ahead_one, .ahead_two = (operand_1).ahead_two, .braces = (operand_1).braces, .comments = (operand_1).comments, .depth = (operand_1).depth, .diagnostic = (operand_1).diagnostic, .dollar = (operand_1).dollar, .frames = (operand_1).frames, .keyword_state = (operand_1).keyword_state, .line_break = (operand_1).line_break, .mode = operand_2, .number = (operand_1).number, .offset = (operand_1).offset, .skip_until = (operand_1).skip_until, .source_length = (operand_1).source_length, .start = (operand_1).start, .symbol = (operand_1).symbol, .tokens = (operand_1).tokens, .warmed = (operand_1).warmed, });

            break :block_4 @as(*const zx_type_28, operand_3);
        };
    };
}

fn function_45_value(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if ((((in).state).mode == @as(zx_type_22, .StringEscape))) {
        if (((((((in).byte != @as(u8, 34)) and ((in).byte != @as(u8, 92))) and ((in).byte != @as(u8, 110))) and ((in).byte != @as(u8, 114))) and ((in).byte != @as(u8, 116)))) {
            return block_96: {
                break :block_96 (try function_6_value(allocator, block_95: {
                    const operand_90 = @as([]const u8, "lexical");
                    const operand_91 = (((in).state).offset - @as(u64, 1));
                    const operand_92 = (((in).state).offset + @as(u64, 1));
                    const operand_93 = @as([]const u8, "unsupported string escape");
                    const operand_94 = (in).state;

                    break :block_95 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_90, .start = operand_91, .end = operand_92, .message = operand_93, .state = operand_94, });
                }));
            };
        }

        return block_89: {
            const operand_87 = (in).state;
            const operand_88 = @as(zx_type_22, .String);

            break :block_89 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_87).ahead_one, .ahead_two = (operand_87).ahead_two, .braces = (operand_87).braces, .comments = (operand_87).comments, .depth = (operand_87).depth, .diagnostic = (operand_87).diagnostic, .dollar = (operand_87).dollar, .frames = (operand_87).frames, .keyword_state = (operand_87).keyword_state, .line_break = (operand_87).line_break, .mode = operand_88, .number = (operand_87).number, .offset = (operand_87).offset, .skip_until = (operand_87).skip_until, .source_length = (operand_87).source_length, .start = (operand_87).start, .symbol = (operand_87).symbol, .tokens = (operand_87).tokens, .warmed = (operand_87).warmed, });
        };
    }

    if (((in).byte == @as(u8, 34))) {
        return block_86: {
            break :block_86 (try function_5_value(allocator, block_85: {
                const operand_77 = @as([]const u8, "string");
                const operand_78 = ((in).state).start;
                const operand_79 = (((in).state).offset + @as(u64, 1));
                const operand_80 = false;
                const operand_81 = block_84: {
                    const operand_82 = (in).state;
                    const operand_83 = @as(zx_type_22, .Idle);

                    break :block_84 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_82).ahead_one, .ahead_two = (operand_82).ahead_two, .braces = (operand_82).braces, .comments = (operand_82).comments, .depth = (operand_82).depth, .diagnostic = (operand_82).diagnostic, .dollar = (operand_82).dollar, .frames = (operand_82).frames, .keyword_state = (operand_82).keyword_state, .line_break = (operand_82).line_break, .mode = operand_83, .number = (operand_82).number, .offset = (operand_82).offset, .skip_until = (operand_82).skip_until, .source_length = (operand_82).source_length, .start = (operand_82).start, .symbol = (operand_82).symbol, .tokens = (operand_82).tokens, .warmed = (operand_82).warmed, });
                };

                break :block_85 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_77, .start = operand_78, .end = operand_79, .comment = operand_80, .state = operand_81, });
            }));
        };
    }

    if (((in).byte < @as(u8, 32))) {
        return block_76: {
            break :block_76 (try function_6_value(allocator, block_75: {
                const operand_70 = @as([]const u8, "lexical");
                const operand_71 = ((in).state).start;
                const operand_72 = (((in).state).offset + @as(u64, 1));
                const operand_73 = @as([]const u8, "control characters must be escaped in strings");
                const operand_74 = (in).state;

                break :block_75 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_70, .start = operand_71, .end = operand_72, .message = operand_73, .state = operand_74, });
            }));
        };
    }

    return block_69: {
        const operand_67 = (in).state;
        const operand_68 = (if (((in).byte == @as(u8, 92))) @as(zx_type_22, .StringEscape) else @as(zx_type_22, .String));

        break :block_69 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_67).ahead_one, .ahead_two = (operand_67).ahead_two, .braces = (operand_67).braces, .comments = (operand_67).comments, .depth = (operand_67).depth, .diagnostic = (operand_67).diagnostic, .dollar = (operand_67).dollar, .frames = (operand_67).frames, .keyword_state = (operand_67).keyword_state, .line_break = (operand_67).line_break, .mode = operand_68, .number = (operand_67).number, .offset = (operand_67).offset, .skip_until = (operand_67).skip_until, .source_length = (operand_67).source_length, .start = (operand_67).start, .symbol = (operand_67).symbol, .tokens = (operand_67).tokens, .warmed = (operand_67).warmed, });
    };
}

fn function_45_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if ((((in).state).mode == @as(zx_type_22, .StringEscape))) {
        if (((((((in).byte != @as(u8, 34)) and ((in).byte != @as(u8, 92))) and ((in).byte != @as(u8, 110))) and ((in).byte != @as(u8, 114))) and ((in).byte != @as(u8, 116)))) {
            return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_126: {
                break :block_126 (try function_6_buffered(allocator, block_125: {
                    const operand_120 = @as([]const u8, "lexical");
                    const operand_121 = (((in).state).offset - @as(u64, 1));
                    const operand_122 = (((in).state).offset + @as(u64, 1));
                    const operand_123 = @as([]const u8, "unsupported string escape");
                    const operand_124 = (in).state;

                    break :block_125 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_120, .start = operand_121, .end = operand_122, .message = operand_123, .state = operand_124, });
                }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
            });
        }

        return block_119: {
            const operand_117 = (in).state;
            const operand_118 = @as(zx_type_22, .String);

            break :block_119 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_117).ahead_one, .ahead_two = (operand_117).ahead_two, .braces = (operand_117).braces, .comments = (operand_117).comments, .depth = (operand_117).depth, .diagnostic = (operand_117).diagnostic, .dollar = (operand_117).dollar, .frames = (operand_117).frames, .keyword_state = (operand_117).keyword_state, .line_break = (operand_117).line_break, .mode = operand_118, .number = (operand_117).number, .offset = (operand_117).offset, .skip_until = (operand_117).skip_until, .source_length = (operand_117).source_length, .start = (operand_117).start, .symbol = (operand_117).symbol, .tokens = (operand_117).tokens, .warmed = (operand_117).warmed, });
        };
    }

    if (((in).byte == @as(u8, 34))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_116: {
            break :block_116 (try function_5_buffered(allocator, block_115: {
                const operand_107 = @as([]const u8, "string");
                const operand_108 = ((in).state).start;
                const operand_109 = (((in).state).offset + @as(u64, 1));
                const operand_110 = false;
                const operand_111 = block_114: {
                    const operand_112 = (in).state;
                    const operand_113 = @as(zx_type_22, .Idle);

                    break :block_114 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_112).ahead_one, .ahead_two = (operand_112).ahead_two, .braces = (operand_112).braces, .comments = (operand_112).comments, .depth = (operand_112).depth, .diagnostic = (operand_112).diagnostic, .dollar = (operand_112).dollar, .frames = (operand_112).frames, .keyword_state = (operand_112).keyword_state, .line_break = (operand_112).line_break, .mode = operand_113, .number = (operand_112).number, .offset = (operand_112).offset, .skip_until = (operand_112).skip_until, .source_length = (operand_112).source_length, .start = (operand_112).start, .symbol = (operand_112).symbol, .tokens = (operand_112).tokens, .warmed = (operand_112).warmed, });
                };

                break :block_115 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_107, .start = operand_108, .end = operand_109, .comment = operand_110, .state = operand_111, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if (((in).byte < @as(u8, 32))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_106: {
            break :block_106 (try function_6_buffered(allocator, block_105: {
                const operand_100 = @as([]const u8, "lexical");
                const operand_101 = ((in).state).start;
                const operand_102 = (((in).state).offset + @as(u64, 1));
                const operand_103 = @as([]const u8, "control characters must be escaped in strings");
                const operand_104 = (in).state;

                break :block_105 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_100, .start = operand_101, .end = operand_102, .message = operand_103, .state = operand_104, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    return block_99: {
        const operand_97 = (in).state;
        const operand_98 = (if (((in).byte == @as(u8, 92))) @as(zx_type_22, .StringEscape) else @as(zx_type_22, .String));

        break :block_99 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_97).ahead_one, .ahead_two = (operand_97).ahead_two, .braces = (operand_97).braces, .comments = (operand_97).comments, .depth = (operand_97).depth, .diagnostic = (operand_97).diagnostic, .dollar = (operand_97).dollar, .frames = (operand_97).frames, .keyword_state = (operand_97).keyword_state, .line_break = (operand_97).line_break, .mode = operand_98, .number = (operand_97).number, .offset = (operand_97).offset, .skip_until = (operand_97).skip_until, .source_length = (operand_97).source_length, .start = (operand_97).start, .symbol = (operand_97).symbol, .tokens = (operand_97).tokens, .warmed = (operand_97).warmed, });
    };
}

fn function_45_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_29, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if ((((in).state).mode == @as(zx_type_22, .StringEscape))) {
        if (((((((in).byte != @as(u8, 34)) and ((in).byte != @as(u8, 92))) and ((in).byte != @as(u8, 110))) and ((in).byte != @as(u8, 114))) and ((in).byte != @as(u8, 116)))) {
            return (try function_6_buffered_pointer(allocator, block_165: {
                const operand_158 = @as([]const u8, "lexical");
                const operand_159 = (((in).state).offset - @as(u64, 1));
                const operand_160 = (((in).state).offset + @as(u64, 1));
                const operand_161 = @as([]const u8, "unsupported string escape");
                const operand_162 = (in).state;

                break :block_165 block_164: {
                    const operand_163 = (try (allocator).create(zx_type_32));

                    (operand_163).* = @as(zx_type_32, zx_type_32{ .code = operand_158, .start = operand_159, .end = operand_160, .message = operand_161, .state = operand_162, });

                    break :block_164 @as(*const zx_type_32, operand_163);
                };
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        }

        return block_157: {
            const operand_153 = (in).state;
            const operand_154 = @as(zx_type_22, .String);

            break :block_157 block_156: {
                const operand_155 = (try (allocator).create(zx_type_28));

                (operand_155).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_153).ahead_one, .ahead_two = (operand_153).ahead_two, .braces = (operand_153).braces, .comments = (operand_153).comments, .depth = (operand_153).depth, .diagnostic = (operand_153).diagnostic, .dollar = (operand_153).dollar, .frames = (operand_153).frames, .keyword_state = (operand_153).keyword_state, .line_break = (operand_153).line_break, .mode = operand_154, .number = (operand_153).number, .offset = (operand_153).offset, .skip_until = (operand_153).skip_until, .source_length = (operand_153).source_length, .start = (operand_153).start, .symbol = (operand_153).symbol, .tokens = (operand_153).tokens, .warmed = (operand_153).warmed, });

                break :block_156 @as(*const zx_type_28, operand_155);
            };
        };
    }

    if (((in).byte == @as(u8, 34))) {
        return (try function_5_buffered_pointer(allocator, block_152: {
            const operand_140 = @as([]const u8, "string");
            const operand_141 = ((in).state).start;
            const operand_142 = (((in).state).offset + @as(u64, 1));
            const operand_143 = false;
            const operand_144 = block_149: {
                const operand_145 = (in).state;
                const operand_146 = @as(zx_type_22, .Idle);

                break :block_149 block_148: {
                    const operand_147 = (try (allocator).create(zx_type_28));

                    (operand_147).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_145).ahead_one, .ahead_two = (operand_145).ahead_two, .braces = (operand_145).braces, .comments = (operand_145).comments, .depth = (operand_145).depth, .diagnostic = (operand_145).diagnostic, .dollar = (operand_145).dollar, .frames = (operand_145).frames, .keyword_state = (operand_145).keyword_state, .line_break = (operand_145).line_break, .mode = operand_146, .number = (operand_145).number, .offset = (operand_145).offset, .skip_until = (operand_145).skip_until, .source_length = (operand_145).source_length, .start = (operand_145).start, .symbol = (operand_145).symbol, .tokens = (operand_145).tokens, .warmed = (operand_145).warmed, });

                    break :block_148 @as(*const zx_type_28, operand_147);
                };
            };

            break :block_152 block_151: {
                const operand_150 = (try (allocator).create(zx_type_31));

                (operand_150).* = @as(zx_type_31, zx_type_31{ .kind = operand_140, .start = operand_141, .end = operand_142, .comment = operand_143, .state = operand_144, });

                break :block_151 @as(*const zx_type_31, operand_150);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if (((in).byte < @as(u8, 32))) {
        return (try function_6_buffered_pointer(allocator, block_139: {
            const operand_132 = @as([]const u8, "lexical");
            const operand_133 = ((in).state).start;
            const operand_134 = (((in).state).offset + @as(u64, 1));
            const operand_135 = @as([]const u8, "control characters must be escaped in strings");
            const operand_136 = (in).state;

            break :block_139 block_138: {
                const operand_137 = (try (allocator).create(zx_type_32));

                (operand_137).* = @as(zx_type_32, zx_type_32{ .code = operand_132, .start = operand_133, .end = operand_134, .message = operand_135, .state = operand_136, });

                break :block_138 @as(*const zx_type_32, operand_137);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    return block_131: {
        const operand_127 = (in).state;
        const operand_128 = (if (((in).byte == @as(u8, 92))) @as(zx_type_22, .StringEscape) else @as(zx_type_22, .String));

        break :block_131 block_130: {
            const operand_129 = (try (allocator).create(zx_type_28));

            (operand_129).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_127).ahead_one, .ahead_two = (operand_127).ahead_two, .braces = (operand_127).braces, .comments = (operand_127).comments, .depth = (operand_127).depth, .diagnostic = (operand_127).diagnostic, .dollar = (operand_127).dollar, .frames = (operand_127).frames, .keyword_state = (operand_127).keyword_state, .line_break = (operand_127).line_break, .mode = operand_128, .number = (operand_127).number, .offset = (operand_127).offset, .skip_until = (operand_127).skip_until, .source_length = (operand_127).source_length, .start = (operand_127).start, .symbol = (operand_127).symbol, .tokens = (operand_127).tokens, .warmed = (operand_127).warmed, });

            break :block_130 @as(*const zx_type_28, operand_129);
        };
    };
}

fn function_46(allocator: ((std).mem).Allocator, in: *const zx_type_28) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if ((@as(u64, ((in).frames).len) == @as(u64, 0))) {
        return block_58: {
            const operand_50 = block_49: {
                const operand_37 = @as([]const u8, "template");
                const operand_38 = (in).start;
                const operand_39 = ((in).offset + @as(u64, 1));
                const operand_40 = false;
                const operand_41 = block_46: {
                    const operand_42 = in;
                    const operand_43 = @as(zx_type_22, .Idle);

                    break :block_46 block_45: {
                        const operand_44 = (try (allocator).create(zx_type_28));

                        (operand_44).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_42).ahead_one, .ahead_two = (operand_42).ahead_two, .braces = (operand_42).braces, .comments = (operand_42).comments, .depth = (operand_42).depth, .diagnostic = (operand_42).diagnostic, .dollar = (operand_42).dollar, .frames = (operand_42).frames, .keyword_state = (operand_42).keyword_state, .line_break = (operand_42).line_break, .mode = operand_43, .number = (operand_42).number, .offset = (operand_42).offset, .skip_until = (operand_42).skip_until, .source_length = (operand_42).source_length, .start = (operand_42).start, .symbol = (operand_42).symbol, .tokens = (operand_42).tokens, .warmed = (operand_42).warmed, });

                        break :block_45 @as(*const zx_type_28, operand_44);
                    };
                };

                break :block_49 block_48: {
                    const operand_47 = (try (allocator).create(zx_type_31));

                    (operand_47).* = @as(zx_type_31, zx_type_31{ .kind = operand_37, .start = operand_38, .end = operand_39, .comment = operand_40, .state = operand_41, });

                    break :block_48 @as(*const zx_type_31, operand_47);
                };
            };
            const operand_51 = (try function_5_value(allocator, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .comment = (operand_50).comment, .end = (operand_50).end, .kind = (operand_50).kind, .start = (operand_50).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_50).state).ahead_one, .ahead_two = ((operand_50).state).ahead_two, .braces = ((operand_50).state).braces, .comments = ((operand_50).state).comments, .depth = ((operand_50).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_50).state).diagnostic).code, .end = (((operand_50).state).diagnostic).end, .message = (((operand_50).state).diagnostic).message, .start = (((operand_50).state).diagnostic).start, .zx_origin = ((operand_50).state).diagnostic, }, .dollar = ((operand_50).state).dollar, .frames = ((operand_50).state).frames, .keyword_state = ((operand_50).state).keyword_state, .line_break = ((operand_50).state).line_break, .mode = ((operand_50).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_50).state).number).end, .last_byte = (((operand_50).state).number).last_byte, .phase = (((operand_50).state).number).phase, .separators_valid = (((operand_50).state).number).separators_valid, .zx_origin = ((operand_50).state).number, }, .offset = ((operand_50).state).offset, .skip_until = ((operand_50).state).skip_until, .source_length = ((operand_50).state).source_length, .start = ((operand_50).state).start, .symbol = ((operand_50).state).symbol, .tokens = ((operand_50).state).tokens, .warmed = ((operand_50).state).warmed, .zx_origin = (operand_50).state, }, .zx_origin = operand_50, }));

            break :block_58 (if (((operand_51).zx_origin != null)) (operand_51).zx_origin.? else block_57: {
                const operand_56 = (try (allocator).create(zx_type_28));

                (operand_56).* = zx_type_28{ .ahead_one = (operand_51).ahead_one, .ahead_two = (operand_51).ahead_two, .braces = (operand_51).braces, .comments = (operand_51).comments, .depth = (operand_51).depth, .diagnostic = (if ((((operand_51).diagnostic).zx_origin != null)) ((operand_51).diagnostic).zx_origin.? else block_53: {
                    const operand_52 = (try (allocator).create(zx_type_23));

                    (operand_52).* = zx_type_23{ .code = ((operand_51).diagnostic).code, .end = ((operand_51).diagnostic).end, .message = ((operand_51).diagnostic).message, .start = ((operand_51).diagnostic).start, };

                    break :block_53 @as(*const zx_type_23, operand_52);
                }), .dollar = (operand_51).dollar, .frames = (operand_51).frames, .keyword_state = (operand_51).keyword_state, .line_break = (operand_51).line_break, .mode = (operand_51).mode, .number = (if ((((operand_51).number).zx_origin != null)) ((operand_51).number).zx_origin.? else block_55: {
                    const operand_54 = (try (allocator).create(zx_type_20));

                    (operand_54).* = zx_type_20{ .end = ((operand_51).number).end, .last_byte = ((operand_51).number).last_byte, .phase = ((operand_51).number).phase, .separators_valid = ((operand_51).number).separators_valid, };

                    break :block_55 @as(*const zx_type_20, operand_54);
                }), .offset = (operand_51).offset, .skip_until = (operand_51).skip_until, .source_length = (operand_51).source_length, .start = (operand_51).start, .symbol = (operand_51).symbol, .tokens = (operand_51).tokens, .warmed = (operand_51).warmed, };

                break :block_57 @as(*const zx_type_28, operand_56);
            });
        };
    }

    const value_1: u64 = (@as(u64, ((in).frames).len) - @as(u64, 1));
    const value_2: zx_type_22 = (block_36: {
        const operand_34 = (in).frames;
        const operand_35 = value_1;

        if ((operand_35 >= (operand_34).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_36 (operand_34)[@intCast(operand_35)];
    }).mode;
    const value_3: u64 = (block_33: {
        const operand_31 = (in).frames;
        const operand_32 = value_1;

        if ((operand_32 >= (operand_31).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_33 (operand_31)[@intCast(operand_32)];
    }).start;
    const value_4: u64 = (block_30: {
        const operand_28 = (in).frames;
        const operand_29 = value_1;

        if ((operand_29 >= (operand_28).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_30 (operand_28)[@intCast(operand_29)];
    }).braces;
    const value_5: u64 = (block_27: {
        const operand_25 = (in).frames;
        const operand_26 = value_1;

        if ((operand_26 >= (operand_25).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_27 (operand_25)[@intCast(operand_26)];
    }).depth;
    const value_6: []const *const zx_type_24 = (block_24: {
        const operand_23 = (in).frames;

        break :block_24 @as(zx_type_44, (if (((operand_23).len == 0)) .{ operand_23, null, } else .{ (operand_23)[0..((operand_23).len - 1)], (operand_23)[((operand_23).len - 1)], }));
    }).@"0";

    return block_22: {
        const operand_1 = (in).source_length;
        const operand_2 = (in).warmed;
        const operand_3 = (in).ahead_one;
        const operand_4 = (in).ahead_two;
        const operand_5 = (in).keyword_state;
        const operand_6 = (in).symbol;
        const operand_7 = (in).line_break;
        const operand_8 = (in).dollar;
        const operand_9 = (in).offset;
        const operand_10 = (in).skip_until;
        const operand_11 = value_2;
        const operand_12 = value_3;
        const operand_13 = value_4;
        const operand_14 = value_5;
        const operand_15 = value_6;
        const operand_16 = (in).number;
        const operand_17 = (in).tokens;
        const operand_18 = (in).comments;
        const operand_19 = (in).diagnostic;

        break :block_22 block_21: {
            const operand_20 = (try (allocator).create(zx_type_28));

            (operand_20).* = @as(zx_type_28, zx_type_28{ .source_length = operand_1, .warmed = operand_2, .ahead_one = operand_3, .ahead_two = operand_4, .keyword_state = operand_5, .symbol = operand_6, .line_break = operand_7, .dollar = operand_8, .offset = operand_9, .skip_until = operand_10, .mode = operand_11, .start = operand_12, .braces = operand_13, .depth = operand_14, .frames = operand_15, .number = operand_16, .tokens = operand_17, .comments = operand_18, .diagnostic = operand_19, });

            break :block_21 @as(*const zx_type_28, operand_20);
        };
    };
}

fn function_46_value(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if ((@as(u64, ((in).frames).len) == @as(u64, 0))) {
        return block_111: {
            break :block_111 (try function_5_value(allocator, block_110: {
                const operand_102 = @as([]const u8, "template");
                const operand_103 = (in).start;
                const operand_104 = ((in).offset + @as(u64, 1));
                const operand_105 = false;
                const operand_106 = block_109: {
                    const operand_107 = in;
                    const operand_108 = @as(zx_type_22, .Idle);

                    break :block_109 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_107).ahead_one, .ahead_two = (operand_107).ahead_two, .braces = (operand_107).braces, .comments = (operand_107).comments, .depth = (operand_107).depth, .diagnostic = (operand_107).diagnostic, .dollar = (operand_107).dollar, .frames = (operand_107).frames, .keyword_state = (operand_107).keyword_state, .line_break = (operand_107).line_break, .mode = operand_108, .number = (operand_107).number, .offset = (operand_107).offset, .skip_until = (operand_107).skip_until, .source_length = (operand_107).source_length, .start = (operand_107).start, .symbol = (operand_107).symbol, .tokens = (operand_107).tokens, .warmed = (operand_107).warmed, });
                };

                break :block_110 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_102, .start = operand_103, .end = operand_104, .comment = operand_105, .state = operand_106, });
            }));
        };
    }

    const value_1: u64 = (@as(u64, ((in).frames).len) - @as(u64, 1));
    const value_2: zx_type_22 = (block_101: {
        const operand_99 = (in).frames;
        const operand_100 = block_98: {
            break :block_98 value_1;
        };

        if ((operand_100 >= (operand_99).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_101 (operand_99)[@intCast(operand_100)];
    }).mode;
    const value_3: u64 = (block_97: {
        const operand_95 = (in).frames;
        const operand_96 = block_94: {
            break :block_94 value_1;
        };

        if ((operand_96 >= (operand_95).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_97 (operand_95)[@intCast(operand_96)];
    }).start;
    const value_4: u64 = (block_93: {
        const operand_91 = (in).frames;
        const operand_92 = block_90: {
            break :block_90 value_1;
        };

        if ((operand_92 >= (operand_91).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_93 (operand_91)[@intCast(operand_92)];
    }).braces;
    const value_5: u64 = (block_89: {
        const operand_87 = (in).frames;
        const operand_88 = block_86: {
            break :block_86 value_1;
        };

        if ((operand_88 >= (operand_87).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_89 (operand_87)[@intCast(operand_88)];
    }).depth;
    const value_6: []const *const zx_type_24 = (block_85: {
        const operand_84 = (in).frames;

        break :block_85 @as(value_zx_type_44_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_84).len == 0)) .{ operand_84, null, null, } else .{ (operand_84)[0..((operand_84).len - 1)], (operand_84)[((operand_84).len - 1)], null, }));
    }).@"0";

    return block_83: {
        const operand_59 = (in).source_length;
        const operand_60 = (in).warmed;
        const operand_61 = (in).ahead_one;
        const operand_62 = (in).ahead_two;
        const operand_63 = (in).keyword_state;
        const operand_64 = (in).symbol;
        const operand_65 = (in).line_break;
        const operand_66 = (in).dollar;
        const operand_67 = (in).offset;
        const operand_68 = (in).skip_until;
        const operand_69 = block_70: {
            break :block_70 value_2;
        };
        const operand_71 = block_72: {
            break :block_72 value_3;
        };
        const operand_73 = block_74: {
            break :block_74 value_4;
        };
        const operand_75 = block_76: {
            break :block_76 value_5;
        };
        const operand_77 = block_78: {
            break :block_78 value_6;
        };
        const operand_79 = (in).number;
        const operand_80 = (in).tokens;
        const operand_81 = (in).comments;
        const operand_82 = (in).diagnostic;

        break :block_83 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_59, .warmed = operand_60, .ahead_one = operand_61, .ahead_two = operand_62, .keyword_state = operand_63, .symbol = operand_64, .line_break = operand_65, .dollar = operand_66, .offset = operand_67, .skip_until = operand_68, .mode = operand_69, .start = operand_71, .braces = operand_73, .depth = operand_75, .frames = operand_77, .number = operand_79, .tokens = operand_80, .comments = operand_81, .diagnostic = operand_82, });
    };
}

fn function_46_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if ((@as(u64, ((in).frames).len) == @as(u64, 0))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_164: {
            break :block_164 (try function_5_buffered(allocator, block_163: {
                const operand_155 = @as([]const u8, "template");
                const operand_156 = (in).start;
                const operand_157 = ((in).offset + @as(u64, 1));
                const operand_158 = false;
                const operand_159 = block_162: {
                    const operand_160 = in;
                    const operand_161 = @as(zx_type_22, .Idle);

                    break :block_162 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_160).ahead_one, .ahead_two = (operand_160).ahead_two, .braces = (operand_160).braces, .comments = (operand_160).comments, .depth = (operand_160).depth, .diagnostic = (operand_160).diagnostic, .dollar = (operand_160).dollar, .frames = (operand_160).frames, .keyword_state = (operand_160).keyword_state, .line_break = (operand_160).line_break, .mode = operand_161, .number = (operand_160).number, .offset = (operand_160).offset, .skip_until = (operand_160).skip_until, .source_length = (operand_160).source_length, .start = (operand_160).start, .symbol = (operand_160).symbol, .tokens = (operand_160).tokens, .warmed = (operand_160).warmed, });
                };

                break :block_163 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_155, .start = operand_156, .end = operand_157, .comment = operand_158, .state = operand_159, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    const value_1: u64 = (@as(u64, ((in).frames).len) - @as(u64, 1));
    const value_2: zx_type_22 = (block_154: {
        const operand_152 = (in).frames;
        const operand_153 = block_151: {
            break :block_151 value_1;
        };

        if ((operand_153 >= (operand_152).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_154 (operand_152)[@intCast(operand_153)];
    }).mode;
    const value_3: u64 = (block_150: {
        const operand_148 = (in).frames;
        const operand_149 = block_147: {
            break :block_147 value_1;
        };

        if ((operand_149 >= (operand_148).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_150 (operand_148)[@intCast(operand_149)];
    }).start;
    const value_4: u64 = (block_146: {
        const operand_144 = (in).frames;
        const operand_145 = block_143: {
            break :block_143 value_1;
        };

        if ((operand_145 >= (operand_144).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_146 (operand_144)[@intCast(operand_145)];
    }).braces;
    const value_5: u64 = (block_142: {
        const operand_140 = (in).frames;
        const operand_141 = block_139: {
            break :block_139 value_1;
        };

        if ((operand_141 >= (operand_140).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_142 (operand_140)[@intCast(operand_141)];
    }).depth;
    const value_6: []const *const zx_type_24 = (block_138: {
        const operand_137 = (in).frames;

        break :block_138 @as(value_zx_type_44_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_137).len == 0)) .{ operand_137, null, null, } else .{ (operand_137)[0..((operand_137).len - 1)], (operand_137)[((operand_137).len - 1)], null, }));
    }).@"0";

    return block_136: {
        const operand_112 = (in).source_length;
        const operand_113 = (in).warmed;
        const operand_114 = (in).ahead_one;
        const operand_115 = (in).ahead_two;
        const operand_116 = (in).keyword_state;
        const operand_117 = (in).symbol;
        const operand_118 = (in).line_break;
        const operand_119 = (in).dollar;
        const operand_120 = (in).offset;
        const operand_121 = (in).skip_until;
        const operand_122 = block_123: {
            break :block_123 value_2;
        };
        const operand_124 = block_125: {
            break :block_125 value_3;
        };
        const operand_126 = block_127: {
            break :block_127 value_4;
        };
        const operand_128 = block_129: {
            break :block_129 value_5;
        };
        const operand_130 = block_131: {
            break :block_131 value_6;
        };
        const operand_132 = (in).number;
        const operand_133 = (in).tokens;
        const operand_134 = (in).comments;
        const operand_135 = (in).diagnostic;

        break :block_136 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_112, .warmed = operand_113, .ahead_one = operand_114, .ahead_two = operand_115, .keyword_state = operand_116, .symbol = operand_117, .line_break = operand_118, .dollar = operand_119, .offset = operand_120, .skip_until = operand_121, .mode = operand_122, .start = operand_124, .braces = operand_126, .depth = operand_128, .frames = operand_130, .number = operand_132, .tokens = operand_133, .comments = operand_134, .diagnostic = operand_135, });
    };
}

fn function_46_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_28, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if ((@as(u64, ((in).frames).len) == @as(u64, 0))) {
        return (try function_5_buffered_pointer(allocator, block_213: {
            const operand_201 = @as([]const u8, "template");
            const operand_202 = (in).start;
            const operand_203 = ((in).offset + @as(u64, 1));
            const operand_204 = false;
            const operand_205 = block_210: {
                const operand_206 = in;
                const operand_207 = @as(zx_type_22, .Idle);

                break :block_210 block_209: {
                    const operand_208 = (try (allocator).create(zx_type_28));

                    (operand_208).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_206).ahead_one, .ahead_two = (operand_206).ahead_two, .braces = (operand_206).braces, .comments = (operand_206).comments, .depth = (operand_206).depth, .diagnostic = (operand_206).diagnostic, .dollar = (operand_206).dollar, .frames = (operand_206).frames, .keyword_state = (operand_206).keyword_state, .line_break = (operand_206).line_break, .mode = operand_207, .number = (operand_206).number, .offset = (operand_206).offset, .skip_until = (operand_206).skip_until, .source_length = (operand_206).source_length, .start = (operand_206).start, .symbol = (operand_206).symbol, .tokens = (operand_206).tokens, .warmed = (operand_206).warmed, });

                    break :block_209 @as(*const zx_type_28, operand_208);
                };
            };

            break :block_213 block_212: {
                const operand_211 = (try (allocator).create(zx_type_31));

                (operand_211).* = @as(zx_type_31, zx_type_31{ .kind = operand_201, .start = operand_202, .end = operand_203, .comment = operand_204, .state = operand_205, });

                break :block_212 @as(*const zx_type_31, operand_211);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    const value_1: u64 = (@as(u64, ((in).frames).len) - @as(u64, 1));
    const value_2: zx_type_22 = (block_200: {
        const operand_198 = (in).frames;
        const operand_199 = value_1;

        if ((operand_199 >= (operand_198).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_200 (operand_198)[@intCast(operand_199)];
    }).mode;
    const value_3: u64 = (block_197: {
        const operand_195 = (in).frames;
        const operand_196 = value_1;

        if ((operand_196 >= (operand_195).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_197 (operand_195)[@intCast(operand_196)];
    }).start;
    const value_4: u64 = (block_194: {
        const operand_192 = (in).frames;
        const operand_193 = value_1;

        if ((operand_193 >= (operand_192).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_194 (operand_192)[@intCast(operand_193)];
    }).braces;
    const value_5: u64 = (block_191: {
        const operand_189 = (in).frames;
        const operand_190 = value_1;

        if ((operand_190 >= (operand_189).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_191 (operand_189)[@intCast(operand_190)];
    }).depth;
    const value_6: []const *const zx_type_24 = (block_188: {
        const operand_187 = (in).frames;

        break :block_188 @as(zx_type_44, (if (((operand_187).len == 0)) .{ operand_187, null, } else .{ (operand_187)[0..((operand_187).len - 1)], (operand_187)[((operand_187).len - 1)], }));
    }).@"0";

    return block_186: {
        const operand_165 = (in).source_length;
        const operand_166 = (in).warmed;
        const operand_167 = (in).ahead_one;
        const operand_168 = (in).ahead_two;
        const operand_169 = (in).keyword_state;
        const operand_170 = (in).symbol;
        const operand_171 = (in).line_break;
        const operand_172 = (in).dollar;
        const operand_173 = (in).offset;
        const operand_174 = (in).skip_until;
        const operand_175 = value_2;
        const operand_176 = value_3;
        const operand_177 = value_4;
        const operand_178 = value_5;
        const operand_179 = value_6;
        const operand_180 = (in).number;
        const operand_181 = (in).tokens;
        const operand_182 = (in).comments;
        const operand_183 = (in).diagnostic;

        break :block_186 block_185: {
            const operand_184 = (try (allocator).create(zx_type_28));

            (operand_184).* = @as(zx_type_28, zx_type_28{ .source_length = operand_165, .warmed = operand_166, .ahead_one = operand_167, .ahead_two = operand_168, .keyword_state = operand_169, .symbol = operand_170, .line_break = operand_171, .dollar = operand_172, .offset = operand_173, .skip_until = operand_174, .mode = operand_175, .start = operand_176, .braces = operand_177, .depth = operand_178, .frames = operand_179, .number = operand_180, .tokens = operand_181, .comments = operand_182, .diagnostic = operand_183, });

            break :block_185 @as(*const zx_type_28, operand_184);
        };
    };
}

fn function_47(allocator: ((std).mem).Allocator, in: *const zx_type_28) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: *const zx_type_24 = block_33: {
        const operand_27 = (in).mode;
        const operand_28 = (in).start;
        const operand_29 = (in).braces;
        const operand_30 = (in).depth;

        break :block_33 block_32: {
            const operand_31 = (try (allocator).create(zx_type_24));

            (operand_31).* = @as(zx_type_24, zx_type_24{ .mode = operand_27, .start = operand_28, .braces = operand_29, .depth = operand_30, });

            break :block_32 @as(*const zx_type_24, operand_31);
        };
    };
    const value_2: []const *const zx_type_24 = (block_26: {
        const operand_23 = (in).frames;
        const operand_24 = value_1;
        const operand_25 = (try (allocator).alloc(*const zx_type_24, (try ((std).math).add(usize, (operand_23).len, 1))));

        @memcpy((operand_25)[0..(operand_23).len], operand_23);

        (operand_25)[(operand_23).len] = operand_24;

        break :block_26 @as(zx_type_42, .{ operand_25, {}, });
    }).@"0";

    return block_22: {
        const operand_1 = (in).source_length;
        const operand_2 = (in).warmed;
        const operand_3 = (in).ahead_one;
        const operand_4 = (in).ahead_two;
        const operand_5 = (in).keyword_state;
        const operand_6 = (in).symbol;
        const operand_7 = (in).line_break;
        const operand_8 = (in).dollar;
        const operand_9 = (in).offset;
        const operand_10 = ((in).offset + @as(u64, 2));
        const operand_11 = @as(zx_type_22, .Interpolation);
        const operand_12 = ((in).offset + @as(u64, 2));
        const operand_13 = @as(u64, 0);
        const operand_14 = ((in).depth + @as(u64, 1));
        const operand_15 = value_2;
        const operand_16 = (in).number;
        const operand_17 = (in).tokens;
        const operand_18 = (in).comments;
        const operand_19 = (in).diagnostic;

        break :block_22 block_21: {
            const operand_20 = (try (allocator).create(zx_type_28));

            (operand_20).* = @as(zx_type_28, zx_type_28{ .source_length = operand_1, .warmed = operand_2, .ahead_one = operand_3, .ahead_two = operand_4, .keyword_state = operand_5, .symbol = operand_6, .line_break = operand_7, .dollar = operand_8, .offset = operand_9, .skip_until = operand_10, .mode = operand_11, .start = operand_12, .braces = operand_13, .depth = operand_14, .frames = operand_15, .number = operand_16, .tokens = operand_17, .comments = operand_18, .diagnostic = operand_19, });

            break :block_21 @as(*const zx_type_28, operand_20);
        };
    };
}

fn function_47_value(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: *const zx_type_24 = block_66: {
        const operand_60 = (in).mode;
        const operand_61 = (in).start;
        const operand_62 = (in).braces;
        const operand_63 = (in).depth;

        break :block_66 block_65: {
            const operand_64 = (try (allocator).create(zx_type_24));

            (operand_64).* = @as(zx_type_24, zx_type_24{ .mode = operand_60, .start = operand_61, .braces = operand_62, .depth = operand_63, });

            break :block_65 @as(*const zx_type_24, operand_64);
        };
    };
    const value_2: []const *const zx_type_24 = (block_59: {
        const operand_55 = (in).frames;
        const operand_57 = block_56: {
            break :block_56 value_1;
        };
        const operand_58 = (try (allocator).alloc(*const zx_type_24, (try ((std).math).add(usize, (operand_55).len, 1))));

        @memcpy((operand_58)[0..(operand_55).len], operand_55);

        (operand_58)[(operand_55).len] = operand_57;

        break :block_59 @as(value_zx_type_42_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_58, {}, null, });
    }).@"0";

    return block_54: {
        const operand_34 = (in).source_length;
        const operand_35 = (in).warmed;
        const operand_36 = (in).ahead_one;
        const operand_37 = (in).ahead_two;
        const operand_38 = (in).keyword_state;
        const operand_39 = (in).symbol;
        const operand_40 = (in).line_break;
        const operand_41 = (in).dollar;
        const operand_42 = (in).offset;
        const operand_43 = ((in).offset + @as(u64, 2));
        const operand_44 = @as(zx_type_22, .Interpolation);
        const operand_45 = ((in).offset + @as(u64, 2));
        const operand_46 = @as(u64, 0);
        const operand_47 = ((in).depth + @as(u64, 1));
        const operand_48 = block_49: {
            break :block_49 value_2;
        };
        const operand_50 = (in).number;
        const operand_51 = (in).tokens;
        const operand_52 = (in).comments;
        const operand_53 = (in).diagnostic;

        break :block_54 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_34, .warmed = operand_35, .ahead_one = operand_36, .ahead_two = operand_37, .keyword_state = operand_38, .symbol = operand_39, .line_break = operand_40, .dollar = operand_41, .offset = operand_42, .skip_until = operand_43, .mode = operand_44, .start = operand_45, .braces = operand_46, .depth = operand_47, .frames = operand_48, .number = operand_50, .tokens = operand_51, .comments = operand_52, .diagnostic = operand_53, });
    };
}

fn function_47_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    const value_1: *const zx_type_24 = block_103: {
        const operand_97 = (in).mode;
        const operand_98 = (in).start;
        const operand_99 = (in).braces;
        const operand_100 = (in).depth;

        break :block_103 block_102: {
            const operand_101 = (try (allocator).create(zx_type_24));

            (operand_101).* = @as(zx_type_24, zx_type_24{ .mode = operand_97, .start = operand_98, .braces = operand_99, .depth = operand_100, });

            break :block_102 @as(*const zx_type_24, operand_101);
        };
    };
    const value_2: []const *const zx_type_24 = @as([]const *const zx_type_24, (if (((buffers).lane_1 != null)) block_91: {
        const operand_88 = (in).frames;
        const operand_90 = block_89: {
            break :block_89 value_1;
        };

        _ = (try ((std).math).add(usize, (operand_88).len, 1));

        if ((!(((buffers).lane_1.?).started).*)) {
            (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_88));

            (((buffers).lane_1.?).started).* = true;
        } else {
            (((((buffers).lane_1.?).buffer).*).items).len = (operand_88).len;
        }

        (try ((((buffers).lane_1.?).buffer).*).append(allocator, operand_90));

        break :block_91 ((((buffers).lane_1.?).buffer).*).items;
    } else (block_96: {
        const operand_92 = (in).frames;
        const operand_94 = block_93: {
            break :block_93 value_1;
        };
        const operand_95 = (try (allocator).alloc(*const zx_type_24, (try ((std).math).add(usize, (operand_92).len, 1))));

        @memcpy((operand_95)[0..(operand_92).len], operand_92);

        (operand_95)[(operand_92).len] = operand_94;

        break :block_96 @as(value_zx_type_42_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_95, {}, null, });
    }).@"0"));

    return block_87: {
        const operand_67 = (in).source_length;
        const operand_68 = (in).warmed;
        const operand_69 = (in).ahead_one;
        const operand_70 = (in).ahead_two;
        const operand_71 = (in).keyword_state;
        const operand_72 = (in).symbol;
        const operand_73 = (in).line_break;
        const operand_74 = (in).dollar;
        const operand_75 = (in).offset;
        const operand_76 = ((in).offset + @as(u64, 2));
        const operand_77 = @as(zx_type_22, .Interpolation);
        const operand_78 = ((in).offset + @as(u64, 2));
        const operand_79 = @as(u64, 0);
        const operand_80 = ((in).depth + @as(u64, 1));
        const operand_81 = block_82: {
            break :block_82 value_2;
        };
        const operand_83 = (in).number;
        const operand_84 = (in).tokens;
        const operand_85 = (in).comments;
        const operand_86 = (in).diagnostic;

        break :block_87 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .source_length = operand_67, .warmed = operand_68, .ahead_one = operand_69, .ahead_two = operand_70, .keyword_state = operand_71, .symbol = operand_72, .line_break = operand_73, .dollar = operand_74, .offset = operand_75, .skip_until = operand_76, .mode = operand_77, .start = operand_78, .braces = operand_79, .depth = operand_80, .frames = operand_81, .number = operand_83, .tokens = operand_84, .comments = operand_85, .diagnostic = operand_86, });
    };
}

fn function_47_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_28, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: *const zx_type_24 = block_139: {
        const operand_133 = (in).mode;
        const operand_134 = (in).start;
        const operand_135 = (in).braces;
        const operand_136 = (in).depth;

        break :block_139 block_138: {
            const operand_137 = (try (allocator).create(zx_type_24));

            (operand_137).* = @as(zx_type_24, zx_type_24{ .mode = operand_133, .start = operand_134, .braces = operand_135, .depth = operand_136, });

            break :block_138 @as(*const zx_type_24, operand_137);
        };
    };
    const value_2: []const *const zx_type_24 = @as([]const *const zx_type_24, (if (((buffers).lane_1 != null)) block_128: {
        const operand_126 = (in).frames;
        const operand_127 = value_1;

        _ = (try ((std).math).add(usize, (operand_126).len, 1));

        if ((!(((buffers).lane_1.?).started).*)) {
            (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_126));

            (((buffers).lane_1.?).started).* = true;
        } else {
            (((((buffers).lane_1.?).buffer).*).items).len = (operand_126).len;
        }

        (try ((((buffers).lane_1.?).buffer).*).append(allocator, operand_127));

        break :block_128 ((((buffers).lane_1.?).buffer).*).items;
    } else (block_132: {
        const operand_129 = (in).frames;
        const operand_130 = value_1;
        const operand_131 = (try (allocator).alloc(*const zx_type_24, (try ((std).math).add(usize, (operand_129).len, 1))));

        @memcpy((operand_131)[0..(operand_129).len], operand_129);

        (operand_131)[(operand_129).len] = operand_130;

        break :block_132 @as(zx_type_42, .{ operand_131, {}, });
    }).@"0"));

    return block_125: {
        const operand_104 = (in).source_length;
        const operand_105 = (in).warmed;
        const operand_106 = (in).ahead_one;
        const operand_107 = (in).ahead_two;
        const operand_108 = (in).keyword_state;
        const operand_109 = (in).symbol;
        const operand_110 = (in).line_break;
        const operand_111 = (in).dollar;
        const operand_112 = (in).offset;
        const operand_113 = ((in).offset + @as(u64, 2));
        const operand_114 = @as(zx_type_22, .Interpolation);
        const operand_115 = ((in).offset + @as(u64, 2));
        const operand_116 = @as(u64, 0);
        const operand_117 = ((in).depth + @as(u64, 1));
        const operand_118 = value_2;
        const operand_119 = (in).number;
        const operand_120 = (in).tokens;
        const operand_121 = (in).comments;
        const operand_122 = (in).diagnostic;

        break :block_125 block_124: {
            const operand_123 = (try (allocator).create(zx_type_28));

            (operand_123).* = @as(zx_type_28, zx_type_28{ .source_length = operand_104, .warmed = operand_105, .ahead_one = operand_106, .ahead_two = operand_107, .keyword_state = operand_108, .symbol = operand_109, .line_break = operand_110, .dollar = operand_111, .offset = operand_112, .skip_until = operand_113, .mode = operand_114, .start = operand_115, .braces = operand_116, .depth = operand_117, .frames = operand_118, .number = operand_119, .tokens = operand_120, .comments = operand_121, .diagnostic = operand_122, });

            break :block_124 @as(*const zx_type_28, operand_123);
        };
    };
}

fn function_48(allocator: ((std).mem).Allocator, in: *const zx_type_29) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if ((((in).state).mode == @as(zx_type_22, .TemplateEscape))) {
        if (((((((((in).byte != @as(u8, 34)) and ((in).byte != @as(u8, 92))) and ((in).byte != @as(u8, 110))) and ((in).byte != @as(u8, 114))) and ((in).byte != @as(u8, 116))) and ((in).byte != @as(u8, 96))) and ((in).byte != @as(u8, 36)))) {
            return block_100: {
                const operand_92 = block_91: {
                    const operand_84 = @as([]const u8, "lexical");
                    const operand_85 = (((in).state).offset - @as(u64, 1));
                    const operand_86 = (((in).state).offset + @as(u64, 1));
                    const operand_87 = @as([]const u8, "unsupported template escape");
                    const operand_88 = (in).state;

                    break :block_91 block_90: {
                        const operand_89 = (try (allocator).create(zx_type_32));

                        (operand_89).* = @as(zx_type_32, zx_type_32{ .code = operand_84, .start = operand_85, .end = operand_86, .message = operand_87, .state = operand_88, });

                        break :block_90 @as(*const zx_type_32, operand_89);
                    };
                };
                const operand_93 = (try function_6_value(allocator, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = (operand_92).code, .end = (operand_92).end, .message = (operand_92).message, .start = (operand_92).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_92).state).ahead_one, .ahead_two = ((operand_92).state).ahead_two, .braces = ((operand_92).state).braces, .comments = ((operand_92).state).comments, .depth = ((operand_92).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_92).state).diagnostic).code, .end = (((operand_92).state).diagnostic).end, .message = (((operand_92).state).diagnostic).message, .start = (((operand_92).state).diagnostic).start, .zx_origin = ((operand_92).state).diagnostic, }, .dollar = ((operand_92).state).dollar, .frames = ((operand_92).state).frames, .keyword_state = ((operand_92).state).keyword_state, .line_break = ((operand_92).state).line_break, .mode = ((operand_92).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_92).state).number).end, .last_byte = (((operand_92).state).number).last_byte, .phase = (((operand_92).state).number).phase, .separators_valid = (((operand_92).state).number).separators_valid, .zx_origin = ((operand_92).state).number, }, .offset = ((operand_92).state).offset, .skip_until = ((operand_92).state).skip_until, .source_length = ((operand_92).state).source_length, .start = ((operand_92).state).start, .symbol = ((operand_92).state).symbol, .tokens = ((operand_92).state).tokens, .warmed = ((operand_92).state).warmed, .zx_origin = (operand_92).state, }, .zx_origin = operand_92, }));

                break :block_100 (if (((operand_93).zx_origin != null)) (operand_93).zx_origin.? else block_99: {
                    const operand_98 = (try (allocator).create(zx_type_28));

                    (operand_98).* = zx_type_28{ .ahead_one = (operand_93).ahead_one, .ahead_two = (operand_93).ahead_two, .braces = (operand_93).braces, .comments = (operand_93).comments, .depth = (operand_93).depth, .diagnostic = (if ((((operand_93).diagnostic).zx_origin != null)) ((operand_93).diagnostic).zx_origin.? else block_95: {
                        const operand_94 = (try (allocator).create(zx_type_23));

                        (operand_94).* = zx_type_23{ .code = ((operand_93).diagnostic).code, .end = ((operand_93).diagnostic).end, .message = ((operand_93).diagnostic).message, .start = ((operand_93).diagnostic).start, };

                        break :block_95 @as(*const zx_type_23, operand_94);
                    }), .dollar = (operand_93).dollar, .frames = (operand_93).frames, .keyword_state = (operand_93).keyword_state, .line_break = (operand_93).line_break, .mode = (operand_93).mode, .number = (if ((((operand_93).number).zx_origin != null)) ((operand_93).number).zx_origin.? else block_97: {
                        const operand_96 = (try (allocator).create(zx_type_20));

                        (operand_96).* = zx_type_20{ .end = ((operand_93).number).end, .last_byte = ((operand_93).number).last_byte, .phase = ((operand_93).number).phase, .separators_valid = ((operand_93).number).separators_valid, };

                        break :block_97 @as(*const zx_type_20, operand_96);
                    }), .offset = (operand_93).offset, .skip_until = (operand_93).skip_until, .source_length = (operand_93).source_length, .start = (operand_93).start, .symbol = (operand_93).symbol, .tokens = (operand_93).tokens, .warmed = (operand_93).warmed, };

                    break :block_99 @as(*const zx_type_28, operand_98);
                });
            };
        }

        return block_83: {
            const operand_79 = (in).state;
            const operand_80 = @as(zx_type_22, .Template);

            break :block_83 block_82: {
                const operand_81 = (try (allocator).create(zx_type_28));

                (operand_81).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_79).ahead_one, .ahead_two = (operand_79).ahead_two, .braces = (operand_79).braces, .comments = (operand_79).comments, .depth = (operand_79).depth, .diagnostic = (operand_79).diagnostic, .dollar = (operand_79).dollar, .frames = (operand_79).frames, .keyword_state = (operand_79).keyword_state, .line_break = (operand_79).line_break, .mode = operand_80, .number = (operand_79).number, .offset = (operand_79).offset, .skip_until = (operand_79).skip_until, .source_length = (operand_79).source_length, .start = (operand_79).start, .symbol = (operand_79).symbol, .tokens = (operand_79).tokens, .warmed = (operand_79).warmed, });

                break :block_82 @as(*const zx_type_28, operand_81);
            };
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .Template))) {
        if (((in).byte == @as(u8, 96))) {
            return block_78: {
                const operand_70 = (in).state;
                const operand_71 = (try function_46_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_70).ahead_one, .ahead_two = (operand_70).ahead_two, .braces = (operand_70).braces, .comments = (operand_70).comments, .depth = (operand_70).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_70).diagnostic).code, .end = ((operand_70).diagnostic).end, .message = ((operand_70).diagnostic).message, .start = ((operand_70).diagnostic).start, .zx_origin = (operand_70).diagnostic, }, .dollar = (operand_70).dollar, .frames = (operand_70).frames, .keyword_state = (operand_70).keyword_state, .line_break = (operand_70).line_break, .mode = (operand_70).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_70).number).end, .last_byte = ((operand_70).number).last_byte, .phase = ((operand_70).number).phase, .separators_valid = ((operand_70).number).separators_valid, .zx_origin = (operand_70).number, }, .offset = (operand_70).offset, .skip_until = (operand_70).skip_until, .source_length = (operand_70).source_length, .start = (operand_70).start, .symbol = (operand_70).symbol, .tokens = (operand_70).tokens, .warmed = (operand_70).warmed, .zx_origin = operand_70, }));

                break :block_78 (if (((operand_71).zx_origin != null)) (operand_71).zx_origin.? else block_77: {
                    const operand_76 = (try (allocator).create(zx_type_28));

                    (operand_76).* = zx_type_28{ .ahead_one = (operand_71).ahead_one, .ahead_two = (operand_71).ahead_two, .braces = (operand_71).braces, .comments = (operand_71).comments, .depth = (operand_71).depth, .diagnostic = (if ((((operand_71).diagnostic).zx_origin != null)) ((operand_71).diagnostic).zx_origin.? else block_73: {
                        const operand_72 = (try (allocator).create(zx_type_23));

                        (operand_72).* = zx_type_23{ .code = ((operand_71).diagnostic).code, .end = ((operand_71).diagnostic).end, .message = ((operand_71).diagnostic).message, .start = ((operand_71).diagnostic).start, };

                        break :block_73 @as(*const zx_type_23, operand_72);
                    }), .dollar = (operand_71).dollar, .frames = (operand_71).frames, .keyword_state = (operand_71).keyword_state, .line_break = (operand_71).line_break, .mode = (operand_71).mode, .number = (if ((((operand_71).number).zx_origin != null)) ((operand_71).number).zx_origin.? else block_75: {
                        const operand_74 = (try (allocator).create(zx_type_20));

                        (operand_74).* = zx_type_20{ .end = ((operand_71).number).end, .last_byte = ((operand_71).number).last_byte, .phase = ((operand_71).number).phase, .separators_valid = ((operand_71).number).separators_valid, };

                        break :block_75 @as(*const zx_type_20, operand_74);
                    }), .offset = (operand_71).offset, .skip_until = (operand_71).skip_until, .source_length = (operand_71).source_length, .start = (operand_71).start, .symbol = (operand_71).symbol, .tokens = (operand_71).tokens, .warmed = (operand_71).warmed, };

                    break :block_77 @as(*const zx_type_28, operand_76);
                });
            };
        }

        if (((in).byte == @as(u8, 92))) {
            return block_69: {
                const operand_65 = (in).state;
                const operand_66 = @as(zx_type_22, .TemplateEscape);

                break :block_69 block_68: {
                    const operand_67 = (try (allocator).create(zx_type_28));

                    (operand_67).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_65).ahead_one, .ahead_two = (operand_65).ahead_two, .braces = (operand_65).braces, .comments = (operand_65).comments, .depth = (operand_65).depth, .diagnostic = (operand_65).diagnostic, .dollar = (operand_65).dollar, .frames = (operand_65).frames, .keyword_state = (operand_65).keyword_state, .line_break = (operand_65).line_break, .mode = operand_66, .number = (operand_65).number, .offset = (operand_65).offset, .skip_until = (operand_65).skip_until, .source_length = (operand_65).source_length, .start = (operand_65).start, .symbol = (operand_65).symbol, .tokens = (operand_65).tokens, .warmed = (operand_65).warmed, });

                    break :block_68 @as(*const zx_type_28, operand_67);
                };
            };
        }

        if (((((in).byte == @as(u8, 36)) and (in).has_next) and ((in).next == @as(u8, 123)))) {
            return block_64: {
                const operand_56 = (in).state;
                const operand_57 = (try function_47_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_56).ahead_one, .ahead_two = (operand_56).ahead_two, .braces = (operand_56).braces, .comments = (operand_56).comments, .depth = (operand_56).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_56).diagnostic).code, .end = ((operand_56).diagnostic).end, .message = ((operand_56).diagnostic).message, .start = ((operand_56).diagnostic).start, .zx_origin = (operand_56).diagnostic, }, .dollar = (operand_56).dollar, .frames = (operand_56).frames, .keyword_state = (operand_56).keyword_state, .line_break = (operand_56).line_break, .mode = (operand_56).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_56).number).end, .last_byte = ((operand_56).number).last_byte, .phase = ((operand_56).number).phase, .separators_valid = ((operand_56).number).separators_valid, .zx_origin = (operand_56).number, }, .offset = (operand_56).offset, .skip_until = (operand_56).skip_until, .source_length = (operand_56).source_length, .start = (operand_56).start, .symbol = (operand_56).symbol, .tokens = (operand_56).tokens, .warmed = (operand_56).warmed, .zx_origin = operand_56, }));

                break :block_64 (if (((operand_57).zx_origin != null)) (operand_57).zx_origin.? else block_63: {
                    const operand_62 = (try (allocator).create(zx_type_28));

                    (operand_62).* = zx_type_28{ .ahead_one = (operand_57).ahead_one, .ahead_two = (operand_57).ahead_two, .braces = (operand_57).braces, .comments = (operand_57).comments, .depth = (operand_57).depth, .diagnostic = (if ((((operand_57).diagnostic).zx_origin != null)) ((operand_57).diagnostic).zx_origin.? else block_59: {
                        const operand_58 = (try (allocator).create(zx_type_23));

                        (operand_58).* = zx_type_23{ .code = ((operand_57).diagnostic).code, .end = ((operand_57).diagnostic).end, .message = ((operand_57).diagnostic).message, .start = ((operand_57).diagnostic).start, };

                        break :block_59 @as(*const zx_type_23, operand_58);
                    }), .dollar = (operand_57).dollar, .frames = (operand_57).frames, .keyword_state = (operand_57).keyword_state, .line_break = (operand_57).line_break, .mode = (operand_57).mode, .number = (if ((((operand_57).number).zx_origin != null)) ((operand_57).number).zx_origin.? else block_61: {
                        const operand_60 = (try (allocator).create(zx_type_20));

                        (operand_60).* = zx_type_20{ .end = ((operand_57).number).end, .last_byte = ((operand_57).number).last_byte, .phase = ((operand_57).number).phase, .separators_valid = ((operand_57).number).separators_valid, };

                        break :block_61 @as(*const zx_type_20, operand_60);
                    }), .offset = (operand_57).offset, .skip_until = (operand_57).skip_until, .source_length = (operand_57).source_length, .start = (operand_57).start, .symbol = (operand_57).symbol, .tokens = (operand_57).tokens, .warmed = (operand_57).warmed, };

                    break :block_63 @as(*const zx_type_28, operand_62);
                });
            };
        }

        return (in).state;
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationStringEscape))) {
        return block_55: {
            const operand_51 = (in).state;
            const operand_52 = @as(zx_type_22, .InterpolationString);

            break :block_55 block_54: {
                const operand_53 = (try (allocator).create(zx_type_28));

                (operand_53).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_51).ahead_one, .ahead_two = (operand_51).ahead_two, .braces = (operand_51).braces, .comments = (operand_51).comments, .depth = (operand_51).depth, .diagnostic = (operand_51).diagnostic, .dollar = (operand_51).dollar, .frames = (operand_51).frames, .keyword_state = (operand_51).keyword_state, .line_break = (operand_51).line_break, .mode = operand_52, .number = (operand_51).number, .offset = (operand_51).offset, .skip_until = (operand_51).skip_until, .source_length = (operand_51).source_length, .start = (operand_51).start, .symbol = (operand_51).symbol, .tokens = (operand_51).tokens, .warmed = (operand_51).warmed, });

                break :block_54 @as(*const zx_type_28, operand_53);
            };
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationString))) {
        return block_50: {
            const operand_46 = (in).state;
            const operand_47 = (if (((in).byte == @as(u8, 34))) @as(zx_type_22, .Interpolation) else (if (((in).byte == @as(u8, 92))) @as(zx_type_22, .InterpolationStringEscape) else @as(zx_type_22, .InterpolationString)));

            break :block_50 block_49: {
                const operand_48 = (try (allocator).create(zx_type_28));

                (operand_48).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_46).ahead_one, .ahead_two = (operand_46).ahead_two, .braces = (operand_46).braces, .comments = (operand_46).comments, .depth = (operand_46).depth, .diagnostic = (operand_46).diagnostic, .dollar = (operand_46).dollar, .frames = (operand_46).frames, .keyword_state = (operand_46).keyword_state, .line_break = (operand_46).line_break, .mode = operand_47, .number = (operand_46).number, .offset = (operand_46).offset, .skip_until = (operand_46).skip_until, .source_length = (operand_46).source_length, .start = (operand_46).start, .symbol = (operand_46).symbol, .tokens = (operand_46).tokens, .warmed = (operand_46).warmed, });

                break :block_49 @as(*const zx_type_28, operand_48);
            };
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationLineComment))) {
        return block_45: {
            const operand_41 = (in).state;
            const operand_42 = (if ((((in).byte == @as(u8, 10)) or ((in).byte == @as(u8, 13)))) @as(zx_type_22, .Interpolation) else @as(zx_type_22, .InterpolationLineComment));

            break :block_45 block_44: {
                const operand_43 = (try (allocator).create(zx_type_28));

                (operand_43).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_41).ahead_one, .ahead_two = (operand_41).ahead_two, .braces = (operand_41).braces, .comments = (operand_41).comments, .depth = (operand_41).depth, .diagnostic = (operand_41).diagnostic, .dollar = (operand_41).dollar, .frames = (operand_41).frames, .keyword_state = (operand_41).keyword_state, .line_break = (operand_41).line_break, .mode = operand_42, .number = (operand_41).number, .offset = (operand_41).offset, .skip_until = (operand_41).skip_until, .source_length = (operand_41).source_length, .start = (operand_41).start, .symbol = (operand_41).symbol, .tokens = (operand_41).tokens, .warmed = (operand_41).warmed, });

                break :block_44 @as(*const zx_type_28, operand_43);
            };
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationBlockComment))) {
        if (((((in).byte == @as(u8, 42)) and (in).has_next) and ((in).next == @as(u8, 47)))) {
            const value_1: u64 = (((in).state).offset + @as(u64, 2));

            return block_40: {
                const operand_35 = (in).state;
                const operand_36 = value_1;
                const operand_37 = @as(zx_type_22, .Interpolation);

                break :block_40 block_39: {
                    const operand_38 = (try (allocator).create(zx_type_28));

                    (operand_38).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_35).ahead_one, .ahead_two = (operand_35).ahead_two, .braces = (operand_35).braces, .comments = (operand_35).comments, .depth = (operand_35).depth, .diagnostic = (operand_35).diagnostic, .dollar = (operand_35).dollar, .frames = (operand_35).frames, .keyword_state = (operand_35).keyword_state, .line_break = (operand_35).line_break, .mode = operand_37, .number = (operand_35).number, .offset = (operand_35).offset, .skip_until = operand_36, .source_length = (operand_35).source_length, .start = (operand_35).start, .symbol = (operand_35).symbol, .tokens = (operand_35).tokens, .warmed = (operand_35).warmed, });

                    break :block_39 @as(*const zx_type_28, operand_38);
                };
            };
        }

        return (in).state;
    }

    if ((((in).byte == @as(u8, 125)) and (((in).state).braces == @as(u64, 0)))) {
        return block_34: {
            const operand_26 = (in).state;
            const operand_27 = (try function_46_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_26).ahead_one, .ahead_two = (operand_26).ahead_two, .braces = (operand_26).braces, .comments = (operand_26).comments, .depth = (operand_26).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_26).diagnostic).code, .end = ((operand_26).diagnostic).end, .message = ((operand_26).diagnostic).message, .start = ((operand_26).diagnostic).start, .zx_origin = (operand_26).diagnostic, }, .dollar = (operand_26).dollar, .frames = (operand_26).frames, .keyword_state = (operand_26).keyword_state, .line_break = (operand_26).line_break, .mode = (operand_26).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_26).number).end, .last_byte = ((operand_26).number).last_byte, .phase = ((operand_26).number).phase, .separators_valid = ((operand_26).number).separators_valid, .zx_origin = (operand_26).number, }, .offset = (operand_26).offset, .skip_until = (operand_26).skip_until, .source_length = (operand_26).source_length, .start = (operand_26).start, .symbol = (operand_26).symbol, .tokens = (operand_26).tokens, .warmed = (operand_26).warmed, .zx_origin = operand_26, }));

            break :block_34 (if (((operand_27).zx_origin != null)) (operand_27).zx_origin.? else block_33: {
                const operand_32 = (try (allocator).create(zx_type_28));

                (operand_32).* = zx_type_28{ .ahead_one = (operand_27).ahead_one, .ahead_two = (operand_27).ahead_two, .braces = (operand_27).braces, .comments = (operand_27).comments, .depth = (operand_27).depth, .diagnostic = (if ((((operand_27).diagnostic).zx_origin != null)) ((operand_27).diagnostic).zx_origin.? else block_29: {
                    const operand_28 = (try (allocator).create(zx_type_23));

                    (operand_28).* = zx_type_23{ .code = ((operand_27).diagnostic).code, .end = ((operand_27).diagnostic).end, .message = ((operand_27).diagnostic).message, .start = ((operand_27).diagnostic).start, };

                    break :block_29 @as(*const zx_type_23, operand_28);
                }), .dollar = (operand_27).dollar, .frames = (operand_27).frames, .keyword_state = (operand_27).keyword_state, .line_break = (operand_27).line_break, .mode = (operand_27).mode, .number = (if ((((operand_27).number).zx_origin != null)) ((operand_27).number).zx_origin.? else block_31: {
                    const operand_30 = (try (allocator).create(zx_type_20));

                    (operand_30).* = zx_type_20{ .end = ((operand_27).number).end, .last_byte = ((operand_27).number).last_byte, .phase = ((operand_27).number).phase, .separators_valid = ((operand_27).number).separators_valid, };

                    break :block_31 @as(*const zx_type_20, operand_30);
                }), .offset = (operand_27).offset, .skip_until = (operand_27).skip_until, .source_length = (operand_27).source_length, .start = (operand_27).start, .symbol = (operand_27).symbol, .tokens = (operand_27).tokens, .warmed = (operand_27).warmed, };

                break :block_33 @as(*const zx_type_28, operand_32);
            });
        };
    }

    if ((((in).byte == @as(u8, 123)) or ((in).byte == @as(u8, 125)))) {
        const value_2: u64 = (if (((in).byte == @as(u8, 123))) (((in).state).braces + @as(u64, 1)) else (((in).state).braces - @as(u64, 1)));

        return block_25: {
            const operand_21 = (in).state;
            const operand_22 = value_2;

            break :block_25 block_24: {
                const operand_23 = (try (allocator).create(zx_type_28));

                (operand_23).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_21).ahead_one, .ahead_two = (operand_21).ahead_two, .braces = operand_22, .comments = (operand_21).comments, .depth = (operand_21).depth, .diagnostic = (operand_21).diagnostic, .dollar = (operand_21).dollar, .frames = (operand_21).frames, .keyword_state = (operand_21).keyword_state, .line_break = (operand_21).line_break, .mode = (operand_21).mode, .number = (operand_21).number, .offset = (operand_21).offset, .skip_until = (operand_21).skip_until, .source_length = (operand_21).source_length, .start = (operand_21).start, .symbol = (operand_21).symbol, .tokens = (operand_21).tokens, .warmed = (operand_21).warmed, });

                break :block_24 @as(*const zx_type_28, operand_23);
            };
        };
    }

    if (((in).byte == @as(u8, 96))) {
        return block_20: {
            const operand_12 = (in).state;
            const operand_13 = (try function_36_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_12).ahead_one, .ahead_two = (operand_12).ahead_two, .braces = (operand_12).braces, .comments = (operand_12).comments, .depth = (operand_12).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_12).diagnostic).code, .end = ((operand_12).diagnostic).end, .message = ((operand_12).diagnostic).message, .start = ((operand_12).diagnostic).start, .zx_origin = (operand_12).diagnostic, }, .dollar = (operand_12).dollar, .frames = (operand_12).frames, .keyword_state = (operand_12).keyword_state, .line_break = (operand_12).line_break, .mode = (operand_12).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_12).number).end, .last_byte = ((operand_12).number).last_byte, .phase = ((operand_12).number).phase, .separators_valid = ((operand_12).number).separators_valid, .zx_origin = (operand_12).number, }, .offset = (operand_12).offset, .skip_until = (operand_12).skip_until, .source_length = (operand_12).source_length, .start = (operand_12).start, .symbol = (operand_12).symbol, .tokens = (operand_12).tokens, .warmed = (operand_12).warmed, .zx_origin = operand_12, }));

            break :block_20 (if (((operand_13).zx_origin != null)) (operand_13).zx_origin.? else block_19: {
                const operand_18 = (try (allocator).create(zx_type_28));

                (operand_18).* = zx_type_28{ .ahead_one = (operand_13).ahead_one, .ahead_two = (operand_13).ahead_two, .braces = (operand_13).braces, .comments = (operand_13).comments, .depth = (operand_13).depth, .diagnostic = (if ((((operand_13).diagnostic).zx_origin != null)) ((operand_13).diagnostic).zx_origin.? else block_15: {
                    const operand_14 = (try (allocator).create(zx_type_23));

                    (operand_14).* = zx_type_23{ .code = ((operand_13).diagnostic).code, .end = ((operand_13).diagnostic).end, .message = ((operand_13).diagnostic).message, .start = ((operand_13).diagnostic).start, };

                    break :block_15 @as(*const zx_type_23, operand_14);
                }), .dollar = (operand_13).dollar, .frames = (operand_13).frames, .keyword_state = (operand_13).keyword_state, .line_break = (operand_13).line_break, .mode = (operand_13).mode, .number = (if ((((operand_13).number).zx_origin != null)) ((operand_13).number).zx_origin.? else block_17: {
                    const operand_16 = (try (allocator).create(zx_type_20));

                    (operand_16).* = zx_type_20{ .end = ((operand_13).number).end, .last_byte = ((operand_13).number).last_byte, .phase = ((operand_13).number).phase, .separators_valid = ((operand_13).number).separators_valid, };

                    break :block_17 @as(*const zx_type_20, operand_16);
                }), .offset = (operand_13).offset, .skip_until = (operand_13).skip_until, .source_length = (operand_13).source_length, .start = (operand_13).start, .symbol = (operand_13).symbol, .tokens = (operand_13).tokens, .warmed = (operand_13).warmed, };

                break :block_19 @as(*const zx_type_28, operand_18);
            });
        };
    }

    if (((in).byte == @as(u8, 34))) {
        return block_11: {
            const operand_7 = (in).state;
            const operand_8 = @as(zx_type_22, .InterpolationString);

            break :block_11 block_10: {
                const operand_9 = (try (allocator).create(zx_type_28));

                (operand_9).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_7).ahead_one, .ahead_two = (operand_7).ahead_two, .braces = (operand_7).braces, .comments = (operand_7).comments, .depth = (operand_7).depth, .diagnostic = (operand_7).diagnostic, .dollar = (operand_7).dollar, .frames = (operand_7).frames, .keyword_state = (operand_7).keyword_state, .line_break = (operand_7).line_break, .mode = operand_8, .number = (operand_7).number, .offset = (operand_7).offset, .skip_until = (operand_7).skip_until, .source_length = (operand_7).source_length, .start = (operand_7).start, .symbol = (operand_7).symbol, .tokens = (operand_7).tokens, .warmed = (operand_7).warmed, });

                break :block_10 @as(*const zx_type_28, operand_9);
            };
        };
    }

    if ((((in).byte == @as(u8, 47)) and (in).has_next)) {
        const value_3: u8 = (in).next;

        if (((value_3 == @as(u8, 47)) or (value_3 == @as(u8, 42)))) {
            const value_4: u64 = (((in).state).offset + @as(u64, 2));

            return block_6: {
                const operand_1 = (in).state;
                const operand_2 = value_4;
                const operand_3 = (if ((value_3 == @as(u8, 47))) @as(zx_type_22, .InterpolationLineComment) else @as(zx_type_22, .InterpolationBlockComment));

                break :block_6 block_5: {
                    const operand_4 = (try (allocator).create(zx_type_28));

                    (operand_4).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_1).ahead_one, .ahead_two = (operand_1).ahead_two, .braces = (operand_1).braces, .comments = (operand_1).comments, .depth = (operand_1).depth, .diagnostic = (operand_1).diagnostic, .dollar = (operand_1).dollar, .frames = (operand_1).frames, .keyword_state = (operand_1).keyword_state, .line_break = (operand_1).line_break, .mode = operand_3, .number = (operand_1).number, .offset = (operand_1).offset, .skip_until = operand_2, .source_length = (operand_1).source_length, .start = (operand_1).start, .symbol = (operand_1).symbol, .tokens = (operand_1).tokens, .warmed = (operand_1).warmed, });

                    break :block_5 @as(*const zx_type_28, operand_4);
                };
            };
        }
    }

    return (in).state;
}

fn function_48_value(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if ((((in).state).mode == @as(zx_type_22, .TemplateEscape))) {
        if (((((((((in).byte != @as(u8, 34)) and ((in).byte != @as(u8, 92))) and ((in).byte != @as(u8, 110))) and ((in).byte != @as(u8, 114))) and ((in).byte != @as(u8, 116))) and ((in).byte != @as(u8, 96))) and ((in).byte != @as(u8, 36)))) {
            return block_146: {
                break :block_146 (try function_6_value(allocator, block_145: {
                    const operand_140 = @as([]const u8, "lexical");
                    const operand_141 = (((in).state).offset - @as(u64, 1));
                    const operand_142 = (((in).state).offset + @as(u64, 1));
                    const operand_143 = @as([]const u8, "unsupported template escape");
                    const operand_144 = (in).state;

                    break :block_145 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_140, .start = operand_141, .end = operand_142, .message = operand_143, .state = operand_144, });
                }));
            };
        }

        return block_139: {
            const operand_137 = (in).state;
            const operand_138 = @as(zx_type_22, .Template);

            break :block_139 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_137).ahead_one, .ahead_two = (operand_137).ahead_two, .braces = (operand_137).braces, .comments = (operand_137).comments, .depth = (operand_137).depth, .diagnostic = (operand_137).diagnostic, .dollar = (operand_137).dollar, .frames = (operand_137).frames, .keyword_state = (operand_137).keyword_state, .line_break = (operand_137).line_break, .mode = operand_138, .number = (operand_137).number, .offset = (operand_137).offset, .skip_until = (operand_137).skip_until, .source_length = (operand_137).source_length, .start = (operand_137).start, .symbol = (operand_137).symbol, .tokens = (operand_137).tokens, .warmed = (operand_137).warmed, });
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .Template))) {
        if (((in).byte == @as(u8, 96))) {
            return block_136: {
                break :block_136 (try function_46_value(allocator, (in).state));
            };
        }

        if (((in).byte == @as(u8, 92))) {
            return block_135: {
                const operand_133 = (in).state;
                const operand_134 = @as(zx_type_22, .TemplateEscape);

                break :block_135 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_133).ahead_one, .ahead_two = (operand_133).ahead_two, .braces = (operand_133).braces, .comments = (operand_133).comments, .depth = (operand_133).depth, .diagnostic = (operand_133).diagnostic, .dollar = (operand_133).dollar, .frames = (operand_133).frames, .keyword_state = (operand_133).keyword_state, .line_break = (operand_133).line_break, .mode = operand_134, .number = (operand_133).number, .offset = (operand_133).offset, .skip_until = (operand_133).skip_until, .source_length = (operand_133).source_length, .start = (operand_133).start, .symbol = (operand_133).symbol, .tokens = (operand_133).tokens, .warmed = (operand_133).warmed, });
            };
        }

        if (((((in).byte == @as(u8, 36)) and (in).has_next) and ((in).next == @as(u8, 123)))) {
            return block_132: {
                break :block_132 (try function_47_value(allocator, (in).state));
            };
        }

        return (in).state;
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationStringEscape))) {
        return block_131: {
            const operand_129 = (in).state;
            const operand_130 = @as(zx_type_22, .InterpolationString);

            break :block_131 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_129).ahead_one, .ahead_two = (operand_129).ahead_two, .braces = (operand_129).braces, .comments = (operand_129).comments, .depth = (operand_129).depth, .diagnostic = (operand_129).diagnostic, .dollar = (operand_129).dollar, .frames = (operand_129).frames, .keyword_state = (operand_129).keyword_state, .line_break = (operand_129).line_break, .mode = operand_130, .number = (operand_129).number, .offset = (operand_129).offset, .skip_until = (operand_129).skip_until, .source_length = (operand_129).source_length, .start = (operand_129).start, .symbol = (operand_129).symbol, .tokens = (operand_129).tokens, .warmed = (operand_129).warmed, });
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationString))) {
        return block_128: {
            const operand_126 = (in).state;
            const operand_127 = (if (((in).byte == @as(u8, 34))) @as(zx_type_22, .Interpolation) else (if (((in).byte == @as(u8, 92))) @as(zx_type_22, .InterpolationStringEscape) else @as(zx_type_22, .InterpolationString)));

            break :block_128 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_126).ahead_one, .ahead_two = (operand_126).ahead_two, .braces = (operand_126).braces, .comments = (operand_126).comments, .depth = (operand_126).depth, .diagnostic = (operand_126).diagnostic, .dollar = (operand_126).dollar, .frames = (operand_126).frames, .keyword_state = (operand_126).keyword_state, .line_break = (operand_126).line_break, .mode = operand_127, .number = (operand_126).number, .offset = (operand_126).offset, .skip_until = (operand_126).skip_until, .source_length = (operand_126).source_length, .start = (operand_126).start, .symbol = (operand_126).symbol, .tokens = (operand_126).tokens, .warmed = (operand_126).warmed, });
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationLineComment))) {
        return block_125: {
            const operand_123 = (in).state;
            const operand_124 = (if ((((in).byte == @as(u8, 10)) or ((in).byte == @as(u8, 13)))) @as(zx_type_22, .Interpolation) else @as(zx_type_22, .InterpolationLineComment));

            break :block_125 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_123).ahead_one, .ahead_two = (operand_123).ahead_two, .braces = (operand_123).braces, .comments = (operand_123).comments, .depth = (operand_123).depth, .diagnostic = (operand_123).diagnostic, .dollar = (operand_123).dollar, .frames = (operand_123).frames, .keyword_state = (operand_123).keyword_state, .line_break = (operand_123).line_break, .mode = operand_124, .number = (operand_123).number, .offset = (operand_123).offset, .skip_until = (operand_123).skip_until, .source_length = (operand_123).source_length, .start = (operand_123).start, .symbol = (operand_123).symbol, .tokens = (operand_123).tokens, .warmed = (operand_123).warmed, });
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationBlockComment))) {
        if (((((in).byte == @as(u8, 42)) and (in).has_next) and ((in).next == @as(u8, 47)))) {
            const value_1: u64 = (((in).state).offset + @as(u64, 2));

            return block_122: {
                const operand_118 = (in).state;
                const operand_119 = block_120: {
                    break :block_120 value_1;
                };
                const operand_121 = @as(zx_type_22, .Interpolation);

                break :block_122 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_118).ahead_one, .ahead_two = (operand_118).ahead_two, .braces = (operand_118).braces, .comments = (operand_118).comments, .depth = (operand_118).depth, .diagnostic = (operand_118).diagnostic, .dollar = (operand_118).dollar, .frames = (operand_118).frames, .keyword_state = (operand_118).keyword_state, .line_break = (operand_118).line_break, .mode = operand_121, .number = (operand_118).number, .offset = (operand_118).offset, .skip_until = operand_119, .source_length = (operand_118).source_length, .start = (operand_118).start, .symbol = (operand_118).symbol, .tokens = (operand_118).tokens, .warmed = (operand_118).warmed, });
            };
        }

        return (in).state;
    }

    if ((((in).byte == @as(u8, 125)) and (((in).state).braces == @as(u64, 0)))) {
        return block_117: {
            break :block_117 (try function_46_value(allocator, (in).state));
        };
    }

    if ((((in).byte == @as(u8, 123)) or ((in).byte == @as(u8, 125)))) {
        const value_2: u64 = (if (((in).byte == @as(u8, 123))) (((in).state).braces + @as(u64, 1)) else (((in).state).braces - @as(u64, 1)));

        return block_116: {
            const operand_113 = (in).state;
            const operand_114 = block_115: {
                break :block_115 value_2;
            };

            break :block_116 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_113).ahead_one, .ahead_two = (operand_113).ahead_two, .braces = operand_114, .comments = (operand_113).comments, .depth = (operand_113).depth, .diagnostic = (operand_113).diagnostic, .dollar = (operand_113).dollar, .frames = (operand_113).frames, .keyword_state = (operand_113).keyword_state, .line_break = (operand_113).line_break, .mode = (operand_113).mode, .number = (operand_113).number, .offset = (operand_113).offset, .skip_until = (operand_113).skip_until, .source_length = (operand_113).source_length, .start = (operand_113).start, .symbol = (operand_113).symbol, .tokens = (operand_113).tokens, .warmed = (operand_113).warmed, });
        };
    }

    if (((in).byte == @as(u8, 96))) {
        return block_112: {
            break :block_112 (try function_36_value(allocator, (in).state));
        };
    }

    if (((in).byte == @as(u8, 34))) {
        return block_111: {
            const operand_109 = (in).state;
            const operand_110 = @as(zx_type_22, .InterpolationString);

            break :block_111 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_109).ahead_one, .ahead_two = (operand_109).ahead_two, .braces = (operand_109).braces, .comments = (operand_109).comments, .depth = (operand_109).depth, .diagnostic = (operand_109).diagnostic, .dollar = (operand_109).dollar, .frames = (operand_109).frames, .keyword_state = (operand_109).keyword_state, .line_break = (operand_109).line_break, .mode = operand_110, .number = (operand_109).number, .offset = (operand_109).offset, .skip_until = (operand_109).skip_until, .source_length = (operand_109).source_length, .start = (operand_109).start, .symbol = (operand_109).symbol, .tokens = (operand_109).tokens, .warmed = (operand_109).warmed, });
        };
    }

    if ((((in).byte == @as(u8, 47)) and (in).has_next)) {
        const value_3: u8 = (in).next;

        if (((block_101: {
            break :block_101 value_3;
        } == @as(u8, 47)) or (block_102: {
            break :block_102 value_3;
        } == @as(u8, 42)))) {
            const value_4: u64 = (((in).state).offset + @as(u64, 2));

            return block_108: {
                const operand_103 = (in).state;
                const operand_104 = block_105: {
                    break :block_105 value_4;
                };
                const operand_106 = (if ((block_107: {
                    break :block_107 value_3;
                } == @as(u8, 47))) @as(zx_type_22, .InterpolationLineComment) else @as(zx_type_22, .InterpolationBlockComment));

                break :block_108 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_103).ahead_one, .ahead_two = (operand_103).ahead_two, .braces = (operand_103).braces, .comments = (operand_103).comments, .depth = (operand_103).depth, .diagnostic = (operand_103).diagnostic, .dollar = (operand_103).dollar, .frames = (operand_103).frames, .keyword_state = (operand_103).keyword_state, .line_break = (operand_103).line_break, .mode = operand_106, .number = (operand_103).number, .offset = (operand_103).offset, .skip_until = operand_104, .source_length = (operand_103).source_length, .start = (operand_103).start, .symbol = (operand_103).symbol, .tokens = (operand_103).tokens, .warmed = (operand_103).warmed, });
            };
        }
    }

    return (in).state;
}

fn function_48_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if ((((in).state).mode == @as(zx_type_22, .TemplateEscape))) {
        if (((((((((in).byte != @as(u8, 34)) and ((in).byte != @as(u8, 92))) and ((in).byte != @as(u8, 110))) and ((in).byte != @as(u8, 114))) and ((in).byte != @as(u8, 116))) and ((in).byte != @as(u8, 96))) and ((in).byte != @as(u8, 36)))) {
            return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_192: {
                break :block_192 (try function_6_buffered(allocator, block_191: {
                    const operand_186 = @as([]const u8, "lexical");
                    const operand_187 = (((in).state).offset - @as(u64, 1));
                    const operand_188 = (((in).state).offset + @as(u64, 1));
                    const operand_189 = @as([]const u8, "unsupported template escape");
                    const operand_190 = (in).state;

                    break :block_191 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_186, .start = operand_187, .end = operand_188, .message = operand_189, .state = operand_190, });
                }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
            });
        }

        return block_185: {
            const operand_183 = (in).state;
            const operand_184 = @as(zx_type_22, .Template);

            break :block_185 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_183).ahead_one, .ahead_two = (operand_183).ahead_two, .braces = (operand_183).braces, .comments = (operand_183).comments, .depth = (operand_183).depth, .diagnostic = (operand_183).diagnostic, .dollar = (operand_183).dollar, .frames = (operand_183).frames, .keyword_state = (operand_183).keyword_state, .line_break = (operand_183).line_break, .mode = operand_184, .number = (operand_183).number, .offset = (operand_183).offset, .skip_until = (operand_183).skip_until, .source_length = (operand_183).source_length, .start = (operand_183).start, .symbol = (operand_183).symbol, .tokens = (operand_183).tokens, .warmed = (operand_183).warmed, });
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .Template))) {
        if (((in).byte == @as(u8, 96))) {
            return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_182: {
                break :block_182 (try function_46_buffered(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
            });
        }

        if (((in).byte == @as(u8, 92))) {
            return block_181: {
                const operand_179 = (in).state;
                const operand_180 = @as(zx_type_22, .TemplateEscape);

                break :block_181 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_179).ahead_one, .ahead_two = (operand_179).ahead_two, .braces = (operand_179).braces, .comments = (operand_179).comments, .depth = (operand_179).depth, .diagnostic = (operand_179).diagnostic, .dollar = (operand_179).dollar, .frames = (operand_179).frames, .keyword_state = (operand_179).keyword_state, .line_break = (operand_179).line_break, .mode = operand_180, .number = (operand_179).number, .offset = (operand_179).offset, .skip_until = (operand_179).skip_until, .source_length = (operand_179).source_length, .start = (operand_179).start, .symbol = (operand_179).symbol, .tokens = (operand_179).tokens, .warmed = (operand_179).warmed, });
            };
        }

        if (((((in).byte == @as(u8, 36)) and (in).has_next) and ((in).next == @as(u8, 123)))) {
            return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_178: {
                break :block_178 (try function_47_buffered(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
            });
        }

        return (in).state;
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationStringEscape))) {
        return block_177: {
            const operand_175 = (in).state;
            const operand_176 = @as(zx_type_22, .InterpolationString);

            break :block_177 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_175).ahead_one, .ahead_two = (operand_175).ahead_two, .braces = (operand_175).braces, .comments = (operand_175).comments, .depth = (operand_175).depth, .diagnostic = (operand_175).diagnostic, .dollar = (operand_175).dollar, .frames = (operand_175).frames, .keyword_state = (operand_175).keyword_state, .line_break = (operand_175).line_break, .mode = operand_176, .number = (operand_175).number, .offset = (operand_175).offset, .skip_until = (operand_175).skip_until, .source_length = (operand_175).source_length, .start = (operand_175).start, .symbol = (operand_175).symbol, .tokens = (operand_175).tokens, .warmed = (operand_175).warmed, });
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationString))) {
        return block_174: {
            const operand_172 = (in).state;
            const operand_173 = (if (((in).byte == @as(u8, 34))) @as(zx_type_22, .Interpolation) else (if (((in).byte == @as(u8, 92))) @as(zx_type_22, .InterpolationStringEscape) else @as(zx_type_22, .InterpolationString)));

            break :block_174 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_172).ahead_one, .ahead_two = (operand_172).ahead_two, .braces = (operand_172).braces, .comments = (operand_172).comments, .depth = (operand_172).depth, .diagnostic = (operand_172).diagnostic, .dollar = (operand_172).dollar, .frames = (operand_172).frames, .keyword_state = (operand_172).keyword_state, .line_break = (operand_172).line_break, .mode = operand_173, .number = (operand_172).number, .offset = (operand_172).offset, .skip_until = (operand_172).skip_until, .source_length = (operand_172).source_length, .start = (operand_172).start, .symbol = (operand_172).symbol, .tokens = (operand_172).tokens, .warmed = (operand_172).warmed, });
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationLineComment))) {
        return block_171: {
            const operand_169 = (in).state;
            const operand_170 = (if ((((in).byte == @as(u8, 10)) or ((in).byte == @as(u8, 13)))) @as(zx_type_22, .Interpolation) else @as(zx_type_22, .InterpolationLineComment));

            break :block_171 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_169).ahead_one, .ahead_two = (operand_169).ahead_two, .braces = (operand_169).braces, .comments = (operand_169).comments, .depth = (operand_169).depth, .diagnostic = (operand_169).diagnostic, .dollar = (operand_169).dollar, .frames = (operand_169).frames, .keyword_state = (operand_169).keyword_state, .line_break = (operand_169).line_break, .mode = operand_170, .number = (operand_169).number, .offset = (operand_169).offset, .skip_until = (operand_169).skip_until, .source_length = (operand_169).source_length, .start = (operand_169).start, .symbol = (operand_169).symbol, .tokens = (operand_169).tokens, .warmed = (operand_169).warmed, });
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationBlockComment))) {
        if (((((in).byte == @as(u8, 42)) and (in).has_next) and ((in).next == @as(u8, 47)))) {
            const value_1: u64 = (((in).state).offset + @as(u64, 2));

            return block_168: {
                const operand_164 = (in).state;
                const operand_165 = block_166: {
                    break :block_166 value_1;
                };
                const operand_167 = @as(zx_type_22, .Interpolation);

                break :block_168 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_164).ahead_one, .ahead_two = (operand_164).ahead_two, .braces = (operand_164).braces, .comments = (operand_164).comments, .depth = (operand_164).depth, .diagnostic = (operand_164).diagnostic, .dollar = (operand_164).dollar, .frames = (operand_164).frames, .keyword_state = (operand_164).keyword_state, .line_break = (operand_164).line_break, .mode = operand_167, .number = (operand_164).number, .offset = (operand_164).offset, .skip_until = operand_165, .source_length = (operand_164).source_length, .start = (operand_164).start, .symbol = (operand_164).symbol, .tokens = (operand_164).tokens, .warmed = (operand_164).warmed, });
            };
        }

        return (in).state;
    }

    if ((((in).byte == @as(u8, 125)) and (((in).state).braces == @as(u64, 0)))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_163: {
            break :block_163 (try function_46_buffered(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if ((((in).byte == @as(u8, 123)) or ((in).byte == @as(u8, 125)))) {
        const value_2: u64 = (if (((in).byte == @as(u8, 123))) (((in).state).braces + @as(u64, 1)) else (((in).state).braces - @as(u64, 1)));

        return block_162: {
            const operand_159 = (in).state;
            const operand_160 = block_161: {
                break :block_161 value_2;
            };

            break :block_162 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_159).ahead_one, .ahead_two = (operand_159).ahead_two, .braces = operand_160, .comments = (operand_159).comments, .depth = (operand_159).depth, .diagnostic = (operand_159).diagnostic, .dollar = (operand_159).dollar, .frames = (operand_159).frames, .keyword_state = (operand_159).keyword_state, .line_break = (operand_159).line_break, .mode = (operand_159).mode, .number = (operand_159).number, .offset = (operand_159).offset, .skip_until = (operand_159).skip_until, .source_length = (operand_159).source_length, .start = (operand_159).start, .symbol = (operand_159).symbol, .tokens = (operand_159).tokens, .warmed = (operand_159).warmed, });
        };
    }

    if (((in).byte == @as(u8, 96))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_158: {
            break :block_158 (try function_36_buffered(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if (((in).byte == @as(u8, 34))) {
        return block_157: {
            const operand_155 = (in).state;
            const operand_156 = @as(zx_type_22, .InterpolationString);

            break :block_157 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_155).ahead_one, .ahead_two = (operand_155).ahead_two, .braces = (operand_155).braces, .comments = (operand_155).comments, .depth = (operand_155).depth, .diagnostic = (operand_155).diagnostic, .dollar = (operand_155).dollar, .frames = (operand_155).frames, .keyword_state = (operand_155).keyword_state, .line_break = (operand_155).line_break, .mode = operand_156, .number = (operand_155).number, .offset = (operand_155).offset, .skip_until = (operand_155).skip_until, .source_length = (operand_155).source_length, .start = (operand_155).start, .symbol = (operand_155).symbol, .tokens = (operand_155).tokens, .warmed = (operand_155).warmed, });
        };
    }

    if ((((in).byte == @as(u8, 47)) and (in).has_next)) {
        const value_3: u8 = (in).next;

        if (((block_147: {
            break :block_147 value_3;
        } == @as(u8, 47)) or (block_148: {
            break :block_148 value_3;
        } == @as(u8, 42)))) {
            const value_4: u64 = (((in).state).offset + @as(u64, 2));

            return block_154: {
                const operand_149 = (in).state;
                const operand_150 = block_151: {
                    break :block_151 value_4;
                };
                const operand_152 = (if ((block_153: {
                    break :block_153 value_3;
                } == @as(u8, 47))) @as(zx_type_22, .InterpolationLineComment) else @as(zx_type_22, .InterpolationBlockComment));

                break :block_154 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_149).ahead_one, .ahead_two = (operand_149).ahead_two, .braces = (operand_149).braces, .comments = (operand_149).comments, .depth = (operand_149).depth, .diagnostic = (operand_149).diagnostic, .dollar = (operand_149).dollar, .frames = (operand_149).frames, .keyword_state = (operand_149).keyword_state, .line_break = (operand_149).line_break, .mode = operand_152, .number = (operand_149).number, .offset = (operand_149).offset, .skip_until = operand_150, .source_length = (operand_149).source_length, .start = (operand_149).start, .symbol = (operand_149).symbol, .tokens = (operand_149).tokens, .warmed = (operand_149).warmed, });
            };
        }
    }

    return (in).state;
}

fn function_48_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_29, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if ((((in).state).mode == @as(zx_type_22, .TemplateEscape))) {
        if (((((((((in).byte != @as(u8, 34)) and ((in).byte != @as(u8, 92))) and ((in).byte != @as(u8, 110))) and ((in).byte != @as(u8, 114))) and ((in).byte != @as(u8, 116))) and ((in).byte != @as(u8, 96))) and ((in).byte != @as(u8, 36)))) {
            return (try function_6_buffered_pointer(allocator, block_247: {
                const operand_240 = @as([]const u8, "lexical");
                const operand_241 = (((in).state).offset - @as(u64, 1));
                const operand_242 = (((in).state).offset + @as(u64, 1));
                const operand_243 = @as([]const u8, "unsupported template escape");
                const operand_244 = (in).state;

                break :block_247 block_246: {
                    const operand_245 = (try (allocator).create(zx_type_32));

                    (operand_245).* = @as(zx_type_32, zx_type_32{ .code = operand_240, .start = operand_241, .end = operand_242, .message = operand_243, .state = operand_244, });

                    break :block_246 @as(*const zx_type_32, operand_245);
                };
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        }

        return block_239: {
            const operand_235 = (in).state;
            const operand_236 = @as(zx_type_22, .Template);

            break :block_239 block_238: {
                const operand_237 = (try (allocator).create(zx_type_28));

                (operand_237).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_235).ahead_one, .ahead_two = (operand_235).ahead_two, .braces = (operand_235).braces, .comments = (operand_235).comments, .depth = (operand_235).depth, .diagnostic = (operand_235).diagnostic, .dollar = (operand_235).dollar, .frames = (operand_235).frames, .keyword_state = (operand_235).keyword_state, .line_break = (operand_235).line_break, .mode = operand_236, .number = (operand_235).number, .offset = (operand_235).offset, .skip_until = (operand_235).skip_until, .source_length = (operand_235).source_length, .start = (operand_235).start, .symbol = (operand_235).symbol, .tokens = (operand_235).tokens, .warmed = (operand_235).warmed, });

                break :block_238 @as(*const zx_type_28, operand_237);
            };
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .Template))) {
        if (((in).byte == @as(u8, 96))) {
            return (try function_46_buffered_pointer(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        }

        if (((in).byte == @as(u8, 92))) {
            return block_234: {
                const operand_230 = (in).state;
                const operand_231 = @as(zx_type_22, .TemplateEscape);

                break :block_234 block_233: {
                    const operand_232 = (try (allocator).create(zx_type_28));

                    (operand_232).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_230).ahead_one, .ahead_two = (operand_230).ahead_two, .braces = (operand_230).braces, .comments = (operand_230).comments, .depth = (operand_230).depth, .diagnostic = (operand_230).diagnostic, .dollar = (operand_230).dollar, .frames = (operand_230).frames, .keyword_state = (operand_230).keyword_state, .line_break = (operand_230).line_break, .mode = operand_231, .number = (operand_230).number, .offset = (operand_230).offset, .skip_until = (operand_230).skip_until, .source_length = (operand_230).source_length, .start = (operand_230).start, .symbol = (operand_230).symbol, .tokens = (operand_230).tokens, .warmed = (operand_230).warmed, });

                    break :block_233 @as(*const zx_type_28, operand_232);
                };
            };
        }

        if (((((in).byte == @as(u8, 36)) and (in).has_next) and ((in).next == @as(u8, 123)))) {
            return (try function_47_buffered_pointer(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        }

        return (in).state;
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationStringEscape))) {
        return block_229: {
            const operand_225 = (in).state;
            const operand_226 = @as(zx_type_22, .InterpolationString);

            break :block_229 block_228: {
                const operand_227 = (try (allocator).create(zx_type_28));

                (operand_227).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_225).ahead_one, .ahead_two = (operand_225).ahead_two, .braces = (operand_225).braces, .comments = (operand_225).comments, .depth = (operand_225).depth, .diagnostic = (operand_225).diagnostic, .dollar = (operand_225).dollar, .frames = (operand_225).frames, .keyword_state = (operand_225).keyword_state, .line_break = (operand_225).line_break, .mode = operand_226, .number = (operand_225).number, .offset = (operand_225).offset, .skip_until = (operand_225).skip_until, .source_length = (operand_225).source_length, .start = (operand_225).start, .symbol = (operand_225).symbol, .tokens = (operand_225).tokens, .warmed = (operand_225).warmed, });

                break :block_228 @as(*const zx_type_28, operand_227);
            };
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationString))) {
        return block_224: {
            const operand_220 = (in).state;
            const operand_221 = (if (((in).byte == @as(u8, 34))) @as(zx_type_22, .Interpolation) else (if (((in).byte == @as(u8, 92))) @as(zx_type_22, .InterpolationStringEscape) else @as(zx_type_22, .InterpolationString)));

            break :block_224 block_223: {
                const operand_222 = (try (allocator).create(zx_type_28));

                (operand_222).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_220).ahead_one, .ahead_two = (operand_220).ahead_two, .braces = (operand_220).braces, .comments = (operand_220).comments, .depth = (operand_220).depth, .diagnostic = (operand_220).diagnostic, .dollar = (operand_220).dollar, .frames = (operand_220).frames, .keyword_state = (operand_220).keyword_state, .line_break = (operand_220).line_break, .mode = operand_221, .number = (operand_220).number, .offset = (operand_220).offset, .skip_until = (operand_220).skip_until, .source_length = (operand_220).source_length, .start = (operand_220).start, .symbol = (operand_220).symbol, .tokens = (operand_220).tokens, .warmed = (operand_220).warmed, });

                break :block_223 @as(*const zx_type_28, operand_222);
            };
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationLineComment))) {
        return block_219: {
            const operand_215 = (in).state;
            const operand_216 = (if ((((in).byte == @as(u8, 10)) or ((in).byte == @as(u8, 13)))) @as(zx_type_22, .Interpolation) else @as(zx_type_22, .InterpolationLineComment));

            break :block_219 block_218: {
                const operand_217 = (try (allocator).create(zx_type_28));

                (operand_217).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_215).ahead_one, .ahead_two = (operand_215).ahead_two, .braces = (operand_215).braces, .comments = (operand_215).comments, .depth = (operand_215).depth, .diagnostic = (operand_215).diagnostic, .dollar = (operand_215).dollar, .frames = (operand_215).frames, .keyword_state = (operand_215).keyword_state, .line_break = (operand_215).line_break, .mode = operand_216, .number = (operand_215).number, .offset = (operand_215).offset, .skip_until = (operand_215).skip_until, .source_length = (operand_215).source_length, .start = (operand_215).start, .symbol = (operand_215).symbol, .tokens = (operand_215).tokens, .warmed = (operand_215).warmed, });

                break :block_218 @as(*const zx_type_28, operand_217);
            };
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .InterpolationBlockComment))) {
        if (((((in).byte == @as(u8, 42)) and (in).has_next) and ((in).next == @as(u8, 47)))) {
            const value_1: u64 = (((in).state).offset + @as(u64, 2));

            return block_214: {
                const operand_209 = (in).state;
                const operand_210 = value_1;
                const operand_211 = @as(zx_type_22, .Interpolation);

                break :block_214 block_213: {
                    const operand_212 = (try (allocator).create(zx_type_28));

                    (operand_212).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_209).ahead_one, .ahead_two = (operand_209).ahead_two, .braces = (operand_209).braces, .comments = (operand_209).comments, .depth = (operand_209).depth, .diagnostic = (operand_209).diagnostic, .dollar = (operand_209).dollar, .frames = (operand_209).frames, .keyword_state = (operand_209).keyword_state, .line_break = (operand_209).line_break, .mode = operand_211, .number = (operand_209).number, .offset = (operand_209).offset, .skip_until = operand_210, .source_length = (operand_209).source_length, .start = (operand_209).start, .symbol = (operand_209).symbol, .tokens = (operand_209).tokens, .warmed = (operand_209).warmed, });

                    break :block_213 @as(*const zx_type_28, operand_212);
                };
            };
        }

        return (in).state;
    }

    if ((((in).byte == @as(u8, 125)) and (((in).state).braces == @as(u64, 0)))) {
        return (try function_46_buffered_pointer(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if ((((in).byte == @as(u8, 123)) or ((in).byte == @as(u8, 125)))) {
        const value_2: u64 = (if (((in).byte == @as(u8, 123))) (((in).state).braces + @as(u64, 1)) else (((in).state).braces - @as(u64, 1)));

        return block_208: {
            const operand_204 = (in).state;
            const operand_205 = value_2;

            break :block_208 block_207: {
                const operand_206 = (try (allocator).create(zx_type_28));

                (operand_206).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_204).ahead_one, .ahead_two = (operand_204).ahead_two, .braces = operand_205, .comments = (operand_204).comments, .depth = (operand_204).depth, .diagnostic = (operand_204).diagnostic, .dollar = (operand_204).dollar, .frames = (operand_204).frames, .keyword_state = (operand_204).keyword_state, .line_break = (operand_204).line_break, .mode = (operand_204).mode, .number = (operand_204).number, .offset = (operand_204).offset, .skip_until = (operand_204).skip_until, .source_length = (operand_204).source_length, .start = (operand_204).start, .symbol = (operand_204).symbol, .tokens = (operand_204).tokens, .warmed = (operand_204).warmed, });

                break :block_207 @as(*const zx_type_28, operand_206);
            };
        };
    }

    if (((in).byte == @as(u8, 96))) {
        return (try function_36_buffered_pointer(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if (((in).byte == @as(u8, 34))) {
        return block_203: {
            const operand_199 = (in).state;
            const operand_200 = @as(zx_type_22, .InterpolationString);

            break :block_203 block_202: {
                const operand_201 = (try (allocator).create(zx_type_28));

                (operand_201).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_199).ahead_one, .ahead_two = (operand_199).ahead_two, .braces = (operand_199).braces, .comments = (operand_199).comments, .depth = (operand_199).depth, .diagnostic = (operand_199).diagnostic, .dollar = (operand_199).dollar, .frames = (operand_199).frames, .keyword_state = (operand_199).keyword_state, .line_break = (operand_199).line_break, .mode = operand_200, .number = (operand_199).number, .offset = (operand_199).offset, .skip_until = (operand_199).skip_until, .source_length = (operand_199).source_length, .start = (operand_199).start, .symbol = (operand_199).symbol, .tokens = (operand_199).tokens, .warmed = (operand_199).warmed, });

                break :block_202 @as(*const zx_type_28, operand_201);
            };
        };
    }

    if ((((in).byte == @as(u8, 47)) and (in).has_next)) {
        const value_3: u8 = (in).next;

        if (((value_3 == @as(u8, 47)) or (value_3 == @as(u8, 42)))) {
            const value_4: u64 = (((in).state).offset + @as(u64, 2));

            return block_198: {
                const operand_193 = (in).state;
                const operand_194 = value_4;
                const operand_195 = (if ((value_3 == @as(u8, 47))) @as(zx_type_22, .InterpolationLineComment) else @as(zx_type_22, .InterpolationBlockComment));

                break :block_198 block_197: {
                    const operand_196 = (try (allocator).create(zx_type_28));

                    (operand_196).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_193).ahead_one, .ahead_two = (operand_193).ahead_two, .braces = (operand_193).braces, .comments = (operand_193).comments, .depth = (operand_193).depth, .diagnostic = (operand_193).diagnostic, .dollar = (operand_193).dollar, .frames = (operand_193).frames, .keyword_state = (operand_193).keyword_state, .line_break = (operand_193).line_break, .mode = operand_195, .number = (operand_193).number, .offset = (operand_193).offset, .skip_until = operand_194, .source_length = (operand_193).source_length, .start = (operand_193).start, .symbol = (operand_193).symbol, .tokens = (operand_193).tokens, .warmed = (operand_193).warmed, });

                    break :block_197 @as(*const zx_type_28, operand_196);
                };
            };
        }
    }

    return (in).state;
}

fn function_49(allocator: ((std).mem).Allocator, in: *const zx_type_29) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if ((((in).state).offset < ((in).state).skip_until)) {
        return (in).state;
    }

    if ((((in).state).mode == @as(zx_type_22, .Idle))) {
        return block_81: {
            const operand_73 = in;
            const operand_74 = (try function_37_value(allocator, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .after = (operand_73).after, .byte = (operand_73).byte, .has_after = (operand_73).has_after, .has_next = (operand_73).has_next, .next = (operand_73).next, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_73).state).ahead_one, .ahead_two = ((operand_73).state).ahead_two, .braces = ((operand_73).state).braces, .comments = ((operand_73).state).comments, .depth = ((operand_73).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_73).state).diagnostic).code, .end = (((operand_73).state).diagnostic).end, .message = (((operand_73).state).diagnostic).message, .start = (((operand_73).state).diagnostic).start, .zx_origin = ((operand_73).state).diagnostic, }, .dollar = ((operand_73).state).dollar, .frames = ((operand_73).state).frames, .keyword_state = ((operand_73).state).keyword_state, .line_break = ((operand_73).state).line_break, .mode = ((operand_73).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_73).state).number).end, .last_byte = (((operand_73).state).number).last_byte, .phase = (((operand_73).state).number).phase, .separators_valid = (((operand_73).state).number).separators_valid, .zx_origin = ((operand_73).state).number, }, .offset = ((operand_73).state).offset, .skip_until = ((operand_73).state).skip_until, .source_length = ((operand_73).state).source_length, .start = ((operand_73).state).start, .symbol = ((operand_73).state).symbol, .tokens = ((operand_73).state).tokens, .warmed = ((operand_73).state).warmed, .zx_origin = (operand_73).state, }, .zx_origin = operand_73, }));

            break :block_81 (if (((operand_74).zx_origin != null)) (operand_74).zx_origin.? else block_80: {
                const operand_79 = (try (allocator).create(zx_type_28));

                (operand_79).* = zx_type_28{ .ahead_one = (operand_74).ahead_one, .ahead_two = (operand_74).ahead_two, .braces = (operand_74).braces, .comments = (operand_74).comments, .depth = (operand_74).depth, .diagnostic = (if ((((operand_74).diagnostic).zx_origin != null)) ((operand_74).diagnostic).zx_origin.? else block_76: {
                    const operand_75 = (try (allocator).create(zx_type_23));

                    (operand_75).* = zx_type_23{ .code = ((operand_74).diagnostic).code, .end = ((operand_74).diagnostic).end, .message = ((operand_74).diagnostic).message, .start = ((operand_74).diagnostic).start, };

                    break :block_76 @as(*const zx_type_23, operand_75);
                }), .dollar = (operand_74).dollar, .frames = (operand_74).frames, .keyword_state = (operand_74).keyword_state, .line_break = (operand_74).line_break, .mode = (operand_74).mode, .number = (if ((((operand_74).number).zx_origin != null)) ((operand_74).number).zx_origin.? else block_78: {
                    const operand_77 = (try (allocator).create(zx_type_20));

                    (operand_77).* = zx_type_20{ .end = ((operand_74).number).end, .last_byte = ((operand_74).number).last_byte, .phase = ((operand_74).number).phase, .separators_valid = ((operand_74).number).separators_valid, };

                    break :block_78 @as(*const zx_type_20, operand_77);
                }), .offset = (operand_74).offset, .skip_until = (operand_74).skip_until, .source_length = (operand_74).source_length, .start = (operand_74).start, .symbol = (operand_74).symbol, .tokens = (operand_74).tokens, .warmed = (operand_74).warmed, };

                break :block_80 @as(*const zx_type_28, operand_79);
            });
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .Identifier))) {
        if ((((try function_7(allocator, (in).byte)) or (try function_33(allocator, (in).byte))) or ((in).byte == @as(u8, 95)))) {
            const value_1: u64 = block_72: {
                const operand_69 = ((in).state).keyword_state;
                const operand_70 = (in).byte;
                const operand_71 = zx_type_33{ .state = operand_69, .byte = operand_70, };

                break :block_72 (try function_32(allocator, (&operand_71)));
            };

            return block_68: {
                const operand_64 = (in).state;
                const operand_65 = value_1;

                break :block_68 block_67: {
                    const operand_66 = (try (allocator).create(zx_type_28));

                    (operand_66).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_64).ahead_one, .ahead_two = (operand_64).ahead_two, .braces = (operand_64).braces, .comments = (operand_64).comments, .depth = (operand_64).depth, .diagnostic = (operand_64).diagnostic, .dollar = (operand_64).dollar, .frames = (operand_64).frames, .keyword_state = operand_65, .line_break = (operand_64).line_break, .mode = (operand_64).mode, .number = (operand_64).number, .offset = (operand_64).offset, .skip_until = (operand_64).skip_until, .source_length = (operand_64).source_length, .start = (operand_64).start, .symbol = (operand_64).symbol, .tokens = (operand_64).tokens, .warmed = (operand_64).warmed, });

                    break :block_67 @as(*const zx_type_28, operand_66);
                };
            };
        }

        const value_2: *const zx_type_28 = block_63: {
            const operand_55 = (in).state;
            const operand_56 = (try function_40_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_55).ahead_one, .ahead_two = (operand_55).ahead_two, .braces = (operand_55).braces, .comments = (operand_55).comments, .depth = (operand_55).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_55).diagnostic).code, .end = ((operand_55).diagnostic).end, .message = ((operand_55).diagnostic).message, .start = ((operand_55).diagnostic).start, .zx_origin = (operand_55).diagnostic, }, .dollar = (operand_55).dollar, .frames = (operand_55).frames, .keyword_state = (operand_55).keyword_state, .line_break = (operand_55).line_break, .mode = (operand_55).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_55).number).end, .last_byte = ((operand_55).number).last_byte, .phase = ((operand_55).number).phase, .separators_valid = ((operand_55).number).separators_valid, .zx_origin = (operand_55).number, }, .offset = (operand_55).offset, .skip_until = (operand_55).skip_until, .source_length = (operand_55).source_length, .start = (operand_55).start, .symbol = (operand_55).symbol, .tokens = (operand_55).tokens, .warmed = (operand_55).warmed, .zx_origin = operand_55, }));

            break :block_63 (if (((operand_56).zx_origin != null)) (operand_56).zx_origin.? else block_62: {
                const operand_61 = (try (allocator).create(zx_type_28));

                (operand_61).* = zx_type_28{ .ahead_one = (operand_56).ahead_one, .ahead_two = (operand_56).ahead_two, .braces = (operand_56).braces, .comments = (operand_56).comments, .depth = (operand_56).depth, .diagnostic = (if ((((operand_56).diagnostic).zx_origin != null)) ((operand_56).diagnostic).zx_origin.? else block_58: {
                    const operand_57 = (try (allocator).create(zx_type_23));

                    (operand_57).* = zx_type_23{ .code = ((operand_56).diagnostic).code, .end = ((operand_56).diagnostic).end, .message = ((operand_56).diagnostic).message, .start = ((operand_56).diagnostic).start, };

                    break :block_58 @as(*const zx_type_23, operand_57);
                }), .dollar = (operand_56).dollar, .frames = (operand_56).frames, .keyword_state = (operand_56).keyword_state, .line_break = (operand_56).line_break, .mode = (operand_56).mode, .number = (if ((((operand_56).number).zx_origin != null)) ((operand_56).number).zx_origin.? else block_60: {
                    const operand_59 = (try (allocator).create(zx_type_20));

                    (operand_59).* = zx_type_20{ .end = ((operand_56).number).end, .last_byte = ((operand_56).number).last_byte, .phase = ((operand_56).number).phase, .separators_valid = ((operand_56).number).separators_valid, };

                    break :block_60 @as(*const zx_type_20, operand_59);
                }), .offset = (operand_56).offset, .skip_until = (operand_56).skip_until, .source_length = (operand_56).source_length, .start = (operand_56).start, .symbol = (operand_56).symbol, .tokens = (operand_56).tokens, .warmed = (operand_56).warmed, };

                break :block_62 @as(*const zx_type_28, operand_61);
            });
        };

        return block_54: {
            const operand_46 = block_45: {
                const operand_37 = (in).byte;
                const operand_38 = (in).next;
                const operand_39 = (in).after;
                const operand_40 = (in).has_next;
                const operand_41 = (in).has_after;
                const operand_42 = value_2;

                break :block_45 block_44: {
                    const operand_43 = (try (allocator).create(zx_type_29));

                    (operand_43).* = @as(zx_type_29, zx_type_29{ .byte = operand_37, .next = operand_38, .after = operand_39, .has_next = operand_40, .has_after = operand_41, .state = operand_42, });

                    break :block_44 @as(*const zx_type_29, operand_43);
                };
            };
            const operand_47 = (try function_37_value(allocator, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .after = (operand_46).after, .byte = (operand_46).byte, .has_after = (operand_46).has_after, .has_next = (operand_46).has_next, .next = (operand_46).next, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_46).state).ahead_one, .ahead_two = ((operand_46).state).ahead_two, .braces = ((operand_46).state).braces, .comments = ((operand_46).state).comments, .depth = ((operand_46).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_46).state).diagnostic).code, .end = (((operand_46).state).diagnostic).end, .message = (((operand_46).state).diagnostic).message, .start = (((operand_46).state).diagnostic).start, .zx_origin = ((operand_46).state).diagnostic, }, .dollar = ((operand_46).state).dollar, .frames = ((operand_46).state).frames, .keyword_state = ((operand_46).state).keyword_state, .line_break = ((operand_46).state).line_break, .mode = ((operand_46).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_46).state).number).end, .last_byte = (((operand_46).state).number).last_byte, .phase = (((operand_46).state).number).phase, .separators_valid = (((operand_46).state).number).separators_valid, .zx_origin = ((operand_46).state).number, }, .offset = ((operand_46).state).offset, .skip_until = ((operand_46).state).skip_until, .source_length = ((operand_46).state).source_length, .start = ((operand_46).state).start, .symbol = ((operand_46).state).symbol, .tokens = ((operand_46).state).tokens, .warmed = ((operand_46).state).warmed, .zx_origin = (operand_46).state, }, .zx_origin = operand_46, }));

            break :block_54 (if (((operand_47).zx_origin != null)) (operand_47).zx_origin.? else block_53: {
                const operand_52 = (try (allocator).create(zx_type_28));

                (operand_52).* = zx_type_28{ .ahead_one = (operand_47).ahead_one, .ahead_two = (operand_47).ahead_two, .braces = (operand_47).braces, .comments = (operand_47).comments, .depth = (operand_47).depth, .diagnostic = (if ((((operand_47).diagnostic).zx_origin != null)) ((operand_47).diagnostic).zx_origin.? else block_49: {
                    const operand_48 = (try (allocator).create(zx_type_23));

                    (operand_48).* = zx_type_23{ .code = ((operand_47).diagnostic).code, .end = ((operand_47).diagnostic).end, .message = ((operand_47).diagnostic).message, .start = ((operand_47).diagnostic).start, };

                    break :block_49 @as(*const zx_type_23, operand_48);
                }), .dollar = (operand_47).dollar, .frames = (operand_47).frames, .keyword_state = (operand_47).keyword_state, .line_break = (operand_47).line_break, .mode = (operand_47).mode, .number = (if ((((operand_47).number).zx_origin != null)) ((operand_47).number).zx_origin.? else block_51: {
                    const operand_50 = (try (allocator).create(zx_type_20));

                    (operand_50).* = zx_type_20{ .end = ((operand_47).number).end, .last_byte = ((operand_47).number).last_byte, .phase = ((operand_47).number).phase, .separators_valid = ((operand_47).number).separators_valid, };

                    break :block_51 @as(*const zx_type_20, operand_50);
                }), .offset = (operand_47).offset, .skip_until = (operand_47).skip_until, .source_length = (operand_47).source_length, .start = (operand_47).start, .symbol = (operand_47).symbol, .tokens = (operand_47).tokens, .warmed = (operand_47).warmed, };

                break :block_53 @as(*const zx_type_28, operand_52);
            });
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .Number))) {
        return block_36: {
            const operand_28 = in;
            const operand_29 = (try function_44_value(allocator, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .after = (operand_28).after, .byte = (operand_28).byte, .has_after = (operand_28).has_after, .has_next = (operand_28).has_next, .next = (operand_28).next, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_28).state).ahead_one, .ahead_two = ((operand_28).state).ahead_two, .braces = ((operand_28).state).braces, .comments = ((operand_28).state).comments, .depth = ((operand_28).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_28).state).diagnostic).code, .end = (((operand_28).state).diagnostic).end, .message = (((operand_28).state).diagnostic).message, .start = (((operand_28).state).diagnostic).start, .zx_origin = ((operand_28).state).diagnostic, }, .dollar = ((operand_28).state).dollar, .frames = ((operand_28).state).frames, .keyword_state = ((operand_28).state).keyword_state, .line_break = ((operand_28).state).line_break, .mode = ((operand_28).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_28).state).number).end, .last_byte = (((operand_28).state).number).last_byte, .phase = (((operand_28).state).number).phase, .separators_valid = (((operand_28).state).number).separators_valid, .zx_origin = ((operand_28).state).number, }, .offset = ((operand_28).state).offset, .skip_until = ((operand_28).state).skip_until, .source_length = ((operand_28).state).source_length, .start = ((operand_28).state).start, .symbol = ((operand_28).state).symbol, .tokens = ((operand_28).state).tokens, .warmed = ((operand_28).state).warmed, .zx_origin = (operand_28).state, }, .zx_origin = operand_28, }));

            break :block_36 (if (((operand_29).zx_origin != null)) (operand_29).zx_origin.? else block_35: {
                const operand_34 = (try (allocator).create(zx_type_28));

                (operand_34).* = zx_type_28{ .ahead_one = (operand_29).ahead_one, .ahead_two = (operand_29).ahead_two, .braces = (operand_29).braces, .comments = (operand_29).comments, .depth = (operand_29).depth, .diagnostic = (if ((((operand_29).diagnostic).zx_origin != null)) ((operand_29).diagnostic).zx_origin.? else block_31: {
                    const operand_30 = (try (allocator).create(zx_type_23));

                    (operand_30).* = zx_type_23{ .code = ((operand_29).diagnostic).code, .end = ((operand_29).diagnostic).end, .message = ((operand_29).diagnostic).message, .start = ((operand_29).diagnostic).start, };

                    break :block_31 @as(*const zx_type_23, operand_30);
                }), .dollar = (operand_29).dollar, .frames = (operand_29).frames, .keyword_state = (operand_29).keyword_state, .line_break = (operand_29).line_break, .mode = (operand_29).mode, .number = (if ((((operand_29).number).zx_origin != null)) ((operand_29).number).zx_origin.? else block_33: {
                    const operand_32 = (try (allocator).create(zx_type_20));

                    (operand_32).* = zx_type_20{ .end = ((operand_29).number).end, .last_byte = ((operand_29).number).last_byte, .phase = ((operand_29).number).phase, .separators_valid = ((operand_29).number).separators_valid, };

                    break :block_33 @as(*const zx_type_20, operand_32);
                }), .offset = (operand_29).offset, .skip_until = (operand_29).skip_until, .source_length = (operand_29).source_length, .start = (operand_29).start, .symbol = (operand_29).symbol, .tokens = (operand_29).tokens, .warmed = (operand_29).warmed, };

                break :block_35 @as(*const zx_type_28, operand_34);
            });
        };
    }

    if (((((in).state).mode == @as(zx_type_22, .String)) or (((in).state).mode == @as(zx_type_22, .StringEscape)))) {
        return block_27: {
            const operand_19 = in;
            const operand_20 = (try function_45_value(allocator, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .after = (operand_19).after, .byte = (operand_19).byte, .has_after = (operand_19).has_after, .has_next = (operand_19).has_next, .next = (operand_19).next, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_19).state).ahead_one, .ahead_two = ((operand_19).state).ahead_two, .braces = ((operand_19).state).braces, .comments = ((operand_19).state).comments, .depth = ((operand_19).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_19).state).diagnostic).code, .end = (((operand_19).state).diagnostic).end, .message = (((operand_19).state).diagnostic).message, .start = (((operand_19).state).diagnostic).start, .zx_origin = ((operand_19).state).diagnostic, }, .dollar = ((operand_19).state).dollar, .frames = ((operand_19).state).frames, .keyword_state = ((operand_19).state).keyword_state, .line_break = ((operand_19).state).line_break, .mode = ((operand_19).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_19).state).number).end, .last_byte = (((operand_19).state).number).last_byte, .phase = (((operand_19).state).number).phase, .separators_valid = (((operand_19).state).number).separators_valid, .zx_origin = ((operand_19).state).number, }, .offset = ((operand_19).state).offset, .skip_until = ((operand_19).state).skip_until, .source_length = ((operand_19).state).source_length, .start = ((operand_19).state).start, .symbol = ((operand_19).state).symbol, .tokens = ((operand_19).state).tokens, .warmed = ((operand_19).state).warmed, .zx_origin = (operand_19).state, }, .zx_origin = operand_19, }));

            break :block_27 (if (((operand_20).zx_origin != null)) (operand_20).zx_origin.? else block_26: {
                const operand_25 = (try (allocator).create(zx_type_28));

                (operand_25).* = zx_type_28{ .ahead_one = (operand_20).ahead_one, .ahead_two = (operand_20).ahead_two, .braces = (operand_20).braces, .comments = (operand_20).comments, .depth = (operand_20).depth, .diagnostic = (if ((((operand_20).diagnostic).zx_origin != null)) ((operand_20).diagnostic).zx_origin.? else block_22: {
                    const operand_21 = (try (allocator).create(zx_type_23));

                    (operand_21).* = zx_type_23{ .code = ((operand_20).diagnostic).code, .end = ((operand_20).diagnostic).end, .message = ((operand_20).diagnostic).message, .start = ((operand_20).diagnostic).start, };

                    break :block_22 @as(*const zx_type_23, operand_21);
                }), .dollar = (operand_20).dollar, .frames = (operand_20).frames, .keyword_state = (operand_20).keyword_state, .line_break = (operand_20).line_break, .mode = (operand_20).mode, .number = (if ((((operand_20).number).zx_origin != null)) ((operand_20).number).zx_origin.? else block_24: {
                    const operand_23 = (try (allocator).create(zx_type_20));

                    (operand_23).* = zx_type_20{ .end = ((operand_20).number).end, .last_byte = ((operand_20).number).last_byte, .phase = ((operand_20).number).phase, .separators_valid = ((operand_20).number).separators_valid, };

                    break :block_24 @as(*const zx_type_20, operand_23);
                }), .offset = (operand_20).offset, .skip_until = (operand_20).skip_until, .source_length = (operand_20).source_length, .start = (operand_20).start, .symbol = (operand_20).symbol, .tokens = (operand_20).tokens, .warmed = (operand_20).warmed, };

                break :block_26 @as(*const zx_type_28, operand_25);
            });
        };
    }

    if (((((in).state).mode == @as(zx_type_22, .LineComment)) or (((in).state).mode == @as(zx_type_22, .BlockComment)))) {
        return block_18: {
            const operand_10 = in;
            const operand_11 = (try function_38_value(allocator, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .after = (operand_10).after, .byte = (operand_10).byte, .has_after = (operand_10).has_after, .has_next = (operand_10).has_next, .next = (operand_10).next, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_10).state).ahead_one, .ahead_two = ((operand_10).state).ahead_two, .braces = ((operand_10).state).braces, .comments = ((operand_10).state).comments, .depth = ((operand_10).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_10).state).diagnostic).code, .end = (((operand_10).state).diagnostic).end, .message = (((operand_10).state).diagnostic).message, .start = (((operand_10).state).diagnostic).start, .zx_origin = ((operand_10).state).diagnostic, }, .dollar = ((operand_10).state).dollar, .frames = ((operand_10).state).frames, .keyword_state = ((operand_10).state).keyword_state, .line_break = ((operand_10).state).line_break, .mode = ((operand_10).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_10).state).number).end, .last_byte = (((operand_10).state).number).last_byte, .phase = (((operand_10).state).number).phase, .separators_valid = (((operand_10).state).number).separators_valid, .zx_origin = ((operand_10).state).number, }, .offset = ((operand_10).state).offset, .skip_until = ((operand_10).state).skip_until, .source_length = ((operand_10).state).source_length, .start = ((operand_10).state).start, .symbol = ((operand_10).state).symbol, .tokens = ((operand_10).state).tokens, .warmed = ((operand_10).state).warmed, .zx_origin = (operand_10).state, }, .zx_origin = operand_10, }));

            break :block_18 (if (((operand_11).zx_origin != null)) (operand_11).zx_origin.? else block_17: {
                const operand_16 = (try (allocator).create(zx_type_28));

                (operand_16).* = zx_type_28{ .ahead_one = (operand_11).ahead_one, .ahead_two = (operand_11).ahead_two, .braces = (operand_11).braces, .comments = (operand_11).comments, .depth = (operand_11).depth, .diagnostic = (if ((((operand_11).diagnostic).zx_origin != null)) ((operand_11).diagnostic).zx_origin.? else block_13: {
                    const operand_12 = (try (allocator).create(zx_type_23));

                    (operand_12).* = zx_type_23{ .code = ((operand_11).diagnostic).code, .end = ((operand_11).diagnostic).end, .message = ((operand_11).diagnostic).message, .start = ((operand_11).diagnostic).start, };

                    break :block_13 @as(*const zx_type_23, operand_12);
                }), .dollar = (operand_11).dollar, .frames = (operand_11).frames, .keyword_state = (operand_11).keyword_state, .line_break = (operand_11).line_break, .mode = (operand_11).mode, .number = (if ((((operand_11).number).zx_origin != null)) ((operand_11).number).zx_origin.? else block_15: {
                    const operand_14 = (try (allocator).create(zx_type_20));

                    (operand_14).* = zx_type_20{ .end = ((operand_11).number).end, .last_byte = ((operand_11).number).last_byte, .phase = ((operand_11).number).phase, .separators_valid = ((operand_11).number).separators_valid, };

                    break :block_15 @as(*const zx_type_20, operand_14);
                }), .offset = (operand_11).offset, .skip_until = (operand_11).skip_until, .source_length = (operand_11).source_length, .start = (operand_11).start, .symbol = (operand_11).symbol, .tokens = (operand_11).tokens, .warmed = (operand_11).warmed, };

                break :block_17 @as(*const zx_type_28, operand_16);
            });
        };
    }

    return block_9: {
        const operand_1 = in;
        const operand_2 = (try function_48_value(allocator, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .after = (operand_1).after, .byte = (operand_1).byte, .has_after = (operand_1).has_after, .has_next = (operand_1).has_next, .next = (operand_1).next, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_1).state).ahead_one, .ahead_two = ((operand_1).state).ahead_two, .braces = ((operand_1).state).braces, .comments = ((operand_1).state).comments, .depth = ((operand_1).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_1).state).diagnostic).code, .end = (((operand_1).state).diagnostic).end, .message = (((operand_1).state).diagnostic).message, .start = (((operand_1).state).diagnostic).start, .zx_origin = ((operand_1).state).diagnostic, }, .dollar = ((operand_1).state).dollar, .frames = ((operand_1).state).frames, .keyword_state = ((operand_1).state).keyword_state, .line_break = ((operand_1).state).line_break, .mode = ((operand_1).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_1).state).number).end, .last_byte = (((operand_1).state).number).last_byte, .phase = (((operand_1).state).number).phase, .separators_valid = (((operand_1).state).number).separators_valid, .zx_origin = ((operand_1).state).number, }, .offset = ((operand_1).state).offset, .skip_until = ((operand_1).state).skip_until, .source_length = ((operand_1).state).source_length, .start = ((operand_1).state).start, .symbol = ((operand_1).state).symbol, .tokens = ((operand_1).state).tokens, .warmed = ((operand_1).state).warmed, .zx_origin = (operand_1).state, }, .zx_origin = operand_1, }));

        break :block_9 (if (((operand_2).zx_origin != null)) (operand_2).zx_origin.? else block_8: {
            const operand_7 = (try (allocator).create(zx_type_28));

            (operand_7).* = zx_type_28{ .ahead_one = (operand_2).ahead_one, .ahead_two = (operand_2).ahead_two, .braces = (operand_2).braces, .comments = (operand_2).comments, .depth = (operand_2).depth, .diagnostic = (if ((((operand_2).diagnostic).zx_origin != null)) ((operand_2).diagnostic).zx_origin.? else block_4: {
                const operand_3 = (try (allocator).create(zx_type_23));

                (operand_3).* = zx_type_23{ .code = ((operand_2).diagnostic).code, .end = ((operand_2).diagnostic).end, .message = ((operand_2).diagnostic).message, .start = ((operand_2).diagnostic).start, };

                break :block_4 @as(*const zx_type_23, operand_3);
            }), .dollar = (operand_2).dollar, .frames = (operand_2).frames, .keyword_state = (operand_2).keyword_state, .line_break = (operand_2).line_break, .mode = (operand_2).mode, .number = (if ((((operand_2).number).zx_origin != null)) ((operand_2).number).zx_origin.? else block_6: {
                const operand_5 = (try (allocator).create(zx_type_20));

                (operand_5).* = zx_type_20{ .end = ((operand_2).number).end, .last_byte = ((operand_2).number).last_byte, .phase = ((operand_2).number).phase, .separators_valid = ((operand_2).number).separators_valid, };

                break :block_6 @as(*const zx_type_20, operand_5);
            }), .offset = (operand_2).offset, .skip_until = (operand_2).skip_until, .source_length = (operand_2).source_length, .start = (operand_2).start, .symbol = (operand_2).symbol, .tokens = (operand_2).tokens, .warmed = (operand_2).warmed, };

            break :block_8 @as(*const zx_type_28, operand_7);
        });
    };
}

fn function_49_value(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if ((((in).state).offset < ((in).state).skip_until)) {
        return (in).state;
    }

    if ((((in).state).mode == @as(zx_type_22, .Idle))) {
        return block_103: {
            break :block_103 (try function_37_value(allocator, in));
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .Identifier))) {
        if ((((try function_7(allocator, (in).byte)) or (try function_33(allocator, (in).byte))) or ((in).byte == @as(u8, 95)))) {
            const value_1: u64 = block_102: {
                const operand_99 = ((in).state).keyword_state;
                const operand_100 = (in).byte;
                const operand_101 = zx_type_33{ .state = operand_99, .byte = operand_100, };

                break :block_102 (try function_32(allocator, (&operand_101)));
            };

            return block_98: {
                const operand_95 = (in).state;
                const operand_96 = block_97: {
                    break :block_97 value_1;
                };

                break :block_98 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_95).ahead_one, .ahead_two = (operand_95).ahead_two, .braces = (operand_95).braces, .comments = (operand_95).comments, .depth = (operand_95).depth, .diagnostic = (operand_95).diagnostic, .dollar = (operand_95).dollar, .frames = (operand_95).frames, .keyword_state = operand_96, .line_break = (operand_95).line_break, .mode = (operand_95).mode, .number = (operand_95).number, .offset = (operand_95).offset, .skip_until = (operand_95).skip_until, .source_length = (operand_95).source_length, .start = (operand_95).start, .symbol = (operand_95).symbol, .tokens = (operand_95).tokens, .warmed = (operand_95).warmed, });
            };
        }

        const value_2: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_94: {
            break :block_94 (try function_40_value(allocator, (in).state));
        };

        return block_93: {
            break :block_93 (try function_37_value(allocator, block_92: {
                const operand_86 = (in).byte;
                const operand_87 = (in).next;
                const operand_88 = (in).after;
                const operand_89 = (in).has_next;
                const operand_90 = (in).has_after;
                const operand_91 = value_2;

                break :block_92 @as(value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .byte = operand_86, .next = operand_87, .after = operand_88, .has_next = operand_89, .has_after = operand_90, .state = operand_91, });
            }));
        };
    }

    if ((((in).state).mode == @as(zx_type_22, .Number))) {
        return block_85: {
            break :block_85 (try function_44_value(allocator, in));
        };
    }

    if (((((in).state).mode == @as(zx_type_22, .String)) or (((in).state).mode == @as(zx_type_22, .StringEscape)))) {
        return block_84: {
            break :block_84 (try function_45_value(allocator, in));
        };
    }

    if (((((in).state).mode == @as(zx_type_22, .LineComment)) or (((in).state).mode == @as(zx_type_22, .BlockComment)))) {
        return block_83: {
            break :block_83 (try function_38_value(allocator, in));
        };
    }

    return block_82: {
        break :block_82 (try function_48_value(allocator, in));
    };
}

fn function_49_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if ((((in).state).offset < ((in).state).skip_until)) {
        return (in).state;
    }

    if ((((in).state).mode == @as(zx_type_22, .Idle))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_125: {
            break :block_125 (try function_37_buffered(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if ((((in).state).mode == @as(zx_type_22, .Identifier))) {
        if ((((try function_7(allocator, (in).byte)) or (try function_33(allocator, (in).byte))) or ((in).byte == @as(u8, 95)))) {
            const value_1: u64 = block_124: {
                const operand_121 = ((in).state).keyword_state;
                const operand_122 = (in).byte;
                const operand_123 = zx_type_33{ .state = operand_121, .byte = operand_122, };

                break :block_124 (try function_32(allocator, (&operand_123)));
            };

            return block_120: {
                const operand_117 = (in).state;
                const operand_118 = block_119: {
                    break :block_119 value_1;
                };

                break :block_120 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_117).ahead_one, .ahead_two = (operand_117).ahead_two, .braces = (operand_117).braces, .comments = (operand_117).comments, .depth = (operand_117).depth, .diagnostic = (operand_117).diagnostic, .dollar = (operand_117).dollar, .frames = (operand_117).frames, .keyword_state = operand_118, .line_break = (operand_117).line_break, .mode = (operand_117).mode, .number = (operand_117).number, .offset = (operand_117).offset, .skip_until = (operand_117).skip_until, .source_length = (operand_117).source_length, .start = (operand_117).start, .symbol = (operand_117).symbol, .tokens = (operand_117).tokens, .warmed = (operand_117).warmed, });
            };
        }

        const value_2: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_116: {
            break :block_116 (try function_40_buffered(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });

        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_115: {
            break :block_115 (try function_37_buffered(allocator, block_114: {
                const operand_108 = (in).byte;
                const operand_109 = (in).next;
                const operand_110 = (in).after;
                const operand_111 = (in).has_next;
                const operand_112 = (in).has_after;
                const operand_113 = value_2;

                break :block_114 @as(value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .byte = operand_108, .next = operand_109, .after = operand_110, .has_next = operand_111, .has_after = operand_112, .state = operand_113, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if ((((in).state).mode == @as(zx_type_22, .Number))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_107: {
            break :block_107 (try function_44_buffered(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if (((((in).state).mode == @as(zx_type_22, .String)) or (((in).state).mode == @as(zx_type_22, .StringEscape)))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_106: {
            break :block_106 (try function_45_buffered(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if (((((in).state).mode == @as(zx_type_22, .LineComment)) or (((in).state).mode == @as(zx_type_22, .BlockComment)))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_105: {
            break :block_105 (try function_38_buffered(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_104: {
        break :block_104 (try function_48_buffered(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    });
}

fn function_49_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_29, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if ((((in).state).offset < ((in).state).skip_until)) {
        return (in).state;
    }

    if ((((in).state).mode == @as(zx_type_22, .Idle))) {
        return (try function_37_buffered_pointer(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if ((((in).state).mode == @as(zx_type_22, .Identifier))) {
        if ((((try function_7(allocator, (in).byte)) or (try function_33(allocator, (in).byte))) or ((in).byte == @as(u8, 95)))) {
            const value_1: u64 = block_143: {
                const operand_140 = ((in).state).keyword_state;
                const operand_141 = (in).byte;
                const operand_142 = zx_type_33{ .state = operand_140, .byte = operand_141, };

                break :block_143 (try function_32(allocator, (&operand_142)));
            };

            return block_139: {
                const operand_135 = (in).state;
                const operand_136 = value_1;

                break :block_139 block_138: {
                    const operand_137 = (try (allocator).create(zx_type_28));

                    (operand_137).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_135).ahead_one, .ahead_two = (operand_135).ahead_two, .braces = (operand_135).braces, .comments = (operand_135).comments, .depth = (operand_135).depth, .diagnostic = (operand_135).diagnostic, .dollar = (operand_135).dollar, .frames = (operand_135).frames, .keyword_state = operand_136, .line_break = (operand_135).line_break, .mode = (operand_135).mode, .number = (operand_135).number, .offset = (operand_135).offset, .skip_until = (operand_135).skip_until, .source_length = (operand_135).source_length, .start = (operand_135).start, .symbol = (operand_135).symbol, .tokens = (operand_135).tokens, .warmed = (operand_135).warmed, });

                    break :block_138 @as(*const zx_type_28, operand_137);
                };
            };
        }

        const value_2: *const zx_type_28 = (try function_40_buffered_pointer(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));

        return (try function_37_buffered_pointer(allocator, block_134: {
            const operand_126 = (in).byte;
            const operand_127 = (in).next;
            const operand_128 = (in).after;
            const operand_129 = (in).has_next;
            const operand_130 = (in).has_after;
            const operand_131 = value_2;

            break :block_134 block_133: {
                const operand_132 = (try (allocator).create(zx_type_29));

                (operand_132).* = @as(zx_type_29, zx_type_29{ .byte = operand_126, .next = operand_127, .after = operand_128, .has_next = operand_129, .has_after = operand_130, .state = operand_131, });

                break :block_133 @as(*const zx_type_29, operand_132);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if ((((in).state).mode == @as(zx_type_22, .Number))) {
        return (try function_44_buffered_pointer(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if (((((in).state).mode == @as(zx_type_22, .String)) or (((in).state).mode == @as(zx_type_22, .StringEscape)))) {
        return (try function_45_buffered_pointer(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if (((((in).state).mode == @as(zx_type_22, .LineComment)) or (((in).state).mode == @as(zx_type_22, .BlockComment)))) {
        return (try function_38_buffered_pointer(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    return (try function_48_buffered_pointer(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
}

fn function_50(allocator: ((std).mem).Allocator, in: *const zx_type_37) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if ((!block_40: {
        const operand_38 = (((in).state).diagnostic).message;
        const operand_39 = @as([]const u8, "");

        break :block_40 ((std).mem).eql(u8, operand_38, operand_39);
    })) {
        return (in).state;
    }

    if ((((in).state).warmed == @as(u8, 0))) {
        return block_37: {
            const operand_32 = (in).state;
            const operand_33 = @as(u8, 1);
            const operand_34 = (in).byte;

            break :block_37 block_36: {
                const operand_35 = (try (allocator).create(zx_type_28));

                (operand_35).* = @as(zx_type_28, zx_type_28{ .ahead_one = operand_34, .ahead_two = (operand_32).ahead_two, .braces = (operand_32).braces, .comments = (operand_32).comments, .depth = (operand_32).depth, .diagnostic = (operand_32).diagnostic, .dollar = (operand_32).dollar, .frames = (operand_32).frames, .keyword_state = (operand_32).keyword_state, .line_break = (operand_32).line_break, .mode = (operand_32).mode, .number = (operand_32).number, .offset = (operand_32).offset, .skip_until = (operand_32).skip_until, .source_length = (operand_32).source_length, .start = (operand_32).start, .symbol = (operand_32).symbol, .tokens = (operand_32).tokens, .warmed = operand_33, });

                break :block_36 @as(*const zx_type_28, operand_35);
            };
        };
    }

    if ((((in).state).warmed == @as(u8, 1))) {
        return block_31: {
            const operand_26 = (in).state;
            const operand_27 = @as(u8, 2);
            const operand_28 = (in).byte;

            break :block_31 block_30: {
                const operand_29 = (try (allocator).create(zx_type_28));

                (operand_29).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_26).ahead_one, .ahead_two = operand_28, .braces = (operand_26).braces, .comments = (operand_26).comments, .depth = (operand_26).depth, .diagnostic = (operand_26).diagnostic, .dollar = (operand_26).dollar, .frames = (operand_26).frames, .keyword_state = (operand_26).keyword_state, .line_break = (operand_26).line_break, .mode = (operand_26).mode, .number = (operand_26).number, .offset = (operand_26).offset, .skip_until = (operand_26).skip_until, .source_length = (operand_26).source_length, .start = (operand_26).start, .symbol = (operand_26).symbol, .tokens = (operand_26).tokens, .warmed = operand_27, });

                break :block_30 @as(*const zx_type_28, operand_29);
            };
        };
    }

    const value_1: u8 = ((in).state).ahead_two;
    const value_2: u8 = (in).byte;
    const value_3: *const zx_type_28 = block_25: {
        const operand_17 = block_16: {
            const operand_8 = ((in).state).ahead_one;
            const operand_9 = ((in).state).ahead_two;
            const operand_10 = (in).byte;
            const operand_11 = true;
            const operand_12 = true;
            const operand_13 = (in).state;

            break :block_16 block_15: {
                const operand_14 = (try (allocator).create(zx_type_29));

                (operand_14).* = @as(zx_type_29, zx_type_29{ .byte = operand_8, .next = operand_9, .after = operand_10, .has_next = operand_11, .has_after = operand_12, .state = operand_13, });

                break :block_15 @as(*const zx_type_29, operand_14);
            };
        };
        const operand_18 = (try function_49_value(allocator, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .after = (operand_17).after, .byte = (operand_17).byte, .has_after = (operand_17).has_after, .has_next = (operand_17).has_next, .next = (operand_17).next, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_17).state).ahead_one, .ahead_two = ((operand_17).state).ahead_two, .braces = ((operand_17).state).braces, .comments = ((operand_17).state).comments, .depth = ((operand_17).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_17).state).diagnostic).code, .end = (((operand_17).state).diagnostic).end, .message = (((operand_17).state).diagnostic).message, .start = (((operand_17).state).diagnostic).start, .zx_origin = ((operand_17).state).diagnostic, }, .dollar = ((operand_17).state).dollar, .frames = ((operand_17).state).frames, .keyword_state = ((operand_17).state).keyword_state, .line_break = ((operand_17).state).line_break, .mode = ((operand_17).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_17).state).number).end, .last_byte = (((operand_17).state).number).last_byte, .phase = (((operand_17).state).number).phase, .separators_valid = (((operand_17).state).number).separators_valid, .zx_origin = ((operand_17).state).number, }, .offset = ((operand_17).state).offset, .skip_until = ((operand_17).state).skip_until, .source_length = ((operand_17).state).source_length, .start = ((operand_17).state).start, .symbol = ((operand_17).state).symbol, .tokens = ((operand_17).state).tokens, .warmed = ((operand_17).state).warmed, .zx_origin = (operand_17).state, }, .zx_origin = operand_17, }));

        break :block_25 (if (((operand_18).zx_origin != null)) (operand_18).zx_origin.? else block_24: {
            const operand_23 = (try (allocator).create(zx_type_28));

            (operand_23).* = zx_type_28{ .ahead_one = (operand_18).ahead_one, .ahead_two = (operand_18).ahead_two, .braces = (operand_18).braces, .comments = (operand_18).comments, .depth = (operand_18).depth, .diagnostic = (if ((((operand_18).diagnostic).zx_origin != null)) ((operand_18).diagnostic).zx_origin.? else block_20: {
                const operand_19 = (try (allocator).create(zx_type_23));

                (operand_19).* = zx_type_23{ .code = ((operand_18).diagnostic).code, .end = ((operand_18).diagnostic).end, .message = ((operand_18).diagnostic).message, .start = ((operand_18).diagnostic).start, };

                break :block_20 @as(*const zx_type_23, operand_19);
            }), .dollar = (operand_18).dollar, .frames = (operand_18).frames, .keyword_state = (operand_18).keyword_state, .line_break = (operand_18).line_break, .mode = (operand_18).mode, .number = (if ((((operand_18).number).zx_origin != null)) ((operand_18).number).zx_origin.? else block_22: {
                const operand_21 = (try (allocator).create(zx_type_20));

                (operand_21).* = zx_type_20{ .end = ((operand_18).number).end, .last_byte = ((operand_18).number).last_byte, .phase = ((operand_18).number).phase, .separators_valid = ((operand_18).number).separators_valid, };

                break :block_22 @as(*const zx_type_20, operand_21);
            }), .offset = (operand_18).offset, .skip_until = (operand_18).skip_until, .source_length = (operand_18).source_length, .start = (operand_18).start, .symbol = (operand_18).symbol, .tokens = (operand_18).tokens, .warmed = (operand_18).warmed, };

            break :block_24 @as(*const zx_type_28, operand_23);
        });
    };
    const value_4: u64 = ((value_3).offset + @as(u64, 1));

    return block_7: {
        const operand_1 = value_3;
        const operand_2 = value_1;
        const operand_3 = value_2;
        const operand_4 = value_4;

        break :block_7 block_6: {
            const operand_5 = (try (allocator).create(zx_type_28));

            (operand_5).* = @as(zx_type_28, zx_type_28{ .ahead_one = operand_2, .ahead_two = operand_3, .braces = (operand_1).braces, .comments = (operand_1).comments, .depth = (operand_1).depth, .diagnostic = (operand_1).diagnostic, .dollar = (operand_1).dollar, .frames = (operand_1).frames, .keyword_state = (operand_1).keyword_state, .line_break = (operand_1).line_break, .mode = (operand_1).mode, .number = (operand_1).number, .offset = operand_4, .skip_until = (operand_1).skip_until, .source_length = (operand_1).source_length, .start = (operand_1).start, .symbol = (operand_1).symbol, .tokens = (operand_1).tokens, .warmed = (operand_1).warmed, });

            break :block_6 @as(*const zx_type_28, operand_5);
        };
    };
}

fn function_50_value(allocator: ((std).mem).Allocator, in: value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if ((!block_67: {
        const operand_65 = (((in).state).diagnostic).message;
        const operand_66 = @as([]const u8, "");

        break :block_67 ((std).mem).eql(u8, operand_65, operand_66);
    })) {
        return (in).state;
    }

    if ((((in).state).warmed == @as(u8, 0))) {
        return block_64: {
            const operand_61 = (in).state;
            const operand_62 = @as(u8, 1);
            const operand_63 = (in).byte;

            break :block_64 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = operand_63, .ahead_two = (operand_61).ahead_two, .braces = (operand_61).braces, .comments = (operand_61).comments, .depth = (operand_61).depth, .diagnostic = (operand_61).diagnostic, .dollar = (operand_61).dollar, .frames = (operand_61).frames, .keyword_state = (operand_61).keyword_state, .line_break = (operand_61).line_break, .mode = (operand_61).mode, .number = (operand_61).number, .offset = (operand_61).offset, .skip_until = (operand_61).skip_until, .source_length = (operand_61).source_length, .start = (operand_61).start, .symbol = (operand_61).symbol, .tokens = (operand_61).tokens, .warmed = operand_62, });
        };
    }

    if ((((in).state).warmed == @as(u8, 1))) {
        return block_60: {
            const operand_57 = (in).state;
            const operand_58 = @as(u8, 2);
            const operand_59 = (in).byte;

            break :block_60 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_57).ahead_one, .ahead_two = operand_59, .braces = (operand_57).braces, .comments = (operand_57).comments, .depth = (operand_57).depth, .diagnostic = (operand_57).diagnostic, .dollar = (operand_57).dollar, .frames = (operand_57).frames, .keyword_state = (operand_57).keyword_state, .line_break = (operand_57).line_break, .mode = (operand_57).mode, .number = (operand_57).number, .offset = (operand_57).offset, .skip_until = (operand_57).skip_until, .source_length = (operand_57).source_length, .start = (operand_57).start, .symbol = (operand_57).symbol, .tokens = (operand_57).tokens, .warmed = operand_58, });
        };
    }

    const value_1: u8 = ((in).state).ahead_two;
    const value_2: u8 = (in).byte;
    const value_3: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_56: {
        break :block_56 (try function_49_value(allocator, block_55: {
            const operand_49 = ((in).state).ahead_one;
            const operand_50 = ((in).state).ahead_two;
            const operand_51 = (in).byte;
            const operand_52 = true;
            const operand_53 = true;
            const operand_54 = (in).state;

            break :block_55 @as(value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .byte = operand_49, .next = operand_50, .after = operand_51, .has_next = operand_52, .has_after = operand_53, .state = operand_54, });
        }));
    };
    const value_4: u64 = ((value_3).offset + @as(u64, 1));

    return block_48: {
        const operand_41 = value_3;
        const operand_42 = block_43: {
            break :block_43 value_1;
        };
        const operand_44 = block_45: {
            break :block_45 value_2;
        };
        const operand_46 = block_47: {
            break :block_47 value_4;
        };

        break :block_48 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = operand_42, .ahead_two = operand_44, .braces = (operand_41).braces, .comments = (operand_41).comments, .depth = (operand_41).depth, .diagnostic = (operand_41).diagnostic, .dollar = (operand_41).dollar, .frames = (operand_41).frames, .keyword_state = (operand_41).keyword_state, .line_break = (operand_41).line_break, .mode = (operand_41).mode, .number = (operand_41).number, .offset = operand_46, .skip_until = (operand_41).skip_until, .source_length = (operand_41).source_length, .start = (operand_41).start, .symbol = (operand_41).symbol, .tokens = (operand_41).tokens, .warmed = (operand_41).warmed, });
    };
}

fn function_50_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if ((!block_94: {
        const operand_92 = (((in).state).diagnostic).message;
        const operand_93 = @as([]const u8, "");

        break :block_94 ((std).mem).eql(u8, operand_92, operand_93);
    })) {
        return (in).state;
    }

    if ((((in).state).warmed == @as(u8, 0))) {
        return block_91: {
            const operand_88 = (in).state;
            const operand_89 = @as(u8, 1);
            const operand_90 = (in).byte;

            break :block_91 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = operand_90, .ahead_two = (operand_88).ahead_two, .braces = (operand_88).braces, .comments = (operand_88).comments, .depth = (operand_88).depth, .diagnostic = (operand_88).diagnostic, .dollar = (operand_88).dollar, .frames = (operand_88).frames, .keyword_state = (operand_88).keyword_state, .line_break = (operand_88).line_break, .mode = (operand_88).mode, .number = (operand_88).number, .offset = (operand_88).offset, .skip_until = (operand_88).skip_until, .source_length = (operand_88).source_length, .start = (operand_88).start, .symbol = (operand_88).symbol, .tokens = (operand_88).tokens, .warmed = operand_89, });
        };
    }

    if ((((in).state).warmed == @as(u8, 1))) {
        return block_87: {
            const operand_84 = (in).state;
            const operand_85 = @as(u8, 2);
            const operand_86 = (in).byte;

            break :block_87 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_84).ahead_one, .ahead_two = operand_86, .braces = (operand_84).braces, .comments = (operand_84).comments, .depth = (operand_84).depth, .diagnostic = (operand_84).diagnostic, .dollar = (operand_84).dollar, .frames = (operand_84).frames, .keyword_state = (operand_84).keyword_state, .line_break = (operand_84).line_break, .mode = (operand_84).mode, .number = (operand_84).number, .offset = (operand_84).offset, .skip_until = (operand_84).skip_until, .source_length = (operand_84).source_length, .start = (operand_84).start, .symbol = (operand_84).symbol, .tokens = (operand_84).tokens, .warmed = operand_85, });
        };
    }

    const value_1: u8 = ((in).state).ahead_two;
    const value_2: u8 = (in).byte;
    const value_3: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_83: {
        break :block_83 (try function_49_buffered(allocator, block_82: {
            const operand_76 = ((in).state).ahead_one;
            const operand_77 = ((in).state).ahead_two;
            const operand_78 = (in).byte;
            const operand_79 = true;
            const operand_80 = true;
            const operand_81 = (in).state;

            break :block_82 @as(value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .byte = operand_76, .next = operand_77, .after = operand_78, .has_next = operand_79, .has_after = operand_80, .state = operand_81, });
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    });
    const value_4: u64 = ((value_3).offset + @as(u64, 1));

    return block_75: {
        const operand_68 = value_3;
        const operand_69 = block_70: {
            break :block_70 value_1;
        };
        const operand_71 = block_72: {
            break :block_72 value_2;
        };
        const operand_73 = block_74: {
            break :block_74 value_4;
        };

        break :block_75 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = operand_69, .ahead_two = operand_71, .braces = (operand_68).braces, .comments = (operand_68).comments, .depth = (operand_68).depth, .diagnostic = (operand_68).diagnostic, .dollar = (operand_68).dollar, .frames = (operand_68).frames, .keyword_state = (operand_68).keyword_state, .line_break = (operand_68).line_break, .mode = (operand_68).mode, .number = (operand_68).number, .offset = operand_73, .skip_until = (operand_68).skip_until, .source_length = (operand_68).source_length, .start = (operand_68).start, .symbol = (operand_68).symbol, .tokens = (operand_68).tokens, .warmed = (operand_68).warmed, });
    };
}

fn function_50_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_37, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if ((!block_125: {
        const operand_123 = (((in).state).diagnostic).message;
        const operand_124 = @as([]const u8, "");

        break :block_125 ((std).mem).eql(u8, operand_123, operand_124);
    })) {
        return (in).state;
    }

    if ((((in).state).warmed == @as(u8, 0))) {
        return block_122: {
            const operand_117 = (in).state;
            const operand_118 = @as(u8, 1);
            const operand_119 = (in).byte;

            break :block_122 block_121: {
                const operand_120 = (try (allocator).create(zx_type_28));

                (operand_120).* = @as(zx_type_28, zx_type_28{ .ahead_one = operand_119, .ahead_two = (operand_117).ahead_two, .braces = (operand_117).braces, .comments = (operand_117).comments, .depth = (operand_117).depth, .diagnostic = (operand_117).diagnostic, .dollar = (operand_117).dollar, .frames = (operand_117).frames, .keyword_state = (operand_117).keyword_state, .line_break = (operand_117).line_break, .mode = (operand_117).mode, .number = (operand_117).number, .offset = (operand_117).offset, .skip_until = (operand_117).skip_until, .source_length = (operand_117).source_length, .start = (operand_117).start, .symbol = (operand_117).symbol, .tokens = (operand_117).tokens, .warmed = operand_118, });

                break :block_121 @as(*const zx_type_28, operand_120);
            };
        };
    }

    if ((((in).state).warmed == @as(u8, 1))) {
        return block_116: {
            const operand_111 = (in).state;
            const operand_112 = @as(u8, 2);
            const operand_113 = (in).byte;

            break :block_116 block_115: {
                const operand_114 = (try (allocator).create(zx_type_28));

                (operand_114).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_111).ahead_one, .ahead_two = operand_113, .braces = (operand_111).braces, .comments = (operand_111).comments, .depth = (operand_111).depth, .diagnostic = (operand_111).diagnostic, .dollar = (operand_111).dollar, .frames = (operand_111).frames, .keyword_state = (operand_111).keyword_state, .line_break = (operand_111).line_break, .mode = (operand_111).mode, .number = (operand_111).number, .offset = (operand_111).offset, .skip_until = (operand_111).skip_until, .source_length = (operand_111).source_length, .start = (operand_111).start, .symbol = (operand_111).symbol, .tokens = (operand_111).tokens, .warmed = operand_112, });

                break :block_115 @as(*const zx_type_28, operand_114);
            };
        };
    }

    const value_1: u8 = ((in).state).ahead_two;
    const value_2: u8 = (in).byte;
    const value_3: *const zx_type_28 = (try function_49_buffered_pointer(allocator, block_110: {
        const operand_102 = ((in).state).ahead_one;
        const operand_103 = ((in).state).ahead_two;
        const operand_104 = (in).byte;
        const operand_105 = true;
        const operand_106 = true;
        const operand_107 = (in).state;

        break :block_110 block_109: {
            const operand_108 = (try (allocator).create(zx_type_29));

            (operand_108).* = @as(zx_type_29, zx_type_29{ .byte = operand_102, .next = operand_103, .after = operand_104, .has_next = operand_105, .has_after = operand_106, .state = operand_107, });

            break :block_109 @as(*const zx_type_29, operand_108);
        };
    }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    const value_4: u64 = ((value_3).offset + @as(u64, 1));

    return block_101: {
        const operand_95 = value_3;
        const operand_96 = value_1;
        const operand_97 = value_2;
        const operand_98 = value_4;

        break :block_101 block_100: {
            const operand_99 = (try (allocator).create(zx_type_28));

            (operand_99).* = @as(zx_type_28, zx_type_28{ .ahead_one = operand_96, .ahead_two = operand_97, .braces = (operand_95).braces, .comments = (operand_95).comments, .depth = (operand_95).depth, .diagnostic = (operand_95).diagnostic, .dollar = (operand_95).dollar, .frames = (operand_95).frames, .keyword_state = (operand_95).keyword_state, .line_break = (operand_95).line_break, .mode = (operand_95).mode, .number = (operand_95).number, .offset = operand_98, .skip_until = (operand_95).skip_until, .source_length = (operand_95).source_length, .start = (operand_95).start, .symbol = (operand_95).symbol, .tokens = (operand_95).tokens, .warmed = (operand_95).warmed, });

            break :block_100 @as(*const zx_type_28, operand_99);
        };
    };
}

fn function_51(allocator: ((std).mem).Allocator, in: *const zx_type_38) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    return block_43: {
        const value_3: []const u8 = (in).source;
        const value_8: *const zx_type_45 = block_42: {
            const operand_8 = block_7: {
                const operand_2 = value_3;
                const operand_3 = @as(u64, 0);
                const operand_4 = (in).state;

                break :block_7 block_6: {
                    const operand_5 = (try (allocator).create(zx_type_45));

                    (operand_5).* = @as(zx_type_45, zx_type_45{ .index = operand_3, .result = operand_4, .source = operand_2, });

                    break :block_6 @as(*const zx_type_45, operand_5);
                };
            };

            var state_capacity_10: (std).ArrayList(*const zx_type_17) = .empty;

            var state_capacity_started_11 = false;

            defer (state_capacity_10).deinit(allocator);

            var state_capacity_12: (std).ArrayList(*const zx_type_24) = .empty;

            var state_capacity_started_13 = false;

            defer (state_capacity_12).deinit(allocator);

            var state_capacity_14: (std).ArrayList(*const zx_type_18) = .empty;

            var state_capacity_started_15 = false;

            defer (state_capacity_14).deinit(allocator);

            var state_1: value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512 = value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = (operand_8).index, .result = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_8).result).ahead_one, .ahead_two = ((operand_8).result).ahead_two, .braces = ((operand_8).result).braces, .comments = ((operand_8).result).comments, .depth = ((operand_8).result).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_8).result).diagnostic).code, .end = (((operand_8).result).diagnostic).end, .message = (((operand_8).result).diagnostic).message, .start = (((operand_8).result).diagnostic).start, .zx_origin = ((operand_8).result).diagnostic, }, .dollar = ((operand_8).result).dollar, .frames = ((operand_8).result).frames, .keyword_state = ((operand_8).result).keyword_state, .line_break = ((operand_8).result).line_break, .mode = ((operand_8).result).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_8).result).number).end, .last_byte = (((operand_8).result).number).last_byte, .phase = (((operand_8).result).number).phase, .separators_valid = (((operand_8).result).number).separators_valid, .zx_origin = ((operand_8).result).number, }, .offset = ((operand_8).result).offset, .skip_until = ((operand_8).result).skip_until, .source_length = ((operand_8).result).source_length, .start = ((operand_8).result).start, .symbol = ((operand_8).result).symbol, .tokens = ((operand_8).result).tokens, .warmed = ((operand_8).result).warmed, .zx_origin = (operand_8).result, }, .source = (operand_8).source, .zx_origin = operand_8, };

            var state_changed_9 = false;

            while (((state_1).index < @as(u64, ((state_1).source).len))) {
                state_1 = block_29: {
                    const value_6: u8 = block_28: {
                        const operand_26 = (state_1).source;
                        const operand_27 = (state_1).index;

                        if ((operand_27 >= (operand_26).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_28 (operand_26)[@intCast(operand_27)];
                    };
                    const value_1: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = (state_1).result;
                    const value_2: u8 = block_25: {
                        break :block_25 value_6;
                    };
                    const value_7: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_24: {
                        break :block_24 (try function_50_buffered(allocator, block_23: {
                            const operand_20 = block_21: {
                                break :block_21 value_2;
                            };
                            const operand_22 = value_1;

                            break :block_23 @as(value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b, value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b{ .byte = operand_20, .state = operand_22, });
                        }, .{ .lane_0 = .{ .buffer = (&state_capacity_10), .started = (&state_capacity_started_11), }, .lane_1 = .{ .buffer = (&state_capacity_12), .started = (&state_capacity_started_13), }, .lane_2 = .{ .buffer = (&state_capacity_14), .started = (&state_capacity_started_15), }, }));
                    });

                    break :block_29 block_19: {
                        const operand_16 = (state_1).source;
                        const operand_17 = ((state_1).index + @as(u64, 1));
                        const operand_18 = value_7;

                        break :block_19 @as(value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512, value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = operand_17, .result = operand_18, .source = operand_16, });
                    };
                };

                state_changed_9 = true;
            }

            var state_owned_30: []const *const zx_type_17 = (&[_]*const zx_type_17{});

            errdefer (allocator).free(state_owned_30);

            if (state_capacity_started_11) {
                ((state_capacity_10).items).len = (((state_1).result).comments).len;

                state_owned_30 = (try (state_capacity_10).toOwnedSlice(allocator));
            }

            if (state_capacity_started_11) {
                state_1 = value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = (state_1).index, .result = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((state_1).result).ahead_one, .ahead_two = ((state_1).result).ahead_two, .braces = ((state_1).result).braces, .comments = state_owned_30, .depth = ((state_1).result).depth, .diagnostic = ((state_1).result).diagnostic, .dollar = ((state_1).result).dollar, .frames = ((state_1).result).frames, .keyword_state = ((state_1).result).keyword_state, .line_break = ((state_1).result).line_break, .mode = ((state_1).result).mode, .number = ((state_1).result).number, .offset = ((state_1).result).offset, .skip_until = ((state_1).result).skip_until, .source_length = ((state_1).result).source_length, .start = ((state_1).result).start, .symbol = ((state_1).result).symbol, .tokens = ((state_1).result).tokens, .warmed = ((state_1).result).warmed, }), .source = (state_1).source, };
            }

            var state_owned_31: []const *const zx_type_24 = (&[_]*const zx_type_24{});

            errdefer (allocator).free(state_owned_31);

            if (state_capacity_started_13) {
                ((state_capacity_12).items).len = (((state_1).result).frames).len;

                state_owned_31 = (try (state_capacity_12).toOwnedSlice(allocator));
            }

            if (state_capacity_started_13) {
                state_1 = value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = (state_1).index, .result = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((state_1).result).ahead_one, .ahead_two = ((state_1).result).ahead_two, .braces = ((state_1).result).braces, .comments = ((state_1).result).comments, .depth = ((state_1).result).depth, .diagnostic = ((state_1).result).diagnostic, .dollar = ((state_1).result).dollar, .frames = state_owned_31, .keyword_state = ((state_1).result).keyword_state, .line_break = ((state_1).result).line_break, .mode = ((state_1).result).mode, .number = ((state_1).result).number, .offset = ((state_1).result).offset, .skip_until = ((state_1).result).skip_until, .source_length = ((state_1).result).source_length, .start = ((state_1).result).start, .symbol = ((state_1).result).symbol, .tokens = ((state_1).result).tokens, .warmed = ((state_1).result).warmed, }), .source = (state_1).source, };
            }

            var state_owned_32: []const *const zx_type_18 = (&[_]*const zx_type_18{});

            errdefer (allocator).free(state_owned_32);

            if (state_capacity_started_15) {
                ((state_capacity_14).items).len = (((state_1).result).tokens).len;

                state_owned_32 = (try (state_capacity_14).toOwnedSlice(allocator));
            }

            if (state_capacity_started_15) {
                state_1 = value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = (state_1).index, .result = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((state_1).result).ahead_one, .ahead_two = ((state_1).result).ahead_two, .braces = ((state_1).result).braces, .comments = ((state_1).result).comments, .depth = ((state_1).result).depth, .diagnostic = ((state_1).result).diagnostic, .dollar = ((state_1).result).dollar, .frames = ((state_1).result).frames, .keyword_state = ((state_1).result).keyword_state, .line_break = ((state_1).result).line_break, .mode = ((state_1).result).mode, .number = ((state_1).result).number, .offset = ((state_1).result).offset, .skip_until = ((state_1).result).skip_until, .source_length = ((state_1).result).source_length, .start = ((state_1).result).start, .symbol = ((state_1).result).symbol, .tokens = state_owned_32, .warmed = ((state_1).result).warmed, }), .source = (state_1).source, };
            }

            break :block_42 (if (state_changed_9) block_41: {
                break :block_41 (if (((state_1).zx_origin != null)) (state_1).zx_origin.? else block_40: {
                    const operand_39 = (try (allocator).create(zx_type_45));

                    (operand_39).* = zx_type_45{ .index = (state_1).index, .result = (if ((((state_1).result).zx_origin != null)) ((state_1).result).zx_origin.? else block_38: {
                        const operand_37 = (try (allocator).create(zx_type_28));

                        (operand_37).* = zx_type_28{ .ahead_one = ((state_1).result).ahead_one, .ahead_two = ((state_1).result).ahead_two, .braces = ((state_1).result).braces, .comments = ((state_1).result).comments, .depth = ((state_1).result).depth, .diagnostic = (if (((((state_1).result).diagnostic).zx_origin != null)) (((state_1).result).diagnostic).zx_origin.? else block_34: {
                            const operand_33 = (try (allocator).create(zx_type_23));

                            (operand_33).* = zx_type_23{ .code = (((state_1).result).diagnostic).code, .end = (((state_1).result).diagnostic).end, .message = (((state_1).result).diagnostic).message, .start = (((state_1).result).diagnostic).start, };

                            break :block_34 @as(*const zx_type_23, operand_33);
                        }), .dollar = ((state_1).result).dollar, .frames = ((state_1).result).frames, .keyword_state = ((state_1).result).keyword_state, .line_break = ((state_1).result).line_break, .mode = ((state_1).result).mode, .number = (if (((((state_1).result).number).zx_origin != null)) (((state_1).result).number).zx_origin.? else block_36: {
                            const operand_35 = (try (allocator).create(zx_type_20));

                            (operand_35).* = zx_type_20{ .end = (((state_1).result).number).end, .last_byte = (((state_1).result).number).last_byte, .phase = (((state_1).result).number).phase, .separators_valid = (((state_1).result).number).separators_valid, };

                            break :block_36 @as(*const zx_type_20, operand_35);
                        }), .offset = ((state_1).result).offset, .skip_until = ((state_1).result).skip_until, .source_length = ((state_1).result).source_length, .start = ((state_1).result).start, .symbol = ((state_1).result).symbol, .tokens = ((state_1).result).tokens, .warmed = ((state_1).result).warmed, };

                        break :block_38 @as(*const zx_type_28, operand_37);
                    }), .source = (state_1).source, };

                    break :block_40 @as(*const zx_type_45, operand_39);
                });
            } else operand_8);
        };

        break :block_43 (value_8).result;
    };
}

fn function_51_value(allocator: ((std).mem).Allocator, in: value_zx_type_38_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    return block_77: {
        const value_3: []const u8 = (in).source;
        const value_8: value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512 = block_76: {
            const operand_50 = block_49: {
                const operand_45 = block_46: {
                    break :block_46 value_3;
                };
                const operand_47 = @as(u64, 0);
                const operand_48 = (in).state;

                break :block_49 @as(value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512, value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = operand_47, .result = operand_48, .source = operand_45, });
            };

            var state_capacity_52: (std).ArrayList(*const zx_type_17) = .empty;

            var state_capacity_started_53 = false;

            defer (state_capacity_52).deinit(allocator);

            var state_capacity_54: (std).ArrayList(*const zx_type_24) = .empty;

            var state_capacity_started_55 = false;

            defer (state_capacity_54).deinit(allocator);

            var state_capacity_56: (std).ArrayList(*const zx_type_18) = .empty;

            var state_capacity_started_57 = false;

            defer (state_capacity_56).deinit(allocator);

            var state_44: value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512 = operand_50;

            var state_changed_51 = false;

            while (((state_44).index < @as(u64, ((state_44).source).len))) {
                state_44 = block_71: {
                    const value_6: u8 = block_70: {
                        const operand_68 = (state_44).source;
                        const operand_69 = (state_44).index;

                        if ((operand_69 >= (operand_68).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_70 (operand_68)[@intCast(operand_69)];
                    };
                    const value_1: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = (state_44).result;
                    const value_2: u8 = block_67: {
                        break :block_67 value_6;
                    };
                    const value_7: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_66: {
                        break :block_66 (try function_50_buffered(allocator, block_65: {
                            const operand_62 = block_63: {
                                break :block_63 value_2;
                            };
                            const operand_64 = value_1;

                            break :block_65 @as(value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b, value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b{ .byte = operand_62, .state = operand_64, });
                        }, .{ .lane_0 = .{ .buffer = (&state_capacity_52), .started = (&state_capacity_started_53), }, .lane_1 = .{ .buffer = (&state_capacity_54), .started = (&state_capacity_started_55), }, .lane_2 = .{ .buffer = (&state_capacity_56), .started = (&state_capacity_started_57), }, }));
                    });

                    break :block_71 block_61: {
                        const operand_58 = (state_44).source;
                        const operand_59 = ((state_44).index + @as(u64, 1));
                        const operand_60 = value_7;

                        break :block_61 @as(value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512, value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = operand_59, .result = operand_60, .source = operand_58, });
                    };
                };

                state_changed_51 = true;
            }

            var state_owned_72: []const *const zx_type_17 = (&[_]*const zx_type_17{});

            errdefer (allocator).free(state_owned_72);

            if (state_capacity_started_53) {
                ((state_capacity_52).items).len = (((state_44).result).comments).len;

                state_owned_72 = (try (state_capacity_52).toOwnedSlice(allocator));
            }

            if (state_capacity_started_53) {
                state_44 = value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = (state_44).index, .result = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((state_44).result).ahead_one, .ahead_two = ((state_44).result).ahead_two, .braces = ((state_44).result).braces, .comments = state_owned_72, .depth = ((state_44).result).depth, .diagnostic = ((state_44).result).diagnostic, .dollar = ((state_44).result).dollar, .frames = ((state_44).result).frames, .keyword_state = ((state_44).result).keyword_state, .line_break = ((state_44).result).line_break, .mode = ((state_44).result).mode, .number = ((state_44).result).number, .offset = ((state_44).result).offset, .skip_until = ((state_44).result).skip_until, .source_length = ((state_44).result).source_length, .start = ((state_44).result).start, .symbol = ((state_44).result).symbol, .tokens = ((state_44).result).tokens, .warmed = ((state_44).result).warmed, }), .source = (state_44).source, };
            }

            var state_owned_73: []const *const zx_type_24 = (&[_]*const zx_type_24{});

            errdefer (allocator).free(state_owned_73);

            if (state_capacity_started_55) {
                ((state_capacity_54).items).len = (((state_44).result).frames).len;

                state_owned_73 = (try (state_capacity_54).toOwnedSlice(allocator));
            }

            if (state_capacity_started_55) {
                state_44 = value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = (state_44).index, .result = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((state_44).result).ahead_one, .ahead_two = ((state_44).result).ahead_two, .braces = ((state_44).result).braces, .comments = ((state_44).result).comments, .depth = ((state_44).result).depth, .diagnostic = ((state_44).result).diagnostic, .dollar = ((state_44).result).dollar, .frames = state_owned_73, .keyword_state = ((state_44).result).keyword_state, .line_break = ((state_44).result).line_break, .mode = ((state_44).result).mode, .number = ((state_44).result).number, .offset = ((state_44).result).offset, .skip_until = ((state_44).result).skip_until, .source_length = ((state_44).result).source_length, .start = ((state_44).result).start, .symbol = ((state_44).result).symbol, .tokens = ((state_44).result).tokens, .warmed = ((state_44).result).warmed, }), .source = (state_44).source, };
            }

            var state_owned_74: []const *const zx_type_18 = (&[_]*const zx_type_18{});

            errdefer (allocator).free(state_owned_74);

            if (state_capacity_started_57) {
                ((state_capacity_56).items).len = (((state_44).result).tokens).len;

                state_owned_74 = (try (state_capacity_56).toOwnedSlice(allocator));
            }

            if (state_capacity_started_57) {
                state_44 = value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = (state_44).index, .result = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((state_44).result).ahead_one, .ahead_two = ((state_44).result).ahead_two, .braces = ((state_44).result).braces, .comments = ((state_44).result).comments, .depth = ((state_44).result).depth, .diagnostic = ((state_44).result).diagnostic, .dollar = ((state_44).result).dollar, .frames = ((state_44).result).frames, .keyword_state = ((state_44).result).keyword_state, .line_break = ((state_44).result).line_break, .mode = ((state_44).result).mode, .number = ((state_44).result).number, .offset = ((state_44).result).offset, .skip_until = ((state_44).result).skip_until, .source_length = ((state_44).result).source_length, .start = ((state_44).result).start, .symbol = ((state_44).result).symbol, .tokens = state_owned_74, .warmed = ((state_44).result).warmed, }), .source = (state_44).source, };
            }

            break :block_76 (if (state_changed_51) state_44 else operand_50);
        };

        break :block_77 (value_8).result;
    };
}

fn function_51_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_38_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    return block_102: {
        const value_3: []const u8 = (in).source;
        const value_8: value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512 = block_101: {
            const operand_84 = block_83: {
                const operand_79 = block_80: {
                    break :block_80 value_3;
                };
                const operand_81 = @as(u64, 0);
                const operand_82 = (in).state;

                break :block_83 @as(value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512, value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = operand_81, .result = operand_82, .source = operand_79, });
            };

            var state_78: value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512 = operand_84;

            var state_changed_85 = false;

            while (((state_78).index < @as(u64, ((state_78).source).len))) {
                state_78 = block_99: {
                    const value_6: u8 = block_98: {
                        const operand_96 = (state_78).source;
                        const operand_97 = (state_78).index;

                        if ((operand_97 >= (operand_96).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_98 (operand_96)[@intCast(operand_97)];
                    };
                    const value_1: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = (state_78).result;
                    const value_2: u8 = block_95: {
                        break :block_95 value_6;
                    };
                    const value_7: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_94: {
                        break :block_94 (try function_50_buffered(allocator, block_93: {
                            const operand_90 = block_91: {
                                break :block_91 value_2;
                            };
                            const operand_92 = value_1;

                            break :block_93 @as(value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b, value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b{ .byte = operand_90, .state = operand_92, });
                        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
                    });

                    break :block_99 block_89: {
                        const operand_86 = (state_78).source;
                        const operand_87 = ((state_78).index + @as(u64, 1));
                        const operand_88 = value_7;

                        break :block_89 @as(value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512, value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = operand_87, .result = operand_88, .source = operand_86, });
                    };
                };

                state_changed_85 = true;
            }

            break :block_101 (if (state_changed_85) state_78 else operand_84);
        };

        break :block_102 (value_8).result;
    };
}

fn function_51_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_38, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    return block_136: {
        const value_3: []const u8 = (in).source;
        const value_8: *const zx_type_45 = block_135: {
            const operand_110 = block_109: {
                const operand_104 = value_3;
                const operand_105 = @as(u64, 0);
                const operand_106 = (in).state;

                break :block_109 block_108: {
                    const operand_107 = (try (allocator).create(zx_type_45));

                    (operand_107).* = @as(zx_type_45, zx_type_45{ .index = operand_105, .result = operand_106, .source = operand_104, });

                    break :block_108 @as(*const zx_type_45, operand_107);
                };
            };

            var state_103: value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512 = value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = (operand_110).index, .result = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_110).result).ahead_one, .ahead_two = ((operand_110).result).ahead_two, .braces = ((operand_110).result).braces, .comments = ((operand_110).result).comments, .depth = ((operand_110).result).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_110).result).diagnostic).code, .end = (((operand_110).result).diagnostic).end, .message = (((operand_110).result).diagnostic).message, .start = (((operand_110).result).diagnostic).start, .zx_origin = ((operand_110).result).diagnostic, }, .dollar = ((operand_110).result).dollar, .frames = ((operand_110).result).frames, .keyword_state = ((operand_110).result).keyword_state, .line_break = ((operand_110).result).line_break, .mode = ((operand_110).result).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_110).result).number).end, .last_byte = (((operand_110).result).number).last_byte, .phase = (((operand_110).result).number).phase, .separators_valid = (((operand_110).result).number).separators_valid, .zx_origin = ((operand_110).result).number, }, .offset = ((operand_110).result).offset, .skip_until = ((operand_110).result).skip_until, .source_length = ((operand_110).result).source_length, .start = ((operand_110).result).start, .symbol = ((operand_110).result).symbol, .tokens = ((operand_110).result).tokens, .warmed = ((operand_110).result).warmed, .zx_origin = (operand_110).result, }, .source = (operand_110).source, .zx_origin = operand_110, };

            var state_changed_111 = false;

            while (((state_103).index < @as(u64, ((state_103).source).len))) {
                state_103 = block_125: {
                    const value_6: u8 = block_124: {
                        const operand_122 = (state_103).source;
                        const operand_123 = (state_103).index;

                        if ((operand_123 >= (operand_122).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_124 (operand_122)[@intCast(operand_123)];
                    };
                    const value_1: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = (state_103).result;
                    const value_2: u8 = block_121: {
                        break :block_121 value_6;
                    };
                    const value_7: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_120: {
                        break :block_120 (try function_50_buffered(allocator, block_119: {
                            const operand_116 = block_117: {
                                break :block_117 value_2;
                            };
                            const operand_118 = value_1;

                            break :block_119 @as(value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b, value_zx_type_37_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b{ .byte = operand_116, .state = operand_118, });
                        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
                    });

                    break :block_125 block_115: {
                        const operand_112 = (state_103).source;
                        const operand_113 = ((state_103).index + @as(u64, 1));
                        const operand_114 = value_7;

                        break :block_115 @as(value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512, value_zx_type_45_640e11a3f89a31a9f656ef50e9767d6e5c9639e52a82bfcd43a0df002e883512{ .index = operand_113, .result = operand_114, .source = operand_112, });
                    };
                };

                state_changed_111 = true;
            }

            break :block_135 (if (state_changed_111) block_134: {
                break :block_134 (if (((state_103).zx_origin != null)) (state_103).zx_origin.? else block_133: {
                    const operand_132 = (try (allocator).create(zx_type_45));

                    (operand_132).* = zx_type_45{ .index = (state_103).index, .result = (if ((((state_103).result).zx_origin != null)) ((state_103).result).zx_origin.? else block_131: {
                        const operand_130 = (try (allocator).create(zx_type_28));

                        (operand_130).* = zx_type_28{ .ahead_one = ((state_103).result).ahead_one, .ahead_two = ((state_103).result).ahead_two, .braces = ((state_103).result).braces, .comments = ((state_103).result).comments, .depth = ((state_103).result).depth, .diagnostic = (if (((((state_103).result).diagnostic).zx_origin != null)) (((state_103).result).diagnostic).zx_origin.? else block_127: {
                            const operand_126 = (try (allocator).create(zx_type_23));

                            (operand_126).* = zx_type_23{ .code = (((state_103).result).diagnostic).code, .end = (((state_103).result).diagnostic).end, .message = (((state_103).result).diagnostic).message, .start = (((state_103).result).diagnostic).start, };

                            break :block_127 @as(*const zx_type_23, operand_126);
                        }), .dollar = ((state_103).result).dollar, .frames = ((state_103).result).frames, .keyword_state = ((state_103).result).keyword_state, .line_break = ((state_103).result).line_break, .mode = ((state_103).result).mode, .number = (if (((((state_103).result).number).zx_origin != null)) (((state_103).result).number).zx_origin.? else block_129: {
                            const operand_128 = (try (allocator).create(zx_type_20));

                            (operand_128).* = zx_type_20{ .end = (((state_103).result).number).end, .last_byte = (((state_103).result).number).last_byte, .phase = (((state_103).result).number).phase, .separators_valid = (((state_103).result).number).separators_valid, };

                            break :block_129 @as(*const zx_type_20, operand_128);
                        }), .offset = ((state_103).result).offset, .skip_until = ((state_103).result).skip_until, .source_length = ((state_103).result).source_length, .start = ((state_103).result).start, .symbol = ((state_103).result).symbol, .tokens = ((state_103).result).tokens, .warmed = ((state_103).result).warmed, };

                        break :block_131 @as(*const zx_type_28, operand_130);
                    }), .source = (state_103).source, };

                    break :block_133 @as(*const zx_type_45, operand_132);
                });
            } else operand_110);
        };

        break :block_136 (value_8).result;
    };
}

fn function_52(allocator: ((std).mem).Allocator, in: *const zx_type_28) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if (((!block_52: {
        const operand_50 = ((in).diagnostic).message;
        const operand_51 = @as([]const u8, "");

        break :block_52 ((std).mem).eql(u8, operand_50, operand_51);
    }) or ((in).warmed == @as(u8, 0)))) {
        return in;
    }

    const value_1: u8 = (in).warmed;
    const value_2: u8 = (in).ahead_two;
    const value_3: *const zx_type_28 = block_49: {
        const operand_41 = block_40: {
            const operand_32 = (in).ahead_one;
            const operand_33 = (in).ahead_two;
            const operand_34 = @as(u8, 0);
            const operand_35 = ((in).warmed == @as(u8, 2));
            const operand_36 = false;
            const operand_37 = in;

            break :block_40 block_39: {
                const operand_38 = (try (allocator).create(zx_type_29));

                (operand_38).* = @as(zx_type_29, zx_type_29{ .byte = operand_32, .next = operand_33, .after = operand_34, .has_next = operand_35, .has_after = operand_36, .state = operand_37, });

                break :block_39 @as(*const zx_type_29, operand_38);
            };
        };
        const operand_42 = (try function_49_value(allocator, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .after = (operand_41).after, .byte = (operand_41).byte, .has_after = (operand_41).has_after, .has_next = (operand_41).has_next, .next = (operand_41).next, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_41).state).ahead_one, .ahead_two = ((operand_41).state).ahead_two, .braces = ((operand_41).state).braces, .comments = ((operand_41).state).comments, .depth = ((operand_41).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_41).state).diagnostic).code, .end = (((operand_41).state).diagnostic).end, .message = (((operand_41).state).diagnostic).message, .start = (((operand_41).state).diagnostic).start, .zx_origin = ((operand_41).state).diagnostic, }, .dollar = ((operand_41).state).dollar, .frames = ((operand_41).state).frames, .keyword_state = ((operand_41).state).keyword_state, .line_break = ((operand_41).state).line_break, .mode = ((operand_41).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_41).state).number).end, .last_byte = (((operand_41).state).number).last_byte, .phase = (((operand_41).state).number).phase, .separators_valid = (((operand_41).state).number).separators_valid, .zx_origin = ((operand_41).state).number, }, .offset = ((operand_41).state).offset, .skip_until = ((operand_41).state).skip_until, .source_length = ((operand_41).state).source_length, .start = ((operand_41).state).start, .symbol = ((operand_41).state).symbol, .tokens = ((operand_41).state).tokens, .warmed = ((operand_41).state).warmed, .zx_origin = (operand_41).state, }, .zx_origin = operand_41, }));

        break :block_49 (if (((operand_42).zx_origin != null)) (operand_42).zx_origin.? else block_48: {
            const operand_47 = (try (allocator).create(zx_type_28));

            (operand_47).* = zx_type_28{ .ahead_one = (operand_42).ahead_one, .ahead_two = (operand_42).ahead_two, .braces = (operand_42).braces, .comments = (operand_42).comments, .depth = (operand_42).depth, .diagnostic = (if ((((operand_42).diagnostic).zx_origin != null)) ((operand_42).diagnostic).zx_origin.? else block_44: {
                const operand_43 = (try (allocator).create(zx_type_23));

                (operand_43).* = zx_type_23{ .code = ((operand_42).diagnostic).code, .end = ((operand_42).diagnostic).end, .message = ((operand_42).diagnostic).message, .start = ((operand_42).diagnostic).start, };

                break :block_44 @as(*const zx_type_23, operand_43);
            }), .dollar = (operand_42).dollar, .frames = (operand_42).frames, .keyword_state = (operand_42).keyword_state, .line_break = (operand_42).line_break, .mode = (operand_42).mode, .number = (if ((((operand_42).number).zx_origin != null)) ((operand_42).number).zx_origin.? else block_46: {
                const operand_45 = (try (allocator).create(zx_type_20));

                (operand_45).* = zx_type_20{ .end = ((operand_42).number).end, .last_byte = ((operand_42).number).last_byte, .phase = ((operand_42).number).phase, .separators_valid = ((operand_42).number).separators_valid, };

                break :block_46 @as(*const zx_type_20, operand_45);
            }), .offset = (operand_42).offset, .skip_until = (operand_42).skip_until, .source_length = (operand_42).source_length, .start = (operand_42).start, .symbol = (operand_42).symbol, .tokens = (operand_42).tokens, .warmed = (operand_42).warmed, };

            break :block_48 @as(*const zx_type_28, operand_47);
        });
    };
    const value_4: u64 = ((value_3).offset + @as(u64, 1));
    const value_5: *const zx_type_28 = block_31: {
        const operand_27 = value_3;
        const operand_28 = value_4;

        break :block_31 block_30: {
            const operand_29 = (try (allocator).create(zx_type_28));

            (operand_29).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_27).ahead_one, .ahead_two = (operand_27).ahead_two, .braces = (operand_27).braces, .comments = (operand_27).comments, .depth = (operand_27).depth, .diagnostic = (operand_27).diagnostic, .dollar = (operand_27).dollar, .frames = (operand_27).frames, .keyword_state = (operand_27).keyword_state, .line_break = (operand_27).line_break, .mode = (operand_27).mode, .number = (operand_27).number, .offset = operand_28, .skip_until = (operand_27).skip_until, .source_length = (operand_27).source_length, .start = (operand_27).start, .symbol = (operand_27).symbol, .tokens = (operand_27).tokens, .warmed = (operand_27).warmed, });

            break :block_30 @as(*const zx_type_28, operand_29);
        };
    };

    if (((value_1 == @as(u8, 1)) or (!block_26: {
        const operand_24 = ((value_5).diagnostic).message;
        const operand_25 = @as([]const u8, "");

        break :block_26 ((std).mem).eql(u8, operand_24, operand_25);
    }))) {
        return value_5;
    }

    const value_6: *const zx_type_28 = block_23: {
        const operand_15 = block_14: {
            const operand_6 = value_2;
            const operand_7 = @as(u8, 0);
            const operand_8 = @as(u8, 0);
            const operand_9 = false;
            const operand_10 = false;
            const operand_11 = value_5;

            break :block_14 block_13: {
                const operand_12 = (try (allocator).create(zx_type_29));

                (operand_12).* = @as(zx_type_29, zx_type_29{ .byte = operand_6, .next = operand_7, .after = operand_8, .has_next = operand_9, .has_after = operand_10, .state = operand_11, });

                break :block_13 @as(*const zx_type_29, operand_12);
            };
        };
        const operand_16 = (try function_49_value(allocator, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .after = (operand_15).after, .byte = (operand_15).byte, .has_after = (operand_15).has_after, .has_next = (operand_15).has_next, .next = (operand_15).next, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_15).state).ahead_one, .ahead_two = ((operand_15).state).ahead_two, .braces = ((operand_15).state).braces, .comments = ((operand_15).state).comments, .depth = ((operand_15).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_15).state).diagnostic).code, .end = (((operand_15).state).diagnostic).end, .message = (((operand_15).state).diagnostic).message, .start = (((operand_15).state).diagnostic).start, .zx_origin = ((operand_15).state).diagnostic, }, .dollar = ((operand_15).state).dollar, .frames = ((operand_15).state).frames, .keyword_state = ((operand_15).state).keyword_state, .line_break = ((operand_15).state).line_break, .mode = ((operand_15).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_15).state).number).end, .last_byte = (((operand_15).state).number).last_byte, .phase = (((operand_15).state).number).phase, .separators_valid = (((operand_15).state).number).separators_valid, .zx_origin = ((operand_15).state).number, }, .offset = ((operand_15).state).offset, .skip_until = ((operand_15).state).skip_until, .source_length = ((operand_15).state).source_length, .start = ((operand_15).state).start, .symbol = ((operand_15).state).symbol, .tokens = ((operand_15).state).tokens, .warmed = ((operand_15).state).warmed, .zx_origin = (operand_15).state, }, .zx_origin = operand_15, }));

        break :block_23 (if (((operand_16).zx_origin != null)) (operand_16).zx_origin.? else block_22: {
            const operand_21 = (try (allocator).create(zx_type_28));

            (operand_21).* = zx_type_28{ .ahead_one = (operand_16).ahead_one, .ahead_two = (operand_16).ahead_two, .braces = (operand_16).braces, .comments = (operand_16).comments, .depth = (operand_16).depth, .diagnostic = (if ((((operand_16).diagnostic).zx_origin != null)) ((operand_16).diagnostic).zx_origin.? else block_18: {
                const operand_17 = (try (allocator).create(zx_type_23));

                (operand_17).* = zx_type_23{ .code = ((operand_16).diagnostic).code, .end = ((operand_16).diagnostic).end, .message = ((operand_16).diagnostic).message, .start = ((operand_16).diagnostic).start, };

                break :block_18 @as(*const zx_type_23, operand_17);
            }), .dollar = (operand_16).dollar, .frames = (operand_16).frames, .keyword_state = (operand_16).keyword_state, .line_break = (operand_16).line_break, .mode = (operand_16).mode, .number = (if ((((operand_16).number).zx_origin != null)) ((operand_16).number).zx_origin.? else block_20: {
                const operand_19 = (try (allocator).create(zx_type_20));

                (operand_19).* = zx_type_20{ .end = ((operand_16).number).end, .last_byte = ((operand_16).number).last_byte, .phase = ((operand_16).number).phase, .separators_valid = ((operand_16).number).separators_valid, };

                break :block_20 @as(*const zx_type_20, operand_19);
            }), .offset = (operand_16).offset, .skip_until = (operand_16).skip_until, .source_length = (operand_16).source_length, .start = (operand_16).start, .symbol = (operand_16).symbol, .tokens = (operand_16).tokens, .warmed = (operand_16).warmed, };

            break :block_22 @as(*const zx_type_28, operand_21);
        });
    };
    const value_7: u64 = ((value_6).offset + @as(u64, 1));

    return block_5: {
        const operand_1 = value_6;
        const operand_2 = value_7;

        break :block_5 block_4: {
            const operand_3 = (try (allocator).create(zx_type_28));

            (operand_3).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_1).ahead_one, .ahead_two = (operand_1).ahead_two, .braces = (operand_1).braces, .comments = (operand_1).comments, .depth = (operand_1).depth, .diagnostic = (operand_1).diagnostic, .dollar = (operand_1).dollar, .frames = (operand_1).frames, .keyword_state = (operand_1).keyword_state, .line_break = (operand_1).line_break, .mode = (operand_1).mode, .number = (operand_1).number, .offset = operand_2, .skip_until = (operand_1).skip_until, .source_length = (operand_1).source_length, .start = (operand_1).start, .symbol = (operand_1).symbol, .tokens = (operand_1).tokens, .warmed = (operand_1).warmed, });

            break :block_4 @as(*const zx_type_28, operand_3);
        };
    };
}

fn function_52_value(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if (((!block_84: {
        const operand_82 = ((in).diagnostic).message;
        const operand_83 = @as([]const u8, "");

        break :block_84 ((std).mem).eql(u8, operand_82, operand_83);
    }) or ((in).warmed == @as(u8, 0)))) {
        return in;
    }

    const value_1: u8 = (in).warmed;
    const value_2: u8 = (in).ahead_two;
    const value_3: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_81: {
        break :block_81 (try function_49_value(allocator, block_80: {
            const operand_74 = (in).ahead_one;
            const operand_75 = (in).ahead_two;
            const operand_76 = @as(u8, 0);
            const operand_77 = ((in).warmed == @as(u8, 2));
            const operand_78 = false;
            const operand_79 = in;

            break :block_80 @as(value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .byte = operand_74, .next = operand_75, .after = operand_76, .has_next = operand_77, .has_after = operand_78, .state = operand_79, });
        }));
    };
    const value_4: u64 = ((value_3).offset + @as(u64, 1));
    const value_5: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_73: {
        const operand_70 = value_3;
        const operand_71 = block_72: {
            break :block_72 value_4;
        };

        break :block_73 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_70).ahead_one, .ahead_two = (operand_70).ahead_two, .braces = (operand_70).braces, .comments = (operand_70).comments, .depth = (operand_70).depth, .diagnostic = (operand_70).diagnostic, .dollar = (operand_70).dollar, .frames = (operand_70).frames, .keyword_state = (operand_70).keyword_state, .line_break = (operand_70).line_break, .mode = (operand_70).mode, .number = (operand_70).number, .offset = operand_71, .skip_until = (operand_70).skip_until, .source_length = (operand_70).source_length, .start = (operand_70).start, .symbol = (operand_70).symbol, .tokens = (operand_70).tokens, .warmed = (operand_70).warmed, });
    };

    if (((block_66: {
        break :block_66 value_1;
    } == @as(u8, 1)) or (!block_69: {
        const operand_67 = ((value_5).diagnostic).message;
        const operand_68 = @as([]const u8, "");

        break :block_69 ((std).mem).eql(u8, operand_67, operand_68);
    }))) {
        return value_5;
    }

    const value_6: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_65: {
        break :block_65 (try function_49_value(allocator, block_64: {
            const operand_57 = block_58: {
                break :block_58 value_2;
            };
            const operand_59 = @as(u8, 0);
            const operand_60 = @as(u8, 0);
            const operand_61 = false;
            const operand_62 = false;
            const operand_63 = value_5;

            break :block_64 @as(value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .byte = operand_57, .next = operand_59, .after = operand_60, .has_next = operand_61, .has_after = operand_62, .state = operand_63, });
        }));
    };
    const value_7: u64 = ((value_6).offset + @as(u64, 1));

    return block_56: {
        const operand_53 = value_6;
        const operand_54 = block_55: {
            break :block_55 value_7;
        };

        break :block_56 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_53).ahead_one, .ahead_two = (operand_53).ahead_two, .braces = (operand_53).braces, .comments = (operand_53).comments, .depth = (operand_53).depth, .diagnostic = (operand_53).diagnostic, .dollar = (operand_53).dollar, .frames = (operand_53).frames, .keyword_state = (operand_53).keyword_state, .line_break = (operand_53).line_break, .mode = (operand_53).mode, .number = (operand_53).number, .offset = operand_54, .skip_until = (operand_53).skip_until, .source_length = (operand_53).source_length, .start = (operand_53).start, .symbol = (operand_53).symbol, .tokens = (operand_53).tokens, .warmed = (operand_53).warmed, });
    };
}

fn function_52_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if (((!block_116: {
        const operand_114 = ((in).diagnostic).message;
        const operand_115 = @as([]const u8, "");

        break :block_116 ((std).mem).eql(u8, operand_114, operand_115);
    }) or ((in).warmed == @as(u8, 0)))) {
        return in;
    }

    const value_1: u8 = (in).warmed;
    const value_2: u8 = (in).ahead_two;
    const value_3: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_113: {
        break :block_113 (try function_49_buffered(allocator, block_112: {
            const operand_106 = (in).ahead_one;
            const operand_107 = (in).ahead_two;
            const operand_108 = @as(u8, 0);
            const operand_109 = ((in).warmed == @as(u8, 2));
            const operand_110 = false;
            const operand_111 = in;

            break :block_112 @as(value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .byte = operand_106, .next = operand_107, .after = operand_108, .has_next = operand_109, .has_after = operand_110, .state = operand_111, });
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    });
    const value_4: u64 = ((value_3).offset + @as(u64, 1));
    const value_5: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_105: {
        const operand_102 = value_3;
        const operand_103 = block_104: {
            break :block_104 value_4;
        };

        break :block_105 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_102).ahead_one, .ahead_two = (operand_102).ahead_two, .braces = (operand_102).braces, .comments = (operand_102).comments, .depth = (operand_102).depth, .diagnostic = (operand_102).diagnostic, .dollar = (operand_102).dollar, .frames = (operand_102).frames, .keyword_state = (operand_102).keyword_state, .line_break = (operand_102).line_break, .mode = (operand_102).mode, .number = (operand_102).number, .offset = operand_103, .skip_until = (operand_102).skip_until, .source_length = (operand_102).source_length, .start = (operand_102).start, .symbol = (operand_102).symbol, .tokens = (operand_102).tokens, .warmed = (operand_102).warmed, });
    };

    if (((block_98: {
        break :block_98 value_1;
    } == @as(u8, 1)) or (!block_101: {
        const operand_99 = ((value_5).diagnostic).message;
        const operand_100 = @as([]const u8, "");

        break :block_101 ((std).mem).eql(u8, operand_99, operand_100);
    }))) {
        return value_5;
    }

    const value_6: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_97: {
        break :block_97 (try function_49_buffered(allocator, block_96: {
            const operand_89 = block_90: {
                break :block_90 value_2;
            };
            const operand_91 = @as(u8, 0);
            const operand_92 = @as(u8, 0);
            const operand_93 = false;
            const operand_94 = false;
            const operand_95 = value_5;

            break :block_96 @as(value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c, value_zx_type_29_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c{ .byte = operand_89, .next = operand_91, .after = operand_92, .has_next = operand_93, .has_after = operand_94, .state = operand_95, });
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    });
    const value_7: u64 = ((value_6).offset + @as(u64, 1));

    return block_88: {
        const operand_85 = value_6;
        const operand_86 = block_87: {
            break :block_87 value_7;
        };

        break :block_88 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_85).ahead_one, .ahead_two = (operand_85).ahead_two, .braces = (operand_85).braces, .comments = (operand_85).comments, .depth = (operand_85).depth, .diagnostic = (operand_85).diagnostic, .dollar = (operand_85).dollar, .frames = (operand_85).frames, .keyword_state = (operand_85).keyword_state, .line_break = (operand_85).line_break, .mode = (operand_85).mode, .number = (operand_85).number, .offset = operand_86, .skip_until = (operand_85).skip_until, .source_length = (operand_85).source_length, .start = (operand_85).start, .symbol = (operand_85).symbol, .tokens = (operand_85).tokens, .warmed = (operand_85).warmed, });
    };
}

fn function_52_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_28, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if (((!block_150: {
        const operand_148 = ((in).diagnostic).message;
        const operand_149 = @as([]const u8, "");

        break :block_150 ((std).mem).eql(u8, operand_148, operand_149);
    }) or ((in).warmed == @as(u8, 0)))) {
        return in;
    }

    const value_1: u8 = (in).warmed;
    const value_2: u8 = (in).ahead_two;
    const value_3: *const zx_type_28 = (try function_49_buffered_pointer(allocator, block_147: {
        const operand_139 = (in).ahead_one;
        const operand_140 = (in).ahead_two;
        const operand_141 = @as(u8, 0);
        const operand_142 = ((in).warmed == @as(u8, 2));
        const operand_143 = false;
        const operand_144 = in;

        break :block_147 block_146: {
            const operand_145 = (try (allocator).create(zx_type_29));

            (operand_145).* = @as(zx_type_29, zx_type_29{ .byte = operand_139, .next = operand_140, .after = operand_141, .has_next = operand_142, .has_after = operand_143, .state = operand_144, });

            break :block_146 @as(*const zx_type_29, operand_145);
        };
    }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    const value_4: u64 = ((value_3).offset + @as(u64, 1));
    const value_5: *const zx_type_28 = block_138: {
        const operand_134 = value_3;
        const operand_135 = value_4;

        break :block_138 block_137: {
            const operand_136 = (try (allocator).create(zx_type_28));

            (operand_136).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_134).ahead_one, .ahead_two = (operand_134).ahead_two, .braces = (operand_134).braces, .comments = (operand_134).comments, .depth = (operand_134).depth, .diagnostic = (operand_134).diagnostic, .dollar = (operand_134).dollar, .frames = (operand_134).frames, .keyword_state = (operand_134).keyword_state, .line_break = (operand_134).line_break, .mode = (operand_134).mode, .number = (operand_134).number, .offset = operand_135, .skip_until = (operand_134).skip_until, .source_length = (operand_134).source_length, .start = (operand_134).start, .symbol = (operand_134).symbol, .tokens = (operand_134).tokens, .warmed = (operand_134).warmed, });

            break :block_137 @as(*const zx_type_28, operand_136);
        };
    };

    if (((value_1 == @as(u8, 1)) or (!block_133: {
        const operand_131 = ((value_5).diagnostic).message;
        const operand_132 = @as([]const u8, "");

        break :block_133 ((std).mem).eql(u8, operand_131, operand_132);
    }))) {
        return value_5;
    }

    const value_6: *const zx_type_28 = (try function_49_buffered_pointer(allocator, block_130: {
        const operand_122 = value_2;
        const operand_123 = @as(u8, 0);
        const operand_124 = @as(u8, 0);
        const operand_125 = false;
        const operand_126 = false;
        const operand_127 = value_5;

        break :block_130 block_129: {
            const operand_128 = (try (allocator).create(zx_type_29));

            (operand_128).* = @as(zx_type_29, zx_type_29{ .byte = operand_122, .next = operand_123, .after = operand_124, .has_next = operand_125, .has_after = operand_126, .state = operand_127, });

            break :block_129 @as(*const zx_type_29, operand_128);
        };
    }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    const value_7: u64 = ((value_6).offset + @as(u64, 1));

    return block_121: {
        const operand_117 = value_6;
        const operand_118 = value_7;

        break :block_121 block_120: {
            const operand_119 = (try (allocator).create(zx_type_28));

            (operand_119).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_117).ahead_one, .ahead_two = (operand_117).ahead_two, .braces = (operand_117).braces, .comments = (operand_117).comments, .depth = (operand_117).depth, .diagnostic = (operand_117).diagnostic, .dollar = (operand_117).dollar, .frames = (operand_117).frames, .keyword_state = (operand_117).keyword_state, .line_break = (operand_117).line_break, .mode = (operand_117).mode, .number = (operand_117).number, .offset = operand_118, .skip_until = (operand_117).skip_until, .source_length = (operand_117).source_length, .start = (operand_117).start, .symbol = (operand_117).symbol, .tokens = (operand_117).tokens, .warmed = (operand_117).warmed, });

            break :block_120 @as(*const zx_type_28, operand_119);
        };
    };
}

fn function_53(allocator: ((std).mem).Allocator, in: *const zx_type_28) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if (((!block_60: {
        const operand_58 = ((in).diagnostic).message;
        const operand_59 = @as([]const u8, "");

        break :block_60 ((std).mem).eql(u8, operand_58, operand_59);
    }) or ((in).mode == @as(zx_type_22, .Idle)))) {
        return in;
    }

    if (((in).mode == @as(zx_type_22, .Identifier))) {
        return block_57: {
            const operand_49 = in;
            const operand_50 = (try function_40_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_49).ahead_one, .ahead_two = (operand_49).ahead_two, .braces = (operand_49).braces, .comments = (operand_49).comments, .depth = (operand_49).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_49).diagnostic).code, .end = ((operand_49).diagnostic).end, .message = ((operand_49).diagnostic).message, .start = ((operand_49).diagnostic).start, .zx_origin = (operand_49).diagnostic, }, .dollar = (operand_49).dollar, .frames = (operand_49).frames, .keyword_state = (operand_49).keyword_state, .line_break = (operand_49).line_break, .mode = (operand_49).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_49).number).end, .last_byte = ((operand_49).number).last_byte, .phase = ((operand_49).number).phase, .separators_valid = ((operand_49).number).separators_valid, .zx_origin = (operand_49).number, }, .offset = (operand_49).offset, .skip_until = (operand_49).skip_until, .source_length = (operand_49).source_length, .start = (operand_49).start, .symbol = (operand_49).symbol, .tokens = (operand_49).tokens, .warmed = (operand_49).warmed, .zx_origin = operand_49, }));

            break :block_57 (if (((operand_50).zx_origin != null)) (operand_50).zx_origin.? else block_56: {
                const operand_55 = (try (allocator).create(zx_type_28));

                (operand_55).* = zx_type_28{ .ahead_one = (operand_50).ahead_one, .ahead_two = (operand_50).ahead_two, .braces = (operand_50).braces, .comments = (operand_50).comments, .depth = (operand_50).depth, .diagnostic = (if ((((operand_50).diagnostic).zx_origin != null)) ((operand_50).diagnostic).zx_origin.? else block_52: {
                    const operand_51 = (try (allocator).create(zx_type_23));

                    (operand_51).* = zx_type_23{ .code = ((operand_50).diagnostic).code, .end = ((operand_50).diagnostic).end, .message = ((operand_50).diagnostic).message, .start = ((operand_50).diagnostic).start, };

                    break :block_52 @as(*const zx_type_23, operand_51);
                }), .dollar = (operand_50).dollar, .frames = (operand_50).frames, .keyword_state = (operand_50).keyword_state, .line_break = (operand_50).line_break, .mode = (operand_50).mode, .number = (if ((((operand_50).number).zx_origin != null)) ((operand_50).number).zx_origin.? else block_54: {
                    const operand_53 = (try (allocator).create(zx_type_20));

                    (operand_53).* = zx_type_20{ .end = ((operand_50).number).end, .last_byte = ((operand_50).number).last_byte, .phase = ((operand_50).number).phase, .separators_valid = ((operand_50).number).separators_valid, };

                    break :block_54 @as(*const zx_type_20, operand_53);
                }), .offset = (operand_50).offset, .skip_until = (operand_50).skip_until, .source_length = (operand_50).source_length, .start = (operand_50).start, .symbol = (operand_50).symbol, .tokens = (operand_50).tokens, .warmed = (operand_50).warmed, };

                break :block_56 @as(*const zx_type_28, operand_55);
            });
        };
    }

    if (((in).mode == @as(zx_type_22, .Number))) {
        return block_48: {
            const operand_40 = in;
            const operand_41 = (try function_42_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_40).ahead_one, .ahead_two = (operand_40).ahead_two, .braces = (operand_40).braces, .comments = (operand_40).comments, .depth = (operand_40).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_40).diagnostic).code, .end = ((operand_40).diagnostic).end, .message = ((operand_40).diagnostic).message, .start = ((operand_40).diagnostic).start, .zx_origin = (operand_40).diagnostic, }, .dollar = (operand_40).dollar, .frames = (operand_40).frames, .keyword_state = (operand_40).keyword_state, .line_break = (operand_40).line_break, .mode = (operand_40).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_40).number).end, .last_byte = ((operand_40).number).last_byte, .phase = ((operand_40).number).phase, .separators_valid = ((operand_40).number).separators_valid, .zx_origin = (operand_40).number, }, .offset = (operand_40).offset, .skip_until = (operand_40).skip_until, .source_length = (operand_40).source_length, .start = (operand_40).start, .symbol = (operand_40).symbol, .tokens = (operand_40).tokens, .warmed = (operand_40).warmed, .zx_origin = operand_40, }));

            break :block_48 (if (((operand_41).zx_origin != null)) (operand_41).zx_origin.? else block_47: {
                const operand_46 = (try (allocator).create(zx_type_28));

                (operand_46).* = zx_type_28{ .ahead_one = (operand_41).ahead_one, .ahead_two = (operand_41).ahead_two, .braces = (operand_41).braces, .comments = (operand_41).comments, .depth = (operand_41).depth, .diagnostic = (if ((((operand_41).diagnostic).zx_origin != null)) ((operand_41).diagnostic).zx_origin.? else block_43: {
                    const operand_42 = (try (allocator).create(zx_type_23));

                    (operand_42).* = zx_type_23{ .code = ((operand_41).diagnostic).code, .end = ((operand_41).diagnostic).end, .message = ((operand_41).diagnostic).message, .start = ((operand_41).diagnostic).start, };

                    break :block_43 @as(*const zx_type_23, operand_42);
                }), .dollar = (operand_41).dollar, .frames = (operand_41).frames, .keyword_state = (operand_41).keyword_state, .line_break = (operand_41).line_break, .mode = (operand_41).mode, .number = (if ((((operand_41).number).zx_origin != null)) ((operand_41).number).zx_origin.? else block_45: {
                    const operand_44 = (try (allocator).create(zx_type_20));

                    (operand_44).* = zx_type_20{ .end = ((operand_41).number).end, .last_byte = ((operand_41).number).last_byte, .phase = ((operand_41).number).phase, .separators_valid = ((operand_41).number).separators_valid, };

                    break :block_45 @as(*const zx_type_20, operand_44);
                }), .offset = (operand_41).offset, .skip_until = (operand_41).skip_until, .source_length = (operand_41).source_length, .start = (operand_41).start, .symbol = (operand_41).symbol, .tokens = (operand_41).tokens, .warmed = (operand_41).warmed, };

                break :block_47 @as(*const zx_type_28, operand_46);
            });
        };
    }

    if (((in).mode == @as(zx_type_22, .LineComment))) {
        return block_39: {
            const operand_31 = block_30: {
                const operand_18 = @as([]const u8, "");
                const operand_19 = (in).start;
                const operand_20 = (in).source_length;
                const operand_21 = true;
                const operand_22 = block_27: {
                    const operand_23 = in;
                    const operand_24 = @as(zx_type_22, .Idle);

                    break :block_27 block_26: {
                        const operand_25 = (try (allocator).create(zx_type_28));

                        (operand_25).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_23).ahead_one, .ahead_two = (operand_23).ahead_two, .braces = (operand_23).braces, .comments = (operand_23).comments, .depth = (operand_23).depth, .diagnostic = (operand_23).diagnostic, .dollar = (operand_23).dollar, .frames = (operand_23).frames, .keyword_state = (operand_23).keyword_state, .line_break = (operand_23).line_break, .mode = operand_24, .number = (operand_23).number, .offset = (operand_23).offset, .skip_until = (operand_23).skip_until, .source_length = (operand_23).source_length, .start = (operand_23).start, .symbol = (operand_23).symbol, .tokens = (operand_23).tokens, .warmed = (operand_23).warmed, });

                        break :block_26 @as(*const zx_type_28, operand_25);
                    };
                };

                break :block_30 block_29: {
                    const operand_28 = (try (allocator).create(zx_type_31));

                    (operand_28).* = @as(zx_type_31, zx_type_31{ .kind = operand_18, .start = operand_19, .end = operand_20, .comment = operand_21, .state = operand_22, });

                    break :block_29 @as(*const zx_type_31, operand_28);
                };
            };
            const operand_32 = (try function_5_value(allocator, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .comment = (operand_31).comment, .end = (operand_31).end, .kind = (operand_31).kind, .start = (operand_31).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_31).state).ahead_one, .ahead_two = ((operand_31).state).ahead_two, .braces = ((operand_31).state).braces, .comments = ((operand_31).state).comments, .depth = ((operand_31).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_31).state).diagnostic).code, .end = (((operand_31).state).diagnostic).end, .message = (((operand_31).state).diagnostic).message, .start = (((operand_31).state).diagnostic).start, .zx_origin = ((operand_31).state).diagnostic, }, .dollar = ((operand_31).state).dollar, .frames = ((operand_31).state).frames, .keyword_state = ((operand_31).state).keyword_state, .line_break = ((operand_31).state).line_break, .mode = ((operand_31).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_31).state).number).end, .last_byte = (((operand_31).state).number).last_byte, .phase = (((operand_31).state).number).phase, .separators_valid = (((operand_31).state).number).separators_valid, .zx_origin = ((operand_31).state).number, }, .offset = ((operand_31).state).offset, .skip_until = ((operand_31).state).skip_until, .source_length = ((operand_31).state).source_length, .start = ((operand_31).state).start, .symbol = ((operand_31).state).symbol, .tokens = ((operand_31).state).tokens, .warmed = ((operand_31).state).warmed, .zx_origin = (operand_31).state, }, .zx_origin = operand_31, }));

            break :block_39 (if (((operand_32).zx_origin != null)) (operand_32).zx_origin.? else block_38: {
                const operand_37 = (try (allocator).create(zx_type_28));

                (operand_37).* = zx_type_28{ .ahead_one = (operand_32).ahead_one, .ahead_two = (operand_32).ahead_two, .braces = (operand_32).braces, .comments = (operand_32).comments, .depth = (operand_32).depth, .diagnostic = (if ((((operand_32).diagnostic).zx_origin != null)) ((operand_32).diagnostic).zx_origin.? else block_34: {
                    const operand_33 = (try (allocator).create(zx_type_23));

                    (operand_33).* = zx_type_23{ .code = ((operand_32).diagnostic).code, .end = ((operand_32).diagnostic).end, .message = ((operand_32).diagnostic).message, .start = ((operand_32).diagnostic).start, };

                    break :block_34 @as(*const zx_type_23, operand_33);
                }), .dollar = (operand_32).dollar, .frames = (operand_32).frames, .keyword_state = (operand_32).keyword_state, .line_break = (operand_32).line_break, .mode = (operand_32).mode, .number = (if ((((operand_32).number).zx_origin != null)) ((operand_32).number).zx_origin.? else block_36: {
                    const operand_35 = (try (allocator).create(zx_type_20));

                    (operand_35).* = zx_type_20{ .end = ((operand_32).number).end, .last_byte = ((operand_32).number).last_byte, .phase = ((operand_32).number).phase, .separators_valid = ((operand_32).number).separators_valid, };

                    break :block_36 @as(*const zx_type_20, operand_35);
                }), .offset = (operand_32).offset, .skip_until = (operand_32).skip_until, .source_length = (operand_32).source_length, .start = (operand_32).start, .symbol = (operand_32).symbol, .tokens = (operand_32).tokens, .warmed = (operand_32).warmed, };

                break :block_38 @as(*const zx_type_28, operand_37);
            });
        };
    }

    const value_1: []const u8 = (if (((in).mode == @as(zx_type_22, .BlockComment))) @as([]const u8, "unterminated block comment") else (if ((((in).mode == @as(zx_type_22, .String)) or ((in).mode == @as(zx_type_22, .StringEscape)))) @as([]const u8, "unterminated string") else (if ((((in).mode == @as(zx_type_22, .Template)) or ((in).mode == @as(zx_type_22, .TemplateEscape)))) @as([]const u8, "unterminated template string") else (if (((in).mode == @as(zx_type_22, .InterpolationBlockComment))) @as([]const u8, "unterminated comment in template") else @as([]const u8, "unterminated template interpolation")))));

    return block_17: {
        const operand_9 = block_8: {
            const operand_1 = @as([]const u8, "lexical");
            const operand_2 = (in).start;
            const operand_3 = (in).source_length;
            const operand_4 = value_1;
            const operand_5 = in;

            break :block_8 block_7: {
                const operand_6 = (try (allocator).create(zx_type_32));

                (operand_6).* = @as(zx_type_32, zx_type_32{ .code = operand_1, .start = operand_2, .end = operand_3, .message = operand_4, .state = operand_5, });

                break :block_7 @as(*const zx_type_32, operand_6);
            };
        };
        const operand_10 = (try function_6_value(allocator, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = (operand_9).code, .end = (operand_9).end, .message = (operand_9).message, .start = (operand_9).start, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_9).state).ahead_one, .ahead_two = ((operand_9).state).ahead_two, .braces = ((operand_9).state).braces, .comments = ((operand_9).state).comments, .depth = ((operand_9).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_9).state).diagnostic).code, .end = (((operand_9).state).diagnostic).end, .message = (((operand_9).state).diagnostic).message, .start = (((operand_9).state).diagnostic).start, .zx_origin = ((operand_9).state).diagnostic, }, .dollar = ((operand_9).state).dollar, .frames = ((operand_9).state).frames, .keyword_state = ((operand_9).state).keyword_state, .line_break = ((operand_9).state).line_break, .mode = ((operand_9).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_9).state).number).end, .last_byte = (((operand_9).state).number).last_byte, .phase = (((operand_9).state).number).phase, .separators_valid = (((operand_9).state).number).separators_valid, .zx_origin = ((operand_9).state).number, }, .offset = ((operand_9).state).offset, .skip_until = ((operand_9).state).skip_until, .source_length = ((operand_9).state).source_length, .start = ((operand_9).state).start, .symbol = ((operand_9).state).symbol, .tokens = ((operand_9).state).tokens, .warmed = ((operand_9).state).warmed, .zx_origin = (operand_9).state, }, .zx_origin = operand_9, }));

        break :block_17 (if (((operand_10).zx_origin != null)) (operand_10).zx_origin.? else block_16: {
            const operand_15 = (try (allocator).create(zx_type_28));

            (operand_15).* = zx_type_28{ .ahead_one = (operand_10).ahead_one, .ahead_two = (operand_10).ahead_two, .braces = (operand_10).braces, .comments = (operand_10).comments, .depth = (operand_10).depth, .diagnostic = (if ((((operand_10).diagnostic).zx_origin != null)) ((operand_10).diagnostic).zx_origin.? else block_12: {
                const operand_11 = (try (allocator).create(zx_type_23));

                (operand_11).* = zx_type_23{ .code = ((operand_10).diagnostic).code, .end = ((operand_10).diagnostic).end, .message = ((operand_10).diagnostic).message, .start = ((operand_10).diagnostic).start, };

                break :block_12 @as(*const zx_type_23, operand_11);
            }), .dollar = (operand_10).dollar, .frames = (operand_10).frames, .keyword_state = (operand_10).keyword_state, .line_break = (operand_10).line_break, .mode = (operand_10).mode, .number = (if ((((operand_10).number).zx_origin != null)) ((operand_10).number).zx_origin.? else block_14: {
                const operand_13 = (try (allocator).create(zx_type_20));

                (operand_13).* = zx_type_20{ .end = ((operand_10).number).end, .last_byte = ((operand_10).number).last_byte, .phase = ((operand_10).number).phase, .separators_valid = ((operand_10).number).separators_valid, };

                break :block_14 @as(*const zx_type_20, operand_13);
            }), .offset = (operand_10).offset, .skip_until = (operand_10).skip_until, .source_length = (operand_10).source_length, .start = (operand_10).start, .symbol = (operand_10).symbol, .tokens = (operand_10).tokens, .warmed = (operand_10).warmed, };

            break :block_16 @as(*const zx_type_28, operand_15);
        });
    };
}

fn function_53_value(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if (((!block_83: {
        const operand_81 = ((in).diagnostic).message;
        const operand_82 = @as([]const u8, "");

        break :block_83 ((std).mem).eql(u8, operand_81, operand_82);
    }) or ((in).mode == @as(zx_type_22, .Idle)))) {
        return in;
    }

    if (((in).mode == @as(zx_type_22, .Identifier))) {
        return block_80: {
            break :block_80 (try function_40_value(allocator, in));
        };
    }

    if (((in).mode == @as(zx_type_22, .Number))) {
        return block_79: {
            break :block_79 (try function_42_value(allocator, in));
        };
    }

    if (((in).mode == @as(zx_type_22, .LineComment))) {
        return block_78: {
            break :block_78 (try function_5_value(allocator, block_77: {
                const operand_69 = @as([]const u8, "");
                const operand_70 = (in).start;
                const operand_71 = (in).source_length;
                const operand_72 = true;
                const operand_73 = block_76: {
                    const operand_74 = in;
                    const operand_75 = @as(zx_type_22, .Idle);

                    break :block_76 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_74).ahead_one, .ahead_two = (operand_74).ahead_two, .braces = (operand_74).braces, .comments = (operand_74).comments, .depth = (operand_74).depth, .diagnostic = (operand_74).diagnostic, .dollar = (operand_74).dollar, .frames = (operand_74).frames, .keyword_state = (operand_74).keyword_state, .line_break = (operand_74).line_break, .mode = operand_75, .number = (operand_74).number, .offset = (operand_74).offset, .skip_until = (operand_74).skip_until, .source_length = (operand_74).source_length, .start = (operand_74).start, .symbol = (operand_74).symbol, .tokens = (operand_74).tokens, .warmed = (operand_74).warmed, });
                };

                break :block_77 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_69, .start = operand_70, .end = operand_71, .comment = operand_72, .state = operand_73, });
            }));
        };
    }

    const value_1: []const u8 = (if (((in).mode == @as(zx_type_22, .BlockComment))) @as([]const u8, "unterminated block comment") else (if ((((in).mode == @as(zx_type_22, .String)) or ((in).mode == @as(zx_type_22, .StringEscape)))) @as([]const u8, "unterminated string") else (if ((((in).mode == @as(zx_type_22, .Template)) or ((in).mode == @as(zx_type_22, .TemplateEscape)))) @as([]const u8, "unterminated template string") else (if (((in).mode == @as(zx_type_22, .InterpolationBlockComment))) @as([]const u8, "unterminated comment in template") else @as([]const u8, "unterminated template interpolation")))));

    return block_68: {
        break :block_68 (try function_6_value(allocator, block_67: {
            const operand_61 = @as([]const u8, "lexical");
            const operand_62 = (in).start;
            const operand_63 = (in).source_length;
            const operand_64 = block_65: {
                break :block_65 value_1;
            };
            const operand_66 = in;

            break :block_67 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_61, .start = operand_62, .end = operand_63, .message = operand_64, .state = operand_66, });
        }));
    };
}

fn function_53_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 {
    @setRuntimeSafety(true);

    if (((!block_106: {
        const operand_104 = ((in).diagnostic).message;
        const operand_105 = @as([]const u8, "");

        break :block_106 ((std).mem).eql(u8, operand_104, operand_105);
    }) or ((in).mode == @as(zx_type_22, .Idle)))) {
        return in;
    }

    if (((in).mode == @as(zx_type_22, .Identifier))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_103: {
            break :block_103 (try function_40_buffered(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if (((in).mode == @as(zx_type_22, .Number))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_102: {
            break :block_102 (try function_42_buffered(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    if (((in).mode == @as(zx_type_22, .LineComment))) {
        return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_101: {
            break :block_101 (try function_5_buffered(allocator, block_100: {
                const operand_92 = @as([]const u8, "");
                const operand_93 = (in).start;
                const operand_94 = (in).source_length;
                const operand_95 = true;
                const operand_96 = block_99: {
                    const operand_97 = in;
                    const operand_98 = @as(zx_type_22, .Idle);

                    break :block_99 @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_97).ahead_one, .ahead_two = (operand_97).ahead_two, .braces = (operand_97).braces, .comments = (operand_97).comments, .depth = (operand_97).depth, .diagnostic = (operand_97).diagnostic, .dollar = (operand_97).dollar, .frames = (operand_97).frames, .keyword_state = (operand_97).keyword_state, .line_break = (operand_97).line_break, .mode = operand_98, .number = (operand_97).number, .offset = (operand_97).offset, .skip_until = (operand_97).skip_until, .source_length = (operand_97).source_length, .start = (operand_97).start, .symbol = (operand_97).symbol, .tokens = (operand_97).tokens, .warmed = (operand_97).warmed, });
                };

                break :block_100 @as(value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_31_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .kind = operand_92, .start = operand_93, .end = operand_94, .comment = operand_95, .state = operand_96, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    const value_1: []const u8 = (if (((in).mode == @as(zx_type_22, .BlockComment))) @as([]const u8, "unterminated block comment") else (if ((((in).mode == @as(zx_type_22, .String)) or ((in).mode == @as(zx_type_22, .StringEscape)))) @as([]const u8, "unterminated string") else (if ((((in).mode == @as(zx_type_22, .Template)) or ((in).mode == @as(zx_type_22, .TemplateEscape)))) @as([]const u8, "unterminated template string") else (if (((in).mode == @as(zx_type_22, .InterpolationBlockComment))) @as([]const u8, "unterminated comment in template") else @as([]const u8, "unterminated template interpolation")))));

    return @as(value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, block_91: {
        break :block_91 (try function_6_buffered(allocator, block_90: {
            const operand_84 = @as([]const u8, "lexical");
            const operand_85 = (in).start;
            const operand_86 = (in).source_length;
            const operand_87 = block_88: {
                break :block_88 value_1;
            };
            const operand_89 = in;

            break :block_90 @as(value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b, value_zx_type_32_06aafe9be56c61e565a3a3c563e360e2f4522084992ebcd7c7c1edbda0cf417b{ .code = operand_84, .start = operand_85, .end = operand_86, .message = operand_87, .state = operand_89, });
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    });
}

fn function_53_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_28, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_24),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_28 {
    @setRuntimeSafety(true);

    if (((!block_130: {
        const operand_128 = ((in).diagnostic).message;
        const operand_129 = @as([]const u8, "");

        break :block_130 ((std).mem).eql(u8, operand_128, operand_129);
    }) or ((in).mode == @as(zx_type_22, .Idle)))) {
        return in;
    }

    if (((in).mode == @as(zx_type_22, .Identifier))) {
        return (try function_40_buffered_pointer(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if (((in).mode == @as(zx_type_22, .Number))) {
        return (try function_42_buffered_pointer(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    if (((in).mode == @as(zx_type_22, .LineComment))) {
        return (try function_5_buffered_pointer(allocator, block_127: {
            const operand_115 = @as([]const u8, "");
            const operand_116 = (in).start;
            const operand_117 = (in).source_length;
            const operand_118 = true;
            const operand_119 = block_124: {
                const operand_120 = in;
                const operand_121 = @as(zx_type_22, .Idle);

                break :block_124 block_123: {
                    const operand_122 = (try (allocator).create(zx_type_28));

                    (operand_122).* = @as(zx_type_28, zx_type_28{ .ahead_one = (operand_120).ahead_one, .ahead_two = (operand_120).ahead_two, .braces = (operand_120).braces, .comments = (operand_120).comments, .depth = (operand_120).depth, .diagnostic = (operand_120).diagnostic, .dollar = (operand_120).dollar, .frames = (operand_120).frames, .keyword_state = (operand_120).keyword_state, .line_break = (operand_120).line_break, .mode = operand_121, .number = (operand_120).number, .offset = (operand_120).offset, .skip_until = (operand_120).skip_until, .source_length = (operand_120).source_length, .start = (operand_120).start, .symbol = (operand_120).symbol, .tokens = (operand_120).tokens, .warmed = (operand_120).warmed, });

                    break :block_123 @as(*const zx_type_28, operand_122);
                };
            };

            break :block_127 block_126: {
                const operand_125 = (try (allocator).create(zx_type_31));

                (operand_125).* = @as(zx_type_31, zx_type_31{ .kind = operand_115, .start = operand_116, .end = operand_117, .comment = operand_118, .state = operand_119, });

                break :block_126 @as(*const zx_type_31, operand_125);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    const value_1: []const u8 = (if (((in).mode == @as(zx_type_22, .BlockComment))) @as([]const u8, "unterminated block comment") else (if ((((in).mode == @as(zx_type_22, .String)) or ((in).mode == @as(zx_type_22, .StringEscape)))) @as([]const u8, "unterminated string") else (if ((((in).mode == @as(zx_type_22, .Template)) or ((in).mode == @as(zx_type_22, .TemplateEscape)))) @as([]const u8, "unterminated template string") else (if (((in).mode == @as(zx_type_22, .InterpolationBlockComment))) @as([]const u8, "unterminated comment in template") else @as([]const u8, "unterminated template interpolation")))));

    return (try function_6_buffered_pointer(allocator, block_114: {
        const operand_107 = @as([]const u8, "lexical");
        const operand_108 = (in).start;
        const operand_109 = (in).source_length;
        const operand_110 = value_1;
        const operand_111 = in;

        break :block_114 block_113: {
            const operand_112 = (try (allocator).create(zx_type_32));

            (operand_112).* = @as(zx_type_32, zx_type_32{ .code = operand_107, .start = operand_108, .end = operand_109, .message = operand_110, .state = operand_111, });

            break :block_113 @as(*const zx_type_32, operand_112);
        };
    }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
}

fn function_54(allocator: ((std).mem).Allocator, in: *const zx_type_28) error{ OutOfMemory, Overflow, }!*const zx_type_30 {
    @setRuntimeSafety(true);

    const value_1: bool = ((@as(u64, ((in).tokens).len) != @as(u64, 0)) and (in).line_break);

    return block_24: {
        const operand_1 = (block_19: {
            const operand_2 = (in).tokens;
            const operand_17 = block_16: {
                const operand_3 = @as(zx_type_15, .Eof);
                const operand_4 = @as(zx_type_14, .Root);
                const operand_5 = @as(zx_type_16, .None);
                const operand_6 = block_11: {
                    const operand_7 = (in).source_length;
                    const operand_8 = (in).source_length;

                    break :block_11 block_10: {
                        const operand_9 = (try (allocator).create(zx_type_17));

                        (operand_9).* = @as(zx_type_17, zx_type_17{ .start = operand_7, .end = operand_8, });

                        break :block_10 @as(*const zx_type_17, operand_9);
                    };
                };
                const operand_12 = value_1;
                const operand_13 = false;

                break :block_16 block_15: {
                    const operand_14 = (try (allocator).create(zx_type_18));

                    (operand_14).* = @as(zx_type_18, zx_type_18{ .kind = operand_3, .word = operand_4, .symbol = operand_5, .span = operand_6, .line_break = operand_12, .dollar = operand_13, });

                    break :block_15 @as(*const zx_type_18, operand_14);
                };
            };
            const operand_18 = (try (allocator).alloc(*const zx_type_18, (try ((std).math).add(usize, (operand_2).len, 1))));

            @memcpy((operand_18)[0..(operand_2).len], operand_2);

            (operand_18)[(operand_2).len] = operand_17;

            break :block_19 @as(zx_type_41, .{ operand_18, {}, });
        }).@"0";
        const operand_20 = (in).comments;
        const operand_21 = (in).diagnostic;

        break :block_24 block_23: {
            const operand_22 = (try (allocator).create(zx_type_30));

            (operand_22).* = @as(zx_type_30, zx_type_30{ .tokens = operand_1, .comments = operand_20, .diagnostic = operand_21, });

            break :block_23 @as(*const zx_type_30, operand_22);
        };
    };
}

fn function_54_value(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955) error{ OutOfMemory, Overflow, }!value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb {
    @setRuntimeSafety(true);

    const value_1: bool = ((@as(u64, ((in).tokens).len) != @as(u64, 0)) and (in).line_break);

    return block_47: {
        const operand_25 = (block_44: {
            const operand_26 = (in).tokens;
            const operand_42 = block_41: {
                const operand_27 = @as(zx_type_15, .Eof);
                const operand_28 = @as(zx_type_14, .Root);
                const operand_29 = @as(zx_type_16, .None);
                const operand_30 = block_35: {
                    const operand_31 = (in).source_length;
                    const operand_32 = (in).source_length;

                    break :block_35 block_34: {
                        const operand_33 = (try (allocator).create(zx_type_17));

                        (operand_33).* = @as(zx_type_17, zx_type_17{ .start = operand_31, .end = operand_32, });

                        break :block_34 @as(*const zx_type_17, operand_33);
                    };
                };
                const operand_36 = block_37: {
                    break :block_37 value_1;
                };
                const operand_38 = false;

                break :block_41 block_40: {
                    const operand_39 = (try (allocator).create(zx_type_18));

                    (operand_39).* = @as(zx_type_18, zx_type_18{ .kind = operand_27, .word = operand_28, .symbol = operand_29, .span = operand_30, .line_break = operand_36, .dollar = operand_38, });

                    break :block_40 @as(*const zx_type_18, operand_39);
                };
            };
            const operand_43 = (try (allocator).alloc(*const zx_type_18, (try ((std).math).add(usize, (operand_26).len, 1))));

            @memcpy((operand_43)[0..(operand_26).len], operand_26);

            (operand_43)[(operand_26).len] = operand_42;

            break :block_44 @as(value_zx_type_41_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_43, {}, null, });
        }).@"0";
        const operand_45 = (in).comments;
        const operand_46 = (in).diagnostic;

        break :block_47 @as(value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb, value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb{ .tokens = operand_25, .comments = operand_45, .diagnostic = operand_46, });
    };
}

fn function_54_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb {
    @setRuntimeSafety(true);

    const value_1: bool = ((@as(u64, ((in).tokens).len) != @as(u64, 0)) and (in).line_break);

    return block_88: {
        const operand_48 = @as([]const *const zx_type_18, (if (((buffers).lane_1 != null)) block_66: {
            const operand_49 = (in).tokens;
            const operand_65 = block_64: {
                const operand_50 = @as(zx_type_15, .Eof);
                const operand_51 = @as(zx_type_14, .Root);
                const operand_52 = @as(zx_type_16, .None);
                const operand_53 = block_58: {
                    const operand_54 = (in).source_length;
                    const operand_55 = (in).source_length;

                    break :block_58 block_57: {
                        const operand_56 = (try (allocator).create(zx_type_17));

                        (operand_56).* = @as(zx_type_17, zx_type_17{ .start = operand_54, .end = operand_55, });

                        break :block_57 @as(*const zx_type_17, operand_56);
                    };
                };
                const operand_59 = block_60: {
                    break :block_60 value_1;
                };
                const operand_61 = false;

                break :block_64 block_63: {
                    const operand_62 = (try (allocator).create(zx_type_18));

                    (operand_62).* = @as(zx_type_18, zx_type_18{ .kind = operand_50, .word = operand_51, .symbol = operand_52, .span = operand_53, .line_break = operand_59, .dollar = operand_61, });

                    break :block_63 @as(*const zx_type_18, operand_62);
                };
            };

            _ = (try ((std).math).add(usize, (operand_49).len, 1));

            if ((!(((buffers).lane_1.?).started).*)) {
                (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_49));

                (((buffers).lane_1.?).started).* = true;
            } else {
                (((((buffers).lane_1.?).buffer).*).items).len = (operand_49).len;
            }

            (try ((((buffers).lane_1.?).buffer).*).append(allocator, operand_65));

            break :block_66 ((((buffers).lane_1.?).buffer).*).items;
        } else (block_85: {
            const operand_67 = (in).tokens;
            const operand_83 = block_82: {
                const operand_68 = @as(zx_type_15, .Eof);
                const operand_69 = @as(zx_type_14, .Root);
                const operand_70 = @as(zx_type_16, .None);
                const operand_71 = block_76: {
                    const operand_72 = (in).source_length;
                    const operand_73 = (in).source_length;

                    break :block_76 block_75: {
                        const operand_74 = (try (allocator).create(zx_type_17));

                        (operand_74).* = @as(zx_type_17, zx_type_17{ .start = operand_72, .end = operand_73, });

                        break :block_75 @as(*const zx_type_17, operand_74);
                    };
                };
                const operand_77 = block_78: {
                    break :block_78 value_1;
                };
                const operand_79 = false;

                break :block_82 block_81: {
                    const operand_80 = (try (allocator).create(zx_type_18));

                    (operand_80).* = @as(zx_type_18, zx_type_18{ .kind = operand_68, .word = operand_69, .symbol = operand_70, .span = operand_71, .line_break = operand_77, .dollar = operand_79, });

                    break :block_81 @as(*const zx_type_18, operand_80);
                };
            };
            const operand_84 = (try (allocator).alloc(*const zx_type_18, (try ((std).math).add(usize, (operand_67).len, 1))));

            @memcpy((operand_84)[0..(operand_67).len], operand_67);

            (operand_84)[(operand_67).len] = operand_83;

            break :block_85 @as(value_zx_type_41_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_84, {}, null, });
        }).@"0"));
        const operand_86 = (in).comments;
        const operand_87 = (in).diagnostic;

        break :block_88 @as(value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb, value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb{ .tokens = operand_48, .comments = operand_86, .diagnostic = operand_87, });
    };
}

fn function_54_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_28, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_17),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(*const zx_type_18),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_30 {
    @setRuntimeSafety(true);

    const value_1: bool = ((@as(u64, ((in).tokens).len) != @as(u64, 0)) and (in).line_break);

    return block_129: {
        const operand_89 = @as([]const *const zx_type_18, (if (((buffers).lane_1 != null)) block_106: {
            const operand_90 = (in).tokens;
            const operand_105 = block_104: {
                const operand_91 = @as(zx_type_15, .Eof);
                const operand_92 = @as(zx_type_14, .Root);
                const operand_93 = @as(zx_type_16, .None);
                const operand_94 = block_99: {
                    const operand_95 = (in).source_length;
                    const operand_96 = (in).source_length;

                    break :block_99 block_98: {
                        const operand_97 = (try (allocator).create(zx_type_17));

                        (operand_97).* = @as(zx_type_17, zx_type_17{ .start = operand_95, .end = operand_96, });

                        break :block_98 @as(*const zx_type_17, operand_97);
                    };
                };
                const operand_100 = value_1;
                const operand_101 = false;

                break :block_104 block_103: {
                    const operand_102 = (try (allocator).create(zx_type_18));

                    (operand_102).* = @as(zx_type_18, zx_type_18{ .kind = operand_91, .word = operand_92, .symbol = operand_93, .span = operand_94, .line_break = operand_100, .dollar = operand_101, });

                    break :block_103 @as(*const zx_type_18, operand_102);
                };
            };

            _ = (try ((std).math).add(usize, (operand_90).len, 1));

            if ((!(((buffers).lane_1.?).started).*)) {
                (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_90));

                (((buffers).lane_1.?).started).* = true;
            } else {
                (((((buffers).lane_1.?).buffer).*).items).len = (operand_90).len;
            }

            (try ((((buffers).lane_1.?).buffer).*).append(allocator, operand_105));

            break :block_106 ((((buffers).lane_1.?).buffer).*).items;
        } else (block_124: {
            const operand_107 = (in).tokens;
            const operand_122 = block_121: {
                const operand_108 = @as(zx_type_15, .Eof);
                const operand_109 = @as(zx_type_14, .Root);
                const operand_110 = @as(zx_type_16, .None);
                const operand_111 = block_116: {
                    const operand_112 = (in).source_length;
                    const operand_113 = (in).source_length;

                    break :block_116 block_115: {
                        const operand_114 = (try (allocator).create(zx_type_17));

                        (operand_114).* = @as(zx_type_17, zx_type_17{ .start = operand_112, .end = operand_113, });

                        break :block_115 @as(*const zx_type_17, operand_114);
                    };
                };
                const operand_117 = value_1;
                const operand_118 = false;

                break :block_121 block_120: {
                    const operand_119 = (try (allocator).create(zx_type_18));

                    (operand_119).* = @as(zx_type_18, zx_type_18{ .kind = operand_108, .word = operand_109, .symbol = operand_110, .span = operand_111, .line_break = operand_117, .dollar = operand_118, });

                    break :block_120 @as(*const zx_type_18, operand_119);
                };
            };
            const operand_123 = (try (allocator).alloc(*const zx_type_18, (try ((std).math).add(usize, (operand_107).len, 1))));

            @memcpy((operand_123)[0..(operand_107).len], operand_107);

            (operand_123)[(operand_107).len] = operand_122;

            break :block_124 @as(zx_type_41, .{ operand_123, {}, });
        }).@"0"));
        const operand_125 = (in).comments;
        const operand_126 = (in).diagnostic;

        break :block_129 block_128: {
            const operand_127 = (try (allocator).create(zx_type_30));

            (operand_127).* = @as(zx_type_30, zx_type_30{ .tokens = operand_89, .comments = operand_125, .diagnostic = operand_126, });

            break :block_128 @as(*const zx_type_30, operand_127);
        };
    };
}

fn function_55(allocator: ((std).mem).Allocator, in: *const zx_type_23) error{ OutOfMemory, }!*const zx_type_30 {
    @setRuntimeSafety(true);

    const value_1: []const *const zx_type_18 = block_8: {
        break :block_8 (try (allocator).dupe(*const zx_type_18, (&[_]*const zx_type_18{})));
    };
    const value_2: []const *const zx_type_17 = block_7: {
        break :block_7 (try (allocator).dupe(*const zx_type_17, (&[_]*const zx_type_17{})));
    };

    return block_6: {
        const operand_1 = value_1;
        const operand_2 = value_2;
        const operand_3 = in;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create(zx_type_30));

            (operand_4).* = @as(zx_type_30, zx_type_30{ .tokens = operand_1, .comments = operand_2, .diagnostic = operand_3, });

            break :block_5 @as(*const zx_type_30, operand_4);
        };
    };
}

fn function_55_value(allocator: ((std).mem).Allocator, in: value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165) error{ OutOfMemory, }!value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb {
    @setRuntimeSafety(true);

    const value_1: []const *const zx_type_18 = block_16: {
        break :block_16 (try (allocator).dupe(*const zx_type_18, (&[_]*const zx_type_18{})));
    };
    const value_2: []const *const zx_type_17 = block_15: {
        break :block_15 (try (allocator).dupe(*const zx_type_17, (&[_]*const zx_type_17{})));
    };

    return block_14: {
        const operand_9 = block_10: {
            break :block_10 value_1;
        };
        const operand_11 = block_12: {
            break :block_12 value_2;
        };
        const operand_13 = in;

        break :block_14 @as(value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb, value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb{ .tokens = operand_9, .comments = operand_11, .diagnostic = operand_13, });
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_30 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = (try function_1(allocator, in));
    const switch_1 = value_1;

    if ((switch_1 == true)) {
        const value_2: *const zx_type_28 = block_79: {
            const operand_71 = block_70: {
                const operand_66 = @as(u64, 0);
                const operand_67 = @as(u64, (in).len);

                break :block_70 block_69: {
                    const operand_68 = (try (allocator).create(zx_type_17));

                    (operand_68).* = @as(zx_type_17, zx_type_17{ .start = operand_66, .end = operand_67, });

                    break :block_69 @as(*const zx_type_17, operand_68);
                };
            };
            const operand_72 = (try function_2_value(allocator, operand_71));

            break :block_79 (if (((operand_72).zx_origin != null)) (operand_72).zx_origin.? else block_78: {
                const operand_77 = (try (allocator).create(zx_type_28));

                (operand_77).* = zx_type_28{ .ahead_one = (operand_72).ahead_one, .ahead_two = (operand_72).ahead_two, .braces = (operand_72).braces, .comments = (operand_72).comments, .depth = (operand_72).depth, .diagnostic = (if ((((operand_72).diagnostic).zx_origin != null)) ((operand_72).diagnostic).zx_origin.? else block_74: {
                    const operand_73 = (try (allocator).create(zx_type_23));

                    (operand_73).* = zx_type_23{ .code = ((operand_72).diagnostic).code, .end = ((operand_72).diagnostic).end, .message = ((operand_72).diagnostic).message, .start = ((operand_72).diagnostic).start, };

                    break :block_74 @as(*const zx_type_23, operand_73);
                }), .dollar = (operand_72).dollar, .frames = (operand_72).frames, .keyword_state = (operand_72).keyword_state, .line_break = (operand_72).line_break, .mode = (operand_72).mode, .number = (if ((((operand_72).number).zx_origin != null)) ((operand_72).number).zx_origin.? else block_76: {
                    const operand_75 = (try (allocator).create(zx_type_20));

                    (operand_75).* = zx_type_20{ .end = ((operand_72).number).end, .last_byte = ((operand_72).number).last_byte, .phase = ((operand_72).number).phase, .separators_valid = ((operand_72).number).separators_valid, };

                    break :block_76 @as(*const zx_type_20, operand_75);
                }), .offset = (operand_72).offset, .skip_until = (operand_72).skip_until, .source_length = (operand_72).source_length, .start = (operand_72).start, .symbol = (operand_72).symbol, .tokens = (operand_72).tokens, .warmed = (operand_72).warmed, };

                break :block_78 @as(*const zx_type_28, operand_77);
            });
        };
        const value_3: *const zx_type_28 = block_65: {
            const operand_57 = block_56: {
                const operand_52 = in;
                const operand_53 = value_2;

                break :block_56 block_55: {
                    const operand_54 = (try (allocator).create(zx_type_38));

                    (operand_54).* = @as(zx_type_38, zx_type_38{ .source = operand_52, .state = operand_53, });

                    break :block_55 @as(*const zx_type_38, operand_54);
                };
            };
            const operand_58 = (try function_51_value(allocator, value_zx_type_38_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b{ .source = (operand_57).source, .state = value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = ((operand_57).state).ahead_one, .ahead_two = ((operand_57).state).ahead_two, .braces = ((operand_57).state).braces, .comments = ((operand_57).state).comments, .depth = ((operand_57).state).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (((operand_57).state).diagnostic).code, .end = (((operand_57).state).diagnostic).end, .message = (((operand_57).state).diagnostic).message, .start = (((operand_57).state).diagnostic).start, .zx_origin = ((operand_57).state).diagnostic, }, .dollar = ((operand_57).state).dollar, .frames = ((operand_57).state).frames, .keyword_state = ((operand_57).state).keyword_state, .line_break = ((operand_57).state).line_break, .mode = ((operand_57).state).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = (((operand_57).state).number).end, .last_byte = (((operand_57).state).number).last_byte, .phase = (((operand_57).state).number).phase, .separators_valid = (((operand_57).state).number).separators_valid, .zx_origin = ((operand_57).state).number, }, .offset = ((operand_57).state).offset, .skip_until = ((operand_57).state).skip_until, .source_length = ((operand_57).state).source_length, .start = ((operand_57).state).start, .symbol = ((operand_57).state).symbol, .tokens = ((operand_57).state).tokens, .warmed = ((operand_57).state).warmed, .zx_origin = (operand_57).state, }, .zx_origin = operand_57, }));

            break :block_65 (if (((operand_58).zx_origin != null)) (operand_58).zx_origin.? else block_64: {
                const operand_63 = (try (allocator).create(zx_type_28));

                (operand_63).* = zx_type_28{ .ahead_one = (operand_58).ahead_one, .ahead_two = (operand_58).ahead_two, .braces = (operand_58).braces, .comments = (operand_58).comments, .depth = (operand_58).depth, .diagnostic = (if ((((operand_58).diagnostic).zx_origin != null)) ((operand_58).diagnostic).zx_origin.? else block_60: {
                    const operand_59 = (try (allocator).create(zx_type_23));

                    (operand_59).* = zx_type_23{ .code = ((operand_58).diagnostic).code, .end = ((operand_58).diagnostic).end, .message = ((operand_58).diagnostic).message, .start = ((operand_58).diagnostic).start, };

                    break :block_60 @as(*const zx_type_23, operand_59);
                }), .dollar = (operand_58).dollar, .frames = (operand_58).frames, .keyword_state = (operand_58).keyword_state, .line_break = (operand_58).line_break, .mode = (operand_58).mode, .number = (if ((((operand_58).number).zx_origin != null)) ((operand_58).number).zx_origin.? else block_62: {
                    const operand_61 = (try (allocator).create(zx_type_20));

                    (operand_61).* = zx_type_20{ .end = ((operand_58).number).end, .last_byte = ((operand_58).number).last_byte, .phase = ((operand_58).number).phase, .separators_valid = ((operand_58).number).separators_valid, };

                    break :block_62 @as(*const zx_type_20, operand_61);
                }), .offset = (operand_58).offset, .skip_until = (operand_58).skip_until, .source_length = (operand_58).source_length, .start = (operand_58).start, .symbol = (operand_58).symbol, .tokens = (operand_58).tokens, .warmed = (operand_58).warmed, };

                break :block_64 @as(*const zx_type_28, operand_63);
            });
        };
        const value_4: *const zx_type_28 = block_51: {
            const operand_43 = value_3;
            const operand_44 = (try function_52_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_43).ahead_one, .ahead_two = (operand_43).ahead_two, .braces = (operand_43).braces, .comments = (operand_43).comments, .depth = (operand_43).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_43).diagnostic).code, .end = ((operand_43).diagnostic).end, .message = ((operand_43).diagnostic).message, .start = ((operand_43).diagnostic).start, .zx_origin = (operand_43).diagnostic, }, .dollar = (operand_43).dollar, .frames = (operand_43).frames, .keyword_state = (operand_43).keyword_state, .line_break = (operand_43).line_break, .mode = (operand_43).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_43).number).end, .last_byte = ((operand_43).number).last_byte, .phase = ((operand_43).number).phase, .separators_valid = ((operand_43).number).separators_valid, .zx_origin = (operand_43).number, }, .offset = (operand_43).offset, .skip_until = (operand_43).skip_until, .source_length = (operand_43).source_length, .start = (operand_43).start, .symbol = (operand_43).symbol, .tokens = (operand_43).tokens, .warmed = (operand_43).warmed, .zx_origin = operand_43, }));

            break :block_51 (if (((operand_44).zx_origin != null)) (operand_44).zx_origin.? else block_50: {
                const operand_49 = (try (allocator).create(zx_type_28));

                (operand_49).* = zx_type_28{ .ahead_one = (operand_44).ahead_one, .ahead_two = (operand_44).ahead_two, .braces = (operand_44).braces, .comments = (operand_44).comments, .depth = (operand_44).depth, .diagnostic = (if ((((operand_44).diagnostic).zx_origin != null)) ((operand_44).diagnostic).zx_origin.? else block_46: {
                    const operand_45 = (try (allocator).create(zx_type_23));

                    (operand_45).* = zx_type_23{ .code = ((operand_44).diagnostic).code, .end = ((operand_44).diagnostic).end, .message = ((operand_44).diagnostic).message, .start = ((operand_44).diagnostic).start, };

                    break :block_46 @as(*const zx_type_23, operand_45);
                }), .dollar = (operand_44).dollar, .frames = (operand_44).frames, .keyword_state = (operand_44).keyword_state, .line_break = (operand_44).line_break, .mode = (operand_44).mode, .number = (if ((((operand_44).number).zx_origin != null)) ((operand_44).number).zx_origin.? else block_48: {
                    const operand_47 = (try (allocator).create(zx_type_20));

                    (operand_47).* = zx_type_20{ .end = ((operand_44).number).end, .last_byte = ((operand_44).number).last_byte, .phase = ((operand_44).number).phase, .separators_valid = ((operand_44).number).separators_valid, };

                    break :block_48 @as(*const zx_type_20, operand_47);
                }), .offset = (operand_44).offset, .skip_until = (operand_44).skip_until, .source_length = (operand_44).source_length, .start = (operand_44).start, .symbol = (operand_44).symbol, .tokens = (operand_44).tokens, .warmed = (operand_44).warmed, };

                break :block_50 @as(*const zx_type_28, operand_49);
            });
        };
        const value_5: *const zx_type_28 = block_42: {
            const operand_34 = value_4;
            const operand_35 = (try function_53_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_34).ahead_one, .ahead_two = (operand_34).ahead_two, .braces = (operand_34).braces, .comments = (operand_34).comments, .depth = (operand_34).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_34).diagnostic).code, .end = ((operand_34).diagnostic).end, .message = ((operand_34).diagnostic).message, .start = ((operand_34).diagnostic).start, .zx_origin = (operand_34).diagnostic, }, .dollar = (operand_34).dollar, .frames = (operand_34).frames, .keyword_state = (operand_34).keyword_state, .line_break = (operand_34).line_break, .mode = (operand_34).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_34).number).end, .last_byte = ((operand_34).number).last_byte, .phase = ((operand_34).number).phase, .separators_valid = ((operand_34).number).separators_valid, .zx_origin = (operand_34).number, }, .offset = (operand_34).offset, .skip_until = (operand_34).skip_until, .source_length = (operand_34).source_length, .start = (operand_34).start, .symbol = (operand_34).symbol, .tokens = (operand_34).tokens, .warmed = (operand_34).warmed, .zx_origin = operand_34, }));

            break :block_42 (if (((operand_35).zx_origin != null)) (operand_35).zx_origin.? else block_41: {
                const operand_40 = (try (allocator).create(zx_type_28));

                (operand_40).* = zx_type_28{ .ahead_one = (operand_35).ahead_one, .ahead_two = (operand_35).ahead_two, .braces = (operand_35).braces, .comments = (operand_35).comments, .depth = (operand_35).depth, .diagnostic = (if ((((operand_35).diagnostic).zx_origin != null)) ((operand_35).diagnostic).zx_origin.? else block_37: {
                    const operand_36 = (try (allocator).create(zx_type_23));

                    (operand_36).* = zx_type_23{ .code = ((operand_35).diagnostic).code, .end = ((operand_35).diagnostic).end, .message = ((operand_35).diagnostic).message, .start = ((operand_35).diagnostic).start, };

                    break :block_37 @as(*const zx_type_23, operand_36);
                }), .dollar = (operand_35).dollar, .frames = (operand_35).frames, .keyword_state = (operand_35).keyword_state, .line_break = (operand_35).line_break, .mode = (operand_35).mode, .number = (if ((((operand_35).number).zx_origin != null)) ((operand_35).number).zx_origin.? else block_39: {
                    const operand_38 = (try (allocator).create(zx_type_20));

                    (operand_38).* = zx_type_20{ .end = ((operand_35).number).end, .last_byte = ((operand_35).number).last_byte, .phase = ((operand_35).number).phase, .separators_valid = ((operand_35).number).separators_valid, };

                    break :block_39 @as(*const zx_type_20, operand_38);
                }), .offset = (operand_35).offset, .skip_until = (operand_35).skip_until, .source_length = (operand_35).source_length, .start = (operand_35).start, .symbol = (operand_35).symbol, .tokens = (operand_35).tokens, .warmed = (operand_35).warmed, };

                break :block_41 @as(*const zx_type_28, operand_40);
            });
        };
        const switch_16 = block_19: {
            const operand_17 = ((value_5).diagnostic).message;
            const operand_18 = @as([]const u8, "");

            break :block_19 ((std).mem).eql(u8, operand_17, operand_18);
        };

        if ((switch_16 == true)) {
            const value_6: *const zx_type_30 = block_33: {
                const operand_27 = value_5;
                const operand_28 = (try function_54_value(allocator, value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955{ .ahead_one = (operand_27).ahead_one, .ahead_two = (operand_27).ahead_two, .braces = (operand_27).braces, .comments = (operand_27).comments, .depth = (operand_27).depth, .diagnostic = value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = ((operand_27).diagnostic).code, .end = ((operand_27).diagnostic).end, .message = ((operand_27).diagnostic).message, .start = ((operand_27).diagnostic).start, .zx_origin = (operand_27).diagnostic, }, .dollar = (operand_27).dollar, .frames = (operand_27).frames, .keyword_state = (operand_27).keyword_state, .line_break = (operand_27).line_break, .mode = (operand_27).mode, .number = value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .end = ((operand_27).number).end, .last_byte = ((operand_27).number).last_byte, .phase = ((operand_27).number).phase, .separators_valid = ((operand_27).number).separators_valid, .zx_origin = (operand_27).number, }, .offset = (operand_27).offset, .skip_until = (operand_27).skip_until, .source_length = (operand_27).source_length, .start = (operand_27).start, .symbol = (operand_27).symbol, .tokens = (operand_27).tokens, .warmed = (operand_27).warmed, .zx_origin = operand_27, }));

                break :block_33 (if (((operand_28).zx_origin != null)) (operand_28).zx_origin.? else block_32: {
                    const operand_31 = (try (allocator).create(zx_type_30));

                    (operand_31).* = zx_type_30{ .comments = (operand_28).comments, .diagnostic = (if ((((operand_28).diagnostic).zx_origin != null)) ((operand_28).diagnostic).zx_origin.? else block_30: {
                        const operand_29 = (try (allocator).create(zx_type_23));

                        (operand_29).* = zx_type_23{ .code = ((operand_28).diagnostic).code, .end = ((operand_28).diagnostic).end, .message = ((operand_28).diagnostic).message, .start = ((operand_28).diagnostic).start, };

                        break :block_30 @as(*const zx_type_23, operand_29);
                    }), .tokens = (operand_28).tokens, };

                    break :block_32 @as(*const zx_type_30, operand_31);
                });
            };

            return value_6;
        } else {
            const value_7: *const zx_type_30 = block_26: {
                const operand_20 = (value_5).diagnostic;
                const operand_21 = (try function_55_value(allocator, value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (operand_20).code, .end = (operand_20).end, .message = (operand_20).message, .start = (operand_20).start, .zx_origin = operand_20, }));

                break :block_26 (if (((operand_21).zx_origin != null)) (operand_21).zx_origin.? else block_25: {
                    const operand_24 = (try (allocator).create(zx_type_30));

                    (operand_24).* = zx_type_30{ .comments = (operand_21).comments, .diagnostic = (if ((((operand_21).diagnostic).zx_origin != null)) ((operand_21).diagnostic).zx_origin.? else block_23: {
                        const operand_22 = (try (allocator).create(zx_type_23));

                        (operand_22).* = zx_type_23{ .code = ((operand_21).diagnostic).code, .end = ((operand_21).diagnostic).end, .message = ((operand_21).diagnostic).message, .start = ((operand_21).diagnostic).start, };

                        break :block_23 @as(*const zx_type_23, operand_22);
                    }), .tokens = (operand_21).tokens, };

                    break :block_25 @as(*const zx_type_30, operand_24);
                });
            };

            return value_7;
        }
    } else {
        const value_8: *const zx_type_30 = block_15: {
            const operand_9 = block_8: {
                const operand_2 = @as([]const u8, "lexical");
                const operand_3 = @as(u64, 0);
                const operand_4 = @as(u64, (in).len);
                const operand_5 = @as([]const u8, "source must be valid UTF-8");

                break :block_8 block_7: {
                    const operand_6 = (try (allocator).create(zx_type_23));

                    (operand_6).* = @as(zx_type_23, zx_type_23{ .code = operand_2, .start = operand_3, .end = operand_4, .message = operand_5, });

                    break :block_7 @as(*const zx_type_23, operand_6);
                };
            };
            const operand_10 = (try function_55_value(allocator, value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = (operand_9).code, .end = (operand_9).end, .message = (operand_9).message, .start = (operand_9).start, .zx_origin = operand_9, }));

            break :block_15 (if (((operand_10).zx_origin != null)) (operand_10).zx_origin.? else block_14: {
                const operand_13 = (try (allocator).create(zx_type_30));

                (operand_13).* = zx_type_30{ .comments = (operand_10).comments, .diagnostic = (if ((((operand_10).diagnostic).zx_origin != null)) ((operand_10).diagnostic).zx_origin.? else block_12: {
                    const operand_11 = (try (allocator).create(zx_type_23));

                    (operand_11).* = zx_type_23{ .code = ((operand_10).diagnostic).code, .end = ((operand_10).diagnostic).end, .message = ((operand_10).diagnostic).message, .start = ((operand_10).diagnostic).start, };

                    break :block_12 @as(*const zx_type_23, operand_11);
                }), .tokens = (operand_10).tokens, };

                break :block_14 @as(*const zx_type_30, operand_13);
            });
        };

        return value_8;
    }
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb {
    @setRuntimeSafety(true);

    const value_1: bool = (try function_1(allocator, in));
    const switch_80 = block_81: {
        break :block_81 value_1;
    };

    if ((switch_80 == true)) {
        const value_2: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_105: {
            break :block_105 (try function_2_value(allocator, block_104: {
                const operand_100 = @as(u64, 0);
                const operand_101 = @as(u64, (in).len);

                break :block_104 block_103: {
                    const operand_102 = (try (allocator).create(zx_type_17));

                    (operand_102).* = @as(zx_type_17, zx_type_17{ .start = operand_100, .end = operand_101, });

                    break :block_103 @as(*const zx_type_17, operand_102);
                };
            }));
        };
        const value_3: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_99: {
            break :block_99 (try function_51_value(allocator, block_98: {
                const operand_96 = in;
                const operand_97 = value_2;

                break :block_98 @as(value_zx_type_38_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b, value_zx_type_38_457157f944d88f0e96f106298e7698fcf74d0dd6e60bbb45d3ec17e527fbd28b{ .source = operand_96, .state = operand_97, });
            }));
        };
        const value_4: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_95: {
            break :block_95 (try function_52_value(allocator, value_3));
        };
        const value_5: value_zx_type_28_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = block_94: {
            break :block_94 (try function_53_value(allocator, value_4));
        };
        const switch_88 = block_91: {
            const operand_89 = ((value_5).diagnostic).message;
            const operand_90 = @as([]const u8, "");

            break :block_91 ((std).mem).eql(u8, operand_89, operand_90);
        };

        if ((switch_88 == true)) {
            const value_6: value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = block_93: {
                break :block_93 (try function_54_value(allocator, value_5));
            };

            return value_6;
        } else {
            const value_7: value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = block_92: {
                break :block_92 (try function_55_value(allocator, (value_5).diagnostic));
            };

            return value_7;
        }
    } else {
        const value_8: value_zx_type_30_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = block_87: {
            break :block_87 (try function_55_value(allocator, block_86: {
                const operand_82 = @as([]const u8, "lexical");
                const operand_83 = @as(u64, 0);
                const operand_84 = @as(u64, (in).len);
                const operand_85 = @as([]const u8, "source must be valid UTF-8");

                break :block_86 @as(value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_23_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .code = operand_82, .start = operand_83, .end = operand_84, .message = operand_85, });
            }));
        };

        return value_8;
    }
}

