pub const generated_parser: bool = true;
