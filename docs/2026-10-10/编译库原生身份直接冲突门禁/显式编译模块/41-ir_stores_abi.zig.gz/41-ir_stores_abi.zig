pub const zx_type_11 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_15 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_16 = struct {
    base: *const zx_type_15,
    delta: *const zx_type_15,
};

pub const zx_type_17 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_18 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    second: u32,
};

pub const zx_type_19 = struct {
    id: u32,
    tables: *const zx_type_16,
};

pub const zx_type_20 = struct {
    children: []const u32,
    fields: *const zx_type_17,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_21 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_22 = struct {
    delta: *const zx_type_15,
    id: u32,
};

pub const zx_type_24 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: *const zx_type_16,
};

pub const zx_type_25 = struct {
    id: u32,
    native_references: bool,
    tables: *const zx_type_16,
};

pub const zx_type_26 = struct {
    id: u32,
    native_references: bool,
    table: *const zx_type_15,
};

pub const zx_type_27 = struct {
    index: u64,
    paths: []const []const u8,
};

pub const zx_type_28 = struct {
    paths: []const []const u8,
    slot_types: []const u32,
    table: *const zx_type_15,
    type_only: bool,
};

pub const zx_type_29 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
};

pub const zx_type_30 = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: *const zx_type_16,
    target: zx_type_11,
};

pub const zx_type_31 = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: *const zx_type_16,
};

pub const zx_type_32 = struct { []const bool, void, };

pub const zx_type_33 = struct {
    index: u64,
    limit: u64,
    path: []const u8,
    paths: []const []const u8,
    repeated: bool,
};

pub const zx_type_34 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
};

pub const zx_type_35 = struct {
    index: u64,
    paths: []const []const u8,
    slot_types: []const u32,
    table: *const zx_type_15,
    valid: bool,
};

pub const zx_type_36 = struct { *const zx_type_28, };

pub const zx_type_37 = struct { *const zx_type_28, bool, };

pub const value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
    zx_origin: ?*const zx_type_15 = null,
};

pub const value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9 = struct {
    base: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    delta: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_18 = null,
};

pub const value_zx_type_19_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d = struct {
    id: u32,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_20_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_21 = null,
};

pub const value_zx_type_22_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922 = struct {
    delta: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    id: u32,
    zx_origin: ?*const zx_type_22 = null,
};

pub const value_zx_type_24_e972f781955bd05b543974dc1c9ab602e43bd152a6dd44491a4c58f77a931cf9 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    zx_origin: ?*const zx_type_24 = null,
};

pub const value_zx_type_25_7a15c29055f8182f7e8d5b03d58bd7d0df7344213af868563cae91988b6f3044 = struct {
    id: u32,
    native_references: bool,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    zx_origin: ?*const zx_type_25 = null,
};

pub const value_zx_type_26_bc0beef4baed6cbec65527f285ce2af317364f06c28bd549a5782c80f0e63a13 = struct {
    id: u32,
    native_references: bool,
    table: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_26 = null,
};

pub const value_zx_type_27_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u64,
    paths: []const []const u8,
    zx_origin: ?*const zx_type_27 = null,
};

pub const value_zx_type_28_ca9b702a05ea69e5310b94362a289c01b011a5de2e5ad8fac4aa0d65cf1702a0 = struct {
    paths: []const []const u8,
    slot_types: []const u32,
    table: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    type_only: bool,
    zx_origin: ?*const zx_type_28 = null,
};

pub const value_zx_type_29_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
    zx_origin: ?*const zx_type_29 = null,
};

pub const value_zx_type_30_2ff90cb3833573922fb9419c6b2505839e93960993f4c45b4c87519ae7802c22 = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    target: zx_type_11,
    zx_origin: ?*const zx_type_30 = null,
};

pub const value_zx_type_31_3d1f37005250a2c0674a51dc35f90d907a592f98f57f7fc69373a63048ed0bbc = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    zx_origin: ?*const zx_type_31 = null,
};

pub const value_zx_type_32_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, void, ?*const zx_type_32, };

pub const value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    limit: u64,
    path: []const u8,
    paths: []const []const u8,
    repeated: bool,
    zx_origin: ?*const zx_type_33 = null,
};

pub const value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_34 = null,
};

pub const value_zx_type_35_1b57aa2355f9edab56816797ae9039ca94b814ce673c0e3ecfe4c45a46d443e4 = struct {
    index: u64,
    paths: []const []const u8,
    slot_types: []const u32,
    table: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    valid: bool,
    zx_origin: ?*const zx_type_35 = null,
};

pub const value_zx_type_36_9050063b6f3b186d5286d2ff8f903268290cc8a02b4a2e6c8df06899c7bec1e4 = struct { value_zx_type_28_ca9b702a05ea69e5310b94362a289c01b011a5de2e5ad8fac4aa0d65cf1702a0, ?*const zx_type_36, };

pub const value_zx_type_37_1e25b9b36044efcdddb7ecb71f216aa804a053defa1bde43b3e7b33d281841f6 = struct { value_zx_type_28_ca9b702a05ea69e5310b94362a289c01b011a5de2e5ad8fac4aa0d65cf1702a0, bool, ?*const zx_type_37, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
};

