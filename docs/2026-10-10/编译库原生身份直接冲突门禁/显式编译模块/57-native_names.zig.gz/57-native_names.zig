const std = @import("std");

const zx_native_0 = @import("zxc_standard");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .scalar, };

const zx_shape_13 = .{ .kind = .scalar, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .end = zx_shape_5, .start = zx_shape_5, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .dollar = zx_shape_1, .kind = zx_shape_12, .line_break = zx_shape_1, .span = zx_shape_14, .symbol = zx_shape_13, .word = zx_shape_11, }, };

const zx_shape_16 = .{ .kind = .scalar, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .end = zx_shape_5, .last_byte = zx_shape_2, .phase = zx_shape_16, .separators_valid = zx_shape_1, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .diagnostic = zx_shape_10, .end = zx_shape_5, }, };

const zx_shape_19 = .{ .kind = .scalar, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .code = zx_shape_10, .end = zx_shape_5, .message = zx_shape_10, .start = zx_shape_5, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .braces = zx_shape_5, .depth = zx_shape_5, .mode = zx_shape_19, .start = zx_shape_5, }, };

const zx_shape_22 = .{ .kind = .list, .child = zx_shape_21, };

const zx_shape_23 = .{ .kind = .list, .child = zx_shape_15, };

const zx_shape_24 = .{ .kind = .list, .child = zx_shape_14, };

const zx_shape_25 = .{ .kind = .object, .fields = .{ .ahead_one = zx_shape_2, .ahead_two = zx_shape_2, .braces = zx_shape_5, .comments = zx_shape_24, .depth = zx_shape_5, .diagnostic = zx_shape_20, .dollar = zx_shape_1, .frames = zx_shape_22, .keyword_state = zx_shape_5, .line_break = zx_shape_1, .mode = zx_shape_19, .number = zx_shape_17, .offset = zx_shape_5, .skip_until = zx_shape_5, .source_length = zx_shape_5, .start = zx_shape_5, .symbol = zx_shape_13, .tokens = zx_shape_23, .warmed = zx_shape_2, }, };

const zx_shape_26 = .{ .kind = .object, .fields = .{ .after = zx_shape_2, .byte = zx_shape_2, .has_after = zx_shape_1, .has_next = zx_shape_1, .next = zx_shape_2, .state = zx_shape_25, }, };

const zx_shape_27 = .{ .kind = .object, .fields = .{ .comments = zx_shape_24, .diagnostic = zx_shape_20, .tokens = zx_shape_23, }, };

const zx_shape_28 = .{ .kind = .scalar, };

const zx_shape_29 = .{ .kind = .scalar, };

const zx_shape_30 = .{ .kind = .object, .fields = .{ .child = zx_shape_5, .count = zx_shape_5, .head = zx_shape_5, .kind = zx_shape_28, .name = zx_shape_14, }, };

const zx_shape_31 = .{ .kind = .object, .fields = .{ .name = zx_shape_14, .previous = zx_shape_5, .value = zx_shape_5, }, };

const zx_shape_32 = .{ .kind = .object, .fields = .{ .previous = zx_shape_5, .value = zx_shape_5, }, };

const zx_shape_33 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .fields = zx_shape_33, .heads = zx_shape_33, .items = zx_shape_33, }, };

const zx_shape_35 = .{ .kind = .list, .child = zx_shape_30, };

const zx_shape_36 = .{ .kind = .list, .child = zx_shape_31, };

const zx_shape_37 = .{ .kind = .list, .child = zx_shape_32, };

const zx_shape_38 = .{ .kind = .object, .fields = .{ .fields = zx_shape_36, .items = zx_shape_37, .nodes = zx_shape_35, }, };

const zx_shape_39 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .field = zx_shape_14, .head = zx_shape_5, .kind = zx_shape_28, .name = zx_shape_14, .optional = zx_shape_1, }, };

const zx_shape_40 = .{ .kind = .object, .fields = .{ .depth = zx_shape_5, .diagnostic = zx_shape_20, .index = zx_shape_5, .name = zx_shape_14, .phase = zx_shape_29, .result = zx_shape_5, .start = zx_shape_5, .token = zx_shape_15, }, };

const zx_shape_41 = .{ .kind = .list, .child = zx_shape_39, };

const zx_shape_42 = .{ .kind = .object, .fields = .{ .control = zx_shape_40, .frames = zx_shape_41, .tree = zx_shape_38, }, };

const zx_shape_43 = .{ .kind = .scalar, };

const zx_shape_44 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .enumeration = zx_shape_1, .first = zx_shape_5, .name = zx_shape_14, .span = zx_shape_14, .value = zx_shape_5, }, };

const zx_shape_45 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .depth = zx_shape_5, .diagnostic = zx_shape_20, .enumeration = zx_shape_1, .first = zx_shape_5, .index = zx_shape_5, .last_end = zx_shape_5, .name = zx_shape_14, .opening = zx_shape_5, .opening_index = zx_shape_5, .phase = zx_shape_43, .start = zx_shape_5, .token = zx_shape_15, .type_diagnostic = zx_shape_1, }, };

const zx_shape_46 = .{ .kind = .list, .child = zx_shape_44, };

const zx_shape_47 = .{ .kind = .object, .fields = .{ .control = zx_shape_45, .declarations = zx_shape_46, .members = zx_shape_24, .types = zx_shape_42, }, };

const zx_shape_48 = .{ .kind = .scalar, };

const zx_shape_49 = .{ .kind = .object, .fields = .{ .end = zx_shape_5, .start = zx_shape_5, .text = zx_shape_10, }, };

const zx_shape_50 = .{ .kind = .object, .fields = .{ .enumeration = zx_shape_1, .index = zx_shape_5, }, };

const zx_shape_51 = .{ .kind = .object, .fields = .{ .child = zx_shape_50, .count = zx_shape_5, .kind = zx_shape_48, .name = zx_shape_49, .position = zx_shape_5, }, };

const zx_shape_52 = .{ .kind = .object, .fields = .{ .name = zx_shape_49, .next = zx_shape_5, .value = zx_shape_50, }, };

const zx_shape_53 = .{ .kind = .object, .fields = .{ .next = zx_shape_5, .value = zx_shape_50, }, };

const zx_shape_54 = .{ .kind = .object, .fields = .{ .name = zx_shape_49, .value = zx_shape_50, }, };

const zx_shape_55 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, }, };

const zx_shape_56 = .{ .kind = .list, .child = zx_shape_51, };

const zx_shape_57 = .{ .kind = .list, .child = zx_shape_52, };

const zx_shape_58 = .{ .kind = .list, .child = zx_shape_53, };

const zx_shape_59 = .{ .kind = .list, .child = zx_shape_54, };

const zx_shape_60 = .{ .kind = .list, .child = zx_shape_55, };

const zx_shape_61 = .{ .kind = .list, .child = zx_shape_49, };

const zx_shape_62 = .{ .kind = .object, .fields = .{ .declarations = zx_shape_59, .enumerations = zx_shape_60, .fields = zx_shape_57, .items = zx_shape_58, .members = zx_shape_61, .nodes = zx_shape_56, }, };

const zx_shape_63 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_64 = .{ .kind = .object, .fields = .{ .bytes = zx_shape_63, .declarations = zx_shape_46, .members = zx_shape_24, .order = zx_shape_34, .types = zx_shape_38, }, };

const zx_shape_65 = .{ .kind = .optional, .child = zx_shape_62, };

const zx_shape_66 = .{ .kind = .object, .fields = .{ .indexed = zx_shape_64, .native = zx_shape_65, }, };

const zx_shape_67 = .{ .kind = .scalar, };

const zx_shape_68 = .{ .kind = .object, .fields = .{ .allocator_argument = zx_shape_1, .concurrent = zx_shape_1, .count = zx_shape_5, .error_count = zx_shape_5, .errors_present = zx_shape_1, .fallible = zx_shape_1, .first_error = zx_shape_5, .first_parameter = zx_shape_5, .io_argument = zx_shape_1, .name = zx_shape_14, .output = zx_shape_5, .process_argument = zx_shape_1, }, };

const zx_shape_69 = .{ .kind = .object, .fields = .{ .name = zx_shape_14, .value = zx_shape_5, }, };

const zx_shape_70 = .{ .kind = .object, .fields = .{ .current = zx_shape_68, .diagnostic = zx_shape_20, .index = zx_shape_5, .injected = zx_shape_5, .parameter = zx_shape_14, .phase = zx_shape_67, }, };

const zx_shape_71 = .{ .kind = .list, .child = zx_shape_68, };

const zx_shape_72 = .{ .kind = .list, .child = zx_shape_69, };

const zx_shape_73 = .{ .kind = .object, .fields = .{ .control = zx_shape_70, .declarations = zx_shape_47, .errors = zx_shape_24, .functions = zx_shape_71, .lexed = zx_shape_27, .parameters = zx_shape_72, }, };

const zx_shape_74 = .{ .kind = .object, .fields = .{ .declarations = zx_shape_46, .diagnostic = zx_shape_20, .errors = zx_shape_24, .functions = zx_shape_71, .members = zx_shape_24, .parameters = zx_shape_72, .type_order = zx_shape_34, .types = zx_shape_38, }, };

const zx_shape_75 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, .parameters = zx_shape_72, .source = zx_shape_66, }, };

const zx_shape_76 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_77 = .{ .kind = .optional, .child = zx_shape_10, };

const zx_shape_78 = .{ .kind = .list, .child = zx_shape_77, };

const zx_shape_79 = .{ .kind = .object, .fields = .{ .aliases = zx_shape_78, .enumerations = zx_shape_76, .nodes = zx_shape_33, }, };

const zx_shape_80 = .{ .kind = .object, .fields = .{ .names = zx_shape_78, .source = zx_shape_66, .valid = zx_shape_1, .work = zx_shape_79, }, };

const zx_shape_81 = .{ .kind = .object, .fields = .{ .names = zx_shape_78, .valid = zx_shape_1, }, };

const zx_shape_82 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_10, .@"1" = zx_shape_5, .@"2" = zx_shape_5, }, };

const zx_shape_83 = .{ .kind = .object, .fields = .{ .source = zx_shape_63, .span = zx_shape_14, }, };

const zx_shape_84 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .source = zx_shape_66, }, };

const zx_shape_85 = .{ .kind = .object, .fields = .{ .limit = zx_shape_5, .name = zx_shape_10, .source = zx_shape_66, }, };

const zx_shape_86 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .index = zx_shape_5, }, };

const zx_shape_87 = .{ .kind = .object, .fields = .{ .reference = zx_shape_50, .source = zx_shape_66, }, };

const zx_shape_88 = .{ .kind = .object, .fields = .{ .position = zx_shape_5, .source = zx_shape_66, }, };

const zx_shape_89 = .{ .kind = .object, .fields = .{ .left = zx_shape_10, .right = zx_shape_10, }, };

const zx_shape_90 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .object = zx_shape_1, .position = zx_shape_5, .source = zx_shape_66, }, };

const zx_shape_91 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .object = zx_shape_1, .position = zx_shape_5, .state = zx_shape_80, }, };

const zx_shape_92 = .{ .kind = .object, .fields = .{ .aliases = zx_shape_78, .enumerations = zx_shape_76, .input = zx_shape_75, .nodes = zx_shape_33, .remaining = zx_shape_5, }, };

const zx_shape_93 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_33, .@"1" = zx_shape_0, }, };

const zx_shape_94 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_76, .@"1" = zx_shape_0, }, };

const zx_shape_95 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_78, .@"1" = zx_shape_0, }, };

const zx_shape_96 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_63, .@"1" = zx_shape_63, }, };

const zx_shape_97 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .index = zx_shape_5, .limit = zx_shape_5, .name = zx_shape_10, .selected = zx_shape_5, .source = zx_shape_66, }, };

const zx_shape_98 = .{ .kind = .object, .fields = .{ .active = zx_shape_1, .reference = zx_shape_50, .source = zx_shape_66, .valid = zx_shape_1, }, };

const zx_shape_99 = .{ .kind = .object, .fields = .{ .equal = zx_shape_1, .index = zx_shape_5, .left = zx_shape_10, .limit = zx_shape_5, .right = zx_shape_10, }, };

const zx_shape_100 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_101 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .input = zx_shape_90, .names = zx_shape_100, .position = zx_shape_5, .positions = zx_shape_33, }, };

const zx_shape_102 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_100, .@"1" = zx_shape_0, }, };

const zx_shape_103 = .{ .kind = .object, .fields = .{ .building = zx_shape_1, .count = zx_shape_5, .names = zx_shape_100, .positions = zx_shape_33, .remaining = zx_shape_5, .root = zx_shape_5, .sifting = zx_shape_1, }, };

const zx_shape_104 = .{ .kind = .object, .fields = .{ .object = zx_shape_1, .positions = zx_shape_33, .remaining = zx_shape_5, .state = zx_shape_80, }, };

const zx_shape_105 = .{ .kind = .optional, .child = zx_shape_5, };

const zx_shape_106 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_33, .@"1" = zx_shape_105, }, };

const zx_shape_107 = .{ .kind = .optional, .child = zx_shape_1, };

const zx_shape_108 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_76, .@"1" = zx_shape_107, }, };

const zx_shape_109 = .{ .kind = .optional, .child = zx_shape_77, };

const zx_shape_110 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_78, .@"1" = zx_shape_109, }, };

const zx_shape_111 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_75, }, };

const zx_shape_112 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_75, .@"1" = zx_shape_80, }, };

const zx_shape_113 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_75, .@"1" = zx_shape_80, .@"2" = zx_shape_81, }, };

pub const input_shape = zx_shape_75;

pub const output_shape = zx_shape_81;

pub const Input = *const (zx_abi).zx_type_75;

pub const Output = *const (zx_abi).zx_type_81;

fn function_0(allocator: ((std).mem).Allocator, in: []const u8) error{ OutOfMemory, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).encodeBase64(allocator, in));

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: []const u8) error{ InvalidCharacter, InvalidPadding, NoSpaceLeft, OutOfMemory, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).decodeBase64(allocator, in));

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: []const u8) error{ OutOfMemory, Overflow, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).encodeHex(allocator, in));

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: []const u8) error{ InvalidCharacter, InvalidHex, InvalidLength, NoSpaceLeft, OutOfMemory, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).decodeHex(allocator, in));

    return native_result;
}

fn function_4(allocator: ((std).mem).Allocator, in: []const u8) error{ InvalidUtf8, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).encodeUtf8(in));

    _ = allocator;

    return native_result;
}

fn function_5(allocator: ((std).mem).Allocator, in: []const u8) error{ InvalidUtf8, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).decodeUtf8(in));

    _ = allocator;

    return native_result;
}

fn function_6(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_82) error{ InvalidRange, }![]const u8 {
    const native_result = (try ((zx_native_0).encoding).sliceBytes((in).@"0", (in).@"1", (in).@"2"));

    _ = allocator;

    return native_result;
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_75) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_80 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = block_73: {
        break :block_73 (try (allocator).dupe(u64, (&[_]u64{})));
    };
    const value_2: []const bool = block_72: {
        break :block_72 (try (allocator).dupe(bool, (&[_]bool{})));
    };
    const value_3: []const ?[]const u8 = block_71: {
        break :block_71 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{})));
    };
    const value_4: []const ?[]const u8 = (if (((in).count == @as(u64, 1))) block_68: {
        break :block_68 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{})));
    } else block_70: {
        const operand_69 = @as(?[]const u8, null);

        break :block_70 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{operand_69, })));
    });

    return block_67: {
        const state_type_2 = struct {
            fields: []const u64,
            heads: []const u64,
            items: []const u64,
        };
        const state_type_3 = struct {
            fields: []const *const (zx_abi).zx_type_31,
            items: []const *const (zx_abi).zx_type_32,
            nodes: []const *const (zx_abi).zx_type_30,
        };
        const state_type_4 = struct {
            bytes: []const u8,
            declarations: []const *const (zx_abi).zx_type_44,
            members: []const *const (zx_abi).zx_type_14,
            order: state_type_2,
            types: state_type_3,
        };
        const state_type_5 = struct {
            declarations: []const *const (zx_abi).zx_type_54,
            enumerations: []const *const (zx_abi).zx_type_55,
            fields: []const *const (zx_abi).zx_type_52,
            items: []const *const (zx_abi).zx_type_53,
            members: []const *const (zx_abi).zx_type_49,
            nodes: []const *const (zx_abi).zx_type_51,
        };
        const state_type_6 = struct {
            indexed: state_type_4,
            native: ?state_type_5,
        };
        const state_type_7 = struct {
            count: u64,
            first: u64,
            parameters: []const *const (zx_abi).zx_type_69,
            source: state_type_6,
        };
        const state_type_8 = struct {
            aliases: []const ?[]const u8,
            enumerations: []const bool,
            input: state_type_7,
            nodes: []const u64,
            remaining: u64,
        };
        const operand_19 = block_18: {
            const operand_11 = block_10: {
                const operand_9 = in;

                break :block_10 state_type_7{ .count = (operand_9).count, .first = (operand_9).first, .parameters = (operand_9).parameters, .source = state_type_6{ .indexed = state_type_4{ .bytes = (((operand_9).source).indexed).bytes, .declarations = (((operand_9).source).indexed).declarations, .members = (((operand_9).source).indexed).members, .order = state_type_2{ .fields = ((((operand_9).source).indexed).order).fields, .heads = ((((operand_9).source).indexed).order).heads, .items = ((((operand_9).source).indexed).order).items, }, .types = state_type_3{ .fields = ((((operand_9).source).indexed).types).fields, .items = ((((operand_9).source).indexed).types).items, .nodes = ((((operand_9).source).indexed).types).nodes, }, }, .native = @as(?state_type_5, (if ((((operand_9).source).native != null)) state_type_5{ .declarations = (((operand_9).source).native.?).declarations, .enumerations = (((operand_9).source).native.?).enumerations, .fields = (((operand_9).source).native.?).fields, .items = (((operand_9).source).native.?).items, .members = (((operand_9).source).native.?).members, .nodes = (((operand_9).source).native.?).nodes, } else null)), }, };
            };
            const operand_12 = value_1;
            const operand_13 = value_2;
            const operand_14 = value_3;
            const operand_17 = (block_16: {
                const operand_15 = in;

                break :block_16 state_type_7{ .count = (operand_15).count, .first = (operand_15).first, .parameters = (operand_15).parameters, .source = state_type_6{ .indexed = state_type_4{ .bytes = (((operand_15).source).indexed).bytes, .declarations = (((operand_15).source).indexed).declarations, .members = (((operand_15).source).indexed).members, .order = state_type_2{ .fields = ((((operand_15).source).indexed).order).fields, .heads = ((((operand_15).source).indexed).order).heads, .items = ((((operand_15).source).indexed).order).items, }, .types = state_type_3{ .fields = ((((operand_15).source).indexed).types).fields, .items = ((((operand_15).source).indexed).types).items, .nodes = ((((operand_15).source).indexed).types).nodes, }, }, .native = @as(?state_type_5, (if ((((operand_15).source).native != null)) state_type_5{ .declarations = (((operand_15).source).native.?).declarations, .enumerations = (((operand_15).source).native.?).enumerations, .fields = (((operand_15).source).native.?).fields, .items = (((operand_15).source).native.?).items, .members = (((operand_15).source).native.?).members, .nodes = (((operand_15).source).native.?).nodes, } else null)), }, };
            }).count;

            break :block_18 state_type_8{ .input = operand_11, .nodes = operand_12, .enumerations = operand_13, .aliases = operand_14, .remaining = operand_17, };
        };

        var state_capacity_21: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_22 = false;

        defer (state_capacity_21).deinit(allocator);

        var state_capacity_23: (std).ArrayList(bool) = .empty;

        var state_capacity_started_24 = false;

        defer (state_capacity_23).deinit(allocator);

        var state_capacity_25: (std).ArrayList(u64) = .empty;

        var state_capacity_started_26 = false;

        defer (state_capacity_25).deinit(allocator);

        const state_type_27 = struct { []const ?[]const u8, void, };
        const state_type_32 = struct { []const bool, void, };
        const state_type_37 = struct { []const u64, void, };
        const state_type_43 = struct {
            end: u64,
            start: u64,
        };
        const state_type_44 = struct {
            name: state_type_43,
            value: u64,
        };

        var state_1: state_type_8 = operand_19;

        var state_changed_20 = false;

        while (((state_1).remaining != @as(u64, 0))) {
            state_1 = block_50: {
                const value_7: u64 = (state_1).remaining;
                const value_8: state_type_8 = block_49: {
                    break :block_49 state_type_8{ .aliases = (state_1).aliases, .enumerations = (state_1).enumerations, .input = (state_1).input, .nodes = (state_1).nodes, .remaining = (value_7 - @as(u64, 1)), };
                };
                const value_9: state_type_8 = block_48: {
                    break :block_48 state_type_8{ .aliases = (value_8).aliases, .enumerations = (value_8).enumerations, .input = (value_8).input, .nodes = (block_47: {
                        const operand_38 = (value_8).nodes;
                        const operand_46 = (block_45: {
                            const operand_42 = block_41: {
                                const operand_39 = ((value_8).input).parameters;
                                const operand_40 = (((value_8).input).first + (value_8).remaining);

                                if ((operand_40 >= (operand_39).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_41 (operand_39)[@intCast(operand_40)];
                            };

                            break :block_45 state_type_44{ .name = state_type_43{ .end = ((operand_42).name).end, .start = ((operand_42).name).start, }, .value = (operand_42).value, };
                        }).value;

                        _ = (try ((std).math).add(usize, (operand_38).len, 1));

                        if ((!state_capacity_started_26)) {
                            (try (state_capacity_25).appendSlice(allocator, operand_38));

                            state_capacity_started_26 = true;
                        } else {
                            ((state_capacity_25).items).len = (operand_38).len;
                        }

                        (try (state_capacity_25).append(allocator, operand_46));

                        break :block_47 @as(state_type_37, .{ (state_capacity_25).items, {}, });
                    }).@"0", .remaining = (value_8).remaining, };
                };
                const value_10: state_type_8 = block_36: {
                    break :block_36 state_type_8{ .aliases = (value_9).aliases, .enumerations = (block_35: {
                        const operand_33 = (value_9).enumerations;
                        const operand_34 = false;

                        _ = (try ((std).math).add(usize, (operand_33).len, 1));

                        if ((!state_capacity_started_24)) {
                            (try (state_capacity_23).appendSlice(allocator, operand_33));

                            state_capacity_started_24 = true;
                        } else {
                            ((state_capacity_23).items).len = (operand_33).len;
                        }

                        (try (state_capacity_23).append(allocator, operand_34));

                        break :block_35 @as(state_type_32, .{ (state_capacity_23).items, {}, });
                    }).@"0", .input = (value_9).input, .nodes = (value_9).nodes, .remaining = (value_9).remaining, };
                };
                const value_11: state_type_8 = block_31: {
                    break :block_31 state_type_8{ .aliases = (block_30: {
                        const operand_28 = (value_10).aliases;
                        const operand_29 = @as(?[]const u8, null);

                        _ = (try ((std).math).add(usize, (operand_28).len, 1));

                        if ((!state_capacity_started_22)) {
                            (try (state_capacity_21).appendSlice(allocator, operand_28));

                            state_capacity_started_22 = true;
                        } else {
                            ((state_capacity_21).items).len = (operand_28).len;
                        }

                        (try (state_capacity_21).append(allocator, operand_29));

                        break :block_30 @as(state_type_27, .{ (state_capacity_21).items, {}, });
                    }).@"0", .enumerations = (value_10).enumerations, .input = (value_10).input, .nodes = (value_10).nodes, .remaining = (value_10).remaining, };
                };

                break :block_50 value_11;
            };

            state_changed_20 = true;
        }

        var state_owned_51: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_51);

        if (state_capacity_started_22) {
            ((state_capacity_21).items).len = ((state_1).aliases).len;

            state_owned_51 = (try (state_capacity_21).toOwnedSlice(allocator));
        }

        if (state_capacity_started_22) {
            (state_1).aliases = state_owned_51;
        }

        var state_owned_52: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_52);

        if (state_capacity_started_24) {
            ((state_capacity_23).items).len = ((state_1).enumerations).len;

            state_owned_52 = (try (state_capacity_23).toOwnedSlice(allocator));
        }

        if (state_capacity_started_24) {
            (state_1).enumerations = state_owned_52;
        }

        var state_owned_53: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_53);

        if (state_capacity_started_26) {
            ((state_capacity_25).items).len = ((state_1).nodes).len;

            state_owned_53 = (try (state_capacity_25).toOwnedSlice(allocator));
        }

        if (state_capacity_started_26) {
            (state_1).nodes = state_owned_53;
        }

        break :block_67 block_66: {
            const operand_54 = (in).source;
            const operand_55 = block_61: {
                const operand_56 = (state_1).nodes;
                const operand_57 = (state_1).enumerations;
                const operand_58 = (state_1).aliases;

                break :block_61 block_60: {
                    const operand_59 = (try (allocator).create((zx_abi).zx_type_79));

                    (operand_59).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_56, .enumerations = operand_57, .aliases = operand_58, });

                    break :block_60 @as(*const (zx_abi).zx_type_79, operand_59);
                };
            };
            const operand_62 = value_4;
            const operand_63 = true;

            break :block_66 block_65: {
                const operand_64 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_64).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .source = operand_54, .work = operand_55, .names = operand_62, .valid = operand_63, });

                break :block_65 @as(*const (zx_abi).zx_type_80, operand_64);
            };
        };
    };
}

fn function_7_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_75_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = block_131: {
        break :block_131 (try (allocator).dupe(u64, (&[_]u64{})));
    };
    const value_2: []const bool = block_130: {
        break :block_130 (try (allocator).dupe(bool, (&[_]bool{})));
    };
    const value_3: []const ?[]const u8 = block_129: {
        break :block_129 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{})));
    };
    const value_4: []const ?[]const u8 = (if (((in).count == @as(u64, 1))) block_126: {
        break :block_126 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{})));
    } else block_128: {
        const operand_127 = @as(?[]const u8, null);

        break :block_128 (try (allocator).dupe(?[]const u8, (&[_]?[]const u8{operand_127, })));
    });
    const value_12: (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba = block_125: {
        const operand_95 = block_94: {
            const operand_86 = in;
            const operand_87 = block_88: {
                break :block_88 value_1;
            };
            const operand_89 = block_90: {
                break :block_90 value_2;
            };
            const operand_91 = block_92: {
                break :block_92 value_3;
            };
            const operand_93 = (in).count;

            break :block_94 @as((zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba, (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba{ .input = operand_86, .nodes = operand_87, .enumerations = operand_89, .aliases = operand_91, .remaining = operand_93, });
        };

        var state_capacity_97: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_98 = false;

        defer (state_capacity_97).deinit(allocator);

        var state_capacity_99: (std).ArrayList(bool) = .empty;

        var state_capacity_started_100 = false;

        defer (state_capacity_99).deinit(allocator);

        var state_capacity_101: (std).ArrayList(u64) = .empty;

        var state_capacity_started_102 = false;

        defer (state_capacity_101).deinit(allocator);

        var state_85: (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba = operand_95;

        var state_changed_96 = false;

        while (((state_85).remaining != @as(u64, 0))) {
            state_85 = block_120: {
                const value_7: u64 = (state_85).remaining;
                const value_8: (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba = block_119: {
                    break :block_119 @as((zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba, (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba{ .aliases = (state_85).aliases, .enumerations = (state_85).enumerations, .input = (state_85).input, .nodes = (state_85).nodes, .remaining = (block_118: {
                        break :block_118 value_7;
                    } - @as(u64, 1)), });
                };
                const value_9: (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba = block_117: {
                    break :block_117 @as((zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba, (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba{ .aliases = (value_8).aliases, .enumerations = (value_8).enumerations, .input = (value_8).input, .nodes = (block_116: {
                        const operand_111 = (value_8).nodes;
                        const operand_115 = (block_114: {
                            const operand_112 = ((value_8).input).parameters;
                            const operand_113 = (((value_8).input).first + (value_8).remaining);

                            if ((operand_113 >= (operand_112).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_114 (operand_112)[@intCast(operand_113)];
                        }).value;

                        _ = (try ((std).math).add(usize, (operand_111).len, 1));

                        if ((!state_capacity_started_102)) {
                            (try (state_capacity_101).appendSlice(allocator, operand_111));

                            state_capacity_started_102 = true;
                        } else {
                            ((state_capacity_101).items).len = (operand_111).len;
                        }

                        (try (state_capacity_101).append(allocator, operand_115));

                        break :block_116 @as((zx_abi).value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_101).items, {}, null, });
                    }).@"0", .remaining = (value_8).remaining, });
                };
                const value_10: (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba = block_110: {
                    break :block_110 @as((zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba, (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba{ .aliases = (value_9).aliases, .enumerations = (block_109: {
                        const operand_107 = (value_9).enumerations;
                        const operand_108 = false;

                        _ = (try ((std).math).add(usize, (operand_107).len, 1));

                        if ((!state_capacity_started_100)) {
                            (try (state_capacity_99).appendSlice(allocator, operand_107));

                            state_capacity_started_100 = true;
                        } else {
                            ((state_capacity_99).items).len = (operand_107).len;
                        }

                        (try (state_capacity_99).append(allocator, operand_108));

                        break :block_109 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_99).items, {}, null, });
                    }).@"0", .input = (value_9).input, .nodes = (value_9).nodes, .remaining = (value_9).remaining, });
                };
                const value_11: (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba = block_106: {
                    break :block_106 @as((zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba, (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba{ .aliases = (block_105: {
                        const operand_103 = (value_10).aliases;
                        const operand_104 = @as(?[]const u8, null);

                        _ = (try ((std).math).add(usize, (operand_103).len, 1));

                        if ((!state_capacity_started_98)) {
                            (try (state_capacity_97).appendSlice(allocator, operand_103));

                            state_capacity_started_98 = true;
                        } else {
                            ((state_capacity_97).items).len = (operand_103).len;
                        }

                        (try (state_capacity_97).append(allocator, operand_104));

                        break :block_105 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_97).items, {}, null, });
                    }).@"0", .enumerations = (value_10).enumerations, .input = (value_10).input, .nodes = (value_10).nodes, .remaining = (value_10).remaining, });
                };

                break :block_120 value_11;
            };

            state_changed_96 = true;
        }

        var state_owned_121: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_121);

        if (state_capacity_started_98) {
            ((state_capacity_97).items).len = ((state_85).aliases).len;

            state_owned_121 = (try (state_capacity_97).toOwnedSlice(allocator));
        }

        if (state_capacity_started_98) {
            state_85 = (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba{ .aliases = state_owned_121, .enumerations = (state_85).enumerations, .input = (state_85).input, .nodes = (state_85).nodes, .remaining = (state_85).remaining, };
        }

        var state_owned_122: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_122);

        if (state_capacity_started_100) {
            ((state_capacity_99).items).len = ((state_85).enumerations).len;

            state_owned_122 = (try (state_capacity_99).toOwnedSlice(allocator));
        }

        if (state_capacity_started_100) {
            state_85 = (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba{ .aliases = (state_85).aliases, .enumerations = state_owned_122, .input = (state_85).input, .nodes = (state_85).nodes, .remaining = (state_85).remaining, };
        }

        var state_owned_123: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_123);

        if (state_capacity_started_102) {
            ((state_capacity_101).items).len = ((state_85).nodes).len;

            state_owned_123 = (try (state_capacity_101).toOwnedSlice(allocator));
        }

        if (state_capacity_started_102) {
            state_85 = (zx_abi).value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba{ .aliases = (state_85).aliases, .enumerations = (state_85).enumerations, .input = (state_85).input, .nodes = state_owned_123, .remaining = (state_85).remaining, };
        }

        break :block_125 (if (state_changed_96) state_85 else operand_95);
    };

    return block_84: {
        const operand_75 = (in).source;
        const operand_76 = block_80: {
            const operand_77 = (value_12).nodes;
            const operand_78 = (value_12).enumerations;
            const operand_79 = (value_12).aliases;

            break :block_80 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_77, .enumerations = operand_78, .aliases = operand_79, });
        };
        const operand_81 = block_82: {
            break :block_82 value_4;
        };
        const operand_83 = true;

        break :block_84 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .source = operand_75, .work = operand_76, .names = operand_81, .valid = operand_83, });
    };
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_66) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: ?*const (zx_abi).zx_type_62 = (in).native;

    return (if ((value_1 != null)) @as(u64, ((value_1.?).declarations).len) else @as(u64, (((in).indexed).declarations).len));
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_83) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_49 {
    @setRuntimeSafety(true);

    const value_1: []const u8 = (try function_5(allocator, block_14: {
        const operand_7 = (in).source;
        const operand_8 = ((in).span).start;
        const operand_9 = (((in).span).end - ((in).span).start);
        const operand_11 = block_10: {
            break :block_10 (try (allocator).dupe(u8, (&[_]u8{})));
        };

        if (((operand_8 > (operand_7).len) or (operand_9 > ((operand_7).len - operand_8)))) {
            return error.IndexOutOfBounds;
        }

        const operand_12 = @as(usize, @intCast(operand_8));
        const operand_13 = @as(usize, @intCast(operand_9));

        _ = (try ((std).math).add(usize, ((operand_7).len - operand_13), (operand_11).len));

        break :block_14 (operand_7)[operand_12..(operand_12 + operand_13)];
    }));

    return block_6: {
        const operand_1 = value_1;
        const operand_2 = ((in).span).start;
        const operand_3 = ((in).span).end;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create((zx_abi).zx_type_49));

            (operand_4).* = @as((zx_abi).zx_type_49, (zx_abi).zx_type_49{ .text = operand_1, .start = operand_2, .end = operand_3, });

            break :block_5 @as(*const (zx_abi).zx_type_49, operand_4);
        };
    };
}

fn function_9_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_83) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).zx_type_49 {
    @setRuntimeSafety(true);

    const value_1: []const u8 = (try function_5(allocator, block_26: {
        const operand_19 = (in).source;
        const operand_20 = ((in).span).start;
        const operand_21 = (((in).span).end - ((in).span).start);
        const operand_23 = block_22: {
            break :block_22 (try (allocator).dupe(u8, (&[_]u8{})));
        };

        if (((operand_20 > (operand_19).len) or (operand_21 > ((operand_19).len - operand_20)))) {
            return error.IndexOutOfBounds;
        }

        const operand_24 = @as(usize, @intCast(operand_20));
        const operand_25 = @as(usize, @intCast(operand_21));

        _ = (try ((std).math).add(usize, ((operand_19).len - operand_25), (operand_23).len));

        break :block_26 (operand_19)[operand_24..(operand_24 + operand_25)];
    }));

    return block_18: {
        const operand_15 = value_1;
        const operand_16 = ((in).span).start;
        const operand_17 = ((in).span).end;

        break :block_18 (zx_abi).zx_type_49{ .text = operand_15, .start = operand_16, .end = operand_17, };
    };
}

fn function_10(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_84) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_54 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return block_25: {
            const operand_23 = (value_1.?).declarations;
            const operand_24 = (in).index;

            if ((operand_24 >= (operand_23).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_25 (operand_23)[@intCast(operand_24)];
        };
    }

    const value_2: *const (zx_abi).zx_type_44 = block_22: {
        const operand_20 = (((in).source).indexed).declarations;
        const operand_21 = (in).index;

        if ((operand_21 >= (operand_20).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_22 (operand_20)[@intCast(operand_21)];
    };

    return block_19: {
        const operand_1 = block_10: {
            const operand_7 = (try function_9_value(allocator, block_6: {
                const operand_2 = (((in).source).indexed).bytes;
                const operand_3 = (value_2).name;

                break :block_6 block_5: {
                    const operand_4 = (try (allocator).create((zx_abi).zx_type_83));

                    (operand_4).* = @as((zx_abi).zx_type_83, (zx_abi).zx_type_83{ .source = operand_2, .span = operand_3, });

                    break :block_5 @as(*const (zx_abi).zx_type_83, operand_4);
                };
            }));

            break :block_10 block_9: {
                const operand_8 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_8).* = @as((zx_abi).zx_type_49, operand_7);

                break :block_9 @as(*const (zx_abi).zx_type_49, operand_8);
            };
        };
        const operand_11 = block_16: {
            const operand_12 = (value_2).enumeration;
            const operand_13 = (if ((value_2).enumeration) (in).index else (value_2).value);

            break :block_16 block_15: {
                const operand_14 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_14).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_12, .index = operand_13, });

                break :block_15 @as(*const (zx_abi).zx_type_50, operand_14);
            };
        };

        break :block_19 block_18: {
            const operand_17 = (try (allocator).create((zx_abi).zx_type_54));

            (operand_17).* = @as((zx_abi).zx_type_54, (zx_abi).zx_type_54{ .name = operand_1, .value = operand_11, });

            break :block_18 @as(*const (zx_abi).zx_type_54, operand_17);
        };
    };
}

fn function_10_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_84) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).zx_type_54 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return (block_48: {
            const operand_46 = (value_1.?).declarations;
            const operand_47 = (in).index;

            if ((operand_47 >= (operand_46).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_48 (operand_46)[@intCast(operand_47)];
        }).*;
    }

    const value_2: (zx_abi).zx_type_44 = (block_45: {
        const operand_43 = (((in).source).indexed).declarations;
        const operand_44 = (in).index;

        if ((operand_44 >= (operand_43).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_45 (operand_43)[@intCast(operand_44)];
    }).*;

    return block_42: {
        const operand_26 = block_35: {
            const operand_32 = (try function_9_value(allocator, block_31: {
                const operand_27 = (((in).source).indexed).bytes;
                const operand_28 = ((&value_2)).name;

                break :block_31 block_30: {
                    const operand_29 = (try (allocator).create((zx_abi).zx_type_83));

                    (operand_29).* = @as((zx_abi).zx_type_83, (zx_abi).zx_type_83{ .source = operand_27, .span = operand_28, });

                    break :block_30 @as(*const (zx_abi).zx_type_83, operand_29);
                };
            }));

            break :block_35 block_34: {
                const operand_33 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_33).* = @as((zx_abi).zx_type_49, operand_32);

                break :block_34 @as(*const (zx_abi).zx_type_49, operand_33);
            };
        };
        const operand_36 = block_41: {
            const operand_37 = ((&value_2)).enumeration;
            const operand_38 = (if (((&value_2)).enumeration) (in).index else ((&value_2)).value);

            break :block_41 block_40: {
                const operand_39 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_39).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_37, .index = operand_38, });

                break :block_40 @as(*const (zx_abi).zx_type_50, operand_39);
            };
        };

        break :block_42 (zx_abi).zx_type_54{ .name = operand_26, .value = operand_36, };
    };
}

fn function_11(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_85) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_86 {
    @setRuntimeSafety(true);

    const value_8: *const (zx_abi).zx_type_97 = block_61: {
        const operand_17 = block_16: {
            const operand_8 = (in).source;
            const operand_9 = (in).name;
            const operand_10 = (in).limit;
            const operand_11 = @as(u64, 0);
            const operand_12 = false;
            const operand_13 = @as(u64, 0);

            break :block_16 block_15: {
                const operand_14 = (try (allocator).create((zx_abi).zx_type_97));

                (operand_14).* = @as((zx_abi).zx_type_97, (zx_abi).zx_type_97{ .source = operand_8, .name = operand_9, .limit = operand_10, .index = operand_11, .found = operand_12, .selected = operand_13, });

                break :block_15 @as(*const (zx_abi).zx_type_97, operand_14);
            };
        };

        var state_7: (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c{ .found = (operand_17).found, .index = (operand_17).index, .limit = (operand_17).limit, .name = (operand_17).name, .selected = (operand_17).selected, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((operand_17).source).indexed).bytes, .declarations = (((operand_17).source).indexed).declarations, .members = (((operand_17).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_17).source).indexed).order).fields, .heads = ((((operand_17).source).indexed).order).heads, .items = ((((operand_17).source).indexed).order).items, .zx_origin = (((operand_17).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_17).source).indexed).types).fields, .items = ((((operand_17).source).indexed).types).items, .nodes = ((((operand_17).source).indexed).types).nodes, .zx_origin = (((operand_17).source).indexed).types, }, .zx_origin = ((operand_17).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if ((((operand_17).source).native != null)) block_46: {
            break :block_46 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = (((operand_17).source).native.?).declarations, .enumerations = (((operand_17).source).native.?).enumerations, .fields = (((operand_17).source).native.?).fields, .items = (((operand_17).source).native.?).items, .members = (((operand_17).source).native.?).members, .nodes = (((operand_17).source).native.?).nodes, .zx_origin = ((operand_17).source).native.?, };
        } else null)), .zx_origin = (operand_17).source, }, .zx_origin = operand_17, };

        var state_changed_18 = false;

        while (((!(state_7).found) and ((state_7).index < (state_7).limit))) {
            state_7 = block_45: {
                const value_3: *const (zx_abi).zx_type_54 = block_44: {
                    const operand_30 = block_29: {
                        const operand_27 = (state_7).source;
                        const operand_28 = (state_7).index;

                        break :block_29 @as((zx_abi).value_zx_type_84_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_84_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_27, .index = operand_28, });
                    };

                    break :block_44 (try function_10(allocator, (if (((operand_30).zx_origin != null)) (operand_30).zx_origin.? else block_43: {
                        const operand_42 = (try (allocator).create((zx_abi).zx_type_84));

                        (operand_42).* = (zx_abi).zx_type_84{ .index = (operand_30).index, .source = (if ((((operand_30).source).zx_origin != null)) ((operand_30).source).zx_origin.? else block_41: {
                            const operand_40 = (try (allocator).create((zx_abi).zx_type_66));

                            (operand_40).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_30).source).indexed).zx_origin != null)) (((operand_30).source).indexed).zx_origin.? else block_36: {
                                const operand_35 = (try (allocator).create((zx_abi).zx_type_64));

                                (operand_35).* = (zx_abi).zx_type_64{ .bytes = (((operand_30).source).indexed).bytes, .declarations = (((operand_30).source).indexed).declarations, .members = (((operand_30).source).indexed).members, .order = (if ((((((operand_30).source).indexed).order).zx_origin != null)) ((((operand_30).source).indexed).order).zx_origin.? else block_32: {
                                    const operand_31 = (try (allocator).create((zx_abi).zx_type_34));

                                    (operand_31).* = (zx_abi).zx_type_34{ .fields = ((((operand_30).source).indexed).order).fields, .heads = ((((operand_30).source).indexed).order).heads, .items = ((((operand_30).source).indexed).order).items, };

                                    break :block_32 @as(*const (zx_abi).zx_type_34, operand_31);
                                }), .types = (if ((((((operand_30).source).indexed).types).zx_origin != null)) ((((operand_30).source).indexed).types).zx_origin.? else block_34: {
                                    const operand_33 = (try (allocator).create((zx_abi).zx_type_38));

                                    (operand_33).* = (zx_abi).zx_type_38{ .fields = ((((operand_30).source).indexed).types).fields, .items = ((((operand_30).source).indexed).types).items, .nodes = ((((operand_30).source).indexed).types).nodes, };

                                    break :block_34 @as(*const (zx_abi).zx_type_38, operand_33);
                                }), };

                                break :block_36 @as(*const (zx_abi).zx_type_64, operand_35);
                            }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_30).source).native != null)) block_39: {
                                break :block_39 (if (((((operand_30).source).native.?).zx_origin != null)) (((operand_30).source).native.?).zx_origin.? else block_38: {
                                    const operand_37 = (try (allocator).create((zx_abi).zx_type_62));

                                    (operand_37).* = (zx_abi).zx_type_62{ .declarations = (((operand_30).source).native.?).declarations, .enumerations = (((operand_30).source).native.?).enumerations, .fields = (((operand_30).source).native.?).fields, .items = (((operand_30).source).native.?).items, .members = (((operand_30).source).native.?).members, .nodes = (((operand_30).source).native.?).nodes, };

                                    break :block_38 @as(*const (zx_abi).zx_type_62, operand_37);
                                });
                            } else null)), };

                            break :block_41 @as(*const (zx_abi).zx_type_66, operand_40);
                        }), };

                        break :block_43 @as(*const (zx_abi).zx_type_84, operand_42);
                    })));
                };
                const value_4: (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = block_26: {
                    break :block_26 @as((zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c, (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c{ .found = block_25: {
                        const operand_23 = ((block_22: {
                            break :block_22 value_3;
                        }).name).text;
                        const operand_24 = (state_7).name;

                        break :block_25 ((std).mem).eql(u8, operand_23, operand_24);
                    }, .index = (state_7).index, .limit = (state_7).limit, .name = (state_7).name, .selected = (state_7).selected, .source = (state_7).source, });
                };
                const value_5: (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = block_21: {
                    break :block_21 @as((zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c, (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c{ .found = (value_4).found, .index = (value_4).index, .limit = (value_4).limit, .name = (value_4).name, .selected = (value_4).index, .source = (value_4).source, });
                };
                const value_6: u64 = (value_5).index;
                const value_7: (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = block_20: {
                    break :block_20 @as((zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c, (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c{ .found = (value_5).found, .index = (block_19: {
                        break :block_19 value_6;
                    } + @as(u64, 1)), .limit = (value_5).limit, .name = (value_5).name, .selected = (value_5).selected, .source = (value_5).source, });
                };

                break :block_45 value_7;
            };

            state_changed_18 = true;
        }

        break :block_61 (if (state_changed_18) block_60: {
            break :block_60 (if (((state_7).zx_origin != null)) (state_7).zx_origin.? else block_59: {
                const operand_58 = (try (allocator).create((zx_abi).zx_type_97));

                (operand_58).* = (zx_abi).zx_type_97{ .found = (state_7).found, .index = (state_7).index, .limit = (state_7).limit, .name = (state_7).name, .selected = (state_7).selected, .source = (if ((((state_7).source).zx_origin != null)) ((state_7).source).zx_origin.? else block_57: {
                    const operand_56 = (try (allocator).create((zx_abi).zx_type_66));

                    (operand_56).* = (zx_abi).zx_type_66{ .indexed = (if (((((state_7).source).indexed).zx_origin != null)) (((state_7).source).indexed).zx_origin.? else block_52: {
                        const operand_51 = (try (allocator).create((zx_abi).zx_type_64));

                        (operand_51).* = (zx_abi).zx_type_64{ .bytes = (((state_7).source).indexed).bytes, .declarations = (((state_7).source).indexed).declarations, .members = (((state_7).source).indexed).members, .order = (if ((((((state_7).source).indexed).order).zx_origin != null)) ((((state_7).source).indexed).order).zx_origin.? else block_48: {
                            const operand_47 = (try (allocator).create((zx_abi).zx_type_34));

                            (operand_47).* = (zx_abi).zx_type_34{ .fields = ((((state_7).source).indexed).order).fields, .heads = ((((state_7).source).indexed).order).heads, .items = ((((state_7).source).indexed).order).items, };

                            break :block_48 @as(*const (zx_abi).zx_type_34, operand_47);
                        }), .types = (if ((((((state_7).source).indexed).types).zx_origin != null)) ((((state_7).source).indexed).types).zx_origin.? else block_50: {
                            const operand_49 = (try (allocator).create((zx_abi).zx_type_38));

                            (operand_49).* = (zx_abi).zx_type_38{ .fields = ((((state_7).source).indexed).types).fields, .items = ((((state_7).source).indexed).types).items, .nodes = ((((state_7).source).indexed).types).nodes, };

                            break :block_50 @as(*const (zx_abi).zx_type_38, operand_49);
                        }), };

                        break :block_52 @as(*const (zx_abi).zx_type_64, operand_51);
                    }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((state_7).source).native != null)) block_55: {
                        break :block_55 (if (((((state_7).source).native.?).zx_origin != null)) (((state_7).source).native.?).zx_origin.? else block_54: {
                            const operand_53 = (try (allocator).create((zx_abi).zx_type_62));

                            (operand_53).* = (zx_abi).zx_type_62{ .declarations = (((state_7).source).native.?).declarations, .enumerations = (((state_7).source).native.?).enumerations, .fields = (((state_7).source).native.?).fields, .items = (((state_7).source).native.?).items, .members = (((state_7).source).native.?).members, .nodes = (((state_7).source).native.?).nodes, };

                            break :block_54 @as(*const (zx_abi).zx_type_62, operand_53);
                        });
                    } else null)), };

                    break :block_57 @as(*const (zx_abi).zx_type_66, operand_56);
                }), };

                break :block_59 @as(*const (zx_abi).zx_type_97, operand_58);
            });
        } else operand_17);
    };

    return block_6: {
        const operand_2 = (value_8).found;
        const operand_3 = (value_8).selected;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create((zx_abi).zx_type_86));

            (operand_4).* = @as((zx_abi).zx_type_86, (zx_abi).zx_type_86{ .found = operand_2, .index = operand_3, });

            break :block_5 @as(*const (zx_abi).zx_type_86, operand_4);
        };
    };
}

fn function_11_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_85_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_86_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_8: (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = block_98: {
        const operand_74 = block_73: {
            const operand_67 = (in).source;
            const operand_68 = (in).name;
            const operand_69 = (in).limit;
            const operand_70 = @as(u64, 0);
            const operand_71 = false;
            const operand_72 = @as(u64, 0);

            break :block_73 @as((zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c, (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c{ .source = operand_67, .name = operand_68, .limit = operand_69, .index = operand_70, .found = operand_71, .selected = operand_72, });
        };

        var state_66: (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = operand_74;

        var state_changed_75 = false;

        while (((!(state_66).found) and ((state_66).index < (state_66).limit))) {
            state_66 = block_96: {
                const value_3: (zx_abi).zx_type_54 = block_95: {
                    const operand_87 = block_86: {
                        const operand_84 = (state_66).source;
                        const operand_85 = (state_66).index;

                        break :block_86 @as((zx_abi).value_zx_type_84_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_84_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_84, .index = operand_85, });
                    };

                    var state_borrow_88: (zx_abi).zx_type_34 = undefined;

                    state_borrow_88 = (zx_abi).zx_type_34{ .fields = ((((operand_87).source).indexed).order).fields, .heads = ((((operand_87).source).indexed).order).heads, .items = ((((operand_87).source).indexed).order).items, };

                    var state_borrow_89: (zx_abi).zx_type_38 = undefined;

                    state_borrow_89 = (zx_abi).zx_type_38{ .fields = ((((operand_87).source).indexed).types).fields, .items = ((((operand_87).source).indexed).types).items, .nodes = ((((operand_87).source).indexed).types).nodes, };

                    var state_borrow_90: (zx_abi).zx_type_64 = undefined;

                    state_borrow_90 = (zx_abi).zx_type_64{ .bytes = (((operand_87).source).indexed).bytes, .declarations = (((operand_87).source).indexed).declarations, .members = (((operand_87).source).indexed).members, .order = (((((operand_87).source).indexed).order).zx_origin orelse (&state_borrow_88)), .types = (((((operand_87).source).indexed).types).zx_origin orelse (&state_borrow_89)), };

                    var state_borrow_91: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_93: (zx_abi).zx_type_66 = undefined;

                    state_borrow_93 = (zx_abi).zx_type_66{ .indexed = ((((operand_87).source).indexed).zx_origin orelse (&state_borrow_90)), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_87).source).native != null)) block_92: {
                        state_borrow_91 = (zx_abi).zx_type_62{ .declarations = (((operand_87).source).native.?).declarations, .enumerations = (((operand_87).source).native.?).enumerations, .fields = (((operand_87).source).native.?).fields, .items = (((operand_87).source).native.?).items, .members = (((operand_87).source).native.?).members, .nodes = (((operand_87).source).native.?).nodes, };

                        break :block_92 ((((operand_87).source).native.?).zx_origin orelse (&state_borrow_91));
                    } else null)), };

                    var state_borrow_94: (zx_abi).zx_type_84 = undefined;

                    state_borrow_94 = (zx_abi).zx_type_84{ .index = (operand_87).index, .source = (((operand_87).source).zx_origin orelse (&state_borrow_93)), };

                    break :block_95 (try function_10_value(allocator, ((operand_87).zx_origin orelse (&state_borrow_94))));
                };
                const value_4: (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = block_83: {
                    break :block_83 @as((zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c, (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c{ .found = block_82: {
                        const operand_80 = ((block_79: {
                            break :block_79 (&value_3);
                        }).name).text;
                        const operand_81 = (state_66).name;

                        break :block_82 ((std).mem).eql(u8, operand_80, operand_81);
                    }, .index = (state_66).index, .limit = (state_66).limit, .name = (state_66).name, .selected = (state_66).selected, .source = (state_66).source, });
                };
                const value_5: (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = block_78: {
                    break :block_78 @as((zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c, (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c{ .found = (value_4).found, .index = (value_4).index, .limit = (value_4).limit, .name = (value_4).name, .selected = (value_4).index, .source = (value_4).source, });
                };
                const value_6: u64 = (value_5).index;
                const value_7: (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = block_77: {
                    break :block_77 @as((zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c, (zx_abi).value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c{ .found = (value_5).found, .index = (block_76: {
                        break :block_76 value_6;
                    } + @as(u64, 1)), .limit = (value_5).limit, .name = (value_5).name, .selected = (value_5).selected, .source = (value_5).source, });
                };

                break :block_96 value_7;
            };

            state_changed_75 = true;
        }

        break :block_98 (if (state_changed_75) state_66 else operand_74);
    };

    return block_65: {
        const operand_63 = (value_8).found;
        const operand_64 = (value_8).selected;

        break :block_65 @as((zx_abi).value_zx_type_86_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_86_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .found = operand_63, .index = operand_64, });
    };
}

fn function_12(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_87) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_51 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if (((in).reference).enumeration) {
        const value_2: u64 = (if ((value_1 != null)) (block_55: {
            const operand_53 = (value_1.?).enumerations;
            const operand_54 = ((in).reference).index;

            if ((operand_54 >= (operand_53).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_55 (operand_53)[@intCast(operand_54)];
        }).count else (block_58: {
            const operand_56 = (((in).source).indexed).declarations;
            const operand_57 = ((in).reference).index;

            if ((operand_57 >= (operand_56).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_58 (operand_56)[@intCast(operand_57)];
        }).count);

        return block_52: {
            const operand_34 = @as((zx_abi).zx_type_48, .Enumeration);
            const operand_35 = block_41: {
                const operand_36 = @as([]const u8, "");
                const operand_37 = @as(u64, 0);
                const operand_38 = @as(u64, 0);

                break :block_41 block_40: {
                    const operand_39 = (try (allocator).create((zx_abi).zx_type_49));

                    (operand_39).* = @as((zx_abi).zx_type_49, (zx_abi).zx_type_49{ .text = operand_36, .start = operand_37, .end = operand_38, });

                    break :block_40 @as(*const (zx_abi).zx_type_49, operand_39);
                };
            };
            const operand_42 = block_47: {
                const operand_43 = false;
                const operand_44 = @as(u64, 0);

                break :block_47 block_46: {
                    const operand_45 = (try (allocator).create((zx_abi).zx_type_50));

                    (operand_45).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_43, .index = operand_44, });

                    break :block_46 @as(*const (zx_abi).zx_type_50, operand_45);
                };
            };
            const operand_48 = value_2;
            const operand_49 = @as(u64, 0);

            break :block_52 block_51: {
                const operand_50 = (try (allocator).create((zx_abi).zx_type_51));

                (operand_50).* = @as((zx_abi).zx_type_51, (zx_abi).zx_type_51{ .kind = operand_34, .name = operand_35, .child = operand_42, .count = operand_48, .position = operand_49, });

                break :block_51 @as(*const (zx_abi).zx_type_51, operand_50);
            };
        };
    }

    if ((value_1 != null)) {
        return block_33: {
            const operand_31 = (value_1.?).nodes;
            const operand_32 = ((in).reference).index;

            if ((operand_32 >= (operand_31).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_33 (operand_31)[@intCast(operand_32)];
        };
    }

    const value_3: *const (zx_abi).zx_type_30 = block_30: {
        const operand_28 = ((((in).source).indexed).types).nodes;
        const operand_29 = ((in).reference).index;

        if ((operand_29 >= (operand_28).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_30 (operand_28)[@intCast(operand_29)];
    };
    const value_4: (zx_abi).zx_type_48 = block_27: {
        const operand_26 = (value_3).kind;

        break :block_27 (if ((operand_26 == @as((zx_abi).zx_type_28, .Named))) @as((zx_abi).zx_type_48, .Named) else (if ((operand_26 == @as((zx_abi).zx_type_28, .Object))) @as((zx_abi).zx_type_48, .Object) else (if ((operand_26 == @as((zx_abi).zx_type_28, .Optional))) @as((zx_abi).zx_type_48, .Optional) else (if ((operand_26 == @as((zx_abi).zx_type_28, .List))) @as((zx_abi).zx_type_48, .List) else (if ((operand_26 == @as((zx_abi).zx_type_28, .Tuple))) @as((zx_abi).zx_type_48, .Tuple) else @as((zx_abi).zx_type_48, .Application))))));
    };

    return block_25: {
        const operand_1 = value_4;
        const operand_2 = block_11: {
            const operand_8 = (try function_9_value(allocator, block_7: {
                const operand_3 = (((in).source).indexed).bytes;
                const operand_4 = (value_3).name;

                break :block_7 block_6: {
                    const operand_5 = (try (allocator).create((zx_abi).zx_type_83));

                    (operand_5).* = @as((zx_abi).zx_type_83, (zx_abi).zx_type_83{ .source = operand_3, .span = operand_4, });

                    break :block_6 @as(*const (zx_abi).zx_type_83, operand_5);
                };
            }));

            break :block_11 block_10: {
                const operand_9 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_9).* = @as((zx_abi).zx_type_49, operand_8);

                break :block_10 @as(*const (zx_abi).zx_type_49, operand_9);
            };
        };
        const operand_12 = block_17: {
            const operand_13 = false;
            const operand_14 = (value_3).child;

            break :block_17 block_16: {
                const operand_15 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_15).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_13, .index = operand_14, });

                break :block_16 @as(*const (zx_abi).zx_type_50, operand_15);
            };
        };
        const operand_18 = (value_3).count;
        const operand_19 = block_22: {
            const operand_20 = ((((in).source).indexed).order).heads;
            const operand_21 = ((in).reference).index;

            if ((operand_21 >= (operand_20).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_22 (operand_20)[@intCast(operand_21)];
        };

        break :block_25 block_24: {
            const operand_23 = (try (allocator).create((zx_abi).zx_type_51));

            (operand_23).* = @as((zx_abi).zx_type_51, (zx_abi).zx_type_51{ .kind = operand_1, .name = operand_2, .child = operand_12, .count = operand_18, .position = operand_19, });

            break :block_24 @as(*const (zx_abi).zx_type_51, operand_23);
        };
    };
}

fn function_12_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_87) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).zx_type_51 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if (((in).reference).enumeration) {
        const value_2: u64 = (if ((value_1 != null)) (block_109: {
            const operand_107 = (value_1.?).enumerations;
            const operand_108 = ((in).reference).index;

            if ((operand_108 >= (operand_107).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_109 (operand_107)[@intCast(operand_108)];
        }).count else (block_112: {
            const operand_110 = (((in).source).indexed).declarations;
            const operand_111 = ((in).reference).index;

            if ((operand_111 >= (operand_110).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_112 (operand_110)[@intCast(operand_111)];
        }).count);

        return block_106: {
            const operand_90 = @as((zx_abi).zx_type_48, .Enumeration);
            const operand_91 = block_97: {
                const operand_92 = @as([]const u8, "");
                const operand_93 = @as(u64, 0);
                const operand_94 = @as(u64, 0);

                break :block_97 block_96: {
                    const operand_95 = (try (allocator).create((zx_abi).zx_type_49));

                    (operand_95).* = @as((zx_abi).zx_type_49, (zx_abi).zx_type_49{ .text = operand_92, .start = operand_93, .end = operand_94, });

                    break :block_96 @as(*const (zx_abi).zx_type_49, operand_95);
                };
            };
            const operand_98 = block_103: {
                const operand_99 = false;
                const operand_100 = @as(u64, 0);

                break :block_103 block_102: {
                    const operand_101 = (try (allocator).create((zx_abi).zx_type_50));

                    (operand_101).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_99, .index = operand_100, });

                    break :block_102 @as(*const (zx_abi).zx_type_50, operand_101);
                };
            };
            const operand_104 = value_2;
            const operand_105 = @as(u64, 0);

            break :block_106 (zx_abi).zx_type_51{ .kind = operand_90, .name = operand_91, .child = operand_98, .count = operand_104, .position = operand_105, };
        };
    }

    if ((value_1 != null)) {
        return (block_89: {
            const operand_87 = (value_1.?).nodes;
            const operand_88 = ((in).reference).index;

            if ((operand_88 >= (operand_87).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_89 (operand_87)[@intCast(operand_88)];
        }).*;
    }

    const value_3: (zx_abi).zx_type_30 = (block_86: {
        const operand_84 = ((((in).source).indexed).types).nodes;
        const operand_85 = ((in).reference).index;

        if ((operand_85 >= (operand_84).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_86 (operand_84)[@intCast(operand_85)];
    }).*;
    const value_4: (zx_abi).zx_type_48 = block_83: {
        const operand_82 = ((&value_3)).kind;

        break :block_83 (if ((operand_82 == @as((zx_abi).zx_type_28, .Named))) @as((zx_abi).zx_type_48, .Named) else (if ((operand_82 == @as((zx_abi).zx_type_28, .Object))) @as((zx_abi).zx_type_48, .Object) else (if ((operand_82 == @as((zx_abi).zx_type_28, .Optional))) @as((zx_abi).zx_type_48, .Optional) else (if ((operand_82 == @as((zx_abi).zx_type_28, .List))) @as((zx_abi).zx_type_48, .List) else (if ((operand_82 == @as((zx_abi).zx_type_28, .Tuple))) @as((zx_abi).zx_type_48, .Tuple) else @as((zx_abi).zx_type_48, .Application))))));
    };

    return block_81: {
        const operand_59 = value_4;
        const operand_60 = block_69: {
            const operand_66 = (try function_9_value(allocator, block_65: {
                const operand_61 = (((in).source).indexed).bytes;
                const operand_62 = ((&value_3)).name;

                break :block_65 block_64: {
                    const operand_63 = (try (allocator).create((zx_abi).zx_type_83));

                    (operand_63).* = @as((zx_abi).zx_type_83, (zx_abi).zx_type_83{ .source = operand_61, .span = operand_62, });

                    break :block_64 @as(*const (zx_abi).zx_type_83, operand_63);
                };
            }));

            break :block_69 block_68: {
                const operand_67 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_67).* = @as((zx_abi).zx_type_49, operand_66);

                break :block_68 @as(*const (zx_abi).zx_type_49, operand_67);
            };
        };
        const operand_70 = block_75: {
            const operand_71 = false;
            const operand_72 = ((&value_3)).child;

            break :block_75 block_74: {
                const operand_73 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_73).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_71, .index = operand_72, });

                break :block_74 @as(*const (zx_abi).zx_type_50, operand_73);
            };
        };
        const operand_76 = ((&value_3)).count;
        const operand_77 = block_80: {
            const operand_78 = ((((in).source).indexed).order).heads;
            const operand_79 = ((in).reference).index;

            if ((operand_79 >= (operand_78).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_80 (operand_78)[@intCast(operand_79)];
        };

        break :block_81 (zx_abi).zx_type_51{ .kind = operand_59, .name = operand_60, .child = operand_70, .count = operand_76, .position = operand_77, };
    };
}

fn function_13(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_87) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    return block_38: {
        const operand_7 = block_6: {
            const operand_2 = (in).source;
            const operand_3 = (in).reference;
            const operand_4 = true;
            const operand_5 = false;

            break :block_6 (zx_abi).zx_type_98{ .source = operand_2, .reference = operand_3, .active = operand_4, .valid = operand_5, };
        };

        var state_1: (zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15 = (zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15{ .active = (operand_7).active, .reference = (operand_7).reference, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((operand_7).source).indexed).bytes, .declarations = (((operand_7).source).indexed).declarations, .members = (((operand_7).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_7).source).indexed).order).fields, .heads = ((((operand_7).source).indexed).order).heads, .items = ((((operand_7).source).indexed).order).items, .zx_origin = (((operand_7).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_7).source).indexed).types).fields, .items = ((((operand_7).source).indexed).types).items, .nodes = ((((operand_7).source).indexed).types).nodes, .zx_origin = (((operand_7).source).indexed).types, }, .zx_origin = ((operand_7).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if ((((operand_7).source).native != null)) block_37: {
            break :block_37 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = (((operand_7).source).native.?).declarations, .enumerations = (((operand_7).source).native.?).enumerations, .fields = (((operand_7).source).native.?).fields, .items = (((operand_7).source).native.?).items, .members = (((operand_7).source).native.?).members, .nodes = (((operand_7).source).native.?).nodes, .zx_origin = ((operand_7).source).native.?, };
        } else null)), .zx_origin = (operand_7).source, }, .valid = (operand_7).valid, .zx_origin = (&operand_7), };

        while ((state_1).active) {
            state_1 = block_36: {
                const value_3: *const (zx_abi).zx_type_51 = block_35: {
                    const operand_21 = block_20: {
                        const operand_18 = (state_1).source;
                        const operand_19 = (state_1).reference;

                        break :block_20 @as((zx_abi).value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_18, .reference = operand_19, });
                    };

                    break :block_35 (try function_12(allocator, (if (((operand_21).zx_origin != null)) (operand_21).zx_origin.? else block_34: {
                        const operand_33 = (try (allocator).create((zx_abi).zx_type_87));

                        (operand_33).* = (zx_abi).zx_type_87{ .reference = (operand_21).reference, .source = (if ((((operand_21).source).zx_origin != null)) ((operand_21).source).zx_origin.? else block_32: {
                            const operand_31 = (try (allocator).create((zx_abi).zx_type_66));

                            (operand_31).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_21).source).indexed).zx_origin != null)) (((operand_21).source).indexed).zx_origin.? else block_27: {
                                const operand_26 = (try (allocator).create((zx_abi).zx_type_64));

                                (operand_26).* = (zx_abi).zx_type_64{ .bytes = (((operand_21).source).indexed).bytes, .declarations = (((operand_21).source).indexed).declarations, .members = (((operand_21).source).indexed).members, .order = (if ((((((operand_21).source).indexed).order).zx_origin != null)) ((((operand_21).source).indexed).order).zx_origin.? else block_23: {
                                    const operand_22 = (try (allocator).create((zx_abi).zx_type_34));

                                    (operand_22).* = (zx_abi).zx_type_34{ .fields = ((((operand_21).source).indexed).order).fields, .heads = ((((operand_21).source).indexed).order).heads, .items = ((((operand_21).source).indexed).order).items, };

                                    break :block_23 @as(*const (zx_abi).zx_type_34, operand_22);
                                }), .types = (if ((((((operand_21).source).indexed).types).zx_origin != null)) ((((operand_21).source).indexed).types).zx_origin.? else block_25: {
                                    const operand_24 = (try (allocator).create((zx_abi).zx_type_38));

                                    (operand_24).* = (zx_abi).zx_type_38{ .fields = ((((operand_21).source).indexed).types).fields, .items = ((((operand_21).source).indexed).types).items, .nodes = ((((operand_21).source).indexed).types).nodes, };

                                    break :block_25 @as(*const (zx_abi).zx_type_38, operand_24);
                                }), };

                                break :block_27 @as(*const (zx_abi).zx_type_64, operand_26);
                            }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_21).source).native != null)) block_30: {
                                break :block_30 (if (((((operand_21).source).native.?).zx_origin != null)) (((operand_21).source).native.?).zx_origin.? else block_29: {
                                    const operand_28 = (try (allocator).create((zx_abi).zx_type_62));

                                    (operand_28).* = (zx_abi).zx_type_62{ .declarations = (((operand_21).source).native.?).declarations, .enumerations = (((operand_21).source).native.?).enumerations, .fields = (((operand_21).source).native.?).fields, .items = (((operand_21).source).native.?).items, .members = (((operand_21).source).native.?).members, .nodes = (((operand_21).source).native.?).nodes, };

                                    break :block_29 @as(*const (zx_abi).zx_type_62, operand_28);
                                });
                            } else null)), };

                            break :block_32 @as(*const (zx_abi).zx_type_66, operand_31);
                        }), };

                        break :block_34 @as(*const (zx_abi).zx_type_87, operand_33);
                    })));
                };
                const value_7: (zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15 = (if (((((block_8: {
                    break :block_8 value_3;
                }).kind == @as((zx_abi).zx_type_48, .Optional)) or ((block_9: {
                    break :block_9 value_3;
                }).kind == @as((zx_abi).zx_type_48, .List))) or ((block_10: {
                    break :block_10 value_3;
                }).kind == @as((zx_abi).zx_type_48, .Application)))) block_13: {
                    const value_4: (zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15 = block_12: {
                        break :block_12 @as((zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15, (zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15{ .active = (state_1).active, .reference = (block_11: {
                            break :block_11 value_3;
                        }).child, .source = (state_1).source, .valid = (state_1).valid, });
                    };

                    break :block_13 value_4;
                } else block_17: {
                    const value_5: (zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15 = block_16: {
                        break :block_16 @as((zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15, (zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15{ .active = (state_1).active, .reference = (state_1).reference, .source = (state_1).source, .valid = ((block_15: {
                            break :block_15 value_3;
                        }).kind == @as((zx_abi).zx_type_48, .Named)), });
                    };
                    const value_6: (zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15 = block_14: {
                        break :block_14 @as((zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15, (zx_abi).value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15{ .active = false, .reference = (value_5).reference, .source = (value_5).source, .valid = (value_5).valid, });
                    };

                    break :block_17 value_6;
                });

                break :block_36 value_7;
            };
        }

        break :block_38 (state_1).valid;
    };
}

fn function_14(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_88) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_52 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return block_29: {
            const operand_27 = (value_1.?).fields;
            const operand_28 = ((in).position - @as(u64, 1));

            if ((operand_28 >= (operand_27).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_29 (operand_27)[@intCast(operand_28)];
        };
    }

    const value_2: *const (zx_abi).zx_type_31 = block_26: {
        const operand_24 = ((((in).source).indexed).types).fields;
        const operand_25 = ((in).position - @as(u64, 1));

        if ((operand_25 >= (operand_24).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_26 (operand_24)[@intCast(operand_25)];
    };

    return block_23: {
        const operand_1 = block_10: {
            const operand_7 = (try function_9_value(allocator, block_6: {
                const operand_2 = (((in).source).indexed).bytes;
                const operand_3 = (value_2).name;

                break :block_6 block_5: {
                    const operand_4 = (try (allocator).create((zx_abi).zx_type_83));

                    (operand_4).* = @as((zx_abi).zx_type_83, (zx_abi).zx_type_83{ .source = operand_2, .span = operand_3, });

                    break :block_5 @as(*const (zx_abi).zx_type_83, operand_4);
                };
            }));

            break :block_10 block_9: {
                const operand_8 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_8).* = @as((zx_abi).zx_type_49, operand_7);

                break :block_9 @as(*const (zx_abi).zx_type_49, operand_8);
            };
        };
        const operand_11 = block_16: {
            const operand_12 = false;
            const operand_13 = (value_2).value;

            break :block_16 block_15: {
                const operand_14 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_14).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_12, .index = operand_13, });

                break :block_15 @as(*const (zx_abi).zx_type_50, operand_14);
            };
        };
        const operand_17 = block_20: {
            const operand_18 = ((((in).source).indexed).order).fields;
            const operand_19 = ((in).position - @as(u64, 1));

            if ((operand_19 >= (operand_18).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_20 (operand_18)[@intCast(operand_19)];
        };

        break :block_23 block_22: {
            const operand_21 = (try (allocator).create((zx_abi).zx_type_52));

            (operand_21).* = @as((zx_abi).zx_type_52, (zx_abi).zx_type_52{ .name = operand_1, .value = operand_11, .next = operand_17, });

            break :block_22 @as(*const (zx_abi).zx_type_52, operand_21);
        };
    };
}

fn function_14_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_88) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).zx_type_52 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return (block_56: {
            const operand_54 = (value_1.?).fields;
            const operand_55 = ((in).position - @as(u64, 1));

            if ((operand_55 >= (operand_54).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_56 (operand_54)[@intCast(operand_55)];
        }).*;
    }

    const value_2: (zx_abi).zx_type_31 = (block_53: {
        const operand_51 = ((((in).source).indexed).types).fields;
        const operand_52 = ((in).position - @as(u64, 1));

        if ((operand_52 >= (operand_51).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_53 (operand_51)[@intCast(operand_52)];
    }).*;

    return block_50: {
        const operand_30 = block_39: {
            const operand_36 = (try function_9_value(allocator, block_35: {
                const operand_31 = (((in).source).indexed).bytes;
                const operand_32 = ((&value_2)).name;

                break :block_35 block_34: {
                    const operand_33 = (try (allocator).create((zx_abi).zx_type_83));

                    (operand_33).* = @as((zx_abi).zx_type_83, (zx_abi).zx_type_83{ .source = operand_31, .span = operand_32, });

                    break :block_34 @as(*const (zx_abi).zx_type_83, operand_33);
                };
            }));

            break :block_39 block_38: {
                const operand_37 = (try (allocator).create((zx_abi).zx_type_49));

                (operand_37).* = @as((zx_abi).zx_type_49, operand_36);

                break :block_38 @as(*const (zx_abi).zx_type_49, operand_37);
            };
        };
        const operand_40 = block_45: {
            const operand_41 = false;
            const operand_42 = ((&value_2)).value;

            break :block_45 block_44: {
                const operand_43 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_43).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_41, .index = operand_42, });

                break :block_44 @as(*const (zx_abi).zx_type_50, operand_43);
            };
        };
        const operand_46 = block_49: {
            const operand_47 = ((((in).source).indexed).order).fields;
            const operand_48 = ((in).position - @as(u64, 1));

            if ((operand_48 >= (operand_47).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_49 (operand_47)[@intCast(operand_48)];
        };

        break :block_50 (zx_abi).zx_type_52{ .name = operand_30, .value = operand_40, .next = operand_46, };
    };
}

fn function_15(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_88) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_53 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return block_19: {
            const operand_17 = (value_1.?).items;
            const operand_18 = ((in).position - @as(u64, 1));

            if ((operand_18 >= (operand_17).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_19 (operand_17)[@intCast(operand_18)];
        };
    }

    return block_16: {
        const operand_1 = block_9: {
            const operand_2 = false;
            const operand_3 = (block_6: {
                const operand_4 = ((((in).source).indexed).types).items;
                const operand_5 = ((in).position - @as(u64, 1));

                if ((operand_5 >= (operand_4).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_6 (operand_4)[@intCast(operand_5)];
            }).value;

            break :block_9 block_8: {
                const operand_7 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_7).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_2, .index = operand_3, });

                break :block_8 @as(*const (zx_abi).zx_type_50, operand_7);
            };
        };
        const operand_10 = block_13: {
            const operand_11 = ((((in).source).indexed).order).items;
            const operand_12 = ((in).position - @as(u64, 1));

            if ((operand_12 >= (operand_11).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_13 (operand_11)[@intCast(operand_12)];
        };

        break :block_16 block_15: {
            const operand_14 = (try (allocator).create((zx_abi).zx_type_53));

            (operand_14).* = @as((zx_abi).zx_type_53, (zx_abi).zx_type_53{ .value = operand_1, .next = operand_10, });

            break :block_15 @as(*const (zx_abi).zx_type_53, operand_14);
        };
    };
}

fn function_15_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_88) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).zx_type_53 {
    @setRuntimeSafety(true);

    const value_1: ?*const (zx_abi).zx_type_62 = ((in).source).native;

    if ((value_1 != null)) {
        return (block_36: {
            const operand_34 = (value_1.?).items;
            const operand_35 = ((in).position - @as(u64, 1));

            if ((operand_35 >= (operand_34).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_36 (operand_34)[@intCast(operand_35)];
        }).*;
    }

    return block_33: {
        const operand_20 = block_28: {
            const operand_21 = false;
            const operand_22 = (block_25: {
                const operand_23 = ((((in).source).indexed).types).items;
                const operand_24 = ((in).position - @as(u64, 1));

                if ((operand_24 >= (operand_23).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_25 (operand_23)[@intCast(operand_24)];
            }).value;

            break :block_28 block_27: {
                const operand_26 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_26).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_21, .index = operand_22, });

                break :block_27 @as(*const (zx_abi).zx_type_50, operand_26);
            };
        };
        const operand_29 = block_32: {
            const operand_30 = ((((in).source).indexed).order).items;
            const operand_31 = ((in).position - @as(u64, 1));

            if ((operand_31 >= (operand_30).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_32 (operand_30)[@intCast(operand_31)];
        };

        break :block_33 (zx_abi).zx_type_53{ .value = operand_20, .next = operand_29, };
    };
}

fn function_16(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_89) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: u64 = (if ((@as(u64, ((in).left).len) < @as(u64, ((in).right).len))) @as(u64, ((in).left).len) else @as(u64, ((in).right).len));
    const value_8: (zx_abi).zx_type_99 = block_28: {
        const operand_14 = block_13: {
            const operand_8 = (in).left;
            const operand_9 = (in).right;
            const operand_10 = @as(u64, 0);
            const operand_11 = value_1;
            const operand_12 = true;

            break :block_13 (zx_abi).zx_type_99{ .left = operand_8, .right = operand_9, .index = operand_10, .limit = operand_11, .equal = operand_12, };
        };

        var state_7: (zx_abi).value_zx_type_99_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = (zx_abi).value_zx_type_99_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .equal = (operand_14).equal, .index = (operand_14).index, .left = (operand_14).left, .limit = (operand_14).limit, .right = (operand_14).right, .zx_origin = (&operand_14), };

        while (((state_7).equal and ((state_7).index < (state_7).limit))) {
            state_7 = block_25: {
                const value_4: (zx_abi).value_zx_type_99_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_24: {
                    break :block_24 @as((zx_abi).value_zx_type_99_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_99_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .equal = (block_20: {
                        const operand_18 = (state_7).left;
                        const operand_19 = (state_7).index;

                        if ((operand_19 >= (operand_18).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_20 (operand_18)[@intCast(operand_19)];
                    } == block_23: {
                        const operand_21 = (state_7).right;
                        const operand_22 = (state_7).index;

                        if ((operand_22 >= (operand_21).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_23 (operand_21)[@intCast(operand_22)];
                    }), .index = (state_7).index, .left = (state_7).left, .limit = (state_7).limit, .right = (state_7).right, });
                };
                const value_7: (zx_abi).value_zx_type_99_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = (if ((value_4).equal) block_17: {
                    const value_5: u64 = (value_4).index;
                    const value_6: (zx_abi).value_zx_type_99_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_16: {
                        break :block_16 @as((zx_abi).value_zx_type_99_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_99_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .equal = (value_4).equal, .index = (block_15: {
                            break :block_15 value_5;
                        } + @as(u64, 1)), .left = (value_4).left, .limit = (value_4).limit, .right = (value_4).right, });
                    };

                    break :block_17 value_6;
                } else value_4);

                break :block_25 value_7;
            };
        }

        break :block_28 block_27: {
            break :block_27 (if (((state_7).zx_origin != null)) ((state_7).zx_origin.?).* else block_26: {
                break :block_26 (zx_abi).zx_type_99{ .equal = (state_7).equal, .index = (state_7).index, .left = (state_7).left, .limit = (state_7).limit, .right = (state_7).right, };
            });
        };
    };

    return (if ((((&value_8)).index == ((&value_8)).limit)) (@as(u64, (((&value_8)).left).len) < @as(u64, (((&value_8)).right).len)) else (block_3: {
        const operand_1 = ((&value_8)).left;
        const operand_2 = ((&value_8)).index;

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    } < block_6: {
        const operand_4 = ((&value_8)).right;
        const operand_5 = ((&value_8)).index;

        if ((operand_5 >= (operand_4).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_6 (operand_4)[@intCast(operand_5)];
    }));
}

fn function_17(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_90) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }![]const u64 {
    @setRuntimeSafety(true);

    const value_1: []const []const u8 = block_247: {
        break :block_247 (try (allocator).dupe([]const u8, (&[_][]const u8{})));
    };
    const value_2: []const u64 = block_246: {
        break :block_246 (try (allocator).dupe(u64, (&[_]u64{})));
    };
    const value_14: *const (zx_abi).zx_type_101 = block_245: {
        const operand_172 = block_171: {
            const operand_164 = in;
            const operand_165 = (in).position;
            const operand_166 = @as(u64, 0);
            const operand_167 = value_1;
            const operand_168 = value_2;

            break :block_171 block_170: {
                const operand_169 = (try (allocator).create((zx_abi).zx_type_101));

                (operand_169).* = @as((zx_abi).zx_type_101, (zx_abi).zx_type_101{ .input = operand_164, .position = operand_165, .index = operand_166, .names = operand_167, .positions = operand_168, });

                break :block_170 @as(*const (zx_abi).zx_type_101, operand_169);
            };
        };

        var state_capacity_174: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_175 = false;

        defer (state_capacity_174).deinit(allocator);

        var state_capacity_176: (std).ArrayList(u64) = .empty;

        var state_capacity_started_177 = false;

        defer (state_capacity_176).deinit(allocator);

        var state_163: (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6 = (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6{ .index = (operand_172).index, .input = (zx_abi).value_zx_type_90_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0{ .count = ((operand_172).input).count, .object = ((operand_172).input).object, .position = ((operand_172).input).position, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = ((((operand_172).input).source).indexed).bytes, .declarations = ((((operand_172).input).source).indexed).declarations, .members = ((((operand_172).input).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = (((((operand_172).input).source).indexed).order).fields, .heads = (((((operand_172).input).source).indexed).order).heads, .items = (((((operand_172).input).source).indexed).order).items, .zx_origin = ((((operand_172).input).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = (((((operand_172).input).source).indexed).types).fields, .items = (((((operand_172).input).source).indexed).types).items, .nodes = (((((operand_172).input).source).indexed).types).nodes, .zx_origin = ((((operand_172).input).source).indexed).types, }, .zx_origin = (((operand_172).input).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if (((((operand_172).input).source).native != null)) block_226: {
            break :block_226 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = ((((operand_172).input).source).native.?).declarations, .enumerations = ((((operand_172).input).source).native.?).enumerations, .fields = ((((operand_172).input).source).native.?).fields, .items = ((((operand_172).input).source).native.?).items, .members = ((((operand_172).input).source).native.?).members, .nodes = ((((operand_172).input).source).native.?).nodes, .zx_origin = (((operand_172).input).source).native.?, };
        } else null)), .zx_origin = ((operand_172).input).source, }, .zx_origin = (operand_172).input, }, .names = (operand_172).names, .position = (operand_172).position, .positions = (operand_172).positions, .zx_origin = operand_172, };

        var state_changed_173 = false;

        while (((state_163).index < ((state_163).input).count)) {
            state_163 = block_225: {
                const value_5: (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6 = block_224: {
                    break :block_224 @as((zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6, (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6{ .index = (state_163).index, .input = (state_163).input, .names = (state_163).names, .position = (state_163).position, .positions = (block_223: {
                        const operand_221 = (state_163).positions;
                        const operand_222 = (state_163).position;

                        _ = (try ((std).math).add(usize, (operand_221).len, 1));

                        if ((!state_capacity_started_177)) {
                            (try (state_capacity_176).appendSlice(allocator, operand_221));

                            state_capacity_started_177 = true;
                        } else {
                            ((state_capacity_176).items).len = (operand_221).len;
                        }

                        (try (state_capacity_176).append(allocator, operand_222));

                        break :block_223 @as((zx_abi).value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_176).items, {}, null, });
                    }).@"0", });
                };
                const value_11: (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6 = (if (((value_5).input).object) block_205: {
                    const value_6: *const (zx_abi).zx_type_52 = block_204: {
                        const operand_190 = block_189: {
                            const operand_187 = ((value_5).input).source;
                            const operand_188 = (value_5).position;

                            break :block_189 @as((zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_187, .position = operand_188, });
                        };

                        break :block_204 (try function_14(allocator, (if (((operand_190).zx_origin != null)) (operand_190).zx_origin.? else block_203: {
                            const operand_202 = (try (allocator).create((zx_abi).zx_type_88));

                            (operand_202).* = (zx_abi).zx_type_88{ .position = (operand_190).position, .source = (if ((((operand_190).source).zx_origin != null)) ((operand_190).source).zx_origin.? else block_201: {
                                const operand_200 = (try (allocator).create((zx_abi).zx_type_66));

                                (operand_200).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_190).source).indexed).zx_origin != null)) (((operand_190).source).indexed).zx_origin.? else block_196: {
                                    const operand_195 = (try (allocator).create((zx_abi).zx_type_64));

                                    (operand_195).* = (zx_abi).zx_type_64{ .bytes = (((operand_190).source).indexed).bytes, .declarations = (((operand_190).source).indexed).declarations, .members = (((operand_190).source).indexed).members, .order = (if ((((((operand_190).source).indexed).order).zx_origin != null)) ((((operand_190).source).indexed).order).zx_origin.? else block_192: {
                                        const operand_191 = (try (allocator).create((zx_abi).zx_type_34));

                                        (operand_191).* = (zx_abi).zx_type_34{ .fields = ((((operand_190).source).indexed).order).fields, .heads = ((((operand_190).source).indexed).order).heads, .items = ((((operand_190).source).indexed).order).items, };

                                        break :block_192 @as(*const (zx_abi).zx_type_34, operand_191);
                                    }), .types = (if ((((((operand_190).source).indexed).types).zx_origin != null)) ((((operand_190).source).indexed).types).zx_origin.? else block_194: {
                                        const operand_193 = (try (allocator).create((zx_abi).zx_type_38));

                                        (operand_193).* = (zx_abi).zx_type_38{ .fields = ((((operand_190).source).indexed).types).fields, .items = ((((operand_190).source).indexed).types).items, .nodes = ((((operand_190).source).indexed).types).nodes, };

                                        break :block_194 @as(*const (zx_abi).zx_type_38, operand_193);
                                    }), };

                                    break :block_196 @as(*const (zx_abi).zx_type_64, operand_195);
                                }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_190).source).native != null)) block_199: {
                                    break :block_199 (if (((((operand_190).source).native.?).zx_origin != null)) (((operand_190).source).native.?).zx_origin.? else block_198: {
                                        const operand_197 = (try (allocator).create((zx_abi).zx_type_62));

                                        (operand_197).* = (zx_abi).zx_type_62{ .declarations = (((operand_190).source).native.?).declarations, .enumerations = (((operand_190).source).native.?).enumerations, .fields = (((operand_190).source).native.?).fields, .items = (((operand_190).source).native.?).items, .members = (((operand_190).source).native.?).members, .nodes = (((operand_190).source).native.?).nodes, };

                                        break :block_198 @as(*const (zx_abi).zx_type_62, operand_197);
                                    });
                                } else null)), };

                                break :block_201 @as(*const (zx_abi).zx_type_66, operand_200);
                            }), };

                            break :block_203 @as(*const (zx_abi).zx_type_88, operand_202);
                        })));
                    };
                    const value_7: (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6 = block_186: {
                        break :block_186 @as((zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6, (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6{ .index = (value_5).index, .input = (value_5).input, .names = (block_185: {
                            const operand_182 = (value_5).names;
                            const operand_184 = ((block_183: {
                                break :block_183 value_6;
                            }).name).text;

                            _ = (try ((std).math).add(usize, (operand_182).len, 1));

                            if ((!state_capacity_started_175)) {
                                (try (state_capacity_174).appendSlice(allocator, operand_182));

                                state_capacity_started_175 = true;
                            } else {
                                ((state_capacity_174).items).len = (operand_182).len;
                            }

                            (try (state_capacity_174).append(allocator, operand_184));

                            break :block_185 @as((zx_abi).value_zx_type_102_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_174).items, {}, null, });
                        }).@"0", .position = (value_5).position, .positions = (value_5).positions, });
                    };
                    const value_8: (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6 = block_181: {
                        break :block_181 @as((zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6, (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6{ .index = (value_7).index, .input = (value_7).input, .names = (value_7).names, .position = (block_180: {
                            break :block_180 value_6;
                        }).next, .positions = (value_7).positions, });
                    };

                    break :block_205 value_8;
                } else block_220: {
                    const value_9: *const (zx_abi).zx_type_53 = block_219: {
                        const operand_211 = block_210: {
                            const operand_208 = ((value_5).input).source;
                            const operand_209 = (value_5).position;

                            break :block_210 @as((zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_208, .position = operand_209, });
                        };

                        var state_borrow_212: (zx_abi).zx_type_34 = undefined;

                        state_borrow_212 = (zx_abi).zx_type_34{ .fields = ((((operand_211).source).indexed).order).fields, .heads = ((((operand_211).source).indexed).order).heads, .items = ((((operand_211).source).indexed).order).items, };

                        var state_borrow_213: (zx_abi).zx_type_38 = undefined;

                        state_borrow_213 = (zx_abi).zx_type_38{ .fields = ((((operand_211).source).indexed).types).fields, .items = ((((operand_211).source).indexed).types).items, .nodes = ((((operand_211).source).indexed).types).nodes, };

                        var state_borrow_214: (zx_abi).zx_type_64 = undefined;

                        state_borrow_214 = (zx_abi).zx_type_64{ .bytes = (((operand_211).source).indexed).bytes, .declarations = (((operand_211).source).indexed).declarations, .members = (((operand_211).source).indexed).members, .order = (((((operand_211).source).indexed).order).zx_origin orelse (&state_borrow_212)), .types = (((((operand_211).source).indexed).types).zx_origin orelse (&state_borrow_213)), };

                        var state_borrow_215: (zx_abi).zx_type_62 = undefined;

                        var state_borrow_217: (zx_abi).zx_type_66 = undefined;

                        state_borrow_217 = (zx_abi).zx_type_66{ .indexed = ((((operand_211).source).indexed).zx_origin orelse (&state_borrow_214)), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_211).source).native != null)) block_216: {
                            state_borrow_215 = (zx_abi).zx_type_62{ .declarations = (((operand_211).source).native.?).declarations, .enumerations = (((operand_211).source).native.?).enumerations, .fields = (((operand_211).source).native.?).fields, .items = (((operand_211).source).native.?).items, .members = (((operand_211).source).native.?).members, .nodes = (((operand_211).source).native.?).nodes, };

                            break :block_216 ((((operand_211).source).native.?).zx_origin orelse (&state_borrow_215));
                        } else null)), };

                        var state_borrow_218: (zx_abi).zx_type_88 = undefined;

                        state_borrow_218 = (zx_abi).zx_type_88{ .position = (operand_211).position, .source = (((operand_211).source).zx_origin orelse (&state_borrow_217)), };

                        break :block_219 (try function_15(allocator, ((operand_211).zx_origin orelse (&state_borrow_218))));
                    };
                    const value_10: (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6 = block_207: {
                        break :block_207 @as((zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6, (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6{ .index = (value_5).index, .input = (value_5).input, .names = (value_5).names, .position = (block_206: {
                            break :block_206 value_9;
                        }).next, .positions = (value_5).positions, });
                    };

                    break :block_220 value_10;
                });
                const value_12: u64 = (value_11).index;
                const value_13: (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6 = block_179: {
                    break :block_179 @as((zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6, (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6{ .index = (block_178: {
                        break :block_178 value_12;
                    } + @as(u64, 1)), .input = (value_11).input, .names = (value_11).names, .position = (value_11).position, .positions = (value_11).positions, });
                };

                break :block_225 value_13;
            };

            state_changed_173 = true;
        }

        var state_owned_227: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_227);

        if (state_capacity_started_175) {
            ((state_capacity_174).items).len = ((state_163).names).len;

            state_owned_227 = (try (state_capacity_174).toOwnedSlice(allocator));
        }

        if (state_capacity_started_175) {
            state_163 = (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6{ .index = (state_163).index, .input = (state_163).input, .names = state_owned_227, .position = (state_163).position, .positions = (state_163).positions, };
        }

        var state_owned_228: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_228);

        if (state_capacity_started_177) {
            ((state_capacity_176).items).len = ((state_163).positions).len;

            state_owned_228 = (try (state_capacity_176).toOwnedSlice(allocator));
        }

        if (state_capacity_started_177) {
            state_163 = (zx_abi).value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6{ .index = (state_163).index, .input = (state_163).input, .names = (state_163).names, .position = (state_163).position, .positions = state_owned_228, };
        }

        break :block_245 (if (state_changed_173) block_244: {
            break :block_244 (if (((state_163).zx_origin != null)) (state_163).zx_origin.? else block_243: {
                const operand_242 = (try (allocator).create((zx_abi).zx_type_101));

                (operand_242).* = (zx_abi).zx_type_101{ .index = (state_163).index, .input = (if ((((state_163).input).zx_origin != null)) ((state_163).input).zx_origin.? else block_241: {
                    const operand_240 = (try (allocator).create((zx_abi).zx_type_90));

                    (operand_240).* = (zx_abi).zx_type_90{ .count = ((state_163).input).count, .object = ((state_163).input).object, .position = ((state_163).input).position, .source = (if (((((state_163).input).source).zx_origin != null)) (((state_163).input).source).zx_origin.? else block_239: {
                        const operand_238 = (try (allocator).create((zx_abi).zx_type_66));

                        (operand_238).* = (zx_abi).zx_type_66{ .indexed = (if ((((((state_163).input).source).indexed).zx_origin != null)) ((((state_163).input).source).indexed).zx_origin.? else block_234: {
                            const operand_233 = (try (allocator).create((zx_abi).zx_type_64));

                            (operand_233).* = (zx_abi).zx_type_64{ .bytes = ((((state_163).input).source).indexed).bytes, .declarations = ((((state_163).input).source).indexed).declarations, .members = ((((state_163).input).source).indexed).members, .order = (if (((((((state_163).input).source).indexed).order).zx_origin != null)) (((((state_163).input).source).indexed).order).zx_origin.? else block_230: {
                                const operand_229 = (try (allocator).create((zx_abi).zx_type_34));

                                (operand_229).* = (zx_abi).zx_type_34{ .fields = (((((state_163).input).source).indexed).order).fields, .heads = (((((state_163).input).source).indexed).order).heads, .items = (((((state_163).input).source).indexed).order).items, };

                                break :block_230 @as(*const (zx_abi).zx_type_34, operand_229);
                            }), .types = (if (((((((state_163).input).source).indexed).types).zx_origin != null)) (((((state_163).input).source).indexed).types).zx_origin.? else block_232: {
                                const operand_231 = (try (allocator).create((zx_abi).zx_type_38));

                                (operand_231).* = (zx_abi).zx_type_38{ .fields = (((((state_163).input).source).indexed).types).fields, .items = (((((state_163).input).source).indexed).types).items, .nodes = (((((state_163).input).source).indexed).types).nodes, };

                                break :block_232 @as(*const (zx_abi).zx_type_38, operand_231);
                            }), };

                            break :block_234 @as(*const (zx_abi).zx_type_64, operand_233);
                        }), .native = @as(?*const (zx_abi).zx_type_62, (if (((((state_163).input).source).native != null)) block_237: {
                            break :block_237 (if ((((((state_163).input).source).native.?).zx_origin != null)) ((((state_163).input).source).native.?).zx_origin.? else block_236: {
                                const operand_235 = (try (allocator).create((zx_abi).zx_type_62));

                                (operand_235).* = (zx_abi).zx_type_62{ .declarations = ((((state_163).input).source).native.?).declarations, .enumerations = ((((state_163).input).source).native.?).enumerations, .fields = ((((state_163).input).source).native.?).fields, .items = ((((state_163).input).source).native.?).items, .members = ((((state_163).input).source).native.?).members, .nodes = ((((state_163).input).source).native.?).nodes, };

                                break :block_236 @as(*const (zx_abi).zx_type_62, operand_235);
                            });
                        } else null)), };

                        break :block_239 @as(*const (zx_abi).zx_type_66, operand_238);
                    }), };

                    break :block_241 @as(*const (zx_abi).zx_type_90, operand_240);
                }), .names = (state_163).names, .position = (state_163).position, .positions = (state_163).positions, };

                break :block_243 @as(*const (zx_abi).zx_type_101, operand_242);
            });
        } else operand_172);
    };

    if (((!(in).object) or ((in).count < @as(u64, 2)))) {
        return (value_14).positions;
    }

    return block_162: {
        const operand_10 = block_9: {
            const operand_2 = (value_14).names;
            const operand_3 = (value_14).positions;
            const operand_4 = (in).count;
            const operand_5 = @divTrunc((in).count, @as(u64, 2));
            const operand_6 = @as(u64, 0);
            const operand_7 = true;
            const operand_8 = false;

            break :block_9 (zx_abi).zx_type_103{ .names = operand_2, .positions = operand_3, .count = operand_4, .remaining = operand_5, .root = operand_6, .building = operand_7, .sifting = operand_8, };
        };

        var state_items_11: [][]const u8 = undefined;

        var state_items_started_12 = false;

        var state_items_13: []u64 = undefined;

        var state_items_started_14 = false;

        var state_1: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (operand_10).building, .count = (operand_10).count, .names = (operand_10).names, .positions = (operand_10).positions, .remaining = (operand_10).remaining, .root = (operand_10).root, .sifting = (operand_10).sifting, .zx_origin = (&operand_10), };

        while ((((state_1).building or ((state_1).count > @as(u64, 1))) or (state_1).sifting)) {
            state_1 = block_161: {
                const value_64: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if ((state_1).sifting) block_100: {
                    const value_38: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if (((state_1).root >= @divTrunc((state_1).count, @as(u64, 2)))) block_16: {
                        const value_17: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_15: {
                            break :block_15 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (state_1).building, .count = (state_1).count, .names = (state_1).names, .positions = (state_1).positions, .remaining = (state_1).remaining, .root = (state_1).root, .sifting = false, });
                        };

                        break :block_16 value_17;
                    } else block_99: {
                        const value_18: u64 = (((state_1).root * @as(u64, 2)) + @as(u64, 1));
                        const value_19: u64 = (block_98: {
                            break :block_98 value_18;
                        } + @as(u64, 1));
                        const value_20: u64 = (if (((block_83: {
                            break :block_83 value_19;
                        } < (state_1).count) and block_95: {
                            const operand_88 = block_87: {
                                const operand_85 = (state_1).names;
                                const operand_86 = block_84: {
                                    break :block_84 value_18;
                                };

                                if ((operand_86 >= (operand_85).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_87 (operand_85)[@intCast(operand_86)];
                            };
                            const operand_93 = block_92: {
                                const operand_90 = (state_1).names;
                                const operand_91 = block_89: {
                                    break :block_89 value_19;
                                };

                                if ((operand_91 >= (operand_90).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_92 (operand_90)[@intCast(operand_91)];
                            };
                            const operand_94 = (zx_abi).zx_type_89{ .left = operand_88, .right = operand_93, };

                            break :block_95 (try function_16(allocator, (&operand_94)));
                        })) block_96: {
                            break :block_96 value_19;
                        } else block_97: {
                            break :block_97 value_18;
                        });
                        const value_37: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if (block_27: {
                            const operand_20 = block_19: {
                                const operand_17 = (state_1).names;
                                const operand_18 = (state_1).root;

                                if ((operand_18 >= (operand_17).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_19 (operand_17)[@intCast(operand_18)];
                            };
                            const operand_25 = block_24: {
                                const operand_22 = (state_1).names;
                                const operand_23 = block_21: {
                                    break :block_21 value_20;
                                };

                                if ((operand_23 >= (operand_22).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_24 (operand_22)[@intCast(operand_23)];
                            };
                            const operand_26 = (zx_abi).zx_type_89{ .left = operand_20, .right = operand_25, };

                            break :block_27 (try function_16(allocator, (&operand_26)));
                        }) block_80: {
                            const value_21: []const u8 = block_79: {
                                const operand_77 = (state_1).names;
                                const operand_78 = (state_1).root;

                                if ((operand_78 >= (operand_77).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_79 (operand_77)[@intCast(operand_78)];
                            };
                            const value_22: u64 = block_76: {
                                const operand_74 = (state_1).positions;
                                const operand_75 = (state_1).root;

                                if ((operand_75 >= (operand_74).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_76 (operand_74)[@intCast(operand_75)];
                            };
                            const value_23: []const []const u8 = (state_1).names;
                            const value_24: u64 = (state_1).root;
                            const value_25: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_73: {
                                break :block_73 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (state_1).building, .count = (state_1).count, .names = block_72: {
                                    const operand_63 = block_62: {
                                        break :block_62 value_23;
                                    };
                                    const operand_65 = block_64: {
                                        break :block_64 value_24;
                                    };

                                    if ((operand_65 >= (operand_63).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    const operand_70 = block_69: {
                                        const operand_67 = (state_1).names;
                                        const operand_68 = block_66: {
                                            break :block_66 value_20;
                                        };

                                        if ((operand_68 >= (operand_67).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_69 (operand_67)[@intCast(operand_68)];
                                    };

                                    break :block_72 block_71: {
                                        if ((!state_items_started_12)) {
                                            state_items_11 = (try (allocator).dupe([]const u8, operand_63));

                                            state_items_started_12 = true;
                                        }

                                        (state_items_11)[@intCast(operand_65)] = operand_70;

                                        break :block_71 state_items_11;
                                    };
                                }, .positions = (state_1).positions, .remaining = (state_1).remaining, .root = (state_1).root, .sifting = (state_1).sifting, });
                            };
                            const value_26: []const u64 = (value_25).positions;
                            const value_27: u64 = (value_25).root;
                            const value_28: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_61: {
                                break :block_61 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_25).building, .count = (value_25).count, .names = (value_25).names, .positions = block_60: {
                                    const operand_51 = block_50: {
                                        break :block_50 value_26;
                                    };
                                    const operand_53 = block_52: {
                                        break :block_52 value_27;
                                    };

                                    if ((operand_53 >= (operand_51).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    const operand_58 = block_57: {
                                        const operand_55 = (value_25).positions;
                                        const operand_56 = block_54: {
                                            break :block_54 value_20;
                                        };

                                        if ((operand_56 >= (operand_55).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_57 (operand_55)[@intCast(operand_56)];
                                    };

                                    break :block_60 block_59: {
                                        if ((!state_items_started_14)) {
                                            state_items_13 = (try (allocator).dupe(u64, operand_51));

                                            state_items_started_14 = true;
                                        }

                                        (state_items_13)[@intCast(operand_53)] = operand_58;

                                        break :block_59 state_items_13;
                                    };
                                }, .remaining = (value_25).remaining, .root = (value_25).root, .sifting = (value_25).sifting, });
                            };
                            const value_29: []const []const u8 = (value_28).names;
                            const value_30: u64 = block_49: {
                                break :block_49 value_20;
                            };
                            const value_31: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_48: {
                                break :block_48 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_28).building, .count = (value_28).count, .names = block_47: {
                                    const operand_41 = block_40: {
                                        break :block_40 value_29;
                                    };
                                    const operand_43 = block_42: {
                                        break :block_42 value_30;
                                    };

                                    if ((operand_43 >= (operand_41).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    const operand_45 = block_44: {
                                        break :block_44 value_21;
                                    };

                                    break :block_47 block_46: {
                                        if ((!state_items_started_12)) {
                                            state_items_11 = (try (allocator).dupe([]const u8, operand_41));

                                            state_items_started_12 = true;
                                        }

                                        (state_items_11)[@intCast(operand_43)] = operand_45;

                                        break :block_46 state_items_11;
                                    };
                                }, .positions = (value_28).positions, .remaining = (value_28).remaining, .root = (value_28).root, .sifting = (value_28).sifting, });
                            };
                            const value_32: []const u64 = (value_31).positions;
                            const value_33: u64 = block_39: {
                                break :block_39 value_20;
                            };
                            const value_34: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_38: {
                                break :block_38 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_31).building, .count = (value_31).count, .names = (value_31).names, .positions = block_37: {
                                    const operand_31 = block_30: {
                                        break :block_30 value_32;
                                    };
                                    const operand_33 = block_32: {
                                        break :block_32 value_33;
                                    };

                                    if ((operand_33 >= (operand_31).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    const operand_35 = block_34: {
                                        break :block_34 value_22;
                                    };

                                    break :block_37 block_36: {
                                        if ((!state_items_started_14)) {
                                            state_items_13 = (try (allocator).dupe(u64, operand_31));

                                            state_items_started_14 = true;
                                        }

                                        (state_items_13)[@intCast(operand_33)] = operand_35;

                                        break :block_36 state_items_13;
                                    };
                                }, .remaining = (value_31).remaining, .root = (value_31).root, .sifting = (value_31).sifting, });
                            };
                            const value_35: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_29: {
                                break :block_29 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_34).building, .count = (value_34).count, .names = (value_34).names, .positions = (value_34).positions, .remaining = (value_34).remaining, .root = block_28: {
                                    break :block_28 value_20;
                                }, .sifting = (value_34).sifting, });
                            };

                            break :block_80 value_35;
                        } else block_82: {
                            const value_36: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_81: {
                                break :block_81 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (state_1).building, .count = (state_1).count, .names = (state_1).names, .positions = (state_1).positions, .remaining = (state_1).remaining, .root = (state_1).root, .sifting = false, });
                            };

                            break :block_82 value_36;
                        });

                        break :block_99 value_37;
                    });

                    break :block_100 value_38;
                } else block_160: {
                    const value_63: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if ((state_1).building) block_108: {
                        const value_44: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if (((state_1).remaining == @as(u64, 0))) block_102: {
                            const value_39: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_101: {
                                break :block_101 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = false, .count = (state_1).count, .names = (state_1).names, .positions = (state_1).positions, .remaining = (state_1).remaining, .root = (state_1).root, .sifting = (state_1).sifting, });
                            };

                            break :block_102 value_39;
                        } else block_107: {
                            const value_40: u64 = (state_1).remaining;
                            const value_41: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_106: {
                                break :block_106 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (state_1).building, .count = (state_1).count, .names = (state_1).names, .positions = (state_1).positions, .remaining = (block_105: {
                                    break :block_105 value_40;
                                } - @as(u64, 1)), .root = (state_1).root, .sifting = (state_1).sifting, });
                            };
                            const value_42: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_104: {
                                break :block_104 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_41).building, .count = (value_41).count, .names = (value_41).names, .positions = (value_41).positions, .remaining = (value_41).remaining, .root = (value_41).remaining, .sifting = (value_41).sifting, });
                            };
                            const value_43: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_103: {
                                break :block_103 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_42).building, .count = (value_42).count, .names = (value_42).names, .positions = (value_42).positions, .remaining = (value_42).remaining, .root = (value_42).root, .sifting = true, });
                            };

                            break :block_107 value_43;
                        });

                        break :block_108 value_44;
                    } else block_159: {
                        const value_45: u64 = (state_1).count;
                        const value_46: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_158: {
                            break :block_158 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (state_1).building, .count = (block_157: {
                                break :block_157 value_45;
                            } - @as(u64, 1)), .names = (state_1).names, .positions = (state_1).positions, .remaining = (state_1).remaining, .root = (state_1).root, .sifting = (state_1).sifting, });
                        };
                        const value_47: []const u8 = block_156: {
                            const operand_154 = (value_46).names;
                            const operand_155 = @as(u64, 0);

                            if ((operand_155 >= (operand_154).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_156 (operand_154)[@intCast(operand_155)];
                        };
                        const value_48: u64 = block_153: {
                            const operand_151 = (value_46).positions;
                            const operand_152 = @as(u64, 0);

                            if ((operand_152 >= (operand_151).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_153 (operand_151)[@intCast(operand_152)];
                        };
                        const value_49: []const []const u8 = (value_46).names;
                        const value_50: u64 = @as(u64, 0);
                        const value_51: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_150: {
                            break :block_150 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_46).building, .count = (value_46).count, .names = block_149: {
                                const operand_141 = block_140: {
                                    break :block_140 value_49;
                                };
                                const operand_143 = block_142: {
                                    break :block_142 value_50;
                                };

                                if ((operand_143 >= (operand_141).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_147 = block_146: {
                                    const operand_144 = (value_46).names;
                                    const operand_145 = (value_46).count;

                                    if ((operand_145 >= (operand_144).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_146 (operand_144)[@intCast(operand_145)];
                                };

                                break :block_149 block_148: {
                                    if ((!state_items_started_12)) {
                                        state_items_11 = (try (allocator).dupe([]const u8, operand_141));

                                        state_items_started_12 = true;
                                    }

                                    (state_items_11)[@intCast(operand_143)] = operand_147;

                                    break :block_148 state_items_11;
                                };
                            }, .positions = (value_46).positions, .remaining = (value_46).remaining, .root = (value_46).root, .sifting = (value_46).sifting, });
                        };
                        const value_52: []const u64 = (value_51).positions;
                        const value_53: u64 = @as(u64, 0);
                        const value_54: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_139: {
                            break :block_139 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_51).building, .count = (value_51).count, .names = (value_51).names, .positions = block_138: {
                                const operand_130 = block_129: {
                                    break :block_129 value_52;
                                };
                                const operand_132 = block_131: {
                                    break :block_131 value_53;
                                };

                                if ((operand_132 >= (operand_130).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_136 = block_135: {
                                    const operand_133 = (value_51).positions;
                                    const operand_134 = (value_51).count;

                                    if ((operand_134 >= (operand_133).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_135 (operand_133)[@intCast(operand_134)];
                                };

                                break :block_138 block_137: {
                                    if ((!state_items_started_14)) {
                                        state_items_13 = (try (allocator).dupe(u64, operand_130));

                                        state_items_started_14 = true;
                                    }

                                    (state_items_13)[@intCast(operand_132)] = operand_136;

                                    break :block_137 state_items_13;
                                };
                            }, .remaining = (value_51).remaining, .root = (value_51).root, .sifting = (value_51).sifting, });
                        };
                        const value_55: []const []const u8 = (value_54).names;
                        const value_56: u64 = (value_54).count;
                        const value_57: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_128: {
                            break :block_128 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_54).building, .count = (value_54).count, .names = block_127: {
                                const operand_121 = block_120: {
                                    break :block_120 value_55;
                                };
                                const operand_123 = block_122: {
                                    break :block_122 value_56;
                                };

                                if ((operand_123 >= (operand_121).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_125 = block_124: {
                                    break :block_124 value_47;
                                };

                                break :block_127 block_126: {
                                    if ((!state_items_started_12)) {
                                        state_items_11 = (try (allocator).dupe([]const u8, operand_121));

                                        state_items_started_12 = true;
                                    }

                                    (state_items_11)[@intCast(operand_123)] = operand_125;

                                    break :block_126 state_items_11;
                                };
                            }, .positions = (value_54).positions, .remaining = (value_54).remaining, .root = (value_54).root, .sifting = (value_54).sifting, });
                        };
                        const value_58: []const u64 = (value_57).positions;
                        const value_59: u64 = (value_57).count;
                        const value_60: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_119: {
                            break :block_119 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_57).building, .count = (value_57).count, .names = (value_57).names, .positions = block_118: {
                                const operand_112 = block_111: {
                                    break :block_111 value_58;
                                };
                                const operand_114 = block_113: {
                                    break :block_113 value_59;
                                };

                                if ((operand_114 >= (operand_112).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_116 = block_115: {
                                    break :block_115 value_48;
                                };

                                break :block_118 block_117: {
                                    if ((!state_items_started_14)) {
                                        state_items_13 = (try (allocator).dupe(u64, operand_112));

                                        state_items_started_14 = true;
                                    }

                                    (state_items_13)[@intCast(operand_114)] = operand_116;

                                    break :block_117 state_items_13;
                                };
                            }, .remaining = (value_57).remaining, .root = (value_57).root, .sifting = (value_57).sifting, });
                        };
                        const value_61: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_110: {
                            break :block_110 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_60).building, .count = (value_60).count, .names = (value_60).names, .positions = (value_60).positions, .remaining = (value_60).remaining, .root = @as(u64, 0), .sifting = (value_60).sifting, });
                        };
                        const value_62: (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_109: {
                            break :block_109 @as((zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .building = (value_61).building, .count = (value_61).count, .names = (value_61).names, .positions = (value_61).positions, .remaining = (value_61).remaining, .root = (value_61).root, .sifting = true, });
                        };

                        break :block_159 value_62;
                    });

                    break :block_160 value_63;
                });

                break :block_161 value_64;
            };
        }

        break :block_162 (state_1).positions;
    };
}

fn function_18(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_91) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_80 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = (try function_17(allocator, block_98: {
        const operand_92 = ((in).state).source;
        const operand_93 = (in).position;
        const operand_94 = (in).count;
        const operand_95 = (in).object;

        break :block_98 block_97: {
            const operand_96 = (try (allocator).create((zx_abi).zx_type_90));

            (operand_96).* = @as((zx_abi).zx_type_90, (zx_abi).zx_type_90{ .source = operand_92, .position = operand_93, .count = operand_94, .object = operand_95, });

            break :block_97 @as(*const (zx_abi).zx_type_90, operand_96);
        };
    }));
    const value_11: *const (zx_abi).zx_type_104 = block_91: {
        const operand_9 = block_8: {
            const operand_2 = (in).state;
            const operand_3 = value_1;
            const operand_4 = @as(u64, (value_1).len);
            const operand_5 = (in).object;

            break :block_8 block_7: {
                const operand_6 = (try (allocator).create((zx_abi).zx_type_104));

                (operand_6).* = @as((zx_abi).zx_type_104, (zx_abi).zx_type_104{ .state = operand_2, .positions = operand_3, .remaining = operand_4, .object = operand_5, });

                break :block_7 @as(*const (zx_abi).zx_type_104, operand_6);
            };
        };

        var state_capacity_11: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_12 = false;

        defer (state_capacity_11).deinit(allocator);

        var state_capacity_13: (std).ArrayList(bool) = .empty;

        var state_capacity_started_14 = false;

        defer (state_capacity_13).deinit(allocator);

        var state_capacity_15: (std).ArrayList(u64) = .empty;

        var state_capacity_started_16 = false;

        defer (state_capacity_15).deinit(allocator);

        var state_1: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (operand_9).object, .positions = (operand_9).positions, .remaining = (operand_9).remaining, .state = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((operand_9).state).names, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = ((((operand_9).state).source).indexed).bytes, .declarations = ((((operand_9).state).source).indexed).declarations, .members = ((((operand_9).state).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = (((((operand_9).state).source).indexed).order).fields, .heads = (((((operand_9).state).source).indexed).order).heads, .items = (((((operand_9).state).source).indexed).order).items, .zx_origin = ((((operand_9).state).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = (((((operand_9).state).source).indexed).types).fields, .items = (((((operand_9).state).source).indexed).types).items, .nodes = (((((operand_9).state).source).indexed).types).nodes, .zx_origin = ((((operand_9).state).source).indexed).types, }, .zx_origin = (((operand_9).state).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if (((((operand_9).state).source).native != null)) block_69: {
            break :block_69 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = ((((operand_9).state).source).native.?).declarations, .enumerations = ((((operand_9).state).source).native.?).enumerations, .fields = ((((operand_9).state).source).native.?).fields, .items = ((((operand_9).state).source).native.?).items, .members = ((((operand_9).state).source).native.?).members, .nodes = ((((operand_9).state).source).native.?).nodes, .zx_origin = (((operand_9).state).source).native.?, };
        } else null)), .zx_origin = ((operand_9).state).source, }, .valid = ((operand_9).state).valid, .work = (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((operand_9).state).work).aliases, .enumerations = (((operand_9).state).work).enumerations, .nodes = (((operand_9).state).work).nodes, .zx_origin = ((operand_9).state).work, }, .zx_origin = (operand_9).state, }, .zx_origin = operand_9, };

        var state_changed_10 = false;

        while (((state_1).remaining != @as(u64, 0))) {
            state_1 = block_68: {
                const value_4: u64 = (state_1).remaining;
                const value_5: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_67: {
                    break :block_67 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_1).object, .positions = (state_1).positions, .remaining = (block_66: {
                        break :block_66 value_4;
                    } - @as(u64, 1)), .state = (state_1).state, });
                };
                const value_6: u64 = block_65: {
                    const operand_63 = (value_5).positions;
                    const operand_64 = (value_5).remaining;

                    if ((operand_64 >= (operand_63).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_65 (operand_63)[@intCast(operand_64)];
                };
                const value_7: *const (zx_abi).zx_type_50 = (if ((value_5).object) (block_49: {
                    const operand_41 = block_40: {
                        const operand_37 = ((value_5).state).source;
                        const operand_38 = block_39: {
                            break :block_39 value_6;
                        };

                        break :block_40 @as((zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_37, .position = operand_38, });
                    };

                    var state_borrow_42: (zx_abi).zx_type_34 = undefined;

                    state_borrow_42 = (zx_abi).zx_type_34{ .fields = ((((operand_41).source).indexed).order).fields, .heads = ((((operand_41).source).indexed).order).heads, .items = ((((operand_41).source).indexed).order).items, };

                    var state_borrow_43: (zx_abi).zx_type_38 = undefined;

                    state_borrow_43 = (zx_abi).zx_type_38{ .fields = ((((operand_41).source).indexed).types).fields, .items = ((((operand_41).source).indexed).types).items, .nodes = ((((operand_41).source).indexed).types).nodes, };

                    var state_borrow_44: (zx_abi).zx_type_64 = undefined;

                    state_borrow_44 = (zx_abi).zx_type_64{ .bytes = (((operand_41).source).indexed).bytes, .declarations = (((operand_41).source).indexed).declarations, .members = (((operand_41).source).indexed).members, .order = (((((operand_41).source).indexed).order).zx_origin orelse (&state_borrow_42)), .types = (((((operand_41).source).indexed).types).zx_origin orelse (&state_borrow_43)), };

                    var state_borrow_45: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_47: (zx_abi).zx_type_66 = undefined;

                    state_borrow_47 = (zx_abi).zx_type_66{ .indexed = ((((operand_41).source).indexed).zx_origin orelse (&state_borrow_44)), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_41).source).native != null)) block_46: {
                        state_borrow_45 = (zx_abi).zx_type_62{ .declarations = (((operand_41).source).native.?).declarations, .enumerations = (((operand_41).source).native.?).enumerations, .fields = (((operand_41).source).native.?).fields, .items = (((operand_41).source).native.?).items, .members = (((operand_41).source).native.?).members, .nodes = (((operand_41).source).native.?).nodes, };

                        break :block_46 ((((operand_41).source).native.?).zx_origin orelse (&state_borrow_45));
                    } else null)), };

                    var state_borrow_48: (zx_abi).zx_type_88 = undefined;

                    state_borrow_48 = (zx_abi).zx_type_88{ .position = (operand_41).position, .source = (((operand_41).source).zx_origin orelse (&state_borrow_47)), };

                    break :block_49 (try function_14_value(allocator, ((operand_41).zx_origin orelse (&state_borrow_48))));
                }).value else (block_62: {
                    const operand_54 = block_53: {
                        const operand_50 = ((value_5).state).source;
                        const operand_51 = block_52: {
                            break :block_52 value_6;
                        };

                        break :block_53 @as((zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_50, .position = operand_51, });
                    };

                    var state_borrow_55: (zx_abi).zx_type_34 = undefined;

                    state_borrow_55 = (zx_abi).zx_type_34{ .fields = ((((operand_54).source).indexed).order).fields, .heads = ((((operand_54).source).indexed).order).heads, .items = ((((operand_54).source).indexed).order).items, };

                    var state_borrow_56: (zx_abi).zx_type_38 = undefined;

                    state_borrow_56 = (zx_abi).zx_type_38{ .fields = ((((operand_54).source).indexed).types).fields, .items = ((((operand_54).source).indexed).types).items, .nodes = ((((operand_54).source).indexed).types).nodes, };

                    var state_borrow_57: (zx_abi).zx_type_64 = undefined;

                    state_borrow_57 = (zx_abi).zx_type_64{ .bytes = (((operand_54).source).indexed).bytes, .declarations = (((operand_54).source).indexed).declarations, .members = (((operand_54).source).indexed).members, .order = (((((operand_54).source).indexed).order).zx_origin orelse (&state_borrow_55)), .types = (((((operand_54).source).indexed).types).zx_origin orelse (&state_borrow_56)), };

                    var state_borrow_58: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_60: (zx_abi).zx_type_66 = undefined;

                    state_borrow_60 = (zx_abi).zx_type_66{ .indexed = ((((operand_54).source).indexed).zx_origin orelse (&state_borrow_57)), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_54).source).native != null)) block_59: {
                        state_borrow_58 = (zx_abi).zx_type_62{ .declarations = (((operand_54).source).native.?).declarations, .enumerations = (((operand_54).source).native.?).enumerations, .fields = (((operand_54).source).native.?).fields, .items = (((operand_54).source).native.?).items, .members = (((operand_54).source).native.?).members, .nodes = (((operand_54).source).native.?).nodes, };

                        break :block_59 ((((operand_54).source).native.?).zx_origin orelse (&state_borrow_58));
                    } else null)), };

                    var state_borrow_61: (zx_abi).zx_type_88 = undefined;

                    state_borrow_61 = (zx_abi).zx_type_88{ .position = (operand_54).position, .source = (((operand_54).source).zx_origin orelse (&state_borrow_60)), };

                    break :block_62 (try function_15_value(allocator, ((operand_54).zx_origin orelse (&state_borrow_61))));
                }).value);
                const value_8: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_36: {
                    break :block_36 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_5).object, .positions = (value_5).positions, .remaining = (value_5).remaining, .state = block_35: {
                        break :block_35 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_5).state).names, .source = ((value_5).state).source, .valid = ((value_5).state).valid, .work = block_34: {
                            break :block_34 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((value_5).state).work).aliases, .enumerations = (((value_5).state).work).enumerations, .nodes = (block_33: {
                                const operand_30 = (((value_5).state).work).nodes;
                                const operand_32 = (block_31: {
                                    break :block_31 value_7;
                                }).index;

                                _ = (try ((std).math).add(usize, (operand_30).len, 1));

                                if ((!state_capacity_started_16)) {
                                    (try (state_capacity_15).appendSlice(allocator, operand_30));

                                    state_capacity_started_16 = true;
                                } else {
                                    ((state_capacity_15).items).len = (operand_30).len;
                                }

                                (try (state_capacity_15).append(allocator, operand_32));

                                break :block_33 @as((zx_abi).value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_15).items, {}, null, });
                            }).@"0", });
                        }, });
                    }, });
                };
                const value_9: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_29: {
                    break :block_29 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_8).object, .positions = (value_8).positions, .remaining = (value_8).remaining, .state = block_28: {
                        break :block_28 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_8).state).names, .source = ((value_8).state).source, .valid = ((value_8).state).valid, .work = block_27: {
                            break :block_27 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((value_8).state).work).aliases, .enumerations = (block_26: {
                                const operand_23 = (((value_8).state).work).enumerations;
                                const operand_25 = (block_24: {
                                    break :block_24 value_7;
                                }).enumeration;

                                _ = (try ((std).math).add(usize, (operand_23).len, 1));

                                if ((!state_capacity_started_14)) {
                                    (try (state_capacity_13).appendSlice(allocator, operand_23));

                                    state_capacity_started_14 = true;
                                } else {
                                    ((state_capacity_13).items).len = (operand_23).len;
                                }

                                (try (state_capacity_13).append(allocator, operand_25));

                                break :block_26 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_13).items, {}, null, });
                            }).@"0", .nodes = (((value_8).state).work).nodes, });
                        }, });
                    }, });
                };
                const value_10: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_22: {
                    break :block_22 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_9).object, .positions = (value_9).positions, .remaining = (value_9).remaining, .state = block_21: {
                        break :block_21 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_9).state).names, .source = ((value_9).state).source, .valid = ((value_9).state).valid, .work = block_20: {
                            break :block_20 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (block_19: {
                                const operand_17 = (((value_9).state).work).aliases;
                                const operand_18 = @as(?[]const u8, null);

                                _ = (try ((std).math).add(usize, (operand_17).len, 1));

                                if ((!state_capacity_started_12)) {
                                    (try (state_capacity_11).appendSlice(allocator, operand_17));

                                    state_capacity_started_12 = true;
                                } else {
                                    ((state_capacity_11).items).len = (operand_17).len;
                                }

                                (try (state_capacity_11).append(allocator, operand_18));

                                break :block_19 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_11).items, {}, null, });
                            }).@"0", .enumerations = (((value_9).state).work).enumerations, .nodes = (((value_9).state).work).nodes, });
                        }, });
                    }, });
                };

                break :block_68 value_10;
            };

            state_changed_10 = true;
        }

        var state_owned_70: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_70);

        if (state_capacity_started_12) {
            ((state_capacity_11).items).len = ((((state_1).state).work).aliases).len;

            state_owned_70 = (try (state_capacity_11).toOwnedSlice(allocator));
        }

        if (state_capacity_started_12) {
            state_1 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_1).object, .positions = (state_1).positions, .remaining = (state_1).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_1).state).names, .source = ((state_1).state).source, .valid = ((state_1).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_70, .enumerations = (((state_1).state).work).enumerations, .nodes = (((state_1).state).work).nodes, }), }), };
        }

        var state_owned_71: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_71);

        if (state_capacity_started_14) {
            ((state_capacity_13).items).len = ((((state_1).state).work).enumerations).len;

            state_owned_71 = (try (state_capacity_13).toOwnedSlice(allocator));
        }

        if (state_capacity_started_14) {
            state_1 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_1).object, .positions = (state_1).positions, .remaining = (state_1).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_1).state).names, .source = ((state_1).state).source, .valid = ((state_1).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_1).state).work).aliases, .enumerations = state_owned_71, .nodes = (((state_1).state).work).nodes, }), }), };
        }

        var state_owned_72: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_72);

        if (state_capacity_started_16) {
            ((state_capacity_15).items).len = ((((state_1).state).work).nodes).len;

            state_owned_72 = (try (state_capacity_15).toOwnedSlice(allocator));
        }

        if (state_capacity_started_16) {
            state_1 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_1).object, .positions = (state_1).positions, .remaining = (state_1).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_1).state).names, .source = ((state_1).state).source, .valid = ((state_1).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_1).state).work).aliases, .enumerations = (((state_1).state).work).enumerations, .nodes = state_owned_72, }), }), };
        }

        break :block_91 (if (state_changed_10) block_90: {
            break :block_90 (if (((state_1).zx_origin != null)) (state_1).zx_origin.? else block_89: {
                const operand_88 = (try (allocator).create((zx_abi).zx_type_104));

                (operand_88).* = (zx_abi).zx_type_104{ .object = (state_1).object, .positions = (state_1).positions, .remaining = (state_1).remaining, .state = (if ((((state_1).state).zx_origin != null)) ((state_1).state).zx_origin.? else block_87: {
                    const operand_86 = (try (allocator).create((zx_abi).zx_type_80));

                    (operand_86).* = (zx_abi).zx_type_80{ .names = ((state_1).state).names, .source = (if (((((state_1).state).source).zx_origin != null)) (((state_1).state).source).zx_origin.? else block_83: {
                        const operand_82 = (try (allocator).create((zx_abi).zx_type_66));

                        (operand_82).* = (zx_abi).zx_type_66{ .indexed = (if ((((((state_1).state).source).indexed).zx_origin != null)) ((((state_1).state).source).indexed).zx_origin.? else block_78: {
                            const operand_77 = (try (allocator).create((zx_abi).zx_type_64));

                            (operand_77).* = (zx_abi).zx_type_64{ .bytes = ((((state_1).state).source).indexed).bytes, .declarations = ((((state_1).state).source).indexed).declarations, .members = ((((state_1).state).source).indexed).members, .order = (if (((((((state_1).state).source).indexed).order).zx_origin != null)) (((((state_1).state).source).indexed).order).zx_origin.? else block_74: {
                                const operand_73 = (try (allocator).create((zx_abi).zx_type_34));

                                (operand_73).* = (zx_abi).zx_type_34{ .fields = (((((state_1).state).source).indexed).order).fields, .heads = (((((state_1).state).source).indexed).order).heads, .items = (((((state_1).state).source).indexed).order).items, };

                                break :block_74 @as(*const (zx_abi).zx_type_34, operand_73);
                            }), .types = (if (((((((state_1).state).source).indexed).types).zx_origin != null)) (((((state_1).state).source).indexed).types).zx_origin.? else block_76: {
                                const operand_75 = (try (allocator).create((zx_abi).zx_type_38));

                                (operand_75).* = (zx_abi).zx_type_38{ .fields = (((((state_1).state).source).indexed).types).fields, .items = (((((state_1).state).source).indexed).types).items, .nodes = (((((state_1).state).source).indexed).types).nodes, };

                                break :block_76 @as(*const (zx_abi).zx_type_38, operand_75);
                            }), };

                            break :block_78 @as(*const (zx_abi).zx_type_64, operand_77);
                        }), .native = @as(?*const (zx_abi).zx_type_62, (if (((((state_1).state).source).native != null)) block_81: {
                            break :block_81 (if ((((((state_1).state).source).native.?).zx_origin != null)) ((((state_1).state).source).native.?).zx_origin.? else block_80: {
                                const operand_79 = (try (allocator).create((zx_abi).zx_type_62));

                                (operand_79).* = (zx_abi).zx_type_62{ .declarations = ((((state_1).state).source).native.?).declarations, .enumerations = ((((state_1).state).source).native.?).enumerations, .fields = ((((state_1).state).source).native.?).fields, .items = ((((state_1).state).source).native.?).items, .members = ((((state_1).state).source).native.?).members, .nodes = ((((state_1).state).source).native.?).nodes, };

                                break :block_80 @as(*const (zx_abi).zx_type_62, operand_79);
                            });
                        } else null)), };

                        break :block_83 @as(*const (zx_abi).zx_type_66, operand_82);
                    }), .valid = ((state_1).state).valid, .work = (if (((((state_1).state).work).zx_origin != null)) (((state_1).state).work).zx_origin.? else block_85: {
                        const operand_84 = (try (allocator).create((zx_abi).zx_type_79));

                        (operand_84).* = (zx_abi).zx_type_79{ .aliases = (((state_1).state).work).aliases, .enumerations = (((state_1).state).work).enumerations, .nodes = (((state_1).state).work).nodes, };

                        break :block_85 @as(*const (zx_abi).zx_type_79, operand_84);
                    }), };

                    break :block_87 @as(*const (zx_abi).zx_type_80, operand_86);
                }), };

                break :block_89 @as(*const (zx_abi).zx_type_104, operand_88);
            });
        } else operand_9);
    };

    return (value_11).state;
}

fn function_18_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_91_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = block_191: {
        const operand_177 = block_176: {
            const operand_172 = ((in).state).source;
            const operand_173 = (in).position;
            const operand_174 = (in).count;
            const operand_175 = (in).object;

            break :block_176 @as((zx_abi).value_zx_type_90_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0, (zx_abi).value_zx_type_90_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0{ .source = operand_172, .position = operand_173, .count = operand_174, .object = operand_175, });
        };

        break :block_191 (try function_17(allocator, (if (((operand_177).zx_origin != null)) (operand_177).zx_origin.? else block_190: {
            const operand_189 = (try (allocator).create((zx_abi).zx_type_90));

            (operand_189).* = (zx_abi).zx_type_90{ .count = (operand_177).count, .object = (operand_177).object, .position = (operand_177).position, .source = (if ((((operand_177).source).zx_origin != null)) ((operand_177).source).zx_origin.? else block_188: {
                const operand_187 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_187).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_177).source).indexed).zx_origin != null)) (((operand_177).source).indexed).zx_origin.? else block_183: {
                    const operand_182 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_182).* = (zx_abi).zx_type_64{ .bytes = (((operand_177).source).indexed).bytes, .declarations = (((operand_177).source).indexed).declarations, .members = (((operand_177).source).indexed).members, .order = (if ((((((operand_177).source).indexed).order).zx_origin != null)) ((((operand_177).source).indexed).order).zx_origin.? else block_179: {
                        const operand_178 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_178).* = (zx_abi).zx_type_34{ .fields = ((((operand_177).source).indexed).order).fields, .heads = ((((operand_177).source).indexed).order).heads, .items = ((((operand_177).source).indexed).order).items, };

                        break :block_179 @as(*const (zx_abi).zx_type_34, operand_178);
                    }), .types = (if ((((((operand_177).source).indexed).types).zx_origin != null)) ((((operand_177).source).indexed).types).zx_origin.? else block_181: {
                        const operand_180 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_180).* = (zx_abi).zx_type_38{ .fields = ((((operand_177).source).indexed).types).fields, .items = ((((operand_177).source).indexed).types).items, .nodes = ((((operand_177).source).indexed).types).nodes, };

                        break :block_181 @as(*const (zx_abi).zx_type_38, operand_180);
                    }), };

                    break :block_183 @as(*const (zx_abi).zx_type_64, operand_182);
                }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_177).source).native != null)) block_186: {
                    break :block_186 (if (((((operand_177).source).native.?).zx_origin != null)) (((operand_177).source).native.?).zx_origin.? else block_185: {
                        const operand_184 = (try (allocator).create((zx_abi).zx_type_62));

                        (operand_184).* = (zx_abi).zx_type_62{ .declarations = (((operand_177).source).native.?).declarations, .enumerations = (((operand_177).source).native.?).enumerations, .fields = (((operand_177).source).native.?).fields, .items = (((operand_177).source).native.?).items, .members = (((operand_177).source).native.?).members, .nodes = (((operand_177).source).native.?).nodes, };

                        break :block_185 @as(*const (zx_abi).zx_type_62, operand_184);
                    });
                } else null)), };

                break :block_188 @as(*const (zx_abi).zx_type_66, operand_187);
            }), };

            break :block_190 @as(*const (zx_abi).zx_type_90, operand_189);
        })));
    };
    const value_11: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_171: {
        const operand_107 = block_106: {
            const operand_100 = (in).state;
            const operand_101 = block_102: {
                break :block_102 value_1;
            };
            const operand_103 = @as(u64, (block_104: {
                break :block_104 value_1;
            }).len);
            const operand_105 = (in).object;

            break :block_106 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .state = operand_100, .positions = operand_101, .remaining = operand_103, .object = operand_105, });
        };

        var state_capacity_109: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_110 = false;

        defer (state_capacity_109).deinit(allocator);

        var state_capacity_111: (std).ArrayList(bool) = .empty;

        var state_capacity_started_112 = false;

        defer (state_capacity_111).deinit(allocator);

        var state_capacity_113: (std).ArrayList(u64) = .empty;

        var state_capacity_started_114 = false;

        defer (state_capacity_113).deinit(allocator);

        var state_99: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = operand_107;

        var state_changed_108 = false;

        while (((state_99).remaining != @as(u64, 0))) {
            state_99 = block_166: {
                const value_4: u64 = (state_99).remaining;
                const value_5: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_165: {
                    break :block_165 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_99).object, .positions = (state_99).positions, .remaining = (block_164: {
                        break :block_164 value_4;
                    } - @as(u64, 1)), .state = (state_99).state, });
                };
                const value_6: u64 = block_163: {
                    const operand_161 = (value_5).positions;
                    const operand_162 = (value_5).remaining;

                    if ((operand_162 >= (operand_161).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_163 (operand_161)[@intCast(operand_162)];
                };
                const value_7: (zx_abi).zx_type_50 = (if ((value_5).object) ((block_147: {
                    const operand_139 = block_138: {
                        const operand_135 = ((value_5).state).source;
                        const operand_136 = block_137: {
                            break :block_137 value_6;
                        };

                        break :block_138 @as((zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_135, .position = operand_136, });
                    };

                    var state_borrow_140: (zx_abi).zx_type_34 = undefined;

                    state_borrow_140 = (zx_abi).zx_type_34{ .fields = ((((operand_139).source).indexed).order).fields, .heads = ((((operand_139).source).indexed).order).heads, .items = ((((operand_139).source).indexed).order).items, };

                    var state_borrow_141: (zx_abi).zx_type_38 = undefined;

                    state_borrow_141 = (zx_abi).zx_type_38{ .fields = ((((operand_139).source).indexed).types).fields, .items = ((((operand_139).source).indexed).types).items, .nodes = ((((operand_139).source).indexed).types).nodes, };

                    var state_borrow_142: (zx_abi).zx_type_64 = undefined;

                    state_borrow_142 = (zx_abi).zx_type_64{ .bytes = (((operand_139).source).indexed).bytes, .declarations = (((operand_139).source).indexed).declarations, .members = (((operand_139).source).indexed).members, .order = (((((operand_139).source).indexed).order).zx_origin orelse (&state_borrow_140)), .types = (((((operand_139).source).indexed).types).zx_origin orelse (&state_borrow_141)), };

                    var state_borrow_143: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_145: (zx_abi).zx_type_66 = undefined;

                    state_borrow_145 = (zx_abi).zx_type_66{ .indexed = ((((operand_139).source).indexed).zx_origin orelse (&state_borrow_142)), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_139).source).native != null)) block_144: {
                        state_borrow_143 = (zx_abi).zx_type_62{ .declarations = (((operand_139).source).native.?).declarations, .enumerations = (((operand_139).source).native.?).enumerations, .fields = (((operand_139).source).native.?).fields, .items = (((operand_139).source).native.?).items, .members = (((operand_139).source).native.?).members, .nodes = (((operand_139).source).native.?).nodes, };

                        break :block_144 ((((operand_139).source).native.?).zx_origin orelse (&state_borrow_143));
                    } else null)), };

                    var state_borrow_146: (zx_abi).zx_type_88 = undefined;

                    state_borrow_146 = (zx_abi).zx_type_88{ .position = (operand_139).position, .source = (((operand_139).source).zx_origin orelse (&state_borrow_145)), };

                    break :block_147 (try function_14_value(allocator, ((operand_139).zx_origin orelse (&state_borrow_146))));
                }).value).* else ((block_160: {
                    const operand_152 = block_151: {
                        const operand_148 = ((value_5).state).source;
                        const operand_149 = block_150: {
                            break :block_150 value_6;
                        };

                        break :block_151 @as((zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_148, .position = operand_149, });
                    };

                    var state_borrow_153: (zx_abi).zx_type_34 = undefined;

                    state_borrow_153 = (zx_abi).zx_type_34{ .fields = ((((operand_152).source).indexed).order).fields, .heads = ((((operand_152).source).indexed).order).heads, .items = ((((operand_152).source).indexed).order).items, };

                    var state_borrow_154: (zx_abi).zx_type_38 = undefined;

                    state_borrow_154 = (zx_abi).zx_type_38{ .fields = ((((operand_152).source).indexed).types).fields, .items = ((((operand_152).source).indexed).types).items, .nodes = ((((operand_152).source).indexed).types).nodes, };

                    var state_borrow_155: (zx_abi).zx_type_64 = undefined;

                    state_borrow_155 = (zx_abi).zx_type_64{ .bytes = (((operand_152).source).indexed).bytes, .declarations = (((operand_152).source).indexed).declarations, .members = (((operand_152).source).indexed).members, .order = (((((operand_152).source).indexed).order).zx_origin orelse (&state_borrow_153)), .types = (((((operand_152).source).indexed).types).zx_origin orelse (&state_borrow_154)), };

                    var state_borrow_156: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_158: (zx_abi).zx_type_66 = undefined;

                    state_borrow_158 = (zx_abi).zx_type_66{ .indexed = ((((operand_152).source).indexed).zx_origin orelse (&state_borrow_155)), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_152).source).native != null)) block_157: {
                        state_borrow_156 = (zx_abi).zx_type_62{ .declarations = (((operand_152).source).native.?).declarations, .enumerations = (((operand_152).source).native.?).enumerations, .fields = (((operand_152).source).native.?).fields, .items = (((operand_152).source).native.?).items, .members = (((operand_152).source).native.?).members, .nodes = (((operand_152).source).native.?).nodes, };

                        break :block_157 ((((operand_152).source).native.?).zx_origin orelse (&state_borrow_156));
                    } else null)), };

                    var state_borrow_159: (zx_abi).zx_type_88 = undefined;

                    state_borrow_159 = (zx_abi).zx_type_88{ .position = (operand_152).position, .source = (((operand_152).source).zx_origin orelse (&state_borrow_158)), };

                    break :block_160 (try function_15_value(allocator, ((operand_152).zx_origin orelse (&state_borrow_159))));
                }).value).*);
                const value_8: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_134: {
                    break :block_134 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_5).object, .positions = (value_5).positions, .remaining = (value_5).remaining, .state = block_133: {
                        break :block_133 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_5).state).names, .source = ((value_5).state).source, .valid = ((value_5).state).valid, .work = block_132: {
                            break :block_132 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((value_5).state).work).aliases, .enumerations = (((value_5).state).work).enumerations, .nodes = (block_131: {
                                const operand_128 = (((value_5).state).work).nodes;
                                const operand_130 = (block_129: {
                                    break :block_129 (&value_7);
                                }).index;

                                _ = (try ((std).math).add(usize, (operand_128).len, 1));

                                if ((!state_capacity_started_114)) {
                                    (try (state_capacity_113).appendSlice(allocator, operand_128));

                                    state_capacity_started_114 = true;
                                } else {
                                    ((state_capacity_113).items).len = (operand_128).len;
                                }

                                (try (state_capacity_113).append(allocator, operand_130));

                                break :block_131 @as((zx_abi).value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_113).items, {}, null, });
                            }).@"0", });
                        }, });
                    }, });
                };
                const value_9: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_127: {
                    break :block_127 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_8).object, .positions = (value_8).positions, .remaining = (value_8).remaining, .state = block_126: {
                        break :block_126 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_8).state).names, .source = ((value_8).state).source, .valid = ((value_8).state).valid, .work = block_125: {
                            break :block_125 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((value_8).state).work).aliases, .enumerations = (block_124: {
                                const operand_121 = (((value_8).state).work).enumerations;
                                const operand_123 = (block_122: {
                                    break :block_122 (&value_7);
                                }).enumeration;

                                _ = (try ((std).math).add(usize, (operand_121).len, 1));

                                if ((!state_capacity_started_112)) {
                                    (try (state_capacity_111).appendSlice(allocator, operand_121));

                                    state_capacity_started_112 = true;
                                } else {
                                    ((state_capacity_111).items).len = (operand_121).len;
                                }

                                (try (state_capacity_111).append(allocator, operand_123));

                                break :block_124 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_111).items, {}, null, });
                            }).@"0", .nodes = (((value_8).state).work).nodes, });
                        }, });
                    }, });
                };
                const value_10: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_120: {
                    break :block_120 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_9).object, .positions = (value_9).positions, .remaining = (value_9).remaining, .state = block_119: {
                        break :block_119 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_9).state).names, .source = ((value_9).state).source, .valid = ((value_9).state).valid, .work = block_118: {
                            break :block_118 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (block_117: {
                                const operand_115 = (((value_9).state).work).aliases;
                                const operand_116 = @as(?[]const u8, null);

                                _ = (try ((std).math).add(usize, (operand_115).len, 1));

                                if ((!state_capacity_started_110)) {
                                    (try (state_capacity_109).appendSlice(allocator, operand_115));

                                    state_capacity_started_110 = true;
                                } else {
                                    ((state_capacity_109).items).len = (operand_115).len;
                                }

                                (try (state_capacity_109).append(allocator, operand_116));

                                break :block_117 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_109).items, {}, null, });
                            }).@"0", .enumerations = (((value_9).state).work).enumerations, .nodes = (((value_9).state).work).nodes, });
                        }, });
                    }, });
                };

                break :block_166 value_10;
            };

            state_changed_108 = true;
        }

        var state_owned_167: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_167);

        if (state_capacity_started_110) {
            ((state_capacity_109).items).len = ((((state_99).state).work).aliases).len;

            state_owned_167 = (try (state_capacity_109).toOwnedSlice(allocator));
        }

        if (state_capacity_started_110) {
            state_99 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_99).object, .positions = (state_99).positions, .remaining = (state_99).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_99).state).names, .source = ((state_99).state).source, .valid = ((state_99).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_167, .enumerations = (((state_99).state).work).enumerations, .nodes = (((state_99).state).work).nodes, }), }), };
        }

        var state_owned_168: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_168);

        if (state_capacity_started_112) {
            ((state_capacity_111).items).len = ((((state_99).state).work).enumerations).len;

            state_owned_168 = (try (state_capacity_111).toOwnedSlice(allocator));
        }

        if (state_capacity_started_112) {
            state_99 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_99).object, .positions = (state_99).positions, .remaining = (state_99).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_99).state).names, .source = ((state_99).state).source, .valid = ((state_99).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_99).state).work).aliases, .enumerations = state_owned_168, .nodes = (((state_99).state).work).nodes, }), }), };
        }

        var state_owned_169: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_169);

        if (state_capacity_started_114) {
            ((state_capacity_113).items).len = ((((state_99).state).work).nodes).len;

            state_owned_169 = (try (state_capacity_113).toOwnedSlice(allocator));
        }

        if (state_capacity_started_114) {
            state_99 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_99).object, .positions = (state_99).positions, .remaining = (state_99).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_99).state).names, .source = ((state_99).state).source, .valid = ((state_99).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_99).state).work).aliases, .enumerations = (((state_99).state).work).enumerations, .nodes = state_owned_169, }), }), };
        }

        break :block_171 (if (state_changed_108) state_99 else operand_107);
    };

    return (value_11).state;
}

fn function_18_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_91_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_44),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_14),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_31),
        started: *bool,
    },
    lane_8: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_32),
        started: *bool,
    },
    lane_9: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_30),
        started: *bool,
    },
    lane_10: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_11: ?struct {
        buffer: *(std).ArrayList(bool),
        started: *bool,
    },
    lane_12: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
}) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = block_295: {
        const operand_281 = block_280: {
            const operand_276 = ((in).state).source;
            const operand_277 = (in).position;
            const operand_278 = (in).count;
            const operand_279 = (in).object;

            break :block_280 @as((zx_abi).value_zx_type_90_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0, (zx_abi).value_zx_type_90_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0{ .source = operand_276, .position = operand_277, .count = operand_278, .object = operand_279, });
        };

        break :block_295 (try function_17(allocator, (if (((operand_281).zx_origin != null)) (operand_281).zx_origin.? else block_294: {
            const operand_293 = (try (allocator).create((zx_abi).zx_type_90));

            (operand_293).* = (zx_abi).zx_type_90{ .count = (operand_281).count, .object = (operand_281).object, .position = (operand_281).position, .source = (if ((((operand_281).source).zx_origin != null)) ((operand_281).source).zx_origin.? else block_292: {
                const operand_291 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_291).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_281).source).indexed).zx_origin != null)) (((operand_281).source).indexed).zx_origin.? else block_287: {
                    const operand_286 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_286).* = (zx_abi).zx_type_64{ .bytes = (((operand_281).source).indexed).bytes, .declarations = (((operand_281).source).indexed).declarations, .members = (((operand_281).source).indexed).members, .order = (if ((((((operand_281).source).indexed).order).zx_origin != null)) ((((operand_281).source).indexed).order).zx_origin.? else block_283: {
                        const operand_282 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_282).* = (zx_abi).zx_type_34{ .fields = ((((operand_281).source).indexed).order).fields, .heads = ((((operand_281).source).indexed).order).heads, .items = ((((operand_281).source).indexed).order).items, };

                        break :block_283 @as(*const (zx_abi).zx_type_34, operand_282);
                    }), .types = (if ((((((operand_281).source).indexed).types).zx_origin != null)) ((((operand_281).source).indexed).types).zx_origin.? else block_285: {
                        const operand_284 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_284).* = (zx_abi).zx_type_38{ .fields = ((((operand_281).source).indexed).types).fields, .items = ((((operand_281).source).indexed).types).items, .nodes = ((((operand_281).source).indexed).types).nodes, };

                        break :block_285 @as(*const (zx_abi).zx_type_38, operand_284);
                    }), };

                    break :block_287 @as(*const (zx_abi).zx_type_64, operand_286);
                }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_281).source).native != null)) block_290: {
                    break :block_290 (if (((((operand_281).source).native.?).zx_origin != null)) (((operand_281).source).native.?).zx_origin.? else block_289: {
                        const operand_288 = (try (allocator).create((zx_abi).zx_type_62));

                        (operand_288).* = (zx_abi).zx_type_62{ .declarations = (((operand_281).source).native.?).declarations, .enumerations = (((operand_281).source).native.?).enumerations, .fields = (((operand_281).source).native.?).fields, .items = (((operand_281).source).native.?).items, .members = (((operand_281).source).native.?).members, .nodes = (((operand_281).source).native.?).nodes, };

                        break :block_289 @as(*const (zx_abi).zx_type_62, operand_288);
                    });
                } else null)), };

                break :block_292 @as(*const (zx_abi).zx_type_66, operand_291);
            }), };

            break :block_294 @as(*const (zx_abi).zx_type_90, operand_293);
        })));
    };
    const value_11: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_275: {
        const operand_200 = block_199: {
            const operand_193 = (in).state;
            const operand_194 = block_195: {
                break :block_195 value_1;
            };
            const operand_196 = @as(u64, (block_197: {
                break :block_197 value_1;
            }).len);
            const operand_198 = (in).object;

            break :block_199 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .state = operand_193, .positions = operand_194, .remaining = operand_196, .object = operand_198, });
        };

        var state_capacity_202: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_203 = false;

        defer (state_capacity_202).deinit(allocator);

        var state_capacity_204: (std).ArrayList(bool) = .empty;

        var state_capacity_started_205 = false;

        defer (state_capacity_204).deinit(allocator);

        var state_capacity_206: (std).ArrayList(u64) = .empty;

        var state_capacity_started_207 = false;

        defer (state_capacity_206).deinit(allocator);

        var state_192: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = operand_200;

        var state_changed_201 = false;

        while (((state_192).remaining != @as(u64, 0))) {
            state_192 = block_270: {
                const value_4: u64 = (state_192).remaining;
                const value_5: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_269: {
                    break :block_269 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_192).object, .positions = (state_192).positions, .remaining = (block_268: {
                        break :block_268 value_4;
                    } - @as(u64, 1)), .state = (state_192).state, });
                };
                const value_6: u64 = block_267: {
                    const operand_265 = (value_5).positions;
                    const operand_266 = (value_5).remaining;

                    if ((operand_266 >= (operand_265).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_267 (operand_265)[@intCast(operand_266)];
                };
                const value_7: (zx_abi).zx_type_50 = (if ((value_5).object) ((block_251: {
                    const operand_243 = block_242: {
                        const operand_239 = ((value_5).state).source;
                        const operand_240 = block_241: {
                            break :block_241 value_6;
                        };

                        break :block_242 @as((zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_239, .position = operand_240, });
                    };

                    var state_borrow_244: (zx_abi).zx_type_34 = undefined;

                    state_borrow_244 = (zx_abi).zx_type_34{ .fields = ((((operand_243).source).indexed).order).fields, .heads = ((((operand_243).source).indexed).order).heads, .items = ((((operand_243).source).indexed).order).items, };

                    var state_borrow_245: (zx_abi).zx_type_38 = undefined;

                    state_borrow_245 = (zx_abi).zx_type_38{ .fields = ((((operand_243).source).indexed).types).fields, .items = ((((operand_243).source).indexed).types).items, .nodes = ((((operand_243).source).indexed).types).nodes, };

                    var state_borrow_246: (zx_abi).zx_type_64 = undefined;

                    state_borrow_246 = (zx_abi).zx_type_64{ .bytes = (((operand_243).source).indexed).bytes, .declarations = (((operand_243).source).indexed).declarations, .members = (((operand_243).source).indexed).members, .order = (((((operand_243).source).indexed).order).zx_origin orelse (&state_borrow_244)), .types = (((((operand_243).source).indexed).types).zx_origin orelse (&state_borrow_245)), };

                    var state_borrow_247: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_249: (zx_abi).zx_type_66 = undefined;

                    state_borrow_249 = (zx_abi).zx_type_66{ .indexed = ((((operand_243).source).indexed).zx_origin orelse (&state_borrow_246)), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_243).source).native != null)) block_248: {
                        state_borrow_247 = (zx_abi).zx_type_62{ .declarations = (((operand_243).source).native.?).declarations, .enumerations = (((operand_243).source).native.?).enumerations, .fields = (((operand_243).source).native.?).fields, .items = (((operand_243).source).native.?).items, .members = (((operand_243).source).native.?).members, .nodes = (((operand_243).source).native.?).nodes, };

                        break :block_248 ((((operand_243).source).native.?).zx_origin orelse (&state_borrow_247));
                    } else null)), };

                    var state_borrow_250: (zx_abi).zx_type_88 = undefined;

                    state_borrow_250 = (zx_abi).zx_type_88{ .position = (operand_243).position, .source = (((operand_243).source).zx_origin orelse (&state_borrow_249)), };

                    break :block_251 (try function_14_value(allocator, ((operand_243).zx_origin orelse (&state_borrow_250))));
                }).value).* else ((block_264: {
                    const operand_256 = block_255: {
                        const operand_252 = ((value_5).state).source;
                        const operand_253 = block_254: {
                            break :block_254 value_6;
                        };

                        break :block_255 @as((zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_252, .position = operand_253, });
                    };

                    var state_borrow_257: (zx_abi).zx_type_34 = undefined;

                    state_borrow_257 = (zx_abi).zx_type_34{ .fields = ((((operand_256).source).indexed).order).fields, .heads = ((((operand_256).source).indexed).order).heads, .items = ((((operand_256).source).indexed).order).items, };

                    var state_borrow_258: (zx_abi).zx_type_38 = undefined;

                    state_borrow_258 = (zx_abi).zx_type_38{ .fields = ((((operand_256).source).indexed).types).fields, .items = ((((operand_256).source).indexed).types).items, .nodes = ((((operand_256).source).indexed).types).nodes, };

                    var state_borrow_259: (zx_abi).zx_type_64 = undefined;

                    state_borrow_259 = (zx_abi).zx_type_64{ .bytes = (((operand_256).source).indexed).bytes, .declarations = (((operand_256).source).indexed).declarations, .members = (((operand_256).source).indexed).members, .order = (((((operand_256).source).indexed).order).zx_origin orelse (&state_borrow_257)), .types = (((((operand_256).source).indexed).types).zx_origin orelse (&state_borrow_258)), };

                    var state_borrow_260: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_262: (zx_abi).zx_type_66 = undefined;

                    state_borrow_262 = (zx_abi).zx_type_66{ .indexed = ((((operand_256).source).indexed).zx_origin orelse (&state_borrow_259)), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_256).source).native != null)) block_261: {
                        state_borrow_260 = (zx_abi).zx_type_62{ .declarations = (((operand_256).source).native.?).declarations, .enumerations = (((operand_256).source).native.?).enumerations, .fields = (((operand_256).source).native.?).fields, .items = (((operand_256).source).native.?).items, .members = (((operand_256).source).native.?).members, .nodes = (((operand_256).source).native.?).nodes, };

                        break :block_261 ((((operand_256).source).native.?).zx_origin orelse (&state_borrow_260));
                    } else null)), };

                    var state_borrow_263: (zx_abi).zx_type_88 = undefined;

                    state_borrow_263 = (zx_abi).zx_type_88{ .position = (operand_256).position, .source = (((operand_256).source).zx_origin orelse (&state_borrow_262)), };

                    break :block_264 (try function_15_value(allocator, ((operand_256).zx_origin orelse (&state_borrow_263))));
                }).value).*);
                const value_8: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_238: {
                    break :block_238 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_5).object, .positions = (value_5).positions, .remaining = (value_5).remaining, .state = block_237: {
                        break :block_237 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_5).state).names, .source = ((value_5).state).source, .valid = ((value_5).state).valid, .work = block_236: {
                            break :block_236 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((value_5).state).work).aliases, .enumerations = (((value_5).state).work).enumerations, .nodes = @as([]const u64, (if (((buffers).lane_12 != null)) block_231: {
                                const operand_228 = (((value_5).state).work).nodes;
                                const operand_230 = (block_229: {
                                    break :block_229 (&value_7);
                                }).index;

                                _ = (try ((std).math).add(usize, (operand_228).len, 1));

                                if ((!(((buffers).lane_12.?).started).*)) {
                                    (try ((((buffers).lane_12.?).buffer).*).appendSlice(allocator, operand_228));

                                    (((buffers).lane_12.?).started).* = true;
                                } else {
                                    (((((buffers).lane_12.?).buffer).*).items).len = (operand_228).len;
                                }

                                (try ((((buffers).lane_12.?).buffer).*).append(allocator, operand_230));

                                break :block_231 ((((buffers).lane_12.?).buffer).*).items;
                            } else (block_235: {
                                const operand_232 = (((value_5).state).work).nodes;
                                const operand_234 = (block_233: {
                                    break :block_233 (&value_7);
                                }).index;

                                _ = (try ((std).math).add(usize, (operand_232).len, 1));

                                if ((!state_capacity_started_207)) {
                                    (try (state_capacity_206).appendSlice(allocator, operand_232));

                                    state_capacity_started_207 = true;
                                } else {
                                    ((state_capacity_206).items).len = (operand_232).len;
                                }

                                (try (state_capacity_206).append(allocator, operand_234));

                                break :block_235 @as((zx_abi).value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_206).items, {}, null, });
                            }).@"0")), });
                        }, });
                    }, });
                };
                const value_9: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_227: {
                    break :block_227 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_8).object, .positions = (value_8).positions, .remaining = (value_8).remaining, .state = block_226: {
                        break :block_226 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_8).state).names, .source = ((value_8).state).source, .valid = ((value_8).state).valid, .work = block_225: {
                            break :block_225 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((value_8).state).work).aliases, .enumerations = @as([]const bool, (if (((buffers).lane_11 != null)) block_220: {
                                const operand_217 = (((value_8).state).work).enumerations;
                                const operand_219 = (block_218: {
                                    break :block_218 (&value_7);
                                }).enumeration;

                                _ = (try ((std).math).add(usize, (operand_217).len, 1));

                                if ((!(((buffers).lane_11.?).started).*)) {
                                    (try ((((buffers).lane_11.?).buffer).*).appendSlice(allocator, operand_217));

                                    (((buffers).lane_11.?).started).* = true;
                                } else {
                                    (((((buffers).lane_11.?).buffer).*).items).len = (operand_217).len;
                                }

                                (try ((((buffers).lane_11.?).buffer).*).append(allocator, operand_219));

                                break :block_220 ((((buffers).lane_11.?).buffer).*).items;
                            } else (block_224: {
                                const operand_221 = (((value_8).state).work).enumerations;
                                const operand_223 = (block_222: {
                                    break :block_222 (&value_7);
                                }).enumeration;

                                _ = (try ((std).math).add(usize, (operand_221).len, 1));

                                if ((!state_capacity_started_205)) {
                                    (try (state_capacity_204).appendSlice(allocator, operand_221));

                                    state_capacity_started_205 = true;
                                } else {
                                    ((state_capacity_204).items).len = (operand_221).len;
                                }

                                (try (state_capacity_204).append(allocator, operand_223));

                                break :block_224 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_204).items, {}, null, });
                            }).@"0")), .nodes = (((value_8).state).work).nodes, });
                        }, });
                    }, });
                };
                const value_10: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_216: {
                    break :block_216 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_9).object, .positions = (value_9).positions, .remaining = (value_9).remaining, .state = block_215: {
                        break :block_215 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_9).state).names, .source = ((value_9).state).source, .valid = ((value_9).state).valid, .work = block_214: {
                            break :block_214 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = @as([]const ?[]const u8, (if (((buffers).lane_10 != null)) block_210: {
                                const operand_208 = (((value_9).state).work).aliases;
                                const operand_209 = @as(?[]const u8, null);

                                _ = (try ((std).math).add(usize, (operand_208).len, 1));

                                if ((!(((buffers).lane_10.?).started).*)) {
                                    (try ((((buffers).lane_10.?).buffer).*).appendSlice(allocator, operand_208));

                                    (((buffers).lane_10.?).started).* = true;
                                } else {
                                    (((((buffers).lane_10.?).buffer).*).items).len = (operand_208).len;
                                }

                                (try ((((buffers).lane_10.?).buffer).*).append(allocator, operand_209));

                                break :block_210 ((((buffers).lane_10.?).buffer).*).items;
                            } else (block_213: {
                                const operand_211 = (((value_9).state).work).aliases;
                                const operand_212 = @as(?[]const u8, null);

                                _ = (try ((std).math).add(usize, (operand_211).len, 1));

                                if ((!state_capacity_started_203)) {
                                    (try (state_capacity_202).appendSlice(allocator, operand_211));

                                    state_capacity_started_203 = true;
                                } else {
                                    ((state_capacity_202).items).len = (operand_211).len;
                                }

                                (try (state_capacity_202).append(allocator, operand_212));

                                break :block_213 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_202).items, {}, null, });
                            }).@"0")), .enumerations = (((value_9).state).work).enumerations, .nodes = (((value_9).state).work).nodes, });
                        }, });
                    }, });
                };

                break :block_270 value_10;
            };

            state_changed_201 = true;
        }

        var state_owned_271: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_271);

        if (state_capacity_started_203) {
            ((state_capacity_202).items).len = ((((state_192).state).work).aliases).len;

            state_owned_271 = (try (state_capacity_202).toOwnedSlice(allocator));
        }

        if (state_capacity_started_203) {
            state_192 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_192).object, .positions = (state_192).positions, .remaining = (state_192).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_192).state).names, .source = ((state_192).state).source, .valid = ((state_192).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_271, .enumerations = (((state_192).state).work).enumerations, .nodes = (((state_192).state).work).nodes, }), }), };
        }

        var state_owned_272: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_272);

        if (state_capacity_started_205) {
            ((state_capacity_204).items).len = ((((state_192).state).work).enumerations).len;

            state_owned_272 = (try (state_capacity_204).toOwnedSlice(allocator));
        }

        if (state_capacity_started_205) {
            state_192 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_192).object, .positions = (state_192).positions, .remaining = (state_192).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_192).state).names, .source = ((state_192).state).source, .valid = ((state_192).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_192).state).work).aliases, .enumerations = state_owned_272, .nodes = (((state_192).state).work).nodes, }), }), };
        }

        var state_owned_273: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_273);

        if (state_capacity_started_207) {
            ((state_capacity_206).items).len = ((((state_192).state).work).nodes).len;

            state_owned_273 = (try (state_capacity_206).toOwnedSlice(allocator));
        }

        if (state_capacity_started_207) {
            state_192 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_192).object, .positions = (state_192).positions, .remaining = (state_192).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_192).state).names, .source = ((state_192).state).source, .valid = ((state_192).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_192).state).work).aliases, .enumerations = (((state_192).state).work).enumerations, .nodes = state_owned_273, }), }), };
        }

        break :block_275 (if (state_changed_201) state_192 else operand_200);
    };

    return (value_11).state;
}

fn function_18_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_91, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_44),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_14),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_31),
        started: *bool,
    },
    lane_8: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_32),
        started: *bool,
    },
    lane_9: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_30),
        started: *bool,
    },
    lane_10: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_11: ?struct {
        buffer: *(std).ArrayList(bool),
        started: *bool,
    },
    lane_12: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
}) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_80 {
    @setRuntimeSafety(true);

    const value_1: []const u64 = (try function_17(allocator, block_404: {
        const operand_398 = ((in).state).source;
        const operand_399 = (in).position;
        const operand_400 = (in).count;
        const operand_401 = (in).object;

        break :block_404 block_403: {
            const operand_402 = (try (allocator).create((zx_abi).zx_type_90));

            (operand_402).* = @as((zx_abi).zx_type_90, (zx_abi).zx_type_90{ .source = operand_398, .position = operand_399, .count = operand_400, .object = operand_401, });

            break :block_403 @as(*const (zx_abi).zx_type_90, operand_402);
        };
    }));
    const value_11: *const (zx_abi).zx_type_104 = block_397: {
        const operand_304 = block_303: {
            const operand_297 = (in).state;
            const operand_298 = value_1;
            const operand_299 = @as(u64, (value_1).len);
            const operand_300 = (in).object;

            break :block_303 block_302: {
                const operand_301 = (try (allocator).create((zx_abi).zx_type_104));

                (operand_301).* = @as((zx_abi).zx_type_104, (zx_abi).zx_type_104{ .state = operand_297, .positions = operand_298, .remaining = operand_299, .object = operand_300, });

                break :block_302 @as(*const (zx_abi).zx_type_104, operand_301);
            };
        };

        var state_capacity_306: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_307 = false;

        defer (state_capacity_306).deinit(allocator);

        var state_capacity_308: (std).ArrayList(bool) = .empty;

        var state_capacity_started_309 = false;

        defer (state_capacity_308).deinit(allocator);

        var state_capacity_310: (std).ArrayList(u64) = .empty;

        var state_capacity_started_311 = false;

        defer (state_capacity_310).deinit(allocator);

        var state_296: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (operand_304).object, .positions = (operand_304).positions, .remaining = (operand_304).remaining, .state = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((operand_304).state).names, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = ((((operand_304).state).source).indexed).bytes, .declarations = ((((operand_304).state).source).indexed).declarations, .members = ((((operand_304).state).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = (((((operand_304).state).source).indexed).order).fields, .heads = (((((operand_304).state).source).indexed).order).heads, .items = (((((operand_304).state).source).indexed).order).items, .zx_origin = ((((operand_304).state).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = (((((operand_304).state).source).indexed).types).fields, .items = (((((operand_304).state).source).indexed).types).items, .nodes = (((((operand_304).state).source).indexed).types).nodes, .zx_origin = ((((operand_304).state).source).indexed).types, }, .zx_origin = (((operand_304).state).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if (((((operand_304).state).source).native != null)) block_375: {
            break :block_375 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = ((((operand_304).state).source).native.?).declarations, .enumerations = ((((operand_304).state).source).native.?).enumerations, .fields = ((((operand_304).state).source).native.?).fields, .items = ((((operand_304).state).source).native.?).items, .members = ((((operand_304).state).source).native.?).members, .nodes = ((((operand_304).state).source).native.?).nodes, .zx_origin = (((operand_304).state).source).native.?, };
        } else null)), .zx_origin = ((operand_304).state).source, }, .valid = ((operand_304).state).valid, .work = (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((operand_304).state).work).aliases, .enumerations = (((operand_304).state).work).enumerations, .nodes = (((operand_304).state).work).nodes, .zx_origin = ((operand_304).state).work, }, .zx_origin = (operand_304).state, }, .zx_origin = operand_304, };

        var state_changed_305 = false;

        while (((state_296).remaining != @as(u64, 0))) {
            state_296 = block_374: {
                const value_4: u64 = (state_296).remaining;
                const value_5: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_373: {
                    break :block_373 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_296).object, .positions = (state_296).positions, .remaining = (block_372: {
                        break :block_372 value_4;
                    } - @as(u64, 1)), .state = (state_296).state, });
                };
                const value_6: u64 = block_371: {
                    const operand_369 = (value_5).positions;
                    const operand_370 = (value_5).remaining;

                    if ((operand_370 >= (operand_369).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_371 (operand_369)[@intCast(operand_370)];
                };
                const value_7: *const (zx_abi).zx_type_50 = (if ((value_5).object) (block_355: {
                    const operand_347 = block_346: {
                        const operand_343 = ((value_5).state).source;
                        const operand_344 = block_345: {
                            break :block_345 value_6;
                        };

                        break :block_346 @as((zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_343, .position = operand_344, });
                    };

                    var state_borrow_348: (zx_abi).zx_type_34 = undefined;

                    state_borrow_348 = (zx_abi).zx_type_34{ .fields = ((((operand_347).source).indexed).order).fields, .heads = ((((operand_347).source).indexed).order).heads, .items = ((((operand_347).source).indexed).order).items, };

                    var state_borrow_349: (zx_abi).zx_type_38 = undefined;

                    state_borrow_349 = (zx_abi).zx_type_38{ .fields = ((((operand_347).source).indexed).types).fields, .items = ((((operand_347).source).indexed).types).items, .nodes = ((((operand_347).source).indexed).types).nodes, };

                    var state_borrow_350: (zx_abi).zx_type_64 = undefined;

                    state_borrow_350 = (zx_abi).zx_type_64{ .bytes = (((operand_347).source).indexed).bytes, .declarations = (((operand_347).source).indexed).declarations, .members = (((operand_347).source).indexed).members, .order = (((((operand_347).source).indexed).order).zx_origin orelse (&state_borrow_348)), .types = (((((operand_347).source).indexed).types).zx_origin orelse (&state_borrow_349)), };

                    var state_borrow_351: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_353: (zx_abi).zx_type_66 = undefined;

                    state_borrow_353 = (zx_abi).zx_type_66{ .indexed = ((((operand_347).source).indexed).zx_origin orelse (&state_borrow_350)), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_347).source).native != null)) block_352: {
                        state_borrow_351 = (zx_abi).zx_type_62{ .declarations = (((operand_347).source).native.?).declarations, .enumerations = (((operand_347).source).native.?).enumerations, .fields = (((operand_347).source).native.?).fields, .items = (((operand_347).source).native.?).items, .members = (((operand_347).source).native.?).members, .nodes = (((operand_347).source).native.?).nodes, };

                        break :block_352 ((((operand_347).source).native.?).zx_origin orelse (&state_borrow_351));
                    } else null)), };

                    var state_borrow_354: (zx_abi).zx_type_88 = undefined;

                    state_borrow_354 = (zx_abi).zx_type_88{ .position = (operand_347).position, .source = (((operand_347).source).zx_origin orelse (&state_borrow_353)), };

                    break :block_355 (try function_14_value(allocator, ((operand_347).zx_origin orelse (&state_borrow_354))));
                }).value else (block_368: {
                    const operand_360 = block_359: {
                        const operand_356 = ((value_5).state).source;
                        const operand_357 = block_358: {
                            break :block_358 value_6;
                        };

                        break :block_359 @as((zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_356, .position = operand_357, });
                    };

                    var state_borrow_361: (zx_abi).zx_type_34 = undefined;

                    state_borrow_361 = (zx_abi).zx_type_34{ .fields = ((((operand_360).source).indexed).order).fields, .heads = ((((operand_360).source).indexed).order).heads, .items = ((((operand_360).source).indexed).order).items, };

                    var state_borrow_362: (zx_abi).zx_type_38 = undefined;

                    state_borrow_362 = (zx_abi).zx_type_38{ .fields = ((((operand_360).source).indexed).types).fields, .items = ((((operand_360).source).indexed).types).items, .nodes = ((((operand_360).source).indexed).types).nodes, };

                    var state_borrow_363: (zx_abi).zx_type_64 = undefined;

                    state_borrow_363 = (zx_abi).zx_type_64{ .bytes = (((operand_360).source).indexed).bytes, .declarations = (((operand_360).source).indexed).declarations, .members = (((operand_360).source).indexed).members, .order = (((((operand_360).source).indexed).order).zx_origin orelse (&state_borrow_361)), .types = (((((operand_360).source).indexed).types).zx_origin orelse (&state_borrow_362)), };

                    var state_borrow_364: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_366: (zx_abi).zx_type_66 = undefined;

                    state_borrow_366 = (zx_abi).zx_type_66{ .indexed = ((((operand_360).source).indexed).zx_origin orelse (&state_borrow_363)), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_360).source).native != null)) block_365: {
                        state_borrow_364 = (zx_abi).zx_type_62{ .declarations = (((operand_360).source).native.?).declarations, .enumerations = (((operand_360).source).native.?).enumerations, .fields = (((operand_360).source).native.?).fields, .items = (((operand_360).source).native.?).items, .members = (((operand_360).source).native.?).members, .nodes = (((operand_360).source).native.?).nodes, };

                        break :block_365 ((((operand_360).source).native.?).zx_origin orelse (&state_borrow_364));
                    } else null)), };

                    var state_borrow_367: (zx_abi).zx_type_88 = undefined;

                    state_borrow_367 = (zx_abi).zx_type_88{ .position = (operand_360).position, .source = (((operand_360).source).zx_origin orelse (&state_borrow_366)), };

                    break :block_368 (try function_15_value(allocator, ((operand_360).zx_origin orelse (&state_borrow_367))));
                }).value);
                const value_8: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_342: {
                    break :block_342 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_5).object, .positions = (value_5).positions, .remaining = (value_5).remaining, .state = block_341: {
                        break :block_341 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_5).state).names, .source = ((value_5).state).source, .valid = ((value_5).state).valid, .work = block_340: {
                            break :block_340 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((value_5).state).work).aliases, .enumerations = (((value_5).state).work).enumerations, .nodes = @as([]const u64, (if (((buffers).lane_12 != null)) block_335: {
                                const operand_332 = (((value_5).state).work).nodes;
                                const operand_334 = (block_333: {
                                    break :block_333 value_7;
                                }).index;

                                _ = (try ((std).math).add(usize, (operand_332).len, 1));

                                if ((!(((buffers).lane_12.?).started).*)) {
                                    (try ((((buffers).lane_12.?).buffer).*).appendSlice(allocator, operand_332));

                                    (((buffers).lane_12.?).started).* = true;
                                } else {
                                    (((((buffers).lane_12.?).buffer).*).items).len = (operand_332).len;
                                }

                                (try ((((buffers).lane_12.?).buffer).*).append(allocator, operand_334));

                                break :block_335 ((((buffers).lane_12.?).buffer).*).items;
                            } else (block_339: {
                                const operand_336 = (((value_5).state).work).nodes;
                                const operand_338 = (block_337: {
                                    break :block_337 value_7;
                                }).index;

                                _ = (try ((std).math).add(usize, (operand_336).len, 1));

                                if ((!state_capacity_started_311)) {
                                    (try (state_capacity_310).appendSlice(allocator, operand_336));

                                    state_capacity_started_311 = true;
                                } else {
                                    ((state_capacity_310).items).len = (operand_336).len;
                                }

                                (try (state_capacity_310).append(allocator, operand_338));

                                break :block_339 @as((zx_abi).value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_310).items, {}, null, });
                            }).@"0")), });
                        }, });
                    }, });
                };
                const value_9: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_331: {
                    break :block_331 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_8).object, .positions = (value_8).positions, .remaining = (value_8).remaining, .state = block_330: {
                        break :block_330 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_8).state).names, .source = ((value_8).state).source, .valid = ((value_8).state).valid, .work = block_329: {
                            break :block_329 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((value_8).state).work).aliases, .enumerations = @as([]const bool, (if (((buffers).lane_11 != null)) block_324: {
                                const operand_321 = (((value_8).state).work).enumerations;
                                const operand_323 = (block_322: {
                                    break :block_322 value_7;
                                }).enumeration;

                                _ = (try ((std).math).add(usize, (operand_321).len, 1));

                                if ((!(((buffers).lane_11.?).started).*)) {
                                    (try ((((buffers).lane_11.?).buffer).*).appendSlice(allocator, operand_321));

                                    (((buffers).lane_11.?).started).* = true;
                                } else {
                                    (((((buffers).lane_11.?).buffer).*).items).len = (operand_321).len;
                                }

                                (try ((((buffers).lane_11.?).buffer).*).append(allocator, operand_323));

                                break :block_324 ((((buffers).lane_11.?).buffer).*).items;
                            } else (block_328: {
                                const operand_325 = (((value_8).state).work).enumerations;
                                const operand_327 = (block_326: {
                                    break :block_326 value_7;
                                }).enumeration;

                                _ = (try ((std).math).add(usize, (operand_325).len, 1));

                                if ((!state_capacity_started_309)) {
                                    (try (state_capacity_308).appendSlice(allocator, operand_325));

                                    state_capacity_started_309 = true;
                                } else {
                                    ((state_capacity_308).items).len = (operand_325).len;
                                }

                                (try (state_capacity_308).append(allocator, operand_327));

                                break :block_328 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_308).items, {}, null, });
                            }).@"0")), .nodes = (((value_8).state).work).nodes, });
                        }, });
                    }, });
                };
                const value_10: (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = block_320: {
                    break :block_320 @as((zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (value_9).object, .positions = (value_9).positions, .remaining = (value_9).remaining, .state = block_319: {
                        break :block_319 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((value_9).state).names, .source = ((value_9).state).source, .valid = ((value_9).state).valid, .work = block_318: {
                            break :block_318 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = @as([]const ?[]const u8, (if (((buffers).lane_10 != null)) block_314: {
                                const operand_312 = (((value_9).state).work).aliases;
                                const operand_313 = @as(?[]const u8, null);

                                _ = (try ((std).math).add(usize, (operand_312).len, 1));

                                if ((!(((buffers).lane_10.?).started).*)) {
                                    (try ((((buffers).lane_10.?).buffer).*).appendSlice(allocator, operand_312));

                                    (((buffers).lane_10.?).started).* = true;
                                } else {
                                    (((((buffers).lane_10.?).buffer).*).items).len = (operand_312).len;
                                }

                                (try ((((buffers).lane_10.?).buffer).*).append(allocator, operand_313));

                                break :block_314 ((((buffers).lane_10.?).buffer).*).items;
                            } else (block_317: {
                                const operand_315 = (((value_9).state).work).aliases;
                                const operand_316 = @as(?[]const u8, null);

                                _ = (try ((std).math).add(usize, (operand_315).len, 1));

                                if ((!state_capacity_started_307)) {
                                    (try (state_capacity_306).appendSlice(allocator, operand_315));

                                    state_capacity_started_307 = true;
                                } else {
                                    ((state_capacity_306).items).len = (operand_315).len;
                                }

                                (try (state_capacity_306).append(allocator, operand_316));

                                break :block_317 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_306).items, {}, null, });
                            }).@"0")), .enumerations = (((value_9).state).work).enumerations, .nodes = (((value_9).state).work).nodes, });
                        }, });
                    }, });
                };

                break :block_374 value_10;
            };

            state_changed_305 = true;
        }

        var state_owned_376: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_376);

        if (state_capacity_started_307) {
            ((state_capacity_306).items).len = ((((state_296).state).work).aliases).len;

            state_owned_376 = (try (state_capacity_306).toOwnedSlice(allocator));
        }

        if (state_capacity_started_307) {
            state_296 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_296).object, .positions = (state_296).positions, .remaining = (state_296).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_296).state).names, .source = ((state_296).state).source, .valid = ((state_296).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_376, .enumerations = (((state_296).state).work).enumerations, .nodes = (((state_296).state).work).nodes, }), }), };
        }

        var state_owned_377: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_377);

        if (state_capacity_started_309) {
            ((state_capacity_308).items).len = ((((state_296).state).work).enumerations).len;

            state_owned_377 = (try (state_capacity_308).toOwnedSlice(allocator));
        }

        if (state_capacity_started_309) {
            state_296 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_296).object, .positions = (state_296).positions, .remaining = (state_296).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_296).state).names, .source = ((state_296).state).source, .valid = ((state_296).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_296).state).work).aliases, .enumerations = state_owned_377, .nodes = (((state_296).state).work).nodes, }), }), };
        }

        var state_owned_378: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_378);

        if (state_capacity_started_311) {
            ((state_capacity_310).items).len = ((((state_296).state).work).nodes).len;

            state_owned_378 = (try (state_capacity_310).toOwnedSlice(allocator));
        }

        if (state_capacity_started_311) {
            state_296 = (zx_abi).value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .object = (state_296).object, .positions = (state_296).positions, .remaining = (state_296).remaining, .state = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((state_296).state).names, .source = ((state_296).state).source, .valid = ((state_296).state).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((state_296).state).work).aliases, .enumerations = (((state_296).state).work).enumerations, .nodes = state_owned_378, }), }), };
        }

        break :block_397 (if (state_changed_305) block_396: {
            break :block_396 (if (((state_296).zx_origin != null)) (state_296).zx_origin.? else block_395: {
                const operand_394 = (try (allocator).create((zx_abi).zx_type_104));

                (operand_394).* = (zx_abi).zx_type_104{ .object = (state_296).object, .positions = (state_296).positions, .remaining = (state_296).remaining, .state = (if ((((state_296).state).zx_origin != null)) ((state_296).state).zx_origin.? else block_393: {
                    const operand_392 = (try (allocator).create((zx_abi).zx_type_80));

                    (operand_392).* = (zx_abi).zx_type_80{ .names = ((state_296).state).names, .source = (if (((((state_296).state).source).zx_origin != null)) (((state_296).state).source).zx_origin.? else block_389: {
                        const operand_388 = (try (allocator).create((zx_abi).zx_type_66));

                        (operand_388).* = (zx_abi).zx_type_66{ .indexed = (if ((((((state_296).state).source).indexed).zx_origin != null)) ((((state_296).state).source).indexed).zx_origin.? else block_384: {
                            const operand_383 = (try (allocator).create((zx_abi).zx_type_64));

                            (operand_383).* = (zx_abi).zx_type_64{ .bytes = ((((state_296).state).source).indexed).bytes, .declarations = ((((state_296).state).source).indexed).declarations, .members = ((((state_296).state).source).indexed).members, .order = (if (((((((state_296).state).source).indexed).order).zx_origin != null)) (((((state_296).state).source).indexed).order).zx_origin.? else block_380: {
                                const operand_379 = (try (allocator).create((zx_abi).zx_type_34));

                                (operand_379).* = (zx_abi).zx_type_34{ .fields = (((((state_296).state).source).indexed).order).fields, .heads = (((((state_296).state).source).indexed).order).heads, .items = (((((state_296).state).source).indexed).order).items, };

                                break :block_380 @as(*const (zx_abi).zx_type_34, operand_379);
                            }), .types = (if (((((((state_296).state).source).indexed).types).zx_origin != null)) (((((state_296).state).source).indexed).types).zx_origin.? else block_382: {
                                const operand_381 = (try (allocator).create((zx_abi).zx_type_38));

                                (operand_381).* = (zx_abi).zx_type_38{ .fields = (((((state_296).state).source).indexed).types).fields, .items = (((((state_296).state).source).indexed).types).items, .nodes = (((((state_296).state).source).indexed).types).nodes, };

                                break :block_382 @as(*const (zx_abi).zx_type_38, operand_381);
                            }), };

                            break :block_384 @as(*const (zx_abi).zx_type_64, operand_383);
                        }), .native = @as(?*const (zx_abi).zx_type_62, (if (((((state_296).state).source).native != null)) block_387: {
                            break :block_387 (if ((((((state_296).state).source).native.?).zx_origin != null)) ((((state_296).state).source).native.?).zx_origin.? else block_386: {
                                const operand_385 = (try (allocator).create((zx_abi).zx_type_62));

                                (operand_385).* = (zx_abi).zx_type_62{ .declarations = ((((state_296).state).source).native.?).declarations, .enumerations = ((((state_296).state).source).native.?).enumerations, .fields = ((((state_296).state).source).native.?).fields, .items = ((((state_296).state).source).native.?).items, .members = ((((state_296).state).source).native.?).members, .nodes = ((((state_296).state).source).native.?).nodes, };

                                break :block_386 @as(*const (zx_abi).zx_type_62, operand_385);
                            });
                        } else null)), };

                        break :block_389 @as(*const (zx_abi).zx_type_66, operand_388);
                    }), .valid = ((state_296).state).valid, .work = (if (((((state_296).state).work).zx_origin != null)) (((state_296).state).work).zx_origin.? else block_391: {
                        const operand_390 = (try (allocator).create((zx_abi).zx_type_79));

                        (operand_390).* = (zx_abi).zx_type_79{ .aliases = (((state_296).state).work).aliases, .enumerations = (((state_296).state).work).enumerations, .nodes = (((state_296).state).work).nodes, };

                        break :block_391 @as(*const (zx_abi).zx_type_79, operand_390);
                    }), };

                    break :block_393 @as(*const (zx_abi).zx_type_80, operand_392);
                }), };

                break :block_395 @as(*const (zx_abi).zx_type_104, operand_394);
            });
        } else operand_304);
    };

    return (value_11).state;
}

fn function_19(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_80) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_80 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, (((in).work).nodes).len) - @as(u64, 1));
    const value_2: *const (zx_abi).zx_type_51 = (try function_12(allocator, block_146: {
        const operand_131 = (in).source;
        const operand_132 = block_143: {
            const operand_133 = block_136: {
                const operand_134 = ((in).work).enumerations;
                const operand_135 = value_1;

                if ((operand_135 >= (operand_134).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_136 (operand_134)[@intCast(operand_135)];
            };
            const operand_137 = block_140: {
                const operand_138 = ((in).work).nodes;
                const operand_139 = value_1;

                if ((operand_139 >= (operand_138).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_140 (operand_138)[@intCast(operand_139)];
            };

            break :block_143 block_142: {
                const operand_141 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_141).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_133, .index = operand_137, });

                break :block_142 @as(*const (zx_abi).zx_type_50, operand_141);
            };
        };

        break :block_146 block_145: {
            const operand_144 = (try (allocator).create((zx_abi).zx_type_87));

            (operand_144).* = @as((zx_abi).zx_type_87, (zx_abi).zx_type_87{ .source = operand_131, .reference = operand_132, });

            break :block_145 @as(*const (zx_abi).zx_type_87, operand_144);
        };
    }));
    const value_3: ?[]const u8 = block_130: {
        const operand_128 = ((in).work).aliases;
        const operand_129 = value_1;

        if ((operand_129 >= (operand_128).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_130 (operand_128)[@intCast(operand_129)];
    };

    if (((value_2).kind == @as((zx_abi).zx_type_48, .Named))) {
        const value_4: *const (zx_abi).zx_type_86 = block_127: {
            const operand_122 = block_121: {
                const operand_116 = (in).source;
                const operand_117 = ((value_2).name).text;
                const operand_118 = (try function_8(allocator, (in).source));

                break :block_121 block_120: {
                    const operand_119 = (try (allocator).create((zx_abi).zx_type_85));

                    (operand_119).* = @as((zx_abi).zx_type_85, (zx_abi).zx_type_85{ .source = operand_116, .name = operand_117, .limit = operand_118, });

                    break :block_120 @as(*const (zx_abi).zx_type_85, operand_119);
                };
            };
            const operand_124 = (try function_11_value(allocator, (zx_abi).value_zx_type_85_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b{ .limit = (operand_122).limit, .name = (operand_122).name, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((operand_122).source).indexed).bytes, .declarations = (((operand_122).source).indexed).declarations, .members = (((operand_122).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_122).source).indexed).order).fields, .heads = ((((operand_122).source).indexed).order).heads, .items = ((((operand_122).source).indexed).order).items, .zx_origin = (((operand_122).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_122).source).indexed).types).fields, .items = ((((operand_122).source).indexed).types).items, .nodes = ((((operand_122).source).indexed).types).nodes, .zx_origin = (((operand_122).source).indexed).types, }, .zx_origin = ((operand_122).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if ((((operand_122).source).native != null)) block_123: {
                break :block_123 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = (((operand_122).source).native.?).declarations, .enumerations = (((operand_122).source).native.?).enumerations, .fields = (((operand_122).source).native.?).fields, .items = (((operand_122).source).native.?).items, .members = (((operand_122).source).native.?).members, .nodes = (((operand_122).source).native.?).nodes, .zx_origin = ((operand_122).source).native.?, };
            } else null)), .zx_origin = (operand_122).source, }, .zx_origin = operand_122, }));

            break :block_127 (if (((operand_124).zx_origin != null)) (operand_124).zx_origin.? else block_126: {
                const operand_125 = (try (allocator).create((zx_abi).zx_type_86));

                (operand_125).* = (zx_abi).zx_type_86{ .found = (operand_124).found, .index = (operand_124).index, };

                break :block_126 @as(*const (zx_abi).zx_type_86, operand_125);
            });
        };

        if ((value_4).found) {
            const value_5: *const (zx_abi).zx_type_54 = (try function_10(allocator, block_115: {
                const operand_111 = (in).source;
                const operand_112 = (value_4).index;

                break :block_115 block_114: {
                    const operand_113 = (try (allocator).create((zx_abi).zx_type_84));

                    (operand_113).* = @as((zx_abi).zx_type_84, (zx_abi).zx_type_84{ .source = operand_111, .index = operand_112, });

                    break :block_114 @as(*const (zx_abi).zx_type_84, operand_113);
                };
            }));

            return block_110: {
                const operand_82 = in;
                const operand_83 = block_107: {
                    const operand_84 = (block_90: {
                        const operand_87 = (block_86: {
                            const operand_85 = ((in).work).nodes;

                            break :block_86 @as((zx_abi).zx_type_106, (if (((operand_85).len == 0)) .{ operand_85, null, } else .{ (operand_85)[0..((operand_85).len - 1)], (operand_85)[((operand_85).len - 1)], }));
                        }).@"0";
                        const operand_88 = ((value_5).value).index;
                        const operand_89 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_87).len, 1))));

                        @memcpy((operand_89)[0..(operand_87).len], operand_87);

                        (operand_89)[(operand_87).len] = operand_88;

                        break :block_90 @as((zx_abi).zx_type_93, .{ operand_89, {}, });
                    }).@"0";
                    const operand_91 = (block_97: {
                        const operand_94 = (block_93: {
                            const operand_92 = ((in).work).enumerations;

                            break :block_93 @as((zx_abi).zx_type_108, (if (((operand_92).len == 0)) .{ operand_92, null, } else .{ (operand_92)[0..((operand_92).len - 1)], (operand_92)[((operand_92).len - 1)], }));
                        }).@"0";
                        const operand_95 = ((value_5).value).enumeration;
                        const operand_96 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_94).len, 1))));

                        @memcpy((operand_96)[0..(operand_94).len], operand_94);

                        (operand_96)[(operand_94).len] = operand_95;

                        break :block_97 @as((zx_abi).zx_type_94, .{ operand_96, {}, });
                    }).@"0";
                    const operand_98 = (block_104: {
                        const operand_101 = (block_100: {
                            const operand_99 = ((in).work).aliases;

                            break :block_100 @as((zx_abi).zx_type_110, (if (((operand_99).len == 0)) .{ operand_99, null, } else .{ (operand_99)[0..((operand_99).len - 1)], (operand_99)[((operand_99).len - 1)], }));
                        }).@"0";
                        const operand_102 = (if ((value_3 != null)) @as(?[]const u8, value_3.?) else @as(?[]const u8, ((value_2).name).text));
                        const operand_103 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_101).len, 1))));

                        @memcpy((operand_103)[0..(operand_101).len], operand_101);

                        (operand_103)[(operand_101).len] = operand_102;

                        break :block_104 @as((zx_abi).zx_type_95, .{ operand_103, {}, });
                    }).@"0";

                    break :block_107 block_106: {
                        const operand_105 = (try (allocator).create((zx_abi).zx_type_79));

                        (operand_105).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_84, .enumerations = operand_91, .aliases = operand_98, });

                        break :block_106 @as(*const (zx_abi).zx_type_79, operand_105);
                    };
                };

                break :block_110 block_109: {
                    const operand_108 = (try (allocator).create((zx_abi).zx_type_80));

                    (operand_108).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (operand_82).names, .source = (operand_82).source, .valid = (operand_82).valid, .work = operand_83, });

                    break :block_109 @as(*const (zx_abi).zx_type_80, operand_108);
                };
            };
        }
    }

    if (((((value_2).kind == @as((zx_abi).zx_type_48, .List)) or ((value_2).kind == @as((zx_abi).zx_type_48, .Application))) and (!(try function_13(allocator, block_76: {
        const operand_72 = (in).source;
        const operand_73 = (value_2).child;

        break :block_76 block_75: {
            const operand_74 = (try (allocator).create((zx_abi).zx_type_87));

            (operand_74).* = @as((zx_abi).zx_type_87, (zx_abi).zx_type_87{ .source = operand_72, .reference = operand_73, });

            break :block_75 @as(*const (zx_abi).zx_type_87, operand_74);
        };
    }))))) {
        return block_81: {
            const operand_77 = in;
            const operand_78 = false;

            break :block_81 block_80: {
                const operand_79 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_79).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (operand_77).names, .source = (operand_77).source, .valid = operand_78, .work = (operand_77).work, });

                break :block_80 @as(*const (zx_abi).zx_type_80, operand_79);
            };
        };
    }

    const value_6: *const (zx_abi).zx_type_80 = block_71: {
        const operand_50 = in;
        const operand_51 = (block_55: {
            const operand_52 = (in).names;
            const operand_53 = value_3;
            const operand_54 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_52).len, 1))));

            @memcpy((operand_54)[0..(operand_52).len], operand_52);

            (operand_54)[(operand_52).len] = operand_53;

            break :block_55 @as((zx_abi).zx_type_95, .{ operand_54, {}, });
        }).@"0";
        const operand_56 = block_68: {
            const operand_57 = (block_59: {
                const operand_58 = ((in).work).nodes;

                break :block_59 @as((zx_abi).zx_type_106, (if (((operand_58).len == 0)) .{ operand_58, null, } else .{ (operand_58)[0..((operand_58).len - 1)], (operand_58)[((operand_58).len - 1)], }));
            }).@"0";
            const operand_60 = (block_62: {
                const operand_61 = ((in).work).enumerations;

                break :block_62 @as((zx_abi).zx_type_108, (if (((operand_61).len == 0)) .{ operand_61, null, } else .{ (operand_61)[0..((operand_61).len - 1)], (operand_61)[((operand_61).len - 1)], }));
            }).@"0";
            const operand_63 = (block_65: {
                const operand_64 = ((in).work).aliases;

                break :block_65 @as((zx_abi).zx_type_110, (if (((operand_64).len == 0)) .{ operand_64, null, } else .{ (operand_64)[0..((operand_64).len - 1)], (operand_64)[((operand_64).len - 1)], }));
            }).@"0";

            break :block_68 block_67: {
                const operand_66 = (try (allocator).create((zx_abi).zx_type_79));

                (operand_66).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_57, .enumerations = operand_60, .aliases = operand_63, });

                break :block_67 @as(*const (zx_abi).zx_type_79, operand_66);
            };
        };

        break :block_71 block_70: {
            const operand_69 = (try (allocator).create((zx_abi).zx_type_80));

            (operand_69).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = operand_51, .source = (operand_50).source, .valid = (operand_50).valid, .work = operand_56, });

            break :block_70 @as(*const (zx_abi).zx_type_80, operand_69);
        };
    };

    if (((((value_2).kind == @as((zx_abi).zx_type_48, .Optional)) or ((value_2).kind == @as((zx_abi).zx_type_48, .List))) or ((value_2).kind == @as((zx_abi).zx_type_48, .Application)))) {
        return block_49: {
            const operand_27 = value_6;
            const operand_28 = block_46: {
                const operand_29 = (block_33: {
                    const operand_30 = ((value_6).work).nodes;
                    const operand_31 = ((value_2).child).index;
                    const operand_32 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_30).len, 1))));

                    @memcpy((operand_32)[0..(operand_30).len], operand_30);

                    (operand_32)[(operand_30).len] = operand_31;

                    break :block_33 @as((zx_abi).zx_type_93, .{ operand_32, {}, });
                }).@"0";
                const operand_34 = (block_38: {
                    const operand_35 = ((value_6).work).enumerations;
                    const operand_36 = ((value_2).child).enumeration;
                    const operand_37 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_35).len, 1))));

                    @memcpy((operand_37)[0..(operand_35).len], operand_35);

                    (operand_37)[(operand_35).len] = operand_36;

                    break :block_38 @as((zx_abi).zx_type_94, .{ operand_37, {}, });
                }).@"0";
                const operand_39 = (block_43: {
                    const operand_40 = ((value_6).work).aliases;
                    const operand_41 = @as(?[]const u8, null);
                    const operand_42 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_40).len, 1))));

                    @memcpy((operand_42)[0..(operand_40).len], operand_40);

                    (operand_42)[(operand_40).len] = operand_41;

                    break :block_43 @as((zx_abi).zx_type_95, .{ operand_42, {}, });
                }).@"0";

                break :block_46 block_45: {
                    const operand_44 = (try (allocator).create((zx_abi).zx_type_79));

                    (operand_44).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_29, .enumerations = operand_34, .aliases = operand_39, });

                    break :block_45 @as(*const (zx_abi).zx_type_79, operand_44);
                };
            };

            break :block_49 block_48: {
                const operand_47 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_47).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (operand_27).names, .source = (operand_27).source, .valid = (operand_27).valid, .work = operand_28, });

                break :block_48 @as(*const (zx_abi).zx_type_80, operand_47);
            };
        };
    }

    if ((((value_2).kind == @as((zx_abi).zx_type_48, .Object)) or ((value_2).kind == @as((zx_abi).zx_type_48, .Tuple)))) {
        return block_26: {
            const operand_8 = block_7: {
                const operand_1 = value_6;
                const operand_2 = (value_2).position;
                const operand_3 = (value_2).count;
                const operand_4 = ((value_2).kind == @as((zx_abi).zx_type_48, .Object));

                break :block_7 block_6: {
                    const operand_5 = (try (allocator).create((zx_abi).zx_type_91));

                    (operand_5).* = @as((zx_abi).zx_type_91, (zx_abi).zx_type_91{ .state = operand_1, .position = operand_2, .count = operand_3, .object = operand_4, });

                    break :block_6 @as(*const (zx_abi).zx_type_91, operand_5);
                };
            };
            const operand_10 = (try function_18_value(allocator, (zx_abi).value_zx_type_91_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .count = (operand_8).count, .object = (operand_8).object, .position = (operand_8).position, .state = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = ((operand_8).state).names, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = ((((operand_8).state).source).indexed).bytes, .declarations = ((((operand_8).state).source).indexed).declarations, .members = ((((operand_8).state).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = (((((operand_8).state).source).indexed).order).fields, .heads = (((((operand_8).state).source).indexed).order).heads, .items = (((((operand_8).state).source).indexed).order).items, .zx_origin = ((((operand_8).state).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = (((((operand_8).state).source).indexed).types).fields, .items = (((((operand_8).state).source).indexed).types).items, .nodes = (((((operand_8).state).source).indexed).types).nodes, .zx_origin = ((((operand_8).state).source).indexed).types, }, .zx_origin = (((operand_8).state).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if (((((operand_8).state).source).native != null)) block_9: {
                break :block_9 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = ((((operand_8).state).source).native.?).declarations, .enumerations = ((((operand_8).state).source).native.?).enumerations, .fields = ((((operand_8).state).source).native.?).fields, .items = ((((operand_8).state).source).native.?).items, .members = ((((operand_8).state).source).native.?).members, .nodes = ((((operand_8).state).source).native.?).nodes, .zx_origin = (((operand_8).state).source).native.?, };
            } else null)), .zx_origin = ((operand_8).state).source, }, .valid = ((operand_8).state).valid, .work = (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = (((operand_8).state).work).aliases, .enumerations = (((operand_8).state).work).enumerations, .nodes = (((operand_8).state).work).nodes, .zx_origin = ((operand_8).state).work, }, .zx_origin = (operand_8).state, }, .zx_origin = operand_8, }));

            break :block_26 (if (((operand_10).zx_origin != null)) (operand_10).zx_origin.? else block_25: {
                const operand_24 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_24).* = (zx_abi).zx_type_80{ .names = (operand_10).names, .source = (if ((((operand_10).source).zx_origin != null)) ((operand_10).source).zx_origin.? else block_21: {
                    const operand_20 = (try (allocator).create((zx_abi).zx_type_66));

                    (operand_20).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_10).source).indexed).zx_origin != null)) (((operand_10).source).indexed).zx_origin.? else block_16: {
                        const operand_15 = (try (allocator).create((zx_abi).zx_type_64));

                        (operand_15).* = (zx_abi).zx_type_64{ .bytes = (((operand_10).source).indexed).bytes, .declarations = (((operand_10).source).indexed).declarations, .members = (((operand_10).source).indexed).members, .order = (if ((((((operand_10).source).indexed).order).zx_origin != null)) ((((operand_10).source).indexed).order).zx_origin.? else block_12: {
                            const operand_11 = (try (allocator).create((zx_abi).zx_type_34));

                            (operand_11).* = (zx_abi).zx_type_34{ .fields = ((((operand_10).source).indexed).order).fields, .heads = ((((operand_10).source).indexed).order).heads, .items = ((((operand_10).source).indexed).order).items, };

                            break :block_12 @as(*const (zx_abi).zx_type_34, operand_11);
                        }), .types = (if ((((((operand_10).source).indexed).types).zx_origin != null)) ((((operand_10).source).indexed).types).zx_origin.? else block_14: {
                            const operand_13 = (try (allocator).create((zx_abi).zx_type_38));

                            (operand_13).* = (zx_abi).zx_type_38{ .fields = ((((operand_10).source).indexed).types).fields, .items = ((((operand_10).source).indexed).types).items, .nodes = ((((operand_10).source).indexed).types).nodes, };

                            break :block_14 @as(*const (zx_abi).zx_type_38, operand_13);
                        }), };

                        break :block_16 @as(*const (zx_abi).zx_type_64, operand_15);
                    }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_10).source).native != null)) block_19: {
                        break :block_19 (if (((((operand_10).source).native.?).zx_origin != null)) (((operand_10).source).native.?).zx_origin.? else block_18: {
                            const operand_17 = (try (allocator).create((zx_abi).zx_type_62));

                            (operand_17).* = (zx_abi).zx_type_62{ .declarations = (((operand_10).source).native.?).declarations, .enumerations = (((operand_10).source).native.?).enumerations, .fields = (((operand_10).source).native.?).fields, .items = (((operand_10).source).native.?).items, .members = (((operand_10).source).native.?).members, .nodes = (((operand_10).source).native.?).nodes, };

                            break :block_18 @as(*const (zx_abi).zx_type_62, operand_17);
                        });
                    } else null)), };

                    break :block_21 @as(*const (zx_abi).zx_type_66, operand_20);
                }), .valid = (operand_10).valid, .work = (if ((((operand_10).work).zx_origin != null)) ((operand_10).work).zx_origin.? else block_23: {
                    const operand_22 = (try (allocator).create((zx_abi).zx_type_79));

                    (operand_22).* = (zx_abi).zx_type_79{ .aliases = ((operand_10).work).aliases, .enumerations = ((operand_10).work).enumerations, .nodes = ((operand_10).work).nodes, };

                    break :block_23 @as(*const (zx_abi).zx_type_79, operand_22);
                }), };

                break :block_25 @as(*const (zx_abi).zx_type_80, operand_24);
            });
        };
    }

    return value_6;
}

fn function_19_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, (((in).work).nodes).len) - @as(u64, 1));
    const value_2: *const (zx_abi).zx_type_51 = block_322: {
        const operand_308 = block_307: {
            const operand_292 = (in).source;
            const operand_293 = block_306: {
                const operand_294 = block_298: {
                    const operand_296 = ((in).work).enumerations;
                    const operand_297 = block_295: {
                        break :block_295 value_1;
                    };

                    if ((operand_297 >= (operand_296).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_298 (operand_296)[@intCast(operand_297)];
                };
                const operand_299 = block_303: {
                    const operand_301 = ((in).work).nodes;
                    const operand_302 = block_300: {
                        break :block_300 value_1;
                    };

                    if ((operand_302 >= (operand_301).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_303 (operand_301)[@intCast(operand_302)];
                };

                break :block_306 block_305: {
                    const operand_304 = (try (allocator).create((zx_abi).zx_type_50));

                    (operand_304).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_294, .index = operand_299, });

                    break :block_305 @as(*const (zx_abi).zx_type_50, operand_304);
                };
            };

            break :block_307 @as((zx_abi).value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_292, .reference = operand_293, });
        };

        break :block_322 (try function_12(allocator, (if (((operand_308).zx_origin != null)) (operand_308).zx_origin.? else block_321: {
            const operand_320 = (try (allocator).create((zx_abi).zx_type_87));

            (operand_320).* = (zx_abi).zx_type_87{ .reference = (operand_308).reference, .source = (if ((((operand_308).source).zx_origin != null)) ((operand_308).source).zx_origin.? else block_319: {
                const operand_318 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_318).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_308).source).indexed).zx_origin != null)) (((operand_308).source).indexed).zx_origin.? else block_314: {
                    const operand_313 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_313).* = (zx_abi).zx_type_64{ .bytes = (((operand_308).source).indexed).bytes, .declarations = (((operand_308).source).indexed).declarations, .members = (((operand_308).source).indexed).members, .order = (if ((((((operand_308).source).indexed).order).zx_origin != null)) ((((operand_308).source).indexed).order).zx_origin.? else block_310: {
                        const operand_309 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_309).* = (zx_abi).zx_type_34{ .fields = ((((operand_308).source).indexed).order).fields, .heads = ((((operand_308).source).indexed).order).heads, .items = ((((operand_308).source).indexed).order).items, };

                        break :block_310 @as(*const (zx_abi).zx_type_34, operand_309);
                    }), .types = (if ((((((operand_308).source).indexed).types).zx_origin != null)) ((((operand_308).source).indexed).types).zx_origin.? else block_312: {
                        const operand_311 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_311).* = (zx_abi).zx_type_38{ .fields = ((((operand_308).source).indexed).types).fields, .items = ((((operand_308).source).indexed).types).items, .nodes = ((((operand_308).source).indexed).types).nodes, };

                        break :block_312 @as(*const (zx_abi).zx_type_38, operand_311);
                    }), };

                    break :block_314 @as(*const (zx_abi).zx_type_64, operand_313);
                }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_308).source).native != null)) block_317: {
                    break :block_317 (if (((((operand_308).source).native.?).zx_origin != null)) (((operand_308).source).native.?).zx_origin.? else block_316: {
                        const operand_315 = (try (allocator).create((zx_abi).zx_type_62));

                        (operand_315).* = (zx_abi).zx_type_62{ .declarations = (((operand_308).source).native.?).declarations, .enumerations = (((operand_308).source).native.?).enumerations, .fields = (((operand_308).source).native.?).fields, .items = (((operand_308).source).native.?).items, .members = (((operand_308).source).native.?).members, .nodes = (((operand_308).source).native.?).nodes, };

                        break :block_316 @as(*const (zx_abi).zx_type_62, operand_315);
                    });
                } else null)), };

                break :block_319 @as(*const (zx_abi).zx_type_66, operand_318);
            }), };

            break :block_321 @as(*const (zx_abi).zx_type_87, operand_320);
        })));
    };
    const value_3: ?[]const u8 = block_291: {
        const operand_289 = ((in).work).aliases;
        const operand_290 = block_288: {
            break :block_288 value_1;
        };

        if ((operand_290 >= (operand_289).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_291 (operand_289)[@intCast(operand_290)];
    };

    if (((block_225: {
        break :block_225 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Named))) {
        const value_4: (zx_abi).value_zx_type_86_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_287: {
            break :block_287 (try function_11_value(allocator, block_286: {
                const operand_274 = (in).source;
                const operand_275 = ((block_276: {
                    break :block_276 value_2;
                }).name).text;
                const operand_277 = block_285: {
                    const operand_278 = (in).source;

                    var state_borrow_279: (zx_abi).zx_type_34 = undefined;

                    state_borrow_279 = (zx_abi).zx_type_34{ .fields = (((operand_278).indexed).order).fields, .heads = (((operand_278).indexed).order).heads, .items = (((operand_278).indexed).order).items, };

                    var state_borrow_280: (zx_abi).zx_type_38 = undefined;

                    state_borrow_280 = (zx_abi).zx_type_38{ .fields = (((operand_278).indexed).types).fields, .items = (((operand_278).indexed).types).items, .nodes = (((operand_278).indexed).types).nodes, };

                    var state_borrow_281: (zx_abi).zx_type_64 = undefined;

                    state_borrow_281 = (zx_abi).zx_type_64{ .bytes = ((operand_278).indexed).bytes, .declarations = ((operand_278).indexed).declarations, .members = ((operand_278).indexed).members, .order = ((((operand_278).indexed).order).zx_origin orelse (&state_borrow_279)), .types = ((((operand_278).indexed).types).zx_origin orelse (&state_borrow_280)), };

                    var state_borrow_282: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_284: (zx_abi).zx_type_66 = undefined;

                    state_borrow_284 = (zx_abi).zx_type_66{ .indexed = (((operand_278).indexed).zx_origin orelse (&state_borrow_281)), .native = @as(?*const (zx_abi).zx_type_62, (if (((operand_278).native != null)) block_283: {
                        state_borrow_282 = (zx_abi).zx_type_62{ .declarations = ((operand_278).native.?).declarations, .enumerations = ((operand_278).native.?).enumerations, .fields = ((operand_278).native.?).fields, .items = ((operand_278).native.?).items, .members = ((operand_278).native.?).members, .nodes = ((operand_278).native.?).nodes, };

                        break :block_283 (((operand_278).native.?).zx_origin orelse (&state_borrow_282));
                    } else null)), };

                    break :block_285 (try function_8(allocator, ((operand_278).zx_origin orelse (&state_borrow_284))));
                };

                break :block_286 @as((zx_abi).value_zx_type_85_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b, (zx_abi).value_zx_type_85_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b{ .source = operand_274, .name = operand_275, .limit = operand_277, });
            }));
        };

        if ((value_4).found) {
            const value_5: *const (zx_abi).zx_type_54 = block_273: {
                const operand_259 = block_258: {
                    const operand_256 = (in).source;
                    const operand_257 = (value_4).index;

                    break :block_258 @as((zx_abi).value_zx_type_84_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_84_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_256, .index = operand_257, });
                };

                break :block_273 (try function_10(allocator, (if (((operand_259).zx_origin != null)) (operand_259).zx_origin.? else block_272: {
                    const operand_271 = (try (allocator).create((zx_abi).zx_type_84));

                    (operand_271).* = (zx_abi).zx_type_84{ .index = (operand_259).index, .source = (if ((((operand_259).source).zx_origin != null)) ((operand_259).source).zx_origin.? else block_270: {
                        const operand_269 = (try (allocator).create((zx_abi).zx_type_66));

                        (operand_269).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_259).source).indexed).zx_origin != null)) (((operand_259).source).indexed).zx_origin.? else block_265: {
                            const operand_264 = (try (allocator).create((zx_abi).zx_type_64));

                            (operand_264).* = (zx_abi).zx_type_64{ .bytes = (((operand_259).source).indexed).bytes, .declarations = (((operand_259).source).indexed).declarations, .members = (((operand_259).source).indexed).members, .order = (if ((((((operand_259).source).indexed).order).zx_origin != null)) ((((operand_259).source).indexed).order).zx_origin.? else block_261: {
                                const operand_260 = (try (allocator).create((zx_abi).zx_type_34));

                                (operand_260).* = (zx_abi).zx_type_34{ .fields = ((((operand_259).source).indexed).order).fields, .heads = ((((operand_259).source).indexed).order).heads, .items = ((((operand_259).source).indexed).order).items, };

                                break :block_261 @as(*const (zx_abi).zx_type_34, operand_260);
                            }), .types = (if ((((((operand_259).source).indexed).types).zx_origin != null)) ((((operand_259).source).indexed).types).zx_origin.? else block_263: {
                                const operand_262 = (try (allocator).create((zx_abi).zx_type_38));

                                (operand_262).* = (zx_abi).zx_type_38{ .fields = ((((operand_259).source).indexed).types).fields, .items = ((((operand_259).source).indexed).types).items, .nodes = ((((operand_259).source).indexed).types).nodes, };

                                break :block_263 @as(*const (zx_abi).zx_type_38, operand_262);
                            }), };

                            break :block_265 @as(*const (zx_abi).zx_type_64, operand_264);
                        }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_259).source).native != null)) block_268: {
                            break :block_268 (if (((((operand_259).source).native.?).zx_origin != null)) (((operand_259).source).native.?).zx_origin.? else block_267: {
                                const operand_266 = (try (allocator).create((zx_abi).zx_type_62));

                                (operand_266).* = (zx_abi).zx_type_62{ .declarations = (((operand_259).source).native.?).declarations, .enumerations = (((operand_259).source).native.?).enumerations, .fields = (((operand_259).source).native.?).fields, .items = (((operand_259).source).native.?).items, .members = (((operand_259).source).native.?).members, .nodes = (((operand_259).source).native.?).nodes, };

                                break :block_267 @as(*const (zx_abi).zx_type_62, operand_266);
                            });
                        } else null)), };

                        break :block_270 @as(*const (zx_abi).zx_type_66, operand_269);
                    }), };

                    break :block_272 @as(*const (zx_abi).zx_type_84, operand_271);
                })));
            };

            return block_255: {
                const operand_226 = in;
                const operand_227 = block_254: {
                    const operand_228 = (block_235: {
                        const operand_231 = (block_230: {
                            const operand_229 = ((in).work).nodes;

                            break :block_230 @as((zx_abi).value_zx_type_106_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_229).len == 0)) .{ operand_229, null, null, } else .{ (operand_229)[0..((operand_229).len - 1)], (operand_229)[((operand_229).len - 1)], null, }));
                        }).@"0";
                        const operand_233 = ((block_232: {
                            break :block_232 value_5;
                        }).value).index;
                        const operand_234 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_231).len, 1))));

                        @memcpy((operand_234)[0..(operand_231).len], operand_231);

                        (operand_234)[(operand_231).len] = operand_233;

                        break :block_235 @as((zx_abi).value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_234, {}, null, });
                    }).@"0";
                    const operand_236 = (block_243: {
                        const operand_239 = (block_238: {
                            const operand_237 = ((in).work).enumerations;

                            break :block_238 @as((zx_abi).value_zx_type_108_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_237).len == 0)) .{ operand_237, null, null, } else .{ (operand_237)[0..((operand_237).len - 1)], (operand_237)[((operand_237).len - 1)], null, }));
                        }).@"0";
                        const operand_241 = ((block_240: {
                            break :block_240 value_5;
                        }).value).enumeration;
                        const operand_242 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_239).len, 1))));

                        @memcpy((operand_242)[0..(operand_239).len], operand_239);

                        (operand_242)[(operand_239).len] = operand_241;

                        break :block_243 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_242, {}, null, });
                    }).@"0";
                    const operand_244 = (block_253: {
                        const operand_247 = (block_246: {
                            const operand_245 = ((in).work).aliases;

                            break :block_246 @as((zx_abi).value_zx_type_110_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec, (if (((operand_245).len == 0)) .{ operand_245, null, null, } else .{ (operand_245)[0..((operand_245).len - 1)], (operand_245)[((operand_245).len - 1)], null, }));
                        }).@"0";
                        const operand_251 = (if ((block_248: {
                            break :block_248 value_3;
                        } != null)) @as(?[]const u8, block_249: {
                            break :block_249 value_3;
                        }.?) else @as(?[]const u8, ((block_250: {
                            break :block_250 value_2;
                        }).name).text));
                        const operand_252 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_247).len, 1))));

                        @memcpy((operand_252)[0..(operand_247).len], operand_247);

                        (operand_252)[(operand_247).len] = operand_251;

                        break :block_253 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_252, {}, null, });
                    }).@"0";

                    break :block_254 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_228, .enumerations = operand_236, .aliases = operand_244, });
                };

                break :block_255 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (operand_226).names, .source = (operand_226).source, .valid = (operand_226).valid, .work = operand_227, });
            };
        }
    }

    if (((((block_201: {
        break :block_201 value_2;
    }).kind == @as((zx_abi).zx_type_48, .List)) or ((block_202: {
        break :block_202 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Application))) and (!block_221: {
        const operand_207 = block_206: {
            const operand_203 = (in).source;
            const operand_204 = (block_205: {
                break :block_205 value_2;
            }).child;

            break :block_206 @as((zx_abi).value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_203, .reference = operand_204, });
        };

        break :block_221 (try function_13(allocator, (if (((operand_207).zx_origin != null)) (operand_207).zx_origin.? else block_220: {
            const operand_219 = (try (allocator).create((zx_abi).zx_type_87));

            (operand_219).* = (zx_abi).zx_type_87{ .reference = (operand_207).reference, .source = (if ((((operand_207).source).zx_origin != null)) ((operand_207).source).zx_origin.? else block_218: {
                const operand_217 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_217).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_207).source).indexed).zx_origin != null)) (((operand_207).source).indexed).zx_origin.? else block_213: {
                    const operand_212 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_212).* = (zx_abi).zx_type_64{ .bytes = (((operand_207).source).indexed).bytes, .declarations = (((operand_207).source).indexed).declarations, .members = (((operand_207).source).indexed).members, .order = (if ((((((operand_207).source).indexed).order).zx_origin != null)) ((((operand_207).source).indexed).order).zx_origin.? else block_209: {
                        const operand_208 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_208).* = (zx_abi).zx_type_34{ .fields = ((((operand_207).source).indexed).order).fields, .heads = ((((operand_207).source).indexed).order).heads, .items = ((((operand_207).source).indexed).order).items, };

                        break :block_209 @as(*const (zx_abi).zx_type_34, operand_208);
                    }), .types = (if ((((((operand_207).source).indexed).types).zx_origin != null)) ((((operand_207).source).indexed).types).zx_origin.? else block_211: {
                        const operand_210 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_210).* = (zx_abi).zx_type_38{ .fields = ((((operand_207).source).indexed).types).fields, .items = ((((operand_207).source).indexed).types).items, .nodes = ((((operand_207).source).indexed).types).nodes, };

                        break :block_211 @as(*const (zx_abi).zx_type_38, operand_210);
                    }), };

                    break :block_213 @as(*const (zx_abi).zx_type_64, operand_212);
                }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_207).source).native != null)) block_216: {
                    break :block_216 (if (((((operand_207).source).native.?).zx_origin != null)) (((operand_207).source).native.?).zx_origin.? else block_215: {
                        const operand_214 = (try (allocator).create((zx_abi).zx_type_62));

                        (operand_214).* = (zx_abi).zx_type_62{ .declarations = (((operand_207).source).native.?).declarations, .enumerations = (((operand_207).source).native.?).enumerations, .fields = (((operand_207).source).native.?).fields, .items = (((operand_207).source).native.?).items, .members = (((operand_207).source).native.?).members, .nodes = (((operand_207).source).native.?).nodes, };

                        break :block_215 @as(*const (zx_abi).zx_type_62, operand_214);
                    });
                } else null)), };

                break :block_218 @as(*const (zx_abi).zx_type_66, operand_217);
            }), };

            break :block_220 @as(*const (zx_abi).zx_type_87, operand_219);
        })));
    }))) {
        return block_224: {
            const operand_222 = in;
            const operand_223 = false;

            break :block_224 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (operand_222).names, .source = (operand_222).source, .valid = operand_223, .work = (operand_222).work, });
        };
    }

    const value_6: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 = block_200: {
        const operand_182 = in;
        const operand_183 = (block_188: {
            const operand_184 = (in).names;
            const operand_186 = block_185: {
                break :block_185 value_3;
            };
            const operand_187 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_184).len, 1))));

            @memcpy((operand_187)[0..(operand_184).len], operand_184);

            (operand_187)[(operand_184).len] = operand_186;

            break :block_188 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_187, {}, null, });
        }).@"0";
        const operand_189 = block_199: {
            const operand_190 = (block_192: {
                const operand_191 = ((in).work).nodes;

                break :block_192 @as((zx_abi).value_zx_type_106_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_191).len == 0)) .{ operand_191, null, null, } else .{ (operand_191)[0..((operand_191).len - 1)], (operand_191)[((operand_191).len - 1)], null, }));
            }).@"0";
            const operand_193 = (block_195: {
                const operand_194 = ((in).work).enumerations;

                break :block_195 @as((zx_abi).value_zx_type_108_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_194).len == 0)) .{ operand_194, null, null, } else .{ (operand_194)[0..((operand_194).len - 1)], (operand_194)[((operand_194).len - 1)], null, }));
            }).@"0";
            const operand_196 = (block_198: {
                const operand_197 = ((in).work).aliases;

                break :block_198 @as((zx_abi).value_zx_type_110_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec, (if (((operand_197).len == 0)) .{ operand_197, null, null, } else .{ (operand_197)[0..((operand_197).len - 1)], (operand_197)[((operand_197).len - 1)], null, }));
            }).@"0";

            break :block_199 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_190, .enumerations = operand_193, .aliases = operand_196, });
        };

        break :block_200 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = operand_183, .source = (operand_182).source, .valid = (operand_182).valid, .work = operand_189, });
    };

    if (((((block_158: {
        break :block_158 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Optional)) or ((block_159: {
        break :block_159 value_2;
    }).kind == @as((zx_abi).zx_type_48, .List))) or ((block_160: {
        break :block_160 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Application)))) {
        return block_181: {
            const operand_161 = value_6;
            const operand_162 = block_180: {
                const operand_163 = (block_168: {
                    const operand_164 = ((value_6).work).nodes;
                    const operand_166 = ((block_165: {
                        break :block_165 value_2;
                    }).child).index;
                    const operand_167 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_164).len, 1))));

                    @memcpy((operand_167)[0..(operand_164).len], operand_164);

                    (operand_167)[(operand_164).len] = operand_166;

                    break :block_168 @as((zx_abi).value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_167, {}, null, });
                }).@"0";
                const operand_169 = (block_174: {
                    const operand_170 = ((value_6).work).enumerations;
                    const operand_172 = ((block_171: {
                        break :block_171 value_2;
                    }).child).enumeration;
                    const operand_173 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_170).len, 1))));

                    @memcpy((operand_173)[0..(operand_170).len], operand_170);

                    (operand_173)[(operand_170).len] = operand_172;

                    break :block_174 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_173, {}, null, });
                }).@"0";
                const operand_175 = (block_179: {
                    const operand_176 = ((value_6).work).aliases;
                    const operand_177 = @as(?[]const u8, null);
                    const operand_178 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_176).len, 1))));

                    @memcpy((operand_178)[0..(operand_176).len], operand_176);

                    (operand_178)[(operand_176).len] = operand_177;

                    break :block_179 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_178, {}, null, });
                }).@"0";

                break :block_180 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_163, .enumerations = operand_169, .aliases = operand_175, });
            };

            break :block_181 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (operand_161).names, .source = (operand_161).source, .valid = (operand_161).valid, .work = operand_162, });
        };
    }

    if ((((block_147: {
        break :block_147 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Object)) or ((block_148: {
        break :block_148 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Tuple)))) {
        return block_157: {
            break :block_157 (try function_18_value(allocator, block_156: {
                const operand_149 = value_6;
                const operand_150 = (block_151: {
                    break :block_151 value_2;
                }).position;
                const operand_152 = (block_153: {
                    break :block_153 value_2;
                }).count;
                const operand_154 = ((block_155: {
                    break :block_155 value_2;
                }).kind == @as((zx_abi).zx_type_48, .Object));

                break :block_156 @as((zx_abi).value_zx_type_91_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_91_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .state = operand_149, .position = operand_150, .count = operand_152, .object = operand_154, });
            }));
        };
    }

    return value_6;
}

fn function_19_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_44),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_14),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_31),
        started: *bool,
    },
    lane_8: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_32),
        started: *bool,
    },
    lane_9: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_30),
        started: *bool,
    },
    lane_10: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_11: ?struct {
        buffer: *(std).ArrayList(bool),
        started: *bool,
    },
    lane_12: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
}) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, (((in).work).nodes).len) - @as(u64, 1));
    const value_2: *const (zx_abi).zx_type_51 = block_533: {
        const operand_519 = block_518: {
            const operand_503 = (in).source;
            const operand_504 = block_517: {
                const operand_505 = block_509: {
                    const operand_507 = ((in).work).enumerations;
                    const operand_508 = block_506: {
                        break :block_506 value_1;
                    };

                    if ((operand_508 >= (operand_507).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_509 (operand_507)[@intCast(operand_508)];
                };
                const operand_510 = block_514: {
                    const operand_512 = ((in).work).nodes;
                    const operand_513 = block_511: {
                        break :block_511 value_1;
                    };

                    if ((operand_513 >= (operand_512).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_514 (operand_512)[@intCast(operand_513)];
                };

                break :block_517 block_516: {
                    const operand_515 = (try (allocator).create((zx_abi).zx_type_50));

                    (operand_515).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_505, .index = operand_510, });

                    break :block_516 @as(*const (zx_abi).zx_type_50, operand_515);
                };
            };

            break :block_518 @as((zx_abi).value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_503, .reference = operand_504, });
        };

        break :block_533 (try function_12(allocator, (if (((operand_519).zx_origin != null)) (operand_519).zx_origin.? else block_532: {
            const operand_531 = (try (allocator).create((zx_abi).zx_type_87));

            (operand_531).* = (zx_abi).zx_type_87{ .reference = (operand_519).reference, .source = (if ((((operand_519).source).zx_origin != null)) ((operand_519).source).zx_origin.? else block_530: {
                const operand_529 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_529).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_519).source).indexed).zx_origin != null)) (((operand_519).source).indexed).zx_origin.? else block_525: {
                    const operand_524 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_524).* = (zx_abi).zx_type_64{ .bytes = (((operand_519).source).indexed).bytes, .declarations = (((operand_519).source).indexed).declarations, .members = (((operand_519).source).indexed).members, .order = (if ((((((operand_519).source).indexed).order).zx_origin != null)) ((((operand_519).source).indexed).order).zx_origin.? else block_521: {
                        const operand_520 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_520).* = (zx_abi).zx_type_34{ .fields = ((((operand_519).source).indexed).order).fields, .heads = ((((operand_519).source).indexed).order).heads, .items = ((((operand_519).source).indexed).order).items, };

                        break :block_521 @as(*const (zx_abi).zx_type_34, operand_520);
                    }), .types = (if ((((((operand_519).source).indexed).types).zx_origin != null)) ((((operand_519).source).indexed).types).zx_origin.? else block_523: {
                        const operand_522 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_522).* = (zx_abi).zx_type_38{ .fields = ((((operand_519).source).indexed).types).fields, .items = ((((operand_519).source).indexed).types).items, .nodes = ((((operand_519).source).indexed).types).nodes, };

                        break :block_523 @as(*const (zx_abi).zx_type_38, operand_522);
                    }), };

                    break :block_525 @as(*const (zx_abi).zx_type_64, operand_524);
                }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_519).source).native != null)) block_528: {
                    break :block_528 (if (((((operand_519).source).native.?).zx_origin != null)) (((operand_519).source).native.?).zx_origin.? else block_527: {
                        const operand_526 = (try (allocator).create((zx_abi).zx_type_62));

                        (operand_526).* = (zx_abi).zx_type_62{ .declarations = (((operand_519).source).native.?).declarations, .enumerations = (((operand_519).source).native.?).enumerations, .fields = (((operand_519).source).native.?).fields, .items = (((operand_519).source).native.?).items, .members = (((operand_519).source).native.?).members, .nodes = (((operand_519).source).native.?).nodes, };

                        break :block_527 @as(*const (zx_abi).zx_type_62, operand_526);
                    });
                } else null)), };

                break :block_530 @as(*const (zx_abi).zx_type_66, operand_529);
            }), };

            break :block_532 @as(*const (zx_abi).zx_type_87, operand_531);
        })));
    };
    const value_3: ?[]const u8 = block_502: {
        const operand_500 = ((in).work).aliases;
        const operand_501 = block_499: {
            break :block_499 value_1;
        };

        if ((operand_501 >= (operand_500).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_502 (operand_500)[@intCast(operand_501)];
    };

    if (((block_416: {
        break :block_416 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Named))) {
        const value_4: (zx_abi).value_zx_type_86_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_498: {
            break :block_498 (try function_11_value(allocator, block_497: {
                const operand_485 = (in).source;
                const operand_486 = ((block_487: {
                    break :block_487 value_2;
                }).name).text;
                const operand_488 = block_496: {
                    const operand_489 = (in).source;

                    var state_borrow_490: (zx_abi).zx_type_34 = undefined;

                    state_borrow_490 = (zx_abi).zx_type_34{ .fields = (((operand_489).indexed).order).fields, .heads = (((operand_489).indexed).order).heads, .items = (((operand_489).indexed).order).items, };

                    var state_borrow_491: (zx_abi).zx_type_38 = undefined;

                    state_borrow_491 = (zx_abi).zx_type_38{ .fields = (((operand_489).indexed).types).fields, .items = (((operand_489).indexed).types).items, .nodes = (((operand_489).indexed).types).nodes, };

                    var state_borrow_492: (zx_abi).zx_type_64 = undefined;

                    state_borrow_492 = (zx_abi).zx_type_64{ .bytes = ((operand_489).indexed).bytes, .declarations = ((operand_489).indexed).declarations, .members = ((operand_489).indexed).members, .order = ((((operand_489).indexed).order).zx_origin orelse (&state_borrow_490)), .types = ((((operand_489).indexed).types).zx_origin orelse (&state_borrow_491)), };

                    var state_borrow_493: (zx_abi).zx_type_62 = undefined;

                    var state_borrow_495: (zx_abi).zx_type_66 = undefined;

                    state_borrow_495 = (zx_abi).zx_type_66{ .indexed = (((operand_489).indexed).zx_origin orelse (&state_borrow_492)), .native = @as(?*const (zx_abi).zx_type_62, (if (((operand_489).native != null)) block_494: {
                        state_borrow_493 = (zx_abi).zx_type_62{ .declarations = ((operand_489).native.?).declarations, .enumerations = ((operand_489).native.?).enumerations, .fields = ((operand_489).native.?).fields, .items = ((operand_489).native.?).items, .members = ((operand_489).native.?).members, .nodes = ((operand_489).native.?).nodes, };

                        break :block_494 (((operand_489).native.?).zx_origin orelse (&state_borrow_493));
                    } else null)), };

                    break :block_496 (try function_8(allocator, ((operand_489).zx_origin orelse (&state_borrow_495))));
                };

                break :block_497 @as((zx_abi).value_zx_type_85_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b, (zx_abi).value_zx_type_85_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b{ .source = operand_485, .name = operand_486, .limit = operand_488, });
            }));
        };

        if ((value_4).found) {
            const value_5: *const (zx_abi).zx_type_54 = block_484: {
                const operand_470 = block_469: {
                    const operand_467 = (in).source;
                    const operand_468 = (value_4).index;

                    break :block_469 @as((zx_abi).value_zx_type_84_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_84_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_467, .index = operand_468, });
                };

                break :block_484 (try function_10(allocator, (if (((operand_470).zx_origin != null)) (operand_470).zx_origin.? else block_483: {
                    const operand_482 = (try (allocator).create((zx_abi).zx_type_84));

                    (operand_482).* = (zx_abi).zx_type_84{ .index = (operand_470).index, .source = (if ((((operand_470).source).zx_origin != null)) ((operand_470).source).zx_origin.? else block_481: {
                        const operand_480 = (try (allocator).create((zx_abi).zx_type_66));

                        (operand_480).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_470).source).indexed).zx_origin != null)) (((operand_470).source).indexed).zx_origin.? else block_476: {
                            const operand_475 = (try (allocator).create((zx_abi).zx_type_64));

                            (operand_475).* = (zx_abi).zx_type_64{ .bytes = (((operand_470).source).indexed).bytes, .declarations = (((operand_470).source).indexed).declarations, .members = (((operand_470).source).indexed).members, .order = (if ((((((operand_470).source).indexed).order).zx_origin != null)) ((((operand_470).source).indexed).order).zx_origin.? else block_472: {
                                const operand_471 = (try (allocator).create((zx_abi).zx_type_34));

                                (operand_471).* = (zx_abi).zx_type_34{ .fields = ((((operand_470).source).indexed).order).fields, .heads = ((((operand_470).source).indexed).order).heads, .items = ((((operand_470).source).indexed).order).items, };

                                break :block_472 @as(*const (zx_abi).zx_type_34, operand_471);
                            }), .types = (if ((((((operand_470).source).indexed).types).zx_origin != null)) ((((operand_470).source).indexed).types).zx_origin.? else block_474: {
                                const operand_473 = (try (allocator).create((zx_abi).zx_type_38));

                                (operand_473).* = (zx_abi).zx_type_38{ .fields = ((((operand_470).source).indexed).types).fields, .items = ((((operand_470).source).indexed).types).items, .nodes = ((((operand_470).source).indexed).types).nodes, };

                                break :block_474 @as(*const (zx_abi).zx_type_38, operand_473);
                            }), };

                            break :block_476 @as(*const (zx_abi).zx_type_64, operand_475);
                        }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_470).source).native != null)) block_479: {
                            break :block_479 (if (((((operand_470).source).native.?).zx_origin != null)) (((operand_470).source).native.?).zx_origin.? else block_478: {
                                const operand_477 = (try (allocator).create((zx_abi).zx_type_62));

                                (operand_477).* = (zx_abi).zx_type_62{ .declarations = (((operand_470).source).native.?).declarations, .enumerations = (((operand_470).source).native.?).enumerations, .fields = (((operand_470).source).native.?).fields, .items = (((operand_470).source).native.?).items, .members = (((operand_470).source).native.?).members, .nodes = (((operand_470).source).native.?).nodes, };

                                break :block_478 @as(*const (zx_abi).zx_type_62, operand_477);
                            });
                        } else null)), };

                        break :block_481 @as(*const (zx_abi).zx_type_66, operand_480);
                    }), };

                    break :block_483 @as(*const (zx_abi).zx_type_84, operand_482);
                })));
            };

            return block_466: {
                const operand_417 = in;
                const operand_418 = block_465: {
                    const operand_419 = @as([]const u64, (if (((buffers).lane_12 != null)) block_425: {
                        const operand_422 = (block_421: {
                            const operand_420 = ((in).work).nodes;

                            break :block_421 @as((zx_abi).value_zx_type_106_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_420).len == 0)) .{ operand_420, null, null, } else .{ (operand_420)[0..((operand_420).len - 1)], (operand_420)[((operand_420).len - 1)], null, }));
                        }).@"0";
                        const operand_424 = ((block_423: {
                            break :block_423 value_5;
                        }).value).index;

                        _ = (try ((std).math).add(usize, (operand_422).len, 1));

                        if ((!(((buffers).lane_12.?).started).*)) {
                            (try ((((buffers).lane_12.?).buffer).*).appendSlice(allocator, operand_422));

                            (((buffers).lane_12.?).started).* = true;
                        } else {
                            (((((buffers).lane_12.?).buffer).*).items).len = (operand_422).len;
                        }

                        (try ((((buffers).lane_12.?).buffer).*).append(allocator, operand_424));

                        break :block_425 ((((buffers).lane_12.?).buffer).*).items;
                    } else (block_432: {
                        const operand_428 = (block_427: {
                            const operand_426 = ((in).work).nodes;

                            break :block_427 @as((zx_abi).value_zx_type_106_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_426).len == 0)) .{ operand_426, null, null, } else .{ (operand_426)[0..((operand_426).len - 1)], (operand_426)[((operand_426).len - 1)], null, }));
                        }).@"0";
                        const operand_430 = ((block_429: {
                            break :block_429 value_5;
                        }).value).index;
                        const operand_431 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_428).len, 1))));

                        @memcpy((operand_431)[0..(operand_428).len], operand_428);

                        (operand_431)[(operand_428).len] = operand_430;

                        break :block_432 @as((zx_abi).value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_431, {}, null, });
                    }).@"0"));
                    const operand_433 = @as([]const bool, (if (((buffers).lane_11 != null)) block_439: {
                        const operand_436 = (block_435: {
                            const operand_434 = ((in).work).enumerations;

                            break :block_435 @as((zx_abi).value_zx_type_108_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_434).len == 0)) .{ operand_434, null, null, } else .{ (operand_434)[0..((operand_434).len - 1)], (operand_434)[((operand_434).len - 1)], null, }));
                        }).@"0";
                        const operand_438 = ((block_437: {
                            break :block_437 value_5;
                        }).value).enumeration;

                        _ = (try ((std).math).add(usize, (operand_436).len, 1));

                        if ((!(((buffers).lane_11.?).started).*)) {
                            (try ((((buffers).lane_11.?).buffer).*).appendSlice(allocator, operand_436));

                            (((buffers).lane_11.?).started).* = true;
                        } else {
                            (((((buffers).lane_11.?).buffer).*).items).len = (operand_436).len;
                        }

                        (try ((((buffers).lane_11.?).buffer).*).append(allocator, operand_438));

                        break :block_439 ((((buffers).lane_11.?).buffer).*).items;
                    } else (block_446: {
                        const operand_442 = (block_441: {
                            const operand_440 = ((in).work).enumerations;

                            break :block_441 @as((zx_abi).value_zx_type_108_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_440).len == 0)) .{ operand_440, null, null, } else .{ (operand_440)[0..((operand_440).len - 1)], (operand_440)[((operand_440).len - 1)], null, }));
                        }).@"0";
                        const operand_444 = ((block_443: {
                            break :block_443 value_5;
                        }).value).enumeration;
                        const operand_445 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_442).len, 1))));

                        @memcpy((operand_445)[0..(operand_442).len], operand_442);

                        (operand_445)[(operand_442).len] = operand_444;

                        break :block_446 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_445, {}, null, });
                    }).@"0"));
                    const operand_447 = @as([]const ?[]const u8, (if (((buffers).lane_10 != null)) block_455: {
                        const operand_450 = (block_449: {
                            const operand_448 = ((in).work).aliases;

                            break :block_449 @as((zx_abi).value_zx_type_110_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec, (if (((operand_448).len == 0)) .{ operand_448, null, null, } else .{ (operand_448)[0..((operand_448).len - 1)], (operand_448)[((operand_448).len - 1)], null, }));
                        }).@"0";
                        const operand_454 = (if ((block_451: {
                            break :block_451 value_3;
                        } != null)) @as(?[]const u8, block_452: {
                            break :block_452 value_3;
                        }.?) else @as(?[]const u8, ((block_453: {
                            break :block_453 value_2;
                        }).name).text));

                        _ = (try ((std).math).add(usize, (operand_450).len, 1));

                        if ((!(((buffers).lane_10.?).started).*)) {
                            (try ((((buffers).lane_10.?).buffer).*).appendSlice(allocator, operand_450));

                            (((buffers).lane_10.?).started).* = true;
                        } else {
                            (((((buffers).lane_10.?).buffer).*).items).len = (operand_450).len;
                        }

                        (try ((((buffers).lane_10.?).buffer).*).append(allocator, operand_454));

                        break :block_455 ((((buffers).lane_10.?).buffer).*).items;
                    } else (block_464: {
                        const operand_458 = (block_457: {
                            const operand_456 = ((in).work).aliases;

                            break :block_457 @as((zx_abi).value_zx_type_110_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec, (if (((operand_456).len == 0)) .{ operand_456, null, null, } else .{ (operand_456)[0..((operand_456).len - 1)], (operand_456)[((operand_456).len - 1)], null, }));
                        }).@"0";
                        const operand_462 = (if ((block_459: {
                            break :block_459 value_3;
                        } != null)) @as(?[]const u8, block_460: {
                            break :block_460 value_3;
                        }.?) else @as(?[]const u8, ((block_461: {
                            break :block_461 value_2;
                        }).name).text));
                        const operand_463 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_458).len, 1))));

                        @memcpy((operand_463)[0..(operand_458).len], operand_458);

                        (operand_463)[(operand_458).len] = operand_462;

                        break :block_464 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_463, {}, null, });
                    }).@"0"));

                    break :block_465 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_419, .enumerations = operand_433, .aliases = operand_447, });
                };

                break :block_466 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (operand_417).names, .source = (operand_417).source, .valid = (operand_417).valid, .work = operand_418, });
            };
        }
    }

    if (((((block_392: {
        break :block_392 value_2;
    }).kind == @as((zx_abi).zx_type_48, .List)) or ((block_393: {
        break :block_393 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Application))) and (!block_412: {
        const operand_398 = block_397: {
            const operand_394 = (in).source;
            const operand_395 = (block_396: {
                break :block_396 value_2;
            }).child;

            break :block_397 @as((zx_abi).value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4, (zx_abi).value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4{ .source = operand_394, .reference = operand_395, });
        };

        break :block_412 (try function_13(allocator, (if (((operand_398).zx_origin != null)) (operand_398).zx_origin.? else block_411: {
            const operand_410 = (try (allocator).create((zx_abi).zx_type_87));

            (operand_410).* = (zx_abi).zx_type_87{ .reference = (operand_398).reference, .source = (if ((((operand_398).source).zx_origin != null)) ((operand_398).source).zx_origin.? else block_409: {
                const operand_408 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_408).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_398).source).indexed).zx_origin != null)) (((operand_398).source).indexed).zx_origin.? else block_404: {
                    const operand_403 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_403).* = (zx_abi).zx_type_64{ .bytes = (((operand_398).source).indexed).bytes, .declarations = (((operand_398).source).indexed).declarations, .members = (((operand_398).source).indexed).members, .order = (if ((((((operand_398).source).indexed).order).zx_origin != null)) ((((operand_398).source).indexed).order).zx_origin.? else block_400: {
                        const operand_399 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_399).* = (zx_abi).zx_type_34{ .fields = ((((operand_398).source).indexed).order).fields, .heads = ((((operand_398).source).indexed).order).heads, .items = ((((operand_398).source).indexed).order).items, };

                        break :block_400 @as(*const (zx_abi).zx_type_34, operand_399);
                    }), .types = (if ((((((operand_398).source).indexed).types).zx_origin != null)) ((((operand_398).source).indexed).types).zx_origin.? else block_402: {
                        const operand_401 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_401).* = (zx_abi).zx_type_38{ .fields = ((((operand_398).source).indexed).types).fields, .items = ((((operand_398).source).indexed).types).items, .nodes = ((((operand_398).source).indexed).types).nodes, };

                        break :block_402 @as(*const (zx_abi).zx_type_38, operand_401);
                    }), };

                    break :block_404 @as(*const (zx_abi).zx_type_64, operand_403);
                }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_398).source).native != null)) block_407: {
                    break :block_407 (if (((((operand_398).source).native.?).zx_origin != null)) (((operand_398).source).native.?).zx_origin.? else block_406: {
                        const operand_405 = (try (allocator).create((zx_abi).zx_type_62));

                        (operand_405).* = (zx_abi).zx_type_62{ .declarations = (((operand_398).source).native.?).declarations, .enumerations = (((operand_398).source).native.?).enumerations, .fields = (((operand_398).source).native.?).fields, .items = (((operand_398).source).native.?).items, .members = (((operand_398).source).native.?).members, .nodes = (((operand_398).source).native.?).nodes, };

                        break :block_406 @as(*const (zx_abi).zx_type_62, operand_405);
                    });
                } else null)), };

                break :block_409 @as(*const (zx_abi).zx_type_66, operand_408);
            }), };

            break :block_411 @as(*const (zx_abi).zx_type_87, operand_410);
        })));
    }))) {
        return block_415: {
            const operand_413 = in;
            const operand_414 = false;

            break :block_415 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (operand_413).names, .source = (operand_413).source, .valid = operand_414, .work = (operand_413).work, });
        };
    }

    const value_6: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 = block_391: {
        const operand_369 = in;
        const operand_370 = @as([]const ?[]const u8, (if (((buffers).lane_0 != null)) block_374: {
            const operand_371 = (in).names;
            const operand_373 = block_372: {
                break :block_372 value_3;
            };

            _ = (try ((std).math).add(usize, (operand_371).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_371));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_371).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_373));

            break :block_374 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_379: {
            const operand_375 = (in).names;
            const operand_377 = block_376: {
                break :block_376 value_3;
            };
            const operand_378 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_375).len, 1))));

            @memcpy((operand_378)[0..(operand_375).len], operand_375);

            (operand_378)[(operand_375).len] = operand_377;

            break :block_379 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_378, {}, null, });
        }).@"0"));
        const operand_380 = block_390: {
            const operand_381 = (block_383: {
                const operand_382 = ((in).work).nodes;

                break :block_383 @as((zx_abi).value_zx_type_106_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_382).len == 0)) .{ operand_382, null, null, } else .{ (operand_382)[0..((operand_382).len - 1)], (operand_382)[((operand_382).len - 1)], null, }));
            }).@"0";
            const operand_384 = (block_386: {
                const operand_385 = ((in).work).enumerations;

                break :block_386 @as((zx_abi).value_zx_type_108_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_385).len == 0)) .{ operand_385, null, null, } else .{ (operand_385)[0..((operand_385).len - 1)], (operand_385)[((operand_385).len - 1)], null, }));
            }).@"0";
            const operand_387 = (block_389: {
                const operand_388 = ((in).work).aliases;

                break :block_389 @as((zx_abi).value_zx_type_110_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec, (if (((operand_388).len == 0)) .{ operand_388, null, null, } else .{ (operand_388)[0..((operand_388).len - 1)], (operand_388)[((operand_388).len - 1)], null, }));
            }).@"0";

            break :block_390 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_381, .enumerations = operand_384, .aliases = operand_387, });
        };

        break :block_391 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = operand_370, .source = (operand_369).source, .valid = (operand_369).valid, .work = operand_380, });
    };

    if (((((block_334: {
        break :block_334 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Optional)) or ((block_335: {
        break :block_335 value_2;
    }).kind == @as((zx_abi).zx_type_48, .List))) or ((block_336: {
        break :block_336 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Application)))) {
        return block_368: {
            const operand_337 = value_6;
            const operand_338 = block_367: {
                const operand_339 = @as([]const u64, (if (((buffers).lane_12 != null)) block_343: {
                    const operand_340 = ((value_6).work).nodes;
                    const operand_342 = ((block_341: {
                        break :block_341 value_2;
                    }).child).index;

                    _ = (try ((std).math).add(usize, (operand_340).len, 1));

                    if ((!(((buffers).lane_12.?).started).*)) {
                        (try ((((buffers).lane_12.?).buffer).*).appendSlice(allocator, operand_340));

                        (((buffers).lane_12.?).started).* = true;
                    } else {
                        (((((buffers).lane_12.?).buffer).*).items).len = (operand_340).len;
                    }

                    (try ((((buffers).lane_12.?).buffer).*).append(allocator, operand_342));

                    break :block_343 ((((buffers).lane_12.?).buffer).*).items;
                } else (block_348: {
                    const operand_344 = ((value_6).work).nodes;
                    const operand_346 = ((block_345: {
                        break :block_345 value_2;
                    }).child).index;
                    const operand_347 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_344).len, 1))));

                    @memcpy((operand_347)[0..(operand_344).len], operand_344);

                    (operand_347)[(operand_344).len] = operand_346;

                    break :block_348 @as((zx_abi).value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_347, {}, null, });
                }).@"0"));
                const operand_349 = @as([]const bool, (if (((buffers).lane_11 != null)) block_353: {
                    const operand_350 = ((value_6).work).enumerations;
                    const operand_352 = ((block_351: {
                        break :block_351 value_2;
                    }).child).enumeration;

                    _ = (try ((std).math).add(usize, (operand_350).len, 1));

                    if ((!(((buffers).lane_11.?).started).*)) {
                        (try ((((buffers).lane_11.?).buffer).*).appendSlice(allocator, operand_350));

                        (((buffers).lane_11.?).started).* = true;
                    } else {
                        (((((buffers).lane_11.?).buffer).*).items).len = (operand_350).len;
                    }

                    (try ((((buffers).lane_11.?).buffer).*).append(allocator, operand_352));

                    break :block_353 ((((buffers).lane_11.?).buffer).*).items;
                } else (block_358: {
                    const operand_354 = ((value_6).work).enumerations;
                    const operand_356 = ((block_355: {
                        break :block_355 value_2;
                    }).child).enumeration;
                    const operand_357 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_354).len, 1))));

                    @memcpy((operand_357)[0..(operand_354).len], operand_354);

                    (operand_357)[(operand_354).len] = operand_356;

                    break :block_358 @as((zx_abi).value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_357, {}, null, });
                }).@"0"));
                const operand_359 = @as([]const ?[]const u8, (if (((buffers).lane_10 != null)) block_362: {
                    const operand_360 = ((value_6).work).aliases;
                    const operand_361 = @as(?[]const u8, null);

                    _ = (try ((std).math).add(usize, (operand_360).len, 1));

                    if ((!(((buffers).lane_10.?).started).*)) {
                        (try ((((buffers).lane_10.?).buffer).*).appendSlice(allocator, operand_360));

                        (((buffers).lane_10.?).started).* = true;
                    } else {
                        (((((buffers).lane_10.?).buffer).*).items).len = (operand_360).len;
                    }

                    (try ((((buffers).lane_10.?).buffer).*).append(allocator, operand_361));

                    break :block_362 ((((buffers).lane_10.?).buffer).*).items;
                } else (block_366: {
                    const operand_363 = ((value_6).work).aliases;
                    const operand_364 = @as(?[]const u8, null);
                    const operand_365 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_363).len, 1))));

                    @memcpy((operand_365)[0..(operand_363).len], operand_363);

                    (operand_365)[(operand_363).len] = operand_364;

                    break :block_366 @as((zx_abi).value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_365, {}, null, });
                }).@"0"));

                break :block_367 @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nodes = operand_339, .enumerations = operand_349, .aliases = operand_359, });
            };

            break :block_368 @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (operand_337).names, .source = (operand_337).source, .valid = (operand_337).valid, .work = operand_338, });
        };
    }

    if ((((block_323: {
        break :block_323 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Object)) or ((block_324: {
        break :block_324 value_2;
    }).kind == @as((zx_abi).zx_type_48, .Tuple)))) {
        return @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, block_333: {
            break :block_333 (try function_18_buffered(allocator, block_332: {
                const operand_325 = value_6;
                const operand_326 = (block_327: {
                    break :block_327 value_2;
                }).position;
                const operand_328 = (block_329: {
                    break :block_329 value_2;
                }).count;
                const operand_330 = ((block_331: {
                    break :block_331 value_2;
                }).kind == @as((zx_abi).zx_type_48, .Object));

                break :block_332 @as((zx_abi).value_zx_type_91_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be, (zx_abi).value_zx_type_91_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be{ .state = operand_325, .position = operand_326, .count = operand_328, .object = operand_330, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), .lane_3 = (if (((buffers).lane_3 != null)) .{ .buffer = (&(((buffers).lane_3.?).buffer).*), .started = (&(((buffers).lane_3.?).started).*), } else null), .lane_4 = (if (((buffers).lane_4 != null)) .{ .buffer = (&(((buffers).lane_4.?).buffer).*), .started = (&(((buffers).lane_4.?).started).*), } else null), .lane_5 = (if (((buffers).lane_5 != null)) .{ .buffer = (&(((buffers).lane_5.?).buffer).*), .started = (&(((buffers).lane_5.?).started).*), } else null), .lane_6 = (if (((buffers).lane_6 != null)) .{ .buffer = (&(((buffers).lane_6.?).buffer).*), .started = (&(((buffers).lane_6.?).started).*), } else null), .lane_7 = (if (((buffers).lane_7 != null)) .{ .buffer = (&(((buffers).lane_7.?).buffer).*), .started = (&(((buffers).lane_7.?).started).*), } else null), .lane_8 = (if (((buffers).lane_8 != null)) .{ .buffer = (&(((buffers).lane_8.?).buffer).*), .started = (&(((buffers).lane_8.?).started).*), } else null), .lane_9 = (if (((buffers).lane_9 != null)) .{ .buffer = (&(((buffers).lane_9.?).buffer).*), .started = (&(((buffers).lane_9.?).started).*), } else null), .lane_10 = (if (((buffers).lane_10 != null)) .{ .buffer = (&(((buffers).lane_10.?).buffer).*), .started = (&(((buffers).lane_10.?).started).*), } else null), .lane_11 = (if (((buffers).lane_11 != null)) .{ .buffer = (&(((buffers).lane_11.?).buffer).*), .started = (&(((buffers).lane_11.?).started).*), } else null), .lane_12 = (if (((buffers).lane_12 != null)) .{ .buffer = (&(((buffers).lane_12.?).buffer).*), .started = (&(((buffers).lane_12.?).started).*), } else null), }));
        });
    }

    return value_6;
}

fn function_19_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_80, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_44),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_14),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_31),
        started: *bool,
    },
    lane_8: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_32),
        started: *bool,
    },
    lane_9: ?struct {
        buffer: *(std).ArrayList(*const (zx_abi).zx_type_30),
        started: *bool,
    },
    lane_10: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
    lane_11: ?struct {
        buffer: *(std).ArrayList(bool),
        started: *bool,
    },
    lane_12: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
}) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_80 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, (((in).work).nodes).len) - @as(u64, 1));
    const value_2: *const (zx_abi).zx_type_51 = (try function_12(allocator, block_687: {
        const operand_672 = (in).source;
        const operand_673 = block_684: {
            const operand_674 = block_677: {
                const operand_675 = ((in).work).enumerations;
                const operand_676 = value_1;

                if ((operand_676 >= (operand_675).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_677 (operand_675)[@intCast(operand_676)];
            };
            const operand_678 = block_681: {
                const operand_679 = ((in).work).nodes;
                const operand_680 = value_1;

                if ((operand_680 >= (operand_679).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_681 (operand_679)[@intCast(operand_680)];
            };

            break :block_684 block_683: {
                const operand_682 = (try (allocator).create((zx_abi).zx_type_50));

                (operand_682).* = @as((zx_abi).zx_type_50, (zx_abi).zx_type_50{ .enumeration = operand_674, .index = operand_678, });

                break :block_683 @as(*const (zx_abi).zx_type_50, operand_682);
            };
        };

        break :block_687 block_686: {
            const operand_685 = (try (allocator).create((zx_abi).zx_type_87));

            (operand_685).* = @as((zx_abi).zx_type_87, (zx_abi).zx_type_87{ .source = operand_672, .reference = operand_673, });

            break :block_686 @as(*const (zx_abi).zx_type_87, operand_685);
        };
    }));
    const value_3: ?[]const u8 = block_671: {
        const operand_669 = ((in).work).aliases;
        const operand_670 = value_1;

        if ((operand_670 >= (operand_669).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_671 (operand_669)[@intCast(operand_670)];
    };

    if (((value_2).kind == @as((zx_abi).zx_type_48, .Named))) {
        const value_4: *const (zx_abi).zx_type_86 = block_668: {
            const operand_663 = block_662: {
                const operand_657 = (in).source;
                const operand_658 = ((value_2).name).text;
                const operand_659 = (try function_8(allocator, (in).source));

                break :block_662 block_661: {
                    const operand_660 = (try (allocator).create((zx_abi).zx_type_85));

                    (operand_660).* = @as((zx_abi).zx_type_85, (zx_abi).zx_type_85{ .source = operand_657, .name = operand_658, .limit = operand_659, });

                    break :block_661 @as(*const (zx_abi).zx_type_85, operand_660);
                };
            };
            const operand_665 = (try function_11_value(allocator, (zx_abi).value_zx_type_85_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b{ .limit = (operand_663).limit, .name = (operand_663).name, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((operand_663).source).indexed).bytes, .declarations = (((operand_663).source).indexed).declarations, .members = (((operand_663).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_663).source).indexed).order).fields, .heads = ((((operand_663).source).indexed).order).heads, .items = ((((operand_663).source).indexed).order).items, .zx_origin = (((operand_663).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_663).source).indexed).types).fields, .items = ((((operand_663).source).indexed).types).items, .nodes = ((((operand_663).source).indexed).types).nodes, .zx_origin = (((operand_663).source).indexed).types, }, .zx_origin = ((operand_663).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if ((((operand_663).source).native != null)) block_664: {
                break :block_664 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = (((operand_663).source).native.?).declarations, .enumerations = (((operand_663).source).native.?).enumerations, .fields = (((operand_663).source).native.?).fields, .items = (((operand_663).source).native.?).items, .members = (((operand_663).source).native.?).members, .nodes = (((operand_663).source).native.?).nodes, .zx_origin = ((operand_663).source).native.?, };
            } else null)), .zx_origin = (operand_663).source, }, .zx_origin = operand_663, }));

            break :block_668 (if (((operand_665).zx_origin != null)) (operand_665).zx_origin.? else block_667: {
                const operand_666 = (try (allocator).create((zx_abi).zx_type_86));

                (operand_666).* = (zx_abi).zx_type_86{ .found = (operand_665).found, .index = (operand_665).index, };

                break :block_667 @as(*const (zx_abi).zx_type_86, operand_666);
            });
        };

        if ((value_4).found) {
            const value_5: *const (zx_abi).zx_type_54 = (try function_10(allocator, block_656: {
                const operand_652 = (in).source;
                const operand_653 = (value_4).index;

                break :block_656 block_655: {
                    const operand_654 = (try (allocator).create((zx_abi).zx_type_84));

                    (operand_654).* = @as((zx_abi).zx_type_84, (zx_abi).zx_type_84{ .source = operand_652, .index = operand_653, });

                    break :block_655 @as(*const (zx_abi).zx_type_84, operand_654);
                };
            }));

            return block_651: {
                const operand_608 = in;
                const operand_609 = block_648: {
                    const operand_610 = @as([]const u64, (if (((buffers).lane_12 != null)) block_615: {
                        const operand_613 = (block_612: {
                            const operand_611 = ((in).work).nodes;

                            break :block_612 @as((zx_abi).zx_type_106, (if (((operand_611).len == 0)) .{ operand_611, null, } else .{ (operand_611)[0..((operand_611).len - 1)], (operand_611)[((operand_611).len - 1)], }));
                        }).@"0";
                        const operand_614 = ((value_5).value).index;

                        _ = (try ((std).math).add(usize, (operand_613).len, 1));

                        if ((!(((buffers).lane_12.?).started).*)) {
                            (try ((((buffers).lane_12.?).buffer).*).appendSlice(allocator, operand_613));

                            (((buffers).lane_12.?).started).* = true;
                        } else {
                            (((((buffers).lane_12.?).buffer).*).items).len = (operand_613).len;
                        }

                        (try ((((buffers).lane_12.?).buffer).*).append(allocator, operand_614));

                        break :block_615 ((((buffers).lane_12.?).buffer).*).items;
                    } else (block_621: {
                        const operand_618 = (block_617: {
                            const operand_616 = ((in).work).nodes;

                            break :block_617 @as((zx_abi).zx_type_106, (if (((operand_616).len == 0)) .{ operand_616, null, } else .{ (operand_616)[0..((operand_616).len - 1)], (operand_616)[((operand_616).len - 1)], }));
                        }).@"0";
                        const operand_619 = ((value_5).value).index;
                        const operand_620 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_618).len, 1))));

                        @memcpy((operand_620)[0..(operand_618).len], operand_618);

                        (operand_620)[(operand_618).len] = operand_619;

                        break :block_621 @as((zx_abi).zx_type_93, .{ operand_620, {}, });
                    }).@"0"));
                    const operand_622 = @as([]const bool, (if (((buffers).lane_11 != null)) block_627: {
                        const operand_625 = (block_624: {
                            const operand_623 = ((in).work).enumerations;

                            break :block_624 @as((zx_abi).zx_type_108, (if (((operand_623).len == 0)) .{ operand_623, null, } else .{ (operand_623)[0..((operand_623).len - 1)], (operand_623)[((operand_623).len - 1)], }));
                        }).@"0";
                        const operand_626 = ((value_5).value).enumeration;

                        _ = (try ((std).math).add(usize, (operand_625).len, 1));

                        if ((!(((buffers).lane_11.?).started).*)) {
                            (try ((((buffers).lane_11.?).buffer).*).appendSlice(allocator, operand_625));

                            (((buffers).lane_11.?).started).* = true;
                        } else {
                            (((((buffers).lane_11.?).buffer).*).items).len = (operand_625).len;
                        }

                        (try ((((buffers).lane_11.?).buffer).*).append(allocator, operand_626));

                        break :block_627 ((((buffers).lane_11.?).buffer).*).items;
                    } else (block_633: {
                        const operand_630 = (block_629: {
                            const operand_628 = ((in).work).enumerations;

                            break :block_629 @as((zx_abi).zx_type_108, (if (((operand_628).len == 0)) .{ operand_628, null, } else .{ (operand_628)[0..((operand_628).len - 1)], (operand_628)[((operand_628).len - 1)], }));
                        }).@"0";
                        const operand_631 = ((value_5).value).enumeration;
                        const operand_632 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_630).len, 1))));

                        @memcpy((operand_632)[0..(operand_630).len], operand_630);

                        (operand_632)[(operand_630).len] = operand_631;

                        break :block_633 @as((zx_abi).zx_type_94, .{ operand_632, {}, });
                    }).@"0"));
                    const operand_634 = @as([]const ?[]const u8, (if (((buffers).lane_10 != null)) block_639: {
                        const operand_637 = (block_636: {
                            const operand_635 = ((in).work).aliases;

                            break :block_636 @as((zx_abi).zx_type_110, (if (((operand_635).len == 0)) .{ operand_635, null, } else .{ (operand_635)[0..((operand_635).len - 1)], (operand_635)[((operand_635).len - 1)], }));
                        }).@"0";
                        const operand_638 = (if ((value_3 != null)) @as(?[]const u8, value_3.?) else @as(?[]const u8, ((value_2).name).text));

                        _ = (try ((std).math).add(usize, (operand_637).len, 1));

                        if ((!(((buffers).lane_10.?).started).*)) {
                            (try ((((buffers).lane_10.?).buffer).*).appendSlice(allocator, operand_637));

                            (((buffers).lane_10.?).started).* = true;
                        } else {
                            (((((buffers).lane_10.?).buffer).*).items).len = (operand_637).len;
                        }

                        (try ((((buffers).lane_10.?).buffer).*).append(allocator, operand_638));

                        break :block_639 ((((buffers).lane_10.?).buffer).*).items;
                    } else (block_645: {
                        const operand_642 = (block_641: {
                            const operand_640 = ((in).work).aliases;

                            break :block_641 @as((zx_abi).zx_type_110, (if (((operand_640).len == 0)) .{ operand_640, null, } else .{ (operand_640)[0..((operand_640).len - 1)], (operand_640)[((operand_640).len - 1)], }));
                        }).@"0";
                        const operand_643 = (if ((value_3 != null)) @as(?[]const u8, value_3.?) else @as(?[]const u8, ((value_2).name).text));
                        const operand_644 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_642).len, 1))));

                        @memcpy((operand_644)[0..(operand_642).len], operand_642);

                        (operand_644)[(operand_642).len] = operand_643;

                        break :block_645 @as((zx_abi).zx_type_95, .{ operand_644, {}, });
                    }).@"0"));

                    break :block_648 block_647: {
                        const operand_646 = (try (allocator).create((zx_abi).zx_type_79));

                        (operand_646).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_610, .enumerations = operand_622, .aliases = operand_634, });

                        break :block_647 @as(*const (zx_abi).zx_type_79, operand_646);
                    };
                };

                break :block_651 block_650: {
                    const operand_649 = (try (allocator).create((zx_abi).zx_type_80));

                    (operand_649).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (operand_608).names, .source = (operand_608).source, .valid = (operand_608).valid, .work = operand_609, });

                    break :block_650 @as(*const (zx_abi).zx_type_80, operand_649);
                };
            };
        }
    }

    if (((((value_2).kind == @as((zx_abi).zx_type_48, .List)) or ((value_2).kind == @as((zx_abi).zx_type_48, .Application))) and (!(try function_13(allocator, block_602: {
        const operand_598 = (in).source;
        const operand_599 = (value_2).child;

        break :block_602 block_601: {
            const operand_600 = (try (allocator).create((zx_abi).zx_type_87));

            (operand_600).* = @as((zx_abi).zx_type_87, (zx_abi).zx_type_87{ .source = operand_598, .reference = operand_599, });

            break :block_601 @as(*const (zx_abi).zx_type_87, operand_600);
        };
    }))))) {
        return block_607: {
            const operand_603 = in;
            const operand_604 = false;

            break :block_607 block_606: {
                const operand_605 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_605).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (operand_603).names, .source = (operand_603).source, .valid = operand_604, .work = (operand_603).work, });

                break :block_606 @as(*const (zx_abi).zx_type_80, operand_605);
            };
        };
    }

    const value_6: *const (zx_abi).zx_type_80 = block_597: {
        const operand_573 = in;
        const operand_574 = @as([]const ?[]const u8, (if (((buffers).lane_0 != null)) block_577: {
            const operand_575 = (in).names;
            const operand_576 = value_3;

            _ = (try ((std).math).add(usize, (operand_575).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_575));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_575).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_576));

            break :block_577 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_581: {
            const operand_578 = (in).names;
            const operand_579 = value_3;
            const operand_580 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_578).len, 1))));

            @memcpy((operand_580)[0..(operand_578).len], operand_578);

            (operand_580)[(operand_578).len] = operand_579;

            break :block_581 @as((zx_abi).zx_type_95, .{ operand_580, {}, });
        }).@"0"));
        const operand_582 = block_594: {
            const operand_583 = (block_585: {
                const operand_584 = ((in).work).nodes;

                break :block_585 @as((zx_abi).zx_type_106, (if (((operand_584).len == 0)) .{ operand_584, null, } else .{ (operand_584)[0..((operand_584).len - 1)], (operand_584)[((operand_584).len - 1)], }));
            }).@"0";
            const operand_586 = (block_588: {
                const operand_587 = ((in).work).enumerations;

                break :block_588 @as((zx_abi).zx_type_108, (if (((operand_587).len == 0)) .{ operand_587, null, } else .{ (operand_587)[0..((operand_587).len - 1)], (operand_587)[((operand_587).len - 1)], }));
            }).@"0";
            const operand_589 = (block_591: {
                const operand_590 = ((in).work).aliases;

                break :block_591 @as((zx_abi).zx_type_110, (if (((operand_590).len == 0)) .{ operand_590, null, } else .{ (operand_590)[0..((operand_590).len - 1)], (operand_590)[((operand_590).len - 1)], }));
            }).@"0";

            break :block_594 block_593: {
                const operand_592 = (try (allocator).create((zx_abi).zx_type_79));

                (operand_592).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_583, .enumerations = operand_586, .aliases = operand_589, });

                break :block_593 @as(*const (zx_abi).zx_type_79, operand_592);
            };
        };

        break :block_597 block_596: {
            const operand_595 = (try (allocator).create((zx_abi).zx_type_80));

            (operand_595).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = operand_574, .source = (operand_573).source, .valid = (operand_573).valid, .work = operand_582, });

            break :block_596 @as(*const (zx_abi).zx_type_80, operand_595);
        };
    };

    if (((((value_2).kind == @as((zx_abi).zx_type_48, .Optional)) or ((value_2).kind == @as((zx_abi).zx_type_48, .List))) or ((value_2).kind == @as((zx_abi).zx_type_48, .Application)))) {
        return block_572: {
            const operand_541 = value_6;
            const operand_542 = block_569: {
                const operand_543 = @as([]const u64, (if (((buffers).lane_12 != null)) block_546: {
                    const operand_544 = ((value_6).work).nodes;
                    const operand_545 = ((value_2).child).index;

                    _ = (try ((std).math).add(usize, (operand_544).len, 1));

                    if ((!(((buffers).lane_12.?).started).*)) {
                        (try ((((buffers).lane_12.?).buffer).*).appendSlice(allocator, operand_544));

                        (((buffers).lane_12.?).started).* = true;
                    } else {
                        (((((buffers).lane_12.?).buffer).*).items).len = (operand_544).len;
                    }

                    (try ((((buffers).lane_12.?).buffer).*).append(allocator, operand_545));

                    break :block_546 ((((buffers).lane_12.?).buffer).*).items;
                } else (block_550: {
                    const operand_547 = ((value_6).work).nodes;
                    const operand_548 = ((value_2).child).index;
                    const operand_549 = (try (allocator).alloc(u64, (try ((std).math).add(usize, (operand_547).len, 1))));

                    @memcpy((operand_549)[0..(operand_547).len], operand_547);

                    (operand_549)[(operand_547).len] = operand_548;

                    break :block_550 @as((zx_abi).zx_type_93, .{ operand_549, {}, });
                }).@"0"));
                const operand_551 = @as([]const bool, (if (((buffers).lane_11 != null)) block_554: {
                    const operand_552 = ((value_6).work).enumerations;
                    const operand_553 = ((value_2).child).enumeration;

                    _ = (try ((std).math).add(usize, (operand_552).len, 1));

                    if ((!(((buffers).lane_11.?).started).*)) {
                        (try ((((buffers).lane_11.?).buffer).*).appendSlice(allocator, operand_552));

                        (((buffers).lane_11.?).started).* = true;
                    } else {
                        (((((buffers).lane_11.?).buffer).*).items).len = (operand_552).len;
                    }

                    (try ((((buffers).lane_11.?).buffer).*).append(allocator, operand_553));

                    break :block_554 ((((buffers).lane_11.?).buffer).*).items;
                } else (block_558: {
                    const operand_555 = ((value_6).work).enumerations;
                    const operand_556 = ((value_2).child).enumeration;
                    const operand_557 = (try (allocator).alloc(bool, (try ((std).math).add(usize, (operand_555).len, 1))));

                    @memcpy((operand_557)[0..(operand_555).len], operand_555);

                    (operand_557)[(operand_555).len] = operand_556;

                    break :block_558 @as((zx_abi).zx_type_94, .{ operand_557, {}, });
                }).@"0"));
                const operand_559 = @as([]const ?[]const u8, (if (((buffers).lane_10 != null)) block_562: {
                    const operand_560 = ((value_6).work).aliases;
                    const operand_561 = @as(?[]const u8, null);

                    _ = (try ((std).math).add(usize, (operand_560).len, 1));

                    if ((!(((buffers).lane_10.?).started).*)) {
                        (try ((((buffers).lane_10.?).buffer).*).appendSlice(allocator, operand_560));

                        (((buffers).lane_10.?).started).* = true;
                    } else {
                        (((((buffers).lane_10.?).buffer).*).items).len = (operand_560).len;
                    }

                    (try ((((buffers).lane_10.?).buffer).*).append(allocator, operand_561));

                    break :block_562 ((((buffers).lane_10.?).buffer).*).items;
                } else (block_566: {
                    const operand_563 = ((value_6).work).aliases;
                    const operand_564 = @as(?[]const u8, null);
                    const operand_565 = (try (allocator).alloc(?[]const u8, (try ((std).math).add(usize, (operand_563).len, 1))));

                    @memcpy((operand_565)[0..(operand_563).len], operand_563);

                    (operand_565)[(operand_563).len] = operand_564;

                    break :block_566 @as((zx_abi).zx_type_95, .{ operand_565, {}, });
                }).@"0"));

                break :block_569 block_568: {
                    const operand_567 = (try (allocator).create((zx_abi).zx_type_79));

                    (operand_567).* = @as((zx_abi).zx_type_79, (zx_abi).zx_type_79{ .nodes = operand_543, .enumerations = operand_551, .aliases = operand_559, });

                    break :block_568 @as(*const (zx_abi).zx_type_79, operand_567);
                };
            };

            break :block_572 block_571: {
                const operand_570 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_570).* = @as((zx_abi).zx_type_80, (zx_abi).zx_type_80{ .names = (operand_541).names, .source = (operand_541).source, .valid = (operand_541).valid, .work = operand_542, });

                break :block_571 @as(*const (zx_abi).zx_type_80, operand_570);
            };
        };
    }

    if ((((value_2).kind == @as((zx_abi).zx_type_48, .Object)) or ((value_2).kind == @as((zx_abi).zx_type_48, .Tuple)))) {
        return (try function_18_buffered_pointer(allocator, block_540: {
            const operand_534 = value_6;
            const operand_535 = (value_2).position;
            const operand_536 = (value_2).count;
            const operand_537 = ((value_2).kind == @as((zx_abi).zx_type_48, .Object));

            break :block_540 block_539: {
                const operand_538 = (try (allocator).create((zx_abi).zx_type_91));

                (operand_538).* = @as((zx_abi).zx_type_91, (zx_abi).zx_type_91{ .state = operand_534, .position = operand_535, .count = operand_536, .object = operand_537, });

                break :block_539 @as(*const (zx_abi).zx_type_91, operand_538);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), .lane_3 = (if (((buffers).lane_3 != null)) .{ .buffer = (&(((buffers).lane_3.?).buffer).*), .started = (&(((buffers).lane_3.?).started).*), } else null), .lane_4 = (if (((buffers).lane_4 != null)) .{ .buffer = (&(((buffers).lane_4.?).buffer).*), .started = (&(((buffers).lane_4.?).started).*), } else null), .lane_5 = (if (((buffers).lane_5 != null)) .{ .buffer = (&(((buffers).lane_5.?).buffer).*), .started = (&(((buffers).lane_5.?).started).*), } else null), .lane_6 = (if (((buffers).lane_6 != null)) .{ .buffer = (&(((buffers).lane_6.?).buffer).*), .started = (&(((buffers).lane_6.?).started).*), } else null), .lane_7 = (if (((buffers).lane_7 != null)) .{ .buffer = (&(((buffers).lane_7.?).buffer).*), .started = (&(((buffers).lane_7.?).started).*), } else null), .lane_8 = (if (((buffers).lane_8 != null)) .{ .buffer = (&(((buffers).lane_8.?).buffer).*), .started = (&(((buffers).lane_8.?).started).*), } else null), .lane_9 = (if (((buffers).lane_9 != null)) .{ .buffer = (&(((buffers).lane_9.?).buffer).*), .started = (&(((buffers).lane_9.?).started).*), } else null), .lane_10 = (if (((buffers).lane_10 != null)) .{ .buffer = (&(((buffers).lane_10.?).buffer).*), .started = (&(((buffers).lane_10.?).started).*), } else null), .lane_11 = (if (((buffers).lane_11 != null)) .{ .buffer = (&(((buffers).lane_11.?).buffer).*), .started = (&(((buffers).lane_11.?).started).*), } else null), .lane_12 = (if (((buffers).lane_12 != null)) .{ .buffer = (&(((buffers).lane_12.?).buffer).*), .started = (&(((buffers).lane_12.?).started).*), } else null), }));
    }

    return value_6;
}

fn function_20(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_80) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_81 {
    @setRuntimeSafety(true);

    const value_4: *const (zx_abi).zx_type_80 = block_64: {
        const operand_8 = in;

        var state_capacity_10: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_11 = false;

        defer (state_capacity_10).deinit(allocator);

        var state_capacity_12: (std).ArrayList(*const (zx_abi).zx_type_44) = .empty;

        var state_capacity_started_13 = false;

        defer (state_capacity_12).deinit(allocator);

        var state_capacity_14: (std).ArrayList(*const (zx_abi).zx_type_14) = .empty;

        var state_capacity_started_15 = false;

        defer (state_capacity_14).deinit(allocator);

        var state_capacity_16: (std).ArrayList(u64) = .empty;

        var state_capacity_started_17 = false;

        defer (state_capacity_16).deinit(allocator);

        var state_capacity_18: (std).ArrayList(u64) = .empty;

        var state_capacity_started_19 = false;

        defer (state_capacity_18).deinit(allocator);

        var state_capacity_20: (std).ArrayList(u64) = .empty;

        var state_capacity_started_21 = false;

        defer (state_capacity_20).deinit(allocator);

        var state_capacity_22: (std).ArrayList(*const (zx_abi).zx_type_31) = .empty;

        var state_capacity_started_23 = false;

        defer (state_capacity_22).deinit(allocator);

        var state_capacity_24: (std).ArrayList(*const (zx_abi).zx_type_32) = .empty;

        var state_capacity_started_25 = false;

        defer (state_capacity_24).deinit(allocator);

        var state_capacity_26: (std).ArrayList(*const (zx_abi).zx_type_30) = .empty;

        var state_capacity_started_27 = false;

        defer (state_capacity_26).deinit(allocator);

        var state_capacity_28: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_29 = false;

        defer (state_capacity_28).deinit(allocator);

        var state_capacity_30: (std).ArrayList(bool) = .empty;

        var state_capacity_started_31 = false;

        defer (state_capacity_30).deinit(allocator);

        var state_capacity_32: (std).ArrayList(u64) = .empty;

        var state_capacity_started_33 = false;

        defer (state_capacity_32).deinit(allocator);

        var state_7: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (operand_8).names, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((operand_8).source).indexed).bytes, .declarations = (((operand_8).source).indexed).declarations, .members = (((operand_8).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_8).source).indexed).order).fields, .heads = ((((operand_8).source).indexed).order).heads, .items = ((((operand_8).source).indexed).order).items, .zx_origin = (((operand_8).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_8).source).indexed).types).fields, .items = ((((operand_8).source).indexed).types).items, .nodes = ((((operand_8).source).indexed).types).nodes, .zx_origin = (((operand_8).source).indexed).types, }, .zx_origin = ((operand_8).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if ((((operand_8).source).native != null)) block_35: {
            break :block_35 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = (((operand_8).source).native.?).declarations, .enumerations = (((operand_8).source).native.?).enumerations, .fields = (((operand_8).source).native.?).fields, .items = (((operand_8).source).native.?).items, .members = (((operand_8).source).native.?).members, .nodes = (((operand_8).source).native.?).nodes, .zx_origin = ((operand_8).source).native.?, };
        } else null)), .zx_origin = (operand_8).source, }, .valid = (operand_8).valid, .work = (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((operand_8).work).aliases, .enumerations = ((operand_8).work).enumerations, .nodes = ((operand_8).work).nodes, .zx_origin = (operand_8).work, }, .zx_origin = operand_8, };

        var state_changed_9 = false;

        while (((state_7).valid and (@as(u64, (((state_7).work).nodes).len) != @as(u64, 0)))) {
            state_7 = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, block_34: {
                break :block_34 (try function_19_buffered(allocator, state_7, .{ .lane_0 = .{ .buffer = (&state_capacity_10), .started = (&state_capacity_started_11), }, .lane_2 = .{ .buffer = (&state_capacity_12), .started = (&state_capacity_started_13), }, .lane_3 = .{ .buffer = (&state_capacity_14), .started = (&state_capacity_started_15), }, .lane_4 = .{ .buffer = (&state_capacity_16), .started = (&state_capacity_started_17), }, .lane_5 = .{ .buffer = (&state_capacity_18), .started = (&state_capacity_started_19), }, .lane_6 = .{ .buffer = (&state_capacity_20), .started = (&state_capacity_started_21), }, .lane_7 = .{ .buffer = (&state_capacity_22), .started = (&state_capacity_started_23), }, .lane_8 = .{ .buffer = (&state_capacity_24), .started = (&state_capacity_started_25), }, .lane_9 = .{ .buffer = (&state_capacity_26), .started = (&state_capacity_started_27), }, .lane_10 = .{ .buffer = (&state_capacity_28), .started = (&state_capacity_started_29), }, .lane_11 = .{ .buffer = (&state_capacity_30), .started = (&state_capacity_started_31), }, .lane_12 = .{ .buffer = (&state_capacity_32), .started = (&state_capacity_started_33), }, }));
            });

            state_changed_9 = true;
        }

        var state_owned_36: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_36);

        if (state_capacity_started_11) {
            ((state_capacity_10).items).len = ((state_7).names).len;

            state_owned_36 = (try (state_capacity_10).toOwnedSlice(allocator));
        }

        if (state_capacity_started_11) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = state_owned_36, .source = (state_7).source, .valid = (state_7).valid, .work = (state_7).work, };
        }

        var state_owned_37: []const *const (zx_abi).zx_type_44 = (&[_]*const (zx_abi).zx_type_44{});

        errdefer (allocator).free(state_owned_37);

        if (state_capacity_started_13) {
            ((state_capacity_12).items).len = ((((state_7).source).indexed).declarations).len;

            state_owned_37 = (try (state_capacity_12).toOwnedSlice(allocator));
        }

        if (state_capacity_started_13) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_7).source).indexed).bytes, .declarations = state_owned_37, .members = (((state_7).source).indexed).members, .order = (((state_7).source).indexed).order, .types = (((state_7).source).indexed).types, }), .native = ((state_7).source).native, }), .valid = (state_7).valid, .work = (state_7).work, };
        }

        var state_owned_38: []const *const (zx_abi).zx_type_14 = (&[_]*const (zx_abi).zx_type_14{});

        errdefer (allocator).free(state_owned_38);

        if (state_capacity_started_15) {
            ((state_capacity_14).items).len = ((((state_7).source).indexed).members).len;

            state_owned_38 = (try (state_capacity_14).toOwnedSlice(allocator));
        }

        if (state_capacity_started_15) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_7).source).indexed).bytes, .declarations = (((state_7).source).indexed).declarations, .members = state_owned_38, .order = (((state_7).source).indexed).order, .types = (((state_7).source).indexed).types, }), .native = ((state_7).source).native, }), .valid = (state_7).valid, .work = (state_7).work, };
        }

        var state_owned_39: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_39);

        if (state_capacity_started_17) {
            ((state_capacity_16).items).len = (((((state_7).source).indexed).order).fields).len;

            state_owned_39 = (try (state_capacity_16).toOwnedSlice(allocator));
        }

        if (state_capacity_started_17) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_7).source).indexed).bytes, .declarations = (((state_7).source).indexed).declarations, .members = (((state_7).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = state_owned_39, .heads = ((((state_7).source).indexed).order).heads, .items = ((((state_7).source).indexed).order).items, }), .types = (((state_7).source).indexed).types, }), .native = ((state_7).source).native, }), .valid = (state_7).valid, .work = (state_7).work, };
        }

        var state_owned_40: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_40);

        if (state_capacity_started_19) {
            ((state_capacity_18).items).len = (((((state_7).source).indexed).order).heads).len;

            state_owned_40 = (try (state_capacity_18).toOwnedSlice(allocator));
        }

        if (state_capacity_started_19) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_7).source).indexed).bytes, .declarations = (((state_7).source).indexed).declarations, .members = (((state_7).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_7).source).indexed).order).fields, .heads = state_owned_40, .items = ((((state_7).source).indexed).order).items, }), .types = (((state_7).source).indexed).types, }), .native = ((state_7).source).native, }), .valid = (state_7).valid, .work = (state_7).work, };
        }

        var state_owned_41: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_41);

        if (state_capacity_started_21) {
            ((state_capacity_20).items).len = (((((state_7).source).indexed).order).items).len;

            state_owned_41 = (try (state_capacity_20).toOwnedSlice(allocator));
        }

        if (state_capacity_started_21) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_7).source).indexed).bytes, .declarations = (((state_7).source).indexed).declarations, .members = (((state_7).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_7).source).indexed).order).fields, .heads = ((((state_7).source).indexed).order).heads, .items = state_owned_41, }), .types = (((state_7).source).indexed).types, }), .native = ((state_7).source).native, }), .valid = (state_7).valid, .work = (state_7).work, };
        }

        var state_owned_42: []const *const (zx_abi).zx_type_31 = (&[_]*const (zx_abi).zx_type_31{});

        errdefer (allocator).free(state_owned_42);

        if (state_capacity_started_23) {
            ((state_capacity_22).items).len = (((((state_7).source).indexed).types).fields).len;

            state_owned_42 = (try (state_capacity_22).toOwnedSlice(allocator));
        }

        if (state_capacity_started_23) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_7).source).indexed).bytes, .declarations = (((state_7).source).indexed).declarations, .members = (((state_7).source).indexed).members, .order = (((state_7).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = state_owned_42, .items = ((((state_7).source).indexed).types).items, .nodes = ((((state_7).source).indexed).types).nodes, }), }), .native = ((state_7).source).native, }), .valid = (state_7).valid, .work = (state_7).work, };
        }

        var state_owned_43: []const *const (zx_abi).zx_type_32 = (&[_]*const (zx_abi).zx_type_32{});

        errdefer (allocator).free(state_owned_43);

        if (state_capacity_started_25) {
            ((state_capacity_24).items).len = (((((state_7).source).indexed).types).items).len;

            state_owned_43 = (try (state_capacity_24).toOwnedSlice(allocator));
        }

        if (state_capacity_started_25) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_7).source).indexed).bytes, .declarations = (((state_7).source).indexed).declarations, .members = (((state_7).source).indexed).members, .order = (((state_7).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_7).source).indexed).types).fields, .items = state_owned_43, .nodes = ((((state_7).source).indexed).types).nodes, }), }), .native = ((state_7).source).native, }), .valid = (state_7).valid, .work = (state_7).work, };
        }

        var state_owned_44: []const *const (zx_abi).zx_type_30 = (&[_]*const (zx_abi).zx_type_30{});

        errdefer (allocator).free(state_owned_44);

        if (state_capacity_started_27) {
            ((state_capacity_26).items).len = (((((state_7).source).indexed).types).nodes).len;

            state_owned_44 = (try (state_capacity_26).toOwnedSlice(allocator));
        }

        if (state_capacity_started_27) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_7).source).indexed).bytes, .declarations = (((state_7).source).indexed).declarations, .members = (((state_7).source).indexed).members, .order = (((state_7).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_7).source).indexed).types).fields, .items = ((((state_7).source).indexed).types).items, .nodes = state_owned_44, }), }), .native = ((state_7).source).native, }), .valid = (state_7).valid, .work = (state_7).work, };
        }

        var state_owned_45: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_45);

        if (state_capacity_started_29) {
            ((state_capacity_28).items).len = (((state_7).work).aliases).len;

            state_owned_45 = (try (state_capacity_28).toOwnedSlice(allocator));
        }

        if (state_capacity_started_29) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = (state_7).source, .valid = (state_7).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_45, .enumerations = ((state_7).work).enumerations, .nodes = ((state_7).work).nodes, }), };
        }

        var state_owned_46: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_46);

        if (state_capacity_started_31) {
            ((state_capacity_30).items).len = (((state_7).work).enumerations).len;

            state_owned_46 = (try (state_capacity_30).toOwnedSlice(allocator));
        }

        if (state_capacity_started_31) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = (state_7).source, .valid = (state_7).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_7).work).aliases, .enumerations = state_owned_46, .nodes = ((state_7).work).nodes, }), };
        }

        var state_owned_47: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_47);

        if (state_capacity_started_33) {
            ((state_capacity_32).items).len = (((state_7).work).nodes).len;

            state_owned_47 = (try (state_capacity_32).toOwnedSlice(allocator));
        }

        if (state_capacity_started_33) {
            state_7 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_7).names, .source = (state_7).source, .valid = (state_7).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_7).work).aliases, .enumerations = ((state_7).work).enumerations, .nodes = state_owned_47, }), };
        }

        break :block_64 (if (state_changed_9) block_63: {
            break :block_63 (if (((state_7).zx_origin != null)) (state_7).zx_origin.? else block_62: {
                const operand_61 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_61).* = (zx_abi).zx_type_80{ .names = (state_7).names, .source = (if ((((state_7).source).zx_origin != null)) ((state_7).source).zx_origin.? else block_58: {
                    const operand_57 = (try (allocator).create((zx_abi).zx_type_66));

                    (operand_57).* = (zx_abi).zx_type_66{ .indexed = (if (((((state_7).source).indexed).zx_origin != null)) (((state_7).source).indexed).zx_origin.? else block_53: {
                        const operand_52 = (try (allocator).create((zx_abi).zx_type_64));

                        (operand_52).* = (zx_abi).zx_type_64{ .bytes = (((state_7).source).indexed).bytes, .declarations = (((state_7).source).indexed).declarations, .members = (((state_7).source).indexed).members, .order = (if ((((((state_7).source).indexed).order).zx_origin != null)) ((((state_7).source).indexed).order).zx_origin.? else block_49: {
                            const operand_48 = (try (allocator).create((zx_abi).zx_type_34));

                            (operand_48).* = (zx_abi).zx_type_34{ .fields = ((((state_7).source).indexed).order).fields, .heads = ((((state_7).source).indexed).order).heads, .items = ((((state_7).source).indexed).order).items, };

                            break :block_49 @as(*const (zx_abi).zx_type_34, operand_48);
                        }), .types = (if ((((((state_7).source).indexed).types).zx_origin != null)) ((((state_7).source).indexed).types).zx_origin.? else block_51: {
                            const operand_50 = (try (allocator).create((zx_abi).zx_type_38));

                            (operand_50).* = (zx_abi).zx_type_38{ .fields = ((((state_7).source).indexed).types).fields, .items = ((((state_7).source).indexed).types).items, .nodes = ((((state_7).source).indexed).types).nodes, };

                            break :block_51 @as(*const (zx_abi).zx_type_38, operand_50);
                        }), };

                        break :block_53 @as(*const (zx_abi).zx_type_64, operand_52);
                    }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((state_7).source).native != null)) block_56: {
                        break :block_56 (if (((((state_7).source).native.?).zx_origin != null)) (((state_7).source).native.?).zx_origin.? else block_55: {
                            const operand_54 = (try (allocator).create((zx_abi).zx_type_62));

                            (operand_54).* = (zx_abi).zx_type_62{ .declarations = (((state_7).source).native.?).declarations, .enumerations = (((state_7).source).native.?).enumerations, .fields = (((state_7).source).native.?).fields, .items = (((state_7).source).native.?).items, .members = (((state_7).source).native.?).members, .nodes = (((state_7).source).native.?).nodes, };

                            break :block_55 @as(*const (zx_abi).zx_type_62, operand_54);
                        });
                    } else null)), };

                    break :block_58 @as(*const (zx_abi).zx_type_66, operand_57);
                }), .valid = (state_7).valid, .work = (if ((((state_7).work).zx_origin != null)) ((state_7).work).zx_origin.? else block_60: {
                    const operand_59 = (try (allocator).create((zx_abi).zx_type_79));

                    (operand_59).* = (zx_abi).zx_type_79{ .aliases = ((state_7).work).aliases, .enumerations = ((state_7).work).enumerations, .nodes = ((state_7).work).nodes, };

                    break :block_60 @as(*const (zx_abi).zx_type_79, operand_59);
                }), };

                break :block_62 @as(*const (zx_abi).zx_type_80, operand_61);
            });
        } else operand_8);
    };

    return block_6: {
        const operand_2 = (value_4).names;
        const operand_3 = (value_4).valid;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create((zx_abi).zx_type_81));

            (operand_4).* = @as((zx_abi).zx_type_81, (zx_abi).zx_type_81{ .names = operand_2, .valid = operand_3, });

            break :block_5 @as(*const (zx_abi).zx_type_81, operand_4);
        };
    };
}

fn function_20_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_4: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 = block_110: {
        const operand_70 = in;

        var state_capacity_72: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_73 = false;

        defer (state_capacity_72).deinit(allocator);

        var state_capacity_74: (std).ArrayList(*const (zx_abi).zx_type_44) = .empty;

        var state_capacity_started_75 = false;

        defer (state_capacity_74).deinit(allocator);

        var state_capacity_76: (std).ArrayList(*const (zx_abi).zx_type_14) = .empty;

        var state_capacity_started_77 = false;

        defer (state_capacity_76).deinit(allocator);

        var state_capacity_78: (std).ArrayList(u64) = .empty;

        var state_capacity_started_79 = false;

        defer (state_capacity_78).deinit(allocator);

        var state_capacity_80: (std).ArrayList(u64) = .empty;

        var state_capacity_started_81 = false;

        defer (state_capacity_80).deinit(allocator);

        var state_capacity_82: (std).ArrayList(u64) = .empty;

        var state_capacity_started_83 = false;

        defer (state_capacity_82).deinit(allocator);

        var state_capacity_84: (std).ArrayList(*const (zx_abi).zx_type_31) = .empty;

        var state_capacity_started_85 = false;

        defer (state_capacity_84).deinit(allocator);

        var state_capacity_86: (std).ArrayList(*const (zx_abi).zx_type_32) = .empty;

        var state_capacity_started_87 = false;

        defer (state_capacity_86).deinit(allocator);

        var state_capacity_88: (std).ArrayList(*const (zx_abi).zx_type_30) = .empty;

        var state_capacity_started_89 = false;

        defer (state_capacity_88).deinit(allocator);

        var state_capacity_90: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_91 = false;

        defer (state_capacity_90).deinit(allocator);

        var state_capacity_92: (std).ArrayList(bool) = .empty;

        var state_capacity_started_93 = false;

        defer (state_capacity_92).deinit(allocator);

        var state_capacity_94: (std).ArrayList(u64) = .empty;

        var state_capacity_started_95 = false;

        defer (state_capacity_94).deinit(allocator);

        var state_69: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 = operand_70;

        var state_changed_71 = false;

        while (((state_69).valid and (@as(u64, (((state_69).work).nodes).len) != @as(u64, 0)))) {
            state_69 = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, block_96: {
                break :block_96 (try function_19_buffered(allocator, state_69, .{ .lane_0 = .{ .buffer = (&state_capacity_72), .started = (&state_capacity_started_73), }, .lane_2 = .{ .buffer = (&state_capacity_74), .started = (&state_capacity_started_75), }, .lane_3 = .{ .buffer = (&state_capacity_76), .started = (&state_capacity_started_77), }, .lane_4 = .{ .buffer = (&state_capacity_78), .started = (&state_capacity_started_79), }, .lane_5 = .{ .buffer = (&state_capacity_80), .started = (&state_capacity_started_81), }, .lane_6 = .{ .buffer = (&state_capacity_82), .started = (&state_capacity_started_83), }, .lane_7 = .{ .buffer = (&state_capacity_84), .started = (&state_capacity_started_85), }, .lane_8 = .{ .buffer = (&state_capacity_86), .started = (&state_capacity_started_87), }, .lane_9 = .{ .buffer = (&state_capacity_88), .started = (&state_capacity_started_89), }, .lane_10 = .{ .buffer = (&state_capacity_90), .started = (&state_capacity_started_91), }, .lane_11 = .{ .buffer = (&state_capacity_92), .started = (&state_capacity_started_93), }, .lane_12 = .{ .buffer = (&state_capacity_94), .started = (&state_capacity_started_95), }, }));
            });

            state_changed_71 = true;
        }

        var state_owned_97: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_97);

        if (state_capacity_started_73) {
            ((state_capacity_72).items).len = ((state_69).names).len;

            state_owned_97 = (try (state_capacity_72).toOwnedSlice(allocator));
        }

        if (state_capacity_started_73) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = state_owned_97, .source = (state_69).source, .valid = (state_69).valid, .work = (state_69).work, };
        }

        var state_owned_98: []const *const (zx_abi).zx_type_44 = (&[_]*const (zx_abi).zx_type_44{});

        errdefer (allocator).free(state_owned_98);

        if (state_capacity_started_75) {
            ((state_capacity_74).items).len = ((((state_69).source).indexed).declarations).len;

            state_owned_98 = (try (state_capacity_74).toOwnedSlice(allocator));
        }

        if (state_capacity_started_75) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_69).source).indexed).bytes, .declarations = state_owned_98, .members = (((state_69).source).indexed).members, .order = (((state_69).source).indexed).order, .types = (((state_69).source).indexed).types, }), .native = ((state_69).source).native, }), .valid = (state_69).valid, .work = (state_69).work, };
        }

        var state_owned_99: []const *const (zx_abi).zx_type_14 = (&[_]*const (zx_abi).zx_type_14{});

        errdefer (allocator).free(state_owned_99);

        if (state_capacity_started_77) {
            ((state_capacity_76).items).len = ((((state_69).source).indexed).members).len;

            state_owned_99 = (try (state_capacity_76).toOwnedSlice(allocator));
        }

        if (state_capacity_started_77) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_69).source).indexed).bytes, .declarations = (((state_69).source).indexed).declarations, .members = state_owned_99, .order = (((state_69).source).indexed).order, .types = (((state_69).source).indexed).types, }), .native = ((state_69).source).native, }), .valid = (state_69).valid, .work = (state_69).work, };
        }

        var state_owned_100: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_100);

        if (state_capacity_started_79) {
            ((state_capacity_78).items).len = (((((state_69).source).indexed).order).fields).len;

            state_owned_100 = (try (state_capacity_78).toOwnedSlice(allocator));
        }

        if (state_capacity_started_79) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_69).source).indexed).bytes, .declarations = (((state_69).source).indexed).declarations, .members = (((state_69).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = state_owned_100, .heads = ((((state_69).source).indexed).order).heads, .items = ((((state_69).source).indexed).order).items, }), .types = (((state_69).source).indexed).types, }), .native = ((state_69).source).native, }), .valid = (state_69).valid, .work = (state_69).work, };
        }

        var state_owned_101: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_101);

        if (state_capacity_started_81) {
            ((state_capacity_80).items).len = (((((state_69).source).indexed).order).heads).len;

            state_owned_101 = (try (state_capacity_80).toOwnedSlice(allocator));
        }

        if (state_capacity_started_81) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_69).source).indexed).bytes, .declarations = (((state_69).source).indexed).declarations, .members = (((state_69).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_69).source).indexed).order).fields, .heads = state_owned_101, .items = ((((state_69).source).indexed).order).items, }), .types = (((state_69).source).indexed).types, }), .native = ((state_69).source).native, }), .valid = (state_69).valid, .work = (state_69).work, };
        }

        var state_owned_102: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_102);

        if (state_capacity_started_83) {
            ((state_capacity_82).items).len = (((((state_69).source).indexed).order).items).len;

            state_owned_102 = (try (state_capacity_82).toOwnedSlice(allocator));
        }

        if (state_capacity_started_83) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_69).source).indexed).bytes, .declarations = (((state_69).source).indexed).declarations, .members = (((state_69).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_69).source).indexed).order).fields, .heads = ((((state_69).source).indexed).order).heads, .items = state_owned_102, }), .types = (((state_69).source).indexed).types, }), .native = ((state_69).source).native, }), .valid = (state_69).valid, .work = (state_69).work, };
        }

        var state_owned_103: []const *const (zx_abi).zx_type_31 = (&[_]*const (zx_abi).zx_type_31{});

        errdefer (allocator).free(state_owned_103);

        if (state_capacity_started_85) {
            ((state_capacity_84).items).len = (((((state_69).source).indexed).types).fields).len;

            state_owned_103 = (try (state_capacity_84).toOwnedSlice(allocator));
        }

        if (state_capacity_started_85) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_69).source).indexed).bytes, .declarations = (((state_69).source).indexed).declarations, .members = (((state_69).source).indexed).members, .order = (((state_69).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = state_owned_103, .items = ((((state_69).source).indexed).types).items, .nodes = ((((state_69).source).indexed).types).nodes, }), }), .native = ((state_69).source).native, }), .valid = (state_69).valid, .work = (state_69).work, };
        }

        var state_owned_104: []const *const (zx_abi).zx_type_32 = (&[_]*const (zx_abi).zx_type_32{});

        errdefer (allocator).free(state_owned_104);

        if (state_capacity_started_87) {
            ((state_capacity_86).items).len = (((((state_69).source).indexed).types).items).len;

            state_owned_104 = (try (state_capacity_86).toOwnedSlice(allocator));
        }

        if (state_capacity_started_87) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_69).source).indexed).bytes, .declarations = (((state_69).source).indexed).declarations, .members = (((state_69).source).indexed).members, .order = (((state_69).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_69).source).indexed).types).fields, .items = state_owned_104, .nodes = ((((state_69).source).indexed).types).nodes, }), }), .native = ((state_69).source).native, }), .valid = (state_69).valid, .work = (state_69).work, };
        }

        var state_owned_105: []const *const (zx_abi).zx_type_30 = (&[_]*const (zx_abi).zx_type_30{});

        errdefer (allocator).free(state_owned_105);

        if (state_capacity_started_89) {
            ((state_capacity_88).items).len = (((((state_69).source).indexed).types).nodes).len;

            state_owned_105 = (try (state_capacity_88).toOwnedSlice(allocator));
        }

        if (state_capacity_started_89) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_69).source).indexed).bytes, .declarations = (((state_69).source).indexed).declarations, .members = (((state_69).source).indexed).members, .order = (((state_69).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_69).source).indexed).types).fields, .items = ((((state_69).source).indexed).types).items, .nodes = state_owned_105, }), }), .native = ((state_69).source).native, }), .valid = (state_69).valid, .work = (state_69).work, };
        }

        var state_owned_106: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_106);

        if (state_capacity_started_91) {
            ((state_capacity_90).items).len = (((state_69).work).aliases).len;

            state_owned_106 = (try (state_capacity_90).toOwnedSlice(allocator));
        }

        if (state_capacity_started_91) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = (state_69).source, .valid = (state_69).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_106, .enumerations = ((state_69).work).enumerations, .nodes = ((state_69).work).nodes, }), };
        }

        var state_owned_107: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_107);

        if (state_capacity_started_93) {
            ((state_capacity_92).items).len = (((state_69).work).enumerations).len;

            state_owned_107 = (try (state_capacity_92).toOwnedSlice(allocator));
        }

        if (state_capacity_started_93) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = (state_69).source, .valid = (state_69).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_69).work).aliases, .enumerations = state_owned_107, .nodes = ((state_69).work).nodes, }), };
        }

        var state_owned_108: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_108);

        if (state_capacity_started_95) {
            ((state_capacity_94).items).len = (((state_69).work).nodes).len;

            state_owned_108 = (try (state_capacity_94).toOwnedSlice(allocator));
        }

        if (state_capacity_started_95) {
            state_69 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_69).names, .source = (state_69).source, .valid = (state_69).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_69).work).aliases, .enumerations = ((state_69).work).enumerations, .nodes = state_owned_108, }), };
        }

        break :block_110 (if (state_changed_71) state_69 else operand_70);
    };

    return block_68: {
        const operand_66 = (value_4).names;
        const operand_67 = (value_4).valid;

        break :block_68 @as((zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = operand_66, .valid = operand_67, });
    };
}

fn function_20_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
}) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_4: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 = block_153: {
        const operand_116 = in;

        var state_capacity_118: (std).ArrayList(*const (zx_abi).zx_type_44) = .empty;

        var state_capacity_started_119 = false;

        defer (state_capacity_118).deinit(allocator);

        var state_capacity_120: (std).ArrayList(*const (zx_abi).zx_type_14) = .empty;

        var state_capacity_started_121 = false;

        defer (state_capacity_120).deinit(allocator);

        var state_capacity_122: (std).ArrayList(u64) = .empty;

        var state_capacity_started_123 = false;

        defer (state_capacity_122).deinit(allocator);

        var state_capacity_124: (std).ArrayList(u64) = .empty;

        var state_capacity_started_125 = false;

        defer (state_capacity_124).deinit(allocator);

        var state_capacity_126: (std).ArrayList(u64) = .empty;

        var state_capacity_started_127 = false;

        defer (state_capacity_126).deinit(allocator);

        var state_capacity_128: (std).ArrayList(*const (zx_abi).zx_type_31) = .empty;

        var state_capacity_started_129 = false;

        defer (state_capacity_128).deinit(allocator);

        var state_capacity_130: (std).ArrayList(*const (zx_abi).zx_type_32) = .empty;

        var state_capacity_started_131 = false;

        defer (state_capacity_130).deinit(allocator);

        var state_capacity_132: (std).ArrayList(*const (zx_abi).zx_type_30) = .empty;

        var state_capacity_started_133 = false;

        defer (state_capacity_132).deinit(allocator);

        var state_capacity_134: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_135 = false;

        defer (state_capacity_134).deinit(allocator);

        var state_capacity_136: (std).ArrayList(bool) = .empty;

        var state_capacity_started_137 = false;

        defer (state_capacity_136).deinit(allocator);

        var state_capacity_138: (std).ArrayList(u64) = .empty;

        var state_capacity_started_139 = false;

        defer (state_capacity_138).deinit(allocator);

        var state_115: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 = operand_116;

        var state_changed_117 = false;

        while (((state_115).valid and (@as(u64, (((state_115).work).nodes).len) != @as(u64, 0)))) {
            state_115 = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, block_140: {
                break :block_140 (try function_19_buffered(allocator, state_115, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_2 = .{ .buffer = (&state_capacity_118), .started = (&state_capacity_started_119), }, .lane_3 = .{ .buffer = (&state_capacity_120), .started = (&state_capacity_started_121), }, .lane_4 = .{ .buffer = (&state_capacity_122), .started = (&state_capacity_started_123), }, .lane_5 = .{ .buffer = (&state_capacity_124), .started = (&state_capacity_started_125), }, .lane_6 = .{ .buffer = (&state_capacity_126), .started = (&state_capacity_started_127), }, .lane_7 = .{ .buffer = (&state_capacity_128), .started = (&state_capacity_started_129), }, .lane_8 = .{ .buffer = (&state_capacity_130), .started = (&state_capacity_started_131), }, .lane_9 = .{ .buffer = (&state_capacity_132), .started = (&state_capacity_started_133), }, .lane_10 = .{ .buffer = (&state_capacity_134), .started = (&state_capacity_started_135), }, .lane_11 = .{ .buffer = (&state_capacity_136), .started = (&state_capacity_started_137), }, .lane_12 = .{ .buffer = (&state_capacity_138), .started = (&state_capacity_started_139), }, }));
            });

            state_changed_117 = true;
        }

        var state_owned_141: []const *const (zx_abi).zx_type_44 = (&[_]*const (zx_abi).zx_type_44{});

        errdefer (allocator).free(state_owned_141);

        if (state_capacity_started_119) {
            ((state_capacity_118).items).len = ((((state_115).source).indexed).declarations).len;

            state_owned_141 = (try (state_capacity_118).toOwnedSlice(allocator));
        }

        if (state_capacity_started_119) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_115).source).indexed).bytes, .declarations = state_owned_141, .members = (((state_115).source).indexed).members, .order = (((state_115).source).indexed).order, .types = (((state_115).source).indexed).types, }), .native = ((state_115).source).native, }), .valid = (state_115).valid, .work = (state_115).work, };
        }

        var state_owned_142: []const *const (zx_abi).zx_type_14 = (&[_]*const (zx_abi).zx_type_14{});

        errdefer (allocator).free(state_owned_142);

        if (state_capacity_started_121) {
            ((state_capacity_120).items).len = ((((state_115).source).indexed).members).len;

            state_owned_142 = (try (state_capacity_120).toOwnedSlice(allocator));
        }

        if (state_capacity_started_121) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_115).source).indexed).bytes, .declarations = (((state_115).source).indexed).declarations, .members = state_owned_142, .order = (((state_115).source).indexed).order, .types = (((state_115).source).indexed).types, }), .native = ((state_115).source).native, }), .valid = (state_115).valid, .work = (state_115).work, };
        }

        var state_owned_143: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_143);

        if (state_capacity_started_123) {
            ((state_capacity_122).items).len = (((((state_115).source).indexed).order).fields).len;

            state_owned_143 = (try (state_capacity_122).toOwnedSlice(allocator));
        }

        if (state_capacity_started_123) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_115).source).indexed).bytes, .declarations = (((state_115).source).indexed).declarations, .members = (((state_115).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = state_owned_143, .heads = ((((state_115).source).indexed).order).heads, .items = ((((state_115).source).indexed).order).items, }), .types = (((state_115).source).indexed).types, }), .native = ((state_115).source).native, }), .valid = (state_115).valid, .work = (state_115).work, };
        }

        var state_owned_144: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_144);

        if (state_capacity_started_125) {
            ((state_capacity_124).items).len = (((((state_115).source).indexed).order).heads).len;

            state_owned_144 = (try (state_capacity_124).toOwnedSlice(allocator));
        }

        if (state_capacity_started_125) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_115).source).indexed).bytes, .declarations = (((state_115).source).indexed).declarations, .members = (((state_115).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_115).source).indexed).order).fields, .heads = state_owned_144, .items = ((((state_115).source).indexed).order).items, }), .types = (((state_115).source).indexed).types, }), .native = ((state_115).source).native, }), .valid = (state_115).valid, .work = (state_115).work, };
        }

        var state_owned_145: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_145);

        if (state_capacity_started_127) {
            ((state_capacity_126).items).len = (((((state_115).source).indexed).order).items).len;

            state_owned_145 = (try (state_capacity_126).toOwnedSlice(allocator));
        }

        if (state_capacity_started_127) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_115).source).indexed).bytes, .declarations = (((state_115).source).indexed).declarations, .members = (((state_115).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_115).source).indexed).order).fields, .heads = ((((state_115).source).indexed).order).heads, .items = state_owned_145, }), .types = (((state_115).source).indexed).types, }), .native = ((state_115).source).native, }), .valid = (state_115).valid, .work = (state_115).work, };
        }

        var state_owned_146: []const *const (zx_abi).zx_type_31 = (&[_]*const (zx_abi).zx_type_31{});

        errdefer (allocator).free(state_owned_146);

        if (state_capacity_started_129) {
            ((state_capacity_128).items).len = (((((state_115).source).indexed).types).fields).len;

            state_owned_146 = (try (state_capacity_128).toOwnedSlice(allocator));
        }

        if (state_capacity_started_129) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_115).source).indexed).bytes, .declarations = (((state_115).source).indexed).declarations, .members = (((state_115).source).indexed).members, .order = (((state_115).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = state_owned_146, .items = ((((state_115).source).indexed).types).items, .nodes = ((((state_115).source).indexed).types).nodes, }), }), .native = ((state_115).source).native, }), .valid = (state_115).valid, .work = (state_115).work, };
        }

        var state_owned_147: []const *const (zx_abi).zx_type_32 = (&[_]*const (zx_abi).zx_type_32{});

        errdefer (allocator).free(state_owned_147);

        if (state_capacity_started_131) {
            ((state_capacity_130).items).len = (((((state_115).source).indexed).types).items).len;

            state_owned_147 = (try (state_capacity_130).toOwnedSlice(allocator));
        }

        if (state_capacity_started_131) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_115).source).indexed).bytes, .declarations = (((state_115).source).indexed).declarations, .members = (((state_115).source).indexed).members, .order = (((state_115).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_115).source).indexed).types).fields, .items = state_owned_147, .nodes = ((((state_115).source).indexed).types).nodes, }), }), .native = ((state_115).source).native, }), .valid = (state_115).valid, .work = (state_115).work, };
        }

        var state_owned_148: []const *const (zx_abi).zx_type_30 = (&[_]*const (zx_abi).zx_type_30{});

        errdefer (allocator).free(state_owned_148);

        if (state_capacity_started_133) {
            ((state_capacity_132).items).len = (((((state_115).source).indexed).types).nodes).len;

            state_owned_148 = (try (state_capacity_132).toOwnedSlice(allocator));
        }

        if (state_capacity_started_133) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_115).source).indexed).bytes, .declarations = (((state_115).source).indexed).declarations, .members = (((state_115).source).indexed).members, .order = (((state_115).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_115).source).indexed).types).fields, .items = ((((state_115).source).indexed).types).items, .nodes = state_owned_148, }), }), .native = ((state_115).source).native, }), .valid = (state_115).valid, .work = (state_115).work, };
        }

        var state_owned_149: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_149);

        if (state_capacity_started_135) {
            ((state_capacity_134).items).len = (((state_115).work).aliases).len;

            state_owned_149 = (try (state_capacity_134).toOwnedSlice(allocator));
        }

        if (state_capacity_started_135) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = (state_115).source, .valid = (state_115).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_149, .enumerations = ((state_115).work).enumerations, .nodes = ((state_115).work).nodes, }), };
        }

        var state_owned_150: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_150);

        if (state_capacity_started_137) {
            ((state_capacity_136).items).len = (((state_115).work).enumerations).len;

            state_owned_150 = (try (state_capacity_136).toOwnedSlice(allocator));
        }

        if (state_capacity_started_137) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = (state_115).source, .valid = (state_115).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_115).work).aliases, .enumerations = state_owned_150, .nodes = ((state_115).work).nodes, }), };
        }

        var state_owned_151: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_151);

        if (state_capacity_started_139) {
            ((state_capacity_138).items).len = (((state_115).work).nodes).len;

            state_owned_151 = (try (state_capacity_138).toOwnedSlice(allocator));
        }

        if (state_capacity_started_139) {
            state_115 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_115).names, .source = (state_115).source, .valid = (state_115).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_115).work).aliases, .enumerations = ((state_115).work).enumerations, .nodes = state_owned_151, }), };
        }

        break :block_153 (if (state_changed_117) state_115 else operand_116);
    };

    return block_114: {
        const operand_112 = (value_4).names;
        const operand_113 = (value_4).valid;

        break :block_114 @as((zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = operand_112, .valid = operand_113, });
    };
}

fn function_20_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_80, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(?[]const u8),
        started: *bool,
    },
}) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_81 {
    @setRuntimeSafety(true);

    const value_4: *const (zx_abi).zx_type_80 = block_214: {
        const operand_161 = in;

        var state_capacity_163: (std).ArrayList(*const (zx_abi).zx_type_44) = .empty;

        var state_capacity_started_164 = false;

        defer (state_capacity_163).deinit(allocator);

        var state_capacity_165: (std).ArrayList(*const (zx_abi).zx_type_14) = .empty;

        var state_capacity_started_166 = false;

        defer (state_capacity_165).deinit(allocator);

        var state_capacity_167: (std).ArrayList(u64) = .empty;

        var state_capacity_started_168 = false;

        defer (state_capacity_167).deinit(allocator);

        var state_capacity_169: (std).ArrayList(u64) = .empty;

        var state_capacity_started_170 = false;

        defer (state_capacity_169).deinit(allocator);

        var state_capacity_171: (std).ArrayList(u64) = .empty;

        var state_capacity_started_172 = false;

        defer (state_capacity_171).deinit(allocator);

        var state_capacity_173: (std).ArrayList(*const (zx_abi).zx_type_31) = .empty;

        var state_capacity_started_174 = false;

        defer (state_capacity_173).deinit(allocator);

        var state_capacity_175: (std).ArrayList(*const (zx_abi).zx_type_32) = .empty;

        var state_capacity_started_176 = false;

        defer (state_capacity_175).deinit(allocator);

        var state_capacity_177: (std).ArrayList(*const (zx_abi).zx_type_30) = .empty;

        var state_capacity_started_178 = false;

        defer (state_capacity_177).deinit(allocator);

        var state_capacity_179: (std).ArrayList(?[]const u8) = .empty;

        var state_capacity_started_180 = false;

        defer (state_capacity_179).deinit(allocator);

        var state_capacity_181: (std).ArrayList(bool) = .empty;

        var state_capacity_started_182 = false;

        defer (state_capacity_181).deinit(allocator);

        var state_capacity_183: (std).ArrayList(u64) = .empty;

        var state_capacity_started_184 = false;

        defer (state_capacity_183).deinit(allocator);

        var state_160: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (operand_161).names, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((operand_161).source).indexed).bytes, .declarations = (((operand_161).source).indexed).declarations, .members = (((operand_161).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_161).source).indexed).order).fields, .heads = ((((operand_161).source).indexed).order).heads, .items = ((((operand_161).source).indexed).order).items, .zx_origin = (((operand_161).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_161).source).indexed).types).fields, .items = ((((operand_161).source).indexed).types).items, .nodes = ((((operand_161).source).indexed).types).nodes, .zx_origin = (((operand_161).source).indexed).types, }, .zx_origin = ((operand_161).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if ((((operand_161).source).native != null)) block_186: {
            break :block_186 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = (((operand_161).source).native.?).declarations, .enumerations = (((operand_161).source).native.?).enumerations, .fields = (((operand_161).source).native.?).fields, .items = (((operand_161).source).native.?).items, .members = (((operand_161).source).native.?).members, .nodes = (((operand_161).source).native.?).nodes, .zx_origin = ((operand_161).source).native.?, };
        } else null)), .zx_origin = (operand_161).source, }, .valid = (operand_161).valid, .work = (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((operand_161).work).aliases, .enumerations = ((operand_161).work).enumerations, .nodes = ((operand_161).work).nodes, .zx_origin = (operand_161).work, }, .zx_origin = operand_161, };

        var state_changed_162 = false;

        while (((state_160).valid and (@as(u64, (((state_160).work).nodes).len) != @as(u64, 0)))) {
            state_160 = @as((zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, block_185: {
                break :block_185 (try function_19_buffered(allocator, state_160, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_2 = .{ .buffer = (&state_capacity_163), .started = (&state_capacity_started_164), }, .lane_3 = .{ .buffer = (&state_capacity_165), .started = (&state_capacity_started_166), }, .lane_4 = .{ .buffer = (&state_capacity_167), .started = (&state_capacity_started_168), }, .lane_5 = .{ .buffer = (&state_capacity_169), .started = (&state_capacity_started_170), }, .lane_6 = .{ .buffer = (&state_capacity_171), .started = (&state_capacity_started_172), }, .lane_7 = .{ .buffer = (&state_capacity_173), .started = (&state_capacity_started_174), }, .lane_8 = .{ .buffer = (&state_capacity_175), .started = (&state_capacity_started_176), }, .lane_9 = .{ .buffer = (&state_capacity_177), .started = (&state_capacity_started_178), }, .lane_10 = .{ .buffer = (&state_capacity_179), .started = (&state_capacity_started_180), }, .lane_11 = .{ .buffer = (&state_capacity_181), .started = (&state_capacity_started_182), }, .lane_12 = .{ .buffer = (&state_capacity_183), .started = (&state_capacity_started_184), }, }));
            });

            state_changed_162 = true;
        }

        var state_owned_187: []const *const (zx_abi).zx_type_44 = (&[_]*const (zx_abi).zx_type_44{});

        errdefer (allocator).free(state_owned_187);

        if (state_capacity_started_164) {
            ((state_capacity_163).items).len = ((((state_160).source).indexed).declarations).len;

            state_owned_187 = (try (state_capacity_163).toOwnedSlice(allocator));
        }

        if (state_capacity_started_164) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_160).source).indexed).bytes, .declarations = state_owned_187, .members = (((state_160).source).indexed).members, .order = (((state_160).source).indexed).order, .types = (((state_160).source).indexed).types, }), .native = ((state_160).source).native, }), .valid = (state_160).valid, .work = (state_160).work, };
        }

        var state_owned_188: []const *const (zx_abi).zx_type_14 = (&[_]*const (zx_abi).zx_type_14{});

        errdefer (allocator).free(state_owned_188);

        if (state_capacity_started_166) {
            ((state_capacity_165).items).len = ((((state_160).source).indexed).members).len;

            state_owned_188 = (try (state_capacity_165).toOwnedSlice(allocator));
        }

        if (state_capacity_started_166) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_160).source).indexed).bytes, .declarations = (((state_160).source).indexed).declarations, .members = state_owned_188, .order = (((state_160).source).indexed).order, .types = (((state_160).source).indexed).types, }), .native = ((state_160).source).native, }), .valid = (state_160).valid, .work = (state_160).work, };
        }

        var state_owned_189: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_189);

        if (state_capacity_started_168) {
            ((state_capacity_167).items).len = (((((state_160).source).indexed).order).fields).len;

            state_owned_189 = (try (state_capacity_167).toOwnedSlice(allocator));
        }

        if (state_capacity_started_168) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_160).source).indexed).bytes, .declarations = (((state_160).source).indexed).declarations, .members = (((state_160).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = state_owned_189, .heads = ((((state_160).source).indexed).order).heads, .items = ((((state_160).source).indexed).order).items, }), .types = (((state_160).source).indexed).types, }), .native = ((state_160).source).native, }), .valid = (state_160).valid, .work = (state_160).work, };
        }

        var state_owned_190: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_190);

        if (state_capacity_started_170) {
            ((state_capacity_169).items).len = (((((state_160).source).indexed).order).heads).len;

            state_owned_190 = (try (state_capacity_169).toOwnedSlice(allocator));
        }

        if (state_capacity_started_170) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_160).source).indexed).bytes, .declarations = (((state_160).source).indexed).declarations, .members = (((state_160).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_160).source).indexed).order).fields, .heads = state_owned_190, .items = ((((state_160).source).indexed).order).items, }), .types = (((state_160).source).indexed).types, }), .native = ((state_160).source).native, }), .valid = (state_160).valid, .work = (state_160).work, };
        }

        var state_owned_191: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_191);

        if (state_capacity_started_172) {
            ((state_capacity_171).items).len = (((((state_160).source).indexed).order).items).len;

            state_owned_191 = (try (state_capacity_171).toOwnedSlice(allocator));
        }

        if (state_capacity_started_172) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_160).source).indexed).bytes, .declarations = (((state_160).source).indexed).declarations, .members = (((state_160).source).indexed).members, .order = @as((zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_160).source).indexed).order).fields, .heads = ((((state_160).source).indexed).order).heads, .items = state_owned_191, }), .types = (((state_160).source).indexed).types, }), .native = ((state_160).source).native, }), .valid = (state_160).valid, .work = (state_160).work, };
        }

        var state_owned_192: []const *const (zx_abi).zx_type_31 = (&[_]*const (zx_abi).zx_type_31{});

        errdefer (allocator).free(state_owned_192);

        if (state_capacity_started_174) {
            ((state_capacity_173).items).len = (((((state_160).source).indexed).types).fields).len;

            state_owned_192 = (try (state_capacity_173).toOwnedSlice(allocator));
        }

        if (state_capacity_started_174) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_160).source).indexed).bytes, .declarations = (((state_160).source).indexed).declarations, .members = (((state_160).source).indexed).members, .order = (((state_160).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = state_owned_192, .items = ((((state_160).source).indexed).types).items, .nodes = ((((state_160).source).indexed).types).nodes, }), }), .native = ((state_160).source).native, }), .valid = (state_160).valid, .work = (state_160).work, };
        }

        var state_owned_193: []const *const (zx_abi).zx_type_32 = (&[_]*const (zx_abi).zx_type_32{});

        errdefer (allocator).free(state_owned_193);

        if (state_capacity_started_176) {
            ((state_capacity_175).items).len = (((((state_160).source).indexed).types).items).len;

            state_owned_193 = (try (state_capacity_175).toOwnedSlice(allocator));
        }

        if (state_capacity_started_176) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_160).source).indexed).bytes, .declarations = (((state_160).source).indexed).declarations, .members = (((state_160).source).indexed).members, .order = (((state_160).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_160).source).indexed).types).fields, .items = state_owned_193, .nodes = ((((state_160).source).indexed).types).nodes, }), }), .native = ((state_160).source).native, }), .valid = (state_160).valid, .work = (state_160).work, };
        }

        var state_owned_194: []const *const (zx_abi).zx_type_30 = (&[_]*const (zx_abi).zx_type_30{});

        errdefer (allocator).free(state_owned_194);

        if (state_capacity_started_178) {
            ((state_capacity_177).items).len = (((((state_160).source).indexed).types).nodes).len;

            state_owned_194 = (try (state_capacity_177).toOwnedSlice(allocator));
        }

        if (state_capacity_started_178) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = @as((zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203, (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = @as((zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97, (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((state_160).source).indexed).bytes, .declarations = (((state_160).source).indexed).declarations, .members = (((state_160).source).indexed).members, .order = (((state_160).source).indexed).order, .types = @as((zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((state_160).source).indexed).types).fields, .items = ((((state_160).source).indexed).types).items, .nodes = state_owned_194, }), }), .native = ((state_160).source).native, }), .valid = (state_160).valid, .work = (state_160).work, };
        }

        var state_owned_195: []const ?[]const u8 = (&[_]?[]const u8{});

        errdefer (allocator).free(state_owned_195);

        if (state_capacity_started_180) {
            ((state_capacity_179).items).len = (((state_160).work).aliases).len;

            state_owned_195 = (try (state_capacity_179).toOwnedSlice(allocator));
        }

        if (state_capacity_started_180) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = (state_160).source, .valid = (state_160).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = state_owned_195, .enumerations = ((state_160).work).enumerations, .nodes = ((state_160).work).nodes, }), };
        }

        var state_owned_196: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_196);

        if (state_capacity_started_182) {
            ((state_capacity_181).items).len = (((state_160).work).enumerations).len;

            state_owned_196 = (try (state_capacity_181).toOwnedSlice(allocator));
        }

        if (state_capacity_started_182) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = (state_160).source, .valid = (state_160).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_160).work).aliases, .enumerations = state_owned_196, .nodes = ((state_160).work).nodes, }), };
        }

        var state_owned_197: []const u64 = (&[_]u64{});

        errdefer (allocator).free(state_owned_197);

        if (state_capacity_started_184) {
            ((state_capacity_183).items).len = (((state_160).work).nodes).len;

            state_owned_197 = (try (state_capacity_183).toOwnedSlice(allocator));
        }

        if (state_capacity_started_184) {
            state_160 = (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (state_160).names, .source = (state_160).source, .valid = (state_160).valid, .work = @as((zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((state_160).work).aliases, .enumerations = ((state_160).work).enumerations, .nodes = state_owned_197, }), };
        }

        break :block_214 (if (state_changed_162) block_213: {
            break :block_213 (if (((state_160).zx_origin != null)) (state_160).zx_origin.? else block_212: {
                const operand_211 = (try (allocator).create((zx_abi).zx_type_80));

                (operand_211).* = (zx_abi).zx_type_80{ .names = (state_160).names, .source = (if ((((state_160).source).zx_origin != null)) ((state_160).source).zx_origin.? else block_208: {
                    const operand_207 = (try (allocator).create((zx_abi).zx_type_66));

                    (operand_207).* = (zx_abi).zx_type_66{ .indexed = (if (((((state_160).source).indexed).zx_origin != null)) (((state_160).source).indexed).zx_origin.? else block_203: {
                        const operand_202 = (try (allocator).create((zx_abi).zx_type_64));

                        (operand_202).* = (zx_abi).zx_type_64{ .bytes = (((state_160).source).indexed).bytes, .declarations = (((state_160).source).indexed).declarations, .members = (((state_160).source).indexed).members, .order = (if ((((((state_160).source).indexed).order).zx_origin != null)) ((((state_160).source).indexed).order).zx_origin.? else block_199: {
                            const operand_198 = (try (allocator).create((zx_abi).zx_type_34));

                            (operand_198).* = (zx_abi).zx_type_34{ .fields = ((((state_160).source).indexed).order).fields, .heads = ((((state_160).source).indexed).order).heads, .items = ((((state_160).source).indexed).order).items, };

                            break :block_199 @as(*const (zx_abi).zx_type_34, operand_198);
                        }), .types = (if ((((((state_160).source).indexed).types).zx_origin != null)) ((((state_160).source).indexed).types).zx_origin.? else block_201: {
                            const operand_200 = (try (allocator).create((zx_abi).zx_type_38));

                            (operand_200).* = (zx_abi).zx_type_38{ .fields = ((((state_160).source).indexed).types).fields, .items = ((((state_160).source).indexed).types).items, .nodes = ((((state_160).source).indexed).types).nodes, };

                            break :block_201 @as(*const (zx_abi).zx_type_38, operand_200);
                        }), };

                        break :block_203 @as(*const (zx_abi).zx_type_64, operand_202);
                    }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((state_160).source).native != null)) block_206: {
                        break :block_206 (if (((((state_160).source).native.?).zx_origin != null)) (((state_160).source).native.?).zx_origin.? else block_205: {
                            const operand_204 = (try (allocator).create((zx_abi).zx_type_62));

                            (operand_204).* = (zx_abi).zx_type_62{ .declarations = (((state_160).source).native.?).declarations, .enumerations = (((state_160).source).native.?).enumerations, .fields = (((state_160).source).native.?).fields, .items = (((state_160).source).native.?).items, .members = (((state_160).source).native.?).members, .nodes = (((state_160).source).native.?).nodes, };

                            break :block_205 @as(*const (zx_abi).zx_type_62, operand_204);
                        });
                    } else null)), };

                    break :block_208 @as(*const (zx_abi).zx_type_66, operand_207);
                }), .valid = (state_160).valid, .work = (if ((((state_160).work).zx_origin != null)) ((state_160).work).zx_origin.? else block_210: {
                    const operand_209 = (try (allocator).create((zx_abi).zx_type_79));

                    (operand_209).* = (zx_abi).zx_type_79{ .aliases = ((state_160).work).aliases, .enumerations = ((state_160).work).enumerations, .nodes = ((state_160).work).nodes, };

                    break :block_210 @as(*const (zx_abi).zx_type_79, operand_209);
                }), };

                break :block_212 @as(*const (zx_abi).zx_type_80, operand_211);
            });
        } else operand_161);
    };

    return block_159: {
        const operand_155 = (value_4).names;
        const operand_156 = (value_4).valid;

        break :block_159 block_158: {
            const operand_157 = (try (allocator).create((zx_abi).zx_type_81));

            (operand_157).* = @as((zx_abi).zx_type_81, (zx_abi).zx_type_81{ .names = operand_155, .valid = operand_156, });

            break :block_158 @as(*const (zx_abi).zx_type_81, operand_157);
        };
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_75) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_81 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: *const (zx_abi).zx_type_80 = block_25: {
        const operand_7 = in;
        const operand_9 = (try function_7_value(allocator, (zx_abi).value_zx_type_75_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0{ .count = (operand_7).count, .first = (operand_7).first, .parameters = (operand_7).parameters, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((operand_7).source).indexed).bytes, .declarations = (((operand_7).source).indexed).declarations, .members = (((operand_7).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_7).source).indexed).order).fields, .heads = ((((operand_7).source).indexed).order).heads, .items = ((((operand_7).source).indexed).order).items, .zx_origin = (((operand_7).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_7).source).indexed).types).fields, .items = ((((operand_7).source).indexed).types).items, .nodes = ((((operand_7).source).indexed).types).nodes, .zx_origin = (((operand_7).source).indexed).types, }, .zx_origin = ((operand_7).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if ((((operand_7).source).native != null)) block_8: {
            break :block_8 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = (((operand_7).source).native.?).declarations, .enumerations = (((operand_7).source).native.?).enumerations, .fields = (((operand_7).source).native.?).fields, .items = (((operand_7).source).native.?).items, .members = (((operand_7).source).native.?).members, .nodes = (((operand_7).source).native.?).nodes, .zx_origin = ((operand_7).source).native.?, };
        } else null)), .zx_origin = (operand_7).source, }, .zx_origin = operand_7, }));

        break :block_25 (if (((operand_9).zx_origin != null)) (operand_9).zx_origin.? else block_24: {
            const operand_23 = (try (allocator).create((zx_abi).zx_type_80));

            (operand_23).* = (zx_abi).zx_type_80{ .names = (operand_9).names, .source = (if ((((operand_9).source).zx_origin != null)) ((operand_9).source).zx_origin.? else block_20: {
                const operand_19 = (try (allocator).create((zx_abi).zx_type_66));

                (operand_19).* = (zx_abi).zx_type_66{ .indexed = (if (((((operand_9).source).indexed).zx_origin != null)) (((operand_9).source).indexed).zx_origin.? else block_15: {
                    const operand_14 = (try (allocator).create((zx_abi).zx_type_64));

                    (operand_14).* = (zx_abi).zx_type_64{ .bytes = (((operand_9).source).indexed).bytes, .declarations = (((operand_9).source).indexed).declarations, .members = (((operand_9).source).indexed).members, .order = (if ((((((operand_9).source).indexed).order).zx_origin != null)) ((((operand_9).source).indexed).order).zx_origin.? else block_11: {
                        const operand_10 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_10).* = (zx_abi).zx_type_34{ .fields = ((((operand_9).source).indexed).order).fields, .heads = ((((operand_9).source).indexed).order).heads, .items = ((((operand_9).source).indexed).order).items, };

                        break :block_11 @as(*const (zx_abi).zx_type_34, operand_10);
                    }), .types = (if ((((((operand_9).source).indexed).types).zx_origin != null)) ((((operand_9).source).indexed).types).zx_origin.? else block_13: {
                        const operand_12 = (try (allocator).create((zx_abi).zx_type_38));

                        (operand_12).* = (zx_abi).zx_type_38{ .fields = ((((operand_9).source).indexed).types).fields, .items = ((((operand_9).source).indexed).types).items, .nodes = ((((operand_9).source).indexed).types).nodes, };

                        break :block_13 @as(*const (zx_abi).zx_type_38, operand_12);
                    }), };

                    break :block_15 @as(*const (zx_abi).zx_type_64, operand_14);
                }), .native = @as(?*const (zx_abi).zx_type_62, (if ((((operand_9).source).native != null)) block_18: {
                    break :block_18 (if (((((operand_9).source).native.?).zx_origin != null)) (((operand_9).source).native.?).zx_origin.? else block_17: {
                        const operand_16 = (try (allocator).create((zx_abi).zx_type_62));

                        (operand_16).* = (zx_abi).zx_type_62{ .declarations = (((operand_9).source).native.?).declarations, .enumerations = (((operand_9).source).native.?).enumerations, .fields = (((operand_9).source).native.?).fields, .items = (((operand_9).source).native.?).items, .members = (((operand_9).source).native.?).members, .nodes = (((operand_9).source).native.?).nodes, };

                        break :block_17 @as(*const (zx_abi).zx_type_62, operand_16);
                    });
                } else null)), };

                break :block_20 @as(*const (zx_abi).zx_type_66, operand_19);
            }), .valid = (operand_9).valid, .work = (if ((((operand_9).work).zx_origin != null)) ((operand_9).work).zx_origin.? else block_22: {
                const operand_21 = (try (allocator).create((zx_abi).zx_type_79));

                (operand_21).* = (zx_abi).zx_type_79{ .aliases = ((operand_9).work).aliases, .enumerations = ((operand_9).work).enumerations, .nodes = ((operand_9).work).nodes, };

                break :block_22 @as(*const (zx_abi).zx_type_79, operand_21);
            }), };

            break :block_24 @as(*const (zx_abi).zx_type_80, operand_23);
        });
    };
    const value_2: *const (zx_abi).zx_type_81 = block_6: {
        const operand_1 = value_1;
        const operand_3 = (try function_20_value(allocator, (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654{ .names = (operand_1).names, .source = (zx_abi).value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203{ .indexed = (zx_abi).value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97{ .bytes = (((operand_1).source).indexed).bytes, .declarations = (((operand_1).source).indexed).declarations, .members = (((operand_1).source).indexed).members, .order = (zx_abi).value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_1).source).indexed).order).fields, .heads = ((((operand_1).source).indexed).order).heads, .items = ((((operand_1).source).indexed).order).items, .zx_origin = (((operand_1).source).indexed).order, }, .types = (zx_abi).value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .fields = ((((operand_1).source).indexed).types).fields, .items = ((((operand_1).source).indexed).types).items, .nodes = ((((operand_1).source).indexed).types).nodes, .zx_origin = (((operand_1).source).indexed).types, }, .zx_origin = ((operand_1).source).indexed, }, .native = @as(?(zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (if ((((operand_1).source).native != null)) block_2: {
            break :block_2 (zx_abi).value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .declarations = (((operand_1).source).native.?).declarations, .enumerations = (((operand_1).source).native.?).enumerations, .fields = (((operand_1).source).native.?).fields, .items = (((operand_1).source).native.?).items, .members = (((operand_1).source).native.?).members, .nodes = (((operand_1).source).native.?).nodes, .zx_origin = ((operand_1).source).native.?, };
        } else null)), .zx_origin = (operand_1).source, }, .valid = (operand_1).valid, .work = (zx_abi).value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .aliases = ((operand_1).work).aliases, .enumerations = ((operand_1).work).enumerations, .nodes = ((operand_1).work).nodes, .zx_origin = (operand_1).work, }, .zx_origin = operand_1, }));

        break :block_6 (if (((operand_3).zx_origin != null)) (operand_3).zx_origin.? else block_5: {
            const operand_4 = (try (allocator).create((zx_abi).zx_type_81));

            (operand_4).* = (zx_abi).zx_type_81{ .names = (operand_3).names, .valid = (operand_3).valid, };

            break :block_5 @as(*const (zx_abi).zx_type_81, operand_4);
        });
    };

    return value_2;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_75_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 = block_27: {
        break :block_27 (try function_7_value(allocator, in));
    };
    const value_2: (zx_abi).value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_26: {
        break :block_26 (try function_20_value(allocator, value_1));
    };

    return value_2;
}

