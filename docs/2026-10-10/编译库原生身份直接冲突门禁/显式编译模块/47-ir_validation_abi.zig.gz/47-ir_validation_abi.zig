pub const zx_type_11 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_12 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_13 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_14 = enum { Negate, Not, };

pub const zx_type_15 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_28 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_15,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_12,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_11,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_13,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_14,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_29 = enum { Copy, Borrowed, Owned, };

pub const zx_type_31 = struct {
    names: []const []const u8,
    ownership: []const zx_type_29,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_32 = enum { Requires, Ensures, };

pub const zx_type_36 = struct {
    expressions: []const *const zx_type_28,
    kinds: []const zx_type_32,
    predicates: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    symbols: []const *const zx_type_31,
};

pub const zx_type_37 = enum { Evaluate, Constant, Parallel, Destructure, Branch, Switch, StoreSet, Result, };

pub const zx_type_39 = struct {
    block_count: []const u32,
    block_first: []const u32,
    branch_conditions: []const u32,
    branch_no: []const u32,
    branch_yes: []const u32,
    case_bodies: []const u32,
    case_values: []const ?u32,
    constant_symbols: []const u32,
    constant_values: []const u32,
    destructure_count: []const u32,
    destructure_first: []const u32,
    destructure_symbols: []const ?u32,
    destructure_values: []const u32,
    evaluations: []const u32,
    parallel_count: []const u32,
    parallel_first: []const u32,
    parallel_symbols: []const ?u32,
    parallel_values: []const u32,
    results: []const ?u32,
    selection_count: []const u32,
    selection_exhaustive: []const bool,
    selection_first: []const u32,
    selection_subjects: []const u32,
    setter_slots: []const u32,
    setter_values: []const u32,
    statement_kinds: []const zx_type_37,
    statement_payloads: []const u32,
};

pub const zx_type_47 = struct {
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_29,
};

pub const zx_type_48 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_49 = enum { transaction, orchestration, };

pub const zx_type_54 = struct {
    contracts: []const *const zx_type_36,
    control: []const *const zx_type_39,
    expressions: []const *const zx_type_28,
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_29,
    roots: []const ?u32,
    store_modes: []const zx_type_49,
    stores: []const *const zx_type_48,
    symbols: []const *const zx_type_31,
};

pub const zx_type_55 = struct {
    control: *const zx_type_39,
    expressions: *const zx_type_28,
    root: ?u32,
    stores: *const zx_type_48,
    symbols: *const zx_type_31,
};

pub const zx_type_56 = struct {
    expressions: *const zx_type_28,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_31,
};

pub const zx_type_58 = struct {
    identities: []const ?[]const u8,
    import_names: []const []const u8,
    specifiers: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    type_namespaces: []const []const []const u8,
};

pub const zx_type_59 = struct {
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    output_types: []const u32,
};

pub const zx_type_60 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_62 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_63 = struct {
    base: *const zx_type_62,
    delta: *const zx_type_62,
};

pub const zx_type_64 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_65 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_60,
    label: []const u8,
    second: u32,
};

pub const zx_type_66 = struct {
    functions: *const zx_type_54,
    max_offset: u64,
    maximum_count: u64,
    modules: *const zx_type_58,
    scalar_count: u64,
    table: *const zx_type_62,
};

pub const zx_type_67 = struct {
    body: *const zx_type_55,
    contracts: *const zx_type_36,
    input_type: u32,
    output_ownership: zx_type_29,
    output_type: u32,
    transaction: bool,
    type_only: bool,
};

pub const zx_type_68 = struct {
    context: *const zx_type_66,
    expected_version: u64,
    export_names: []const []const u8,
    export_types: []const u32,
    unit: *const zx_type_67,
    version: u64,
};

pub const zx_type_69 = struct {
    maximum_count: u64,
    scalar_count: u64,
    table: *const zx_type_62,
};

pub const zx_type_70 = enum { Value, Callable, TypeDecl, };

pub const zx_type_71 = struct {
    kind: zx_type_70,
    name: []const u8,
};

pub const zx_type_72 = struct {
    left: []const u8,
    right: []const u8,
};

pub const zx_type_73 = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    table: *const zx_type_62,
};

pub const zx_type_74 = struct {
    count: u64,
    errors: bool,
    first: u64,
    values: []const []const u8,
};

pub const zx_type_75 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_62,
};

pub const zx_type_76 = struct {
    scalar_count: u64,
    table: *const zx_type_62,
};

pub const zx_type_77 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
};

pub const zx_type_78 = struct {
    max_offset: u64,
    symbols: *const zx_type_31,
};

pub const zx_type_79 = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_28,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
};

pub const zx_type_80 = struct {
    kind: zx_type_11,
    payload: u64,
    state: *const zx_type_79,
};

pub const zx_type_81 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
};

pub const zx_type_82 = struct {
    max_offset: u64,
    table: *const zx_type_28,
};

pub const zx_type_83 = struct {
    block: u64,
    control: *const zx_type_39,
};

pub const zx_type_84 = struct {
    control: *const zx_type_39,
    root: ?u32,
};

pub const zx_type_85 = struct {
    count: u64,
    values: []const ?u32,
};

pub const zx_type_86 = struct {
    count: u64,
    values: []const u32,
};

pub const zx_type_87 = struct {
    contracts: *const zx_type_36,
    max_offset: u64,
};

pub const zx_type_88 = struct {
    functions: *const zx_type_54,
    index: u64,
};

pub const zx_type_89 = enum { File, Package, Zig, C, Standard, LegacyLibrary, Invalid, };

pub const zx_type_90 = struct {
    index: u64,
    modules: *const zx_type_58,
};

pub const zx_type_91 = struct {
    modules: *const zx_type_58,
    table: *const zx_type_62,
};

pub const zx_type_92 = struct {
    functions: *const zx_type_59,
    index: u64,
    modules: *const zx_type_58,
};

pub const zx_type_93 = struct {
    context: *const zx_type_91,
    type_id: u64,
};

pub const zx_type_94 = struct {
    id: u32,
    tables: *const zx_type_63,
};

pub const zx_type_95 = struct {
    children: []const u32,
    fields: *const zx_type_64,
    first: u32,
    kind: zx_type_60,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_96 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_97 = struct {
    delta: *const zx_type_62,
    id: u32,
};

pub const zx_type_98 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: *const zx_type_63,
};

pub const zx_type_99 = struct {
    id: u32,
    native_references: bool,
    tables: *const zx_type_63,
};

pub const zx_type_100 = struct {
    id: u32,
    native_references: bool,
    table: *const zx_type_62,
};

pub const zx_type_101 = struct {
    index: u64,
    paths: []const []const u8,
};

pub const zx_type_102 = struct {
    paths: []const []const u8,
    slot_types: []const u32,
    table: *const zx_type_62,
    type_only: bool,
};

pub const zx_type_103 = struct {
    context: *const zx_type_66,
    unit: *const zx_type_67,
};

pub const zx_type_104 = struct {
    expressions: *const zx_type_28,
    id: u32,
    index: u64,
    type_id: u32,
};

pub const zx_type_105 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_48,
};

pub const zx_type_106 = struct {
    expressions: *const zx_type_28,
    functions: *const zx_type_105,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_48,
    symbols: *const zx_type_31,
    table: *const zx_type_62,
};

pub const zx_type_107 = struct {
    context: *const zx_type_106,
    kind: zx_type_11,
    payload: u64,
    target: zx_type_60,
    type_id: u32,
};

pub const zx_type_108 = enum { Other, Integer, Signed, Float, };

pub const zx_type_111 = struct {
    available: *const zx_type_48,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_48,
    slots: []const u32,
};

pub const zx_type_112 = struct {
    table: *const zx_type_62,
    type_id: u32,
};

pub const zx_type_113 = struct {
    contracts: *const zx_type_36,
    input_type: u32,
    max_offset: u64,
    output_type: u32,
    table: *const zx_type_62,
};

pub const zx_type_114 = struct {
    index: u64,
    program: *const zx_type_113,
};

pub const zx_type_115 = struct {
    control: *const zx_type_39,
    returns: []const bool,
    selection: u64,
};

pub const zx_type_116 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_28,
    limit: u64,
};

pub const zx_type_117 = struct {
    expressions: []const *const zx_type_28,
    native_concurrent: []const bool,
    native_modules: []const ?u32,
    stores: []const *const zx_type_48,
};

pub const zx_type_118 = struct {
    concurrent: bool,
    functions: *const zx_type_117,
};

pub const zx_type_119 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
};

pub const zx_type_120 = struct {
    captures: u64,
    nonnull: u64,
};

pub const zx_type_121 = struct {
    conditions: []const u64,
    facts: *const zx_type_119,
    truths: []const bool,
};

pub const zx_type_122 = enum { Block, BlockNext, Expression, Declare, ScopeDeclare, Destructure, Branch, BranchPost, Switch, Restore, RestoreFacts, Assume, IterationCondition, IterationBody, Transform, Invalid, };

pub const zx_type_123 = struct {
    a: u64,
    b: u64,
    c: u64,
    phase: zx_type_122,
};

pub const zx_type_124 = struct {
    body: *const zx_type_55,
    functions: *const zx_type_117,
    output_type: u32,
    table: *const zx_type_62,
    transaction: bool,
};

pub const zx_type_125 = struct {
    concurrent: []const bool,
    pure: []const bool,
    returns: []const bool,
};

pub const zx_type_126 = struct {
    prepared: *const zx_type_125,
    program: *const zx_type_124,
};

pub const zx_type_127 = struct {
    active: []const bool,
    changed_symbols: []const u64,
    changed_values: []const bool,
    declared: []const bool,
    owners: []const u64,
};

pub const zx_type_129 = struct {
    a: []const u64,
    b: []const u64,
    c: []const u64,
    phases: []const zx_type_122,
};

pub const zx_type_130 = struct {
    activity: *const zx_type_127,
    frames: *const zx_type_129,
    refinement: *const zx_type_121,
};

pub const zx_type_131 = struct {
    context: *const zx_type_126,
    frame: *const zx_type_123,
    state: *const zx_type_130,
};

pub const zx_type_132 = enum { Ordinary, Scope, Callback, };

pub const zx_type_133 = struct {
    state: *const zx_type_130,
    valid: bool,
};

pub const zx_type_134 = struct {
    facts: *const zx_type_119,
    symbol: u32,
};

pub const zx_type_135 = struct {
    expressions: *const zx_type_28,
    facts: *const zx_type_119,
    payload: u64,
    truth: bool,
};

pub const zx_type_136 = struct {
    condition: u64,
    expressions: *const zx_type_28,
    state: *const zx_type_121,
    truth: bool,
};

pub const zx_type_137 = struct {
    facts: *const zx_type_119,
    mark: *const zx_type_120,
};

pub const zx_type_138 = struct {
    activity: *const zx_type_127,
    mark: u64,
};

pub const zx_type_139 = struct {
    context: *const zx_type_126,
    statement: u64,
};

pub const zx_type_140 = struct {
    frame: *const zx_type_123,
    state: *const zx_type_130,
};

pub const zx_type_141 = struct {
    activity: *const zx_type_127,
    symbol: u64,
    value: bool,
};

pub const zx_type_142 = struct {
    mode: zx_type_132,
    owner: u64,
    program: *const zx_type_124,
    state: *const zx_type_130,
    symbol: u64,
    type_id: u32,
};

pub const zx_type_143 = struct {
    err: u32,
    facts: *const zx_type_119,
    result: u32,
};

pub const zx_type_144 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_28,
    facts: *const zx_type_119,
    result: ?u32,
    value: u64,
};

pub const zx_type_145 = struct {
    count: u64,
    depth: u64,
    first: u64,
    flags: u64,
    state: *const zx_type_130,
    values: []const u32,
};

pub const zx_type_146 = struct {
    count: u64,
    expressions: *const zx_type_28,
    facts: *const zx_type_119,
    first: u64,
};

pub const zx_type_147 = struct {
    active: []const bool,
    count: u64,
    first: u64,
    symbols: []const u32,
};

pub const zx_type_148 = struct {
    payload: u64,
    position: u64,
    program: *const zx_type_124,
};

pub const zx_type_150 = struct {
    expressions: *const zx_type_28,
    left: u64,
    right: u64,
};

pub const zx_type_151 = struct {
    payload: u64,
    program: *const zx_type_124,
};

pub const zx_type_152 = struct {
    context: *const zx_type_126,
    state: *const zx_type_130,
};

pub const zx_type_153 = struct {
    body: *const zx_type_55,
    input_type: u32,
    output_type: u32,
    table: *const zx_type_62,
};

pub const zx_type_154 = struct {
    ownership: []const zx_type_29,
    stores: []const *const zx_type_48,
};

pub const zx_type_155 = struct {
    body: ?u32,
    control: *const zx_type_39,
    expressions: *const zx_type_28,
    functions: *const zx_type_154,
    symbols: *const zx_type_31,
    type_only: bool,
    types: *const zx_type_63,
};

pub const zx_type_156 = struct {
    id: u64,
    types: *const zx_type_63,
};

pub const zx_type_157 = struct {
    expression: u64,
    expressions: *const zx_type_28,
    index: u64,
};

pub const zx_type_158 = struct {
    expression: u64,
    found: bool,
};

pub const zx_type_159 = struct {
    expression: u64,
    expressions: *const zx_type_28,
    locals: []const bool,
};

pub const zx_type_160 = struct {
    expression: u64,
    program: *const zx_type_155,
};

pub const zx_type_161 = struct {
    count: []const u64,
    first: []const u64,
    symbols: []const u64,
};

pub const zx_type_162 = enum { Copy, Borrowed, Owned, Loaned, Moved, };

pub const zx_type_163 = enum { Assign, Borrow, Freeze, };

pub const zx_type_164 = struct {
    children: []const u64,
    field_indices: []const u64,
    parents: []const u64,
    references: []const bool,
    siblings: []const u64,
    types: []const u32,
};

pub const zx_type_166 = struct {
    id: u64,
    layout: *const zx_type_164,
    operation: zx_type_163,
    states: []const zx_type_162,
    value: zx_type_162,
};

pub const zx_type_167 = struct {
    count: []const u64,
    first: []const u64,
    positions: []const u64,
};

pub const zx_type_168 = struct {
    cached: *const zx_type_167,
    heads: []const u64,
    next: []const u64,
    tree: *const zx_type_164,
};

pub const zx_type_169 = struct {
    cached: *const zx_type_167,
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    tree: *const zx_type_164,
    values: []const u64,
};

pub const zx_type_170 = enum { Heads, Symbols, Expressions, Evaluation, };

pub const zx_type_171 = struct {
    program: *const zx_type_155,
    references: []const bool,
};

pub const zx_type_172 = struct {
    capacity: u64,
    field: u64,
    parent: u64,
};

pub const zx_type_173 = struct {
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_174 = struct {
    field: u64,
    parent: u64,
};

pub const zx_type_175 = struct {
    found: bool,
    slot: u64,
    value: u64,
};

pub const zx_type_176 = struct {
    index: *const zx_type_173,
    key: *const zx_type_174,
};

pub const zx_type_177 = struct {
    expressions: *const zx_type_28,
    id: u64,
};

pub const zx_type_178 = struct {
    index: u32,
    target: u64,
};

pub const zx_type_179 = enum { Expression, AncestorStart, Ancestor, Root, Path, Ensure, Grow, Clear, Rehash, };

pub const zx_type_180 = struct {
    active: bool,
    ancestor: u64,
    bindings: []const u64,
    cached: *const zx_type_167,
    capacity: u64,
    child_expression: u64,
    children: []const u64,
    cursor: u64,
    direct: bool,
    expression: u64,
    field_indices: []const u64,
    heads: []const u64,
    key_fields: []const u64,
    key_parents: []const u64,
    next: []const u64,
    parent: u64,
    parents: []const u64,
    path: []const u64,
    path_index: u64,
    phase: zx_type_179,
    place_types: []const u32,
    program: *const zx_type_155,
    record: u64,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_181 = struct {
    first: u64,
    slots: []const u64,
};

pub const zx_type_182 = struct {
    program: *const zx_type_155,
    references: []const bool,
    roots: *const zx_type_168,
};

pub const zx_type_183 = struct {
    children: []const u64,
    count: []const u64,
    first: []const u64,
    shells: []const zx_type_162,
    states: []const zx_type_162,
    types: []const u32,
};

pub const zx_type_184 = struct {
    fact: u64,
    forest: *const zx_type_183,
};

pub const zx_type_185 = struct {
    fact: u64,
    forest: *const zx_type_183,
    index: u64,
    reference: bool,
};

pub const zx_type_186 = struct {
    index: u64,
    type_id: u32,
    types: *const zx_type_63,
};

pub const zx_type_187 = struct {
    left: zx_type_162,
    right: zx_type_162,
};

pub const zx_type_188 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_183,
    shell: zx_type_162,
    type_id: u32,
};

pub const zx_type_189 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    forest: *const zx_type_183,
    shell: zx_type_162,
    type_id: u32,
};

pub const zx_type_190 = struct {
    fact: u64,
    forest: *const zx_type_183,
    index: u64,
    references: []const bool,
    type_id: u32,
    types: *const zx_type_63,
    value: u64,
};

pub const zx_type_191 = struct {
    facts: []const u64,
    forest: *const zx_type_183,
    states: []const zx_type_162,
};

pub const zx_type_192 = struct {
    fact: u64,
    id: u64,
    layout: *const zx_type_164,
    references: []const bool,
    storage: *const zx_type_191,
    types: *const zx_type_63,
};

pub const zx_type_193 = struct {
    capacity: u64,
    left: u64,
    right: u64,
};

pub const zx_type_194 = enum { Join, Read, Borrow, Freeze, ReleaseAllLoans, ReleaseNewLoans, };

pub const zx_type_195 = struct {
    left: []const u64,
    right: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_196 = struct {
    cache: *const zx_type_195,
    left: u64,
    right: u64,
};

pub const zx_type_197 = struct {
    cache: *const zx_type_195,
    left: u64,
    right: u64,
    value: u64,
};

pub const zx_type_198 = struct {
    count: u64,
    values: []const u64,
};

pub const zx_type_199 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: *const zx_type_183,
    references: []const bool,
    shell: zx_type_162,
    type_id: u32,
    types: *const zx_type_63,
};

pub const zx_type_200 = struct {
    action: zx_type_194,
    left: zx_type_162,
    right: zx_type_162,
};

pub const zx_type_201 = struct {
    action: zx_type_194,
    forest: *const zx_type_183,
    left: u64,
    references: []const bool,
    right: u64,
    types: *const zx_type_63,
};

pub const zx_type_202 = enum { States, Memo, Both, };

pub const zx_type_203 = enum { RestoreStates, MergeStates, ReleaseNewLoans, ReleaseAllLoans, RestoreMemo, };

pub const zx_type_204 = struct {
    facts: []const u64,
    memo: []const u64,
    memo_count: []const u64,
    memo_first: []const u64,
    state_count: []const u64,
    state_first: []const u64,
};

pub const zx_type_205 = struct {
    facts: []const u64,
    forest: *const zx_type_183,
    memo: []const u64,
    states: []const zx_type_162,
    trail: []const u64,
};

pub const zx_type_206 = struct {
    memory: *const zx_type_205,
    snapshots: *const zx_type_204,
};

pub const zx_type_207 = struct {
    fact: u64,
    id: u64,
    layout: *const zx_type_164,
    memory: *const zx_type_205,
    operation: zx_type_163,
    references: []const bool,
    types: *const zx_type_63,
};

pub const zx_type_208 = struct {
    layout: *const zx_type_169,
    program: *const zx_type_155,
    references: []const bool,
};

pub const zx_type_209 = enum { Block, Statement, Release, Value, Finish, Project, Captured, Copy, Borrowed, Constant, Result, Store, Destructure, Borrow, Aggregate, Sequence, SequenceResult, IndexTarget, IndexResult, BranchCondition, BranchYes, BranchNo, CallResult, BinaryLeft, BinaryRight, ConditionalCondition, ConditionalYes, ConditionalNo, UpdateResult, ScopeBinding, ScopeResult, ScopeFinish, TaskCapture, TaskFinish, ParallelBranch, ObjectEvaluation, ObjectCached, ObjectField, ObjectFieldResult, ObjectFinish, Invocation, InvocationResult, CollectionTarget, CollectionArgument, CollectionResult, CollectionFreeze, SwitchSubject, SwitchCase, SwitchResult, MatchSubject, MatchArm, MatchCondition, MatchResult, MatchFinish, IterationInitial, IterationRound, IterationAdvance, IterationCondition, IterationBody, IterationFinish, TransformTarget, TransformInitial, TransformParameter, TransformBody, TransformFinish, };

pub const zx_type_210 = struct {
    action: zx_type_209,
    index: u64,
    moving: bool,
    subject: u64,
};

pub const zx_type_212 = struct {
    actions: []const zx_type_209,
    indices: []const u64,
    moving: []const bool,
    subjects: []const u64,
};

pub const zx_type_213 = struct {
    complete: bool,
    expression: u64,
    failed: bool,
    output: zx_type_162,
    stores_owned: bool,
};

pub const zx_type_214 = struct {
    action: zx_type_203,
    frame: u64,
    layout: *const zx_type_164,
    memory: *const zx_type_205,
    references: []const bool,
    stack: *const zx_type_204,
    types: *const zx_type_63,
};

pub const zx_type_215 = struct {
    frame: u64,
    stack: *const zx_type_204,
};

pub const zx_type_216 = struct {
    capture: zx_type_202,
    memory: *const zx_type_205,
    stack: *const zx_type_204,
};

pub const zx_type_217 = struct {
    frame: *const zx_type_210,
    work: *const zx_type_212,
};

pub const zx_type_218 = struct {
    count: []const u64,
    first: []const u64,
};

pub const zx_type_219 = struct {
    boundaries: []const u64,
    count: []const u64,
    entries: []const u64,
    exits: []const u64,
    facts: []const u64,
    first: []const u64,
    heads: []const u64,
    outputs: []const u64,
    roots: []const u64,
    seen: []const bool,
};

pub const zx_type_220 = enum { Statements, Values, Callbacks, Branches, Calls, Collections, Objects, Scope, Tasks, Expression, Invalid, };

pub const zx_type_221 = struct {
    active: bool,
    builders: *const zx_type_218,
    complete: bool,
    domains: *const zx_type_161,
    expression: u64,
    failed: bool,
    layout: *const zx_type_169,
    loops: *const zx_type_219,
    memory: *const zx_type_205,
    program: *const zx_type_155,
    references: []const bool,
    returned: zx_type_162,
    returns: []const bool,
    snapshots: *const zx_type_204,
    stores_owned: bool,
    value: u64,
    values: []const u64,
    work: *const zx_type_212,
};

pub const zx_type_222 = struct {
    frame: u64,
    layout: *const zx_type_164,
    memory: *const zx_type_205,
    merge: bool,
    references: []const bool,
    stack: *const zx_type_204,
    types: *const zx_type_63,
};

pub const zx_type_223 = struct {
    index: u64,
    loops: *const zx_type_219,
    memory: *const zx_type_205,
    references: []const bool,
    types: *const zx_type_63,
    value: u64,
};

pub const zx_type_224 = struct {
    forest: *const zx_type_183,
    loops: *const zx_type_219,
};

pub const zx_type_225 = struct {
    condition: bool,
    expression: u64,
    index: u64,
    machine: *const zx_type_221,
    value: u64,
};

pub const zx_type_226 = struct {
    boundary: u64,
    memory: *const zx_type_205,
    snapshots: *const zx_type_204,
    work: *const zx_type_212,
};

pub const zx_type_227 = struct {
    changed: bool,
    forest: *const zx_type_183,
    loops: *const zx_type_219,
};

pub const zx_type_228 = struct {
    domains: *const zx_type_161,
    exiting: bool,
    expression: u64,
    index: u64,
    layout: *const zx_type_164,
    loops: *const zx_type_219,
    memory: *const zx_type_205,
    references: []const bool,
    snapshots: *const zx_type_204,
    types: *const zx_type_63,
};

pub const zx_type_229 = struct {
    domains: *const zx_type_161,
    entry: u64,
    expression: u64,
    layout: *const zx_type_164,
    loops: *const zx_type_219,
    memory: *const zx_type_205,
    program: *const zx_type_155,
    value: u64,
};

pub const zx_type_231 = enum { Next, Query, Descend, Expand, Enter, Done, };

pub const zx_type_232 = struct {
    active: bool,
    cursors: []const u64,
    expression: u64,
    expressions: *const zx_type_28,
    facts: []const u64,
    forest: *const zx_type_183,
    layout: *const zx_type_169,
    memo: []const u64,
    permanent: bool,
    phase: zx_type_231,
    position: u64,
    query: u64,
    references: []const bool,
    root: u64,
    states: []const zx_type_162,
    trail: []const u64,
    types: *const zx_type_63,
    work: []const u64,
};

pub const zx_type_233 = struct {
    expression: u64,
    expressions: *const zx_type_28,
    index: u64,
    permanent: bool,
};

pub const zx_type_234 = struct {
    expression: u64,
    expressions: *const zx_type_28,
    layout: *const zx_type_169,
    memory: *const zx_type_205,
    permanent: bool,
    references: []const bool,
    types: *const zx_type_63,
};

pub const zx_type_235 = struct {
    expression: u64,
    expressions: *const zx_type_28,
    layout: *const zx_type_169,
    memo: []const u64,
    trail: []const u64,
};

pub const zx_type_236 = struct {
    found: bool,
    position: u64,
    trail: []const u64,
};

pub const zx_type_237 = struct {
    current: zx_type_162,
    moving: bool,
    position: u64,
    symbols: *const zx_type_31,
    types: *const zx_type_63,
};

pub const zx_type_238 = struct {
    assign: bool,
    assigned: zx_type_162,
    failed: bool,
    value: zx_type_162,
};

pub const zx_type_239 = struct {
    builders: *const zx_type_218,
    count: u64,
    forest: *const zx_type_183,
};

pub const zx_type_240 = struct {
    builders: *const zx_type_218,
    forest: *const zx_type_183,
};

pub const zx_type_241 = enum { Operands, Containers, Control, };

pub const zx_type_242 = struct {
    container: bool,
    frame: *const zx_type_210,
    kind: zx_type_11,
    machine: *const zx_type_221,
    payload: u64,
};

pub const zx_type_243 = struct {
    builders: *const zx_type_218,
    forest: *const zx_type_183,
    type_id: u32,
};

pub const zx_type_244 = struct {
    builders: *const zx_type_218,
    fact: u64,
    forest: *const zx_type_183,
};

pub const zx_type_245 = struct {
    domains: *const zx_type_161,
    layout: *const zx_type_169,
    program: *const zx_type_155,
    references: []const bool,
    returns: []const bool,
    runtime: *const zx_type_206,
};

pub const zx_type_246 = struct {
    declared: zx_type_29,
    outcome: *const zx_type_213,
};

pub const zx_type_247 = struct {
    context: *const zx_type_66,
    index: u64,
};

pub const zx_type_248 = struct {
    functions: *const zx_type_59,
    index: u64,
};

pub const zx_type_249 = struct {
    fallible: bool,
    members: ?[]const []const u8,
};

pub const zx_type_250 = struct {
    modules: *const zx_type_58,
    name: []const u8,
    owner: []const u8,
};

pub const zx_type_251 = struct {
    functions: *const zx_type_59,
    left: u64,
    right: u64,
};

pub const zx_type_252 = struct {
    context: *const zx_type_92,
    name: []const u8,
    owner: []const u8,
};

pub const zx_type_253 = struct {
    binding_names: []const []const u8,
    binding_types: []const u32,
    depth: u64,
    names: []const ?[]const u8,
    table: *const zx_type_62,
    type_id: u32,
};

pub const zx_type_255 = struct {
    name: ?[]const u8,
    names: []const []const u8,
    required: bool,
    type_id: u32,
    types: []const u32,
};

pub const zx_type_256 = struct {
    contracts: []const *const zx_type_36,
    control: []const *const zx_type_39,
    expressions: []const *const zx_type_28,
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_fallible: []const bool,
    native_modules: []const ?u32,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_29,
    roots: []const ?u32,
    stores: []const *const zx_type_48,
};

pub const zx_type_257 = struct {
    count: u64,
    slots: []const u64,
};

pub const zx_type_258 = enum { Expression, Function, Block, };

pub const zx_type_259 = struct {
    count: u64,
    index: u64,
    operation: zx_type_258,
    source: u64,
};

pub const zx_type_260 = struct {
    control: *const zx_type_39,
    expressions: *const zx_type_28,
    returns: []const bool,
    visited: *const zx_type_257,
};

pub const zx_type_261 = struct {
    functions: *const zx_type_256,
    types: *const zx_type_63,
};

pub const zx_type_264 = struct {
    called: *const zx_type_257,
    context: *const zx_type_261,
    frames: []const *const zx_type_259,
    names: []const []const u8,
    sources: []const *const zx_type_260,
    unknown: bool,
};

pub const zx_type_265 = struct {
    context: *const zx_type_261,
    contracts: *const zx_type_36,
    control: *const zx_type_39,
    expression: u32,
    expressions: *const zx_type_28,
    program: bool,
    root: ?u32,
    stores: bool,
};

pub const zx_type_266 = struct {
    control: *const zx_type_39,
    expressions: *const zx_type_28,
    state: *const zx_type_264,
};

pub const zx_type_267 = struct {
    source: u64,
    state: *const zx_type_264,
};

pub const zx_type_268 = struct {
    contracts: *const zx_type_36,
    state: *const zx_type_264,
};

pub const zx_type_269 = struct {
    frame: *const zx_type_259,
    state: *const zx_type_264,
};

pub const zx_type_270 = struct {
    id: u32,
    seen: *const zx_type_257,
};

pub const zx_type_271 = struct {
    fresh: bool,
    seen: *const zx_type_257,
};

pub const zx_type_272 = struct {
    expressions: *const zx_type_28,
    index: u64,
};

pub const zx_type_273 = struct {
    names: []const []const u8,
    tables: *const zx_type_63,
    type_id: u32,
};

pub const zx_type_274 = struct {
    expressions: *const zx_type_28,
    index: u64,
    names: []const []const u8,
    tables: *const zx_type_63,
};

pub const zx_type_275 = struct {
    index: u64,
    state: *const zx_type_264,
};

pub const zx_type_276 = struct {
    body: *const zx_type_55,
    max_offset: u64,
};

pub const zx_type_277 = struct {
    max_offset: u64,
    unit: *const zx_type_67,
};

pub const zx_type_278 = struct {
    concurrent: bool,
    enabled: bool,
    functions: *const zx_type_117,
};

pub const zx_type_279 = struct {
    domains: *const zx_type_161,
    layout: *const zx_type_169,
    references: []const bool,
    returns: []const bool,
};

pub const zx_type_280 = struct {
    memory: *const zx_type_205,
    prepared: *const zx_type_279,
    snapshots: *const zx_type_204,
};

pub const zx_type_281 = struct {
    index: u64,
    table: *const zx_type_54,
    valid: bool,
};

pub const zx_type_282 = struct {
    child_end: u64,
    field_end: u64,
    index: u64,
    name_end: u64,
    scalar_count: u64,
    table: *const zx_type_62,
    valid: bool,
};

pub const zx_type_283 = struct {
    after_underscore: bool,
    index: u64,
    kind: zx_type_70,
    name: []const u8,
    valid: bool,
};

pub const zx_type_284 = struct {
    ascending: bool,
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
};

pub const zx_type_285 = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    owner: u64,
    table: *const zx_type_62,
    valid: bool,
    values: []const u32,
};

pub const zx_type_286 = struct {
    count: u64,
    errors: bool,
    first: u64,
    index: u64,
    valid: bool,
    values: []const []const u8,
};

pub const zx_type_287 = struct {
    count: u64,
    first: u64,
    index: u64,
    member: []const u8,
    unique: bool,
    values: []const []const u8,
};

pub const zx_type_288 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_62,
    valid: bool,
};

pub const zx_type_289 = struct { *const zx_type_69, };

pub const zx_type_290 = struct { *const zx_type_69, bool, };

pub const zx_type_291 = struct { *const zx_type_69, bool, bool, };

pub const zx_type_292 = struct {
    index: u64,
    input: *const zx_type_77,
    valid: bool,
};

pub const zx_type_293 = struct {
    index: u64,
    input: *const zx_type_81,
    next: u64,
    valid: bool,
};

pub const zx_type_294 = struct {
    block: u64,
    control: *const zx_type_39,
    end: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_295 = struct {
    block: u64,
    bodies: []const u32,
    end: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_296 = struct {
    branches: u64,
    constants: u64,
    control: *const zx_type_39,
    destructures: u64,
    evaluations: u64,
    index: u64,
    parallels: u64,
    results: u64,
    selections: u64,
    setters: u64,
    valid: bool,
};

pub const zx_type_297 = struct {
    block: u64,
    control: *const zx_type_39,
    valid: bool,
};

pub const zx_type_298 = struct {
    count: u64,
    depths: []const u64,
    owned: []const bool,
    root: u64,
};

pub const zx_type_299 = struct { []const bool, void, };

pub const zx_type_300 = struct { []const u64, void, };

pub const zx_type_301 = struct {
    block: u64,
    control: *const zx_type_39,
    depths: []const u64,
    edge: u64,
    index: u64,
    owned: []const bool,
    valid: bool,
};

pub const zx_type_302 = struct {
    index: u64,
    result: bool,
    source: []const bool,
};

pub const zx_type_303 = struct { *const zx_type_276, };

pub const zx_type_304 = struct { *const zx_type_276, bool, };

pub const zx_type_305 = struct { *const zx_type_276, bool, bool, };

pub const zx_type_306 = struct { *const zx_type_276, bool, bool, bool, };

pub const zx_type_307 = struct { *const zx_type_276, bool, bool, bool, bool, };

pub const zx_type_308 = struct { *const zx_type_276, bool, bool, bool, bool, bool, };

pub const zx_type_309 = struct {
    index: u64,
    input: *const zx_type_85,
    valid: bool,
};

pub const zx_type_310 = struct {
    index: u64,
    input: *const zx_type_86,
    valid: bool,
};

pub const zx_type_311 = struct {
    contracts: *const zx_type_36,
    index: u64,
    max_offset: u64,
    valid: bool,
};

pub const zx_type_312 = struct { *const zx_type_87, };

pub const zx_type_313 = struct { *const zx_type_87, bool, };

pub const zx_type_314 = struct { *const zx_type_277, };

pub const zx_type_315 = struct { *const zx_type_277, bool, };

pub const zx_type_316 = struct { *const zx_type_277, bool, bool, };

pub const zx_type_317 = struct {
    context: *const zx_type_66,
    index: u64,
    valid: bool,
};

pub const zx_type_318 = struct { *const zx_type_68, };

pub const zx_type_319 = struct { *const zx_type_68, bool, };

pub const zx_type_320 = struct { *const zx_type_68, bool, bool, };

pub const zx_type_321 = struct {
    index: u64,
    modules: *const zx_type_58,
    valid: bool,
};

pub const zx_type_322 = struct {
    offset: u64,
    separator: u64,
    source: []const u8,
    valid: bool,
};

pub const zx_type_323 = struct {
    offset: u64,
    source: []const u8,
    start: u64,
    valid: bool,
};

pub const zx_type_324 = struct {
    high: u8,
    index: u64,
    low: u8,
    remaining: u64,
    text: []const u8,
    valid: bool,
};

pub const zx_type_325 = struct {
    index: u64,
    names: []const []const u8,
    valid: bool,
};

pub const zx_type_326 = struct {
    count: u64,
    found: bool,
    index: u64,
    modules: *const zx_type_58,
    name: []const u8,
    owner: []const u8,
};

pub const zx_type_327 = struct { *const zx_type_58, };

pub const zx_type_328 = struct { *const zx_type_58, bool, };

pub const zx_type_329 = struct { *const zx_type_58, bool, bool, };

pub const zx_type_330 = struct { *const zx_type_58, bool, bool, bool, };

pub const zx_type_331 = struct {
    index: u64,
    modules: *const zx_type_58,
    type_count: u64,
    valid: bool,
};

pub const zx_type_332 = struct {
    ids: []const u32,
    index: u64,
    names: []const []const u8,
    type_count: u64,
    valid: bool,
};

pub const zx_type_333 = struct {
    count: u64,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_334 = struct {
    index: u64,
    module: u64,
    modules: *const zx_type_58,
    owner: []const u8,
    valid: bool,
};

pub const zx_type_335 = struct {
    count: u64,
    index: u64,
    modules: *const zx_type_58,
    name: []const u8,
    owner: []const u8,
    type_id: u32,
    valid: bool,
};

pub const zx_type_336 = struct {
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u32,
    valid: bool,
};

pub const zx_type_337 = struct { *const zx_type_91, };

pub const zx_type_338 = struct { *const zx_type_91, bool, };

pub const zx_type_339 = struct { *const zx_type_91, bool, bool, };

pub const zx_type_340 = struct { *const zx_type_91, bool, bool, bool, };

pub const zx_type_341 = struct {
    declared: bool,
    index: u64,
    modules: *const zx_type_58,
    name: []const u8,
    owner: ?[]const u8,
    type_id: u64,
    valid: bool,
};

pub const zx_type_342 = struct {
    declared: bool,
    found: bool,
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u64,
};

pub const zx_type_343 = struct {
    context: *const zx_type_91,
    index: u64,
    valid: bool,
};

pub const zx_type_344 = struct { *const zx_type_91, bool, bool, bool, bool, };

pub const zx_type_345 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
};

pub const zx_type_346 = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: *const zx_type_63,
    target: zx_type_60,
};

pub const zx_type_347 = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: *const zx_type_63,
};

pub const zx_type_348 = struct {
    index: u64,
    limit: u64,
    path: []const u8,
    paths: []const []const u8,
    repeated: bool,
};

pub const zx_type_349 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
};

pub const zx_type_350 = struct {
    index: u64,
    paths: []const []const u8,
    slot_types: []const u32,
    table: *const zx_type_62,
    valid: bool,
};

pub const zx_type_351 = struct { *const zx_type_102, };

pub const zx_type_352 = struct { *const zx_type_102, bool, };

pub const zx_type_353 = struct {
    available: *const zx_type_48,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_48,
    slots: []const u32,
    valid: bool,
};

pub const zx_type_354 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
};

pub const zx_type_355 = struct {
    condition_type: u32,
    context: *const zx_type_106,
    count: u64,
    first: u64,
    index: u64,
    result_type: u32,
    valid: bool,
};

pub const zx_type_356 = struct {
    context: *const zx_type_106,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_357 = struct {
    context: *const zx_type_106,
    count: u64,
    first: u64,
    index: u64,
    type_first: u64,
    valid: bool,
};

pub const zx_type_358 = struct {
    field: u64,
    first: u64,
    found: bool,
    index: u64,
    indices: []const u32,
    limit: u64,
};

pub const zx_type_359 = struct {
    context: *const zx_type_106,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_12,
    source: u32,
    valid: bool,
};

pub const zx_type_360 = struct {
    check: *const zx_type_107,
    count: u64,
    fields: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_361 = struct {
    field: ?u32,
    fields: []const ?u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    task: u32,
    tasks: []const u32,
};

pub const zx_type_362 = struct {
    check: *const zx_type_107,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_363 = struct {
    captures: []const u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    symbol: u32,
};

pub const zx_type_364 = struct {
    context: *const zx_type_106,
    context_type: u32,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_13,
    valid: bool,
};

pub const zx_type_365 = struct {
    expressions: *const zx_type_28,
    functions: *const zx_type_105,
    index: u64,
    stores: *const zx_type_48,
    symbols: *const zx_type_31,
    table: *const zx_type_62,
    valid: bool,
};

pub const zx_type_366 = struct {
    has_ensures: bool,
    index: u64,
    program: *const zx_type_113,
    valid: bool,
};

pub const zx_type_367 = struct { *const zx_type_113, };

pub const zx_type_368 = struct { *const zx_type_113, bool, };

pub const zx_type_369 = struct { *const zx_type_113, bool, bool, };

pub const zx_type_370 = struct {
    count: u64,
    index: u64,
    symbols: *const zx_type_31,
    valid: bool,
};

pub const zx_type_371 = struct {
    index: u64,
    request: *const zx_type_103,
    valid: bool,
};

pub const zx_type_372 = struct {
    all: bool,
    bodies: []const u32,
    end: u64,
    index: u64,
    returns: []const bool,
};

pub const zx_type_373 = struct {
    block: u64,
    control: *const zx_type_39,
    returns: []const bool,
};

pub const zx_type_374 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_28,
    index: u64,
    limit: u64,
    valid: bool,
};

pub const zx_type_375 = struct {
    index: u64,
    result: []const bool,
    source: []const ?u32,
};

pub const zx_type_376 = struct {
    concurrent: bool,
    functions: *const zx_type_117,
    index: u64,
    values: []const bool,
};

pub const zx_type_377 = struct { *const zx_type_278, };

pub const zx_type_378 = struct { *const zx_type_278, []const bool, };

pub const zx_type_379 = struct { *const zx_type_124, };

pub const zx_type_380 = struct { *const zx_type_124, []const bool, };

pub const zx_type_381 = struct { *const zx_type_124, []const bool, []const bool, };

pub const zx_type_382 = struct { *const zx_type_124, []const bool, []const bool, []const bool, };

pub const zx_type_383 = struct {
    index: u64,
    result: []const bool,
    source: []const []const u8,
};

pub const zx_type_384 = struct {
    index: u64,
    result: []const u64,
    source: []const []const u8,
};

pub const zx_type_385 = struct {
    found: bool,
    index: u64,
    symbol: u32,
    values: []const u32,
};

pub const zx_type_386 = struct { []const u32, void, };

pub const zx_type_387 = struct {
    facts: *const zx_type_119,
    index: u64,
    symbol: u32,
};

pub const zx_type_388 = struct {
    expressions: *const zx_type_28,
    state: *const zx_type_121,
};

pub const zx_type_389 = struct { []const u64, ?u64, };

pub const zx_type_390 = struct { []const bool, ?bool, };

pub const zx_type_391 = struct { []const u32, []const u32, };

pub const zx_type_392 = struct { []const zx_type_122, void, };

pub const zx_type_393 = struct {
    control: *const zx_type_39,
    first: u64,
    index: u64,
    state: *const zx_type_130,
};

pub const zx_type_394 = struct {
    context: *const zx_type_126,
    first: u64,
    index: u64,
    result: *const zx_type_133,
};

pub const zx_type_395 = struct {
    activity: *const zx_type_127,
    index: u64,
};

pub const zx_type_396 = struct {
    count: u64,
    first: u64,
    index: u64,
    owner: u64,
    program: *const zx_type_124,
    result: *const zx_type_133,
};

pub const zx_type_397 = struct {
    count: u64,
    first: u64,
    index: u64,
    program: *const zx_type_124,
    result: *const zx_type_133,
    type_first: u64,
};

pub const zx_type_398 = struct {
    depth: u64,
    first: u64,
    flags: u64,
    index: u64,
    state: *const zx_type_130,
    values: []const u32,
};

pub const zx_type_399 = struct {
    depth: u64,
    expressions: *const zx_type_28,
    first: u64,
    flags: u64,
    index: u64,
    state: *const zx_type_130,
};

pub const zx_type_400 = struct {
    count: u64,
    expressions: *const zx_type_28,
    facts: *const zx_type_119,
    first: u64,
    index: u64,
};

pub const zx_type_401 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_28,
    first: u64,
    index: u64,
    result: ?u32,
    symbol: u32,
};

pub const zx_type_402 = struct {
    depth: u64,
    expressions: *const zx_type_28,
    first: u64,
    flags: u64,
    index: u64,
    owner: u64,
    state: *const zx_type_130,
};

pub const zx_type_403 = struct {
    active: []const bool,
    count: u64,
    first: u64,
    index: u64,
    symbols: []const u32,
    valid: bool,
};

pub const zx_type_404 = struct {
    activity: *const zx_type_127,
    count: u64,
    expressions: *const zx_type_28,
    first: u64,
    index: u64,
};

pub const zx_type_405 = struct {
    control: *const zx_type_39,
    count: u64,
    expressions: *const zx_type_28,
    first: u64,
    index: u64,
    no: bool,
    valid: bool,
    yes: bool,
};

pub const zx_type_406 = struct {
    count: u64,
    first: u64,
    has_default: bool,
    index: u64,
    program: *const zx_type_124,
    type_id: u32,
    valid: bool,
};

pub const zx_type_407 = struct {
    count: u64,
    first: u64,
    found: bool,
    index: u64,
    program: *const zx_type_124,
    value: u64,
};

pub const zx_type_408 = struct {
    captures: u64,
    depth: u64,
    facts: u64,
    first: u64,
    index: u64,
    payload: u64,
    program: *const zx_type_124,
    state: *const zx_type_130,
};

pub const zx_type_410 = struct { []const zx_type_122, ?zx_type_122, };

pub const zx_type_411 = struct {
    context: *const zx_type_126,
    result: *const zx_type_133,
};

pub const zx_type_412 = struct { *const zx_type_126, };

pub const zx_type_413 = struct { *const zx_type_126, *const zx_type_133, };

pub const zx_type_414 = struct { *const zx_type_126, *const zx_type_133, *const zx_type_133, };

pub const zx_type_415 = struct { *const zx_type_126, *const zx_type_133, *const zx_type_133, bool, };

pub const zx_type_416 = struct { *const zx_type_126, *const zx_type_133, *const zx_type_133, bool, bool, };

pub const zx_type_417 = struct { *const zx_type_124, *const zx_type_125, };

pub const zx_type_418 = struct { *const zx_type_124, *const zx_type_125, bool, };

pub const zx_type_419 = struct {
    capture: u64,
    expressions: *const zx_type_28,
    index: u64,
    symbols: *const zx_type_31,
    table: *const zx_type_62,
    valid: bool,
};

pub const zx_type_420 = struct {
    index: u64,
    result: []const u64,
    source: []const zx_type_11,
};

pub const zx_type_421 = struct {
    binding: u64,
    constants: []const u32,
    edge: u64,
    expressions: *const zx_type_28,
    index: u64,
    table: *const zx_type_62,
    uses: []const u64,
    valid: bool,
};

pub const zx_type_422 = struct {
    expressions: *const zx_type_28,
    index: u64,
    table: *const zx_type_62,
    uses: []const u64,
    valid: bool,
};

pub const zx_type_423 = struct { *const zx_type_153, };

pub const zx_type_424 = struct { *const zx_type_153, bool, };

pub const zx_type_425 = struct { *const zx_type_153, bool, bool, };

pub const zx_type_426 = struct { *const zx_type_153, bool, bool, bool, };

pub const zx_type_427 = struct {
    target: *const zx_type_65,
    types: *const zx_type_63,
};

pub const zx_type_428 = struct {
    index: u64,
    references: []const bool,
    types: *const zx_type_63,
};

pub const zx_type_429 = struct {
    count: u64,
    expressions: *const zx_type_28,
    index: u64,
    kind: zx_type_11,
    locals: []const bool,
    payload: u64,
};

pub const zx_type_430 = struct {
    body: u64,
    condition: u64,
    count: u64,
    locals: []const bool,
    reachable: []const bool,
    symbols: u64,
};

pub const zx_type_431 = struct {
    expressions: *const zx_type_28,
    index: u64,
    locals: []const bool,
    reachable: []const bool,
    remaining: u64,
};

pub const zx_type_432 = struct {
    count: []const u64,
    first: []const u64,
    index: u64,
    program: *const zx_type_155,
    symbols: []const u64,
};

pub const zx_type_433 = struct {
    index: u64,
    locals: []const bool,
    symbols: []const u64,
};

pub const zx_type_434 = struct {
    active: bool,
    cached_count: []const u64,
    cached_first: []const u64,
    cached_positions: []const u64,
    children: []const u64,
    field_indices: []const u64,
    heads: []const u64,
    index: u64,
    item: u64,
    next: []const u64,
    parents: []const u64,
    phase: zx_type_170,
    place_types: []const u32,
    program: *const zx_type_155,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    tails: []const u64,
};

pub const zx_type_435 = struct {
    active: bool,
    found: bool,
    index: *const zx_type_173,
    key: *const zx_type_174,
    slot: u64,
    value: u64,
};

pub const zx_type_436 = struct { []const u64, []const u64, };

pub const zx_type_437 = struct {
    position: u64,
    slots: []const u64,
};

pub const zx_type_438 = struct { *const zx_type_155, };

pub const zx_type_439 = struct { *const zx_type_155, []const bool, };

pub const zx_type_440 = struct { *const zx_type_155, []const bool, []const bool, };

pub const zx_type_441 = struct { *const zx_type_155, []const bool, []const bool, *const zx_type_161, };

pub const zx_type_442 = struct { *const zx_type_155, []const bool, []const bool, *const zx_type_161, *const zx_type_168, };

pub const zx_type_443 = struct { *const zx_type_155, []const bool, []const bool, *const zx_type_161, *const zx_type_168, *const zx_type_169, };

pub const zx_type_444 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_183,
    index: u64,
    state: zx_type_162,
};

pub const zx_type_445 = struct { []const zx_type_162, void, };

pub const zx_type_446 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    index: u64,
    source: []const u64,
};

pub const zx_type_447 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    forest: *const zx_type_183,
    index: u64,
    references: []const bool,
    target: u64,
    type_id: u32,
    types: *const zx_type_63,
    value: u64,
};

pub const zx_type_448 = struct {
    active: bool,
    ascending: bool,
    fact: u64,
    facts: []const u64,
    forest: *const zx_type_183,
    id: u64,
    layout: *const zx_type_164,
    leaving: bool,
    references: []const bool,
    root: u64,
    states: []const zx_type_162,
    types: *const zx_type_63,
};

pub const zx_type_449 = struct {
    active: bool,
    cache: *const zx_type_195,
    found: bool,
    left: u64,
    right: u64,
    slot: u64,
    value: u64,
};

pub const zx_type_450 = struct {
    active: bool,
    cache: *const zx_type_195,
    capacity: u64,
    grow: bool,
    index: u64,
    left: u64,
    right: u64,
    value: u64,
};

pub const zx_type_451 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: *const zx_type_183,
    index: u64,
    references: []const bool,
    same: bool,
    type_id: u32,
    types: *const zx_type_63,
};

pub const zx_type_452 = struct {
    action: zx_type_194,
    cache: *const zx_type_195,
    children: []const u64,
    first: []const u64,
    forest: *const zx_type_183,
    indices: []const u64,
    left: []const u64,
    paired: bool,
    references: []const bool,
    right: []const u64,
    types: *const zx_type_63,
    value: u64,
};

pub const zx_type_453 = struct {
    expressions: u64,
    facts: []const u64,
    memo: []const u64,
    places: u64,
    states: []const zx_type_162,
};

pub const zx_type_454 = struct { *const zx_type_155, *const zx_type_279, };

pub const zx_type_455 = struct { *const zx_type_155, *const zx_type_279, *const zx_type_206, };

pub const zx_type_456 = struct {
    action: zx_type_203,
    count: u64,
    index: u64,
    layout: *const zx_type_164,
    memo_first: u64,
    memory: *const zx_type_205,
    references: []const bool,
    rewrite_action: zx_type_194,
    saved: *const zx_type_204,
    state_first: u64,
    types: *const zx_type_63,
};

pub const zx_type_458 = struct { []const zx_type_209, ?zx_type_209, };

pub const zx_type_459 = struct { []const zx_type_209, void, };

pub const zx_type_460 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_183,
    index: u64,
    merge: bool,
    parents: []const u64,
    references: []const bool,
    saved: []const u64,
    source: []const u64,
    types: *const zx_type_63,
};

pub const zx_type_461 = struct {
    activation: u64,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: *const zx_type_183,
    index: u64,
    loops: *const zx_type_219,
    references: []const bool,
    seen: bool,
    types: *const zx_type_63,
    value: u64,
};

pub const zx_type_462 = struct {
    activation: u64,
    changed: bool,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: *const zx_type_183,
    index: u64,
    loops: *const zx_type_219,
    references: []const bool,
    types: *const zx_type_63,
    value: u64,
};

pub const zx_type_463 = struct {
    count: u64,
    facts: []const u64,
    first: u64,
    index: u64,
    layout: *const zx_type_164,
    local_first: u64,
    locals: u64,
    memory: *const zx_type_205,
    references: []const bool,
    roots: []const u64,
    symbols: []const u64,
    types: *const zx_type_63,
};

pub const zx_type_464 = struct {
    count: u64,
    flags: []const bool,
    symbols: u64,
};

pub const zx_type_465 = struct {
    count: u64,
    first: u64,
    flags: []const bool,
    index: u64,
    symbols: []const u64,
};

pub const zx_type_466 = struct {
    flags: []const bool,
    index: u64,
    memo: []const u64,
    parents: []const u64,
};

pub const zx_type_467 = struct {
    id: u64,
    parents: []const u64,
};

pub const zx_type_468 = struct {
    facts: []const u64,
    flags: []const bool,
    index: u64,
    outputs: []const u64,
    roots: []const u64,
    source: []const u64,
};

pub const zx_type_469 = struct {
    count: u64,
    first: u64,
};

pub const zx_type_470 = struct {
    found: bool,
    index: u64,
    slots: *const zx_type_48,
};

pub const zx_type_471 = struct {
    active: bool,
    ascending: bool,
    expression: u64,
    expressions: *const zx_type_28,
    found: bool,
    layout: *const zx_type_169,
    memo: []const u64,
    position: u64,
    trail: []const u64,
};

pub const zx_type_472 = struct {
    children: []const u64,
    count: u64,
    index: u64,
};

pub const zx_type_473 = struct { *const zx_type_155, *const zx_type_280, };

pub const zx_type_474 = struct { *const zx_type_155, *const zx_type_280, *const zx_type_213, };

pub const zx_type_475 = struct { *const zx_type_103, };

pub const zx_type_476 = struct { *const zx_type_103, bool, };

pub const zx_type_477 = struct { *const zx_type_103, bool, bool, };

pub const zx_type_478 = struct { *const zx_type_103, bool, bool, *const zx_type_155, };

pub const zx_type_479 = struct { *const zx_type_103, bool, bool, *const zx_type_155, *const zx_type_213, };

pub const zx_type_480 = struct { *const zx_type_103, bool, bool, *const zx_type_155, *const zx_type_213, bool, };

pub const zx_type_481 = struct { *const zx_type_103, bool, bool, bool, };

pub const zx_type_482 = struct { *const zx_type_103, bool, bool, bool, bool, };

pub const zx_type_483 = struct {
    expressions: *const zx_type_28,
    index: u64,
    limit: u64,
    valid: bool,
};

pub const zx_type_484 = struct {
    index: u64,
    members: []const []const u8,
    valid: bool,
};

pub const zx_type_485 = struct {
    index: u64,
    modules: *const zx_type_58,
    name: []const u8,
    owner: []const u8,
    valid: bool,
};

pub const zx_type_486 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_487 = struct {
    index: u64,
    left: []const []const u8,
    right: []const []const u8,
    valid: bool,
};

pub const zx_type_488 = struct {
    context: *const zx_type_92,
    index: u64,
    name: []const u8,
    owner: []const u8,
    valid: bool,
};

pub const zx_type_489 = struct { *const zx_type_92, };

pub const zx_type_490 = struct { *const zx_type_92, ?[]const u8, };

pub const zx_type_491 = struct { *const zx_type_92, ?[]const u8, []const u8, };

pub const zx_type_492 = struct { *const zx_type_92, ?[]const u8, []const u8, bool, };

pub const zx_type_493 = struct { *const zx_type_92, ?[]const u8, []const u8, bool, bool, };

pub const zx_type_494 = struct { *const zx_type_92, ?[]const u8, []const u8, bool, bool, bool, };

pub const zx_type_495 = struct { *const zx_type_92, ?[]const u8, []const u8, bool, bool, bool, bool, };

pub const zx_type_496 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u32,
    types: []const u32,
};

pub const zx_type_497 = struct {
    input: *const zx_type_253,
    position: u64,
    positions: []const ?u32,
    type_ids: []const u32,
    valid: bool,
};

pub const zx_type_498 = struct { []const u32, ?u32, };

pub const zx_type_500 = struct { []const ?u32, ??u32, };

pub const zx_type_501 = struct { []const ?u32, void, };

pub const zx_type_502 = struct { *const zx_type_253, };

pub const zx_type_503 = struct { *const zx_type_253, bool, };

pub const zx_type_504 = struct { *const zx_type_253, bool, bool, };

pub const zx_type_505 = struct { *const zx_type_247, };

pub const zx_type_506 = struct { *const zx_type_247, bool, };

pub const zx_type_507 = struct { *const zx_type_247, bool, bool, };

pub const zx_type_508 = struct { *const zx_type_247, bool, bool, bool, };

pub const zx_type_509 = struct { *const zx_type_247, bool, bool, bool, ?*const zx_type_253, };

pub const zx_type_510 = struct { *const zx_type_247, bool, bool, bool, ?*const zx_type_253, bool, };

pub const zx_type_511 = struct { *const zx_type_247, bool, *const zx_type_67, };

pub const zx_type_512 = struct { *const zx_type_247, bool, *const zx_type_67, bool, };

pub const zx_type_513 = struct {
    index: u64,
    names: []const []const u8,
    table: *const zx_type_62,
    types: []const u32,
    valid: bool,
};

pub const zx_type_514 = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_515 = struct { []const *const zx_type_260, void, };

pub const zx_type_516 = struct {
    contracts: *const zx_type_36,
    index: u64,
    state: *const zx_type_264,
};

pub const zx_type_517 = struct { []const []const u8, void, };

pub const zx_type_518 = struct { []const *const zx_type_259, void, };

pub const zx_type_519 = struct {
    control: *const zx_type_39,
    first: u64,
    frames: []const *const zx_type_259,
    index: u64,
    source: u64,
};

pub const zx_type_520 = struct {
    capacity: u64,
    slots: []const u64,
};

pub const zx_type_521 = struct {
    index: u64,
    previous: []const u64,
    slots: []const u64,
};

pub const zx_type_522 = struct {
    key: u64,
    position: u64,
    slots: []const u64,
};

pub const zx_type_523 = struct {
    end: u64,
    index: u64,
    table: *const zx_type_28,
    values: []const u32,
};

pub const zx_type_524 = struct { []const []const u8, []const []const u8, };

pub const zx_type_525 = struct {
    end: u64,
    expressions: *const zx_type_28,
    index: u64,
    names: []const []const u8,
    tables: *const zx_type_63,
};

pub const zx_type_526 = struct { []const *const zx_type_260, []const *const zx_type_260, };

pub const zx_type_527 = struct {
    frames: []const *const zx_type_259,
    index: u64,
    source: u64,
    values: []const u32,
};

pub const zx_type_529 = struct { []const *const zx_type_259, ?*const zx_type_259, };

pub const zx_type_530 = struct {
    index: u64,
    names: []const []const u8,
    values: []const []const u8,
};

pub const zx_type_531 = struct { *const zx_type_265, };

pub const zx_type_532 = struct { *const zx_type_265, *const zx_type_264, };

pub const zx_type_533 = struct { *const zx_type_265, *const zx_type_264, *const zx_type_264, };

pub const zx_type_534 = struct { *const zx_type_265, *const zx_type_264, *const zx_type_264, ?[]const []const u8, };

pub const zx_type_535 = struct {
    context: *const zx_type_261,
    index: u64,
    unit: *const zx_type_67,
    valid: bool,
};

pub const zx_type_536 = struct {
    first: u64,
    index: u64,
    members: []const []const u8,
    names: []const []const u8,
    valid: bool,
};

pub const zx_type_537 = struct { *const zx_type_68, bool, bool, bool, };

pub const zx_type_538 = struct { *const zx_type_68, bool, bool, bool, bool, };

pub const zx_type_539 = struct { *const zx_type_68, bool, bool, bool, bool, bool, };

pub const value_zx_type_47_27f6baed02dfb16b8bbeaef695a80d4899de28e19dde605fcd26d176c6e70749 = struct {
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_29,
    zx_origin: ?*const zx_type_47 = null,
};

pub const value_zx_type_54_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8 = struct {
    contracts: []const *const zx_type_36,
    control: []const *const zx_type_39,
    expressions: []const *const zx_type_28,
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_29,
    roots: []const ?u32,
    store_modes: []const zx_type_49,
    stores: []const *const zx_type_48,
    symbols: []const *const zx_type_31,
    zx_origin: ?*const zx_type_54 = null,
};

pub const value_zx_type_55_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80 = struct {
    control: *const zx_type_39,
    expressions: *const zx_type_28,
    root: ?u32,
    stores: *const zx_type_48,
    symbols: *const zx_type_31,
    zx_origin: ?*const zx_type_55 = null,
};

pub const value_zx_type_56_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_28,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_31,
    zx_origin: ?*const zx_type_56 = null,
};

pub const value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    identities: []const ?[]const u8,
    import_names: []const []const u8,
    specifiers: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    type_namespaces: []const []const []const u8,
    zx_origin: ?*const zx_type_58 = null,
};

pub const value_zx_type_59_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    output_types: []const u32,
    zx_origin: ?*const zx_type_59 = null,
};

pub const value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    base: *const zx_type_62,
    delta: *const zx_type_62,
    zx_origin: ?*const zx_type_63 = null,
};

pub const value_zx_type_64_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_64 = null,
};

pub const value_zx_type_65_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_60,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_65 = null,
};

pub const value_zx_type_66_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e = struct {
    functions: value_zx_type_54_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8,
    max_offset: u64,
    maximum_count: u64,
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    scalar_count: u64,
    table: *const zx_type_62,
    zx_origin: ?*const zx_type_66 = null,
};

pub const value_zx_type_67_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5 = struct {
    body: value_zx_type_55_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80,
    contracts: *const zx_type_36,
    input_type: u32,
    output_ownership: zx_type_29,
    output_type: u32,
    transaction: bool,
    type_only: bool,
    zx_origin: ?*const zx_type_67 = null,
};

pub const value_zx_type_68_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235 = struct {
    context: value_zx_type_66_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e,
    expected_version: u64,
    export_names: []const []const u8,
    export_types: []const u32,
    unit: value_zx_type_67_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5,
    version: u64,
    zx_origin: ?*const zx_type_68 = null,
};

pub const value_zx_type_69_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    maximum_count: u64,
    scalar_count: u64,
    table: *const zx_type_62,
    zx_origin: ?*const zx_type_69 = null,
};

pub const value_zx_type_71_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    kind: zx_type_70,
    name: []const u8,
    zx_origin: ?*const zx_type_71 = null,
};

pub const value_zx_type_72_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_72 = null,
};

pub const value_zx_type_73_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    table: *const zx_type_62,
    zx_origin: ?*const zx_type_73 = null,
};

pub const value_zx_type_74_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    errors: bool,
    first: u64,
    values: []const []const u8,
    zx_origin: ?*const zx_type_74 = null,
};

pub const value_zx_type_75_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_62,
    zx_origin: ?*const zx_type_75 = null,
};

pub const value_zx_type_76_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    scalar_count: u64,
    table: *const zx_type_62,
    zx_origin: ?*const zx_type_76 = null,
};

pub const value_zx_type_77_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
    zx_origin: ?*const zx_type_77 = null,
};

pub const value_zx_type_78_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    max_offset: u64,
    symbols: *const zx_type_31,
    zx_origin: ?*const zx_type_78 = null,
};

pub const value_zx_type_79_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_28,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
    zx_origin: ?*const zx_type_79 = null,
};

pub const value_zx_type_80_65cf7d6fbad1c16266bae803c08ca5f9cfd0a43ae4a2b544cd579935fe760b39 = struct {
    kind: zx_type_11,
    payload: u64,
    state: value_zx_type_79_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a,
    zx_origin: ?*const zx_type_80 = null,
};

pub const value_zx_type_81_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
    zx_origin: ?*const zx_type_81 = null,
};

pub const value_zx_type_82_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    max_offset: u64,
    table: *const zx_type_28,
    zx_origin: ?*const zx_type_82 = null,
};

pub const value_zx_type_83_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    block: u64,
    control: *const zx_type_39,
    zx_origin: ?*const zx_type_83 = null,
};

pub const value_zx_type_84_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct {
    control: *const zx_type_39,
    root: ?u32,
    zx_origin: ?*const zx_type_84 = null,
};

pub const value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const ?u32,
    zx_origin: ?*const zx_type_85 = null,
};

pub const value_zx_type_86_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u32,
    zx_origin: ?*const zx_type_86 = null,
};

pub const value_zx_type_87_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    contracts: *const zx_type_36,
    max_offset: u64,
    zx_origin: ?*const zx_type_87 = null,
};

pub const value_zx_type_88_5ec2c5edd29e0d3f01648c48f884d91d1e084ad59827a77873e8587ae07c5bf1 = struct {
    functions: value_zx_type_54_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8,
    index: u64,
    zx_origin: ?*const zx_type_88 = null,
};

pub const value_zx_type_90_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    index: u64,
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_90 = null,
};

pub const value_zx_type_91_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct {
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    table: *const zx_type_62,
    zx_origin: ?*const zx_type_91 = null,
};

pub const value_zx_type_92_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea = struct {
    functions: value_zx_type_59_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    index: u64,
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_92 = null,
};

pub const value_zx_type_93_80fa3f09fde2ea8660c1d43e969ee3d68c4cda0e85a50de87ab5f1fb43c5c390 = struct {
    context: value_zx_type_91_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189,
    type_id: u64,
    zx_origin: ?*const zx_type_93 = null,
};

pub const value_zx_type_94_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u32,
    tables: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_94 = null,
};

pub const value_zx_type_95_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_64_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_60,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_95 = null,
};

pub const value_zx_type_96_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_96 = null,
};

pub const value_zx_type_97_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    delta: *const zx_type_62,
    id: u32,
    zx_origin: ?*const zx_type_97 = null,
};

pub const value_zx_type_98_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_98 = null,
};

pub const value_zx_type_99_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    id: u32,
    native_references: bool,
    tables: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_99 = null,
};

pub const value_zx_type_100_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    id: u32,
    native_references: bool,
    table: *const zx_type_62,
    zx_origin: ?*const zx_type_100 = null,
};

pub const value_zx_type_101_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u64,
    paths: []const []const u8,
    zx_origin: ?*const zx_type_101 = null,
};

pub const value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    paths: []const []const u8,
    slot_types: []const u32,
    table: *const zx_type_62,
    type_only: bool,
    zx_origin: ?*const zx_type_102 = null,
};

pub const value_zx_type_103_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d = struct {
    context: value_zx_type_66_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e,
    unit: value_zx_type_67_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5,
    zx_origin: ?*const zx_type_103 = null,
};

pub const value_zx_type_104_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: *const zx_type_28,
    id: u32,
    index: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_104 = null,
};

pub const value_zx_type_105_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_48,
    zx_origin: ?*const zx_type_105 = null,
};

pub const value_zx_type_106_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6 = struct {
    expressions: *const zx_type_28,
    functions: value_zx_type_105_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_48,
    symbols: *const zx_type_31,
    table: *const zx_type_62,
    zx_origin: ?*const zx_type_106 = null,
};

pub const value_zx_type_107_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed = struct {
    context: value_zx_type_106_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    kind: zx_type_11,
    payload: u64,
    target: zx_type_60,
    type_id: u32,
    zx_origin: ?*const zx_type_107 = null,
};

pub const value_zx_type_111_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    available: *const zx_type_48,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_48,
    slots: []const u32,
    zx_origin: ?*const zx_type_111 = null,
};

pub const value_zx_type_112_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    table: *const zx_type_62,
    type_id: u32,
    zx_origin: ?*const zx_type_112 = null,
};

pub const value_zx_type_113_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    contracts: *const zx_type_36,
    input_type: u32,
    max_offset: u64,
    output_type: u32,
    table: *const zx_type_62,
    zx_origin: ?*const zx_type_113 = null,
};

pub const value_zx_type_114_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603 = struct {
    index: u64,
    program: value_zx_type_113_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_114 = null,
};

pub const value_zx_type_115_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    control: *const zx_type_39,
    returns: []const bool,
    selection: u64,
    zx_origin: ?*const zx_type_115 = null,
};

pub const value_zx_type_116_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_28,
    limit: u64,
    zx_origin: ?*const zx_type_116 = null,
};

pub const value_zx_type_117_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: []const *const zx_type_28,
    native_concurrent: []const bool,
    native_modules: []const ?u32,
    stores: []const *const zx_type_48,
    zx_origin: ?*const zx_type_117 = null,
};

pub const value_zx_type_118_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = struct {
    concurrent: bool,
    functions: value_zx_type_117_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_118 = null,
};

pub const value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
    zx_origin: ?*const zx_type_119 = null,
};

pub const value_zx_type_120_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    captures: u64,
    nonnull: u64,
    zx_origin: ?*const zx_type_120 = null,
};

pub const value_zx_type_121_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    conditions: []const u64,
    facts: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    truths: []const bool,
    zx_origin: ?*const zx_type_121 = null,
};

pub const value_zx_type_123_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    a: u64,
    b: u64,
    c: u64,
    phase: zx_type_122,
    zx_origin: ?*const zx_type_123 = null,
};

pub const value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7 = struct {
    body: value_zx_type_55_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80,
    functions: value_zx_type_117_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    output_type: u32,
    table: *const zx_type_62,
    transaction: bool,
    zx_origin: ?*const zx_type_124 = null,
};

pub const value_zx_type_125_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    concurrent: []const bool,
    pure: []const bool,
    returns: []const bool,
    zx_origin: ?*const zx_type_125 = null,
};

pub const value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0 = struct {
    prepared: value_zx_type_125_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    program: value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    zx_origin: ?*const zx_type_126 = null,
};

pub const value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    active: []const bool,
    changed_symbols: []const u64,
    changed_values: []const bool,
    declared: []const bool,
    owners: []const u64,
    zx_origin: ?*const zx_type_127 = null,
};

pub const value_zx_type_129_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    a: []const u64,
    b: []const u64,
    c: []const u64,
    phases: []const zx_type_122,
    zx_origin: ?*const zx_type_129 = null,
};

pub const value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d = struct {
    activity: value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    frames: value_zx_type_129_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    refinement: value_zx_type_121_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    zx_origin: ?*const zx_type_130 = null,
};

pub const value_zx_type_131_f470abcbb887e90abb8d9cc33ef348b0350c739d56bd4342cef13bf8e9afa562 = struct {
    context: value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0,
    frame: value_zx_type_123_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_131 = null,
};

pub const value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063 = struct {
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    valid: bool,
    zx_origin: ?*const zx_type_133 = null,
};

pub const value_zx_type_134_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct {
    facts: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    symbol: u32,
    zx_origin: ?*const zx_type_134 = null,
};

pub const value_zx_type_135_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    expressions: *const zx_type_28,
    facts: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    payload: u64,
    truth: bool,
    zx_origin: ?*const zx_type_135 = null,
};

pub const value_zx_type_136_180c8db61327c5ec28c1dd7044b5cf087f6bf11c71b70daa8f83a901fbf86853 = struct {
    condition: u64,
    expressions: *const zx_type_28,
    state: value_zx_type_121_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    truth: bool,
    zx_origin: ?*const zx_type_136 = null,
};

pub const value_zx_type_137_92508f644127bb85f633340ef0446c798ffdbb802763fefb2c89d184c66bdb3c = struct {
    facts: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    mark: value_zx_type_120_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_137 = null,
};

pub const value_zx_type_138_b4c00b0680a164f9ad85cafef49c2f1d31566b1a676a14d85e4570178e088fb9 = struct {
    activity: value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    mark: u64,
    zx_origin: ?*const zx_type_138 = null,
};

pub const value_zx_type_139_305a62f990205c111b44fc67db9221487d395cc635760c1b61644adb1bf4c462 = struct {
    context: value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0,
    statement: u64,
    zx_origin: ?*const zx_type_139 = null,
};

pub const value_zx_type_140_951ce996038a89a93b91040661ad8e5f18114a0520be5139c04eac3a15e2318a = struct {
    frame: value_zx_type_123_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_140 = null,
};

pub const value_zx_type_141_79b96ffa2e891f4534c9a8b770935af0223aeb89cda66f40793025b64b74d946 = struct {
    activity: value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    symbol: u64,
    value: bool,
    zx_origin: ?*const zx_type_141 = null,
};

pub const value_zx_type_142_a8cc14e4741ce478441a6af0b40d58bf8b3f27bab9314693255c6d791dc94e81 = struct {
    mode: zx_type_132,
    owner: u64,
    program: value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    symbol: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_142 = null,
};

pub const value_zx_type_143_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    err: u32,
    facts: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: u32,
    zx_origin: ?*const zx_type_143 = null,
};

pub const value_zx_type_144_073d891ba45095e5915c165198921d39ae001c11a900ba5941237395e3848750 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_28,
    facts: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: ?u32,
    value: u64,
    zx_origin: ?*const zx_type_144 = null,
};

pub const value_zx_type_145_b8ec70fbd49037c4f5f15832ef24774698f9ceaf2b6c8bda56f20308b14ddd6f = struct {
    count: u64,
    depth: u64,
    first: u64,
    flags: u64,
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    values: []const u32,
    zx_origin: ?*const zx_type_145 = null,
};

pub const value_zx_type_146_cf7f91935142e682a287d5d100dd4ce0b0109b30ee54eeca5ee330715975db08 = struct {
    count: u64,
    expressions: *const zx_type_28,
    facts: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    first: u64,
    zx_origin: ?*const zx_type_146 = null,
};

pub const value_zx_type_147_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    active: []const bool,
    count: u64,
    first: u64,
    symbols: []const u32,
    zx_origin: ?*const zx_type_147 = null,
};

pub const value_zx_type_148_c63bcba686670049248646377d5d23dc63c4a7a91d3483419515b2f1fd8e2b64 = struct {
    payload: u64,
    position: u64,
    program: value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    zx_origin: ?*const zx_type_148 = null,
};

pub const value_zx_type_150_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expressions: *const zx_type_28,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_150 = null,
};

pub const value_zx_type_151_b06ba9ffb7550edab6c90294a6cfddbec1276107726d70c06500e2c71a01deb4 = struct {
    payload: u64,
    program: value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    zx_origin: ?*const zx_type_151 = null,
};

pub const value_zx_type_152_0052edaa8370b31f34b2f05af01ed3537fdd252f1e5484a30f0eadd3bd3f1c9d = struct {
    context: value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0,
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_152 = null,
};

pub const value_zx_type_153_d67de9150a29b2c86fcfaa670164fb137ade9312feda415779572f647ca40086 = struct {
    body: value_zx_type_55_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80,
    input_type: u32,
    output_type: u32,
    table: *const zx_type_62,
    zx_origin: ?*const zx_type_153 = null,
};

pub const value_zx_type_154_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    ownership: []const zx_type_29,
    stores: []const *const zx_type_48,
    zx_origin: ?*const zx_type_154 = null,
};

pub const value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695 = struct {
    body: ?u32,
    control: *const zx_type_39,
    expressions: *const zx_type_28,
    functions: value_zx_type_154_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    symbols: *const zx_type_31,
    type_only: bool,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_155 = null,
};

pub const value_zx_type_156_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u64,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_156 = null,
};

pub const value_zx_type_157_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expression: u64,
    expressions: *const zx_type_28,
    index: u64,
    zx_origin: ?*const zx_type_157 = null,
};

pub const value_zx_type_158_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expression: u64,
    found: bool,
    zx_origin: ?*const zx_type_158 = null,
};

pub const value_zx_type_159_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expression: u64,
    expressions: *const zx_type_28,
    locals: []const bool,
    zx_origin: ?*const zx_type_159 = null,
};

pub const value_zx_type_160_e05028d9f2b1d7792bfed137694ab8e6051e740db09be899cd5c3c4ff8b94544 = struct {
    expression: u64,
    program: value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    zx_origin: ?*const zx_type_160 = null,
};

pub const value_zx_type_161_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u64,
    first: []const u64,
    symbols: []const u64,
    zx_origin: ?*const zx_type_161 = null,
};

pub const value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u64,
    field_indices: []const u64,
    parents: []const u64,
    references: []const bool,
    siblings: []const u64,
    types: []const u32,
    zx_origin: ?*const zx_type_164 = null,
};

pub const value_zx_type_166_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d = struct {
    id: u64,
    layout: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    operation: zx_type_163,
    states: []const zx_type_162,
    value: zx_type_162,
    zx_origin: ?*const zx_type_166 = null,
};

pub const value_zx_type_167_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u64,
    first: []const u64,
    positions: []const u64,
    zx_origin: ?*const zx_type_167 = null,
};

pub const value_zx_type_168_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937 = struct {
    cached: value_zx_type_167_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    heads: []const u64,
    next: []const u64,
    tree: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_168 = null,
};

pub const value_zx_type_169_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d = struct {
    cached: value_zx_type_167_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    tree: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    values: []const u64,
    zx_origin: ?*const zx_type_169 = null,
};

pub const value_zx_type_171_767b69074202a272a12100b84e23109da965767802298cfb5e4fed280635514e = struct {
    program: value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    zx_origin: ?*const zx_type_171 = null,
};

pub const value_zx_type_172_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capacity: u64,
    field: u64,
    parent: u64,
    zx_origin: ?*const zx_type_172 = null,
};

pub const value_zx_type_173_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_173 = null,
};

pub const value_zx_type_174_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    field: u64,
    parent: u64,
    zx_origin: ?*const zx_type_174 = null,
};

pub const value_zx_type_175_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_175 = null,
};

pub const value_zx_type_176_0093e0155d66cb511a94de9e5d1d5b400f76ae0078e86bc776bc6b8934ee5924 = struct {
    index: value_zx_type_173_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    key: value_zx_type_174_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_176 = null,
};

pub const value_zx_type_177_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expressions: *const zx_type_28,
    id: u64,
    zx_origin: ?*const zx_type_177 = null,
};

pub const value_zx_type_178_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u32,
    target: u64,
    zx_origin: ?*const zx_type_178 = null,
};

pub const value_zx_type_180_66dcc527b00a87c3c2a5109b4a3924ac4c4d43c09f84caa10ed23e5ea63930cf = struct {
    active: bool,
    ancestor: u64,
    bindings: []const u64,
    cached: value_zx_type_167_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    capacity: u64,
    child_expression: u64,
    children: []const u64,
    cursor: u64,
    direct: bool,
    expression: u64,
    field_indices: []const u64,
    heads: []const u64,
    key_fields: []const u64,
    key_parents: []const u64,
    next: []const u64,
    parent: u64,
    parents: []const u64,
    path: []const u64,
    path_index: u64,
    phase: zx_type_179,
    place_types: []const u32,
    program: value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    record: u64,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_180 = null,
};

pub const value_zx_type_181_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    first: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_181 = null,
};

pub const value_zx_type_182_08ae4a5c88157bebdfb632c2939fd9a2fdb6e48e4cc60655b08697fb2d0015fb = struct {
    program: value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    roots: value_zx_type_168_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937,
    zx_origin: ?*const zx_type_182 = null,
};

pub const value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u64,
    count: []const u64,
    first: []const u64,
    shells: []const zx_type_162,
    states: []const zx_type_162,
    types: []const u32,
    zx_origin: ?*const zx_type_183 = null,
};

pub const value_zx_type_184_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    fact: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_184 = null,
};

pub const value_zx_type_185_461a038225996c015433bf0a5fb2c9e6a36f43e598f85eccd7a2eee1e984e893 = struct {
    fact: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    reference: bool,
    zx_origin: ?*const zx_type_185 = null,
};

pub const value_zx_type_186_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    index: u64,
    type_id: u32,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_186 = null,
};

pub const value_zx_type_187_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    left: zx_type_162,
    right: zx_type_162,
    zx_origin: ?*const zx_type_187 = null,
};

pub const value_zx_type_188_df87d4e4c94482fd017e977a114eba826861ac6af356c343aea16855cac7c373 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    shell: zx_type_162,
    type_id: u32,
    zx_origin: ?*const zx_type_188 = null,
};

pub const value_zx_type_189_b1b23fbb7680b8cb1b3dadbfa986aa274ef1483cb6efee44a47ca580481a8e23 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    shell: zx_type_162,
    type_id: u32,
    zx_origin: ?*const zx_type_189 = null,
};

pub const value_zx_type_190_48e6facbc67e19905cc5d1979cc7988969acfd6e4bae54b78cb7684de3ebbbab = struct {
    fact: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    type_id: u32,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_190 = null,
};

pub const value_zx_type_191_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0 = struct {
    facts: []const u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    states: []const zx_type_162,
    zx_origin: ?*const zx_type_191 = null,
};

pub const value_zx_type_192_c7b60c00d717dc61a2a9736408d32321057c2522adc791850c9eae52b70181a8 = struct {
    fact: u64,
    id: u64,
    layout: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    references: []const bool,
    storage: value_zx_type_191_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_192 = null,
};

pub const value_zx_type_193_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capacity: u64,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_193 = null,
};

pub const value_zx_type_195_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    left: []const u64,
    right: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_195 = null,
};

pub const value_zx_type_196_9e473f196db28165f17fa02012d877e38b20b2fdd7fbf0bd932a3b8513569fa0 = struct {
    cache: value_zx_type_195_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_196 = null,
};

pub const value_zx_type_197_03d90fa68e4e68b677112113e76ce3e9fb7563db5d750228bd60f891663f8e20 = struct {
    cache: value_zx_type_195_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    left: u64,
    right: u64,
    value: u64,
    zx_origin: ?*const zx_type_197 = null,
};

pub const value_zx_type_198_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_198 = null,
};

pub const value_zx_type_199_0e14e5cdabbe38cb1c79f91fab9c5efb4effe8af60678a6b3d272d5ab52e2387 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    references: []const bool,
    shell: zx_type_162,
    type_id: u32,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_199 = null,
};

pub const value_zx_type_200_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    action: zx_type_194,
    left: zx_type_162,
    right: zx_type_162,
    zx_origin: ?*const zx_type_200 = null,
};

pub const value_zx_type_201_ec908cc2db7bcb55b295ba38c99a7117d8d48d2fedde568fd60bfa6cb2ebc669 = struct {
    action: zx_type_194,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    left: u64,
    references: []const bool,
    right: u64,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_201 = null,
};

pub const value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    facts: []const u64,
    memo: []const u64,
    memo_count: []const u64,
    memo_first: []const u64,
    state_count: []const u64,
    state_first: []const u64,
    zx_origin: ?*const zx_type_204 = null,
};

pub const value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d = struct {
    facts: []const u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memo: []const u64,
    states: []const zx_type_162,
    trail: []const u64,
    zx_origin: ?*const zx_type_205 = null,
};

pub const value_zx_type_206_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf = struct {
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    snapshots: value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_206 = null,
};

pub const value_zx_type_207_c2b2345f31a3ca9410ec1d01298fd1e422f335f176ffd7a4e0451d112beced1a = struct {
    fact: u64,
    id: u64,
    layout: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    operation: zx_type_163,
    references: []const bool,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_207 = null,
};

pub const value_zx_type_208_a0405b3f3da574378c4599f54a1cf52b9531f3ff33aefbd053cbddcca68d591c = struct {
    layout: value_zx_type_169_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    program: value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    zx_origin: ?*const zx_type_208 = null,
};

pub const value_zx_type_210_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    action: zx_type_209,
    index: u64,
    moving: bool,
    subject: u64,
    zx_origin: ?*const zx_type_210 = null,
};

pub const value_zx_type_212_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    actions: []const zx_type_209,
    indices: []const u64,
    moving: []const bool,
    subjects: []const u64,
    zx_origin: ?*const zx_type_212 = null,
};

pub const value_zx_type_213_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    complete: bool,
    expression: u64,
    failed: bool,
    output: zx_type_162,
    stores_owned: bool,
    zx_origin: ?*const zx_type_213 = null,
};

pub const value_zx_type_214_9ca4da4ade6ce39392bcd565b92026186825f5515fba0d69864aa5bdd2c0c8c0 = struct {
    action: zx_type_203,
    frame: u64,
    layout: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    stack: value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_214 = null,
};

pub const value_zx_type_215_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    frame: u64,
    stack: value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_215 = null,
};

pub const value_zx_type_216_38e16b7ca832d5cab2cdd1573bdea3003d7c88255f2146bd1c658c5474aa0153 = struct {
    capture: zx_type_202,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    stack: value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_216 = null,
};

pub const value_zx_type_217_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53 = struct {
    frame: value_zx_type_210_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    work: value_zx_type_212_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_217 = null,
};

pub const value_zx_type_218_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: []const u64,
    first: []const u64,
    zx_origin: ?*const zx_type_218 = null,
};

pub const value_zx_type_219_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d = struct {
    boundaries: []const u64,
    count: []const u64,
    entries: []const u64,
    exits: []const u64,
    facts: []const u64,
    first: []const u64,
    heads: []const u64,
    outputs: []const u64,
    roots: []const u64,
    seen: []const bool,
    zx_origin: ?*const zx_type_219 = null,
};

pub const value_zx_type_221_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3 = struct {
    active: bool,
    builders: value_zx_type_218_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    complete: bool,
    domains: value_zx_type_161_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    expression: u64,
    failed: bool,
    layout: value_zx_type_169_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    loops: value_zx_type_219_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    program: value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    returned: zx_type_162,
    returns: []const bool,
    snapshots: value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    stores_owned: bool,
    value: u64,
    values: []const u64,
    work: value_zx_type_212_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_221 = null,
};

pub const value_zx_type_222_a338d1ab71f88877331d772f98bd14da65b1786b2be70c874f8b7e12b86f2f1f = struct {
    frame: u64,
    layout: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    merge: bool,
    references: []const bool,
    stack: value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_222 = null,
};

pub const value_zx_type_223_c24243ffcb91606794657c93d9112ec4c334bd9de6c46889f83dc67ca369b0a0 = struct {
    index: u64,
    loops: value_zx_type_219_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_223 = null,
};

pub const value_zx_type_224_e0ee3b7694a94ee6184c97b78a601ea953f2ec41d003a59e2d2c20bd608416ca = struct {
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_219_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_224 = null,
};

pub const value_zx_type_225_3d04dd43b3d06a3225ea47bfd43abc7af1e40baf278abd1b107975826d4f1dbb = struct {
    condition: bool,
    expression: u64,
    index: u64,
    machine: value_zx_type_221_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3,
    value: u64,
    zx_origin: ?*const zx_type_225 = null,
};

pub const value_zx_type_226_240efbbbf7810640b6fc01ce36bdc99bfbeb5720a9917ff0491c9572a913a019 = struct {
    boundary: u64,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    snapshots: value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    work: value_zx_type_212_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_226 = null,
};

pub const value_zx_type_227_4d3f012ce1af010aa08025827bda50d8f143763669bc2e4b561dcc5658f0bb6a = struct {
    changed: bool,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_219_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_227 = null,
};

pub const value_zx_type_228_9ea6e119697e5089b2d71b0128c4d91826c989da87b1481dc0d5f340ecdd8edd = struct {
    domains: value_zx_type_161_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    exiting: bool,
    expression: u64,
    index: u64,
    layout: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_219_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    snapshots: value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_228 = null,
};

pub const value_zx_type_229_889643ab829a1c5bfcc90b79c286ed0a794313db5ea714f0972ac74b5720a859 = struct {
    domains: value_zx_type_161_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    entry: u64,
    expression: u64,
    layout: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_219_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    program: value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    value: u64,
    zx_origin: ?*const zx_type_229 = null,
};

pub const value_zx_type_232_4158841c74e882000927bc9fb2cfef48d50f106f07c7898967375498c5ede5cb = struct {
    active: bool,
    cursors: []const u64,
    expression: u64,
    expressions: *const zx_type_28,
    facts: []const u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    layout: value_zx_type_169_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    permanent: bool,
    phase: zx_type_231,
    position: u64,
    query: u64,
    references: []const bool,
    root: u64,
    states: []const zx_type_162,
    trail: []const u64,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    work: []const u64,
    zx_origin: ?*const zx_type_232 = null,
};

pub const value_zx_type_233_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expression: u64,
    expressions: *const zx_type_28,
    index: u64,
    permanent: bool,
    zx_origin: ?*const zx_type_233 = null,
};

pub const value_zx_type_234_0d6d611f2caeee490761bbb5ea443b6881e3d712a7de202a9d02b0df984686e1 = struct {
    expression: u64,
    expressions: *const zx_type_28,
    layout: value_zx_type_169_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    permanent: bool,
    references: []const bool,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_234 = null,
};

pub const value_zx_type_235_ba054a92466517afadfa71eb48b1a69236032a9b3b84f6ef89ed7b3a38acc13a = struct {
    expression: u64,
    expressions: *const zx_type_28,
    layout: value_zx_type_169_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_235 = null,
};

pub const value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    position: u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_236 = null,
};

pub const value_zx_type_237_7498e4f806a7d6cb548387280423a75175fc5b80ec06eb4213ab0655a938538d = struct {
    current: zx_type_162,
    moving: bool,
    position: u64,
    symbols: *const zx_type_31,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_237 = null,
};

pub const value_zx_type_238_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    assign: bool,
    assigned: zx_type_162,
    failed: bool,
    value: zx_type_162,
    zx_origin: ?*const zx_type_238 = null,
};

pub const value_zx_type_239_548d03a1c937aa175a4ae6dc65848134fd43039f0f2deb8397102cde1a357280 = struct {
    builders: value_zx_type_218_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    count: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_239 = null,
};

pub const value_zx_type_240_9b2f070bd0a5a2314312b35bc5cd00be816db0248310d896c611be777eb24dfc = struct {
    builders: value_zx_type_218_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_240 = null,
};

pub const value_zx_type_242_3d9243068d042715091b3bc26eced84b2276542fa4ce6ed7c77bd25c76818046 = struct {
    container: bool,
    frame: value_zx_type_210_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    kind: zx_type_11,
    machine: value_zx_type_221_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3,
    payload: u64,
    zx_origin: ?*const zx_type_242 = null,
};

pub const value_zx_type_243_190073c195a96e0748b52805b1cbcc6366d97081df0f6eda8af2362d81577f30 = struct {
    builders: value_zx_type_218_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    type_id: u32,
    zx_origin: ?*const zx_type_243 = null,
};

pub const value_zx_type_244_548d03a1c937aa175a4ae6dc65848134fd43039f0f2deb8397102cde1a357280 = struct {
    builders: value_zx_type_218_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    fact: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_244 = null,
};

pub const value_zx_type_245_9c68fc8229a3cb9544086ee9d74623a5845e02f8d7b0c7e22830b51be4e668ef = struct {
    domains: value_zx_type_161_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    layout: value_zx_type_169_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    program: value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    returns: []const bool,
    runtime: value_zx_type_206_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf,
    zx_origin: ?*const zx_type_245 = null,
};

pub const value_zx_type_246_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603 = struct {
    declared: zx_type_29,
    outcome: value_zx_type_213_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_246 = null,
};

pub const value_zx_type_247_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d = struct {
    context: value_zx_type_66_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e,
    index: u64,
    zx_origin: ?*const zx_type_247 = null,
};

pub const value_zx_type_248_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922 = struct {
    functions: value_zx_type_59_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    index: u64,
    zx_origin: ?*const zx_type_248 = null,
};

pub const value_zx_type_249_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct {
    fallible: bool,
    members: ?[]const []const u8,
    zx_origin: ?*const zx_type_249 = null,
};

pub const value_zx_type_250_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06 = struct {
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_250 = null,
};

pub const value_zx_type_251_e1a3efb1661a55082d96026e298239963014feef940e12b8f12b12b89508e175 = struct {
    functions: value_zx_type_59_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_251 = null,
};

pub const value_zx_type_252_f47a528fe3999e4825e51b818f48ae0051b6bc27266259ed0b6b499f41ce5434 = struct {
    context: value_zx_type_92_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea,
    name: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_252 = null,
};

pub const value_zx_type_253_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    binding_names: []const []const u8,
    binding_types: []const u32,
    depth: u64,
    names: []const ?[]const u8,
    table: *const zx_type_62,
    type_id: u32,
    zx_origin: ?*const zx_type_253 = null,
};

pub const value_zx_type_255_bd5cde306a9184c1dd5f19d89241557a288445ac299b32af3954003bd39dc874 = struct {
    name: ?[]const u8,
    names: []const []const u8,
    required: bool,
    type_id: u32,
    types: []const u32,
    zx_origin: ?*const zx_type_255 = null,
};

pub const value_zx_type_256_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731 = struct {
    contracts: []const *const zx_type_36,
    control: []const *const zx_type_39,
    expressions: []const *const zx_type_28,
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_fallible: []const bool,
    native_modules: []const ?u32,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_29,
    roots: []const ?u32,
    stores: []const *const zx_type_48,
    zx_origin: ?*const zx_type_256 = null,
};

pub const value_zx_type_261_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b = struct {
    functions: value_zx_type_256_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_261 = null,
};

pub const value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290 = struct {
    called: *const zx_type_257,
    context: value_zx_type_261_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b,
    frames: []const *const zx_type_259,
    names: []const []const u8,
    sources: []const *const zx_type_260,
    unknown: bool,
    zx_origin: ?*const zx_type_264 = null,
};

pub const value_zx_type_265_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea = struct {
    context: value_zx_type_261_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b,
    contracts: *const zx_type_36,
    control: *const zx_type_39,
    expression: u32,
    expressions: *const zx_type_28,
    program: bool,
    root: ?u32,
    stores: bool,
    zx_origin: ?*const zx_type_265 = null,
};

pub const value_zx_type_266_5821a6631fd0a2b5d5f68275f533e0b86f2430edbf1471339d13b94e742690d5 = struct {
    control: *const zx_type_39,
    expressions: *const zx_type_28,
    state: value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_266 = null,
};

pub const value_zx_type_267_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    source: u64,
    state: value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_267 = null,
};

pub const value_zx_type_268_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    contracts: *const zx_type_36,
    state: value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_268 = null,
};

pub const value_zx_type_269_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    frame: *const zx_type_259,
    state: value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_269 = null,
};

pub const value_zx_type_270_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    seen: *const zx_type_257,
    zx_origin: ?*const zx_type_270 = null,
};

pub const value_zx_type_271_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    fresh: bool,
    seen: *const zx_type_257,
    zx_origin: ?*const zx_type_271 = null,
};

pub const value_zx_type_272_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expressions: *const zx_type_28,
    index: u64,
    zx_origin: ?*const zx_type_272 = null,
};

pub const value_zx_type_273_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    names: []const []const u8,
    tables: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    type_id: u32,
    zx_origin: ?*const zx_type_273 = null,
};

pub const value_zx_type_274_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    expressions: *const zx_type_28,
    index: u64,
    names: []const []const u8,
    tables: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_274 = null,
};

pub const value_zx_type_275_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    index: u64,
    state: value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_275 = null,
};

pub const value_zx_type_276_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268 = struct {
    body: value_zx_type_55_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80,
    max_offset: u64,
    zx_origin: ?*const zx_type_276 = null,
};

pub const value_zx_type_277_3403bced3238582f4651b52b5d76688e0dab464cb25a410da69862695487fda5 = struct {
    max_offset: u64,
    unit: value_zx_type_67_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5,
    zx_origin: ?*const zx_type_277 = null,
};

pub const value_zx_type_278_56513ec0a3f7b0e8fe4c027e5a3dc9f234c7819d1970f29b9e830566c787d458 = struct {
    concurrent: bool,
    enabled: bool,
    functions: value_zx_type_117_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_278 = null,
};

pub const value_zx_type_279_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a = struct {
    domains: value_zx_type_161_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    layout: value_zx_type_169_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    references: []const bool,
    returns: []const bool,
    zx_origin: ?*const zx_type_279 = null,
};

pub const value_zx_type_280_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134 = struct {
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    prepared: value_zx_type_279_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a,
    snapshots: value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_280 = null,
};

pub const value_zx_type_281_bcdb98c2112c7ef8c38aec6ac62cd8a1517a99f368050adc47ee5c23b76f23a2 = struct {
    index: u64,
    table: value_zx_type_54_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8,
    valid: bool,
    zx_origin: ?*const zx_type_281 = null,
};

pub const value_zx_type_282_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    child_end: u64,
    field_end: u64,
    index: u64,
    name_end: u64,
    scalar_count: u64,
    table: *const zx_type_62,
    valid: bool,
    zx_origin: ?*const zx_type_282 = null,
};

pub const value_zx_type_283_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    after_underscore: bool,
    index: u64,
    kind: zx_type_70,
    name: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_283 = null,
};

pub const value_zx_type_284_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    ascending: bool,
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_284 = null,
};

pub const value_zx_type_285_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    owner: u64,
    table: *const zx_type_62,
    valid: bool,
    values: []const u32,
    zx_origin: ?*const zx_type_285 = null,
};

pub const value_zx_type_286_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    errors: bool,
    first: u64,
    index: u64,
    valid: bool,
    values: []const []const u8,
    zx_origin: ?*const zx_type_286 = null,
};

pub const value_zx_type_287_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    first: u64,
    index: u64,
    member: []const u8,
    unique: bool,
    values: []const []const u8,
    zx_origin: ?*const zx_type_287 = null,
};

pub const value_zx_type_288_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_62,
    valid: bool,
    zx_origin: ?*const zx_type_288 = null,
};

pub const value_zx_type_289_49129128bed2eab4847d5108d0ed3c4d32810f9cdd95b1d04dcc61383544ee70 = struct { value_zx_type_69_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_289, };

pub const value_zx_type_290_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct { value_zx_type_69_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, bool, ?*const zx_type_290, };

pub const value_zx_type_291_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct { value_zx_type_69_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, bool, bool, ?*const zx_type_291, };

pub const value_zx_type_292_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    index: u64,
    input: value_zx_type_77_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    valid: bool,
    zx_origin: ?*const zx_type_292 = null,
};

pub const value_zx_type_293_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    index: u64,
    input: value_zx_type_81_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    next: u64,
    valid: bool,
    zx_origin: ?*const zx_type_293 = null,
};

pub const value_zx_type_294_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    block: u64,
    control: *const zx_type_39,
    end: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_294 = null,
};

pub const value_zx_type_295_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    block: u64,
    bodies: []const u32,
    end: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_295 = null,
};

pub const value_zx_type_296_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d = struct {
    branches: u64,
    constants: u64,
    control: *const zx_type_39,
    destructures: u64,
    evaluations: u64,
    index: u64,
    parallels: u64,
    results: u64,
    selections: u64,
    setters: u64,
    valid: bool,
    zx_origin: ?*const zx_type_296 = null,
};

pub const value_zx_type_297_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    block: u64,
    control: *const zx_type_39,
    valid: bool,
    zx_origin: ?*const zx_type_297 = null,
};

pub const value_zx_type_298_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    depths: []const u64,
    owned: []const bool,
    root: u64,
    zx_origin: ?*const zx_type_298 = null,
};

pub const value_zx_type_299_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, void, ?*const zx_type_299, };

pub const value_zx_type_300_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_300, };

pub const value_zx_type_301_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    block: u64,
    control: *const zx_type_39,
    depths: []const u64,
    edge: u64,
    index: u64,
    owned: []const bool,
    valid: bool,
    zx_origin: ?*const zx_type_301 = null,
};

pub const value_zx_type_302_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: bool,
    source: []const bool,
    zx_origin: ?*const zx_type_302 = null,
};

pub const value_zx_type_303_747f72635b917529c60fe3ddd4b139add9d19e47868d0437d3b1eaa0e5a06cbe = struct { value_zx_type_276_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, ?*const zx_type_303, };

pub const value_zx_type_304_9fa353a13aef4fcbd68e9e65c345217702e70a477c2e8b34bab582e5f919b0ab = struct { value_zx_type_276_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, bool, ?*const zx_type_304, };

pub const value_zx_type_305_5f210d33b8c76198cb39e577e40573158f40124c771140f4877c3fb884267c96 = struct { value_zx_type_276_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, bool, bool, ?*const zx_type_305, };

pub const value_zx_type_306_cdb50b0313c74b116f115cfa35a04b06b60d43ce9f1153dc7dfaea33e5997abb = struct { value_zx_type_276_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, bool, bool, bool, ?*const zx_type_306, };

pub const value_zx_type_307_e076203cc44cd5b3cd45d256176e9fc34055f2ae1a060fa3e29d9588d8f4ce7d = struct { value_zx_type_276_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, bool, bool, bool, bool, ?*const zx_type_307, };

pub const value_zx_type_308_637585634439c917a0fd688f9e35fe14f1c43532b907c828e3a10b2df0602216 = struct { value_zx_type_276_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, bool, bool, bool, bool, bool, ?*const zx_type_308, };

pub const value_zx_type_309_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    index: u64,
    input: value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    valid: bool,
    zx_origin: ?*const zx_type_309 = null,
};

pub const value_zx_type_310_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    index: u64,
    input: value_zx_type_86_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    valid: bool,
    zx_origin: ?*const zx_type_310 = null,
};

pub const value_zx_type_311_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    contracts: *const zx_type_36,
    index: u64,
    max_offset: u64,
    valid: bool,
    zx_origin: ?*const zx_type_311 = null,
};

pub const value_zx_type_312_ed98ab2d684155f0f16edf3c906e8b7cce9beb0c415885713abde878f5ffabc6 = struct { value_zx_type_87_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, ?*const zx_type_312, };

pub const value_zx_type_313_758dce47268ce260391b79fcce19430100f29f81aa06dca556ac6c937c9b34ac = struct { value_zx_type_87_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, bool, ?*const zx_type_313, };

pub const value_zx_type_314_b987e2a8336dd5fe5154834b3b39be96d75a9414e18010c03cead626fdd2ff2d = struct { value_zx_type_277_3403bced3238582f4651b52b5d76688e0dab464cb25a410da69862695487fda5, ?*const zx_type_314, };

pub const value_zx_type_315_c477267367d27377853d9ec182fe65dcbbfffab8a243ed9c9f1d1562cb3522f2 = struct { value_zx_type_277_3403bced3238582f4651b52b5d76688e0dab464cb25a410da69862695487fda5, bool, ?*const zx_type_315, };

pub const value_zx_type_316_aeadd0682a50b343e99877ebd4af36830054f6a607a8d6606bbe41c64764a2cf = struct { value_zx_type_277_3403bced3238582f4651b52b5d76688e0dab464cb25a410da69862695487fda5, bool, bool, ?*const zx_type_316, };

pub const value_zx_type_317_2005be18f3f738830a7095b8f8338aa4032ca575f11fcda5d9048025bf5b4906 = struct {
    context: value_zx_type_66_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_317 = null,
};

pub const value_zx_type_318_264b57f9398a8c89b636a6199fb1a45d5519286c3c0ab2e406e46725ab40cb1a = struct { value_zx_type_68_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, ?*const zx_type_318, };

pub const value_zx_type_319_e293f9444885f043aac5ffd18424308b3341a05faa07ca25362527b432f43c42 = struct { value_zx_type_68_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, bool, ?*const zx_type_319, };

pub const value_zx_type_320_754e542ded2d437ac5b84a31ee26e4809bd90d9d5604a44a42444a4627a2c061 = struct { value_zx_type_68_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, bool, bool, ?*const zx_type_320, };

pub const value_zx_type_321_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0 = struct {
    index: u64,
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    valid: bool,
    zx_origin: ?*const zx_type_321 = null,
};

pub const value_zx_type_322_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    offset: u64,
    separator: u64,
    source: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_322 = null,
};

pub const value_zx_type_323_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    offset: u64,
    source: []const u8,
    start: u64,
    valid: bool,
    zx_origin: ?*const zx_type_323 = null,
};

pub const value_zx_type_324_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    high: u8,
    index: u64,
    low: u8,
    remaining: u64,
    text: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_324 = null,
};

pub const value_zx_type_325_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    names: []const []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_325 = null,
};

pub const value_zx_type_326_b1b23fbb7680b8cb1b3dadbfa986aa274ef1483cb6efee44a47ca580481a8e23 = struct {
    count: u64,
    found: bool,
    index: u64,
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_326 = null,
};

pub const value_zx_type_327_efdd75a5e607c61dffb07c66411d75c96f1f2b811307e711dcc2093faf9ae2b2 = struct { value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, ?*const zx_type_327, };

pub const value_zx_type_328_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct { value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, ?*const zx_type_328, };

pub const value_zx_type_329_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06 = struct { value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, bool, ?*const zx_type_329, };

pub const value_zx_type_330_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8 = struct { value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, bool, bool, ?*const zx_type_330, };

pub const value_zx_type_331_461a038225996c015433bf0a5fb2c9e6a36f43e598f85eccd7a2eee1e984e893 = struct {
    index: u64,
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    type_count: u64,
    valid: bool,
    zx_origin: ?*const zx_type_331 = null,
};

pub const value_zx_type_332_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    ids: []const u32,
    index: u64,
    names: []const []const u8,
    type_count: u64,
    valid: bool,
    zx_origin: ?*const zx_type_332 = null,
};

pub const value_zx_type_333_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_333 = null,
};

pub const value_zx_type_334_df87d4e4c94482fd017e977a114eba826861ac6af356c343aea16855cac7c373 = struct {
    index: u64,
    module: u64,
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    owner: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_334 = null,
};

pub const value_zx_type_335_ea1b7ae541093ece52c59f2de2f23eb593426bae77184c88543e9788bf3186e6 = struct {
    count: u64,
    index: u64,
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: []const u8,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_335 = null,
};

pub const value_zx_type_336_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_336 = null,
};

pub const value_zx_type_337_4bb438ff01f237569bb9646dc2578b71e2a1e16fa8fe9e4b0b9d926ac5640cd1 = struct { value_zx_type_91_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, ?*const zx_type_337, };

pub const value_zx_type_338_80fa3f09fde2ea8660c1d43e969ee3d68c4cda0e85a50de87ab5f1fb43c5c390 = struct { value_zx_type_91_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, ?*const zx_type_338, };

pub const value_zx_type_339_ee123d0c630fe117230fb019f7a85eb490b50840dfc1899f8c57c79c91c3899f = struct { value_zx_type_91_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, bool, ?*const zx_type_339, };

pub const value_zx_type_340_0e0d5c43ce78ae1236d49a3faeba388d032732faba89517792623bca4c309c09 = struct { value_zx_type_91_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, bool, bool, ?*const zx_type_340, };

pub const value_zx_type_341_39550f691687970b5dbfe4b46111ad44602515eab5c342208f2139f13ca4b8cf = struct {
    declared: bool,
    index: u64,
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: ?[]const u8,
    type_id: u64,
    valid: bool,
    zx_origin: ?*const zx_type_341 = null,
};

pub const value_zx_type_342_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    declared: bool,
    found: bool,
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u64,
    zx_origin: ?*const zx_type_342 = null,
};

pub const value_zx_type_343_ee123d0c630fe117230fb019f7a85eb490b50840dfc1899f8c57c79c91c3899f = struct {
    context: value_zx_type_91_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_343 = null,
};

pub const value_zx_type_344_d96b64d9a0cdeb5c4d9519515e9692cefd4e8b6e0fd3a4acd43c7a6cb54deb90 = struct { value_zx_type_91_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, bool, bool, bool, ?*const zx_type_344, };

pub const value_zx_type_345_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
    zx_origin: ?*const zx_type_345 = null,
};

pub const value_zx_type_346_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    target: zx_type_60,
    zx_origin: ?*const zx_type_346 = null,
};

pub const value_zx_type_347_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_347 = null,
};

pub const value_zx_type_348_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    limit: u64,
    path: []const u8,
    paths: []const []const u8,
    repeated: bool,
    zx_origin: ?*const zx_type_348 = null,
};

pub const value_zx_type_349_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_349 = null,
};

pub const value_zx_type_350_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    paths: []const []const u8,
    slot_types: []const u32,
    table: *const zx_type_62,
    valid: bool,
    zx_origin: ?*const zx_type_350 = null,
};

pub const value_zx_type_351_009b209c29dfed37d6f0ddf10651eb819801430299ea03fd6bf9a11471606d6e = struct { value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, ?*const zx_type_351, };

pub const value_zx_type_352_9068dcb27588fc549cd15008d3bd15e507480c6631115fd15614e1d02077b29f = struct { value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, bool, ?*const zx_type_352, };

pub const value_zx_type_353_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    available: *const zx_type_48,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_48,
    slots: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_353 = null,
};

pub const value_zx_type_354_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
    zx_origin: ?*const zx_type_354 = null,
};

pub const value_zx_type_355_c6f082592747bfb97c58ad22751dc4616b503541b82be1a501dcd45ec633ad7a = struct {
    condition_type: u32,
    context: value_zx_type_106_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    first: u64,
    index: u64,
    result_type: u32,
    valid: bool,
    zx_origin: ?*const zx_type_355 = null,
};

pub const value_zx_type_356_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed = struct {
    context: value_zx_type_106_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_356 = null,
};

pub const value_zx_type_357_c65f606cad38c9bde5a22d060283f020c6df16f448945ff8555407599cee695f = struct {
    context: value_zx_type_106_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    first: u64,
    index: u64,
    type_first: u64,
    valid: bool,
    zx_origin: ?*const zx_type_357 = null,
};

pub const value_zx_type_358_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    field: u64,
    first: u64,
    found: bool,
    index: u64,
    indices: []const u32,
    limit: u64,
    zx_origin: ?*const zx_type_358 = null,
};

pub const value_zx_type_359_0226e38872eacdc3e44e606ef924db3a519c6f4fa1a6333f3794af990383ea77 = struct {
    context: value_zx_type_106_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_12,
    source: u32,
    valid: bool,
    zx_origin: ?*const zx_type_359 = null,
};

pub const value_zx_type_360_88d54f056223ef8ac2f93da2e10b59b5e31b44b0c33166e8b7201a394c231718 = struct {
    check: value_zx_type_107_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed,
    count: u64,
    fields: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_360 = null,
};

pub const value_zx_type_361_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077 = struct {
    field: ?u32,
    fields: []const ?u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    task: u32,
    tasks: []const u32,
    zx_origin: ?*const zx_type_361 = null,
};

pub const value_zx_type_362_f3a9fcf220984d9746551b1ea2c8c509f64c311c9dd8964488d8c18fdae2ce12 = struct {
    check: value_zx_type_107_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_362 = null,
};

pub const value_zx_type_363_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    captures: []const u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    symbol: u32,
    zx_origin: ?*const zx_type_363 = null,
};

pub const value_zx_type_364_0226e38872eacdc3e44e606ef924db3a519c6f4fa1a6333f3794af990383ea77 = struct {
    context: value_zx_type_106_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    context_type: u32,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_13,
    valid: bool,
    zx_origin: ?*const zx_type_364 = null,
};

pub const value_zx_type_365_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6 = struct {
    expressions: *const zx_type_28,
    functions: value_zx_type_105_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    stores: *const zx_type_48,
    symbols: *const zx_type_31,
    table: *const zx_type_62,
    valid: bool,
    zx_origin: ?*const zx_type_365 = null,
};

pub const value_zx_type_366_21e4f8ef344e503f822fcb829467993616ac72b250c11649bad4e903e93caa0c = struct {
    has_ensures: bool,
    index: u64,
    program: value_zx_type_113_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    valid: bool,
    zx_origin: ?*const zx_type_366 = null,
};

pub const value_zx_type_367_7695a4d364d66a6902b4af6ac6744d237e533b15944969bca7543d8f0ffc99af = struct { value_zx_type_113_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_367, };

pub const value_zx_type_368_b4c00b0680a164f9ad85cafef49c2f1d31566b1a676a14d85e4570178e088fb9 = struct { value_zx_type_113_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, bool, ?*const zx_type_368, };

pub const value_zx_type_369_79b96ffa2e891f4534c9a8b770935af0223aeb89cda66f40793025b64b74d946 = struct { value_zx_type_113_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, bool, bool, ?*const zx_type_369, };

pub const value_zx_type_370_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    index: u64,
    symbols: *const zx_type_31,
    valid: bool,
    zx_origin: ?*const zx_type_370 = null,
};

pub const value_zx_type_371_0c3c634be52883a604be7f6c9f533fa83ee9fcdc9d677f14a435e37a442cd739 = struct {
    index: u64,
    request: value_zx_type_103_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d,
    valid: bool,
    zx_origin: ?*const zx_type_371 = null,
};

pub const value_zx_type_372_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    all: bool,
    bodies: []const u32,
    end: u64,
    index: u64,
    returns: []const bool,
    zx_origin: ?*const zx_type_372 = null,
};

pub const value_zx_type_373_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    block: u64,
    control: *const zx_type_39,
    returns: []const bool,
    zx_origin: ?*const zx_type_373 = null,
};

pub const value_zx_type_374_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_28,
    index: u64,
    limit: u64,
    valid: bool,
    zx_origin: ?*const zx_type_374 = null,
};

pub const value_zx_type_375_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const bool,
    source: []const ?u32,
    zx_origin: ?*const zx_type_375 = null,
};

pub const value_zx_type_376_3a2d3372119d766901b9e73d1d1a1cb69e32e364aec8da316dab97f3e55fcf11 = struct {
    concurrent: bool,
    functions: value_zx_type_117_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    index: u64,
    values: []const bool,
    zx_origin: ?*const zx_type_376 = null,
};

pub const value_zx_type_377_ea224267afd93fd3f3d4000179ad152ebe9ec0b03599ef65b3732cadbbdff343 = struct { value_zx_type_278_56513ec0a3f7b0e8fe4c027e5a3dc9f234c7819d1970f29b9e830566c787d458, ?*const zx_type_377, };

pub const value_zx_type_378_ec65d43862fabc1ba3f66365439915d1135e981063a601844d880216f7595104 = struct { value_zx_type_278_56513ec0a3f7b0e8fe4c027e5a3dc9f234c7819d1970f29b9e830566c787d458, []const bool, ?*const zx_type_378, };

pub const value_zx_type_379_46c5d60b64cf56cb771da46a6165931fb8fa4e77cc44efffaceea6431db220d7 = struct { value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, ?*const zx_type_379, };

pub const value_zx_type_380_3b09208d71e6eced43b0d3100ffc3c9ef0100a82597dbbcaeaf6c94ce042306b = struct { value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, []const bool, ?*const zx_type_380, };

pub const value_zx_type_381_75ff338b263cfa5d9d312b9a70bf4ae14f153dc381571b5760f3c5b8b914ebf9 = struct { value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, []const bool, []const bool, ?*const zx_type_381, };

pub const value_zx_type_382_e118d84f4abede871251d81ca2d003f253902bfbf372e406dc4b726b98d0cd5f = struct { value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, []const bool, []const bool, []const bool, ?*const zx_type_382, };

pub const value_zx_type_383_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const bool,
    source: []const []const u8,
    zx_origin: ?*const zx_type_383 = null,
};

pub const value_zx_type_384_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const []const u8,
    zx_origin: ?*const zx_type_384 = null,
};

pub const value_zx_type_385_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    found: bool,
    index: u64,
    symbol: u32,
    values: []const u32,
    zx_origin: ?*const zx_type_385 = null,
};

pub const value_zx_type_386_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, void, ?*const zx_type_386, };

pub const value_zx_type_387_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    facts: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    symbol: u32,
    zx_origin: ?*const zx_type_387 = null,
};

pub const value_zx_type_388_4373da08621bcbc23abd1852eb2d5ba558f05027208e827b7568eb84bcb01181 = struct {
    expressions: *const zx_type_28,
    state: value_zx_type_121_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    zx_origin: ?*const zx_type_388 = null,
};

pub const value_zx_type_389_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u64, ?u64, ?*const zx_type_389, };

pub const value_zx_type_390_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const bool, ?bool, ?*const zx_type_390, };

pub const value_zx_type_391_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, []const u32, ?*const zx_type_391, };

pub const value_zx_type_392_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_122, void, ?*const zx_type_392, };

pub const value_zx_type_393_60476d3f86ecd6f6b546dce9803cb26d53be6cc5e23c28d693274b526d5c73b1 = struct {
    control: *const zx_type_39,
    first: u64,
    index: u64,
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_393 = null,
};

pub const value_zx_type_394_32f7e74537e9df233607e6adcd543ab93f704c9753770d3c59de323bff658ff9 = struct {
    context: value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0,
    first: u64,
    index: u64,
    result: value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063,
    zx_origin: ?*const zx_type_394 = null,
};

pub const value_zx_type_395_b4c00b0680a164f9ad85cafef49c2f1d31566b1a676a14d85e4570178e088fb9 = struct {
    activity: value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    index: u64,
    zx_origin: ?*const zx_type_395 = null,
};

pub const value_zx_type_396_87ce98851c74e4bb881d7b286d23c668bc10ac8d52be427cc29c9d7eeacaac3e = struct {
    count: u64,
    first: u64,
    index: u64,
    owner: u64,
    program: value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    result: value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063,
    zx_origin: ?*const zx_type_396 = null,
};

pub const value_zx_type_397_6d9798f49879817ed1bf2a66248bb033e4380a67df59cd5195609fdd4517fd57 = struct {
    count: u64,
    first: u64,
    index: u64,
    program: value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    result: value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063,
    type_first: u64,
    zx_origin: ?*const zx_type_397 = null,
};

pub const value_zx_type_398_b8ec70fbd49037c4f5f15832ef24774698f9ceaf2b6c8bda56f20308b14ddd6f = struct {
    depth: u64,
    first: u64,
    flags: u64,
    index: u64,
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    values: []const u32,
    zx_origin: ?*const zx_type_398 = null,
};

pub const value_zx_type_399_c783738b37c1abb5587b595a894032f687198bb2afdfedcf3224868e2b3ee6ce = struct {
    depth: u64,
    expressions: *const zx_type_28,
    first: u64,
    flags: u64,
    index: u64,
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_399 = null,
};

pub const value_zx_type_400_4cc958f044815e7193e188aa8d2b374a7d7b5bdc35e292ff41875ed7f5ad06b2 = struct {
    count: u64,
    expressions: *const zx_type_28,
    facts: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    first: u64,
    index: u64,
    zx_origin: ?*const zx_type_400 = null,
};

pub const value_zx_type_401_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_28,
    first: u64,
    index: u64,
    result: ?u32,
    symbol: u32,
    zx_origin: ?*const zx_type_401 = null,
};

pub const value_zx_type_402_c3e968df1f71f0e1fe9002a2718c62d7f895e7e395e15c7a9c8aea2cadf96ee5 = struct {
    depth: u64,
    expressions: *const zx_type_28,
    first: u64,
    flags: u64,
    index: u64,
    owner: u64,
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_402 = null,
};

pub const value_zx_type_403_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    active: []const bool,
    count: u64,
    first: u64,
    index: u64,
    symbols: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_403 = null,
};

pub const value_zx_type_404_5858107fbdadcc083e312bfcf504b1d0b97b4200ec30bf4c6f639637dc9c91ba = struct {
    activity: value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    count: u64,
    expressions: *const zx_type_28,
    first: u64,
    index: u64,
    zx_origin: ?*const zx_type_404 = null,
};

pub const value_zx_type_405_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    control: *const zx_type_39,
    count: u64,
    expressions: *const zx_type_28,
    first: u64,
    index: u64,
    no: bool,
    valid: bool,
    yes: bool,
    zx_origin: ?*const zx_type_405 = null,
};

pub const value_zx_type_406_28ec67a1b3512058011fb8c36c7fbea177d57a2436abccdef3b72983a75cfa1b = struct {
    count: u64,
    first: u64,
    has_default: bool,
    index: u64,
    program: value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_406 = null,
};

pub const value_zx_type_407_597b115a29e5acb3e5825fd5e696f573a33b81233a7f6927d1c589529f09ca26 = struct {
    count: u64,
    first: u64,
    found: bool,
    index: u64,
    program: value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    value: u64,
    zx_origin: ?*const zx_type_407 = null,
};

pub const value_zx_type_408_3a1785f07cd24dcb5929359c13d36b4bf63681e93136d07868893d9f0e26c2cb = struct {
    captures: u64,
    depth: u64,
    facts: u64,
    first: u64,
    index: u64,
    payload: u64,
    program: value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    state: value_zx_type_130_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_408 = null,
};

pub const value_zx_type_410_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const zx_type_122, ?zx_type_122, ?*const zx_type_410, };

pub const value_zx_type_411_f02a620810820dcc60ddd15370d805d29f7cdde1cf6896338bfedd10fa5a7da0 = struct {
    context: value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0,
    result: value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063,
    zx_origin: ?*const zx_type_411 = null,
};

pub const value_zx_type_412_8c66a5b9a54b9bbe92468e75907297d74c648c030a68ba8e2cecc6553e709b32 = struct { value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0, ?*const zx_type_412, };

pub const value_zx_type_413_f02a620810820dcc60ddd15370d805d29f7cdde1cf6896338bfedd10fa5a7da0 = struct { value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0, value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, ?*const zx_type_413, };

pub const value_zx_type_414_060659a3386750ea3402036c95d9fcb755a30cecd1e8a387129a868f86ad8ba8 = struct { value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0, value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, ?*const zx_type_414, };

pub const value_zx_type_415_39ecf2710d0861d63680882cb4073ed50aa0c6c119d6b03d76c4753c0f72cf0f = struct { value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0, value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, bool, ?*const zx_type_415, };

pub const value_zx_type_416_ba3b383aaa977febdfef4c3d05f94b7f246cc4463eacc2dd8aec1237b528ec0b = struct { value_zx_type_126_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0, value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, value_zx_type_133_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, bool, bool, ?*const zx_type_416, };

pub const value_zx_type_417_b202a6b9a97b84d925d8c00ee25721e5ebf31883d49d2e83037938798eb9ee6a = struct { value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, value_zx_type_125_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_417, };

pub const value_zx_type_418_914afb2d82744a67bc682fe94cfae502f792fdb14f070fa88351f0b5d6b2d203 = struct { value_zx_type_124_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, value_zx_type_125_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, bool, ?*const zx_type_418, };

pub const value_zx_type_419_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    capture: u64,
    expressions: *const zx_type_28,
    index: u64,
    symbols: *const zx_type_31,
    table: *const zx_type_62,
    valid: bool,
    zx_origin: ?*const zx_type_419 = null,
};

pub const value_zx_type_420_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const zx_type_11,
    zx_origin: ?*const zx_type_420 = null,
};

pub const value_zx_type_421_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    binding: u64,
    constants: []const u32,
    edge: u64,
    expressions: *const zx_type_28,
    index: u64,
    table: *const zx_type_62,
    uses: []const u64,
    valid: bool,
    zx_origin: ?*const zx_type_421 = null,
};

pub const value_zx_type_422_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_28,
    index: u64,
    table: *const zx_type_62,
    uses: []const u64,
    valid: bool,
    zx_origin: ?*const zx_type_422 = null,
};

pub const value_zx_type_423_c300e804702735c272af3dc9237d24b99a108a57cb3a9dd6f1ea306197d45e80 = struct { value_zx_type_153_d67de9150a29b2c86fcfaa670164fb137ade9312feda415779572f647ca40086, ?*const zx_type_423, };

pub const value_zx_type_424_bd613536ed4e31fa9c4b984dfa3963a789b779a01214b9f7baf6c42f76d22bf5 = struct { value_zx_type_153_d67de9150a29b2c86fcfaa670164fb137ade9312feda415779572f647ca40086, bool, ?*const zx_type_424, };

pub const value_zx_type_425_f06ea3741345e40877bb331df41fcc2ce19c2b659365442e7f817f87e8313e36 = struct { value_zx_type_153_d67de9150a29b2c86fcfaa670164fb137ade9312feda415779572f647ca40086, bool, bool, ?*const zx_type_425, };

pub const value_zx_type_426_4131923c55f52de8d72edffece19050837767ea060906fc6aeb35c95f6468cdd = struct { value_zx_type_153_d67de9150a29b2c86fcfaa670164fb137ade9312feda415779572f647ca40086, bool, bool, bool, ?*const zx_type_426, };

pub const value_zx_type_427_4854cde39e36b19a70d421960f863c814d73da5cf3181d8fbe8174fcb46ecdcd = struct {
    target: value_zx_type_65_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_427 = null,
};

pub const value_zx_type_428_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    index: u64,
    references: []const bool,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_428 = null,
};

pub const value_zx_type_429_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    expressions: *const zx_type_28,
    index: u64,
    kind: zx_type_11,
    locals: []const bool,
    payload: u64,
    zx_origin: ?*const zx_type_429 = null,
};

pub const value_zx_type_430_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    body: u64,
    condition: u64,
    count: u64,
    locals: []const bool,
    reachable: []const bool,
    symbols: u64,
    zx_origin: ?*const zx_type_430 = null,
};

pub const value_zx_type_431_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_28,
    index: u64,
    locals: []const bool,
    reachable: []const bool,
    remaining: u64,
    zx_origin: ?*const zx_type_431 = null,
};

pub const value_zx_type_432_d42088e18bb5c05cf1e3a3d9851c1dd08d41eae9e1223a6150bd284f2dc08b77 = struct {
    count: []const u64,
    first: []const u64,
    index: u64,
    program: value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    symbols: []const u64,
    zx_origin: ?*const zx_type_432 = null,
};

pub const value_zx_type_433_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    locals: []const bool,
    symbols: []const u64,
    zx_origin: ?*const zx_type_433 = null,
};

pub const value_zx_type_434_4c9a900895778ef8a8b8af9807bd68428ea35c59b77acdf07c33728d1d771352 = struct {
    active: bool,
    cached_count: []const u64,
    cached_first: []const u64,
    cached_positions: []const u64,
    children: []const u64,
    field_indices: []const u64,
    heads: []const u64,
    index: u64,
    item: u64,
    next: []const u64,
    parents: []const u64,
    phase: zx_type_170,
    place_types: []const u32,
    program: value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    tails: []const u64,
    zx_origin: ?*const zx_type_434 = null,
};

pub const value_zx_type_435_1b2191a44235c6e6b65e1ae9ab1c3d223553737681d5d92d9e9cae41a381d262 = struct {
    active: bool,
    found: bool,
    index: value_zx_type_173_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    key: value_zx_type_174_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_435 = null,
};

pub const value_zx_type_436_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, []const u64, ?*const zx_type_436, };

pub const value_zx_type_437_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    position: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_437 = null,
};

pub const value_zx_type_438_2a73385728db51fa9518b55ca4dd797e91049a447a89c6c5efe9d790e5c08e2e = struct { value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, ?*const zx_type_438, };

pub const value_zx_type_439_767b69074202a272a12100b84e23109da965767802298cfb5e4fed280635514e = struct { value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, ?*const zx_type_439, };

pub const value_zx_type_440_46b777fb29a6ec83f56ee22ad77d1bbbd13caf8e6a27064012c94c0eb1544938 = struct { value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, ?*const zx_type_440, };

pub const value_zx_type_441_18fcb2898d1d7204e87db706f073fcf51d79752c11063fe602073e375e06acd1 = struct { value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_161_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_441, };

pub const value_zx_type_442_2cde30861016700fbcc37ec0e53f358a870f83b3d9276e54dca5abfa42381dbf = struct { value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_161_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_168_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937, ?*const zx_type_442, };

pub const value_zx_type_443_fc9d1607bfc29c393e85973469418c6449deb36cf03f440f10859d1b0e6cf2c1 = struct { value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_161_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_168_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937, value_zx_type_169_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d, ?*const zx_type_443, };

pub const value_zx_type_444_df87d4e4c94482fd017e977a114eba826861ac6af356c343aea16855cac7c373 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    state: zx_type_162,
    zx_origin: ?*const zx_type_444 = null,
};

pub const value_zx_type_445_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_162, void, ?*const zx_type_445, };

pub const value_zx_type_446_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    children: []const u64,
    count: u64,
    first: u64,
    index: u64,
    source: []const u64,
    zx_origin: ?*const zx_type_446 = null,
};

pub const value_zx_type_447_03ceda26995807c2aa6530d3178a20e89911f37af4bad09be3c9b210bc3682ce = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    target: u64,
    type_id: u32,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_447 = null,
};

pub const value_zx_type_448_20d7d99279e33ed98c39ff3a89f60b0602618a66dfe76434242c1e24534deee7 = struct {
    active: bool,
    ascending: bool,
    fact: u64,
    facts: []const u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    id: u64,
    layout: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    leaving: bool,
    references: []const bool,
    root: u64,
    states: []const zx_type_162,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_448 = null,
};

pub const value_zx_type_449_b96c48974ce17ef2b8be551c68efc904286af193386b87a21ad68406a5672c15 = struct {
    active: bool,
    cache: value_zx_type_195_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    found: bool,
    left: u64,
    right: u64,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_449 = null,
};

pub const value_zx_type_450_4b4ea4009453ea5e4d3d79e2158cdc223b3d2c1404741f1be6d92e28595818e4 = struct {
    active: bool,
    cache: value_zx_type_195_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    capacity: u64,
    grow: bool,
    index: u64,
    left: u64,
    right: u64,
    value: u64,
    zx_origin: ?*const zx_type_450 = null,
};

pub const value_zx_type_451_fddf701302546dc5c12ecdb7d8719eb57b5e534ac713eb9744231ee909d8dc70 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    same: bool,
    type_id: u32,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_451 = null,
};

pub const value_zx_type_452_b3760cb020967af5517f45e8ca01d64dcc589438ca8342340b78221ceef17d6a = struct {
    action: zx_type_194,
    cache: value_zx_type_195_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    children: []const u64,
    first: []const u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    indices: []const u64,
    left: []const u64,
    paired: bool,
    references: []const bool,
    right: []const u64,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_452 = null,
};

pub const value_zx_type_453_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: u64,
    facts: []const u64,
    memo: []const u64,
    places: u64,
    states: []const zx_type_162,
    zx_origin: ?*const zx_type_453 = null,
};

pub const value_zx_type_454_84331d6a4a43806456ffa46c6afa1bd16dcd6bebddd17f96d6eddd9ac3c6fff1 = struct { value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_279_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a, ?*const zx_type_454, };

pub const value_zx_type_455_56d3a3384af94c4c5beea8da80c665c922686500c24f911e92fe4db704c5a3bf = struct { value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_279_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a, value_zx_type_206_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf, ?*const zx_type_455, };

pub const value_zx_type_456_797fedc00020e01168f99323a87b071e9e1bdebae23b4195463f8ae8c1241ef7 = struct {
    action: zx_type_203,
    count: u64,
    index: u64,
    layout: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memo_first: u64,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    rewrite_action: zx_type_194,
    saved: value_zx_type_204_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    state_first: u64,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_456 = null,
};

pub const value_zx_type_458_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const zx_type_209, ?zx_type_209, ?*const zx_type_458, };

pub const value_zx_type_459_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_209, void, ?*const zx_type_459, };

pub const value_zx_type_460_463372a636e1a2c93bbb2070e2204f09a436eef0f006e94b3d11fa862ef159e2 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    merge: bool,
    parents: []const u64,
    references: []const bool,
    saved: []const u64,
    source: []const u64,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_460 = null,
};

pub const value_zx_type_461_2b3f0033db751cf78256c30d401a1a8639ee63997cf1909aeaff24112d21a8c6 = struct {
    activation: u64,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    loops: value_zx_type_219_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    references: []const bool,
    seen: bool,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_461 = null,
};

pub const value_zx_type_462_57c8216039667f25f8124cd801f82d6db9b8e64f4e9aa500df6f0cbf67657227 = struct {
    activation: u64,
    changed: bool,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: value_zx_type_183_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    loops: value_zx_type_219_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    references: []const bool,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_462 = null,
};

pub const value_zx_type_463_87c1c976ed99693bb0b79319ced55961e2f09cd998a5c93ecc538e2ca8eb719e = struct {
    count: u64,
    facts: []const u64,
    first: u64,
    index: u64,
    layout: value_zx_type_164_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    local_first: u64,
    locals: u64,
    memory: value_zx_type_205_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    roots: []const u64,
    symbols: []const u64,
    types: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_463 = null,
};

pub const value_zx_type_464_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    flags: []const bool,
    symbols: u64,
    zx_origin: ?*const zx_type_464 = null,
};

pub const value_zx_type_465_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    first: u64,
    flags: []const bool,
    index: u64,
    symbols: []const u64,
    zx_origin: ?*const zx_type_465 = null,
};

pub const value_zx_type_466_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    flags: []const bool,
    index: u64,
    memo: []const u64,
    parents: []const u64,
    zx_origin: ?*const zx_type_466 = null,
};

pub const value_zx_type_467_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u64,
    parents: []const u64,
    zx_origin: ?*const zx_type_467 = null,
};

pub const value_zx_type_468_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    facts: []const u64,
    flags: []const bool,
    index: u64,
    outputs: []const u64,
    roots: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_468 = null,
};

pub const value_zx_type_469_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    first: u64,
    zx_origin: ?*const zx_type_469 = null,
};

pub const value_zx_type_470_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    index: u64,
    slots: *const zx_type_48,
    zx_origin: ?*const zx_type_470 = null,
};

pub const value_zx_type_471_45c9de4479c865238cef7a36dce7217ac4de64b83f4320ae5b044d7e2faff701 = struct {
    active: bool,
    ascending: bool,
    expression: u64,
    expressions: *const zx_type_28,
    found: bool,
    layout: value_zx_type_169_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    position: u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_471 = null,
};

pub const value_zx_type_472_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    children: []const u64,
    count: u64,
    index: u64,
    zx_origin: ?*const zx_type_472 = null,
};

pub const value_zx_type_473_39e74984115c929e88eabd575698c342998222fa7ee1c2957f496eb4bea9c312 = struct { value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_280_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134, ?*const zx_type_473, };

pub const value_zx_type_474_3ef121c2969f416beec22224e6006647d628ebbbd818e782fec8feea9c3aa01c = struct { value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_280_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134, value_zx_type_213_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_474, };

pub const value_zx_type_475_96d59ef42dfaa6f63ae76f96f93bea239e6bf4f0d4040dd0d8e67637a8a19f9b = struct { value_zx_type_103_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, ?*const zx_type_475, };

pub const value_zx_type_476_9412c839c4879a86cd9ae3e0103c9ccf6966a45b6e70cb5541a6200c50920121 = struct { value_zx_type_103_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, ?*const zx_type_476, };

pub const value_zx_type_477_5f75a732777ffa08755b59b1020ff9fec4bc7ca52ab6b7f965350f62bd8d2dd1 = struct { value_zx_type_103_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, ?*const zx_type_477, };

pub const value_zx_type_478_75e08de77d6e56ca845840a6b21d75631fa69d76d0660b98a5fb39e5141e3552 = struct { value_zx_type_103_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, ?*const zx_type_478, };

pub const value_zx_type_479_63158ce2356408fc7d4f3b5e2b0660a165e11792b30c8267f6b16faaede41bc6 = struct { value_zx_type_103_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_213_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_479, };

pub const value_zx_type_480_a252266785ed2c072e72fb23f03640f83fbfcaf61598af22238498adeaab2f72 = struct { value_zx_type_103_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, value_zx_type_155_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_213_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, bool, ?*const zx_type_480, };

pub const value_zx_type_481_6b36136f08b1ecdc688c412d14c48773d44bb759a49656ca1c5672b4211e77b5 = struct { value_zx_type_103_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, bool, ?*const zx_type_481, };

pub const value_zx_type_482_32abba56676d7e1bfae0149cb931913947440d6b9f3ac11995558be847b69fd3 = struct { value_zx_type_103_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, bool, bool, ?*const zx_type_482, };

pub const value_zx_type_483_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: *const zx_type_28,
    index: u64,
    limit: u64,
    valid: bool,
    zx_origin: ?*const zx_type_483 = null,
};

pub const value_zx_type_484_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    members: []const []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_484 = null,
};

pub const value_zx_type_485_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d = struct {
    index: u64,
    modules: value_zx_type_58_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_485 = null,
};

pub const value_zx_type_486_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_486 = null,
};

pub const value_zx_type_487_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    left: []const []const u8,
    right: []const []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_487 = null,
};

pub const value_zx_type_488_baebe69047a6187417aee9fcf2f488ecfe1a2e75d46b45a6e051c442e2cc077b = struct {
    context: value_zx_type_92_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea,
    index: u64,
    name: []const u8,
    owner: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_488 = null,
};

pub const value_zx_type_489_e2046bbbdd123b340ba885225deecccca3eb1df70cd21bf5e0834e01a8367832 = struct { value_zx_type_92_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?*const zx_type_489, };

pub const value_zx_type_490_d0454f4a1a7de6aeeb81f6f933317e2b1cae56f63e59320e6127de9228953b6d = struct { value_zx_type_92_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, ?*const zx_type_490, };

pub const value_zx_type_491_ef0a93c819150b4bd1bdd5e2d698ce3efee444949e0d810849c9712837294128 = struct { value_zx_type_92_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, []const u8, ?*const zx_type_491, };

pub const value_zx_type_492_7bc328ba5cf99a5b76a8fcf29acd76fe767f9143af361280d1b32d7c839d09a0 = struct { value_zx_type_92_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, []const u8, bool, ?*const zx_type_492, };

pub const value_zx_type_493_0eaee0151510bfd991a3bd0b89367cdadb492abec1a5fd00c10697062204fb50 = struct { value_zx_type_92_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, []const u8, bool, bool, ?*const zx_type_493, };

pub const value_zx_type_494_5c3c4da74c27c16d65bdea72766e8717a308e65195b5fc3eb5fc7814376e200e = struct { value_zx_type_92_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, []const u8, bool, bool, bool, ?*const zx_type_494, };

pub const value_zx_type_495_34b10c8fb4fbd35db9d232cb0f993fe12d688f67d7d4e366c1c21a61272239c8 = struct { value_zx_type_92_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, []const u8, bool, bool, bool, bool, ?*const zx_type_495, };

pub const value_zx_type_496_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u32,
    types: []const u32,
    zx_origin: ?*const zx_type_496 = null,
};

pub const value_zx_type_497_e366d4f93466af93bfbf8b4815757383af115756f7364062c2c9d566a0fb2311 = struct {
    input: value_zx_type_253_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    position: u64,
    positions: []const ?u32,
    type_ids: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_497 = null,
};

pub const value_zx_type_498_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u32, ?u32, ?*const zx_type_498, };

pub const value_zx_type_500_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec = struct { []const ?u32, ??u32, ?*const zx_type_500, };

pub const value_zx_type_501_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?u32, void, ?*const zx_type_501, };

pub const value_zx_type_502_efdd75a5e607c61dffb07c66411d75c96f1f2b811307e711dcc2093faf9ae2b2 = struct { value_zx_type_253_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, ?*const zx_type_502, };

pub const value_zx_type_503_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct { value_zx_type_253_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, ?*const zx_type_503, };

pub const value_zx_type_504_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06 = struct { value_zx_type_253_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, bool, ?*const zx_type_504, };

pub const value_zx_type_505_9b770bfbaef1ee4a1f37cd5c69496f8e6265dc77782a7366bf43ec067765a897 = struct { value_zx_type_247_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, ?*const zx_type_505, };

pub const value_zx_type_506_bf234d34f878674ed8858181ac2a0c4fd477de7fa4f453b993f7dab67dc14e39 = struct { value_zx_type_247_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, ?*const zx_type_506, };

pub const value_zx_type_507_556e1ac08c0fc3979e6036c160a2f2a62709a2e5ccad3786614889613cfdd764 = struct { value_zx_type_247_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, bool, ?*const zx_type_507, };

pub const value_zx_type_508_92efd3022152da7dc5c749fdfd73fdff302acd575ca7a7c8920c615ca11a0e05 = struct { value_zx_type_247_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, bool, bool, ?*const zx_type_508, };

pub const value_zx_type_509_7ab9c026eaa54cb0320a667a0ff657ceef59035c2f2475d6fc17da0ab13558a9 = struct { value_zx_type_247_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, bool, bool, ?value_zx_type_253_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, ?*const zx_type_509, };

pub const value_zx_type_510_b6658afbb0dbb221585c28b225ed84d4d8f26171cf709d7184581e757682a853 = struct { value_zx_type_247_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, bool, bool, ?value_zx_type_253_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, ?*const zx_type_510, };

pub const value_zx_type_511_44cf8fab33977767e4c055445acad6cd3fc2421a67b93fec221d92bc429fb63d = struct { value_zx_type_247_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, value_zx_type_67_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5, ?*const zx_type_511, };

pub const value_zx_type_512_7c3cada982eb8438381d40c327e0b6dc2488553fb4130cb5762524bce3ea95b7 = struct { value_zx_type_247_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, value_zx_type_67_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5, bool, ?*const zx_type_512, };

pub const value_zx_type_513_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    names: []const []const u8,
    table: *const zx_type_62,
    types: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_513 = null,
};

pub const value_zx_type_514_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_514 = null,
};

pub const value_zx_type_515_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_260, void, ?*const zx_type_515, };

pub const value_zx_type_516_5821a6631fd0a2b5d5f68275f533e0b86f2430edbf1471339d13b94e742690d5 = struct {
    contracts: *const zx_type_36,
    index: u64,
    state: value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_516 = null,
};

pub const value_zx_type_517_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, void, ?*const zx_type_517, };

pub const value_zx_type_518_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_259, void, ?*const zx_type_518, };

pub const value_zx_type_519_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    control: *const zx_type_39,
    first: u64,
    frames: []const *const zx_type_259,
    index: u64,
    source: u64,
    zx_origin: ?*const zx_type_519 = null,
};

pub const value_zx_type_520_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    capacity: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_520 = null,
};

pub const value_zx_type_521_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    previous: []const u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_521 = null,
};

pub const value_zx_type_522_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    key: u64,
    position: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_522 = null,
};

pub const value_zx_type_523_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    end: u64,
    index: u64,
    table: *const zx_type_28,
    values: []const u32,
    zx_origin: ?*const zx_type_523 = null,
};

pub const value_zx_type_524_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, []const []const u8, ?*const zx_type_524, };

pub const value_zx_type_525_7498e4f806a7d6cb548387280423a75175fc5b80ec06eb4213ab0655a938538d = struct {
    end: u64,
    expressions: *const zx_type_28,
    index: u64,
    names: []const []const u8,
    tables: value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_525 = null,
};

pub const value_zx_type_526_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_260, []const *const zx_type_260, ?*const zx_type_526, };

pub const value_zx_type_527_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    frames: []const *const zx_type_259,
    index: u64,
    source: u64,
    values: []const u32,
    zx_origin: ?*const zx_type_527 = null,
};

pub const value_zx_type_529_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_259, ?*const zx_type_259, ?*const zx_type_529, };

pub const value_zx_type_530_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    names: []const []const u8,
    values: []const []const u8,
    zx_origin: ?*const zx_type_530 = null,
};

pub const value_zx_type_531_b06e51454feef7fdf7d9b33c62cb112de772e5d9de51777f095ab91e73b9d4a4 = struct { value_zx_type_265_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, ?*const zx_type_531, };

pub const value_zx_type_532_559c4a2367a0e05791ca87aafe7d7cdb8a8bef28a8e16e6f7fcc6220ff365f00 = struct { value_zx_type_265_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?*const zx_type_532, };

pub const value_zx_type_533_7e470e8ae35bc1ae71064e0d2c7f58ebb3ee66a2637521f4043452e64e35c605 = struct { value_zx_type_265_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?*const zx_type_533, };

pub const value_zx_type_534_6327aad74f053b917836b19aec6a569c09585fbbc9966097f141db1ae3eef3e6 = struct { value_zx_type_265_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, value_zx_type_264_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?[]const []const u8, ?*const zx_type_534, };

pub const value_zx_type_535_d24b26c0aea29f7ac2d1c547d13d7291794ab89c1d1ffa5dfc71206601edcad6 = struct {
    context: value_zx_type_261_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b,
    index: u64,
    unit: value_zx_type_67_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5,
    valid: bool,
    zx_origin: ?*const zx_type_535 = null,
};

pub const value_zx_type_536_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    first: u64,
    index: u64,
    members: []const []const u8,
    names: []const []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_536 = null,
};

pub const value_zx_type_537_dc2d42eac19bfb34fc4f908abe20295af94d45c49ad5d7797489bde46135f52a = struct { value_zx_type_68_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, bool, bool, bool, ?*const zx_type_537, };

pub const value_zx_type_538_021b7381f380cabd2db3eeb3ddf349cff4c6c84e76d3c31e21bbe00b7a7b09a0 = struct { value_zx_type_68_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, bool, bool, bool, bool, ?*const zx_type_538, };

pub const value_zx_type_539_57dce5d4254efe041b987cdedb775c04961c5941cc08a0b50819eb66743d1e59 = struct { value_zx_type_68_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, bool, bool, bool, bool, bool, ?*const zx_type_539, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
    pub const @"zig:floats" = struct {
        pub const narrow = struct {
            pub const Input = f64;
            pub const Output = f32;
            pub const InputValue = f64;
            pub const OutputValue = f32;
        };
        pub const widen = struct {
            pub const Input = f32;
            pub const Output = f64;
            pub const InputValue = f32;
            pub const OutputValue = f64;
        };
        pub const isFinite = struct {
            pub const Input = f64;
            pub const Output = bool;
            pub const InputValue = f64;
            pub const OutputValue = bool;
        };
        pub const parse32 = struct {
            pub const Input = []const u8;
            pub const Output = ?f32;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f32;
        };
        pub const parse64 = struct {
            pub const Input = []const u8;
            pub const Output = ?f64;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f64;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
    pub const @"zig:floats" = struct {
    };
};

