pub const generated_paths: bool = true;
pub const generated_graph: bool = true;
pub const generated_rules: bool = true;
