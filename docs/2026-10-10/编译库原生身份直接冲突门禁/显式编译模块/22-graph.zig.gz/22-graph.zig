const std = @import("std");

const zx_type_11 = enum { None, InvalidPath, Missing, Cycle, };

const zx_type_14 = struct {
    issues: []const zx_type_11,
    offsets: []const u64,
    targets: []const u64,
};

const zx_type_15 = struct {
    count: u64,
    cursors: []const u64,
    depth: u64,
    edge: u64,
    frames: []const u64,
    graph: *const zx_type_14,
    issue: zx_type_11,
    marks: []const u64,
    order: []const u64,
    root: u64,
};

const zx_type_16 = struct {
    count: u64,
    edge: u64,
    issue: zx_type_11,
    order: []const u64,
};

const zx_type_17 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
};

const zx_type_18 = struct { []const u64, void, };

const zx_type_20 = struct { []const u64, ?u64, };

const zx_type_21 = struct { *const zx_type_14, };

const zx_type_22 = struct { *const zx_type_14, *const zx_type_16, };

const value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    issues: []const zx_type_11,
    offsets: []const u64,
    targets: []const u64,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = struct {
    count: u64,
    cursors: []const u64,
    depth: u64,
    edge: u64,
    frames: []const u64,
    graph: value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    issue: zx_type_11,
    marks: []const u64,
    order: []const u64,
    root: u64,
    zx_origin: ?*const zx_type_15 = null,
};

const value_zx_type_16_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    edge: u64,
    issue: zx_type_11,
    order: []const u64,
    zx_origin: ?*const zx_type_16 = null,
};

const value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_17 = null,
};

const value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_18, };

const value_zx_type_20_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u64, ?u64, ?*const zx_type_20, };

const value_zx_type_21_49129128bed2eab4847d5108d0ed3c4d32810f9cdd95b1d04dcc61383544ee70 = struct { value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_21, };

const value_zx_type_22_7a8ac30af04c84613c3591f9b4f6e1998d2be62e127f0e92267c8278bac14469 = struct { value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_16_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, ?*const zx_type_22, };

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_11, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .issues = zx_shape_13, .offsets = zx_shape_12, .targets = zx_shape_12, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .cursors = zx_shape_12, .depth = zx_shape_5, .edge = zx_shape_5, .frames = zx_shape_12, .graph = zx_shape_14, .issue = zx_shape_11, .marks = zx_shape_12, .order = zx_shape_12, .root = zx_shape_5, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .edge = zx_shape_5, .issue = zx_shape_11, .order = zx_shape_12, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_12, .source = zx_shape_12, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_12, .@"1" = zx_shape_0, }, };

const zx_shape_19 = .{ .kind = .optional, .child = zx_shape_5, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_12, .@"1" = zx_shape_19, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_14, }, };

const zx_shape_22 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_14, .@"1" = zx_shape_16, }, };

pub const input_shape = zx_shape_14;

pub const output_shape = zx_shape_16;

pub const Input = *const zx_type_14;

pub const Output = *const zx_type_16;

fn function_0(allocator: ((std).mem).Allocator, in: *const zx_type_14) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_15 {
    @setRuntimeSafety(true);

    return block_129: {
        const operand_1 = in;
        const operand_2 = (block_29: {
            const operand_28 = block_27: {
                const value_2: []const u64 = (in).offsets;

                break :block_27 block_26: {
                    const operand_9 = block_8: {
                        const operand_4 = value_2;
                        const operand_5 = @as(u64, 0);
                        const operand_6 = block_7: {
                            break :block_7 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_8 zx_type_17{ .index = operand_5, .result = operand_6, .source = operand_4, };
                    };

                    var state_capacity_11: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_12 = false;

                    defer (state_capacity_11).deinit(allocator);

                    var state_3: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_9).index, .result = (operand_9).result, .source = (operand_9).source, .zx_origin = (&operand_9), };

                    while (((state_3).index < @as(u64, ((state_3).source).len))) {
                        state_3 = block_24: {
                            _ = block_23: {
                                const operand_21 = (state_3).source;
                                const operand_22 = (state_3).index;

                                if ((operand_22 >= (operand_21).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_23 (operand_21)[@intCast(operand_22)];
                            };

                            const value_6: u64 = @as(u64, 0);

                            break :block_24 block_20: {
                                const operand_13 = (state_3).source;
                                const operand_14 = ((state_3).index + @as(u64, 1));
                                const operand_15 = (block_19: {
                                    const operand_16 = (state_3).result;
                                    const operand_18 = block_17: {
                                        break :block_17 value_6;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_16).len, 1));

                                    if ((!state_capacity_started_12)) {
                                        (try (state_capacity_11).ensureTotalCapacityPrecise(allocator, ((operand_9).source).len));

                                        (try (state_capacity_11).appendSlice(allocator, operand_16));

                                        state_capacity_started_12 = true;
                                    } else {
                                        ((state_capacity_11).items).len = (operand_16).len;
                                    }

                                    (try (state_capacity_11).append(allocator, operand_18));

                                    break :block_19 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_11).items, {}, null, });
                                }).@"0";

                                break :block_20 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_14, .result = operand_15, .source = operand_13, });
                            };
                        };
                    }

                    var state_owned_25: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_25);

                    if (state_capacity_started_12) {
                        ((state_capacity_11).items).len = ((state_3).result).len;

                        state_owned_25 = (try (state_capacity_11).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_12) {
                        state_3 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_3).index, .result = state_owned_25, .source = (state_3).source, };
                    }

                    break :block_26 (state_3).result;
                };
            };

            break :block_29 @as(zx_type_20, (if (((operand_28).len == 0)) .{ operand_28, null, } else .{ (operand_28)[0..((operand_28).len - 1)], (operand_28)[((operand_28).len - 1)], }));
        }).@"0";
        const operand_30 = (block_60: {
            const operand_59 = block_58: {
                const value_9: []const u64 = (in).offsets;

                break :block_58 block_57: {
                    const operand_37 = block_36: {
                        const operand_32 = value_9;
                        const operand_33 = @as(u64, 0);
                        const operand_34 = block_35: {
                            break :block_35 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_36 zx_type_17{ .index = operand_33, .result = operand_34, .source = operand_32, };
                    };

                    var state_capacity_40: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_41 = false;

                    defer (state_capacity_40).deinit(allocator);

                    var state_31: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_37).index, .result = (operand_37).result, .source = (operand_37).source, .zx_origin = (&operand_37), };

                    while (((state_31).index < @as(u64, ((state_31).source).len))) {
                        state_31 = block_55: {
                            const value_12: u64 = block_54: {
                                const operand_52 = (state_31).source;
                                const operand_53 = (state_31).index;

                                if ((operand_53 >= (operand_52).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_54 (operand_52)[@intCast(operand_53)];
                            };
                            const value_8: u64 = block_51: {
                                break :block_51 value_12;
                            };
                            const value_13: u64 = block_50: {
                                break :block_50 value_8;
                            };

                            break :block_55 block_49: {
                                const operand_42 = (state_31).source;
                                const operand_43 = ((state_31).index + @as(u64, 1));
                                const operand_44 = (block_48: {
                                    const operand_45 = (state_31).result;
                                    const operand_47 = block_46: {
                                        break :block_46 value_13;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_45).len, 1));

                                    if ((!state_capacity_started_41)) {
                                        (try (state_capacity_40).ensureTotalCapacityPrecise(allocator, ((operand_37).source).len));

                                        (try (state_capacity_40).appendSlice(allocator, operand_45));

                                        state_capacity_started_41 = true;
                                    } else {
                                        ((state_capacity_40).items).len = (operand_45).len;
                                    }

                                    (try (state_capacity_40).append(allocator, operand_47));

                                    break :block_48 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_40).items, {}, null, });
                                }).@"0";

                                break :block_49 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_43, .result = operand_44, .source = operand_42, });
                            };
                        };
                    }

                    var state_owned_56: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_56);

                    if (state_capacity_started_41) {
                        ((state_capacity_40).items).len = ((state_31).result).len;

                        state_owned_56 = (try (state_capacity_40).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_41) {
                        state_31 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_31).index, .result = state_owned_56, .source = (state_31).source, };
                    }

                    break :block_57 (state_31).result;
                };
            };

            break :block_60 @as(zx_type_20, (if (((operand_59).len == 0)) .{ operand_59, null, } else .{ (operand_59)[0..((operand_59).len - 1)], (operand_59)[((operand_59).len - 1)], }));
        }).@"0";
        const operand_61 = (block_90: {
            const operand_89 = block_88: {
                const value_16: []const u64 = (in).offsets;

                break :block_88 block_87: {
                    const operand_68 = block_67: {
                        const operand_63 = value_16;
                        const operand_64 = @as(u64, 0);
                        const operand_65 = block_66: {
                            break :block_66 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_67 zx_type_17{ .index = operand_64, .result = operand_65, .source = operand_63, };
                    };

                    var state_capacity_72: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_73 = false;

                    defer (state_capacity_72).deinit(allocator);

                    var state_62: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_68).index, .result = (operand_68).result, .source = (operand_68).source, .zx_origin = (&operand_68), };

                    while (((state_62).index < @as(u64, ((state_62).source).len))) {
                        state_62 = block_85: {
                            _ = block_84: {
                                const operand_82 = (state_62).source;
                                const operand_83 = (state_62).index;

                                if ((operand_83 >= (operand_82).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_84 (operand_82)[@intCast(operand_83)];
                            };

                            const value_20: u64 = @as(u64, 0);

                            break :block_85 block_81: {
                                const operand_74 = (state_62).source;
                                const operand_75 = ((state_62).index + @as(u64, 1));
                                const operand_76 = (block_80: {
                                    const operand_77 = (state_62).result;
                                    const operand_79 = block_78: {
                                        break :block_78 value_20;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_77).len, 1));

                                    if ((!state_capacity_started_73)) {
                                        (try (state_capacity_72).ensureTotalCapacityPrecise(allocator, ((operand_68).source).len));

                                        (try (state_capacity_72).appendSlice(allocator, operand_77));

                                        state_capacity_started_73 = true;
                                    } else {
                                        ((state_capacity_72).items).len = (operand_77).len;
                                    }

                                    (try (state_capacity_72).append(allocator, operand_79));

                                    break :block_80 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_72).items, {}, null, });
                                }).@"0";

                                break :block_81 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_75, .result = operand_76, .source = operand_74, });
                            };
                        };
                    }

                    var state_owned_86: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_86);

                    if (state_capacity_started_73) {
                        ((state_capacity_72).items).len = ((state_62).result).len;

                        state_owned_86 = (try (state_capacity_72).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_73) {
                        state_62 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_62).index, .result = state_owned_86, .source = (state_62).source, };
                    }

                    break :block_87 (state_62).result;
                };
            };

            break :block_90 @as(zx_type_20, (if (((operand_89).len == 0)) .{ operand_89, null, } else .{ (operand_89)[0..((operand_89).len - 1)], (operand_89)[((operand_89).len - 1)], }));
        }).@"0";
        const operand_91 = (block_121: {
            const operand_120 = block_119: {
                const value_23: []const u64 = (in).offsets;

                break :block_119 block_118: {
                    const operand_98 = block_97: {
                        const operand_93 = value_23;
                        const operand_94 = @as(u64, 0);
                        const operand_95 = block_96: {
                            break :block_96 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_97 zx_type_17{ .index = operand_94, .result = operand_95, .source = operand_93, };
                    };

                    var state_capacity_103: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_104 = false;

                    defer (state_capacity_103).deinit(allocator);

                    var state_92: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_98).index, .result = (operand_98).result, .source = (operand_98).source, .zx_origin = (&operand_98), };

                    while (((state_92).index < @as(u64, ((state_92).source).len))) {
                        state_92 = block_116: {
                            _ = block_115: {
                                const operand_113 = (state_92).source;
                                const operand_114 = (state_92).index;

                                if ((operand_114 >= (operand_113).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_115 (operand_113)[@intCast(operand_114)];
                            };

                            const value_27: u64 = @as(u64, 0);

                            break :block_116 block_112: {
                                const operand_105 = (state_92).source;
                                const operand_106 = ((state_92).index + @as(u64, 1));
                                const operand_107 = (block_111: {
                                    const operand_108 = (state_92).result;
                                    const operand_110 = block_109: {
                                        break :block_109 value_27;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_108).len, 1));

                                    if ((!state_capacity_started_104)) {
                                        (try (state_capacity_103).ensureTotalCapacityPrecise(allocator, ((operand_98).source).len));

                                        (try (state_capacity_103).appendSlice(allocator, operand_108));

                                        state_capacity_started_104 = true;
                                    } else {
                                        ((state_capacity_103).items).len = (operand_108).len;
                                    }

                                    (try (state_capacity_103).append(allocator, operand_110));

                                    break :block_111 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_103).items, {}, null, });
                                }).@"0";

                                break :block_112 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_106, .result = operand_107, .source = operand_105, });
                            };
                        };
                    }

                    var state_owned_117: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_117);

                    if (state_capacity_started_104) {
                        ((state_capacity_103).items).len = ((state_92).result).len;

                        state_owned_117 = (try (state_capacity_103).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_104) {
                        state_92 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_92).index, .result = state_owned_117, .source = (state_92).source, };
                    }

                    break :block_118 (state_92).result;
                };
            };

            break :block_121 @as(zx_type_20, (if (((operand_120).len == 0)) .{ operand_120, null, } else .{ (operand_120)[0..((operand_120).len - 1)], (operand_120)[((operand_120).len - 1)], }));
        }).@"0";
        const operand_122 = @as(u64, 0);
        const operand_123 = @as(u64, 0);
        const operand_124 = @as(u64, 0);
        const operand_125 = @as(zx_type_11, .None);
        const operand_126 = @as(u64, 0);

        break :block_129 block_128: {
            const operand_127 = (try (allocator).create(zx_type_15));

            (operand_127).* = @as(zx_type_15, zx_type_15{ .graph = operand_1, .marks = operand_2, .cursors = operand_30, .frames = operand_61, .order = operand_91, .root = operand_122, .depth = operand_123, .count = operand_124, .issue = operand_125, .edge = operand_126, });

            break :block_128 @as(*const zx_type_15, operand_127);
        };
    };
}

fn function_0_value(allocator: ((std).mem).Allocator, in: value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 {
    @setRuntimeSafety(true);

    return block_250: {
        const operand_130 = in;
        const operand_131 = (block_158: {
            const operand_157 = block_156: {
                const value_2: []const u64 = (in).offsets;

                break :block_156 block_155: {
                    const operand_139 = block_138: {
                        const operand_133 = block_134: {
                            break :block_134 value_2;
                        };
                        const operand_135 = @as(u64, 0);
                        const operand_136 = block_137: {
                            break :block_137 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_138 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_135, .result = operand_136, .source = operand_133, });
                    };

                    var state_capacity_140: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_141 = false;

                    defer (state_capacity_140).deinit(allocator);

                    var state_132: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_139;

                    while (((state_132).index < @as(u64, ((state_132).source).len))) {
                        state_132 = block_153: {
                            _ = block_152: {
                                const operand_150 = (state_132).source;
                                const operand_151 = (state_132).index;

                                if ((operand_151 >= (operand_150).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_152 (operand_150)[@intCast(operand_151)];
                            };

                            const value_6: u64 = @as(u64, 0);

                            break :block_153 block_149: {
                                const operand_142 = (state_132).source;
                                const operand_143 = ((state_132).index + @as(u64, 1));
                                const operand_144 = (block_148: {
                                    const operand_145 = (state_132).result;
                                    const operand_147 = block_146: {
                                        break :block_146 value_6;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_145).len, 1));

                                    if ((!state_capacity_started_141)) {
                                        (try (state_capacity_140).ensureTotalCapacityPrecise(allocator, ((operand_139).source).len));

                                        (try (state_capacity_140).appendSlice(allocator, operand_145));

                                        state_capacity_started_141 = true;
                                    } else {
                                        ((state_capacity_140).items).len = (operand_145).len;
                                    }

                                    (try (state_capacity_140).append(allocator, operand_147));

                                    break :block_148 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_140).items, {}, null, });
                                }).@"0";

                                break :block_149 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_143, .result = operand_144, .source = operand_142, });
                            };
                        };
                    }

                    var state_owned_154: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_154);

                    if (state_capacity_started_141) {
                        ((state_capacity_140).items).len = ((state_132).result).len;

                        state_owned_154 = (try (state_capacity_140).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_141) {
                        state_132 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_132).index, .result = state_owned_154, .source = (state_132).source, };
                    }

                    break :block_155 (state_132).result;
                };
            };

            break :block_158 @as(value_zx_type_20_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_157).len == 0)) .{ operand_157, null, null, } else .{ (operand_157)[0..((operand_157).len - 1)], (operand_157)[((operand_157).len - 1)], null, }));
        }).@"0";
        const operand_159 = (block_188: {
            const operand_187 = block_186: {
                const value_9: []const u64 = (in).offsets;

                break :block_186 block_185: {
                    const operand_167 = block_166: {
                        const operand_161 = block_162: {
                            break :block_162 value_9;
                        };
                        const operand_163 = @as(u64, 0);
                        const operand_164 = block_165: {
                            break :block_165 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_166 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_163, .result = operand_164, .source = operand_161, });
                    };

                    var state_capacity_168: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_169 = false;

                    defer (state_capacity_168).deinit(allocator);

                    var state_160: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_167;

                    while (((state_160).index < @as(u64, ((state_160).source).len))) {
                        state_160 = block_183: {
                            const value_12: u64 = block_182: {
                                const operand_180 = (state_160).source;
                                const operand_181 = (state_160).index;

                                if ((operand_181 >= (operand_180).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_182 (operand_180)[@intCast(operand_181)];
                            };
                            const value_8: u64 = block_179: {
                                break :block_179 value_12;
                            };
                            const value_13: u64 = block_178: {
                                break :block_178 value_8;
                            };

                            break :block_183 block_177: {
                                const operand_170 = (state_160).source;
                                const operand_171 = ((state_160).index + @as(u64, 1));
                                const operand_172 = (block_176: {
                                    const operand_173 = (state_160).result;
                                    const operand_175 = block_174: {
                                        break :block_174 value_13;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_173).len, 1));

                                    if ((!state_capacity_started_169)) {
                                        (try (state_capacity_168).ensureTotalCapacityPrecise(allocator, ((operand_167).source).len));

                                        (try (state_capacity_168).appendSlice(allocator, operand_173));

                                        state_capacity_started_169 = true;
                                    } else {
                                        ((state_capacity_168).items).len = (operand_173).len;
                                    }

                                    (try (state_capacity_168).append(allocator, operand_175));

                                    break :block_176 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_168).items, {}, null, });
                                }).@"0";

                                break :block_177 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_171, .result = operand_172, .source = operand_170, });
                            };
                        };
                    }

                    var state_owned_184: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_184);

                    if (state_capacity_started_169) {
                        ((state_capacity_168).items).len = ((state_160).result).len;

                        state_owned_184 = (try (state_capacity_168).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_169) {
                        state_160 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_160).index, .result = state_owned_184, .source = (state_160).source, };
                    }

                    break :block_185 (state_160).result;
                };
            };

            break :block_188 @as(value_zx_type_20_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_187).len == 0)) .{ operand_187, null, null, } else .{ (operand_187)[0..((operand_187).len - 1)], (operand_187)[((operand_187).len - 1)], null, }));
        }).@"0";
        const operand_189 = (block_216: {
            const operand_215 = block_214: {
                const value_16: []const u64 = (in).offsets;

                break :block_214 block_213: {
                    const operand_197 = block_196: {
                        const operand_191 = block_192: {
                            break :block_192 value_16;
                        };
                        const operand_193 = @as(u64, 0);
                        const operand_194 = block_195: {
                            break :block_195 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_196 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_193, .result = operand_194, .source = operand_191, });
                    };

                    var state_capacity_198: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_199 = false;

                    defer (state_capacity_198).deinit(allocator);

                    var state_190: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_197;

                    while (((state_190).index < @as(u64, ((state_190).source).len))) {
                        state_190 = block_211: {
                            _ = block_210: {
                                const operand_208 = (state_190).source;
                                const operand_209 = (state_190).index;

                                if ((operand_209 >= (operand_208).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_210 (operand_208)[@intCast(operand_209)];
                            };

                            const value_20: u64 = @as(u64, 0);

                            break :block_211 block_207: {
                                const operand_200 = (state_190).source;
                                const operand_201 = ((state_190).index + @as(u64, 1));
                                const operand_202 = (block_206: {
                                    const operand_203 = (state_190).result;
                                    const operand_205 = block_204: {
                                        break :block_204 value_20;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_203).len, 1));

                                    if ((!state_capacity_started_199)) {
                                        (try (state_capacity_198).ensureTotalCapacityPrecise(allocator, ((operand_197).source).len));

                                        (try (state_capacity_198).appendSlice(allocator, operand_203));

                                        state_capacity_started_199 = true;
                                    } else {
                                        ((state_capacity_198).items).len = (operand_203).len;
                                    }

                                    (try (state_capacity_198).append(allocator, operand_205));

                                    break :block_206 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_198).items, {}, null, });
                                }).@"0";

                                break :block_207 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_201, .result = operand_202, .source = operand_200, });
                            };
                        };
                    }

                    var state_owned_212: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_212);

                    if (state_capacity_started_199) {
                        ((state_capacity_198).items).len = ((state_190).result).len;

                        state_owned_212 = (try (state_capacity_198).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_199) {
                        state_190 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_190).index, .result = state_owned_212, .source = (state_190).source, };
                    }

                    break :block_213 (state_190).result;
                };
            };

            break :block_216 @as(value_zx_type_20_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_215).len == 0)) .{ operand_215, null, null, } else .{ (operand_215)[0..((operand_215).len - 1)], (operand_215)[((operand_215).len - 1)], null, }));
        }).@"0";
        const operand_217 = (block_244: {
            const operand_243 = block_242: {
                const value_23: []const u64 = (in).offsets;

                break :block_242 block_241: {
                    const operand_225 = block_224: {
                        const operand_219 = block_220: {
                            break :block_220 value_23;
                        };
                        const operand_221 = @as(u64, 0);
                        const operand_222 = block_223: {
                            break :block_223 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_224 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_221, .result = operand_222, .source = operand_219, });
                    };

                    var state_capacity_226: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_227 = false;

                    defer (state_capacity_226).deinit(allocator);

                    var state_218: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_225;

                    while (((state_218).index < @as(u64, ((state_218).source).len))) {
                        state_218 = block_239: {
                            _ = block_238: {
                                const operand_236 = (state_218).source;
                                const operand_237 = (state_218).index;

                                if ((operand_237 >= (operand_236).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_238 (operand_236)[@intCast(operand_237)];
                            };

                            const value_27: u64 = @as(u64, 0);

                            break :block_239 block_235: {
                                const operand_228 = (state_218).source;
                                const operand_229 = ((state_218).index + @as(u64, 1));
                                const operand_230 = (block_234: {
                                    const operand_231 = (state_218).result;
                                    const operand_233 = block_232: {
                                        break :block_232 value_27;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_231).len, 1));

                                    if ((!state_capacity_started_227)) {
                                        (try (state_capacity_226).ensureTotalCapacityPrecise(allocator, ((operand_225).source).len));

                                        (try (state_capacity_226).appendSlice(allocator, operand_231));

                                        state_capacity_started_227 = true;
                                    } else {
                                        ((state_capacity_226).items).len = (operand_231).len;
                                    }

                                    (try (state_capacity_226).append(allocator, operand_233));

                                    break :block_234 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_226).items, {}, null, });
                                }).@"0";

                                break :block_235 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_229, .result = operand_230, .source = operand_228, });
                            };
                        };
                    }

                    var state_owned_240: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_240);

                    if (state_capacity_started_227) {
                        ((state_capacity_226).items).len = ((state_218).result).len;

                        state_owned_240 = (try (state_capacity_226).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_227) {
                        state_218 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_218).index, .result = state_owned_240, .source = (state_218).source, };
                    }

                    break :block_241 (state_218).result;
                };
            };

            break :block_244 @as(value_zx_type_20_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_243).len == 0)) .{ operand_243, null, null, } else .{ (operand_243)[0..((operand_243).len - 1)], (operand_243)[((operand_243).len - 1)], null, }));
        }).@"0";
        const operand_245 = @as(u64, 0);
        const operand_246 = @as(u64, 0);
        const operand_247 = @as(u64, 0);
        const operand_248 = @as(zx_type_11, .None);
        const operand_249 = @as(u64, 0);

        break :block_250 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .graph = operand_130, .marks = operand_131, .cursors = operand_159, .frames = operand_189, .order = operand_217, .root = operand_245, .depth = operand_246, .count = operand_247, .issue = operand_248, .edge = operand_249, });
    };
}

fn function_0_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(zx_type_11),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 {
    @setRuntimeSafety(true);

    _ = buffers;

    return block_371: {
        const operand_251 = in;
        const operand_252 = (block_279: {
            const operand_278 = block_277: {
                const value_2: []const u64 = (in).offsets;

                break :block_277 block_276: {
                    const operand_260 = block_259: {
                        const operand_254 = block_255: {
                            break :block_255 value_2;
                        };
                        const operand_256 = @as(u64, 0);
                        const operand_257 = block_258: {
                            break :block_258 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_259 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_256, .result = operand_257, .source = operand_254, });
                    };

                    var state_capacity_261: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_262 = false;

                    defer (state_capacity_261).deinit(allocator);

                    var state_253: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_260;

                    while (((state_253).index < @as(u64, ((state_253).source).len))) {
                        state_253 = block_274: {
                            _ = block_273: {
                                const operand_271 = (state_253).source;
                                const operand_272 = (state_253).index;

                                if ((operand_272 >= (operand_271).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_273 (operand_271)[@intCast(operand_272)];
                            };

                            const value_6: u64 = @as(u64, 0);

                            break :block_274 block_270: {
                                const operand_263 = (state_253).source;
                                const operand_264 = ((state_253).index + @as(u64, 1));
                                const operand_265 = (block_269: {
                                    const operand_266 = (state_253).result;
                                    const operand_268 = block_267: {
                                        break :block_267 value_6;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_266).len, 1));

                                    if ((!state_capacity_started_262)) {
                                        (try (state_capacity_261).ensureTotalCapacityPrecise(allocator, ((operand_260).source).len));

                                        (try (state_capacity_261).appendSlice(allocator, operand_266));

                                        state_capacity_started_262 = true;
                                    } else {
                                        ((state_capacity_261).items).len = (operand_266).len;
                                    }

                                    (try (state_capacity_261).append(allocator, operand_268));

                                    break :block_269 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_261).items, {}, null, });
                                }).@"0";

                                break :block_270 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_264, .result = operand_265, .source = operand_263, });
                            };
                        };
                    }

                    var state_owned_275: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_275);

                    if (state_capacity_started_262) {
                        ((state_capacity_261).items).len = ((state_253).result).len;

                        state_owned_275 = (try (state_capacity_261).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_262) {
                        state_253 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_253).index, .result = state_owned_275, .source = (state_253).source, };
                    }

                    break :block_276 (state_253).result;
                };
            };

            break :block_279 @as(value_zx_type_20_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_278).len == 0)) .{ operand_278, null, null, } else .{ (operand_278)[0..((operand_278).len - 1)], (operand_278)[((operand_278).len - 1)], null, }));
        }).@"0";
        const operand_280 = (block_309: {
            const operand_308 = block_307: {
                const value_9: []const u64 = (in).offsets;

                break :block_307 block_306: {
                    const operand_288 = block_287: {
                        const operand_282 = block_283: {
                            break :block_283 value_9;
                        };
                        const operand_284 = @as(u64, 0);
                        const operand_285 = block_286: {
                            break :block_286 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_287 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_284, .result = operand_285, .source = operand_282, });
                    };

                    var state_capacity_289: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_290 = false;

                    defer (state_capacity_289).deinit(allocator);

                    var state_281: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_288;

                    while (((state_281).index < @as(u64, ((state_281).source).len))) {
                        state_281 = block_304: {
                            const value_12: u64 = block_303: {
                                const operand_301 = (state_281).source;
                                const operand_302 = (state_281).index;

                                if ((operand_302 >= (operand_301).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_303 (operand_301)[@intCast(operand_302)];
                            };
                            const value_8: u64 = block_300: {
                                break :block_300 value_12;
                            };
                            const value_13: u64 = block_299: {
                                break :block_299 value_8;
                            };

                            break :block_304 block_298: {
                                const operand_291 = (state_281).source;
                                const operand_292 = ((state_281).index + @as(u64, 1));
                                const operand_293 = (block_297: {
                                    const operand_294 = (state_281).result;
                                    const operand_296 = block_295: {
                                        break :block_295 value_13;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_294).len, 1));

                                    if ((!state_capacity_started_290)) {
                                        (try (state_capacity_289).ensureTotalCapacityPrecise(allocator, ((operand_288).source).len));

                                        (try (state_capacity_289).appendSlice(allocator, operand_294));

                                        state_capacity_started_290 = true;
                                    } else {
                                        ((state_capacity_289).items).len = (operand_294).len;
                                    }

                                    (try (state_capacity_289).append(allocator, operand_296));

                                    break :block_297 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_289).items, {}, null, });
                                }).@"0";

                                break :block_298 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_292, .result = operand_293, .source = operand_291, });
                            };
                        };
                    }

                    var state_owned_305: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_305);

                    if (state_capacity_started_290) {
                        ((state_capacity_289).items).len = ((state_281).result).len;

                        state_owned_305 = (try (state_capacity_289).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_290) {
                        state_281 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_281).index, .result = state_owned_305, .source = (state_281).source, };
                    }

                    break :block_306 (state_281).result;
                };
            };

            break :block_309 @as(value_zx_type_20_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_308).len == 0)) .{ operand_308, null, null, } else .{ (operand_308)[0..((operand_308).len - 1)], (operand_308)[((operand_308).len - 1)], null, }));
        }).@"0";
        const operand_310 = (block_337: {
            const operand_336 = block_335: {
                const value_16: []const u64 = (in).offsets;

                break :block_335 block_334: {
                    const operand_318 = block_317: {
                        const operand_312 = block_313: {
                            break :block_313 value_16;
                        };
                        const operand_314 = @as(u64, 0);
                        const operand_315 = block_316: {
                            break :block_316 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_317 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_314, .result = operand_315, .source = operand_312, });
                    };

                    var state_capacity_319: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_320 = false;

                    defer (state_capacity_319).deinit(allocator);

                    var state_311: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_318;

                    while (((state_311).index < @as(u64, ((state_311).source).len))) {
                        state_311 = block_332: {
                            _ = block_331: {
                                const operand_329 = (state_311).source;
                                const operand_330 = (state_311).index;

                                if ((operand_330 >= (operand_329).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_331 (operand_329)[@intCast(operand_330)];
                            };

                            const value_20: u64 = @as(u64, 0);

                            break :block_332 block_328: {
                                const operand_321 = (state_311).source;
                                const operand_322 = ((state_311).index + @as(u64, 1));
                                const operand_323 = (block_327: {
                                    const operand_324 = (state_311).result;
                                    const operand_326 = block_325: {
                                        break :block_325 value_20;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_324).len, 1));

                                    if ((!state_capacity_started_320)) {
                                        (try (state_capacity_319).ensureTotalCapacityPrecise(allocator, ((operand_318).source).len));

                                        (try (state_capacity_319).appendSlice(allocator, operand_324));

                                        state_capacity_started_320 = true;
                                    } else {
                                        ((state_capacity_319).items).len = (operand_324).len;
                                    }

                                    (try (state_capacity_319).append(allocator, operand_326));

                                    break :block_327 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_319).items, {}, null, });
                                }).@"0";

                                break :block_328 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_322, .result = operand_323, .source = operand_321, });
                            };
                        };
                    }

                    var state_owned_333: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_333);

                    if (state_capacity_started_320) {
                        ((state_capacity_319).items).len = ((state_311).result).len;

                        state_owned_333 = (try (state_capacity_319).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_320) {
                        state_311 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_311).index, .result = state_owned_333, .source = (state_311).source, };
                    }

                    break :block_334 (state_311).result;
                };
            };

            break :block_337 @as(value_zx_type_20_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_336).len == 0)) .{ operand_336, null, null, } else .{ (operand_336)[0..((operand_336).len - 1)], (operand_336)[((operand_336).len - 1)], null, }));
        }).@"0";
        const operand_338 = (block_365: {
            const operand_364 = block_363: {
                const value_23: []const u64 = (in).offsets;

                break :block_363 block_362: {
                    const operand_346 = block_345: {
                        const operand_340 = block_341: {
                            break :block_341 value_23;
                        };
                        const operand_342 = @as(u64, 0);
                        const operand_343 = block_344: {
                            break :block_344 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_345 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_342, .result = operand_343, .source = operand_340, });
                    };

                    var state_capacity_347: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_348 = false;

                    defer (state_capacity_347).deinit(allocator);

                    var state_339: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_346;

                    while (((state_339).index < @as(u64, ((state_339).source).len))) {
                        state_339 = block_360: {
                            _ = block_359: {
                                const operand_357 = (state_339).source;
                                const operand_358 = (state_339).index;

                                if ((operand_358 >= (operand_357).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_359 (operand_357)[@intCast(operand_358)];
                            };

                            const value_27: u64 = @as(u64, 0);

                            break :block_360 block_356: {
                                const operand_349 = (state_339).source;
                                const operand_350 = ((state_339).index + @as(u64, 1));
                                const operand_351 = (block_355: {
                                    const operand_352 = (state_339).result;
                                    const operand_354 = block_353: {
                                        break :block_353 value_27;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_352).len, 1));

                                    if ((!state_capacity_started_348)) {
                                        (try (state_capacity_347).ensureTotalCapacityPrecise(allocator, ((operand_346).source).len));

                                        (try (state_capacity_347).appendSlice(allocator, operand_352));

                                        state_capacity_started_348 = true;
                                    } else {
                                        ((state_capacity_347).items).len = (operand_352).len;
                                    }

                                    (try (state_capacity_347).append(allocator, operand_354));

                                    break :block_355 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_347).items, {}, null, });
                                }).@"0";

                                break :block_356 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_350, .result = operand_351, .source = operand_349, });
                            };
                        };
                    }

                    var state_owned_361: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_361);

                    if (state_capacity_started_348) {
                        ((state_capacity_347).items).len = ((state_339).result).len;

                        state_owned_361 = (try (state_capacity_347).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_348) {
                        state_339 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_339).index, .result = state_owned_361, .source = (state_339).source, };
                    }

                    break :block_362 (state_339).result;
                };
            };

            break :block_365 @as(value_zx_type_20_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754, (if (((operand_364).len == 0)) .{ operand_364, null, null, } else .{ (operand_364)[0..((operand_364).len - 1)], (operand_364)[((operand_364).len - 1)], null, }));
        }).@"0";
        const operand_366 = @as(u64, 0);
        const operand_367 = @as(u64, 0);
        const operand_368 = @as(u64, 0);
        const operand_369 = @as(zx_type_11, .None);
        const operand_370 = @as(u64, 0);

        break :block_371 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .graph = operand_251, .marks = operand_252, .cursors = operand_280, .frames = operand_310, .order = operand_338, .root = operand_366, .depth = operand_367, .count = operand_368, .issue = operand_369, .edge = operand_370, });
    };
}

fn function_0_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_14, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(zx_type_11),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u64),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_15 {
    @setRuntimeSafety(true);

    _ = buffers;

    return block_500: {
        const operand_372 = in;
        const operand_373 = (block_400: {
            const operand_399 = block_398: {
                const value_2: []const u64 = (in).offsets;

                break :block_398 block_397: {
                    const operand_380 = block_379: {
                        const operand_375 = value_2;
                        const operand_376 = @as(u64, 0);
                        const operand_377 = block_378: {
                            break :block_378 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_379 zx_type_17{ .index = operand_376, .result = operand_377, .source = operand_375, };
                    };

                    var state_capacity_382: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_383 = false;

                    defer (state_capacity_382).deinit(allocator);

                    var state_374: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_380).index, .result = (operand_380).result, .source = (operand_380).source, .zx_origin = (&operand_380), };

                    while (((state_374).index < @as(u64, ((state_374).source).len))) {
                        state_374 = block_395: {
                            _ = block_394: {
                                const operand_392 = (state_374).source;
                                const operand_393 = (state_374).index;

                                if ((operand_393 >= (operand_392).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_394 (operand_392)[@intCast(operand_393)];
                            };

                            const value_6: u64 = @as(u64, 0);

                            break :block_395 block_391: {
                                const operand_384 = (state_374).source;
                                const operand_385 = ((state_374).index + @as(u64, 1));
                                const operand_386 = (block_390: {
                                    const operand_387 = (state_374).result;
                                    const operand_389 = block_388: {
                                        break :block_388 value_6;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_387).len, 1));

                                    if ((!state_capacity_started_383)) {
                                        (try (state_capacity_382).ensureTotalCapacityPrecise(allocator, ((operand_380).source).len));

                                        (try (state_capacity_382).appendSlice(allocator, operand_387));

                                        state_capacity_started_383 = true;
                                    } else {
                                        ((state_capacity_382).items).len = (operand_387).len;
                                    }

                                    (try (state_capacity_382).append(allocator, operand_389));

                                    break :block_390 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_382).items, {}, null, });
                                }).@"0";

                                break :block_391 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_385, .result = operand_386, .source = operand_384, });
                            };
                        };
                    }

                    var state_owned_396: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_396);

                    if (state_capacity_started_383) {
                        ((state_capacity_382).items).len = ((state_374).result).len;

                        state_owned_396 = (try (state_capacity_382).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_383) {
                        state_374 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_374).index, .result = state_owned_396, .source = (state_374).source, };
                    }

                    break :block_397 (state_374).result;
                };
            };

            break :block_400 @as(zx_type_20, (if (((operand_399).len == 0)) .{ operand_399, null, } else .{ (operand_399)[0..((operand_399).len - 1)], (operand_399)[((operand_399).len - 1)], }));
        }).@"0";
        const operand_401 = (block_431: {
            const operand_430 = block_429: {
                const value_9: []const u64 = (in).offsets;

                break :block_429 block_428: {
                    const operand_408 = block_407: {
                        const operand_403 = value_9;
                        const operand_404 = @as(u64, 0);
                        const operand_405 = block_406: {
                            break :block_406 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_407 zx_type_17{ .index = operand_404, .result = operand_405, .source = operand_403, };
                    };

                    var state_capacity_411: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_412 = false;

                    defer (state_capacity_411).deinit(allocator);

                    var state_402: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_408).index, .result = (operand_408).result, .source = (operand_408).source, .zx_origin = (&operand_408), };

                    while (((state_402).index < @as(u64, ((state_402).source).len))) {
                        state_402 = block_426: {
                            const value_12: u64 = block_425: {
                                const operand_423 = (state_402).source;
                                const operand_424 = (state_402).index;

                                if ((operand_424 >= (operand_423).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_425 (operand_423)[@intCast(operand_424)];
                            };
                            const value_8: u64 = block_422: {
                                break :block_422 value_12;
                            };
                            const value_13: u64 = block_421: {
                                break :block_421 value_8;
                            };

                            break :block_426 block_420: {
                                const operand_413 = (state_402).source;
                                const operand_414 = ((state_402).index + @as(u64, 1));
                                const operand_415 = (block_419: {
                                    const operand_416 = (state_402).result;
                                    const operand_418 = block_417: {
                                        break :block_417 value_13;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_416).len, 1));

                                    if ((!state_capacity_started_412)) {
                                        (try (state_capacity_411).ensureTotalCapacityPrecise(allocator, ((operand_408).source).len));

                                        (try (state_capacity_411).appendSlice(allocator, operand_416));

                                        state_capacity_started_412 = true;
                                    } else {
                                        ((state_capacity_411).items).len = (operand_416).len;
                                    }

                                    (try (state_capacity_411).append(allocator, operand_418));

                                    break :block_419 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_411).items, {}, null, });
                                }).@"0";

                                break :block_420 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_414, .result = operand_415, .source = operand_413, });
                            };
                        };
                    }

                    var state_owned_427: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_427);

                    if (state_capacity_started_412) {
                        ((state_capacity_411).items).len = ((state_402).result).len;

                        state_owned_427 = (try (state_capacity_411).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_412) {
                        state_402 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_402).index, .result = state_owned_427, .source = (state_402).source, };
                    }

                    break :block_428 (state_402).result;
                };
            };

            break :block_431 @as(zx_type_20, (if (((operand_430).len == 0)) .{ operand_430, null, } else .{ (operand_430)[0..((operand_430).len - 1)], (operand_430)[((operand_430).len - 1)], }));
        }).@"0";
        const operand_432 = (block_461: {
            const operand_460 = block_459: {
                const value_16: []const u64 = (in).offsets;

                break :block_459 block_458: {
                    const operand_439 = block_438: {
                        const operand_434 = value_16;
                        const operand_435 = @as(u64, 0);
                        const operand_436 = block_437: {
                            break :block_437 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_438 zx_type_17{ .index = operand_435, .result = operand_436, .source = operand_434, };
                    };

                    var state_capacity_443: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_444 = false;

                    defer (state_capacity_443).deinit(allocator);

                    var state_433: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_439).index, .result = (operand_439).result, .source = (operand_439).source, .zx_origin = (&operand_439), };

                    while (((state_433).index < @as(u64, ((state_433).source).len))) {
                        state_433 = block_456: {
                            _ = block_455: {
                                const operand_453 = (state_433).source;
                                const operand_454 = (state_433).index;

                                if ((operand_454 >= (operand_453).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_455 (operand_453)[@intCast(operand_454)];
                            };

                            const value_20: u64 = @as(u64, 0);

                            break :block_456 block_452: {
                                const operand_445 = (state_433).source;
                                const operand_446 = ((state_433).index + @as(u64, 1));
                                const operand_447 = (block_451: {
                                    const operand_448 = (state_433).result;
                                    const operand_450 = block_449: {
                                        break :block_449 value_20;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_448).len, 1));

                                    if ((!state_capacity_started_444)) {
                                        (try (state_capacity_443).ensureTotalCapacityPrecise(allocator, ((operand_439).source).len));

                                        (try (state_capacity_443).appendSlice(allocator, operand_448));

                                        state_capacity_started_444 = true;
                                    } else {
                                        ((state_capacity_443).items).len = (operand_448).len;
                                    }

                                    (try (state_capacity_443).append(allocator, operand_450));

                                    break :block_451 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_443).items, {}, null, });
                                }).@"0";

                                break :block_452 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_446, .result = operand_447, .source = operand_445, });
                            };
                        };
                    }

                    var state_owned_457: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_457);

                    if (state_capacity_started_444) {
                        ((state_capacity_443).items).len = ((state_433).result).len;

                        state_owned_457 = (try (state_capacity_443).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_444) {
                        state_433 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_433).index, .result = state_owned_457, .source = (state_433).source, };
                    }

                    break :block_458 (state_433).result;
                };
            };

            break :block_461 @as(zx_type_20, (if (((operand_460).len == 0)) .{ operand_460, null, } else .{ (operand_460)[0..((operand_460).len - 1)], (operand_460)[((operand_460).len - 1)], }));
        }).@"0";
        const operand_462 = (block_492: {
            const operand_491 = block_490: {
                const value_23: []const u64 = (in).offsets;

                break :block_490 block_489: {
                    const operand_469 = block_468: {
                        const operand_464 = value_23;
                        const operand_465 = @as(u64, 0);
                        const operand_466 = block_467: {
                            break :block_467 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_468 zx_type_17{ .index = operand_465, .result = operand_466, .source = operand_464, };
                    };

                    var state_capacity_474: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_475 = false;

                    defer (state_capacity_474).deinit(allocator);

                    var state_463: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_469).index, .result = (operand_469).result, .source = (operand_469).source, .zx_origin = (&operand_469), };

                    while (((state_463).index < @as(u64, ((state_463).source).len))) {
                        state_463 = block_487: {
                            _ = block_486: {
                                const operand_484 = (state_463).source;
                                const operand_485 = (state_463).index;

                                if ((operand_485 >= (operand_484).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_486 (operand_484)[@intCast(operand_485)];
                            };

                            const value_27: u64 = @as(u64, 0);

                            break :block_487 block_483: {
                                const operand_476 = (state_463).source;
                                const operand_477 = ((state_463).index + @as(u64, 1));
                                const operand_478 = (block_482: {
                                    const operand_479 = (state_463).result;
                                    const operand_481 = block_480: {
                                        break :block_480 value_27;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_479).len, 1));

                                    if ((!state_capacity_started_475)) {
                                        (try (state_capacity_474).ensureTotalCapacityPrecise(allocator, ((operand_469).source).len));

                                        (try (state_capacity_474).appendSlice(allocator, operand_479));

                                        state_capacity_started_475 = true;
                                    } else {
                                        ((state_capacity_474).items).len = (operand_479).len;
                                    }

                                    (try (state_capacity_474).append(allocator, operand_481));

                                    break :block_482 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_474).items, {}, null, });
                                }).@"0";

                                break :block_483 @as(value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_477, .result = operand_478, .source = operand_476, });
                            };
                        };
                    }

                    var state_owned_488: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_488);

                    if (state_capacity_started_475) {
                        ((state_capacity_474).items).len = ((state_463).result).len;

                        state_owned_488 = (try (state_capacity_474).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_475) {
                        state_463 = value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_463).index, .result = state_owned_488, .source = (state_463).source, };
                    }

                    break :block_489 (state_463).result;
                };
            };

            break :block_492 @as(zx_type_20, (if (((operand_491).len == 0)) .{ operand_491, null, } else .{ (operand_491)[0..((operand_491).len - 1)], (operand_491)[((operand_491).len - 1)], }));
        }).@"0";
        const operand_493 = @as(u64, 0);
        const operand_494 = @as(u64, 0);
        const operand_495 = @as(u64, 0);
        const operand_496 = @as(zx_type_11, .None);
        const operand_497 = @as(u64, 0);

        break :block_500 block_499: {
            const operand_498 = (try (allocator).create(zx_type_15));

            (operand_498).* = @as(zx_type_15, zx_type_15{ .graph = operand_372, .marks = operand_373, .cursors = operand_401, .frames = operand_432, .order = operand_462, .root = operand_493, .depth = operand_494, .count = operand_495, .issue = operand_496, .edge = operand_497, });

            break :block_499 @as(*const zx_type_15, operand_498);
        };
    };
}

fn function_1(allocator: ((std).mem).Allocator, in: *const zx_type_14) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_16 {
    @setRuntimeSafety(true);

    return block_119: {
        const state_type_3 = struct {
            issues: []const zx_type_11,
            offsets: []const u64,
            targets: []const u64,
        };
        const state_type_14 = struct {
            count: u64,
            cursors: []const u64,
            depth: u64,
            edge: u64,
            frames: []const u64,
            graph: state_type_3,
            issue: zx_type_11,
            marks: []const u64,
            order: []const u64,
            root: u64,
        };
        const operand_16 = block_15: {
            const operand_5 = block_4: {
                const operand_2 = in;

                break :block_4 state_type_3{ .issues = (operand_2).issues, .offsets = (operand_2).offsets, .targets = (operand_2).targets, };
            };
            const operand_6 = zx_type_14{ .issues = (operand_5).issues, .offsets = (operand_5).offsets, .targets = (operand_5).targets, };
            const operand_13 = block_12: {
                const operand_7 = (&operand_6);
                const operand_8 = (try function_0_value(allocator, value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .issues = (operand_7).issues, .offsets = (operand_7).offsets, .targets = (operand_7).targets, .zx_origin = operand_7, }));

                break :block_12 (if (((operand_8).zx_origin != null)) ((operand_8).zx_origin.?).* else block_11: {
                    break :block_11 zx_type_15{ .count = (operand_8).count, .cursors = (operand_8).cursors, .depth = (operand_8).depth, .edge = (operand_8).edge, .frames = (operand_8).frames, .graph = (if ((((operand_8).graph).zx_origin != null)) ((operand_8).graph).zx_origin.? else block_10: {
                        const operand_9 = (try (allocator).create(zx_type_14));

                        (operand_9).* = zx_type_14{ .issues = ((operand_8).graph).issues, .offsets = ((operand_8).graph).offsets, .targets = ((operand_8).graph).targets, };

                        break :block_10 @as(*const zx_type_14, operand_9);
                    }), .issue = (operand_8).issue, .marks = (operand_8).marks, .order = (operand_8).order, .root = (operand_8).root, };
                });
            };

            break :block_15 state_type_14{ .count = (operand_13).count, .cursors = (operand_13).cursors, .depth = (operand_13).depth, .edge = (operand_13).edge, .frames = (operand_13).frames, .graph = state_type_3{ .issues = ((operand_13).graph).issues, .offsets = ((operand_13).graph).offsets, .targets = ((operand_13).graph).targets, }, .issue = (operand_13).issue, .marks = (operand_13).marks, .order = (operand_13).order, .root = (operand_13).root, };
        };

        var state_items_18: []u64 = undefined;

        var state_items_started_19 = false;

        var state_items_20: []u64 = undefined;

        var state_items_started_21 = false;

        var state_items_22: []u64 = undefined;

        var state_items_started_23 = false;

        var state_items_24: []u64 = undefined;

        var state_items_started_25 = false;

        var state_1: state_type_14 = operand_16;

        var state_changed_17 = false;

        while ((((state_1).issue == @as(zx_type_11, .None)) and ((((state_1).root + @as(u64, 1)) < @as(u64, (((state_1).graph).offsets).len)) or ((state_1).depth != @as(u64, 0))))) {
            state_1 = block_111: {
                const value_47: state_type_14 = (if (((state_1).depth == @as(u64, 0))) block_44: {
                    const value_3: u64 = (state_1).root;
                    const value_11: state_type_14 = (if ((block_29: {
                        const operand_27 = (state_1).marks;
                        const operand_28 = value_3;

                        if ((operand_28 >= (operand_27).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_29 (operand_27)[@intCast(operand_28)];
                    } == @as(u64, 0))) block_43: {
                        const value_4: []const u64 = (state_1).marks;
                        const value_5: u64 = value_3;
                        const value_6: state_type_14 = block_42: {
                            break :block_42 state_type_14{ .count = (state_1).count, .cursors = (state_1).cursors, .depth = (state_1).depth, .edge = (state_1).edge, .frames = (state_1).frames, .graph = (state_1).graph, .issue = (state_1).issue, .marks = block_41: {
                                const operand_37 = value_4;
                                const operand_38 = value_5;

                                if ((operand_38 >= (operand_37).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_39 = @as(u64, 1);

                                break :block_41 block_40: {
                                    if ((!state_items_started_23)) {
                                        state_items_22 = (try (allocator).dupe(u64, operand_37));

                                        state_items_started_23 = true;
                                    }

                                    (state_items_22)[@intCast(operand_38)] = operand_39;

                                    break :block_40 state_items_22;
                                };
                            }, .order = (state_1).order, .root = (state_1).root, };
                        };
                        const value_7: []const u64 = (value_6).frames;
                        const value_8: u64 = @as(u64, 0);
                        const value_9: state_type_14 = block_36: {
                            break :block_36 state_type_14{ .count = (value_6).count, .cursors = (value_6).cursors, .depth = (value_6).depth, .edge = (value_6).edge, .frames = block_35: {
                                const operand_31 = value_7;
                                const operand_32 = value_8;

                                if ((operand_32 >= (operand_31).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_33 = value_3;

                                break :block_35 block_34: {
                                    if ((!state_items_started_21)) {
                                        state_items_20 = (try (allocator).dupe(u64, operand_31));

                                        state_items_started_21 = true;
                                    }

                                    (state_items_20)[@intCast(operand_32)] = operand_33;

                                    break :block_34 state_items_20;
                                };
                            }, .graph = (value_6).graph, .issue = (value_6).issue, .marks = (value_6).marks, .order = (value_6).order, .root = (value_6).root, };
                        };
                        const value_10: state_type_14 = block_30: {
                            break :block_30 state_type_14{ .count = (value_9).count, .cursors = (value_9).cursors, .depth = @as(u64, 1), .edge = (value_9).edge, .frames = (value_9).frames, .graph = (value_9).graph, .issue = (value_9).issue, .marks = (value_9).marks, .order = (value_9).order, .root = (value_9).root, };
                        };

                        break :block_43 value_10;
                    } else state_1);
                    const value_12: u64 = (value_11).root;
                    const value_13: state_type_14 = block_26: {
                        break :block_26 state_type_14{ .count = (value_11).count, .cursors = (value_11).cursors, .depth = (value_11).depth, .edge = (value_11).edge, .frames = (value_11).frames, .graph = (value_11).graph, .issue = (value_11).issue, .marks = (value_11).marks, .order = (value_11).order, .root = (value_12 + @as(u64, 1)), };
                    };

                    break :block_44 value_13;
                } else block_110: {
                    const value_14: u64 = block_109: {
                        const operand_107 = (state_1).frames;
                        const operand_108 = ((state_1).depth - @as(u64, 1));

                        if ((operand_108 >= (operand_107).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_109 (operand_107)[@intCast(operand_108)];
                    };
                    const value_15: u64 = block_106: {
                        const operand_104 = (state_1).cursors;
                        const operand_105 = value_14;

                        if ((operand_105 >= (operand_104).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_106 (operand_104)[@intCast(operand_105)];
                    };
                    const value_46: state_type_14 = (if ((value_15 == block_47: {
                        const operand_45 = ((state_1).graph).offsets;
                        const operand_46 = (value_14 + @as(u64, 1));

                        if ((operand_46 >= (operand_45).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_47 (operand_45)[@intCast(operand_46)];
                    })) block_62: {
                        const value_16: []const u64 = (state_1).marks;
                        const value_17: u64 = value_14;
                        const value_18: state_type_14 = block_61: {
                            break :block_61 state_type_14{ .count = (state_1).count, .cursors = (state_1).cursors, .depth = (state_1).depth, .edge = (state_1).edge, .frames = (state_1).frames, .graph = (state_1).graph, .issue = (state_1).issue, .marks = block_60: {
                                const operand_56 = value_16;
                                const operand_57 = value_17;

                                if ((operand_57 >= (operand_56).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_58 = @as(u64, 2);

                                break :block_60 block_59: {
                                    if ((!state_items_started_23)) {
                                        state_items_22 = (try (allocator).dupe(u64, operand_56));

                                        state_items_started_23 = true;
                                    }

                                    (state_items_22)[@intCast(operand_57)] = operand_58;

                                    break :block_59 state_items_22;
                                };
                            }, .order = (state_1).order, .root = (state_1).root, };
                        };
                        const value_19: []const u64 = (value_18).order;
                        const value_20: u64 = (value_18).count;
                        const value_21: state_type_14 = block_55: {
                            break :block_55 state_type_14{ .count = (value_18).count, .cursors = (value_18).cursors, .depth = (value_18).depth, .edge = (value_18).edge, .frames = (value_18).frames, .graph = (value_18).graph, .issue = (value_18).issue, .marks = (value_18).marks, .order = block_54: {
                                const operand_50 = value_19;
                                const operand_51 = value_20;

                                if ((operand_51 >= (operand_50).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_52 = value_14;

                                break :block_54 block_53: {
                                    if ((!state_items_started_25)) {
                                        state_items_24 = (try (allocator).dupe(u64, operand_50));

                                        state_items_started_25 = true;
                                    }

                                    (state_items_24)[@intCast(operand_51)] = operand_52;

                                    break :block_53 state_items_24;
                                };
                            }, .root = (value_18).root, };
                        };
                        const value_22: u64 = (value_21).count;
                        const value_23: state_type_14 = block_49: {
                            break :block_49 state_type_14{ .count = (value_22 + @as(u64, 1)), .cursors = (value_21).cursors, .depth = (value_21).depth, .edge = (value_21).edge, .frames = (value_21).frames, .graph = (value_21).graph, .issue = (value_21).issue, .marks = (value_21).marks, .order = (value_21).order, .root = (value_21).root, };
                        };
                        const value_24: u64 = (value_23).depth;
                        const value_25: state_type_14 = block_48: {
                            break :block_48 state_type_14{ .count = (value_23).count, .cursors = (value_23).cursors, .depth = (value_24 - @as(u64, 1)), .edge = (value_23).edge, .frames = (value_23).frames, .graph = (value_23).graph, .issue = (value_23).issue, .marks = (value_23).marks, .order = (value_23).order, .root = (value_23).root, };
                        };

                        break :block_62 value_25;
                    } else block_103: {
                        const value_26: zx_type_11 = block_102: {
                            const operand_100 = ((state_1).graph).issues;
                            const operand_101 = value_15;

                            if ((operand_101 >= (operand_100).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_102 (operand_100)[@intCast(operand_101)];
                        };
                        const value_27: u64 = block_99: {
                            const operand_97 = ((state_1).graph).targets;
                            const operand_98 = value_15;

                            if ((operand_98 >= (operand_97).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_99 (operand_97)[@intCast(operand_98)];
                        };
                        const value_28: []const u64 = (state_1).cursors;
                        const value_29: u64 = value_14;
                        const value_30: state_type_14 = block_96: {
                            break :block_96 state_type_14{ .count = (state_1).count, .cursors = block_95: {
                                const operand_91 = value_28;
                                const operand_92 = value_29;

                                if ((operand_92 >= (operand_91).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_93 = (value_15 + @as(u64, 1));

                                break :block_95 block_94: {
                                    if ((!state_items_started_19)) {
                                        state_items_18 = (try (allocator).dupe(u64, operand_91));

                                        state_items_started_19 = true;
                                    }

                                    (state_items_18)[@intCast(operand_92)] = operand_93;

                                    break :block_94 state_items_18;
                                };
                            }, .depth = (state_1).depth, .edge = (state_1).edge, .frames = (state_1).frames, .graph = (state_1).graph, .issue = (state_1).issue, .marks = (state_1).marks, .order = (state_1).order, .root = (state_1).root, };
                        };
                        const value_45: state_type_14 = (if ((value_26 != @as(zx_type_11, .None))) block_65: {
                            const value_31: state_type_14 = block_64: {
                                break :block_64 state_type_14{ .count = (value_30).count, .cursors = (value_30).cursors, .depth = (value_30).depth, .edge = (value_30).edge, .frames = (value_30).frames, .graph = (value_30).graph, .issue = value_26, .marks = (value_30).marks, .order = (value_30).order, .root = (value_30).root, };
                            };
                            const value_32: state_type_14 = block_63: {
                                break :block_63 state_type_14{ .count = (value_31).count, .cursors = (value_31).cursors, .depth = (value_31).depth, .edge = value_15, .frames = (value_31).frames, .graph = (value_31).graph, .issue = (value_31).issue, .marks = (value_31).marks, .order = (value_31).order, .root = (value_31).root, };
                            };

                            break :block_65 value_32;
                        } else block_90: {
                            const value_44: state_type_14 = (if ((block_68: {
                                const operand_66 = (value_30).marks;
                                const operand_67 = value_27;

                                if ((operand_67 >= (operand_66).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_68 (operand_66)[@intCast(operand_67)];
                            } == @as(u64, 1))) block_71: {
                                const value_33: state_type_14 = block_70: {
                                    break :block_70 state_type_14{ .count = (value_30).count, .cursors = (value_30).cursors, .depth = (value_30).depth, .edge = (value_30).edge, .frames = (value_30).frames, .graph = (value_30).graph, .issue = @as(zx_type_11, .Cycle), .marks = (value_30).marks, .order = (value_30).order, .root = (value_30).root, };
                                };
                                const value_34: state_type_14 = block_69: {
                                    break :block_69 state_type_14{ .count = (value_33).count, .cursors = (value_33).cursors, .depth = (value_33).depth, .edge = value_15, .frames = (value_33).frames, .graph = (value_33).graph, .issue = (value_33).issue, .marks = (value_33).marks, .order = (value_33).order, .root = (value_33).root, };
                                };

                                break :block_71 value_34;
                            } else block_89: {
                                const value_43: state_type_14 = (if ((block_74: {
                                    const operand_72 = (value_30).marks;
                                    const operand_73 = value_27;

                                    if ((operand_73 >= (operand_72).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_74 (operand_72)[@intCast(operand_73)];
                                } == @as(u64, 0))) block_88: {
                                    const value_35: []const u64 = (value_30).marks;
                                    const value_36: u64 = value_27;
                                    const value_37: state_type_14 = block_87: {
                                        break :block_87 state_type_14{ .count = (value_30).count, .cursors = (value_30).cursors, .depth = (value_30).depth, .edge = (value_30).edge, .frames = (value_30).frames, .graph = (value_30).graph, .issue = (value_30).issue, .marks = block_86: {
                                            const operand_82 = value_35;
                                            const operand_83 = value_36;

                                            if ((operand_83 >= (operand_82).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            const operand_84 = @as(u64, 1);

                                            break :block_86 block_85: {
                                                if ((!state_items_started_23)) {
                                                    state_items_22 = (try (allocator).dupe(u64, operand_82));

                                                    state_items_started_23 = true;
                                                }

                                                (state_items_22)[@intCast(operand_83)] = operand_84;

                                                break :block_85 state_items_22;
                                            };
                                        }, .order = (value_30).order, .root = (value_30).root, };
                                    };
                                    const value_38: []const u64 = (value_37).frames;
                                    const value_39: u64 = (value_37).depth;
                                    const value_40: state_type_14 = block_81: {
                                        break :block_81 state_type_14{ .count = (value_37).count, .cursors = (value_37).cursors, .depth = (value_37).depth, .edge = (value_37).edge, .frames = block_80: {
                                            const operand_76 = value_38;
                                            const operand_77 = value_39;

                                            if ((operand_77 >= (operand_76).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            const operand_78 = value_27;

                                            break :block_80 block_79: {
                                                if ((!state_items_started_21)) {
                                                    state_items_20 = (try (allocator).dupe(u64, operand_76));

                                                    state_items_started_21 = true;
                                                }

                                                (state_items_20)[@intCast(operand_77)] = operand_78;

                                                break :block_79 state_items_20;
                                            };
                                        }, .graph = (value_37).graph, .issue = (value_37).issue, .marks = (value_37).marks, .order = (value_37).order, .root = (value_37).root, };
                                    };
                                    const value_41: u64 = (value_40).depth;
                                    const value_42: state_type_14 = block_75: {
                                        break :block_75 state_type_14{ .count = (value_40).count, .cursors = (value_40).cursors, .depth = (value_41 + @as(u64, 1)), .edge = (value_40).edge, .frames = (value_40).frames, .graph = (value_40).graph, .issue = (value_40).issue, .marks = (value_40).marks, .order = (value_40).order, .root = (value_40).root, };
                                    };

                                    break :block_88 value_42;
                                } else value_30);

                                break :block_89 value_43;
                            });

                            break :block_90 value_44;
                        });

                        break :block_103 value_45;
                    });

                    break :block_110 value_46;
                });

                break :block_111 value_47;
            };

            state_changed_17 = true;
        }

        break :block_119 block_118: {
            const operand_112 = (state_1).order;
            const operand_113 = (state_1).count;
            const operand_114 = (state_1).issue;
            const operand_115 = (state_1).edge;

            break :block_118 block_117: {
                const operand_116 = (try (allocator).create(zx_type_16));

                (operand_116).* = @as(zx_type_16, zx_type_16{ .order = operand_112, .count = operand_113, .issue = operand_114, .edge = operand_115, });

                break :block_117 @as(*const zx_type_16, operand_116);
            };
        };
    };
}

fn function_1_value(allocator: ((std).mem).Allocator, in: value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_16_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    const value_48: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_263: {
        const operand_128 = block_127: {
            break :block_127 (try function_0_value(allocator, in));
        };

        var state_items_130: []u64 = undefined;

        var state_items_started_131 = false;

        var state_items_132: []u64 = undefined;

        var state_items_started_133 = false;

        var state_items_134: []u64 = undefined;

        var state_items_started_135 = false;

        var state_items_136: []u64 = undefined;

        var state_items_started_137 = false;

        var state_126: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = operand_128;

        var state_changed_129 = false;

        while ((((state_126).issue == @as(zx_type_11, .None)) and ((((state_126).root + @as(u64, 1)) < @as(u64, (((state_126).graph).offsets).len)) or ((state_126).depth != @as(u64, 0))))) {
            state_126 = block_261: {
                const value_47: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = (if (((state_126).depth == @as(u64, 0))) block_164: {
                    const value_3: u64 = (state_126).root;
                    const value_11: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = (if ((block_143: {
                        const operand_141 = (state_126).marks;
                        const operand_142 = block_140: {
                            break :block_140 value_3;
                        };

                        if ((operand_142 >= (operand_141).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_143 (operand_141)[@intCast(operand_142)];
                    } == @as(u64, 0))) block_163: {
                        const value_4: []const u64 = (state_126).marks;
                        const value_5: u64 = block_162: {
                            break :block_162 value_3;
                        };
                        const value_6: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_161: {
                            break :block_161 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (state_126).count, .cursors = (state_126).cursors, .depth = (state_126).depth, .edge = (state_126).edge, .frames = (state_126).frames, .graph = (state_126).graph, .issue = (state_126).issue, .marks = block_160: {
                                const operand_155 = block_154: {
                                    break :block_154 value_4;
                                };
                                const operand_157 = block_156: {
                                    break :block_156 value_5;
                                };

                                if ((operand_157 >= (operand_155).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_158 = @as(u64, 1);

                                break :block_160 block_159: {
                                    if ((!state_items_started_135)) {
                                        state_items_134 = (try (allocator).dupe(u64, operand_155));

                                        state_items_started_135 = true;
                                    }

                                    (state_items_134)[@intCast(operand_157)] = operand_158;

                                    break :block_159 state_items_134;
                                };
                            }, .order = (state_126).order, .root = (state_126).root, });
                        };
                        const value_7: []const u64 = (value_6).frames;
                        const value_8: u64 = @as(u64, 0);
                        const value_9: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_153: {
                            break :block_153 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_6).count, .cursors = (value_6).cursors, .depth = (value_6).depth, .edge = (value_6).edge, .frames = block_152: {
                                const operand_146 = block_145: {
                                    break :block_145 value_7;
                                };
                                const operand_148 = block_147: {
                                    break :block_147 value_8;
                                };

                                if ((operand_148 >= (operand_146).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_150 = block_149: {
                                    break :block_149 value_3;
                                };

                                break :block_152 block_151: {
                                    if ((!state_items_started_133)) {
                                        state_items_132 = (try (allocator).dupe(u64, operand_146));

                                        state_items_started_133 = true;
                                    }

                                    (state_items_132)[@intCast(operand_148)] = operand_150;

                                    break :block_151 state_items_132;
                                };
                            }, .graph = (value_6).graph, .issue = (value_6).issue, .marks = (value_6).marks, .order = (value_6).order, .root = (value_6).root, });
                        };
                        const value_10: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_144: {
                            break :block_144 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_9).count, .cursors = (value_9).cursors, .depth = @as(u64, 1), .edge = (value_9).edge, .frames = (value_9).frames, .graph = (value_9).graph, .issue = (value_9).issue, .marks = (value_9).marks, .order = (value_9).order, .root = (value_9).root, });
                        };

                        break :block_163 value_10;
                    } else state_126);
                    const value_12: u64 = (value_11).root;
                    const value_13: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_139: {
                        break :block_139 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_11).count, .cursors = (value_11).cursors, .depth = (value_11).depth, .edge = (value_11).edge, .frames = (value_11).frames, .graph = (value_11).graph, .issue = (value_11).issue, .marks = (value_11).marks, .order = (value_11).order, .root = (block_138: {
                            break :block_138 value_12;
                        } + @as(u64, 1)), });
                    };

                    break :block_164 value_13;
                } else block_260: {
                    const value_14: u64 = block_259: {
                        const operand_257 = (state_126).frames;
                        const operand_258 = ((state_126).depth - @as(u64, 1));

                        if ((operand_258 >= (operand_257).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_259 (operand_257)[@intCast(operand_258)];
                    };
                    const value_15: u64 = block_256: {
                        const operand_254 = (state_126).cursors;
                        const operand_255 = block_253: {
                            break :block_253 value_14;
                        };

                        if ((operand_255 >= (operand_254).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_256 (operand_254)[@intCast(operand_255)];
                    };
                    const value_46: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = (if ((block_165: {
                        break :block_165 value_15;
                    } == block_169: {
                        const operand_167 = ((state_126).graph).offsets;
                        const operand_168 = (block_166: {
                            break :block_166 value_14;
                        } + @as(u64, 1));

                        if ((operand_168 >= (operand_167).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_169 (operand_167)[@intCast(operand_168)];
                    })) block_192: {
                        const value_16: []const u64 = (state_126).marks;
                        const value_17: u64 = block_191: {
                            break :block_191 value_14;
                        };
                        const value_18: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_190: {
                            break :block_190 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (state_126).count, .cursors = (state_126).cursors, .depth = (state_126).depth, .edge = (state_126).edge, .frames = (state_126).frames, .graph = (state_126).graph, .issue = (state_126).issue, .marks = block_189: {
                                const operand_184 = block_183: {
                                    break :block_183 value_16;
                                };
                                const operand_186 = block_185: {
                                    break :block_185 value_17;
                                };

                                if ((operand_186 >= (operand_184).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_187 = @as(u64, 2);

                                break :block_189 block_188: {
                                    if ((!state_items_started_135)) {
                                        state_items_134 = (try (allocator).dupe(u64, operand_184));

                                        state_items_started_135 = true;
                                    }

                                    (state_items_134)[@intCast(operand_186)] = operand_187;

                                    break :block_188 state_items_134;
                                };
                            }, .order = (state_126).order, .root = (state_126).root, });
                        };
                        const value_19: []const u64 = (value_18).order;
                        const value_20: u64 = (value_18).count;
                        const value_21: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_182: {
                            break :block_182 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_18).count, .cursors = (value_18).cursors, .depth = (value_18).depth, .edge = (value_18).edge, .frames = (value_18).frames, .graph = (value_18).graph, .issue = (value_18).issue, .marks = (value_18).marks, .order = block_181: {
                                const operand_175 = block_174: {
                                    break :block_174 value_19;
                                };
                                const operand_177 = block_176: {
                                    break :block_176 value_20;
                                };

                                if ((operand_177 >= (operand_175).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_179 = block_178: {
                                    break :block_178 value_14;
                                };

                                break :block_181 block_180: {
                                    if ((!state_items_started_137)) {
                                        state_items_136 = (try (allocator).dupe(u64, operand_175));

                                        state_items_started_137 = true;
                                    }

                                    (state_items_136)[@intCast(operand_177)] = operand_179;

                                    break :block_180 state_items_136;
                                };
                            }, .root = (value_18).root, });
                        };
                        const value_22: u64 = (value_21).count;
                        const value_23: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_173: {
                            break :block_173 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (block_172: {
                                break :block_172 value_22;
                            } + @as(u64, 1)), .cursors = (value_21).cursors, .depth = (value_21).depth, .edge = (value_21).edge, .frames = (value_21).frames, .graph = (value_21).graph, .issue = (value_21).issue, .marks = (value_21).marks, .order = (value_21).order, .root = (value_21).root, });
                        };
                        const value_24: u64 = (value_23).depth;
                        const value_25: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_171: {
                            break :block_171 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_23).count, .cursors = (value_23).cursors, .depth = (block_170: {
                                break :block_170 value_24;
                            } - @as(u64, 1)), .edge = (value_23).edge, .frames = (value_23).frames, .graph = (value_23).graph, .issue = (value_23).issue, .marks = (value_23).marks, .order = (value_23).order, .root = (value_23).root, });
                        };

                        break :block_192 value_25;
                    } else block_252: {
                        const value_26: zx_type_11 = block_251: {
                            const operand_249 = ((state_126).graph).issues;
                            const operand_250 = block_248: {
                                break :block_248 value_15;
                            };

                            if ((operand_250 >= (operand_249).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_251 (operand_249)[@intCast(operand_250)];
                        };
                        const value_27: u64 = block_247: {
                            const operand_245 = ((state_126).graph).targets;
                            const operand_246 = block_244: {
                                break :block_244 value_15;
                            };

                            if ((operand_246 >= (operand_245).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_247 (operand_245)[@intCast(operand_246)];
                        };
                        const value_28: []const u64 = (state_126).cursors;
                        const value_29: u64 = block_243: {
                            break :block_243 value_14;
                        };
                        const value_30: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_242: {
                            break :block_242 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (state_126).count, .cursors = block_241: {
                                const operand_235 = block_234: {
                                    break :block_234 value_28;
                                };
                                const operand_237 = block_236: {
                                    break :block_236 value_29;
                                };

                                if ((operand_237 >= (operand_235).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_239 = (block_238: {
                                    break :block_238 value_15;
                                } + @as(u64, 1));

                                break :block_241 block_240: {
                                    if ((!state_items_started_131)) {
                                        state_items_130 = (try (allocator).dupe(u64, operand_235));

                                        state_items_started_131 = true;
                                    }

                                    (state_items_130)[@intCast(operand_237)] = operand_239;

                                    break :block_240 state_items_130;
                                };
                            }, .depth = (state_126).depth, .edge = (state_126).edge, .frames = (state_126).frames, .graph = (state_126).graph, .issue = (state_126).issue, .marks = (state_126).marks, .order = (state_126).order, .root = (state_126).root, });
                        };
                        const value_45: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = (if ((block_193: {
                            break :block_193 value_26;
                        } != @as(zx_type_11, .None))) block_198: {
                            const value_31: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_197: {
                                break :block_197 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_30).count, .cursors = (value_30).cursors, .depth = (value_30).depth, .edge = (value_30).edge, .frames = (value_30).frames, .graph = (value_30).graph, .issue = block_196: {
                                    break :block_196 value_26;
                                }, .marks = (value_30).marks, .order = (value_30).order, .root = (value_30).root, });
                            };
                            const value_32: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_195: {
                                break :block_195 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_31).count, .cursors = (value_31).cursors, .depth = (value_31).depth, .edge = block_194: {
                                    break :block_194 value_15;
                                }, .frames = (value_31).frames, .graph = (value_31).graph, .issue = (value_31).issue, .marks = (value_31).marks, .order = (value_31).order, .root = (value_31).root, });
                            };

                            break :block_198 value_32;
                        } else block_233: {
                            const value_44: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = (if ((block_202: {
                                const operand_200 = (value_30).marks;
                                const operand_201 = block_199: {
                                    break :block_199 value_27;
                                };

                                if ((operand_201 >= (operand_200).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_202 (operand_200)[@intCast(operand_201)];
                            } == @as(u64, 1))) block_206: {
                                const value_33: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_205: {
                                    break :block_205 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_30).count, .cursors = (value_30).cursors, .depth = (value_30).depth, .edge = (value_30).edge, .frames = (value_30).frames, .graph = (value_30).graph, .issue = @as(zx_type_11, .Cycle), .marks = (value_30).marks, .order = (value_30).order, .root = (value_30).root, });
                                };
                                const value_34: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_204: {
                                    break :block_204 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_33).count, .cursors = (value_33).cursors, .depth = (value_33).depth, .edge = block_203: {
                                        break :block_203 value_15;
                                    }, .frames = (value_33).frames, .graph = (value_33).graph, .issue = (value_33).issue, .marks = (value_33).marks, .order = (value_33).order, .root = (value_33).root, });
                                };

                                break :block_206 value_34;
                            } else block_232: {
                                const value_43: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = (if ((block_210: {
                                    const operand_208 = (value_30).marks;
                                    const operand_209 = block_207: {
                                        break :block_207 value_27;
                                    };

                                    if ((operand_209 >= (operand_208).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_210 (operand_208)[@intCast(operand_209)];
                                } == @as(u64, 0))) block_231: {
                                    const value_35: []const u64 = (value_30).marks;
                                    const value_36: u64 = block_230: {
                                        break :block_230 value_27;
                                    };
                                    const value_37: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_229: {
                                        break :block_229 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_30).count, .cursors = (value_30).cursors, .depth = (value_30).depth, .edge = (value_30).edge, .frames = (value_30).frames, .graph = (value_30).graph, .issue = (value_30).issue, .marks = block_228: {
                                            const operand_223 = block_222: {
                                                break :block_222 value_35;
                                            };
                                            const operand_225 = block_224: {
                                                break :block_224 value_36;
                                            };

                                            if ((operand_225 >= (operand_223).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            const operand_226 = @as(u64, 1);

                                            break :block_228 block_227: {
                                                if ((!state_items_started_135)) {
                                                    state_items_134 = (try (allocator).dupe(u64, operand_223));

                                                    state_items_started_135 = true;
                                                }

                                                (state_items_134)[@intCast(operand_225)] = operand_226;

                                                break :block_227 state_items_134;
                                            };
                                        }, .order = (value_30).order, .root = (value_30).root, });
                                    };
                                    const value_38: []const u64 = (value_37).frames;
                                    const value_39: u64 = (value_37).depth;
                                    const value_40: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_221: {
                                        break :block_221 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_37).count, .cursors = (value_37).cursors, .depth = (value_37).depth, .edge = (value_37).edge, .frames = block_220: {
                                            const operand_214 = block_213: {
                                                break :block_213 value_38;
                                            };
                                            const operand_216 = block_215: {
                                                break :block_215 value_39;
                                            };

                                            if ((operand_216 >= (operand_214).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            const operand_218 = block_217: {
                                                break :block_217 value_27;
                                            };

                                            break :block_220 block_219: {
                                                if ((!state_items_started_133)) {
                                                    state_items_132 = (try (allocator).dupe(u64, operand_214));

                                                    state_items_started_133 = true;
                                                }

                                                (state_items_132)[@intCast(operand_216)] = operand_218;

                                                break :block_219 state_items_132;
                                            };
                                        }, .graph = (value_37).graph, .issue = (value_37).issue, .marks = (value_37).marks, .order = (value_37).order, .root = (value_37).root, });
                                    };
                                    const value_41: u64 = (value_40).depth;
                                    const value_42: value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8 = block_212: {
                                        break :block_212 @as(value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8, value_zx_type_15_aaa56cff424361d44bfd6e096281a697ea7ba1f132207b5ae6f511a597d171e8{ .count = (value_40).count, .cursors = (value_40).cursors, .depth = (block_211: {
                                            break :block_211 value_41;
                                        } + @as(u64, 1)), .edge = (value_40).edge, .frames = (value_40).frames, .graph = (value_40).graph, .issue = (value_40).issue, .marks = (value_40).marks, .order = (value_40).order, .root = (value_40).root, });
                                    };

                                    break :block_231 value_42;
                                } else value_30);

                                break :block_232 value_43;
                            });

                            break :block_233 value_44;
                        });

                        break :block_252 value_45;
                    });

                    break :block_260 value_46;
                });

                break :block_261 value_47;
            };

            state_changed_129 = true;
        }

        break :block_263 (if (state_changed_129) state_126 else operand_128);
    };

    return block_125: {
        const operand_121 = (value_48).order;
        const operand_122 = (value_48).count;
        const operand_123 = (value_48).issue;
        const operand_124 = (value_48).edge;

        break :block_125 @as(value_zx_type_16_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_16_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .order = operand_121, .count = operand_122, .issue = operand_123, .edge = operand_124, });
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_14) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_16 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: *const zx_type_16 = block_5: {
        const operand_1 = in;
        const operand_2 = (try function_1_value(allocator, value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .issues = (operand_1).issues, .offsets = (operand_1).offsets, .targets = (operand_1).targets, .zx_origin = operand_1, }));

        break :block_5 (if (((operand_2).zx_origin != null)) (operand_2).zx_origin.? else block_4: {
            const operand_3 = (try (allocator).create(zx_type_16));

            (operand_3).* = zx_type_16{ .count = (operand_2).count, .edge = (operand_2).edge, .issue = (operand_2).issue, .order = (operand_2).order, };

            break :block_4 @as(*const zx_type_16, operand_3);
        });
    };

    return value_1;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_16_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    const value_1: value_zx_type_16_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_6: {
        break :block_6 (try function_1_value(allocator, in));
    };

    return value_1;
}

