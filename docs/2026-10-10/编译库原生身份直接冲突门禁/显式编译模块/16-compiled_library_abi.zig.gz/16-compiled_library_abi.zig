pub const zx_type_11 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
};

pub const zx_type_15 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
};

pub const zx_type_16 = struct {
    base: *const zx_type_15,
    delta: *const zx_type_15,
};

pub const zx_type_17 = struct {
    names: []const []const u8,
    origins: *const zx_type_15,
};

pub const zx_type_18 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_19 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_20 = struct {
    base: *const zx_type_19,
    delta: *const zx_type_19,
};

pub const zx_type_21 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_22 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_18,
    label: []const u8,
    second: u32,
};

pub const zx_type_23 = struct {
    index: u64,
    names: []const []const u8,
    origins: *const zx_type_15,
    table: *const zx_type_19,
};

pub const zx_type_24 = struct {
    index: u64,
    names: []const []const u8,
    origins: *const zx_type_15,
};

pub const zx_type_25 = struct {
    names: []const []const u8,
    origins: *const zx_type_15,
    table: *const zx_type_19,
};

pub const zx_type_26 = struct {
    artifact: []const u8,
    instance: []const u8,
    load: bool,
};

pub const zx_type_27 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_28 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_29 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_30 = enum { Negate, Not, };

pub const zx_type_31 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_42 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_31,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_28,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_27,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_29,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_30,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_43 = enum { Copy, Borrowed, Owned, };

pub const zx_type_45 = struct {
    names: []const []const u8,
    ownership: []const zx_type_43,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_46 = enum { Requires, Ensures, };

pub const zx_type_50 = struct {
    expressions: []const *const zx_type_42,
    kinds: []const zx_type_46,
    predicates: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    symbols: []const *const zx_type_45,
};

pub const zx_type_51 = enum { Evaluate, Constant, Parallel, Destructure, Branch, Switch, StoreSet, Result, };

pub const zx_type_53 = struct {
    block_count: []const u32,
    block_first: []const u32,
    branch_conditions: []const u32,
    branch_no: []const u32,
    branch_yes: []const u32,
    case_bodies: []const u32,
    case_values: []const ?u32,
    constant_symbols: []const u32,
    constant_values: []const u32,
    destructure_count: []const u32,
    destructure_first: []const u32,
    destructure_symbols: []const ?u32,
    destructure_values: []const u32,
    evaluations: []const u32,
    parallel_count: []const u32,
    parallel_first: []const u32,
    parallel_symbols: []const ?u32,
    parallel_values: []const u32,
    results: []const ?u32,
    selection_count: []const u32,
    selection_exhaustive: []const bool,
    selection_first: []const u32,
    selection_subjects: []const u32,
    setter_slots: []const u32,
    setter_values: []const u32,
    statement_kinds: []const zx_type_51,
    statement_payloads: []const u32,
};

pub const zx_type_61 = struct {
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_43,
};

pub const zx_type_62 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_63 = enum { transaction, orchestration, };

pub const zx_type_68 = struct {
    contracts: []const *const zx_type_50,
    control: []const *const zx_type_53,
    expressions: []const *const zx_type_42,
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_43,
    roots: []const ?u32,
    store_modes: []const zx_type_63,
    stores: []const *const zx_type_62,
    symbols: []const *const zx_type_45,
};

pub const zx_type_70 = struct {
    identities: []const ?[]const u8,
    import_names: []const []const u8,
    specifiers: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    type_namespaces: []const []const []const u8,
};

pub const zx_type_71 = struct {
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    output_types: []const u32,
};

pub const zx_type_72 = struct {
    control: *const zx_type_53,
    expressions: *const zx_type_42,
    root: ?u32,
    stores: *const zx_type_62,
    symbols: *const zx_type_45,
};

pub const zx_type_73 = struct {
    expressions: *const zx_type_42,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_45,
};

pub const zx_type_74 = struct {
    functions: *const zx_type_68,
    max_offset: u64,
    maximum_count: u64,
    modules: *const zx_type_70,
    scalar_count: u64,
    table: *const zx_type_19,
};

pub const zx_type_75 = struct {
    body: *const zx_type_72,
    contracts: *const zx_type_50,
    input_type: u32,
    output_ownership: zx_type_43,
    output_type: u32,
    transaction: bool,
    type_only: bool,
};

pub const zx_type_76 = struct {
    context: *const zx_type_74,
    expected_version: u64,
    export_names: []const []const u8,
    export_types: []const u32,
    unit: *const zx_type_75,
    version: u64,
};

pub const zx_type_77 = struct {
    functions: []const ?u32,
    names: []const []const u8,
    paths: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
};

pub const zx_type_78 = struct {
    functions: []const u32,
    identities: []const []const u8,
    versions: []const u32,
};

pub const zx_type_79 = struct {
    exports: *const zx_type_77,
    initializers: *const zx_type_78,
    origin_names: []const []const u8,
    origins: *const zx_type_15,
    program: *const zx_type_76,
};

pub const zx_type_80 = struct {
    function_count: u64,
    natives: *const zx_type_70,
    origin_names: []const []const u8,
    origins: *const zx_type_15,
    types: *const zx_type_19,
};

pub const zx_type_81 = struct {
    artifact: []const u8,
    destination: *const zx_type_80,
    graph: *const zx_type_79,
    instance: []const u8,
    load: bool,
    seed: bool,
};

pub const zx_type_82 = struct {
    exports: *const zx_type_77,
    functions: *const zx_type_68,
    initializers: *const zx_type_78,
    natives: *const zx_type_70,
    origins: *const zx_type_15,
    status: u64,
    types: *const zx_type_19,
};

pub const zx_type_83 = struct {
    maximum_count: u64,
    scalar_count: u64,
    table: *const zx_type_19,
};

pub const zx_type_84 = enum { Value, Callable, TypeDecl, };

pub const zx_type_85 = struct {
    kind: zx_type_84,
    name: []const u8,
};

pub const zx_type_86 = struct {
    left: []const u8,
    right: []const u8,
};

pub const zx_type_87 = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    table: *const zx_type_19,
};

pub const zx_type_88 = struct {
    count: u64,
    errors: bool,
    first: u64,
    values: []const []const u8,
};

pub const zx_type_89 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_19,
};

pub const zx_type_90 = struct {
    scalar_count: u64,
    table: *const zx_type_19,
};

pub const zx_type_91 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
};

pub const zx_type_92 = struct {
    max_offset: u64,
    symbols: *const zx_type_45,
};

pub const zx_type_93 = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_42,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
};

pub const zx_type_94 = struct {
    kind: zx_type_27,
    payload: u64,
    state: *const zx_type_93,
};

pub const zx_type_95 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
};

pub const zx_type_96 = struct {
    max_offset: u64,
    table: *const zx_type_42,
};

pub const zx_type_97 = struct {
    block: u64,
    control: *const zx_type_53,
};

pub const zx_type_98 = struct {
    control: *const zx_type_53,
    root: ?u32,
};

pub const zx_type_99 = struct {
    count: u64,
    values: []const ?u32,
};

pub const zx_type_100 = struct {
    count: u64,
    values: []const u32,
};

pub const zx_type_101 = struct {
    contracts: *const zx_type_50,
    max_offset: u64,
};

pub const zx_type_102 = struct {
    functions: *const zx_type_68,
    index: u64,
};

pub const zx_type_103 = enum { File, Package, Zig, C, Standard, LegacyLibrary, Invalid, };

pub const zx_type_104 = struct {
    index: u64,
    modules: *const zx_type_70,
};

pub const zx_type_105 = struct {
    modules: *const zx_type_70,
    table: *const zx_type_19,
};

pub const zx_type_106 = struct {
    functions: *const zx_type_71,
    index: u64,
    modules: *const zx_type_70,
};

pub const zx_type_107 = struct {
    context: *const zx_type_105,
    type_id: u64,
};

pub const zx_type_108 = struct {
    id: u32,
    tables: *const zx_type_20,
};

pub const zx_type_109 = struct {
    children: []const u32,
    fields: *const zx_type_21,
    first: u32,
    kind: zx_type_18,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_110 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_111 = struct {
    delta: *const zx_type_19,
    id: u32,
};

pub const zx_type_112 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: *const zx_type_20,
};

pub const zx_type_113 = struct {
    id: u32,
    native_references: bool,
    tables: *const zx_type_20,
};

pub const zx_type_114 = struct {
    id: u32,
    native_references: bool,
    table: *const zx_type_19,
};

pub const zx_type_115 = struct {
    index: u64,
    paths: []const []const u8,
};

pub const zx_type_116 = struct {
    paths: []const []const u8,
    slot_types: []const u32,
    table: *const zx_type_19,
    type_only: bool,
};

pub const zx_type_117 = struct {
    context: *const zx_type_74,
    unit: *const zx_type_75,
};

pub const zx_type_118 = struct {
    expressions: *const zx_type_42,
    id: u32,
    index: u64,
    type_id: u32,
};

pub const zx_type_119 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_62,
};

pub const zx_type_120 = struct {
    expressions: *const zx_type_42,
    functions: *const zx_type_119,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_62,
    symbols: *const zx_type_45,
    table: *const zx_type_19,
};

pub const zx_type_121 = struct {
    context: *const zx_type_120,
    kind: zx_type_27,
    payload: u64,
    target: zx_type_18,
    type_id: u32,
};

pub const zx_type_122 = enum { Other, Integer, Signed, Float, };

pub const zx_type_125 = struct {
    available: *const zx_type_62,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_62,
    slots: []const u32,
};

pub const zx_type_126 = struct {
    table: *const zx_type_19,
    type_id: u32,
};

pub const zx_type_127 = struct {
    contracts: *const zx_type_50,
    input_type: u32,
    max_offset: u64,
    output_type: u32,
    table: *const zx_type_19,
};

pub const zx_type_128 = struct {
    index: u64,
    program: *const zx_type_127,
};

pub const zx_type_129 = struct {
    control: *const zx_type_53,
    returns: []const bool,
    selection: u64,
};

pub const zx_type_130 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_42,
    limit: u64,
};

pub const zx_type_131 = struct {
    expressions: []const *const zx_type_42,
    native_concurrent: []const bool,
    native_modules: []const ?u32,
    stores: []const *const zx_type_62,
};

pub const zx_type_132 = struct {
    concurrent: bool,
    functions: *const zx_type_131,
};

pub const zx_type_133 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
};

pub const zx_type_134 = struct {
    captures: u64,
    nonnull: u64,
};

pub const zx_type_135 = struct {
    conditions: []const u64,
    facts: *const zx_type_133,
    truths: []const bool,
};

pub const zx_type_136 = enum { Block, BlockNext, Expression, Declare, ScopeDeclare, Destructure, Branch, BranchPost, Switch, Restore, RestoreFacts, Assume, IterationCondition, IterationBody, Transform, Invalid, };

pub const zx_type_137 = struct {
    a: u64,
    b: u64,
    c: u64,
    phase: zx_type_136,
};

pub const zx_type_138 = struct {
    body: *const zx_type_72,
    functions: *const zx_type_131,
    output_type: u32,
    table: *const zx_type_19,
    transaction: bool,
};

pub const zx_type_139 = struct {
    concurrent: []const bool,
    pure: []const bool,
    returns: []const bool,
};

pub const zx_type_140 = struct {
    prepared: *const zx_type_139,
    program: *const zx_type_138,
};

pub const zx_type_141 = struct {
    active: []const bool,
    changed_symbols: []const u64,
    changed_values: []const bool,
    declared: []const bool,
    owners: []const u64,
};

pub const zx_type_143 = struct {
    a: []const u64,
    b: []const u64,
    c: []const u64,
    phases: []const zx_type_136,
};

pub const zx_type_144 = struct {
    activity: *const zx_type_141,
    frames: *const zx_type_143,
    refinement: *const zx_type_135,
};

pub const zx_type_145 = struct {
    context: *const zx_type_140,
    frame: *const zx_type_137,
    state: *const zx_type_144,
};

pub const zx_type_146 = enum { Ordinary, Scope, Callback, };

pub const zx_type_147 = struct {
    state: *const zx_type_144,
    valid: bool,
};

pub const zx_type_148 = struct {
    facts: *const zx_type_133,
    symbol: u32,
};

pub const zx_type_149 = struct {
    expressions: *const zx_type_42,
    facts: *const zx_type_133,
    payload: u64,
    truth: bool,
};

pub const zx_type_150 = struct {
    condition: u64,
    expressions: *const zx_type_42,
    state: *const zx_type_135,
    truth: bool,
};

pub const zx_type_151 = struct {
    facts: *const zx_type_133,
    mark: *const zx_type_134,
};

pub const zx_type_152 = struct {
    activity: *const zx_type_141,
    mark: u64,
};

pub const zx_type_153 = struct {
    context: *const zx_type_140,
    statement: u64,
};

pub const zx_type_154 = struct {
    frame: *const zx_type_137,
    state: *const zx_type_144,
};

pub const zx_type_155 = struct {
    activity: *const zx_type_141,
    symbol: u64,
    value: bool,
};

pub const zx_type_156 = struct {
    mode: zx_type_146,
    owner: u64,
    program: *const zx_type_138,
    state: *const zx_type_144,
    symbol: u64,
    type_id: u32,
};

pub const zx_type_157 = struct {
    err: u32,
    facts: *const zx_type_133,
    result: u32,
};

pub const zx_type_158 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_42,
    facts: *const zx_type_133,
    result: ?u32,
    value: u64,
};

pub const zx_type_159 = struct {
    count: u64,
    depth: u64,
    first: u64,
    flags: u64,
    state: *const zx_type_144,
    values: []const u32,
};

pub const zx_type_160 = struct {
    count: u64,
    expressions: *const zx_type_42,
    facts: *const zx_type_133,
    first: u64,
};

pub const zx_type_161 = struct {
    active: []const bool,
    count: u64,
    first: u64,
    symbols: []const u32,
};

pub const zx_type_162 = struct {
    payload: u64,
    position: u64,
    program: *const zx_type_138,
};

pub const zx_type_164 = struct {
    expressions: *const zx_type_42,
    left: u64,
    right: u64,
};

pub const zx_type_165 = struct {
    payload: u64,
    program: *const zx_type_138,
};

pub const zx_type_166 = struct {
    context: *const zx_type_140,
    state: *const zx_type_144,
};

pub const zx_type_167 = struct {
    body: *const zx_type_72,
    input_type: u32,
    output_type: u32,
    table: *const zx_type_19,
};

pub const zx_type_168 = struct {
    ownership: []const zx_type_43,
    stores: []const *const zx_type_62,
};

pub const zx_type_169 = struct {
    body: ?u32,
    control: *const zx_type_53,
    expressions: *const zx_type_42,
    functions: *const zx_type_168,
    symbols: *const zx_type_45,
    type_only: bool,
    types: *const zx_type_20,
};

pub const zx_type_170 = struct {
    id: u64,
    types: *const zx_type_20,
};

pub const zx_type_171 = struct {
    expression: u64,
    expressions: *const zx_type_42,
    index: u64,
};

pub const zx_type_172 = struct {
    expression: u64,
    found: bool,
};

pub const zx_type_173 = struct {
    expression: u64,
    expressions: *const zx_type_42,
    locals: []const bool,
};

pub const zx_type_174 = struct {
    expression: u64,
    program: *const zx_type_169,
};

pub const zx_type_175 = struct {
    count: []const u64,
    first: []const u64,
    symbols: []const u64,
};

pub const zx_type_176 = enum { Copy, Borrowed, Owned, Loaned, Moved, };

pub const zx_type_177 = enum { Assign, Borrow, Freeze, };

pub const zx_type_178 = struct {
    children: []const u64,
    field_indices: []const u64,
    parents: []const u64,
    references: []const bool,
    siblings: []const u64,
    types: []const u32,
};

pub const zx_type_180 = struct {
    id: u64,
    layout: *const zx_type_178,
    operation: zx_type_177,
    states: []const zx_type_176,
    value: zx_type_176,
};

pub const zx_type_181 = struct {
    count: []const u64,
    first: []const u64,
    positions: []const u64,
};

pub const zx_type_182 = struct {
    cached: *const zx_type_181,
    heads: []const u64,
    next: []const u64,
    tree: *const zx_type_178,
};

pub const zx_type_183 = struct {
    cached: *const zx_type_181,
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    tree: *const zx_type_178,
    values: []const u64,
};

pub const zx_type_184 = enum { Heads, Symbols, Expressions, Evaluation, };

pub const zx_type_185 = struct {
    program: *const zx_type_169,
    references: []const bool,
};

pub const zx_type_186 = struct {
    capacity: u64,
    field: u64,
    parent: u64,
};

pub const zx_type_187 = struct {
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_188 = struct {
    field: u64,
    parent: u64,
};

pub const zx_type_189 = struct {
    found: bool,
    slot: u64,
    value: u64,
};

pub const zx_type_190 = struct {
    index: *const zx_type_187,
    key: *const zx_type_188,
};

pub const zx_type_191 = struct {
    expressions: *const zx_type_42,
    id: u64,
};

pub const zx_type_192 = struct {
    index: u32,
    target: u64,
};

pub const zx_type_193 = enum { Expression, AncestorStart, Ancestor, Root, Path, Ensure, Grow, Clear, Rehash, };

pub const zx_type_194 = struct {
    active: bool,
    ancestor: u64,
    bindings: []const u64,
    cached: *const zx_type_181,
    capacity: u64,
    child_expression: u64,
    children: []const u64,
    cursor: u64,
    direct: bool,
    expression: u64,
    field_indices: []const u64,
    heads: []const u64,
    key_fields: []const u64,
    key_parents: []const u64,
    next: []const u64,
    parent: u64,
    parents: []const u64,
    path: []const u64,
    path_index: u64,
    phase: zx_type_193,
    place_types: []const u32,
    program: *const zx_type_169,
    record: u64,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_195 = struct {
    first: u64,
    slots: []const u64,
};

pub const zx_type_196 = struct {
    program: *const zx_type_169,
    references: []const bool,
    roots: *const zx_type_182,
};

pub const zx_type_197 = struct {
    children: []const u64,
    count: []const u64,
    first: []const u64,
    shells: []const zx_type_176,
    states: []const zx_type_176,
    types: []const u32,
};

pub const zx_type_198 = struct {
    fact: u64,
    forest: *const zx_type_197,
};

pub const zx_type_199 = struct {
    fact: u64,
    forest: *const zx_type_197,
    index: u64,
    reference: bool,
};

pub const zx_type_200 = struct {
    index: u64,
    type_id: u32,
    types: *const zx_type_20,
};

pub const zx_type_201 = struct {
    left: zx_type_176,
    right: zx_type_176,
};

pub const zx_type_202 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_197,
    shell: zx_type_176,
    type_id: u32,
};

pub const zx_type_203 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    forest: *const zx_type_197,
    shell: zx_type_176,
    type_id: u32,
};

pub const zx_type_204 = struct {
    fact: u64,
    forest: *const zx_type_197,
    index: u64,
    references: []const bool,
    type_id: u32,
    types: *const zx_type_20,
    value: u64,
};

pub const zx_type_205 = struct {
    facts: []const u64,
    forest: *const zx_type_197,
    states: []const zx_type_176,
};

pub const zx_type_206 = struct {
    fact: u64,
    id: u64,
    layout: *const zx_type_178,
    references: []const bool,
    storage: *const zx_type_205,
    types: *const zx_type_20,
};

pub const zx_type_207 = struct {
    capacity: u64,
    left: u64,
    right: u64,
};

pub const zx_type_208 = enum { Join, Read, Borrow, Freeze, ReleaseAllLoans, ReleaseNewLoans, };

pub const zx_type_209 = struct {
    left: []const u64,
    right: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_210 = struct {
    cache: *const zx_type_209,
    left: u64,
    right: u64,
};

pub const zx_type_211 = struct {
    cache: *const zx_type_209,
    left: u64,
    right: u64,
    value: u64,
};

pub const zx_type_212 = struct {
    count: u64,
    values: []const u64,
};

pub const zx_type_213 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: *const zx_type_197,
    references: []const bool,
    shell: zx_type_176,
    type_id: u32,
    types: *const zx_type_20,
};

pub const zx_type_214 = struct {
    action: zx_type_208,
    left: zx_type_176,
    right: zx_type_176,
};

pub const zx_type_215 = struct {
    action: zx_type_208,
    forest: *const zx_type_197,
    left: u64,
    references: []const bool,
    right: u64,
    types: *const zx_type_20,
};

pub const zx_type_216 = enum { States, Memo, Both, };

pub const zx_type_217 = enum { RestoreStates, MergeStates, ReleaseNewLoans, ReleaseAllLoans, RestoreMemo, };

pub const zx_type_218 = struct {
    facts: []const u64,
    memo: []const u64,
    memo_count: []const u64,
    memo_first: []const u64,
    state_count: []const u64,
    state_first: []const u64,
};

pub const zx_type_219 = struct {
    facts: []const u64,
    forest: *const zx_type_197,
    memo: []const u64,
    states: []const zx_type_176,
    trail: []const u64,
};

pub const zx_type_220 = struct {
    memory: *const zx_type_219,
    snapshots: *const zx_type_218,
};

pub const zx_type_221 = struct {
    fact: u64,
    id: u64,
    layout: *const zx_type_178,
    memory: *const zx_type_219,
    operation: zx_type_177,
    references: []const bool,
    types: *const zx_type_20,
};

pub const zx_type_222 = struct {
    layout: *const zx_type_183,
    program: *const zx_type_169,
    references: []const bool,
};

pub const zx_type_223 = enum { Block, Statement, Release, Value, Finish, Project, Captured, Copy, Borrowed, Constant, Result, Store, Destructure, Borrow, Aggregate, Sequence, SequenceResult, IndexTarget, IndexResult, BranchCondition, BranchYes, BranchNo, CallResult, BinaryLeft, BinaryRight, ConditionalCondition, ConditionalYes, ConditionalNo, UpdateResult, ScopeBinding, ScopeResult, ScopeFinish, TaskCapture, TaskFinish, ParallelBranch, ObjectEvaluation, ObjectCached, ObjectField, ObjectFieldResult, ObjectFinish, Invocation, InvocationResult, CollectionTarget, CollectionArgument, CollectionResult, CollectionFreeze, SwitchSubject, SwitchCase, SwitchResult, MatchSubject, MatchArm, MatchCondition, MatchResult, MatchFinish, IterationInitial, IterationRound, IterationAdvance, IterationCondition, IterationBody, IterationFinish, TransformTarget, TransformInitial, TransformParameter, TransformBody, TransformFinish, };

pub const zx_type_224 = struct {
    action: zx_type_223,
    index: u64,
    moving: bool,
    subject: u64,
};

pub const zx_type_226 = struct {
    actions: []const zx_type_223,
    indices: []const u64,
    moving: []const bool,
    subjects: []const u64,
};

pub const zx_type_227 = struct {
    complete: bool,
    expression: u64,
    failed: bool,
    output: zx_type_176,
    stores_owned: bool,
};

pub const zx_type_228 = struct {
    action: zx_type_217,
    frame: u64,
    layout: *const zx_type_178,
    memory: *const zx_type_219,
    references: []const bool,
    stack: *const zx_type_218,
    types: *const zx_type_20,
};

pub const zx_type_229 = struct {
    frame: u64,
    stack: *const zx_type_218,
};

pub const zx_type_230 = struct {
    capture: zx_type_216,
    memory: *const zx_type_219,
    stack: *const zx_type_218,
};

pub const zx_type_231 = struct {
    frame: *const zx_type_224,
    work: *const zx_type_226,
};

pub const zx_type_232 = struct {
    count: []const u64,
    first: []const u64,
};

pub const zx_type_233 = struct {
    boundaries: []const u64,
    count: []const u64,
    entries: []const u64,
    exits: []const u64,
    facts: []const u64,
    first: []const u64,
    heads: []const u64,
    outputs: []const u64,
    roots: []const u64,
    seen: []const bool,
};

pub const zx_type_234 = enum { Statements, Values, Callbacks, Branches, Calls, Collections, Objects, Scope, Tasks, Expression, Invalid, };

pub const zx_type_235 = struct {
    active: bool,
    builders: *const zx_type_232,
    complete: bool,
    domains: *const zx_type_175,
    expression: u64,
    failed: bool,
    layout: *const zx_type_183,
    loops: *const zx_type_233,
    memory: *const zx_type_219,
    program: *const zx_type_169,
    references: []const bool,
    returned: zx_type_176,
    returns: []const bool,
    snapshots: *const zx_type_218,
    stores_owned: bool,
    value: u64,
    values: []const u64,
    work: *const zx_type_226,
};

pub const zx_type_236 = struct {
    frame: u64,
    layout: *const zx_type_178,
    memory: *const zx_type_219,
    merge: bool,
    references: []const bool,
    stack: *const zx_type_218,
    types: *const zx_type_20,
};

pub const zx_type_237 = struct {
    index: u64,
    loops: *const zx_type_233,
    memory: *const zx_type_219,
    references: []const bool,
    types: *const zx_type_20,
    value: u64,
};

pub const zx_type_238 = struct {
    forest: *const zx_type_197,
    loops: *const zx_type_233,
};

pub const zx_type_239 = struct {
    condition: bool,
    expression: u64,
    index: u64,
    machine: *const zx_type_235,
    value: u64,
};

pub const zx_type_240 = struct {
    boundary: u64,
    memory: *const zx_type_219,
    snapshots: *const zx_type_218,
    work: *const zx_type_226,
};

pub const zx_type_241 = struct {
    changed: bool,
    forest: *const zx_type_197,
    loops: *const zx_type_233,
};

pub const zx_type_242 = struct {
    domains: *const zx_type_175,
    exiting: bool,
    expression: u64,
    index: u64,
    layout: *const zx_type_178,
    loops: *const zx_type_233,
    memory: *const zx_type_219,
    references: []const bool,
    snapshots: *const zx_type_218,
    types: *const zx_type_20,
};

pub const zx_type_243 = struct {
    domains: *const zx_type_175,
    entry: u64,
    expression: u64,
    layout: *const zx_type_178,
    loops: *const zx_type_233,
    memory: *const zx_type_219,
    program: *const zx_type_169,
    value: u64,
};

pub const zx_type_245 = enum { Next, Query, Descend, Expand, Enter, Done, };

pub const zx_type_246 = struct {
    active: bool,
    cursors: []const u64,
    expression: u64,
    expressions: *const zx_type_42,
    facts: []const u64,
    forest: *const zx_type_197,
    layout: *const zx_type_183,
    memo: []const u64,
    permanent: bool,
    phase: zx_type_245,
    position: u64,
    query: u64,
    references: []const bool,
    root: u64,
    states: []const zx_type_176,
    trail: []const u64,
    types: *const zx_type_20,
    work: []const u64,
};

pub const zx_type_247 = struct {
    expression: u64,
    expressions: *const zx_type_42,
    index: u64,
    permanent: bool,
};

pub const zx_type_248 = struct {
    expression: u64,
    expressions: *const zx_type_42,
    layout: *const zx_type_183,
    memory: *const zx_type_219,
    permanent: bool,
    references: []const bool,
    types: *const zx_type_20,
};

pub const zx_type_249 = struct {
    expression: u64,
    expressions: *const zx_type_42,
    layout: *const zx_type_183,
    memo: []const u64,
    trail: []const u64,
};

pub const zx_type_250 = struct {
    found: bool,
    position: u64,
    trail: []const u64,
};

pub const zx_type_251 = struct {
    current: zx_type_176,
    moving: bool,
    position: u64,
    symbols: *const zx_type_45,
    types: *const zx_type_20,
};

pub const zx_type_252 = struct {
    assign: bool,
    assigned: zx_type_176,
    failed: bool,
    value: zx_type_176,
};

pub const zx_type_253 = struct {
    builders: *const zx_type_232,
    count: u64,
    forest: *const zx_type_197,
};

pub const zx_type_254 = struct {
    builders: *const zx_type_232,
    forest: *const zx_type_197,
};

pub const zx_type_255 = enum { Operands, Containers, Control, };

pub const zx_type_256 = struct {
    container: bool,
    frame: *const zx_type_224,
    kind: zx_type_27,
    machine: *const zx_type_235,
    payload: u64,
};

pub const zx_type_257 = struct {
    builders: *const zx_type_232,
    forest: *const zx_type_197,
    type_id: u32,
};

pub const zx_type_258 = struct {
    builders: *const zx_type_232,
    fact: u64,
    forest: *const zx_type_197,
};

pub const zx_type_259 = struct {
    domains: *const zx_type_175,
    layout: *const zx_type_183,
    program: *const zx_type_169,
    references: []const bool,
    returns: []const bool,
    runtime: *const zx_type_220,
};

pub const zx_type_260 = struct {
    declared: zx_type_43,
    outcome: *const zx_type_227,
};

pub const zx_type_261 = struct {
    context: *const zx_type_74,
    index: u64,
};

pub const zx_type_262 = struct {
    functions: *const zx_type_71,
    index: u64,
};

pub const zx_type_263 = struct {
    fallible: bool,
    members: ?[]const []const u8,
};

pub const zx_type_264 = struct {
    modules: *const zx_type_70,
    name: []const u8,
    owner: []const u8,
};

pub const zx_type_265 = struct {
    functions: *const zx_type_71,
    left: u64,
    right: u64,
};

pub const zx_type_266 = struct {
    context: *const zx_type_106,
    name: []const u8,
    owner: []const u8,
};

pub const zx_type_267 = struct {
    binding_names: []const []const u8,
    binding_types: []const u32,
    depth: u64,
    names: []const ?[]const u8,
    table: *const zx_type_19,
    type_id: u32,
};

pub const zx_type_269 = struct {
    name: ?[]const u8,
    names: []const []const u8,
    required: bool,
    type_id: u32,
    types: []const u32,
};

pub const zx_type_270 = struct {
    contracts: []const *const zx_type_50,
    control: []const *const zx_type_53,
    expressions: []const *const zx_type_42,
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_fallible: []const bool,
    native_modules: []const ?u32,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_43,
    roots: []const ?u32,
    stores: []const *const zx_type_62,
};

pub const zx_type_271 = struct {
    count: u64,
    slots: []const u64,
};

pub const zx_type_272 = enum { Expression, Function, Block, };

pub const zx_type_273 = struct {
    count: u64,
    index: u64,
    operation: zx_type_272,
    source: u64,
};

pub const zx_type_274 = struct {
    control: *const zx_type_53,
    expressions: *const zx_type_42,
    returns: []const bool,
    visited: *const zx_type_271,
};

pub const zx_type_275 = struct {
    functions: *const zx_type_270,
    types: *const zx_type_20,
};

pub const zx_type_278 = struct {
    called: *const zx_type_271,
    context: *const zx_type_275,
    frames: []const *const zx_type_273,
    names: []const []const u8,
    sources: []const *const zx_type_274,
    unknown: bool,
};

pub const zx_type_279 = struct {
    context: *const zx_type_275,
    contracts: *const zx_type_50,
    control: *const zx_type_53,
    expression: u32,
    expressions: *const zx_type_42,
    program: bool,
    root: ?u32,
    stores: bool,
};

pub const zx_type_280 = struct {
    control: *const zx_type_53,
    expressions: *const zx_type_42,
    state: *const zx_type_278,
};

pub const zx_type_281 = struct {
    source: u64,
    state: *const zx_type_278,
};

pub const zx_type_282 = struct {
    contracts: *const zx_type_50,
    state: *const zx_type_278,
};

pub const zx_type_283 = struct {
    frame: *const zx_type_273,
    state: *const zx_type_278,
};

pub const zx_type_284 = struct {
    id: u32,
    seen: *const zx_type_271,
};

pub const zx_type_285 = struct {
    fresh: bool,
    seen: *const zx_type_271,
};

pub const zx_type_286 = struct {
    expressions: *const zx_type_42,
    index: u64,
};

pub const zx_type_287 = struct {
    names: []const []const u8,
    tables: *const zx_type_20,
    type_id: u32,
};

pub const zx_type_288 = struct {
    expressions: *const zx_type_42,
    index: u64,
    names: []const []const u8,
    tables: *const zx_type_20,
};

pub const zx_type_289 = struct {
    index: u64,
    state: *const zx_type_278,
};

pub const zx_type_290 = struct {
    identity: []const u8,
    stores: []const *const zx_type_62,
    type_id: u32,
};

pub const zx_type_291 = struct {
    graph: *const zx_type_79,
    index: u64,
};

pub const zx_type_292 = struct {
    count: u64,
    function_id: ?u32,
    functions: *const zx_type_68,
    ids: []const u32,
    names: []const []const u8,
};

pub const zx_type_293 = struct {
    instance: []const u8,
    value: []const u8,
};

pub const zx_type_294 = struct {
    instance: []const u8,
    modules: *const zx_type_70,
    value: []const u8,
};

pub const zx_type_295 = struct {
    instance: []const u8,
    modules: *const zx_type_70,
    origins: *const zx_type_15,
};

pub const zx_type_296 = struct {
    base: *const zx_type_19,
    base_origins: *const zx_type_15,
    first: u64,
    origin_indices: []const u64,
    origins: *const zx_type_15,
    source: *const zx_type_19,
};

pub const zx_type_297 = struct {
    delta: *const zx_type_19,
    mapping: []const u32,
    origins: *const zx_type_15,
    references: []const u32,
    status: u64,
};

pub const zx_type_298 = struct {
    request: *const zx_type_296,
    state: *const zx_type_297,
};

pub const zx_type_299 = struct {
    base: *const zx_type_19,
    base_origins: *const zx_type_15,
    names: []const []const u8,
    origins: *const zx_type_15,
    source: *const zx_type_19,
};

pub const zx_type_300 = struct {
    names: []const []const u8,
    origins: *const zx_type_15,
    source: *const zx_type_19,
};

pub const zx_type_301 = struct {
    indices: []const u64,
    valid: bool,
};

pub const zx_type_302 = struct {
    first: u64,
    source: *const zx_type_19,
    target: *const zx_type_19,
};

pub const zx_type_303 = struct {
    children: []const u32,
    count: u64,
    field_names: []const []const u8,
    field_types: []const u32,
    first: u32,
    kind: zx_type_18,
    label: []const u8,
    names: []const []const u8,
    offset: u64,
    second: u32,
};

pub const zx_type_304 = struct {
    left: *const zx_type_303,
    right: *const zx_type_303,
};

pub const zx_type_305 = struct {
    index: u64,
    table: *const zx_type_19,
};

pub const zx_type_306 = struct {
    first: u64,
    mapping: []const u32,
};

pub const zx_type_307 = struct {
    candidate: *const zx_type_109,
    delta: *const zx_type_19,
};

pub const zx_type_308 = struct {
    index: u64,
    references: []const u32,
    source: *const zx_type_19,
};

pub const zx_type_309 = enum { Missing, Found, Conflict, };

pub const zx_type_310 = struct {
    id: u32,
    status: zx_type_309,
};

pub const zx_type_311 = struct {
    candidate: *const zx_type_109,
    id: u32,
    tables: *const zx_type_20,
};

pub const zx_type_312 = struct {
    candidate: *const zx_type_109,
    origin: *const zx_type_11,
    origins: *const zx_type_16,
    tables: *const zx_type_20,
};

pub const zx_type_313 = struct {
    bindings: *const zx_type_15,
    id: u32,
    origin: *const zx_type_11,
};

pub const zx_type_314 = struct {
    index: u64,
    mapping: []const u32,
    references: []const u32,
    source: *const zx_type_19,
};

pub const zx_type_315 = struct {
    candidate: *const zx_type_109,
    tables: *const zx_type_20,
};

pub const zx_type_316 = struct {
    added: u64,
    existing: u64,
    maximum: u64,
};

pub const zx_type_317 = struct {
    block_size: u32,
    cost: u32,
    length: u32,
    max_memory: u64,
    parallelism: u32,
    password: []const u8,
    salt: []const u8,
};

pub const zx_type_318 = struct {
    left: []const u8,
    right: []const u8,
};

pub const zx_type_319 = struct {
    data: []const u8,
    key: []const u8,
    tag: []const u8,
};

pub const zx_type_320 = struct {
    data: []const u8,
    key: []const u8,
};

pub const zx_type_321 = struct {
    info: []const u8,
    key: []const u8,
    length: u32,
    salt: []const u8,
};

pub const zx_type_322 = struct {
    iterations: u32,
    length: u32,
    password: []const u8,
    salt: []const u8,
};

pub const zx_type_323 = struct {
    aad: []const u8,
    data: []const u8,
    key: []const u8,
    nonce: []const u8,
};

pub const zx_type_324 = struct {
    ciphertext: []const u8,
    tag: []const u8,
};

pub const zx_type_325 = struct {
    aad: []const u8,
    ciphertext: []const u8,
    key: []const u8,
    nonce: []const u8,
    tag: []const u8,
};

pub const zx_type_326 = struct { []const u8, u64, u64, };

pub const zx_type_327 = struct {
    identity: ?[]const u8,
    ids: []const u32,
    import_name: []const u8,
    names: []const []const u8,
    namespace: []const []const u8,
    specifier: []const u8,
};

pub const zx_type_328 = struct {
    delta: *const zx_type_70,
    mapping: []const u32,
    status: u64,
};

pub const zx_type_329 = struct {
    base: *const zx_type_70,
    instance: []const u8,
    maximum: u64,
    source: *const zx_type_70,
    types: []const u32,
};

pub const zx_type_330 = struct {
    index: u64,
    instance: []const u8,
    source: *const zx_type_70,
};

pub const zx_type_331 = struct {
    mapping: []const u32,
    values: []const u32,
};

pub const zx_type_332 = struct {
    index: u64,
    table: *const zx_type_70,
    value: *const zx_type_327,
};

pub const zx_type_333 = struct {
    base: *const zx_type_70,
    maximum: u64,
    state: *const zx_type_328,
    value: *const zx_type_327,
};

pub const zx_type_334 = struct {
    first: u64,
    instance: []const u8,
    natives: []const u32,
    source: *const zx_type_68,
    types: []const u32,
};

pub const zx_type_335 = struct {
    contracts: *const zx_type_50,
    expressions: *const zx_type_42,
    file: []const u8,
    input_type: u32,
    native_module: ?u32,
    output_type: u32,
    stores: *const zx_type_62,
    symbols: *const zx_type_45,
};

pub const zx_type_336 = struct {
    index: u64,
    request: *const zx_type_334,
};

pub const zx_type_337 = struct {
    file: []const u8,
    input_type: u32,
    native_module: ?u32,
    output_type: u32,
};

pub const zx_type_338 = struct {
    mapping: []const u32,
    source: *const zx_type_45,
};

pub const zx_type_339 = struct {
    first: u64,
    mapping: []const u32,
    source: *const zx_type_42,
};

pub const zx_type_340 = struct {
    first: u64,
    mapping: []const u32,
    source: *const zx_type_50,
};

pub const zx_type_341 = struct {
    instance: []const u8,
    mapping: []const u32,
    source: *const zx_type_62,
};

pub const zx_type_342 = struct {
    first: u64,
    instance: []const u8,
    mapping: []const u32,
    source: *const zx_type_77,
};

pub const zx_type_343 = struct {
    first: u64,
    instance: []const u8,
    source: *const zx_type_78,
};

pub const zx_type_344 = struct {
    base: *const zx_type_19,
    delta: *const zx_type_19,
    existing_count: u64,
};

pub const zx_type_345 = struct {
    body: *const zx_type_72,
    max_offset: u64,
};

pub const zx_type_346 = struct {
    max_offset: u64,
    unit: *const zx_type_75,
};

pub const zx_type_347 = struct {
    concurrent: bool,
    enabled: bool,
    functions: *const zx_type_131,
};

pub const zx_type_348 = struct {
    domains: *const zx_type_175,
    layout: *const zx_type_183,
    references: []const bool,
    returns: []const bool,
};

pub const zx_type_349 = struct {
    memory: *const zx_type_219,
    prepared: *const zx_type_348,
    snapshots: *const zx_type_218,
};

pub const zx_type_351 = struct {
    first: u64,
    names: []const []const u8,
    origins: *const zx_type_15,
    source: *const zx_type_19,
    target: *const zx_type_19,
};

pub const zx_type_352 = struct {
    expressions: *const zx_type_42,
    symbols: *const zx_type_45,
};

pub const zx_type_353 = struct {
    base: *const zx_type_19,
    input: *const zx_type_81,
    merged: *const zx_type_297,
    native: *const zx_type_328,
};

pub const zx_type_354 = struct {
    destination: *const zx_type_80,
    seed: bool,
};

pub const zx_type_355 = struct {
    index: u64,
    request: *const zx_type_329,
    state: *const zx_type_328,
};

pub const zx_type_356 = struct {
    expressions: *const zx_type_42,
    first: u64,
    mapping: []const u32,
    symbols: *const zx_type_45,
};

pub const zx_type_357 = struct {
    count: u64,
    index: u64,
    origins: *const zx_type_15,
    valid: bool,
};

pub const zx_type_358 = struct {
    index: u64,
    names: []const []const u8,
    origins: *const zx_type_15,
    previous: u64,
    unique: bool,
};

pub const zx_type_359 = struct {
    count: u64,
    index: u64,
    names: []const []const u8,
    origins: *const zx_type_15,
    table: *const zx_type_19,
    valid: bool,
};

pub const zx_type_360 = struct { *const zx_type_25, };

pub const zx_type_361 = struct { *const zx_type_25, bool, };

pub const zx_type_362 = struct { *const zx_type_25, bool, bool, };

pub const zx_type_363 = struct { *const zx_type_354, };

pub const zx_type_364 = struct { *const zx_type_354, bool, };

pub const zx_type_365 = struct {
    high: u8,
    index: u64,
    low: u8,
    remaining: u64,
    text: []const u8,
    valid: bool,
};

pub const zx_type_366 = struct {
    index: u64,
    table: *const zx_type_68,
    valid: bool,
};

pub const zx_type_367 = struct {
    child_end: u64,
    field_end: u64,
    index: u64,
    name_end: u64,
    scalar_count: u64,
    table: *const zx_type_19,
    valid: bool,
};

pub const zx_type_368 = struct {
    after_underscore: bool,
    index: u64,
    kind: zx_type_84,
    name: []const u8,
    valid: bool,
};

pub const zx_type_369 = struct {
    ascending: bool,
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
};

pub const zx_type_370 = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    owner: u64,
    table: *const zx_type_19,
    valid: bool,
    values: []const u32,
};

pub const zx_type_371 = struct {
    count: u64,
    errors: bool,
    first: u64,
    index: u64,
    valid: bool,
    values: []const []const u8,
};

pub const zx_type_372 = struct {
    count: u64,
    first: u64,
    index: u64,
    member: []const u8,
    unique: bool,
    values: []const []const u8,
};

pub const zx_type_373 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_19,
    valid: bool,
};

pub const zx_type_374 = struct { *const zx_type_83, };

pub const zx_type_375 = struct { *const zx_type_83, bool, };

pub const zx_type_376 = struct { *const zx_type_83, bool, bool, };

pub const zx_type_377 = struct {
    index: u64,
    input: *const zx_type_91,
    valid: bool,
};

pub const zx_type_378 = struct {
    index: u64,
    input: *const zx_type_95,
    next: u64,
    valid: bool,
};

pub const zx_type_379 = struct {
    block: u64,
    control: *const zx_type_53,
    end: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_380 = struct {
    block: u64,
    bodies: []const u32,
    end: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_381 = struct {
    branches: u64,
    constants: u64,
    control: *const zx_type_53,
    destructures: u64,
    evaluations: u64,
    index: u64,
    parallels: u64,
    results: u64,
    selections: u64,
    setters: u64,
    valid: bool,
};

pub const zx_type_382 = struct {
    block: u64,
    control: *const zx_type_53,
    valid: bool,
};

pub const zx_type_383 = struct {
    count: u64,
    depths: []const u64,
    owned: []const bool,
    root: u64,
};

pub const zx_type_384 = struct { []const bool, void, };

pub const zx_type_385 = struct { []const u64, void, };

pub const zx_type_386 = struct {
    block: u64,
    control: *const zx_type_53,
    depths: []const u64,
    edge: u64,
    index: u64,
    owned: []const bool,
    valid: bool,
};

pub const zx_type_387 = struct {
    index: u64,
    result: bool,
    source: []const bool,
};

pub const zx_type_388 = struct { *const zx_type_345, };

pub const zx_type_389 = struct { *const zx_type_345, bool, };

pub const zx_type_390 = struct { *const zx_type_345, bool, bool, };

pub const zx_type_391 = struct { *const zx_type_345, bool, bool, bool, };

pub const zx_type_392 = struct { *const zx_type_345, bool, bool, bool, bool, };

pub const zx_type_393 = struct { *const zx_type_345, bool, bool, bool, bool, bool, };

pub const zx_type_394 = struct {
    index: u64,
    input: *const zx_type_99,
    valid: bool,
};

pub const zx_type_395 = struct {
    index: u64,
    input: *const zx_type_100,
    valid: bool,
};

pub const zx_type_396 = struct {
    contracts: *const zx_type_50,
    index: u64,
    max_offset: u64,
    valid: bool,
};

pub const zx_type_397 = struct { *const zx_type_101, };

pub const zx_type_398 = struct { *const zx_type_101, bool, };

pub const zx_type_399 = struct { *const zx_type_346, };

pub const zx_type_400 = struct { *const zx_type_346, bool, };

pub const zx_type_401 = struct { *const zx_type_346, bool, bool, };

pub const zx_type_402 = struct {
    context: *const zx_type_74,
    index: u64,
    valid: bool,
};

pub const zx_type_403 = struct { *const zx_type_76, };

pub const zx_type_404 = struct { *const zx_type_76, bool, };

pub const zx_type_405 = struct { *const zx_type_76, bool, bool, };

pub const zx_type_406 = struct {
    index: u64,
    modules: *const zx_type_70,
    valid: bool,
};

pub const zx_type_407 = struct {
    offset: u64,
    separator: u64,
    source: []const u8,
    valid: bool,
};

pub const zx_type_408 = struct {
    offset: u64,
    source: []const u8,
    start: u64,
    valid: bool,
};

pub const zx_type_409 = struct {
    index: u64,
    names: []const []const u8,
    valid: bool,
};

pub const zx_type_410 = struct {
    count: u64,
    found: bool,
    index: u64,
    modules: *const zx_type_70,
    name: []const u8,
    owner: []const u8,
};

pub const zx_type_411 = struct { *const zx_type_70, };

pub const zx_type_412 = struct { *const zx_type_70, bool, };

pub const zx_type_413 = struct { *const zx_type_70, bool, bool, };

pub const zx_type_414 = struct { *const zx_type_70, bool, bool, bool, };

pub const zx_type_415 = struct {
    index: u64,
    modules: *const zx_type_70,
    type_count: u64,
    valid: bool,
};

pub const zx_type_416 = struct {
    ids: []const u32,
    index: u64,
    names: []const []const u8,
    type_count: u64,
    valid: bool,
};

pub const zx_type_417 = struct {
    count: u64,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_418 = struct {
    index: u64,
    module: u64,
    modules: *const zx_type_70,
    owner: []const u8,
    valid: bool,
};

pub const zx_type_419 = struct {
    count: u64,
    index: u64,
    modules: *const zx_type_70,
    name: []const u8,
    owner: []const u8,
    type_id: u32,
    valid: bool,
};

pub const zx_type_420 = struct {
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u32,
    valid: bool,
};

pub const zx_type_421 = struct { *const zx_type_105, };

pub const zx_type_422 = struct { *const zx_type_105, bool, };

pub const zx_type_423 = struct { *const zx_type_105, bool, bool, };

pub const zx_type_424 = struct { *const zx_type_105, bool, bool, bool, };

pub const zx_type_425 = struct {
    declared: bool,
    index: u64,
    modules: *const zx_type_70,
    name: []const u8,
    owner: ?[]const u8,
    type_id: u64,
    valid: bool,
};

pub const zx_type_426 = struct {
    declared: bool,
    found: bool,
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u64,
};

pub const zx_type_427 = struct {
    context: *const zx_type_105,
    index: u64,
    valid: bool,
};

pub const zx_type_428 = struct { *const zx_type_105, bool, bool, bool, bool, };

pub const zx_type_429 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
};

pub const zx_type_430 = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: *const zx_type_20,
    target: zx_type_18,
};

pub const zx_type_431 = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: *const zx_type_20,
};

pub const zx_type_432 = struct {
    index: u64,
    limit: u64,
    path: []const u8,
    paths: []const []const u8,
    repeated: bool,
};

pub const zx_type_433 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
};

pub const zx_type_434 = struct {
    index: u64,
    paths: []const []const u8,
    slot_types: []const u32,
    table: *const zx_type_19,
    valid: bool,
};

pub const zx_type_435 = struct { *const zx_type_116, };

pub const zx_type_436 = struct { *const zx_type_116, bool, };

pub const zx_type_437 = struct {
    available: *const zx_type_62,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_62,
    slots: []const u32,
    valid: bool,
};

pub const zx_type_438 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
};

pub const zx_type_439 = struct {
    condition_type: u32,
    context: *const zx_type_120,
    count: u64,
    first: u64,
    index: u64,
    result_type: u32,
    valid: bool,
};

pub const zx_type_440 = struct {
    context: *const zx_type_120,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_441 = struct {
    context: *const zx_type_120,
    count: u64,
    first: u64,
    index: u64,
    type_first: u64,
    valid: bool,
};

pub const zx_type_442 = struct {
    field: u64,
    first: u64,
    found: bool,
    index: u64,
    indices: []const u32,
    limit: u64,
};

pub const zx_type_443 = struct {
    context: *const zx_type_120,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_28,
    source: u32,
    valid: bool,
};

pub const zx_type_444 = struct {
    check: *const zx_type_121,
    count: u64,
    fields: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_445 = struct {
    field: ?u32,
    fields: []const ?u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    task: u32,
    tasks: []const u32,
};

pub const zx_type_446 = struct {
    check: *const zx_type_121,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_447 = struct {
    captures: []const u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    symbol: u32,
};

pub const zx_type_448 = struct {
    context: *const zx_type_120,
    context_type: u32,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_29,
    valid: bool,
};

pub const zx_type_449 = struct {
    expressions: *const zx_type_42,
    functions: *const zx_type_119,
    index: u64,
    stores: *const zx_type_62,
    symbols: *const zx_type_45,
    table: *const zx_type_19,
    valid: bool,
};

pub const zx_type_450 = struct {
    has_ensures: bool,
    index: u64,
    program: *const zx_type_127,
    valid: bool,
};

pub const zx_type_451 = struct { *const zx_type_127, };

pub const zx_type_452 = struct { *const zx_type_127, bool, };

pub const zx_type_453 = struct { *const zx_type_127, bool, bool, };

pub const zx_type_454 = struct {
    count: u64,
    index: u64,
    symbols: *const zx_type_45,
    valid: bool,
};

pub const zx_type_455 = struct {
    index: u64,
    request: *const zx_type_117,
    valid: bool,
};

pub const zx_type_456 = struct {
    all: bool,
    bodies: []const u32,
    end: u64,
    index: u64,
    returns: []const bool,
};

pub const zx_type_457 = struct {
    block: u64,
    control: *const zx_type_53,
    returns: []const bool,
};

pub const zx_type_458 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_42,
    index: u64,
    limit: u64,
    valid: bool,
};

pub const zx_type_459 = struct {
    index: u64,
    result: []const bool,
    source: []const ?u32,
};

pub const zx_type_460 = struct {
    concurrent: bool,
    functions: *const zx_type_131,
    index: u64,
    values: []const bool,
};

pub const zx_type_461 = struct { *const zx_type_347, };

pub const zx_type_462 = struct { *const zx_type_347, []const bool, };

pub const zx_type_463 = struct { *const zx_type_138, };

pub const zx_type_464 = struct { *const zx_type_138, []const bool, };

pub const zx_type_465 = struct { *const zx_type_138, []const bool, []const bool, };

pub const zx_type_466 = struct { *const zx_type_138, []const bool, []const bool, []const bool, };

pub const zx_type_467 = struct {
    index: u64,
    result: []const bool,
    source: []const []const u8,
};

pub const zx_type_468 = struct {
    index: u64,
    result: []const u64,
    source: []const []const u8,
};

pub const zx_type_469 = struct {
    found: bool,
    index: u64,
    symbol: u32,
    values: []const u32,
};

pub const zx_type_470 = struct { []const u32, void, };

pub const zx_type_471 = struct {
    facts: *const zx_type_133,
    index: u64,
    symbol: u32,
};

pub const zx_type_472 = struct {
    expressions: *const zx_type_42,
    state: *const zx_type_135,
};

pub const zx_type_473 = struct { []const u64, ?u64, };

pub const zx_type_474 = struct { []const bool, ?bool, };

pub const zx_type_475 = struct { []const u32, []const u32, };

pub const zx_type_476 = struct { []const zx_type_136, void, };

pub const zx_type_477 = struct {
    control: *const zx_type_53,
    first: u64,
    index: u64,
    state: *const zx_type_144,
};

pub const zx_type_478 = struct {
    context: *const zx_type_140,
    first: u64,
    index: u64,
    result: *const zx_type_147,
};

pub const zx_type_479 = struct {
    activity: *const zx_type_141,
    index: u64,
};

pub const zx_type_480 = struct {
    count: u64,
    first: u64,
    index: u64,
    owner: u64,
    program: *const zx_type_138,
    result: *const zx_type_147,
};

pub const zx_type_481 = struct {
    count: u64,
    first: u64,
    index: u64,
    program: *const zx_type_138,
    result: *const zx_type_147,
    type_first: u64,
};

pub const zx_type_482 = struct {
    depth: u64,
    first: u64,
    flags: u64,
    index: u64,
    state: *const zx_type_144,
    values: []const u32,
};

pub const zx_type_483 = struct {
    depth: u64,
    expressions: *const zx_type_42,
    first: u64,
    flags: u64,
    index: u64,
    state: *const zx_type_144,
};

pub const zx_type_484 = struct {
    count: u64,
    expressions: *const zx_type_42,
    facts: *const zx_type_133,
    first: u64,
    index: u64,
};

pub const zx_type_485 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_42,
    first: u64,
    index: u64,
    result: ?u32,
    symbol: u32,
};

pub const zx_type_486 = struct {
    depth: u64,
    expressions: *const zx_type_42,
    first: u64,
    flags: u64,
    index: u64,
    owner: u64,
    state: *const zx_type_144,
};

pub const zx_type_487 = struct {
    active: []const bool,
    count: u64,
    first: u64,
    index: u64,
    symbols: []const u32,
    valid: bool,
};

pub const zx_type_488 = struct {
    activity: *const zx_type_141,
    count: u64,
    expressions: *const zx_type_42,
    first: u64,
    index: u64,
};

pub const zx_type_489 = struct {
    control: *const zx_type_53,
    count: u64,
    expressions: *const zx_type_42,
    first: u64,
    index: u64,
    no: bool,
    valid: bool,
    yes: bool,
};

pub const zx_type_490 = struct {
    count: u64,
    first: u64,
    has_default: bool,
    index: u64,
    program: *const zx_type_138,
    type_id: u32,
    valid: bool,
};

pub const zx_type_491 = struct {
    count: u64,
    first: u64,
    found: bool,
    index: u64,
    program: *const zx_type_138,
    value: u64,
};

pub const zx_type_492 = struct {
    captures: u64,
    depth: u64,
    facts: u64,
    first: u64,
    index: u64,
    payload: u64,
    program: *const zx_type_138,
    state: *const zx_type_144,
};

pub const zx_type_494 = struct { []const zx_type_136, ?zx_type_136, };

pub const zx_type_495 = struct {
    context: *const zx_type_140,
    result: *const zx_type_147,
};

pub const zx_type_496 = struct { *const zx_type_140, };

pub const zx_type_497 = struct { *const zx_type_140, *const zx_type_147, };

pub const zx_type_498 = struct { *const zx_type_140, *const zx_type_147, *const zx_type_147, };

pub const zx_type_499 = struct { *const zx_type_140, *const zx_type_147, *const zx_type_147, bool, };

pub const zx_type_500 = struct { *const zx_type_140, *const zx_type_147, *const zx_type_147, bool, bool, };

pub const zx_type_501 = struct { *const zx_type_138, *const zx_type_139, };

pub const zx_type_502 = struct { *const zx_type_138, *const zx_type_139, bool, };

pub const zx_type_503 = struct {
    capture: u64,
    expressions: *const zx_type_42,
    index: u64,
    symbols: *const zx_type_45,
    table: *const zx_type_19,
    valid: bool,
};

pub const zx_type_504 = struct {
    index: u64,
    result: []const u64,
    source: []const zx_type_27,
};

pub const zx_type_505 = struct {
    binding: u64,
    constants: []const u32,
    edge: u64,
    expressions: *const zx_type_42,
    index: u64,
    table: *const zx_type_19,
    uses: []const u64,
    valid: bool,
};

pub const zx_type_506 = struct {
    expressions: *const zx_type_42,
    index: u64,
    table: *const zx_type_19,
    uses: []const u64,
    valid: bool,
};

pub const zx_type_507 = struct { *const zx_type_167, };

pub const zx_type_508 = struct { *const zx_type_167, bool, };

pub const zx_type_509 = struct { *const zx_type_167, bool, bool, };

pub const zx_type_510 = struct { *const zx_type_167, bool, bool, bool, };

pub const zx_type_511 = struct {
    target: *const zx_type_22,
    types: *const zx_type_20,
};

pub const zx_type_512 = struct {
    index: u64,
    references: []const bool,
    types: *const zx_type_20,
};

pub const zx_type_513 = struct {
    count: u64,
    expressions: *const zx_type_42,
    index: u64,
    kind: zx_type_27,
    locals: []const bool,
    payload: u64,
};

pub const zx_type_514 = struct {
    body: u64,
    condition: u64,
    count: u64,
    locals: []const bool,
    reachable: []const bool,
    symbols: u64,
};

pub const zx_type_515 = struct {
    expressions: *const zx_type_42,
    index: u64,
    locals: []const bool,
    reachable: []const bool,
    remaining: u64,
};

pub const zx_type_516 = struct {
    count: []const u64,
    first: []const u64,
    index: u64,
    program: *const zx_type_169,
    symbols: []const u64,
};

pub const zx_type_517 = struct {
    index: u64,
    locals: []const bool,
    symbols: []const u64,
};

pub const zx_type_518 = struct {
    active: bool,
    cached_count: []const u64,
    cached_first: []const u64,
    cached_positions: []const u64,
    children: []const u64,
    field_indices: []const u64,
    heads: []const u64,
    index: u64,
    item: u64,
    next: []const u64,
    parents: []const u64,
    phase: zx_type_184,
    place_types: []const u32,
    program: *const zx_type_169,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    tails: []const u64,
};

pub const zx_type_519 = struct {
    active: bool,
    found: bool,
    index: *const zx_type_187,
    key: *const zx_type_188,
    slot: u64,
    value: u64,
};

pub const zx_type_520 = struct { []const u64, []const u64, };

pub const zx_type_521 = struct {
    position: u64,
    slots: []const u64,
};

pub const zx_type_522 = struct { *const zx_type_169, };

pub const zx_type_523 = struct { *const zx_type_169, []const bool, };

pub const zx_type_524 = struct { *const zx_type_169, []const bool, []const bool, };

pub const zx_type_525 = struct { *const zx_type_169, []const bool, []const bool, *const zx_type_175, };

pub const zx_type_526 = struct { *const zx_type_169, []const bool, []const bool, *const zx_type_175, *const zx_type_182, };

pub const zx_type_527 = struct { *const zx_type_169, []const bool, []const bool, *const zx_type_175, *const zx_type_182, *const zx_type_183, };

pub const zx_type_528 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_197,
    index: u64,
    state: zx_type_176,
};

pub const zx_type_529 = struct { []const zx_type_176, void, };

pub const zx_type_530 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    index: u64,
    source: []const u64,
};

pub const zx_type_531 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    forest: *const zx_type_197,
    index: u64,
    references: []const bool,
    target: u64,
    type_id: u32,
    types: *const zx_type_20,
    value: u64,
};

pub const zx_type_532 = struct {
    active: bool,
    ascending: bool,
    fact: u64,
    facts: []const u64,
    forest: *const zx_type_197,
    id: u64,
    layout: *const zx_type_178,
    leaving: bool,
    references: []const bool,
    root: u64,
    states: []const zx_type_176,
    types: *const zx_type_20,
};

pub const zx_type_533 = struct {
    active: bool,
    cache: *const zx_type_209,
    found: bool,
    left: u64,
    right: u64,
    slot: u64,
    value: u64,
};

pub const zx_type_534 = struct {
    active: bool,
    cache: *const zx_type_209,
    capacity: u64,
    grow: bool,
    index: u64,
    left: u64,
    right: u64,
    value: u64,
};

pub const zx_type_535 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: *const zx_type_197,
    index: u64,
    references: []const bool,
    same: bool,
    type_id: u32,
    types: *const zx_type_20,
};

pub const zx_type_536 = struct {
    action: zx_type_208,
    cache: *const zx_type_209,
    children: []const u64,
    first: []const u64,
    forest: *const zx_type_197,
    indices: []const u64,
    left: []const u64,
    paired: bool,
    references: []const bool,
    right: []const u64,
    types: *const zx_type_20,
    value: u64,
};

pub const zx_type_537 = struct {
    expressions: u64,
    facts: []const u64,
    memo: []const u64,
    places: u64,
    states: []const zx_type_176,
};

pub const zx_type_538 = struct { *const zx_type_169, *const zx_type_348, };

pub const zx_type_539 = struct { *const zx_type_169, *const zx_type_348, *const zx_type_220, };

pub const zx_type_540 = struct {
    action: zx_type_217,
    count: u64,
    index: u64,
    layout: *const zx_type_178,
    memo_first: u64,
    memory: *const zx_type_219,
    references: []const bool,
    rewrite_action: zx_type_208,
    saved: *const zx_type_218,
    state_first: u64,
    types: *const zx_type_20,
};

pub const zx_type_542 = struct { []const zx_type_223, ?zx_type_223, };

pub const zx_type_543 = struct { []const zx_type_223, void, };

pub const zx_type_544 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_197,
    index: u64,
    merge: bool,
    parents: []const u64,
    references: []const bool,
    saved: []const u64,
    source: []const u64,
    types: *const zx_type_20,
};

pub const zx_type_545 = struct {
    activation: u64,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: *const zx_type_197,
    index: u64,
    loops: *const zx_type_233,
    references: []const bool,
    seen: bool,
    types: *const zx_type_20,
    value: u64,
};

pub const zx_type_546 = struct {
    activation: u64,
    changed: bool,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: *const zx_type_197,
    index: u64,
    loops: *const zx_type_233,
    references: []const bool,
    types: *const zx_type_20,
    value: u64,
};

pub const zx_type_547 = struct {
    count: u64,
    facts: []const u64,
    first: u64,
    index: u64,
    layout: *const zx_type_178,
    local_first: u64,
    locals: u64,
    memory: *const zx_type_219,
    references: []const bool,
    roots: []const u64,
    symbols: []const u64,
    types: *const zx_type_20,
};

pub const zx_type_548 = struct {
    count: u64,
    flags: []const bool,
    symbols: u64,
};

pub const zx_type_549 = struct {
    count: u64,
    first: u64,
    flags: []const bool,
    index: u64,
    symbols: []const u64,
};

pub const zx_type_550 = struct {
    flags: []const bool,
    index: u64,
    memo: []const u64,
    parents: []const u64,
};

pub const zx_type_551 = struct {
    id: u64,
    parents: []const u64,
};

pub const zx_type_552 = struct {
    facts: []const u64,
    flags: []const bool,
    index: u64,
    outputs: []const u64,
    roots: []const u64,
    source: []const u64,
};

pub const zx_type_553 = struct {
    count: u64,
    first: u64,
};

pub const zx_type_554 = struct {
    found: bool,
    index: u64,
    slots: *const zx_type_62,
};

pub const zx_type_555 = struct {
    active: bool,
    ascending: bool,
    expression: u64,
    expressions: *const zx_type_42,
    found: bool,
    layout: *const zx_type_183,
    memo: []const u64,
    position: u64,
    trail: []const u64,
};

pub const zx_type_556 = struct {
    children: []const u64,
    count: u64,
    index: u64,
};

pub const zx_type_557 = struct { *const zx_type_169, *const zx_type_349, };

pub const zx_type_558 = struct { *const zx_type_169, *const zx_type_349, *const zx_type_227, };

pub const zx_type_559 = struct { *const zx_type_117, };

pub const zx_type_560 = struct { *const zx_type_117, bool, };

pub const zx_type_561 = struct { *const zx_type_117, bool, bool, };

pub const zx_type_562 = struct { *const zx_type_117, bool, bool, *const zx_type_169, };

pub const zx_type_563 = struct { *const zx_type_117, bool, bool, *const zx_type_169, *const zx_type_227, };

pub const zx_type_564 = struct { *const zx_type_117, bool, bool, *const zx_type_169, *const zx_type_227, bool, };

pub const zx_type_565 = struct { *const zx_type_117, bool, bool, bool, };

pub const zx_type_566 = struct { *const zx_type_117, bool, bool, bool, bool, };

pub const zx_type_567 = struct {
    expressions: *const zx_type_42,
    index: u64,
    limit: u64,
    valid: bool,
};

pub const zx_type_568 = struct {
    index: u64,
    members: []const []const u8,
    valid: bool,
};

pub const zx_type_569 = struct {
    index: u64,
    modules: *const zx_type_70,
    name: []const u8,
    owner: []const u8,
    valid: bool,
};

pub const zx_type_570 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_571 = struct {
    index: u64,
    left: []const []const u8,
    right: []const []const u8,
    valid: bool,
};

pub const zx_type_572 = struct {
    context: *const zx_type_106,
    index: u64,
    name: []const u8,
    owner: []const u8,
    valid: bool,
};

pub const zx_type_573 = struct { *const zx_type_106, };

pub const zx_type_574 = struct { *const zx_type_106, ?[]const u8, };

pub const zx_type_575 = struct { *const zx_type_106, ?[]const u8, []const u8, };

pub const zx_type_576 = struct { *const zx_type_106, ?[]const u8, []const u8, bool, };

pub const zx_type_577 = struct { *const zx_type_106, ?[]const u8, []const u8, bool, bool, };

pub const zx_type_578 = struct { *const zx_type_106, ?[]const u8, []const u8, bool, bool, bool, };

pub const zx_type_579 = struct { *const zx_type_106, ?[]const u8, []const u8, bool, bool, bool, bool, };

pub const zx_type_580 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u32,
    types: []const u32,
};

pub const zx_type_581 = struct {
    input: *const zx_type_267,
    position: u64,
    positions: []const ?u32,
    type_ids: []const u32,
    valid: bool,
};

pub const zx_type_582 = struct { []const u32, ?u32, };

pub const zx_type_584 = struct { []const ?u32, ??u32, };

pub const zx_type_585 = struct { []const ?u32, void, };

pub const zx_type_586 = struct { *const zx_type_267, };

pub const zx_type_587 = struct { *const zx_type_267, bool, };

pub const zx_type_588 = struct { *const zx_type_267, bool, bool, };

pub const zx_type_589 = struct { *const zx_type_261, };

pub const zx_type_590 = struct { *const zx_type_261, bool, };

pub const zx_type_591 = struct { *const zx_type_261, bool, bool, };

pub const zx_type_592 = struct { *const zx_type_261, bool, bool, bool, };

pub const zx_type_593 = struct { *const zx_type_261, bool, bool, bool, ?*const zx_type_267, };

pub const zx_type_594 = struct { *const zx_type_261, bool, bool, bool, ?*const zx_type_267, bool, };

pub const zx_type_595 = struct { *const zx_type_261, bool, *const zx_type_75, };

pub const zx_type_596 = struct { *const zx_type_261, bool, *const zx_type_75, bool, };

pub const zx_type_597 = struct {
    index: u64,
    names: []const []const u8,
    table: *const zx_type_19,
    types: []const u32,
    valid: bool,
};

pub const zx_type_598 = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_599 = struct { []const *const zx_type_274, void, };

pub const zx_type_600 = struct {
    contracts: *const zx_type_50,
    index: u64,
    state: *const zx_type_278,
};

pub const zx_type_601 = struct { []const []const u8, void, };

pub const zx_type_602 = struct { []const *const zx_type_273, void, };

pub const zx_type_603 = struct {
    control: *const zx_type_53,
    first: u64,
    frames: []const *const zx_type_273,
    index: u64,
    source: u64,
};

pub const zx_type_604 = struct {
    capacity: u64,
    slots: []const u64,
};

pub const zx_type_605 = struct {
    index: u64,
    previous: []const u64,
    slots: []const u64,
};

pub const zx_type_606 = struct {
    key: u64,
    position: u64,
    slots: []const u64,
};

pub const zx_type_607 = struct {
    end: u64,
    index: u64,
    table: *const zx_type_42,
    values: []const u32,
};

pub const zx_type_608 = struct { []const []const u8, []const []const u8, };

pub const zx_type_609 = struct {
    end: u64,
    expressions: *const zx_type_42,
    index: u64,
    names: []const []const u8,
    tables: *const zx_type_20,
};

pub const zx_type_610 = struct { []const *const zx_type_274, []const *const zx_type_274, };

pub const zx_type_611 = struct {
    frames: []const *const zx_type_273,
    index: u64,
    source: u64,
    values: []const u32,
};

pub const zx_type_613 = struct { []const *const zx_type_273, ?*const zx_type_273, };

pub const zx_type_614 = struct {
    index: u64,
    names: []const []const u8,
    values: []const []const u8,
};

pub const zx_type_615 = struct { *const zx_type_279, };

pub const zx_type_616 = struct { *const zx_type_279, *const zx_type_278, };

pub const zx_type_617 = struct { *const zx_type_279, *const zx_type_278, *const zx_type_278, };

pub const zx_type_618 = struct { *const zx_type_279, *const zx_type_278, *const zx_type_278, ?[]const []const u8, };

pub const zx_type_619 = struct {
    context: *const zx_type_275,
    index: u64,
    unit: *const zx_type_75,
    valid: bool,
};

pub const zx_type_620 = struct {
    first: u64,
    index: u64,
    members: []const []const u8,
    names: []const []const u8,
    valid: bool,
};

pub const zx_type_621 = struct { *const zx_type_76, bool, bool, bool, };

pub const zx_type_622 = struct { *const zx_type_76, bool, bool, bool, bool, };

pub const zx_type_623 = struct { *const zx_type_76, bool, bool, bool, bool, bool, };

pub const zx_type_624 = struct {
    index: u64,
    result: []const bool,
    source: []const u8,
};

pub const zx_type_625 = struct {
    context: *const zx_type_74,
    declared: []const bool,
    index: u64,
    origins: *const zx_type_15,
    valid: bool,
};

pub const zx_type_626 = struct {
    declared: []const bool,
    index: u64,
    table: *const zx_type_19,
    valid: bool,
};

pub const zx_type_627 = struct {
    found: bool,
    identity: []const u8,
    index: u64,
    stores: []const *const zx_type_62,
    type_id: u32,
    valid: bool,
};

pub const zx_type_628 = struct {
    found: bool,
    identity: []const u8,
    index: u64,
    stores: *const zx_type_62,
    type_id: u32,
    valid: bool,
};

pub const zx_type_629 = struct {
    index: u64,
    kinds: []const zx_type_27,
    valid: bool,
};

pub const zx_type_630 = struct {
    graph: *const zx_type_79,
    index: u64,
    valid: bool,
};

pub const zx_type_631 = struct {
    index: u64,
    input: *const zx_type_292,
    valid: bool,
};

pub const zx_type_632 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    limit: u64,
    right: []const u8,
};

pub const zx_type_633 = struct {
    building: bool,
    count: u64,
    names: []const []const u8,
    remaining: u64,
    root: u64,
    sifting: bool,
    types: []const u32,
};

pub const zx_type_634 = struct {
    index: u64,
    names: []const []const u8,
    stores: []const *const zx_type_62,
    types: []const u32,
};

pub const zx_type_635 = struct {
    fields: *const zx_type_21,
    index: u64,
    valid: bool,
};

pub const zx_type_636 = struct { *const zx_type_79, };

pub const zx_type_637 = struct { *const zx_type_79, bool, };

pub const zx_type_638 = struct { *const zx_type_79, bool, bool, };

pub const zx_type_639 = struct { *const zx_type_79, bool, bool, bool, };

pub const zx_type_640 = struct { *const zx_type_79, bool, bool, bool, bool, };

pub const zx_type_641 = struct { *const zx_type_79, bool, bool, bool, bool, bool, };

pub const zx_type_642 = struct { *const zx_type_79, bool, bool, bool, bool, bool, bool, };

pub const zx_type_643 = struct { *const zx_type_79, bool, bool, bool, bool, bool, bool, bool, };

pub const zx_type_644 = struct {
    count: u64,
    index: u64,
    scalar: u8,
    table: *const zx_type_19,
    zero: u32,
};

pub const zx_type_645 = struct { []const u8, void, };

pub const zx_type_646 = struct {
    found: bool,
    index: u64,
    modules: *const zx_type_70,
    value: []const u8,
};

pub const zx_type_647 = struct {
    index: u64,
    input: *const zx_type_295,
    owners: []const []const u8,
};

pub const zx_type_648 = struct { u32, };

pub const zx_type_649 = struct {
    captures: *const zx_type_648,
    index: u64,
    result: []const u32,
    source: []const u8,
};

pub const zx_type_650 = struct {
    index: u64,
    result: []const u64,
    source: []const u8,
};

pub const zx_type_651 = struct {
    index: u64,
    indices: []const u64,
    names: []const []const u8,
    origins: *const zx_type_15,
    source: *const zx_type_19,
    valid: bool,
};

pub const zx_type_652 = struct { *const zx_type_351, };

pub const zx_type_653 = struct { *const zx_type_351, bool, };

pub const zx_type_654 = struct { *const zx_type_351, bool, *const zx_type_301, };

pub const zx_type_655 = struct { *const zx_type_351, bool, *const zx_type_301, bool, };

pub const zx_type_656 = struct {
    equal: bool,
    index: u64,
    left: *const zx_type_303,
    right: *const zx_type_303,
};

pub const zx_type_657 = struct {
    first: u64,
    index: u64,
    source: *const zx_type_19,
    target: *const zx_type_19,
    valid: bool,
};

pub const zx_type_658 = struct {
    first: u64,
    index: u64,
    mapping: []const u32,
};

pub const zx_type_659 = struct {
    candidate: *const zx_type_109,
    count: u64,
    id: u32,
    index: u64,
    origin: *const zx_type_11,
    origins: *const zx_type_16,
    status: zx_type_309,
    tables: *const zx_type_20,
};

pub const zx_type_660 = struct {
    count: u64,
    first: u64,
    index: u64,
    mapping: []const u32,
    references: []const u32,
    values: []const u32,
};

pub const zx_type_661 = struct {
    candidate: *const zx_type_109,
    count: u64,
    found: bool,
    id: u32,
    index: u64,
    tables: *const zx_type_20,
};

pub const zx_type_662 = struct {
    index: u64,
    request: *const zx_type_296,
    state: *const zx_type_297,
};

pub const zx_type_663 = struct { *const zx_type_298, };

pub const zx_type_664 = struct { *const zx_type_298, bool, };

pub const zx_type_665 = struct { *const zx_type_298, bool, []const u32, };

pub const zx_type_666 = struct { *const zx_type_298, bool, []const u32, *const zx_type_297, };

pub const zx_type_667 = struct { *const zx_type_299, };

pub const zx_type_668 = struct { *const zx_type_299, *const zx_type_297, };

pub const zx_type_669 = struct { *const zx_type_299, *const zx_type_297, ?[]const u64, };

pub const zx_type_670 = struct { *const zx_type_299, *const zx_type_297, ?[]const u64, *const zx_type_297, };

pub const zx_type_671 = struct { *const zx_type_331, };

pub const zx_type_672 = struct {
    captures: *const zx_type_671,
    index: u64,
    result: []const u32,
    source: []const u32,
};

pub const zx_type_673 = struct {
    ids: []const u32,
    index: u64,
    names: []const []const u8,
    valid: bool,
    value: *const zx_type_327,
};

pub const zx_type_674 = struct {
    base: *const zx_type_70,
    count: u64,
    delta: *const zx_type_70,
    found: bool,
    import_name: []const u8,
    index: u64,
    name: []const u8,
};

pub const zx_type_675 = struct { []const ?[]const u8, void, };

pub const zx_type_676 = struct { []const []const u32, void, };

pub const zx_type_677 = struct { []const []const []const u8, void, };

pub const zx_type_678 = struct { *const zx_type_355, };

pub const zx_type_679 = struct { *const zx_type_355, *const zx_type_327, };

pub const zx_type_680 = struct { *const zx_type_355, *const zx_type_327, []const u32, };

pub const zx_type_681 = struct { *const zx_type_355, *const zx_type_327, []const u32, *const zx_type_328, };

pub const zx_type_682 = struct { *const zx_type_339, };

pub const zx_type_683 = struct {
    captures: *const zx_type_682,
    index: u64,
    result: []const u32,
    source: []const u32,
};

pub const zx_type_684 = struct { *const zx_type_356, };

pub const zx_type_685 = struct { *const zx_type_356, *const zx_type_45, };

pub const zx_type_686 = struct { *const zx_type_356, *const zx_type_45, *const zx_type_42, };

pub const zx_type_687 = struct {
    expressions: []const *const zx_type_42,
    index: u64,
    input: *const zx_type_340,
    symbols: []const *const zx_type_45,
};

pub const zx_type_688 = struct { []const *const zx_type_45, void, };

pub const zx_type_689 = struct { []const *const zx_type_42, void, };

pub const zx_type_690 = struct { *const zx_type_341, };

pub const zx_type_691 = struct {
    captures: *const zx_type_690,
    index: u64,
    result: []const []const u8,
    source: []const []const u8,
};

pub const zx_type_692 = struct { *const zx_type_336, };

pub const zx_type_693 = struct { *const zx_type_336, *const zx_type_337, };

pub const zx_type_694 = struct { *const zx_type_336, *const zx_type_337, *const zx_type_45, };

pub const zx_type_695 = struct { *const zx_type_336, *const zx_type_337, *const zx_type_45, *const zx_type_42, };

pub const zx_type_696 = struct { *const zx_type_336, *const zx_type_337, *const zx_type_45, *const zx_type_42, *const zx_type_50, };

pub const zx_type_697 = struct { *const zx_type_336, *const zx_type_337, *const zx_type_45, *const zx_type_42, *const zx_type_50, *const zx_type_62, };

pub const zx_type_698 = struct {
    contracts: []const *const zx_type_50,
    expressions: []const *const zx_type_42,
    files: []const []const u8,
    index: u64,
    inputs: []const u32,
    modules: []const ?u32,
    outputs: []const u32,
    request: *const zx_type_334,
    stores: []const *const zx_type_62,
    symbols: []const *const zx_type_45,
};

pub const zx_type_699 = struct { []const *const zx_type_62, void, };

pub const zx_type_700 = struct { []const *const zx_type_50, void, };

pub const zx_type_701 = struct {
    functions: []const ?u32,
    index: u64,
    input: *const zx_type_342,
    paths: []const []const u8,
    types: []const []const u32,
};

pub const zx_type_702 = struct { *const zx_type_343, };

pub const zx_type_703 = struct {
    captures: *const zx_type_702,
    index: u64,
    result: []const []const u8,
    source: []const []const u8,
};

pub const zx_type_704 = struct {
    captures: *const zx_type_702,
    index: u64,
    result: []const u32,
    source: []const u32,
};

pub const zx_type_705 = struct { *const zx_type_353, };

pub const zx_type_706 = struct { *const zx_type_353, *const zx_type_68, };

pub const zx_type_707 = struct { *const zx_type_353, *const zx_type_68, *const zx_type_77, };

pub const zx_type_708 = struct { *const zx_type_353, *const zx_type_68, *const zx_type_77, *const zx_type_78, };

pub const zx_type_709 = struct { *const zx_type_353, *const zx_type_68, *const zx_type_77, *const zx_type_78, *const zx_type_19, };

pub const zx_type_710 = struct { *const zx_type_81, };

pub const zx_type_711 = struct { *const zx_type_81, *const zx_type_19, };

pub const zx_type_712 = struct { *const zx_type_81, *const zx_type_19, *const zx_type_15, };

pub const zx_type_713 = struct { *const zx_type_81, *const zx_type_19, *const zx_type_15, *const zx_type_297, };

pub const zx_type_714 = struct { *const zx_type_81, *const zx_type_19, *const zx_type_15, *const zx_type_297, bool, };

pub const zx_type_715 = struct { *const zx_type_81, *const zx_type_19, *const zx_type_15, *const zx_type_297, bool, *const zx_type_328, };

pub const zx_type_716 = struct { *const zx_type_81, *const zx_type_19, *const zx_type_15, *const zx_type_297, bool, *const zx_type_328, *const zx_type_82, };

pub const zx_type_717 = struct { *const zx_type_81, *const zx_type_19, *const zx_type_15, *const zx_type_297, bool, *const zx_type_82, };

pub const zx_type_718 = struct { *const zx_type_81, *const zx_type_19, *const zx_type_15, *const zx_type_297, u64, };

pub const zx_type_719 = struct { *const zx_type_81, *const zx_type_19, *const zx_type_15, *const zx_type_297, u64, *const zx_type_82, };

pub const zx_type_720 = struct { *const zx_type_81, bool, };

pub const zx_type_721 = struct { *const zx_type_81, bool, bool, };

pub const zx_type_722 = struct { *const zx_type_81, bool, bool, bool, };

pub const zx_type_723 = struct { *const zx_type_81, bool, bool, bool, *const zx_type_82, };

pub const zx_type_724 = struct { *const zx_type_81, bool, bool, *const zx_type_82, };

pub const zx_type_725 = struct { *const zx_type_81, bool, *const zx_type_82, };

pub const value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_11 = null,
};

pub const value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
    zx_origin: ?*const zx_type_15 = null,
};

pub const value_zx_type_16_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53 = struct {
    base: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    delta: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_17_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = struct {
    names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    base: *const zx_type_19,
    delta: *const zx_type_19,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_21 = null,
};

pub const value_zx_type_22_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_18,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_22 = null,
};

pub const value_zx_type_23_86fe3af64a4fc82484b11d86fdfb9b3c31ed1030b6b1103b69296f1bbd952e94 = struct {
    index: u64,
    names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_23 = null,
};

pub const value_zx_type_24_56513ec0a3f7b0e8fe4c027e5a3dc9f234c7819d1970f29b9e830566c787d458 = struct {
    index: u64,
    names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_24 = null,
};

pub const value_zx_type_25_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = struct {
    names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_25 = null,
};

pub const value_zx_type_26_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    artifact: []const u8,
    instance: []const u8,
    load: bool,
    zx_origin: ?*const zx_type_26 = null,
};

pub const value_zx_type_61_27f6baed02dfb16b8bbeaef695a80d4899de28e19dde605fcd26d176c6e70749 = struct {
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_43,
    zx_origin: ?*const zx_type_61 = null,
};

pub const value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8 = struct {
    contracts: []const *const zx_type_50,
    control: []const *const zx_type_53,
    expressions: []const *const zx_type_42,
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_43,
    roots: []const ?u32,
    store_modes: []const zx_type_63,
    stores: []const *const zx_type_62,
    symbols: []const *const zx_type_45,
    zx_origin: ?*const zx_type_68 = null,
};

pub const value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    identities: []const ?[]const u8,
    import_names: []const []const u8,
    specifiers: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    type_namespaces: []const []const []const u8,
    zx_origin: ?*const zx_type_70 = null,
};

pub const value_zx_type_71_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    output_types: []const u32,
    zx_origin: ?*const zx_type_71 = null,
};

pub const value_zx_type_72_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80 = struct {
    control: *const zx_type_53,
    expressions: *const zx_type_42,
    root: ?u32,
    stores: *const zx_type_62,
    symbols: *const zx_type_45,
    zx_origin: ?*const zx_type_72 = null,
};

pub const value_zx_type_73_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_42,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_45,
    zx_origin: ?*const zx_type_73 = null,
};

pub const value_zx_type_74_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e = struct {
    functions: value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8,
    max_offset: u64,
    maximum_count: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    scalar_count: u64,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_74 = null,
};

pub const value_zx_type_75_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5 = struct {
    body: value_zx_type_72_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80,
    contracts: *const zx_type_50,
    input_type: u32,
    output_ownership: zx_type_43,
    output_type: u32,
    transaction: bool,
    type_only: bool,
    zx_origin: ?*const zx_type_75 = null,
};

pub const value_zx_type_76_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235 = struct {
    context: value_zx_type_74_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e,
    expected_version: u64,
    export_names: []const []const u8,
    export_types: []const u32,
    unit: value_zx_type_75_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5,
    version: u64,
    zx_origin: ?*const zx_type_76 = null,
};

pub const value_zx_type_77_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    functions: []const ?u32,
    names: []const []const u8,
    paths: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    zx_origin: ?*const zx_type_77 = null,
};

pub const value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    functions: []const u32,
    identities: []const []const u8,
    versions: []const u32,
    zx_origin: ?*const zx_type_78 = null,
};

pub const value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638 = struct {
    exports: value_zx_type_77_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    initializers: value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origin_names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    program: value_zx_type_76_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235,
    zx_origin: ?*const zx_type_79 = null,
};

pub const value_zx_type_80_568cf0b95c6523ecc986c6032ffd9fea08a5f5091afc3b1382361c635503b72f = struct {
    function_count: u64,
    natives: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    origin_names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    types: *const zx_type_19,
    zx_origin: ?*const zx_type_80 = null,
};

pub const value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed = struct {
    artifact: []const u8,
    destination: value_zx_type_80_568cf0b95c6523ecc986c6032ffd9fea08a5f5091afc3b1382361c635503b72f,
    graph: value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638,
    instance: []const u8,
    load: bool,
    seed: bool,
    zx_origin: ?*const zx_type_81 = null,
};

pub const value_zx_type_82_28f473da2a87d2ad04981199ccf8ba960699ded176a2bd8d1e7bcc545893a7b9 = struct {
    exports: value_zx_type_77_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    functions: value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8,
    initializers: value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    natives: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    status: u64,
    types: *const zx_type_19,
    zx_origin: ?*const zx_type_82 = null,
};

pub const value_zx_type_83_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    maximum_count: u64,
    scalar_count: u64,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_83 = null,
};

pub const value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    kind: zx_type_84,
    name: []const u8,
    zx_origin: ?*const zx_type_85 = null,
};

pub const value_zx_type_86_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_86 = null,
};

pub const value_zx_type_87_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_87 = null,
};

pub const value_zx_type_88_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    errors: bool,
    first: u64,
    values: []const []const u8,
    zx_origin: ?*const zx_type_88 = null,
};

pub const value_zx_type_89_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_89 = null,
};

pub const value_zx_type_90_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    scalar_count: u64,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_90 = null,
};

pub const value_zx_type_91_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
    zx_origin: ?*const zx_type_91 = null,
};

pub const value_zx_type_92_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    max_offset: u64,
    symbols: *const zx_type_45,
    zx_origin: ?*const zx_type_92 = null,
};

pub const value_zx_type_93_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_42,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
    zx_origin: ?*const zx_type_93 = null,
};

pub const value_zx_type_94_65cf7d6fbad1c16266bae803c08ca5f9cfd0a43ae4a2b544cd579935fe760b39 = struct {
    kind: zx_type_27,
    payload: u64,
    state: value_zx_type_93_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a,
    zx_origin: ?*const zx_type_94 = null,
};

pub const value_zx_type_95_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
    zx_origin: ?*const zx_type_95 = null,
};

pub const value_zx_type_96_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    max_offset: u64,
    table: *const zx_type_42,
    zx_origin: ?*const zx_type_96 = null,
};

pub const value_zx_type_97_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    block: u64,
    control: *const zx_type_53,
    zx_origin: ?*const zx_type_97 = null,
};

pub const value_zx_type_98_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct {
    control: *const zx_type_53,
    root: ?u32,
    zx_origin: ?*const zx_type_98 = null,
};

pub const value_zx_type_99_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const ?u32,
    zx_origin: ?*const zx_type_99 = null,
};

pub const value_zx_type_100_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u32,
    zx_origin: ?*const zx_type_100 = null,
};

pub const value_zx_type_101_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    contracts: *const zx_type_50,
    max_offset: u64,
    zx_origin: ?*const zx_type_101 = null,
};

pub const value_zx_type_102_5ec2c5edd29e0d3f01648c48f884d91d1e084ad59827a77873e8587ae07c5bf1 = struct {
    functions: value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8,
    index: u64,
    zx_origin: ?*const zx_type_102 = null,
};

pub const value_zx_type_104_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    index: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_104 = null,
};

pub const value_zx_type_105_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct {
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_105 = null,
};

pub const value_zx_type_106_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea = struct {
    functions: value_zx_type_71_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    index: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_106 = null,
};

pub const value_zx_type_107_80fa3f09fde2ea8660c1d43e969ee3d68c4cda0e85a50de87ab5f1fb43c5c390 = struct {
    context: value_zx_type_105_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189,
    type_id: u64,
    zx_origin: ?*const zx_type_107 = null,
};

pub const value_zx_type_108_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u32,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_108 = null,
};

pub const value_zx_type_109_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_18,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_109 = null,
};

pub const value_zx_type_110_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_110 = null,
};

pub const value_zx_type_111_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    delta: *const zx_type_19,
    id: u32,
    zx_origin: ?*const zx_type_111 = null,
};

pub const value_zx_type_112_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_112 = null,
};

pub const value_zx_type_113_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    id: u32,
    native_references: bool,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_113 = null,
};

pub const value_zx_type_114_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    id: u32,
    native_references: bool,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_114 = null,
};

pub const value_zx_type_115_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u64,
    paths: []const []const u8,
    zx_origin: ?*const zx_type_115 = null,
};

pub const value_zx_type_116_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    paths: []const []const u8,
    slot_types: []const u32,
    table: *const zx_type_19,
    type_only: bool,
    zx_origin: ?*const zx_type_116 = null,
};

pub const value_zx_type_117_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d = struct {
    context: value_zx_type_74_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e,
    unit: value_zx_type_75_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5,
    zx_origin: ?*const zx_type_117 = null,
};

pub const value_zx_type_118_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: *const zx_type_42,
    id: u32,
    index: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_118 = null,
};

pub const value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_62,
    zx_origin: ?*const zx_type_119 = null,
};

pub const value_zx_type_120_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6 = struct {
    expressions: *const zx_type_42,
    functions: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_62,
    symbols: *const zx_type_45,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_120 = null,
};

pub const value_zx_type_121_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed = struct {
    context: value_zx_type_120_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    kind: zx_type_27,
    payload: u64,
    target: zx_type_18,
    type_id: u32,
    zx_origin: ?*const zx_type_121 = null,
};

pub const value_zx_type_125_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    available: *const zx_type_62,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_62,
    slots: []const u32,
    zx_origin: ?*const zx_type_125 = null,
};

pub const value_zx_type_126_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    table: *const zx_type_19,
    type_id: u32,
    zx_origin: ?*const zx_type_126 = null,
};

pub const value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    contracts: *const zx_type_50,
    input_type: u32,
    max_offset: u64,
    output_type: u32,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_127 = null,
};

pub const value_zx_type_128_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603 = struct {
    index: u64,
    program: value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_128 = null,
};

pub const value_zx_type_129_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    control: *const zx_type_53,
    returns: []const bool,
    selection: u64,
    zx_origin: ?*const zx_type_129 = null,
};

pub const value_zx_type_130_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_42,
    limit: u64,
    zx_origin: ?*const zx_type_130 = null,
};

pub const value_zx_type_131_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: []const *const zx_type_42,
    native_concurrent: []const bool,
    native_modules: []const ?u32,
    stores: []const *const zx_type_62,
    zx_origin: ?*const zx_type_131 = null,
};

pub const value_zx_type_132_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = struct {
    concurrent: bool,
    functions: value_zx_type_131_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_132 = null,
};

pub const value_zx_type_133_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
    zx_origin: ?*const zx_type_133 = null,
};

pub const value_zx_type_134_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    captures: u64,
    nonnull: u64,
    zx_origin: ?*const zx_type_134 = null,
};

pub const value_zx_type_135_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    conditions: []const u64,
    facts: value_zx_type_133_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    truths: []const bool,
    zx_origin: ?*const zx_type_135 = null,
};

pub const value_zx_type_137_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    a: u64,
    b: u64,
    c: u64,
    phase: zx_type_136,
    zx_origin: ?*const zx_type_137 = null,
};

pub const value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7 = struct {
    body: value_zx_type_72_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80,
    functions: value_zx_type_131_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    output_type: u32,
    table: *const zx_type_19,
    transaction: bool,
    zx_origin: ?*const zx_type_138 = null,
};

pub const value_zx_type_139_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    concurrent: []const bool,
    pure: []const bool,
    returns: []const bool,
    zx_origin: ?*const zx_type_139 = null,
};

pub const value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0 = struct {
    prepared: value_zx_type_139_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    program: value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    zx_origin: ?*const zx_type_140 = null,
};

pub const value_zx_type_141_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    active: []const bool,
    changed_symbols: []const u64,
    changed_values: []const bool,
    declared: []const bool,
    owners: []const u64,
    zx_origin: ?*const zx_type_141 = null,
};

pub const value_zx_type_143_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    a: []const u64,
    b: []const u64,
    c: []const u64,
    phases: []const zx_type_136,
    zx_origin: ?*const zx_type_143 = null,
};

pub const value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d = struct {
    activity: value_zx_type_141_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    frames: value_zx_type_143_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    refinement: value_zx_type_135_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    zx_origin: ?*const zx_type_144 = null,
};

pub const value_zx_type_145_f470abcbb887e90abb8d9cc33ef348b0350c739d56bd4342cef13bf8e9afa562 = struct {
    context: value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0,
    frame: value_zx_type_137_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_145 = null,
};

pub const value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063 = struct {
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    valid: bool,
    zx_origin: ?*const zx_type_147 = null,
};

pub const value_zx_type_148_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct {
    facts: value_zx_type_133_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    symbol: u32,
    zx_origin: ?*const zx_type_148 = null,
};

pub const value_zx_type_149_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    expressions: *const zx_type_42,
    facts: value_zx_type_133_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    payload: u64,
    truth: bool,
    zx_origin: ?*const zx_type_149 = null,
};

pub const value_zx_type_150_180c8db61327c5ec28c1dd7044b5cf087f6bf11c71b70daa8f83a901fbf86853 = struct {
    condition: u64,
    expressions: *const zx_type_42,
    state: value_zx_type_135_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    truth: bool,
    zx_origin: ?*const zx_type_150 = null,
};

pub const value_zx_type_151_92508f644127bb85f633340ef0446c798ffdbb802763fefb2c89d184c66bdb3c = struct {
    facts: value_zx_type_133_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    mark: value_zx_type_134_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_151 = null,
};

pub const value_zx_type_152_b4c00b0680a164f9ad85cafef49c2f1d31566b1a676a14d85e4570178e088fb9 = struct {
    activity: value_zx_type_141_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    mark: u64,
    zx_origin: ?*const zx_type_152 = null,
};

pub const value_zx_type_153_305a62f990205c111b44fc67db9221487d395cc635760c1b61644adb1bf4c462 = struct {
    context: value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0,
    statement: u64,
    zx_origin: ?*const zx_type_153 = null,
};

pub const value_zx_type_154_951ce996038a89a93b91040661ad8e5f18114a0520be5139c04eac3a15e2318a = struct {
    frame: value_zx_type_137_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_154 = null,
};

pub const value_zx_type_155_79b96ffa2e891f4534c9a8b770935af0223aeb89cda66f40793025b64b74d946 = struct {
    activity: value_zx_type_141_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    symbol: u64,
    value: bool,
    zx_origin: ?*const zx_type_155 = null,
};

pub const value_zx_type_156_a8cc14e4741ce478441a6af0b40d58bf8b3f27bab9314693255c6d791dc94e81 = struct {
    mode: zx_type_146,
    owner: u64,
    program: value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    symbol: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_156 = null,
};

pub const value_zx_type_157_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    err: u32,
    facts: value_zx_type_133_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: u32,
    zx_origin: ?*const zx_type_157 = null,
};

pub const value_zx_type_158_073d891ba45095e5915c165198921d39ae001c11a900ba5941237395e3848750 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_42,
    facts: value_zx_type_133_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: ?u32,
    value: u64,
    zx_origin: ?*const zx_type_158 = null,
};

pub const value_zx_type_159_b8ec70fbd49037c4f5f15832ef24774698f9ceaf2b6c8bda56f20308b14ddd6f = struct {
    count: u64,
    depth: u64,
    first: u64,
    flags: u64,
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    values: []const u32,
    zx_origin: ?*const zx_type_159 = null,
};

pub const value_zx_type_160_cf7f91935142e682a287d5d100dd4ce0b0109b30ee54eeca5ee330715975db08 = struct {
    count: u64,
    expressions: *const zx_type_42,
    facts: value_zx_type_133_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    first: u64,
    zx_origin: ?*const zx_type_160 = null,
};

pub const value_zx_type_161_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    active: []const bool,
    count: u64,
    first: u64,
    symbols: []const u32,
    zx_origin: ?*const zx_type_161 = null,
};

pub const value_zx_type_162_c63bcba686670049248646377d5d23dc63c4a7a91d3483419515b2f1fd8e2b64 = struct {
    payload: u64,
    position: u64,
    program: value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    zx_origin: ?*const zx_type_162 = null,
};

pub const value_zx_type_164_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expressions: *const zx_type_42,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_164 = null,
};

pub const value_zx_type_165_b06ba9ffb7550edab6c90294a6cfddbec1276107726d70c06500e2c71a01deb4 = struct {
    payload: u64,
    program: value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    zx_origin: ?*const zx_type_165 = null,
};

pub const value_zx_type_166_0052edaa8370b31f34b2f05af01ed3537fdd252f1e5484a30f0eadd3bd3f1c9d = struct {
    context: value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0,
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_166 = null,
};

pub const value_zx_type_167_d67de9150a29b2c86fcfaa670164fb137ade9312feda415779572f647ca40086 = struct {
    body: value_zx_type_72_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80,
    input_type: u32,
    output_type: u32,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_167 = null,
};

pub const value_zx_type_168_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    ownership: []const zx_type_43,
    stores: []const *const zx_type_62,
    zx_origin: ?*const zx_type_168 = null,
};

pub const value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695 = struct {
    body: ?u32,
    control: *const zx_type_53,
    expressions: *const zx_type_42,
    functions: value_zx_type_168_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    symbols: *const zx_type_45,
    type_only: bool,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_169 = null,
};

pub const value_zx_type_170_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u64,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_170 = null,
};

pub const value_zx_type_171_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expression: u64,
    expressions: *const zx_type_42,
    index: u64,
    zx_origin: ?*const zx_type_171 = null,
};

pub const value_zx_type_172_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expression: u64,
    found: bool,
    zx_origin: ?*const zx_type_172 = null,
};

pub const value_zx_type_173_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expression: u64,
    expressions: *const zx_type_42,
    locals: []const bool,
    zx_origin: ?*const zx_type_173 = null,
};

pub const value_zx_type_174_e05028d9f2b1d7792bfed137694ab8e6051e740db09be899cd5c3c4ff8b94544 = struct {
    expression: u64,
    program: value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    zx_origin: ?*const zx_type_174 = null,
};

pub const value_zx_type_175_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u64,
    first: []const u64,
    symbols: []const u64,
    zx_origin: ?*const zx_type_175 = null,
};

pub const value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u64,
    field_indices: []const u64,
    parents: []const u64,
    references: []const bool,
    siblings: []const u64,
    types: []const u32,
    zx_origin: ?*const zx_type_178 = null,
};

pub const value_zx_type_180_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d = struct {
    id: u64,
    layout: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    operation: zx_type_177,
    states: []const zx_type_176,
    value: zx_type_176,
    zx_origin: ?*const zx_type_180 = null,
};

pub const value_zx_type_181_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u64,
    first: []const u64,
    positions: []const u64,
    zx_origin: ?*const zx_type_181 = null,
};

pub const value_zx_type_182_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937 = struct {
    cached: value_zx_type_181_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    heads: []const u64,
    next: []const u64,
    tree: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_182 = null,
};

pub const value_zx_type_183_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d = struct {
    cached: value_zx_type_181_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    tree: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    values: []const u64,
    zx_origin: ?*const zx_type_183 = null,
};

pub const value_zx_type_185_767b69074202a272a12100b84e23109da965767802298cfb5e4fed280635514e = struct {
    program: value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    zx_origin: ?*const zx_type_185 = null,
};

pub const value_zx_type_186_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capacity: u64,
    field: u64,
    parent: u64,
    zx_origin: ?*const zx_type_186 = null,
};

pub const value_zx_type_187_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_187 = null,
};

pub const value_zx_type_188_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    field: u64,
    parent: u64,
    zx_origin: ?*const zx_type_188 = null,
};

pub const value_zx_type_189_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_189 = null,
};

pub const value_zx_type_190_0093e0155d66cb511a94de9e5d1d5b400f76ae0078e86bc776bc6b8934ee5924 = struct {
    index: value_zx_type_187_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    key: value_zx_type_188_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_190 = null,
};

pub const value_zx_type_191_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expressions: *const zx_type_42,
    id: u64,
    zx_origin: ?*const zx_type_191 = null,
};

pub const value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u32,
    target: u64,
    zx_origin: ?*const zx_type_192 = null,
};

pub const value_zx_type_194_66dcc527b00a87c3c2a5109b4a3924ac4c4d43c09f84caa10ed23e5ea63930cf = struct {
    active: bool,
    ancestor: u64,
    bindings: []const u64,
    cached: value_zx_type_181_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    capacity: u64,
    child_expression: u64,
    children: []const u64,
    cursor: u64,
    direct: bool,
    expression: u64,
    field_indices: []const u64,
    heads: []const u64,
    key_fields: []const u64,
    key_parents: []const u64,
    next: []const u64,
    parent: u64,
    parents: []const u64,
    path: []const u64,
    path_index: u64,
    phase: zx_type_193,
    place_types: []const u32,
    program: value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    record: u64,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_194 = null,
};

pub const value_zx_type_195_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    first: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_195 = null,
};

pub const value_zx_type_196_08ae4a5c88157bebdfb632c2939fd9a2fdb6e48e4cc60655b08697fb2d0015fb = struct {
    program: value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    roots: value_zx_type_182_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937,
    zx_origin: ?*const zx_type_196 = null,
};

pub const value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u64,
    count: []const u64,
    first: []const u64,
    shells: []const zx_type_176,
    states: []const zx_type_176,
    types: []const u32,
    zx_origin: ?*const zx_type_197 = null,
};

pub const value_zx_type_198_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    fact: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_198 = null,
};

pub const value_zx_type_199_461a038225996c015433bf0a5fb2c9e6a36f43e598f85eccd7a2eee1e984e893 = struct {
    fact: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    reference: bool,
    zx_origin: ?*const zx_type_199 = null,
};

pub const value_zx_type_200_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    index: u64,
    type_id: u32,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_200 = null,
};

pub const value_zx_type_201_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    left: zx_type_176,
    right: zx_type_176,
    zx_origin: ?*const zx_type_201 = null,
};

pub const value_zx_type_202_df87d4e4c94482fd017e977a114eba826861ac6af356c343aea16855cac7c373 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    shell: zx_type_176,
    type_id: u32,
    zx_origin: ?*const zx_type_202 = null,
};

pub const value_zx_type_203_b1b23fbb7680b8cb1b3dadbfa986aa274ef1483cb6efee44a47ca580481a8e23 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    shell: zx_type_176,
    type_id: u32,
    zx_origin: ?*const zx_type_203 = null,
};

pub const value_zx_type_204_48e6facbc67e19905cc5d1979cc7988969acfd6e4bae54b78cb7684de3ebbbab = struct {
    fact: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    type_id: u32,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_204 = null,
};

pub const value_zx_type_205_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0 = struct {
    facts: []const u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    states: []const zx_type_176,
    zx_origin: ?*const zx_type_205 = null,
};

pub const value_zx_type_206_c7b60c00d717dc61a2a9736408d32321057c2522adc791850c9eae52b70181a8 = struct {
    fact: u64,
    id: u64,
    layout: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    references: []const bool,
    storage: value_zx_type_205_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_206 = null,
};

pub const value_zx_type_207_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capacity: u64,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_207 = null,
};

pub const value_zx_type_209_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    left: []const u64,
    right: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_209 = null,
};

pub const value_zx_type_210_9e473f196db28165f17fa02012d877e38b20b2fdd7fbf0bd932a3b8513569fa0 = struct {
    cache: value_zx_type_209_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_210 = null,
};

pub const value_zx_type_211_03d90fa68e4e68b677112113e76ce3e9fb7563db5d750228bd60f891663f8e20 = struct {
    cache: value_zx_type_209_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    left: u64,
    right: u64,
    value: u64,
    zx_origin: ?*const zx_type_211 = null,
};

pub const value_zx_type_212_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_212 = null,
};

pub const value_zx_type_213_0e14e5cdabbe38cb1c79f91fab9c5efb4effe8af60678a6b3d272d5ab52e2387 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    references: []const bool,
    shell: zx_type_176,
    type_id: u32,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_213 = null,
};

pub const value_zx_type_214_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    action: zx_type_208,
    left: zx_type_176,
    right: zx_type_176,
    zx_origin: ?*const zx_type_214 = null,
};

pub const value_zx_type_215_ec908cc2db7bcb55b295ba38c99a7117d8d48d2fedde568fd60bfa6cb2ebc669 = struct {
    action: zx_type_208,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    left: u64,
    references: []const bool,
    right: u64,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_215 = null,
};

pub const value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    facts: []const u64,
    memo: []const u64,
    memo_count: []const u64,
    memo_first: []const u64,
    state_count: []const u64,
    state_first: []const u64,
    zx_origin: ?*const zx_type_218 = null,
};

pub const value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d = struct {
    facts: []const u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memo: []const u64,
    states: []const zx_type_176,
    trail: []const u64,
    zx_origin: ?*const zx_type_219 = null,
};

pub const value_zx_type_220_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf = struct {
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    snapshots: value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_220 = null,
};

pub const value_zx_type_221_c2b2345f31a3ca9410ec1d01298fd1e422f335f176ffd7a4e0451d112beced1a = struct {
    fact: u64,
    id: u64,
    layout: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    operation: zx_type_177,
    references: []const bool,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_221 = null,
};

pub const value_zx_type_222_a0405b3f3da574378c4599f54a1cf52b9531f3ff33aefbd053cbddcca68d591c = struct {
    layout: value_zx_type_183_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    program: value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    zx_origin: ?*const zx_type_222 = null,
};

pub const value_zx_type_224_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    action: zx_type_223,
    index: u64,
    moving: bool,
    subject: u64,
    zx_origin: ?*const zx_type_224 = null,
};

pub const value_zx_type_226_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    actions: []const zx_type_223,
    indices: []const u64,
    moving: []const bool,
    subjects: []const u64,
    zx_origin: ?*const zx_type_226 = null,
};

pub const value_zx_type_227_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    complete: bool,
    expression: u64,
    failed: bool,
    output: zx_type_176,
    stores_owned: bool,
    zx_origin: ?*const zx_type_227 = null,
};

pub const value_zx_type_228_9ca4da4ade6ce39392bcd565b92026186825f5515fba0d69864aa5bdd2c0c8c0 = struct {
    action: zx_type_217,
    frame: u64,
    layout: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    stack: value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_228 = null,
};

pub const value_zx_type_229_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    frame: u64,
    stack: value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_229 = null,
};

pub const value_zx_type_230_38e16b7ca832d5cab2cdd1573bdea3003d7c88255f2146bd1c658c5474aa0153 = struct {
    capture: zx_type_216,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    stack: value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_230 = null,
};

pub const value_zx_type_231_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53 = struct {
    frame: value_zx_type_224_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    work: value_zx_type_226_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_231 = null,
};

pub const value_zx_type_232_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: []const u64,
    first: []const u64,
    zx_origin: ?*const zx_type_232 = null,
};

pub const value_zx_type_233_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d = struct {
    boundaries: []const u64,
    count: []const u64,
    entries: []const u64,
    exits: []const u64,
    facts: []const u64,
    first: []const u64,
    heads: []const u64,
    outputs: []const u64,
    roots: []const u64,
    seen: []const bool,
    zx_origin: ?*const zx_type_233 = null,
};

pub const value_zx_type_235_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3 = struct {
    active: bool,
    builders: value_zx_type_232_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    complete: bool,
    domains: value_zx_type_175_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    expression: u64,
    failed: bool,
    layout: value_zx_type_183_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    loops: value_zx_type_233_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    program: value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    returned: zx_type_176,
    returns: []const bool,
    snapshots: value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    stores_owned: bool,
    value: u64,
    values: []const u64,
    work: value_zx_type_226_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_235 = null,
};

pub const value_zx_type_236_a338d1ab71f88877331d772f98bd14da65b1786b2be70c874f8b7e12b86f2f1f = struct {
    frame: u64,
    layout: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    merge: bool,
    references: []const bool,
    stack: value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_236 = null,
};

pub const value_zx_type_237_c24243ffcb91606794657c93d9112ec4c334bd9de6c46889f83dc67ca369b0a0 = struct {
    index: u64,
    loops: value_zx_type_233_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_237 = null,
};

pub const value_zx_type_238_e0ee3b7694a94ee6184c97b78a601ea953f2ec41d003a59e2d2c20bd608416ca = struct {
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_233_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_238 = null,
};

pub const value_zx_type_239_3d04dd43b3d06a3225ea47bfd43abc7af1e40baf278abd1b107975826d4f1dbb = struct {
    condition: bool,
    expression: u64,
    index: u64,
    machine: value_zx_type_235_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3,
    value: u64,
    zx_origin: ?*const zx_type_239 = null,
};

pub const value_zx_type_240_240efbbbf7810640b6fc01ce36bdc99bfbeb5720a9917ff0491c9572a913a019 = struct {
    boundary: u64,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    snapshots: value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    work: value_zx_type_226_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_240 = null,
};

pub const value_zx_type_241_4d3f012ce1af010aa08025827bda50d8f143763669bc2e4b561dcc5658f0bb6a = struct {
    changed: bool,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_233_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_241 = null,
};

pub const value_zx_type_242_9ea6e119697e5089b2d71b0128c4d91826c989da87b1481dc0d5f340ecdd8edd = struct {
    domains: value_zx_type_175_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    exiting: bool,
    expression: u64,
    index: u64,
    layout: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_233_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    snapshots: value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_242 = null,
};

pub const value_zx_type_243_889643ab829a1c5bfcc90b79c286ed0a794313db5ea714f0972ac74b5720a859 = struct {
    domains: value_zx_type_175_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    entry: u64,
    expression: u64,
    layout: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_233_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    program: value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    value: u64,
    zx_origin: ?*const zx_type_243 = null,
};

pub const value_zx_type_246_4158841c74e882000927bc9fb2cfef48d50f106f07c7898967375498c5ede5cb = struct {
    active: bool,
    cursors: []const u64,
    expression: u64,
    expressions: *const zx_type_42,
    facts: []const u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    layout: value_zx_type_183_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    permanent: bool,
    phase: zx_type_245,
    position: u64,
    query: u64,
    references: []const bool,
    root: u64,
    states: []const zx_type_176,
    trail: []const u64,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    work: []const u64,
    zx_origin: ?*const zx_type_246 = null,
};

pub const value_zx_type_247_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expression: u64,
    expressions: *const zx_type_42,
    index: u64,
    permanent: bool,
    zx_origin: ?*const zx_type_247 = null,
};

pub const value_zx_type_248_0d6d611f2caeee490761bbb5ea443b6881e3d712a7de202a9d02b0df984686e1 = struct {
    expression: u64,
    expressions: *const zx_type_42,
    layout: value_zx_type_183_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    permanent: bool,
    references: []const bool,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_248 = null,
};

pub const value_zx_type_249_ba054a92466517afadfa71eb48b1a69236032a9b3b84f6ef89ed7b3a38acc13a = struct {
    expression: u64,
    expressions: *const zx_type_42,
    layout: value_zx_type_183_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_249 = null,
};

pub const value_zx_type_250_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    position: u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_250 = null,
};

pub const value_zx_type_251_7498e4f806a7d6cb548387280423a75175fc5b80ec06eb4213ab0655a938538d = struct {
    current: zx_type_176,
    moving: bool,
    position: u64,
    symbols: *const zx_type_45,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_251 = null,
};

pub const value_zx_type_252_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    assign: bool,
    assigned: zx_type_176,
    failed: bool,
    value: zx_type_176,
    zx_origin: ?*const zx_type_252 = null,
};

pub const value_zx_type_253_548d03a1c937aa175a4ae6dc65848134fd43039f0f2deb8397102cde1a357280 = struct {
    builders: value_zx_type_232_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    count: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_253 = null,
};

pub const value_zx_type_254_9b2f070bd0a5a2314312b35bc5cd00be816db0248310d896c611be777eb24dfc = struct {
    builders: value_zx_type_232_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_254 = null,
};

pub const value_zx_type_256_3d9243068d042715091b3bc26eced84b2276542fa4ce6ed7c77bd25c76818046 = struct {
    container: bool,
    frame: value_zx_type_224_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    kind: zx_type_27,
    machine: value_zx_type_235_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3,
    payload: u64,
    zx_origin: ?*const zx_type_256 = null,
};

pub const value_zx_type_257_190073c195a96e0748b52805b1cbcc6366d97081df0f6eda8af2362d81577f30 = struct {
    builders: value_zx_type_232_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    type_id: u32,
    zx_origin: ?*const zx_type_257 = null,
};

pub const value_zx_type_258_548d03a1c937aa175a4ae6dc65848134fd43039f0f2deb8397102cde1a357280 = struct {
    builders: value_zx_type_232_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    fact: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_258 = null,
};

pub const value_zx_type_259_9c68fc8229a3cb9544086ee9d74623a5845e02f8d7b0c7e22830b51be4e668ef = struct {
    domains: value_zx_type_175_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    layout: value_zx_type_183_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    program: value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    returns: []const bool,
    runtime: value_zx_type_220_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf,
    zx_origin: ?*const zx_type_259 = null,
};

pub const value_zx_type_260_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603 = struct {
    declared: zx_type_43,
    outcome: value_zx_type_227_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_260 = null,
};

pub const value_zx_type_261_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d = struct {
    context: value_zx_type_74_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e,
    index: u64,
    zx_origin: ?*const zx_type_261 = null,
};

pub const value_zx_type_262_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922 = struct {
    functions: value_zx_type_71_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    index: u64,
    zx_origin: ?*const zx_type_262 = null,
};

pub const value_zx_type_263_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct {
    fallible: bool,
    members: ?[]const []const u8,
    zx_origin: ?*const zx_type_263 = null,
};

pub const value_zx_type_264_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06 = struct {
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_264 = null,
};

pub const value_zx_type_265_e1a3efb1661a55082d96026e298239963014feef940e12b8f12b12b89508e175 = struct {
    functions: value_zx_type_71_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_265 = null,
};

pub const value_zx_type_266_f47a528fe3999e4825e51b818f48ae0051b6bc27266259ed0b6b499f41ce5434 = struct {
    context: value_zx_type_106_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea,
    name: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_266 = null,
};

pub const value_zx_type_267_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    binding_names: []const []const u8,
    binding_types: []const u32,
    depth: u64,
    names: []const ?[]const u8,
    table: *const zx_type_19,
    type_id: u32,
    zx_origin: ?*const zx_type_267 = null,
};

pub const value_zx_type_269_bd5cde306a9184c1dd5f19d89241557a288445ac299b32af3954003bd39dc874 = struct {
    name: ?[]const u8,
    names: []const []const u8,
    required: bool,
    type_id: u32,
    types: []const u32,
    zx_origin: ?*const zx_type_269 = null,
};

pub const value_zx_type_270_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731 = struct {
    contracts: []const *const zx_type_50,
    control: []const *const zx_type_53,
    expressions: []const *const zx_type_42,
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_fallible: []const bool,
    native_modules: []const ?u32,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_43,
    roots: []const ?u32,
    stores: []const *const zx_type_62,
    zx_origin: ?*const zx_type_270 = null,
};

pub const value_zx_type_275_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b = struct {
    functions: value_zx_type_270_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_275 = null,
};

pub const value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290 = struct {
    called: *const zx_type_271,
    context: value_zx_type_275_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b,
    frames: []const *const zx_type_273,
    names: []const []const u8,
    sources: []const *const zx_type_274,
    unknown: bool,
    zx_origin: ?*const zx_type_278 = null,
};

pub const value_zx_type_279_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea = struct {
    context: value_zx_type_275_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b,
    contracts: *const zx_type_50,
    control: *const zx_type_53,
    expression: u32,
    expressions: *const zx_type_42,
    program: bool,
    root: ?u32,
    stores: bool,
    zx_origin: ?*const zx_type_279 = null,
};

pub const value_zx_type_280_5821a6631fd0a2b5d5f68275f533e0b86f2430edbf1471339d13b94e742690d5 = struct {
    control: *const zx_type_53,
    expressions: *const zx_type_42,
    state: value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_280 = null,
};

pub const value_zx_type_281_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    source: u64,
    state: value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_281 = null,
};

pub const value_zx_type_282_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    contracts: *const zx_type_50,
    state: value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_282 = null,
};

pub const value_zx_type_283_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    frame: *const zx_type_273,
    state: value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_283 = null,
};

pub const value_zx_type_284_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    seen: *const zx_type_271,
    zx_origin: ?*const zx_type_284 = null,
};

pub const value_zx_type_285_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    fresh: bool,
    seen: *const zx_type_271,
    zx_origin: ?*const zx_type_285 = null,
};

pub const value_zx_type_286_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expressions: *const zx_type_42,
    index: u64,
    zx_origin: ?*const zx_type_286 = null,
};

pub const value_zx_type_287_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    names: []const []const u8,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    type_id: u32,
    zx_origin: ?*const zx_type_287 = null,
};

pub const value_zx_type_288_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    expressions: *const zx_type_42,
    index: u64,
    names: []const []const u8,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_288 = null,
};

pub const value_zx_type_289_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    index: u64,
    state: value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_289 = null,
};

pub const value_zx_type_290_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    identity: []const u8,
    stores: []const *const zx_type_62,
    type_id: u32,
    zx_origin: ?*const zx_type_290 = null,
};

pub const value_zx_type_291_a0feea08302b6219ebdf27f7701bf5c06f5d2870468ab6fb9c77eac395ef840a = struct {
    graph: value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638,
    index: u64,
    zx_origin: ?*const zx_type_291 = null,
};

pub const value_zx_type_292_f1df282d6e484b7127898a03b5f590e15df63b6ee6d22af1df6699f4f325bd16 = struct {
    count: u64,
    function_id: ?u32,
    functions: value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8,
    ids: []const u32,
    names: []const []const u8,
    zx_origin: ?*const zx_type_292 = null,
};

pub const value_zx_type_293_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    instance: []const u8,
    value: []const u8,
    zx_origin: ?*const zx_type_293 = null,
};

pub const value_zx_type_294_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0 = struct {
    instance: []const u8,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    value: []const u8,
    zx_origin: ?*const zx_type_294 = null,
};

pub const value_zx_type_295_0409e489687dab5e722cf1f8c25f35a783581c270ff2f42a3f0a46342247d9ff = struct {
    instance: []const u8,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_295 = null,
};

pub const value_zx_type_296_a5f957dcc1eb48c009581bc18274d6ff18510deb427b7a3469fa032db39dc942 = struct {
    base: *const zx_type_19,
    base_origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    first: u64,
    origin_indices: []const u64,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    source: *const zx_type_19,
    zx_origin: ?*const zx_type_296 = null,
};

pub const value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = struct {
    delta: *const zx_type_19,
    mapping: []const u32,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    references: []const u32,
    status: u64,
    zx_origin: ?*const zx_type_297 = null,
};

pub const value_zx_type_298_678517bea1354ebf2792ee61e35792b8e11faf1d9c912fe6172420b5a8d9dc45 = struct {
    request: value_zx_type_296_a5f957dcc1eb48c009581bc18274d6ff18510deb427b7a3469fa032db39dc942,
    state: value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87,
    zx_origin: ?*const zx_type_298 = null,
};

pub const value_zx_type_299_6910f7d9dba2c694d06ffd684becdcaa9d2348be1866381b49b73a4a1c30ef9e = struct {
    base: *const zx_type_19,
    base_origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    source: *const zx_type_19,
    zx_origin: ?*const zx_type_299 = null,
};

pub const value_zx_type_300_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = struct {
    names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    source: *const zx_type_19,
    zx_origin: ?*const zx_type_300 = null,
};

pub const value_zx_type_301_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    indices: []const u64,
    valid: bool,
    zx_origin: ?*const zx_type_301 = null,
};

pub const value_zx_type_302_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    first: u64,
    source: *const zx_type_19,
    target: *const zx_type_19,
    zx_origin: ?*const zx_type_302 = null,
};

pub const value_zx_type_303_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d = struct {
    children: []const u32,
    count: u64,
    field_names: []const []const u8,
    field_types: []const u32,
    first: u32,
    kind: zx_type_18,
    label: []const u8,
    names: []const []const u8,
    offset: u64,
    second: u32,
    zx_origin: ?*const zx_type_303 = null,
};

pub const value_zx_type_304_6f975b180818098029dbaef75bb89bfea5e3cb89ee69a1d9370d1963760c4a33 = struct {
    left: value_zx_type_303_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    right: value_zx_type_303_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_304 = null,
};

pub const value_zx_type_305_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u64,
    table: *const zx_type_19,
    zx_origin: ?*const zx_type_305 = null,
};

pub const value_zx_type_306_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    first: u64,
    mapping: []const u32,
    zx_origin: ?*const zx_type_306 = null,
};

pub const value_zx_type_307_655f2c15f8b96113ed59dee46636710e0c7433f1f71d56fc2c400bda5a955e85 = struct {
    candidate: value_zx_type_109_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    delta: *const zx_type_19,
    zx_origin: ?*const zx_type_307 = null,
};

pub const value_zx_type_308_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    references: []const u32,
    source: *const zx_type_19,
    zx_origin: ?*const zx_type_308 = null,
};

pub const value_zx_type_310_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    status: zx_type_309,
    zx_origin: ?*const zx_type_310 = null,
};

pub const value_zx_type_311_2c4a87f781c651962259ae1ef67d878ae312a61c3d14b66307e5fd0a9c7f1e1e = struct {
    candidate: value_zx_type_109_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    id: u32,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_311 = null,
};

pub const value_zx_type_312_57bd08a78bda4971daa7f20aaeb00603dcff27862b3de41335ca02b25ff5c6ff = struct {
    candidate: value_zx_type_109_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_16_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_312 = null,
};

pub const value_zx_type_313_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39 = struct {
    bindings: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    id: u32,
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_313 = null,
};

pub const value_zx_type_314_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    mapping: []const u32,
    references: []const u32,
    source: *const zx_type_19,
    zx_origin: ?*const zx_type_314 = null,
};

pub const value_zx_type_315_f9f434bc9d0869ee4fe93b8f2d75449d97ec21cc1ea12455f1df810be7821e22 = struct {
    candidate: value_zx_type_109_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_315 = null,
};

pub const value_zx_type_316_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    added: u64,
    existing: u64,
    maximum: u64,
    zx_origin: ?*const zx_type_316 = null,
};

pub const value_zx_type_327_f0efbe3095313e389200ce15211d85a75831f6f84ebaa79a40337d64d6e07e5b = struct {
    identity: ?[]const u8,
    ids: []const u32,
    import_name: []const u8,
    names: []const []const u8,
    namespace: []const []const u8,
    specifier: []const u8,
    zx_origin: ?*const zx_type_327 = null,
};

pub const value_zx_type_328_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06 = struct {
    delta: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    mapping: []const u32,
    status: u64,
    zx_origin: ?*const zx_type_328 = null,
};

pub const value_zx_type_329_29893f6f53029cf43ba7d28c81482ffa31e6253e7dabd8c86cbb9a48e17f2cc0 = struct {
    base: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    instance: []const u8,
    maximum: u64,
    source: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: []const u32,
    zx_origin: ?*const zx_type_329 = null,
};

pub const value_zx_type_330_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    index: u64,
    instance: []const u8,
    source: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_330 = null,
};

pub const value_zx_type_331_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    mapping: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_331 = null,
};

pub const value_zx_type_332_92c03528dac9c9a4fba9a5d4d3791bbf3267de67e01eac0301b60af51e378eec = struct {
    index: u64,
    table: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    value: value_zx_type_327_f0efbe3095313e389200ce15211d85a75831f6f84ebaa79a40337d64d6e07e5b,
    zx_origin: ?*const zx_type_332 = null,
};

pub const value_zx_type_333_d0f7d36a9cc2a52317c02f5e80b541a5a03a4dabfe4b1b85b100c04f570321d7 = struct {
    base: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    maximum: u64,
    state: value_zx_type_328_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06,
    value: value_zx_type_327_f0efbe3095313e389200ce15211d85a75831f6f84ebaa79a40337d64d6e07e5b,
    zx_origin: ?*const zx_type_333 = null,
};

pub const value_zx_type_334_70c5b3c2f45727ed8f61774b74c8f3909d313beac38427e976c16f634d41af66 = struct {
    first: u64,
    instance: []const u8,
    natives: []const u32,
    source: value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8,
    types: []const u32,
    zx_origin: ?*const zx_type_334 = null,
};

pub const value_zx_type_335_b11dab29b7180035e938e3ea70649f2e4e32fcf3233ac142ecc9a29288c88935 = struct {
    contracts: *const zx_type_50,
    expressions: *const zx_type_42,
    file: []const u8,
    input_type: u32,
    native_module: ?u32,
    output_type: u32,
    stores: *const zx_type_62,
    symbols: *const zx_type_45,
    zx_origin: ?*const zx_type_335 = null,
};

pub const value_zx_type_336_d7a5c10f2ea918f9a61d8c31039ae40be7d5d60da8788d94789121a2791040a5 = struct {
    index: u64,
    request: value_zx_type_334_70c5b3c2f45727ed8f61774b74c8f3909d313beac38427e976c16f634d41af66,
    zx_origin: ?*const zx_type_336 = null,
};

pub const value_zx_type_337_c8ef79bf4d3b91a2c9b2f614591933f932c897963dd6c705cc8aca7b6f3d3660 = struct {
    file: []const u8,
    input_type: u32,
    native_module: ?u32,
    output_type: u32,
    zx_origin: ?*const zx_type_337 = null,
};

pub const value_zx_type_338_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    mapping: []const u32,
    source: *const zx_type_45,
    zx_origin: ?*const zx_type_338 = null,
};

pub const value_zx_type_339_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    first: u64,
    mapping: []const u32,
    source: *const zx_type_42,
    zx_origin: ?*const zx_type_339 = null,
};

pub const value_zx_type_340_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    first: u64,
    mapping: []const u32,
    source: *const zx_type_50,
    zx_origin: ?*const zx_type_340 = null,
};

pub const value_zx_type_341_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    instance: []const u8,
    mapping: []const u32,
    source: *const zx_type_62,
    zx_origin: ?*const zx_type_341 = null,
};

pub const value_zx_type_342_b5269a6450d9595cda619b08591a67cbaae315944227d0713dbdbc8349c83527 = struct {
    first: u64,
    instance: []const u8,
    mapping: []const u32,
    source: value_zx_type_77_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_342 = null,
};

pub const value_zx_type_343_5c55ea113028a923cd7b60993d0cbd0ca61f6c42ff9efed54c09fd78195978c4 = struct {
    first: u64,
    instance: []const u8,
    source: value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_343 = null,
};

pub const value_zx_type_344_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    base: *const zx_type_19,
    delta: *const zx_type_19,
    existing_count: u64,
    zx_origin: ?*const zx_type_344 = null,
};

pub const value_zx_type_345_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268 = struct {
    body: value_zx_type_72_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80,
    max_offset: u64,
    zx_origin: ?*const zx_type_345 = null,
};

pub const value_zx_type_346_3403bced3238582f4651b52b5d76688e0dab464cb25a410da69862695487fda5 = struct {
    max_offset: u64,
    unit: value_zx_type_75_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5,
    zx_origin: ?*const zx_type_346 = null,
};

pub const value_zx_type_347_56513ec0a3f7b0e8fe4c027e5a3dc9f234c7819d1970f29b9e830566c787d458 = struct {
    concurrent: bool,
    enabled: bool,
    functions: value_zx_type_131_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_347 = null,
};

pub const value_zx_type_348_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a = struct {
    domains: value_zx_type_175_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    layout: value_zx_type_183_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    references: []const bool,
    returns: []const bool,
    zx_origin: ?*const zx_type_348 = null,
};

pub const value_zx_type_349_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134 = struct {
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    prepared: value_zx_type_348_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a,
    snapshots: value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_349 = null,
};

pub const value_zx_type_351_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = struct {
    first: u64,
    names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    source: *const zx_type_19,
    target: *const zx_type_19,
    zx_origin: ?*const zx_type_351 = null,
};

pub const value_zx_type_352_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expressions: *const zx_type_42,
    symbols: *const zx_type_45,
    zx_origin: ?*const zx_type_352 = null,
};

pub const value_zx_type_353_c5016fbf4205dbc5f597fe1330a86f71507a94ff71fcb2b9f6ace510ea97fc21 = struct {
    base: *const zx_type_19,
    input: value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed,
    merged: value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87,
    native: value_zx_type_328_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06,
    zx_origin: ?*const zx_type_353 = null,
};

pub const value_zx_type_354_1bbe09255aa6b306aefd24431848a653babc04a6ae28e570e263af2eea88c2e1 = struct {
    destination: value_zx_type_80_568cf0b95c6523ecc986c6032ffd9fea08a5f5091afc3b1382361c635503b72f,
    seed: bool,
    zx_origin: ?*const zx_type_354 = null,
};

pub const value_zx_type_355_0ed01b68f4c141e7bd395d473f85a378b16da06108cedbad8097f62049757281 = struct {
    index: u64,
    request: value_zx_type_329_29893f6f53029cf43ba7d28c81482ffa31e6253e7dabd8c86cbb9a48e17f2cc0,
    state: value_zx_type_328_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06,
    zx_origin: ?*const zx_type_355 = null,
};

pub const value_zx_type_356_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: *const zx_type_42,
    first: u64,
    mapping: []const u32,
    symbols: *const zx_type_45,
    zx_origin: ?*const zx_type_356 = null,
};

pub const value_zx_type_357_86fe3af64a4fc82484b11d86fdfb9b3c31ed1030b6b1103b69296f1bbd952e94 = struct {
    count: u64,
    index: u64,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    valid: bool,
    zx_origin: ?*const zx_type_357 = null,
};

pub const value_zx_type_358_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87 = struct {
    index: u64,
    names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    previous: u64,
    unique: bool,
    zx_origin: ?*const zx_type_358 = null,
};

pub const value_zx_type_359_025f48c4857bfffa7b37d9c120e29a33704982d2f2684791d2d41fe995906439 = struct {
    count: u64,
    index: u64,
    names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    table: *const zx_type_19,
    valid: bool,
    zx_origin: ?*const zx_type_359 = null,
};

pub const value_zx_type_360_0c9e8fa14944db2f61b959828430a1da5dc8fa69fcb2715d464e558712ea3972 = struct { value_zx_type_25_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb, ?*const zx_type_360, };

pub const value_zx_type_361_bfaac0f26d84f5d4943ac6e7457f982f2643cd2785dc100455f8c6122324104c = struct { value_zx_type_25_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb, bool, ?*const zx_type_361, };

pub const value_zx_type_362_8f0105a13460d9d80dd5b91d8ce481c37b89c0f88104eeab7d2703780fa7206e = struct { value_zx_type_25_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb, bool, bool, ?*const zx_type_362, };

pub const value_zx_type_363_de69536f94c9aa0d9a400789a7ae1b462a4c0b38fe31a99d9fe0f76e10444788 = struct { value_zx_type_354_1bbe09255aa6b306aefd24431848a653babc04a6ae28e570e263af2eea88c2e1, ?*const zx_type_363, };

pub const value_zx_type_364_346ed1a8dacdd6812dd9f3f91f0736375708a2c7e948d285a04415ecf68a2947 = struct { value_zx_type_354_1bbe09255aa6b306aefd24431848a653babc04a6ae28e570e263af2eea88c2e1, bool, ?*const zx_type_364, };

pub const value_zx_type_365_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    high: u8,
    index: u64,
    low: u8,
    remaining: u64,
    text: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_365 = null,
};

pub const value_zx_type_366_bcdb98c2112c7ef8c38aec6ac62cd8a1517a99f368050adc47ee5c23b76f23a2 = struct {
    index: u64,
    table: value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8,
    valid: bool,
    zx_origin: ?*const zx_type_366 = null,
};

pub const value_zx_type_367_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    child_end: u64,
    field_end: u64,
    index: u64,
    name_end: u64,
    scalar_count: u64,
    table: *const zx_type_19,
    valid: bool,
    zx_origin: ?*const zx_type_367 = null,
};

pub const value_zx_type_368_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    after_underscore: bool,
    index: u64,
    kind: zx_type_84,
    name: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_368 = null,
};

pub const value_zx_type_369_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    ascending: bool,
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_369 = null,
};

pub const value_zx_type_370_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    owner: u64,
    table: *const zx_type_19,
    valid: bool,
    values: []const u32,
    zx_origin: ?*const zx_type_370 = null,
};

pub const value_zx_type_371_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    errors: bool,
    first: u64,
    index: u64,
    valid: bool,
    values: []const []const u8,
    zx_origin: ?*const zx_type_371 = null,
};

pub const value_zx_type_372_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    first: u64,
    index: u64,
    member: []const u8,
    unique: bool,
    values: []const []const u8,
    zx_origin: ?*const zx_type_372 = null,
};

pub const value_zx_type_373_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_19,
    valid: bool,
    zx_origin: ?*const zx_type_373 = null,
};

pub const value_zx_type_374_49129128bed2eab4847d5108d0ed3c4d32810f9cdd95b1d04dcc61383544ee70 = struct { value_zx_type_83_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_374, };

pub const value_zx_type_375_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct { value_zx_type_83_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, bool, ?*const zx_type_375, };

pub const value_zx_type_376_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct { value_zx_type_83_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, bool, bool, ?*const zx_type_376, };

pub const value_zx_type_377_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    index: u64,
    input: value_zx_type_91_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    valid: bool,
    zx_origin: ?*const zx_type_377 = null,
};

pub const value_zx_type_378_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    index: u64,
    input: value_zx_type_95_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    next: u64,
    valid: bool,
    zx_origin: ?*const zx_type_378 = null,
};

pub const value_zx_type_379_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    block: u64,
    control: *const zx_type_53,
    end: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_379 = null,
};

pub const value_zx_type_380_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    block: u64,
    bodies: []const u32,
    end: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_380 = null,
};

pub const value_zx_type_381_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d = struct {
    branches: u64,
    constants: u64,
    control: *const zx_type_53,
    destructures: u64,
    evaluations: u64,
    index: u64,
    parallels: u64,
    results: u64,
    selections: u64,
    setters: u64,
    valid: bool,
    zx_origin: ?*const zx_type_381 = null,
};

pub const value_zx_type_382_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    block: u64,
    control: *const zx_type_53,
    valid: bool,
    zx_origin: ?*const zx_type_382 = null,
};

pub const value_zx_type_383_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    depths: []const u64,
    owned: []const bool,
    root: u64,
    zx_origin: ?*const zx_type_383 = null,
};

pub const value_zx_type_384_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, void, ?*const zx_type_384, };

pub const value_zx_type_385_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_385, };

pub const value_zx_type_386_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    block: u64,
    control: *const zx_type_53,
    depths: []const u64,
    edge: u64,
    index: u64,
    owned: []const bool,
    valid: bool,
    zx_origin: ?*const zx_type_386 = null,
};

pub const value_zx_type_387_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: bool,
    source: []const bool,
    zx_origin: ?*const zx_type_387 = null,
};

pub const value_zx_type_388_747f72635b917529c60fe3ddd4b139add9d19e47868d0437d3b1eaa0e5a06cbe = struct { value_zx_type_345_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, ?*const zx_type_388, };

pub const value_zx_type_389_9fa353a13aef4fcbd68e9e65c345217702e70a477c2e8b34bab582e5f919b0ab = struct { value_zx_type_345_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, bool, ?*const zx_type_389, };

pub const value_zx_type_390_5f210d33b8c76198cb39e577e40573158f40124c771140f4877c3fb884267c96 = struct { value_zx_type_345_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, bool, bool, ?*const zx_type_390, };

pub const value_zx_type_391_cdb50b0313c74b116f115cfa35a04b06b60d43ce9f1153dc7dfaea33e5997abb = struct { value_zx_type_345_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, bool, bool, bool, ?*const zx_type_391, };

pub const value_zx_type_392_e076203cc44cd5b3cd45d256176e9fc34055f2ae1a060fa3e29d9588d8f4ce7d = struct { value_zx_type_345_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, bool, bool, bool, bool, ?*const zx_type_392, };

pub const value_zx_type_393_637585634439c917a0fd688f9e35fe14f1c43532b907c828e3a10b2df0602216 = struct { value_zx_type_345_ec633dedc57f8eaf1a851081caadaff49c1dc4dfe370c323bf28cb82cd2e0268, bool, bool, bool, bool, bool, ?*const zx_type_393, };

pub const value_zx_type_394_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    index: u64,
    input: value_zx_type_99_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    valid: bool,
    zx_origin: ?*const zx_type_394 = null,
};

pub const value_zx_type_395_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    index: u64,
    input: value_zx_type_100_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    valid: bool,
    zx_origin: ?*const zx_type_395 = null,
};

pub const value_zx_type_396_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    contracts: *const zx_type_50,
    index: u64,
    max_offset: u64,
    valid: bool,
    zx_origin: ?*const zx_type_396 = null,
};

pub const value_zx_type_397_ed98ab2d684155f0f16edf3c906e8b7cce9beb0c415885713abde878f5ffabc6 = struct { value_zx_type_101_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, ?*const zx_type_397, };

pub const value_zx_type_398_758dce47268ce260391b79fcce19430100f29f81aa06dca556ac6c937c9b34ac = struct { value_zx_type_101_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, bool, ?*const zx_type_398, };

pub const value_zx_type_399_b987e2a8336dd5fe5154834b3b39be96d75a9414e18010c03cead626fdd2ff2d = struct { value_zx_type_346_3403bced3238582f4651b52b5d76688e0dab464cb25a410da69862695487fda5, ?*const zx_type_399, };

pub const value_zx_type_400_c477267367d27377853d9ec182fe65dcbbfffab8a243ed9c9f1d1562cb3522f2 = struct { value_zx_type_346_3403bced3238582f4651b52b5d76688e0dab464cb25a410da69862695487fda5, bool, ?*const zx_type_400, };

pub const value_zx_type_401_aeadd0682a50b343e99877ebd4af36830054f6a607a8d6606bbe41c64764a2cf = struct { value_zx_type_346_3403bced3238582f4651b52b5d76688e0dab464cb25a410da69862695487fda5, bool, bool, ?*const zx_type_401, };

pub const value_zx_type_402_2005be18f3f738830a7095b8f8338aa4032ca575f11fcda5d9048025bf5b4906 = struct {
    context: value_zx_type_74_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_402 = null,
};

pub const value_zx_type_403_264b57f9398a8c89b636a6199fb1a45d5519286c3c0ab2e406e46725ab40cb1a = struct { value_zx_type_76_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, ?*const zx_type_403, };

pub const value_zx_type_404_e293f9444885f043aac5ffd18424308b3341a05faa07ca25362527b432f43c42 = struct { value_zx_type_76_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, bool, ?*const zx_type_404, };

pub const value_zx_type_405_754e542ded2d437ac5b84a31ee26e4809bd90d9d5604a44a42444a4627a2c061 = struct { value_zx_type_76_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, bool, bool, ?*const zx_type_405, };

pub const value_zx_type_406_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0 = struct {
    index: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    valid: bool,
    zx_origin: ?*const zx_type_406 = null,
};

pub const value_zx_type_407_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    offset: u64,
    separator: u64,
    source: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_407 = null,
};

pub const value_zx_type_408_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    offset: u64,
    source: []const u8,
    start: u64,
    valid: bool,
    zx_origin: ?*const zx_type_408 = null,
};

pub const value_zx_type_409_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    names: []const []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_409 = null,
};

pub const value_zx_type_410_b1b23fbb7680b8cb1b3dadbfa986aa274ef1483cb6efee44a47ca580481a8e23 = struct {
    count: u64,
    found: bool,
    index: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_410 = null,
};

pub const value_zx_type_411_efdd75a5e607c61dffb07c66411d75c96f1f2b811307e711dcc2093faf9ae2b2 = struct { value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, ?*const zx_type_411, };

pub const value_zx_type_412_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct { value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, ?*const zx_type_412, };

pub const value_zx_type_413_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06 = struct { value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, bool, ?*const zx_type_413, };

pub const value_zx_type_414_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8 = struct { value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, bool, bool, ?*const zx_type_414, };

pub const value_zx_type_415_461a038225996c015433bf0a5fb2c9e6a36f43e598f85eccd7a2eee1e984e893 = struct {
    index: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    type_count: u64,
    valid: bool,
    zx_origin: ?*const zx_type_415 = null,
};

pub const value_zx_type_416_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    ids: []const u32,
    index: u64,
    names: []const []const u8,
    type_count: u64,
    valid: bool,
    zx_origin: ?*const zx_type_416 = null,
};

pub const value_zx_type_417_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_417 = null,
};

pub const value_zx_type_418_df87d4e4c94482fd017e977a114eba826861ac6af356c343aea16855cac7c373 = struct {
    index: u64,
    module: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    owner: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_418 = null,
};

pub const value_zx_type_419_ea1b7ae541093ece52c59f2de2f23eb593426bae77184c88543e9788bf3186e6 = struct {
    count: u64,
    index: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: []const u8,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_419 = null,
};

pub const value_zx_type_420_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_420 = null,
};

pub const value_zx_type_421_4bb438ff01f237569bb9646dc2578b71e2a1e16fa8fe9e4b0b9d926ac5640cd1 = struct { value_zx_type_105_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, ?*const zx_type_421, };

pub const value_zx_type_422_80fa3f09fde2ea8660c1d43e969ee3d68c4cda0e85a50de87ab5f1fb43c5c390 = struct { value_zx_type_105_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, ?*const zx_type_422, };

pub const value_zx_type_423_ee123d0c630fe117230fb019f7a85eb490b50840dfc1899f8c57c79c91c3899f = struct { value_zx_type_105_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, bool, ?*const zx_type_423, };

pub const value_zx_type_424_0e0d5c43ce78ae1236d49a3faeba388d032732faba89517792623bca4c309c09 = struct { value_zx_type_105_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, bool, bool, ?*const zx_type_424, };

pub const value_zx_type_425_39550f691687970b5dbfe4b46111ad44602515eab5c342208f2139f13ca4b8cf = struct {
    declared: bool,
    index: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: ?[]const u8,
    type_id: u64,
    valid: bool,
    zx_origin: ?*const zx_type_425 = null,
};

pub const value_zx_type_426_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    declared: bool,
    found: bool,
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u64,
    zx_origin: ?*const zx_type_426 = null,
};

pub const value_zx_type_427_ee123d0c630fe117230fb019f7a85eb490b50840dfc1899f8c57c79c91c3899f = struct {
    context: value_zx_type_105_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_427 = null,
};

pub const value_zx_type_428_d96b64d9a0cdeb5c4d9519515e9692cefd4e8b6e0fd3a4acd43c7a6cb54deb90 = struct { value_zx_type_105_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, bool, bool, bool, ?*const zx_type_428, };

pub const value_zx_type_429_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
    zx_origin: ?*const zx_type_429 = null,
};

pub const value_zx_type_430_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    target: zx_type_18,
    zx_origin: ?*const zx_type_430 = null,
};

pub const value_zx_type_431_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_431 = null,
};

pub const value_zx_type_432_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    limit: u64,
    path: []const u8,
    paths: []const []const u8,
    repeated: bool,
    zx_origin: ?*const zx_type_432 = null,
};

pub const value_zx_type_433_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_433 = null,
};

pub const value_zx_type_434_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    paths: []const []const u8,
    slot_types: []const u32,
    table: *const zx_type_19,
    valid: bool,
    zx_origin: ?*const zx_type_434 = null,
};

pub const value_zx_type_435_009b209c29dfed37d6f0ddf10651eb819801430299ea03fd6bf9a11471606d6e = struct { value_zx_type_116_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, ?*const zx_type_435, };

pub const value_zx_type_436_9068dcb27588fc549cd15008d3bd15e507480c6631115fd15614e1d02077b29f = struct { value_zx_type_116_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, bool, ?*const zx_type_436, };

pub const value_zx_type_437_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    available: *const zx_type_62,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_62,
    slots: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_437 = null,
};

pub const value_zx_type_438_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
    zx_origin: ?*const zx_type_438 = null,
};

pub const value_zx_type_439_c6f082592747bfb97c58ad22751dc4616b503541b82be1a501dcd45ec633ad7a = struct {
    condition_type: u32,
    context: value_zx_type_120_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    first: u64,
    index: u64,
    result_type: u32,
    valid: bool,
    zx_origin: ?*const zx_type_439 = null,
};

pub const value_zx_type_440_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed = struct {
    context: value_zx_type_120_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_440 = null,
};

pub const value_zx_type_441_c65f606cad38c9bde5a22d060283f020c6df16f448945ff8555407599cee695f = struct {
    context: value_zx_type_120_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    first: u64,
    index: u64,
    type_first: u64,
    valid: bool,
    zx_origin: ?*const zx_type_441 = null,
};

pub const value_zx_type_442_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    field: u64,
    first: u64,
    found: bool,
    index: u64,
    indices: []const u32,
    limit: u64,
    zx_origin: ?*const zx_type_442 = null,
};

pub const value_zx_type_443_0226e38872eacdc3e44e606ef924db3a519c6f4fa1a6333f3794af990383ea77 = struct {
    context: value_zx_type_120_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_28,
    source: u32,
    valid: bool,
    zx_origin: ?*const zx_type_443 = null,
};

pub const value_zx_type_444_88d54f056223ef8ac2f93da2e10b59b5e31b44b0c33166e8b7201a394c231718 = struct {
    check: value_zx_type_121_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed,
    count: u64,
    fields: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_444 = null,
};

pub const value_zx_type_445_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077 = struct {
    field: ?u32,
    fields: []const ?u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    task: u32,
    tasks: []const u32,
    zx_origin: ?*const zx_type_445 = null,
};

pub const value_zx_type_446_f3a9fcf220984d9746551b1ea2c8c509f64c311c9dd8964488d8c18fdae2ce12 = struct {
    check: value_zx_type_121_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_446 = null,
};

pub const value_zx_type_447_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    captures: []const u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    symbol: u32,
    zx_origin: ?*const zx_type_447 = null,
};

pub const value_zx_type_448_0226e38872eacdc3e44e606ef924db3a519c6f4fa1a6333f3794af990383ea77 = struct {
    context: value_zx_type_120_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    context_type: u32,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_29,
    valid: bool,
    zx_origin: ?*const zx_type_448 = null,
};

pub const value_zx_type_449_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6 = struct {
    expressions: *const zx_type_42,
    functions: value_zx_type_119_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    stores: *const zx_type_62,
    symbols: *const zx_type_45,
    table: *const zx_type_19,
    valid: bool,
    zx_origin: ?*const zx_type_449 = null,
};

pub const value_zx_type_450_21e4f8ef344e503f822fcb829467993616ac72b250c11649bad4e903e93caa0c = struct {
    has_ensures: bool,
    index: u64,
    program: value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    valid: bool,
    zx_origin: ?*const zx_type_450 = null,
};

pub const value_zx_type_451_7695a4d364d66a6902b4af6ac6744d237e533b15944969bca7543d8f0ffc99af = struct { value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_451, };

pub const value_zx_type_452_b4c00b0680a164f9ad85cafef49c2f1d31566b1a676a14d85e4570178e088fb9 = struct { value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, bool, ?*const zx_type_452, };

pub const value_zx_type_453_79b96ffa2e891f4534c9a8b770935af0223aeb89cda66f40793025b64b74d946 = struct { value_zx_type_127_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, bool, bool, ?*const zx_type_453, };

pub const value_zx_type_454_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    index: u64,
    symbols: *const zx_type_45,
    valid: bool,
    zx_origin: ?*const zx_type_454 = null,
};

pub const value_zx_type_455_0c3c634be52883a604be7f6c9f533fa83ee9fcdc9d677f14a435e37a442cd739 = struct {
    index: u64,
    request: value_zx_type_117_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d,
    valid: bool,
    zx_origin: ?*const zx_type_455 = null,
};

pub const value_zx_type_456_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    all: bool,
    bodies: []const u32,
    end: u64,
    index: u64,
    returns: []const bool,
    zx_origin: ?*const zx_type_456 = null,
};

pub const value_zx_type_457_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    block: u64,
    control: *const zx_type_53,
    returns: []const bool,
    zx_origin: ?*const zx_type_457 = null,
};

pub const value_zx_type_458_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_42,
    index: u64,
    limit: u64,
    valid: bool,
    zx_origin: ?*const zx_type_458 = null,
};

pub const value_zx_type_459_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const bool,
    source: []const ?u32,
    zx_origin: ?*const zx_type_459 = null,
};

pub const value_zx_type_460_3a2d3372119d766901b9e73d1d1a1cb69e32e364aec8da316dab97f3e55fcf11 = struct {
    concurrent: bool,
    functions: value_zx_type_131_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    index: u64,
    values: []const bool,
    zx_origin: ?*const zx_type_460 = null,
};

pub const value_zx_type_461_ea224267afd93fd3f3d4000179ad152ebe9ec0b03599ef65b3732cadbbdff343 = struct { value_zx_type_347_56513ec0a3f7b0e8fe4c027e5a3dc9f234c7819d1970f29b9e830566c787d458, ?*const zx_type_461, };

pub const value_zx_type_462_ec65d43862fabc1ba3f66365439915d1135e981063a601844d880216f7595104 = struct { value_zx_type_347_56513ec0a3f7b0e8fe4c027e5a3dc9f234c7819d1970f29b9e830566c787d458, []const bool, ?*const zx_type_462, };

pub const value_zx_type_463_46c5d60b64cf56cb771da46a6165931fb8fa4e77cc44efffaceea6431db220d7 = struct { value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, ?*const zx_type_463, };

pub const value_zx_type_464_3b09208d71e6eced43b0d3100ffc3c9ef0100a82597dbbcaeaf6c94ce042306b = struct { value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, []const bool, ?*const zx_type_464, };

pub const value_zx_type_465_75ff338b263cfa5d9d312b9a70bf4ae14f153dc381571b5760f3c5b8b914ebf9 = struct { value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, []const bool, []const bool, ?*const zx_type_465, };

pub const value_zx_type_466_e118d84f4abede871251d81ca2d003f253902bfbf372e406dc4b726b98d0cd5f = struct { value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, []const bool, []const bool, []const bool, ?*const zx_type_466, };

pub const value_zx_type_467_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const bool,
    source: []const []const u8,
    zx_origin: ?*const zx_type_467 = null,
};

pub const value_zx_type_468_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const []const u8,
    zx_origin: ?*const zx_type_468 = null,
};

pub const value_zx_type_469_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    found: bool,
    index: u64,
    symbol: u32,
    values: []const u32,
    zx_origin: ?*const zx_type_469 = null,
};

pub const value_zx_type_470_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, void, ?*const zx_type_470, };

pub const value_zx_type_471_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    facts: value_zx_type_133_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    symbol: u32,
    zx_origin: ?*const zx_type_471 = null,
};

pub const value_zx_type_472_4373da08621bcbc23abd1852eb2d5ba558f05027208e827b7568eb84bcb01181 = struct {
    expressions: *const zx_type_42,
    state: value_zx_type_135_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    zx_origin: ?*const zx_type_472 = null,
};

pub const value_zx_type_473_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u64, ?u64, ?*const zx_type_473, };

pub const value_zx_type_474_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const bool, ?bool, ?*const zx_type_474, };

pub const value_zx_type_475_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, []const u32, ?*const zx_type_475, };

pub const value_zx_type_476_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_136, void, ?*const zx_type_476, };

pub const value_zx_type_477_60476d3f86ecd6f6b546dce9803cb26d53be6cc5e23c28d693274b526d5c73b1 = struct {
    control: *const zx_type_53,
    first: u64,
    index: u64,
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_477 = null,
};

pub const value_zx_type_478_32f7e74537e9df233607e6adcd543ab93f704c9753770d3c59de323bff658ff9 = struct {
    context: value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0,
    first: u64,
    index: u64,
    result: value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063,
    zx_origin: ?*const zx_type_478 = null,
};

pub const value_zx_type_479_b4c00b0680a164f9ad85cafef49c2f1d31566b1a676a14d85e4570178e088fb9 = struct {
    activity: value_zx_type_141_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    index: u64,
    zx_origin: ?*const zx_type_479 = null,
};

pub const value_zx_type_480_87ce98851c74e4bb881d7b286d23c668bc10ac8d52be427cc29c9d7eeacaac3e = struct {
    count: u64,
    first: u64,
    index: u64,
    owner: u64,
    program: value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    result: value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063,
    zx_origin: ?*const zx_type_480 = null,
};

pub const value_zx_type_481_6d9798f49879817ed1bf2a66248bb033e4380a67df59cd5195609fdd4517fd57 = struct {
    count: u64,
    first: u64,
    index: u64,
    program: value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    result: value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063,
    type_first: u64,
    zx_origin: ?*const zx_type_481 = null,
};

pub const value_zx_type_482_b8ec70fbd49037c4f5f15832ef24774698f9ceaf2b6c8bda56f20308b14ddd6f = struct {
    depth: u64,
    first: u64,
    flags: u64,
    index: u64,
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    values: []const u32,
    zx_origin: ?*const zx_type_482 = null,
};

pub const value_zx_type_483_c783738b37c1abb5587b595a894032f687198bb2afdfedcf3224868e2b3ee6ce = struct {
    depth: u64,
    expressions: *const zx_type_42,
    first: u64,
    flags: u64,
    index: u64,
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_483 = null,
};

pub const value_zx_type_484_4cc958f044815e7193e188aa8d2b374a7d7b5bdc35e292ff41875ed7f5ad06b2 = struct {
    count: u64,
    expressions: *const zx_type_42,
    facts: value_zx_type_133_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    first: u64,
    index: u64,
    zx_origin: ?*const zx_type_484 = null,
};

pub const value_zx_type_485_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_42,
    first: u64,
    index: u64,
    result: ?u32,
    symbol: u32,
    zx_origin: ?*const zx_type_485 = null,
};

pub const value_zx_type_486_c3e968df1f71f0e1fe9002a2718c62d7f895e7e395e15c7a9c8aea2cadf96ee5 = struct {
    depth: u64,
    expressions: *const zx_type_42,
    first: u64,
    flags: u64,
    index: u64,
    owner: u64,
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_486 = null,
};

pub const value_zx_type_487_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    active: []const bool,
    count: u64,
    first: u64,
    index: u64,
    symbols: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_487 = null,
};

pub const value_zx_type_488_5858107fbdadcc083e312bfcf504b1d0b97b4200ec30bf4c6f639637dc9c91ba = struct {
    activity: value_zx_type_141_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    count: u64,
    expressions: *const zx_type_42,
    first: u64,
    index: u64,
    zx_origin: ?*const zx_type_488 = null,
};

pub const value_zx_type_489_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    control: *const zx_type_53,
    count: u64,
    expressions: *const zx_type_42,
    first: u64,
    index: u64,
    no: bool,
    valid: bool,
    yes: bool,
    zx_origin: ?*const zx_type_489 = null,
};

pub const value_zx_type_490_28ec67a1b3512058011fb8c36c7fbea177d57a2436abccdef3b72983a75cfa1b = struct {
    count: u64,
    first: u64,
    has_default: bool,
    index: u64,
    program: value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_490 = null,
};

pub const value_zx_type_491_597b115a29e5acb3e5825fd5e696f573a33b81233a7f6927d1c589529f09ca26 = struct {
    count: u64,
    first: u64,
    found: bool,
    index: u64,
    program: value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    value: u64,
    zx_origin: ?*const zx_type_491 = null,
};

pub const value_zx_type_492_3a1785f07cd24dcb5929359c13d36b4bf63681e93136d07868893d9f0e26c2cb = struct {
    captures: u64,
    depth: u64,
    facts: u64,
    first: u64,
    index: u64,
    payload: u64,
    program: value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7,
    state: value_zx_type_144_f35f4b59e5aaa7b0012b75e7340dec8f5a1419ff1587c5b118fad76c1a2cf26d,
    zx_origin: ?*const zx_type_492 = null,
};

pub const value_zx_type_494_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const zx_type_136, ?zx_type_136, ?*const zx_type_494, };

pub const value_zx_type_495_f02a620810820dcc60ddd15370d805d29f7cdde1cf6896338bfedd10fa5a7da0 = struct {
    context: value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0,
    result: value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063,
    zx_origin: ?*const zx_type_495 = null,
};

pub const value_zx_type_496_8c66a5b9a54b9bbe92468e75907297d74c648c030a68ba8e2cecc6553e709b32 = struct { value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0, ?*const zx_type_496, };

pub const value_zx_type_497_f02a620810820dcc60ddd15370d805d29f7cdde1cf6896338bfedd10fa5a7da0 = struct { value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0, value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, ?*const zx_type_497, };

pub const value_zx_type_498_060659a3386750ea3402036c95d9fcb755a30cecd1e8a387129a868f86ad8ba8 = struct { value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0, value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, ?*const zx_type_498, };

pub const value_zx_type_499_39ecf2710d0861d63680882cb4073ed50aa0c6c119d6b03d76c4753c0f72cf0f = struct { value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0, value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, bool, ?*const zx_type_499, };

pub const value_zx_type_500_ba3b383aaa977febdfef4c3d05f94b7f246cc4463eacc2dd8aec1237b528ec0b = struct { value_zx_type_140_c07befa419cbb321a2dad851cdd659e245c55a63075448274abb5ccb83abc4c0, value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, value_zx_type_147_314caf8a6cbb1c454cbd090d0ad3c0fc418cfe158796ec50692610fae6013063, bool, bool, ?*const zx_type_500, };

pub const value_zx_type_501_b202a6b9a97b84d925d8c00ee25721e5ebf31883d49d2e83037938798eb9ee6a = struct { value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, value_zx_type_139_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_501, };

pub const value_zx_type_502_914afb2d82744a67bc682fe94cfae502f792fdb14f070fa88351f0b5d6b2d203 = struct { value_zx_type_138_88cb58a77b0cb6f2cfd8c75b44fb1fcdf46be9971d0f181b2fc4e6375ea458f7, value_zx_type_139_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, bool, ?*const zx_type_502, };

pub const value_zx_type_503_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    capture: u64,
    expressions: *const zx_type_42,
    index: u64,
    symbols: *const zx_type_45,
    table: *const zx_type_19,
    valid: bool,
    zx_origin: ?*const zx_type_503 = null,
};

pub const value_zx_type_504_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const zx_type_27,
    zx_origin: ?*const zx_type_504 = null,
};

pub const value_zx_type_505_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    binding: u64,
    constants: []const u32,
    edge: u64,
    expressions: *const zx_type_42,
    index: u64,
    table: *const zx_type_19,
    uses: []const u64,
    valid: bool,
    zx_origin: ?*const zx_type_505 = null,
};

pub const value_zx_type_506_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_42,
    index: u64,
    table: *const zx_type_19,
    uses: []const u64,
    valid: bool,
    zx_origin: ?*const zx_type_506 = null,
};

pub const value_zx_type_507_c300e804702735c272af3dc9237d24b99a108a57cb3a9dd6f1ea306197d45e80 = struct { value_zx_type_167_d67de9150a29b2c86fcfaa670164fb137ade9312feda415779572f647ca40086, ?*const zx_type_507, };

pub const value_zx_type_508_bd613536ed4e31fa9c4b984dfa3963a789b779a01214b9f7baf6c42f76d22bf5 = struct { value_zx_type_167_d67de9150a29b2c86fcfaa670164fb137ade9312feda415779572f647ca40086, bool, ?*const zx_type_508, };

pub const value_zx_type_509_f06ea3741345e40877bb331df41fcc2ce19c2b659365442e7f817f87e8313e36 = struct { value_zx_type_167_d67de9150a29b2c86fcfaa670164fb137ade9312feda415779572f647ca40086, bool, bool, ?*const zx_type_509, };

pub const value_zx_type_510_4131923c55f52de8d72edffece19050837767ea060906fc6aeb35c95f6468cdd = struct { value_zx_type_167_d67de9150a29b2c86fcfaa670164fb137ade9312feda415779572f647ca40086, bool, bool, bool, ?*const zx_type_510, };

pub const value_zx_type_511_4854cde39e36b19a70d421960f863c814d73da5cf3181d8fbe8174fcb46ecdcd = struct {
    target: value_zx_type_22_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_511 = null,
};

pub const value_zx_type_512_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    index: u64,
    references: []const bool,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_512 = null,
};

pub const value_zx_type_513_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    expressions: *const zx_type_42,
    index: u64,
    kind: zx_type_27,
    locals: []const bool,
    payload: u64,
    zx_origin: ?*const zx_type_513 = null,
};

pub const value_zx_type_514_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    body: u64,
    condition: u64,
    count: u64,
    locals: []const bool,
    reachable: []const bool,
    symbols: u64,
    zx_origin: ?*const zx_type_514 = null,
};

pub const value_zx_type_515_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_42,
    index: u64,
    locals: []const bool,
    reachable: []const bool,
    remaining: u64,
    zx_origin: ?*const zx_type_515 = null,
};

pub const value_zx_type_516_d42088e18bb5c05cf1e3a3d9851c1dd08d41eae9e1223a6150bd284f2dc08b77 = struct {
    count: []const u64,
    first: []const u64,
    index: u64,
    program: value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    symbols: []const u64,
    zx_origin: ?*const zx_type_516 = null,
};

pub const value_zx_type_517_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    locals: []const bool,
    symbols: []const u64,
    zx_origin: ?*const zx_type_517 = null,
};

pub const value_zx_type_518_4c9a900895778ef8a8b8af9807bd68428ea35c59b77acdf07c33728d1d771352 = struct {
    active: bool,
    cached_count: []const u64,
    cached_first: []const u64,
    cached_positions: []const u64,
    children: []const u64,
    field_indices: []const u64,
    heads: []const u64,
    index: u64,
    item: u64,
    next: []const u64,
    parents: []const u64,
    phase: zx_type_184,
    place_types: []const u32,
    program: value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    tails: []const u64,
    zx_origin: ?*const zx_type_518 = null,
};

pub const value_zx_type_519_1b2191a44235c6e6b65e1ae9ab1c3d223553737681d5d92d9e9cae41a381d262 = struct {
    active: bool,
    found: bool,
    index: value_zx_type_187_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    key: value_zx_type_188_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_519 = null,
};

pub const value_zx_type_520_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, []const u64, ?*const zx_type_520, };

pub const value_zx_type_521_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    position: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_521 = null,
};

pub const value_zx_type_522_2a73385728db51fa9518b55ca4dd797e91049a447a89c6c5efe9d790e5c08e2e = struct { value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, ?*const zx_type_522, };

pub const value_zx_type_523_767b69074202a272a12100b84e23109da965767802298cfb5e4fed280635514e = struct { value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, ?*const zx_type_523, };

pub const value_zx_type_524_46b777fb29a6ec83f56ee22ad77d1bbbd13caf8e6a27064012c94c0eb1544938 = struct { value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, ?*const zx_type_524, };

pub const value_zx_type_525_18fcb2898d1d7204e87db706f073fcf51d79752c11063fe602073e375e06acd1 = struct { value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_175_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_525, };

pub const value_zx_type_526_2cde30861016700fbcc37ec0e53f358a870f83b3d9276e54dca5abfa42381dbf = struct { value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_175_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_182_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937, ?*const zx_type_526, };

pub const value_zx_type_527_fc9d1607bfc29c393e85973469418c6449deb36cf03f440f10859d1b0e6cf2c1 = struct { value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_175_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_182_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937, value_zx_type_183_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d, ?*const zx_type_527, };

pub const value_zx_type_528_df87d4e4c94482fd017e977a114eba826861ac6af356c343aea16855cac7c373 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    state: zx_type_176,
    zx_origin: ?*const zx_type_528 = null,
};

pub const value_zx_type_529_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_176, void, ?*const zx_type_529, };

pub const value_zx_type_530_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    children: []const u64,
    count: u64,
    first: u64,
    index: u64,
    source: []const u64,
    zx_origin: ?*const zx_type_530 = null,
};

pub const value_zx_type_531_03ceda26995807c2aa6530d3178a20e89911f37af4bad09be3c9b210bc3682ce = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    target: u64,
    type_id: u32,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_531 = null,
};

pub const value_zx_type_532_20d7d99279e33ed98c39ff3a89f60b0602618a66dfe76434242c1e24534deee7 = struct {
    active: bool,
    ascending: bool,
    fact: u64,
    facts: []const u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    id: u64,
    layout: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    leaving: bool,
    references: []const bool,
    root: u64,
    states: []const zx_type_176,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_532 = null,
};

pub const value_zx_type_533_b96c48974ce17ef2b8be551c68efc904286af193386b87a21ad68406a5672c15 = struct {
    active: bool,
    cache: value_zx_type_209_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    found: bool,
    left: u64,
    right: u64,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_533 = null,
};

pub const value_zx_type_534_4b4ea4009453ea5e4d3d79e2158cdc223b3d2c1404741f1be6d92e28595818e4 = struct {
    active: bool,
    cache: value_zx_type_209_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    capacity: u64,
    grow: bool,
    index: u64,
    left: u64,
    right: u64,
    value: u64,
    zx_origin: ?*const zx_type_534 = null,
};

pub const value_zx_type_535_fddf701302546dc5c12ecdb7d8719eb57b5e534ac713eb9744231ee909d8dc70 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    same: bool,
    type_id: u32,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_535 = null,
};

pub const value_zx_type_536_b3760cb020967af5517f45e8ca01d64dcc589438ca8342340b78221ceef17d6a = struct {
    action: zx_type_208,
    cache: value_zx_type_209_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    children: []const u64,
    first: []const u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    indices: []const u64,
    left: []const u64,
    paired: bool,
    references: []const bool,
    right: []const u64,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_536 = null,
};

pub const value_zx_type_537_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: u64,
    facts: []const u64,
    memo: []const u64,
    places: u64,
    states: []const zx_type_176,
    zx_origin: ?*const zx_type_537 = null,
};

pub const value_zx_type_538_84331d6a4a43806456ffa46c6afa1bd16dcd6bebddd17f96d6eddd9ac3c6fff1 = struct { value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_348_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a, ?*const zx_type_538, };

pub const value_zx_type_539_56d3a3384af94c4c5beea8da80c665c922686500c24f911e92fe4db704c5a3bf = struct { value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_348_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a, value_zx_type_220_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf, ?*const zx_type_539, };

pub const value_zx_type_540_797fedc00020e01168f99323a87b071e9e1bdebae23b4195463f8ae8c1241ef7 = struct {
    action: zx_type_217,
    count: u64,
    index: u64,
    layout: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memo_first: u64,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    rewrite_action: zx_type_208,
    saved: value_zx_type_218_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    state_first: u64,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_540 = null,
};

pub const value_zx_type_542_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const zx_type_223, ?zx_type_223, ?*const zx_type_542, };

pub const value_zx_type_543_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_223, void, ?*const zx_type_543, };

pub const value_zx_type_544_463372a636e1a2c93bbb2070e2204f09a436eef0f006e94b3d11fa862ef159e2 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    merge: bool,
    parents: []const u64,
    references: []const bool,
    saved: []const u64,
    source: []const u64,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_544 = null,
};

pub const value_zx_type_545_2b3f0033db751cf78256c30d401a1a8639ee63997cf1909aeaff24112d21a8c6 = struct {
    activation: u64,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    loops: value_zx_type_233_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    references: []const bool,
    seen: bool,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_545 = null,
};

pub const value_zx_type_546_57c8216039667f25f8124cd801f82d6db9b8e64f4e9aa500df6f0cbf67657227 = struct {
    activation: u64,
    changed: bool,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: value_zx_type_197_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    loops: value_zx_type_233_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    references: []const bool,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_546 = null,
};

pub const value_zx_type_547_87c1c976ed99693bb0b79319ced55961e2f09cd998a5c93ecc538e2ca8eb719e = struct {
    count: u64,
    facts: []const u64,
    first: u64,
    index: u64,
    layout: value_zx_type_178_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    local_first: u64,
    locals: u64,
    memory: value_zx_type_219_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    roots: []const u64,
    symbols: []const u64,
    types: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_547 = null,
};

pub const value_zx_type_548_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    flags: []const bool,
    symbols: u64,
    zx_origin: ?*const zx_type_548 = null,
};

pub const value_zx_type_549_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    first: u64,
    flags: []const bool,
    index: u64,
    symbols: []const u64,
    zx_origin: ?*const zx_type_549 = null,
};

pub const value_zx_type_550_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    flags: []const bool,
    index: u64,
    memo: []const u64,
    parents: []const u64,
    zx_origin: ?*const zx_type_550 = null,
};

pub const value_zx_type_551_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u64,
    parents: []const u64,
    zx_origin: ?*const zx_type_551 = null,
};

pub const value_zx_type_552_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    facts: []const u64,
    flags: []const bool,
    index: u64,
    outputs: []const u64,
    roots: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_552 = null,
};

pub const value_zx_type_553_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    first: u64,
    zx_origin: ?*const zx_type_553 = null,
};

pub const value_zx_type_554_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    index: u64,
    slots: *const zx_type_62,
    zx_origin: ?*const zx_type_554 = null,
};

pub const value_zx_type_555_45c9de4479c865238cef7a36dce7217ac4de64b83f4320ae5b044d7e2faff701 = struct {
    active: bool,
    ascending: bool,
    expression: u64,
    expressions: *const zx_type_42,
    found: bool,
    layout: value_zx_type_183_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    position: u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_555 = null,
};

pub const value_zx_type_556_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    children: []const u64,
    count: u64,
    index: u64,
    zx_origin: ?*const zx_type_556 = null,
};

pub const value_zx_type_557_39e74984115c929e88eabd575698c342998222fa7ee1c2957f496eb4bea9c312 = struct { value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_349_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134, ?*const zx_type_557, };

pub const value_zx_type_558_3ef121c2969f416beec22224e6006647d628ebbbd818e782fec8feea9c3aa01c = struct { value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_349_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134, value_zx_type_227_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_558, };

pub const value_zx_type_559_96d59ef42dfaa6f63ae76f96f93bea239e6bf4f0d4040dd0d8e67637a8a19f9b = struct { value_zx_type_117_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, ?*const zx_type_559, };

pub const value_zx_type_560_9412c839c4879a86cd9ae3e0103c9ccf6966a45b6e70cb5541a6200c50920121 = struct { value_zx_type_117_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, ?*const zx_type_560, };

pub const value_zx_type_561_5f75a732777ffa08755b59b1020ff9fec4bc7ca52ab6b7f965350f62bd8d2dd1 = struct { value_zx_type_117_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, ?*const zx_type_561, };

pub const value_zx_type_562_75e08de77d6e56ca845840a6b21d75631fa69d76d0660b98a5fb39e5141e3552 = struct { value_zx_type_117_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, ?*const zx_type_562, };

pub const value_zx_type_563_63158ce2356408fc7d4f3b5e2b0660a165e11792b30c8267f6b16faaede41bc6 = struct { value_zx_type_117_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_227_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_563, };

pub const value_zx_type_564_a252266785ed2c072e72fb23f03640f83fbfcaf61598af22238498adeaab2f72 = struct { value_zx_type_117_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, value_zx_type_169_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_227_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, bool, ?*const zx_type_564, };

pub const value_zx_type_565_6b36136f08b1ecdc688c412d14c48773d44bb759a49656ca1c5672b4211e77b5 = struct { value_zx_type_117_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, bool, ?*const zx_type_565, };

pub const value_zx_type_566_32abba56676d7e1bfae0149cb931913947440d6b9f3ac11995558be847b69fd3 = struct { value_zx_type_117_319d9c12e0b0eee194630a23b18bc4f8a58c1bf2c27ae49271671a3082843f3d, bool, bool, bool, bool, ?*const zx_type_566, };

pub const value_zx_type_567_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: *const zx_type_42,
    index: u64,
    limit: u64,
    valid: bool,
    zx_origin: ?*const zx_type_567 = null,
};

pub const value_zx_type_568_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    members: []const []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_568 = null,
};

pub const value_zx_type_569_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d = struct {
    index: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_569 = null,
};

pub const value_zx_type_570_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_570 = null,
};

pub const value_zx_type_571_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    left: []const []const u8,
    right: []const []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_571 = null,
};

pub const value_zx_type_572_baebe69047a6187417aee9fcf2f488ecfe1a2e75d46b45a6e051c442e2cc077b = struct {
    context: value_zx_type_106_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea,
    index: u64,
    name: []const u8,
    owner: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_572 = null,
};

pub const value_zx_type_573_e2046bbbdd123b340ba885225deecccca3eb1df70cd21bf5e0834e01a8367832 = struct { value_zx_type_106_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?*const zx_type_573, };

pub const value_zx_type_574_d0454f4a1a7de6aeeb81f6f933317e2b1cae56f63e59320e6127de9228953b6d = struct { value_zx_type_106_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, ?*const zx_type_574, };

pub const value_zx_type_575_ef0a93c819150b4bd1bdd5e2d698ce3efee444949e0d810849c9712837294128 = struct { value_zx_type_106_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, []const u8, ?*const zx_type_575, };

pub const value_zx_type_576_7bc328ba5cf99a5b76a8fcf29acd76fe767f9143af361280d1b32d7c839d09a0 = struct { value_zx_type_106_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, []const u8, bool, ?*const zx_type_576, };

pub const value_zx_type_577_0eaee0151510bfd991a3bd0b89367cdadb492abec1a5fd00c10697062204fb50 = struct { value_zx_type_106_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, []const u8, bool, bool, ?*const zx_type_577, };

pub const value_zx_type_578_5c3c4da74c27c16d65bdea72766e8717a308e65195b5fc3eb5fc7814376e200e = struct { value_zx_type_106_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, []const u8, bool, bool, bool, ?*const zx_type_578, };

pub const value_zx_type_579_34b10c8fb4fbd35db9d232cb0f993fe12d688f67d7d4e366c1c21a61272239c8 = struct { value_zx_type_106_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea, ?[]const u8, []const u8, bool, bool, bool, bool, ?*const zx_type_579, };

pub const value_zx_type_580_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u32,
    types: []const u32,
    zx_origin: ?*const zx_type_580 = null,
};

pub const value_zx_type_581_e366d4f93466af93bfbf8b4815757383af115756f7364062c2c9d566a0fb2311 = struct {
    input: value_zx_type_267_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    position: u64,
    positions: []const ?u32,
    type_ids: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_581 = null,
};

pub const value_zx_type_582_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u32, ?u32, ?*const zx_type_582, };

pub const value_zx_type_584_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec = struct { []const ?u32, ??u32, ?*const zx_type_584, };

pub const value_zx_type_585_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?u32, void, ?*const zx_type_585, };

pub const value_zx_type_586_efdd75a5e607c61dffb07c66411d75c96f1f2b811307e711dcc2093faf9ae2b2 = struct { value_zx_type_267_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, ?*const zx_type_586, };

pub const value_zx_type_587_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct { value_zx_type_267_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, ?*const zx_type_587, };

pub const value_zx_type_588_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06 = struct { value_zx_type_267_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, bool, ?*const zx_type_588, };

pub const value_zx_type_589_9b770bfbaef1ee4a1f37cd5c69496f8e6265dc77782a7366bf43ec067765a897 = struct { value_zx_type_261_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, ?*const zx_type_589, };

pub const value_zx_type_590_bf234d34f878674ed8858181ac2a0c4fd477de7fa4f453b993f7dab67dc14e39 = struct { value_zx_type_261_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, ?*const zx_type_590, };

pub const value_zx_type_591_556e1ac08c0fc3979e6036c160a2f2a62709a2e5ccad3786614889613cfdd764 = struct { value_zx_type_261_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, bool, ?*const zx_type_591, };

pub const value_zx_type_592_92efd3022152da7dc5c749fdfd73fdff302acd575ca7a7c8920c615ca11a0e05 = struct { value_zx_type_261_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, bool, bool, ?*const zx_type_592, };

pub const value_zx_type_593_7ab9c026eaa54cb0320a667a0ff657ceef59035c2f2475d6fc17da0ab13558a9 = struct { value_zx_type_261_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, bool, bool, ?value_zx_type_267_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, ?*const zx_type_593, };

pub const value_zx_type_594_b6658afbb0dbb221585c28b225ed84d4d8f26171cf709d7184581e757682a853 = struct { value_zx_type_261_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, bool, bool, ?value_zx_type_267_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, ?*const zx_type_594, };

pub const value_zx_type_595_44cf8fab33977767e4c055445acad6cd3fc2421a67b93fec221d92bc429fb63d = struct { value_zx_type_261_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, value_zx_type_75_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5, ?*const zx_type_595, };

pub const value_zx_type_596_7c3cada982eb8438381d40c327e0b6dc2488553fb4130cb5762524bce3ea95b7 = struct { value_zx_type_261_35a5c25db515506632d82798661f2c94aea11e993db35ebe12d26d8ef6a2e50d, bool, value_zx_type_75_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5, bool, ?*const zx_type_596, };

pub const value_zx_type_597_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    names: []const []const u8,
    table: *const zx_type_19,
    types: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_597 = null,
};

pub const value_zx_type_598_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_598 = null,
};

pub const value_zx_type_599_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_274, void, ?*const zx_type_599, };

pub const value_zx_type_600_5821a6631fd0a2b5d5f68275f533e0b86f2430edbf1471339d13b94e742690d5 = struct {
    contracts: *const zx_type_50,
    index: u64,
    state: value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_600 = null,
};

pub const value_zx_type_601_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, void, ?*const zx_type_601, };

pub const value_zx_type_602_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_273, void, ?*const zx_type_602, };

pub const value_zx_type_603_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    control: *const zx_type_53,
    first: u64,
    frames: []const *const zx_type_273,
    index: u64,
    source: u64,
    zx_origin: ?*const zx_type_603 = null,
};

pub const value_zx_type_604_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    capacity: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_604 = null,
};

pub const value_zx_type_605_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    previous: []const u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_605 = null,
};

pub const value_zx_type_606_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    key: u64,
    position: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_606 = null,
};

pub const value_zx_type_607_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    end: u64,
    index: u64,
    table: *const zx_type_42,
    values: []const u32,
    zx_origin: ?*const zx_type_607 = null,
};

pub const value_zx_type_608_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, []const []const u8, ?*const zx_type_608, };

pub const value_zx_type_609_7498e4f806a7d6cb548387280423a75175fc5b80ec06eb4213ab0655a938538d = struct {
    end: u64,
    expressions: *const zx_type_42,
    index: u64,
    names: []const []const u8,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_609 = null,
};

pub const value_zx_type_610_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_274, []const *const zx_type_274, ?*const zx_type_610, };

pub const value_zx_type_611_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    frames: []const *const zx_type_273,
    index: u64,
    source: u64,
    values: []const u32,
    zx_origin: ?*const zx_type_611 = null,
};

pub const value_zx_type_613_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_273, ?*const zx_type_273, ?*const zx_type_613, };

pub const value_zx_type_614_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    names: []const []const u8,
    values: []const []const u8,
    zx_origin: ?*const zx_type_614 = null,
};

pub const value_zx_type_615_b06e51454feef7fdf7d9b33c62cb112de772e5d9de51777f095ab91e73b9d4a4 = struct { value_zx_type_279_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, ?*const zx_type_615, };

pub const value_zx_type_616_559c4a2367a0e05791ca87aafe7d7cdb8a8bef28a8e16e6f7fcc6220ff365f00 = struct { value_zx_type_279_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?*const zx_type_616, };

pub const value_zx_type_617_7e470e8ae35bc1ae71064e0d2c7f58ebb3ee66a2637521f4043452e64e35c605 = struct { value_zx_type_279_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?*const zx_type_617, };

pub const value_zx_type_618_6327aad74f053b917836b19aec6a569c09585fbbc9966097f141db1ae3eef3e6 = struct { value_zx_type_279_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, value_zx_type_278_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?[]const []const u8, ?*const zx_type_618, };

pub const value_zx_type_619_d24b26c0aea29f7ac2d1c547d13d7291794ab89c1d1ffa5dfc71206601edcad6 = struct {
    context: value_zx_type_275_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b,
    index: u64,
    unit: value_zx_type_75_242a9693ac07831dd594af13e82cb7ab63d66b5204f347ccc5f7ac4040ca6aa5,
    valid: bool,
    zx_origin: ?*const zx_type_619 = null,
};

pub const value_zx_type_620_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    first: u64,
    index: u64,
    members: []const []const u8,
    names: []const []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_620 = null,
};

pub const value_zx_type_621_dc2d42eac19bfb34fc4f908abe20295af94d45c49ad5d7797489bde46135f52a = struct { value_zx_type_76_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, bool, bool, bool, ?*const zx_type_621, };

pub const value_zx_type_622_021b7381f380cabd2db3eeb3ddf349cff4c6c84e76d3c31e21bbe00b7a7b09a0 = struct { value_zx_type_76_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, bool, bool, bool, bool, ?*const zx_type_622, };

pub const value_zx_type_623_57dce5d4254efe041b987cdedb775c04961c5941cc08a0b50819eb66743d1e59 = struct { value_zx_type_76_f3e88d0461892c15610d96f18f2967cbe6108bcea062216f1cd4224665acd235, bool, bool, bool, bool, bool, ?*const zx_type_623, };

pub const value_zx_type_624_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const bool,
    source: []const u8,
    zx_origin: ?*const zx_type_624 = null,
};

pub const value_zx_type_625_bb434d5e72b066e53cf6e19c78521c727a793cb1b95ed74bb315c89aa840629a = struct {
    context: value_zx_type_74_ca20ba241cdc71253872e78631d53d1e525bab3b64ed51d77db3ec5ab064b09e,
    declared: []const bool,
    index: u64,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    valid: bool,
    zx_origin: ?*const zx_type_625 = null,
};

pub const value_zx_type_626_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    declared: []const bool,
    index: u64,
    table: *const zx_type_19,
    valid: bool,
    zx_origin: ?*const zx_type_626 = null,
};

pub const value_zx_type_627_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    found: bool,
    identity: []const u8,
    index: u64,
    stores: []const *const zx_type_62,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_627 = null,
};

pub const value_zx_type_628_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    found: bool,
    identity: []const u8,
    index: u64,
    stores: *const zx_type_62,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_628 = null,
};

pub const value_zx_type_629_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    kinds: []const zx_type_27,
    valid: bool,
    zx_origin: ?*const zx_type_629 = null,
};

pub const value_zx_type_630_084b80cb68dfdf1a08bca62f81a8a7989cecfcf6ba2030b5f38f474597729de3 = struct {
    graph: value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_630 = null,
};

pub const value_zx_type_631_0569ce77f4b821eace8febdedd7895223be0dfddc2ebeb3616075bdc2cb966bb = struct {
    index: u64,
    input: value_zx_type_292_f1df282d6e484b7127898a03b5f590e15df63b6ee6d22af1df6699f4f325bd16,
    valid: bool,
    zx_origin: ?*const zx_type_631 = null,
};

pub const value_zx_type_632_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    limit: u64,
    right: []const u8,
    zx_origin: ?*const zx_type_632 = null,
};

pub const value_zx_type_633_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    building: bool,
    count: u64,
    names: []const []const u8,
    remaining: u64,
    root: u64,
    sifting: bool,
    types: []const u32,
    zx_origin: ?*const zx_type_633 = null,
};

pub const value_zx_type_634_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    names: []const []const u8,
    stores: []const *const zx_type_62,
    types: []const u32,
    zx_origin: ?*const zx_type_634 = null,
};

pub const value_zx_type_635_b136b1d01bf66184f41ee2f39a29133b575d8ab64b8482edb58d6f8c2be9e268 = struct {
    fields: value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_635 = null,
};

pub const value_zx_type_636_075d13e5cd4fc801fede9d5ea073c549f15a322355f73a15538b07eefdd7b81e = struct { value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638, ?*const zx_type_636, };

pub const value_zx_type_637_a0feea08302b6219ebdf27f7701bf5c06f5d2870468ab6fb9c77eac395ef840a = struct { value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638, bool, ?*const zx_type_637, };

pub const value_zx_type_638_084b80cb68dfdf1a08bca62f81a8a7989cecfcf6ba2030b5f38f474597729de3 = struct { value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638, bool, bool, ?*const zx_type_638, };

pub const value_zx_type_639_8aab28868dfbf1a1508d349276cb255dcb04ffe77c6bb790fdf39f817facad1b = struct { value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638, bool, bool, bool, ?*const zx_type_639, };

pub const value_zx_type_640_c821e530046f60b24304360a0bfc56ceb3a83b9e49a56d0e382c5b201289778d = struct { value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638, bool, bool, bool, bool, ?*const zx_type_640, };

pub const value_zx_type_641_bfd0c1a59610ee95b5e8eeb665e69721a06e2d073ff296a86e233d4599bf50c0 = struct { value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638, bool, bool, bool, bool, bool, ?*const zx_type_641, };

pub const value_zx_type_642_532cd82a2c316bfb1b4e782635de36f710f3ad43bb831d133f7a8c75a147ba29 = struct { value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638, bool, bool, bool, bool, bool, bool, ?*const zx_type_642, };

pub const value_zx_type_643_05709a4144b9301e3ba2d69ee1fbf56a496e7067ab43c2cc317e154eebaec11b = struct { value_zx_type_79_e07f80c8a474ebb57a747260d29e1d65e7cbf2e844a0b4bbf51b20f910c9f638, bool, bool, bool, bool, bool, bool, bool, ?*const zx_type_643, };

pub const value_zx_type_644_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    index: u64,
    scalar: u8,
    table: *const zx_type_19,
    zero: u32,
    zx_origin: ?*const zx_type_644 = null,
};

pub const value_zx_type_645_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, void, ?*const zx_type_645, };

pub const value_zx_type_646_56b664a23dccb3b4c9c1dea493fb95e98960a53ecfef31ef7b2460404f2aed8c = struct {
    found: bool,
    index: u64,
    modules: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    value: []const u8,
    zx_origin: ?*const zx_type_646 = null,
};

pub const value_zx_type_647_2c9f6174d4c6b0ae4ce47827b5a95d8152bec2df1edaca0b6d1af1d540fcfb24 = struct {
    index: u64,
    input: value_zx_type_295_0409e489687dab5e722cf1f8c25f35a783581c270ff2f42a3f0a46342247d9ff,
    owners: []const []const u8,
    zx_origin: ?*const zx_type_647 = null,
};

pub const value_zx_type_648_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = struct { u32, ?*const zx_type_648, };

pub const value_zx_type_649_f5e553eae73ca161c587937fe6f7a8387771b918fa9e3e0a9ea7ddf837de9813 = struct {
    captures: value_zx_type_648_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744,
    index: u64,
    result: []const u32,
    source: []const u8,
    zx_origin: ?*const zx_type_649 = null,
};

pub const value_zx_type_650_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u8,
    zx_origin: ?*const zx_type_650 = null,
};

pub const value_zx_type_651_025f48c4857bfffa7b37d9c120e29a33704982d2f2684791d2d41fe995906439 = struct {
    index: u64,
    indices: []const u64,
    names: []const []const u8,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    source: *const zx_type_19,
    valid: bool,
    zx_origin: ?*const zx_type_651 = null,
};

pub const value_zx_type_652_39deabb2b2695c3beb2d57c97c18d541a05e70727606e510a1e78404e74bfebe = struct { value_zx_type_351_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, ?*const zx_type_652, };

pub const value_zx_type_653_adad6f99bbff4b9e651ae853c26bfdd04dd68160d05bd5e9931c7b29acd55676 = struct { value_zx_type_351_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, bool, ?*const zx_type_653, };

pub const value_zx_type_654_e255b7bfde3236ee539d39e518c24a0b23dacaed7e16fa67c4704da539250b3b = struct { value_zx_type_351_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, bool, value_zx_type_301_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, ?*const zx_type_654, };

pub const value_zx_type_655_1d0b06e4dd93dfee91b88b63decaa8dfad3c0110bb66a3ab25da9432d3f32797 = struct { value_zx_type_351_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, bool, value_zx_type_301_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, bool, ?*const zx_type_655, };

pub const value_zx_type_656_713639bf2340277cb2fc17b55239d7eafff49067cfedc85ab5bd099cd1d4078d = struct {
    equal: bool,
    index: u64,
    left: value_zx_type_303_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    right: value_zx_type_303_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_656 = null,
};

pub const value_zx_type_657_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    first: u64,
    index: u64,
    source: *const zx_type_19,
    target: *const zx_type_19,
    valid: bool,
    zx_origin: ?*const zx_type_657 = null,
};

pub const value_zx_type_658_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    first: u64,
    index: u64,
    mapping: []const u32,
    zx_origin: ?*const zx_type_658 = null,
};

pub const value_zx_type_659_5d935698269bb7ab2f4dad6a0056b556e12f7bcf0bf731e892e1d03c5753906e = struct {
    candidate: value_zx_type_109_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    count: u64,
    id: u32,
    index: u64,
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_16_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53,
    status: zx_type_309,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_659 = null,
};

pub const value_zx_type_660_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    first: u64,
    index: u64,
    mapping: []const u32,
    references: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_660 = null,
};

pub const value_zx_type_661_0e70c693f6adee041b71153b65d39c537ba5de74cae3bc9eba48950bd94db775 = struct {
    candidate: value_zx_type_109_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    count: u64,
    found: bool,
    id: u32,
    index: u64,
    tables: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_661 = null,
};

pub const value_zx_type_662_05a5d3a5878a18fa3771d0d6292dbfaf460977507b1db542e0319c8fbfb0a521 = struct {
    index: u64,
    request: value_zx_type_296_a5f957dcc1eb48c009581bc18274d6ff18510deb427b7a3469fa032db39dc942,
    state: value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87,
    zx_origin: ?*const zx_type_662 = null,
};

pub const value_zx_type_663_79a0f2b5cd7632b6b6a69bfecbb2c63310542f657e73f2d5c2495e110b45cce8 = struct { value_zx_type_298_678517bea1354ebf2792ee61e35792b8e11faf1d9c912fe6172420b5a8d9dc45, ?*const zx_type_663, };

pub const value_zx_type_664_f72f35e6810e37ab3c64ad2898348e94cecb4b0ea57af3b975d05d5d6092e071 = struct { value_zx_type_298_678517bea1354ebf2792ee61e35792b8e11faf1d9c912fe6172420b5a8d9dc45, bool, ?*const zx_type_664, };

pub const value_zx_type_665_dd6a7de636f26f11d818806ebd8e2949298f31e09abecbecebb697688b1cc6ac = struct { value_zx_type_298_678517bea1354ebf2792ee61e35792b8e11faf1d9c912fe6172420b5a8d9dc45, bool, []const u32, ?*const zx_type_665, };

pub const value_zx_type_666_838e8753c6ba464f3e984e7ecbe5645a655294ef45532a882890b3828eecb221 = struct { value_zx_type_298_678517bea1354ebf2792ee61e35792b8e11faf1d9c912fe6172420b5a8d9dc45, bool, []const u32, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, ?*const zx_type_666, };

pub const value_zx_type_667_4304d5306020390c14328b10b0550dda8e154411f56b8d2df4b9fa3e2f47eb5a = struct { value_zx_type_299_6910f7d9dba2c694d06ffd684becdcaa9d2348be1866381b49b73a4a1c30ef9e, ?*const zx_type_667, };

pub const value_zx_type_668_687031bb6dbd21825a38d5293c7c5bacdb2bcc6953be36a52d2113b6e8c1507c = struct { value_zx_type_299_6910f7d9dba2c694d06ffd684becdcaa9d2348be1866381b49b73a4a1c30ef9e, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, ?*const zx_type_668, };

pub const value_zx_type_669_d6df8a06785b796d927aa1906b4ef69d15ac4ecf8f1590f0423547738f6e3482 = struct { value_zx_type_299_6910f7d9dba2c694d06ffd684becdcaa9d2348be1866381b49b73a4a1c30ef9e, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, ?[]const u64, ?*const zx_type_669, };

pub const value_zx_type_670_5f6f2c5e28503373fd394c6eafb79ea4378a5252039299d85814281094ee5999 = struct { value_zx_type_299_6910f7d9dba2c694d06ffd684becdcaa9d2348be1866381b49b73a4a1c30ef9e, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, ?[]const u64, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, ?*const zx_type_670, };

pub const value_zx_type_671_ed98ab2d684155f0f16edf3c906e8b7cce9beb0c415885713abde878f5ffabc6 = struct { value_zx_type_331_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, ?*const zx_type_671, };

pub const value_zx_type_672_c3ddfcc026466d3a2792bf529dbc7868b3ee7cde7c5b8a3f449506d71cf92e19 = struct {
    captures: value_zx_type_671_ed98ab2d684155f0f16edf3c906e8b7cce9beb0c415885713abde878f5ffabc6,
    index: u64,
    result: []const u32,
    source: []const u32,
    zx_origin: ?*const zx_type_672 = null,
};

pub const value_zx_type_673_08069f06583aa6f56d798ad1a2c6e8adc7819f9b5bdc88188382992bc161a985 = struct {
    ids: []const u32,
    index: u64,
    names: []const []const u8,
    valid: bool,
    value: value_zx_type_327_f0efbe3095313e389200ce15211d85a75831f6f84ebaa79a40337d64d6e07e5b,
    zx_origin: ?*const zx_type_673 = null,
};

pub const value_zx_type_674_8500f0a005b162543c9b57d8e96b4d1ddb37848d0d7cf80d7209849aa5d915dd = struct {
    base: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    count: u64,
    delta: value_zx_type_70_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    found: bool,
    import_name: []const u8,
    index: u64,
    name: []const u8,
    zx_origin: ?*const zx_type_674 = null,
};

pub const value_zx_type_675_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?[]const u8, void, ?*const zx_type_675, };

pub const value_zx_type_676_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u32, void, ?*const zx_type_676, };

pub const value_zx_type_677_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const []const u8, void, ?*const zx_type_677, };

pub const value_zx_type_678_bc8931138882ad710f3b0938b188c6f09e21d0c8418d4783816baceb2c29ab37 = struct { value_zx_type_355_0ed01b68f4c141e7bd395d473f85a378b16da06108cedbad8097f62049757281, ?*const zx_type_678, };

pub const value_zx_type_679_b85701b75d8c3e6d870c4f88c6628b31e28ebe90380cf60ab98df0ac7dfb53dc = struct { value_zx_type_355_0ed01b68f4c141e7bd395d473f85a378b16da06108cedbad8097f62049757281, value_zx_type_327_f0efbe3095313e389200ce15211d85a75831f6f84ebaa79a40337d64d6e07e5b, ?*const zx_type_679, };

pub const value_zx_type_680_a9b331ff1b5cbbb8abeb628b1f09031cf03592430364d7f870fc1c6ad3483ec4 = struct { value_zx_type_355_0ed01b68f4c141e7bd395d473f85a378b16da06108cedbad8097f62049757281, value_zx_type_327_f0efbe3095313e389200ce15211d85a75831f6f84ebaa79a40337d64d6e07e5b, []const u32, ?*const zx_type_680, };

pub const value_zx_type_681_36107df23a93c52be28e9cb8e71466a876bcfa7f5a7e6ed8547a04315dc28524 = struct { value_zx_type_355_0ed01b68f4c141e7bd395d473f85a378b16da06108cedbad8097f62049757281, value_zx_type_327_f0efbe3095313e389200ce15211d85a75831f6f84ebaa79a40337d64d6e07e5b, []const u32, value_zx_type_328_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06, ?*const zx_type_681, };

pub const value_zx_type_682_49129128bed2eab4847d5108d0ed3c4d32810f9cdd95b1d04dcc61383544ee70 = struct { value_zx_type_339_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_682, };

pub const value_zx_type_683_2a06c0e1945e2be4ccba75082fecad06e035d1b78594cca1137381b015534d98 = struct {
    captures: value_zx_type_682_49129128bed2eab4847d5108d0ed3c4d32810f9cdd95b1d04dcc61383544ee70,
    index: u64,
    result: []const u32,
    source: []const u32,
    zx_origin: ?*const zx_type_683 = null,
};

pub const value_zx_type_684_009b209c29dfed37d6f0ddf10651eb819801430299ea03fd6bf9a11471606d6e = struct { value_zx_type_356_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, ?*const zx_type_684, };

pub const value_zx_type_685_9068dcb27588fc549cd15008d3bd15e507480c6631115fd15614e1d02077b29f = struct { value_zx_type_356_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, *const zx_type_45, ?*const zx_type_685, };

pub const value_zx_type_686_9e473f196db28165f17fa02012d877e38b20b2fdd7fbf0bd932a3b8513569fa0 = struct { value_zx_type_356_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, *const zx_type_45, *const zx_type_42, ?*const zx_type_686, };

pub const value_zx_type_687_cf7f91935142e682a287d5d100dd4ce0b0109b30ee54eeca5ee330715975db08 = struct {
    expressions: []const *const zx_type_42,
    index: u64,
    input: value_zx_type_340_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    symbols: []const *const zx_type_45,
    zx_origin: ?*const zx_type_687 = null,
};

pub const value_zx_type_688_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_45, void, ?*const zx_type_688, };

pub const value_zx_type_689_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_42, void, ?*const zx_type_689, };

pub const value_zx_type_690_49129128bed2eab4847d5108d0ed3c4d32810f9cdd95b1d04dcc61383544ee70 = struct { value_zx_type_341_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_690, };

pub const value_zx_type_691_2a06c0e1945e2be4ccba75082fecad06e035d1b78594cca1137381b015534d98 = struct {
    captures: value_zx_type_690_49129128bed2eab4847d5108d0ed3c4d32810f9cdd95b1d04dcc61383544ee70,
    index: u64,
    result: []const []const u8,
    source: []const []const u8,
    zx_origin: ?*const zx_type_691 = null,
};

pub const value_zx_type_692_67228720a8622b99a204b0d635fffdcc2ffde3207bf7e7cd616999266c6efddb = struct { value_zx_type_336_d7a5c10f2ea918f9a61d8c31039ae40be7d5d60da8788d94789121a2791040a5, ?*const zx_type_692, };

pub const value_zx_type_693_365ce6dbe7632fe9a050303a1a6e770b1ac74e87f433f5177eb8322386b680ce = struct { value_zx_type_336_d7a5c10f2ea918f9a61d8c31039ae40be7d5d60da8788d94789121a2791040a5, value_zx_type_337_c8ef79bf4d3b91a2c9b2f614591933f932c897963dd6c705cc8aca7b6f3d3660, ?*const zx_type_693, };

pub const value_zx_type_694_989dcfd981741d844657828d6718099e1f8ef0f65a71a39e88d89763bfcfaf71 = struct { value_zx_type_336_d7a5c10f2ea918f9a61d8c31039ae40be7d5d60da8788d94789121a2791040a5, value_zx_type_337_c8ef79bf4d3b91a2c9b2f614591933f932c897963dd6c705cc8aca7b6f3d3660, *const zx_type_45, ?*const zx_type_694, };

pub const value_zx_type_695_c8e6f26172ad65364689364a41827f2859c88ac694084aeba2f171980760555b = struct { value_zx_type_336_d7a5c10f2ea918f9a61d8c31039ae40be7d5d60da8788d94789121a2791040a5, value_zx_type_337_c8ef79bf4d3b91a2c9b2f614591933f932c897963dd6c705cc8aca7b6f3d3660, *const zx_type_45, *const zx_type_42, ?*const zx_type_695, };

pub const value_zx_type_696_1fc7413b79be60ade319e0660bf4aa340f82ec91f5b696c97d68a4d5741c3352 = struct { value_zx_type_336_d7a5c10f2ea918f9a61d8c31039ae40be7d5d60da8788d94789121a2791040a5, value_zx_type_337_c8ef79bf4d3b91a2c9b2f614591933f932c897963dd6c705cc8aca7b6f3d3660, *const zx_type_45, *const zx_type_42, *const zx_type_50, ?*const zx_type_696, };

pub const value_zx_type_697_bf76b7884ca00f80ed8548c016c224c8c0d240b0a0d29f98160ed552da727514 = struct { value_zx_type_336_d7a5c10f2ea918f9a61d8c31039ae40be7d5d60da8788d94789121a2791040a5, value_zx_type_337_c8ef79bf4d3b91a2c9b2f614591933f932c897963dd6c705cc8aca7b6f3d3660, *const zx_type_45, *const zx_type_42, *const zx_type_50, *const zx_type_62, ?*const zx_type_697, };

pub const value_zx_type_698_ab9fea2864d4d037a37f087b8a8d0934155cd46d5ad73bb1a787aadd3be9297d = struct {
    contracts: []const *const zx_type_50,
    expressions: []const *const zx_type_42,
    files: []const []const u8,
    index: u64,
    inputs: []const u32,
    modules: []const ?u32,
    outputs: []const u32,
    request: value_zx_type_334_70c5b3c2f45727ed8f61774b74c8f3909d313beac38427e976c16f634d41af66,
    stores: []const *const zx_type_62,
    symbols: []const *const zx_type_45,
    zx_origin: ?*const zx_type_698 = null,
};

pub const value_zx_type_699_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_62, void, ?*const zx_type_699, };

pub const value_zx_type_700_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_50, void, ?*const zx_type_700, };

pub const value_zx_type_701_12c426f47f5c0bb21f7d5163134ce5b2ad9ccbfe73855ebb948cd9e53384bc10 = struct {
    functions: []const ?u32,
    index: u64,
    input: value_zx_type_342_b5269a6450d9595cda619b08591a67cbaae315944227d0713dbdbc8349c83527,
    paths: []const []const u8,
    types: []const []const u32,
    zx_origin: ?*const zx_type_701 = null,
};

pub const value_zx_type_702_c2e1fc8f246767c9131773aaa9423674ddf82c687720cba6141070a0c0d9ae1a = struct { value_zx_type_343_5c55ea113028a923cd7b60993d0cbd0ca61f6c42ff9efed54c09fd78195978c4, ?*const zx_type_702, };

pub const value_zx_type_703_e63a96a28c08a0137e6b62c708c4db4c950a60bc32df5de14a38bd42976487b4 = struct {
    captures: value_zx_type_702_c2e1fc8f246767c9131773aaa9423674ddf82c687720cba6141070a0c0d9ae1a,
    index: u64,
    result: []const []const u8,
    source: []const []const u8,
    zx_origin: ?*const zx_type_703 = null,
};

pub const value_zx_type_704_e63a96a28c08a0137e6b62c708c4db4c950a60bc32df5de14a38bd42976487b4 = struct {
    captures: value_zx_type_702_c2e1fc8f246767c9131773aaa9423674ddf82c687720cba6141070a0c0d9ae1a,
    index: u64,
    result: []const u32,
    source: []const u32,
    zx_origin: ?*const zx_type_704 = null,
};

pub const value_zx_type_705_1bbe1af145970e8baf717333faadd90ad9f65c8d62c17703f588c89583e63cca = struct { value_zx_type_353_c5016fbf4205dbc5f597fe1330a86f71507a94ff71fcb2b9f6ace510ea97fc21, ?*const zx_type_705, };

pub const value_zx_type_706_d3af0c055a4bb273e37383e43ff230ad0d29e37b25ba0a7d04b055d84b41fdf8 = struct { value_zx_type_353_c5016fbf4205dbc5f597fe1330a86f71507a94ff71fcb2b9f6ace510ea97fc21, value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8, ?*const zx_type_706, };

pub const value_zx_type_707_c26afb1895613e0757d0c60a1a4473dae0895076c3efed449b5e3e24b5262cec = struct { value_zx_type_353_c5016fbf4205dbc5f597fe1330a86f71507a94ff71fcb2b9f6ace510ea97fc21, value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8, value_zx_type_77_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_707, };

pub const value_zx_type_708_08fee147b51c8fad012101d56c5256de71a55f3833c0c5283d59a964ca8e8ccf = struct { value_zx_type_353_c5016fbf4205dbc5f597fe1330a86f71507a94ff71fcb2b9f6ace510ea97fc21, value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8, value_zx_type_77_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_708, };

pub const value_zx_type_709_849c1a5f8f9110f1afa91dadac620569f97beae6478942273d9042d6038918eb = struct { value_zx_type_353_c5016fbf4205dbc5f597fe1330a86f71507a94ff71fcb2b9f6ace510ea97fc21, value_zx_type_68_d20a4f4fdd92e7535661695e5b4c1823ca66c58eb3b0a431a1721035aa2fb7a8, value_zx_type_77_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, *const zx_type_19, ?*const zx_type_709, };

pub const value_zx_type_710_bffc5e8eb5a02694e3480db2dd27ba0646cd38df64043234007bf2db6f623548 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, ?*const zx_type_710, };

pub const value_zx_type_711_45da3fe45241c4b458e4f647275889f9f438736171cb17026f282c439662917f = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, *const zx_type_19, ?*const zx_type_711, };

pub const value_zx_type_712_fedf8b94d021f43bef6dacd89d08a3053a3aa0564582b4aef0ac6d6a597c1d13 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, *const zx_type_19, value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, ?*const zx_type_712, };

pub const value_zx_type_713_32f8536563d8a4b701b01f62a25105db16b17168fc282dbd43ba2abf9ce6b657 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, *const zx_type_19, value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, ?*const zx_type_713, };

pub const value_zx_type_714_eb7ea2427a1f684ef24c7274af742bdbf734b2ec7af333cbba62193de3b89a20 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, *const zx_type_19, value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, bool, ?*const zx_type_714, };

pub const value_zx_type_715_c3701d45de4dc88874ec2de4b124d1441a1300a8bcce2831086fae830d9e9498 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, *const zx_type_19, value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, bool, value_zx_type_328_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06, ?*const zx_type_715, };

pub const value_zx_type_716_df4735d4a9de25a7c8986cb3319ff1c7f463847de1ae652a422e5b2635834456 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, *const zx_type_19, value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, bool, value_zx_type_328_5160eb1c7b96ef87a1dc62bbd174d33f7e1457b4aa84245e3745977fb48f4d06, value_zx_type_82_28f473da2a87d2ad04981199ccf8ba960699ded176a2bd8d1e7bcc545893a7b9, ?*const zx_type_716, };

pub const value_zx_type_717_d38605cb746ae2f9080c0732073cf0062c170822abcf76a3c9a20eb04dff1661 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, *const zx_type_19, value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, bool, value_zx_type_82_28f473da2a87d2ad04981199ccf8ba960699ded176a2bd8d1e7bcc545893a7b9, ?*const zx_type_717, };

pub const value_zx_type_718_eb7ea2427a1f684ef24c7274af742bdbf734b2ec7af333cbba62193de3b89a20 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, *const zx_type_19, value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, u64, ?*const zx_type_718, };

pub const value_zx_type_719_d38605cb746ae2f9080c0732073cf0062c170822abcf76a3c9a20eb04dff1661 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, *const zx_type_19, value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_297_515f73fa8e5a79f129f252b62dd73912342f1d3e8c492f54f17b87756eb5ad87, u64, value_zx_type_82_28f473da2a87d2ad04981199ccf8ba960699ded176a2bd8d1e7bcc545893a7b9, ?*const zx_type_719, };

pub const value_zx_type_720_45da3fe45241c4b458e4f647275889f9f438736171cb17026f282c439662917f = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, bool, ?*const zx_type_720, };

pub const value_zx_type_721_397561f369112e8451b81430ab76000d457c09a5a6343de05cb7cdee82b385fb = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, bool, bool, ?*const zx_type_721, };

pub const value_zx_type_722_936f8be813bc7edb0b0ad706ea01305f77e176b9df2c35b9e9afc2afd78b08d8 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, bool, bool, bool, ?*const zx_type_722, };

pub const value_zx_type_723_adebc148d2999973fe6a59f96bf41ba3ad27c13db7db27556ecebf84ecc976ef = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, bool, bool, bool, value_zx_type_82_28f473da2a87d2ad04981199ccf8ba960699ded176a2bd8d1e7bcc545893a7b9, ?*const zx_type_723, };

pub const value_zx_type_724_e62b5b3f4036127e93b7615ee39c81de9463bcdc168a0352cc5b483470fdc5fd = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, bool, bool, value_zx_type_82_28f473da2a87d2ad04981199ccf8ba960699ded176a2bd8d1e7bcc545893a7b9, ?*const zx_type_724, };

pub const value_zx_type_725_2e70977a634f0cdbc63de55735946305efb367cebafe699f2bf910f1d99a1770 = struct { value_zx_type_81_8d64086a617183b6291d65e91413a46dfca972761c8647c470f0e2c9fc7c7bed, bool, value_zx_type_82_28f473da2a87d2ad04981199ccf8ba960699ded176a2bd8d1e7bcc545893a7b9, ?*const zx_type_725, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
    pub const @"zig:floats" = struct {
        pub const narrow = struct {
            pub const Input = f64;
            pub const Output = f32;
            pub const InputValue = f64;
            pub const OutputValue = f32;
        };
        pub const widen = struct {
            pub const Input = f32;
            pub const Output = f64;
            pub const InputValue = f32;
            pub const OutputValue = f64;
        };
        pub const isFinite = struct {
            pub const Input = f64;
            pub const Output = bool;
            pub const InputValue = f64;
            pub const OutputValue = bool;
        };
        pub const parse32 = struct {
            pub const Input = []const u8;
            pub const Output = ?f32;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f32;
        };
        pub const parse64 = struct {
            pub const Input = []const u8;
            pub const Output = ?f64;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f64;
        };
    };
    pub const @"std:crypto" = struct {
        pub const ScryptOptions = *const zx_type_317;
        pub const sha256 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const sha512 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const timingSafeEqual = struct {
            pub const Input = *const zx_type_318;
            pub const Output = bool;
            pub const InputValue = zx_type_318;
            pub const OutputValue = bool;
        };
        pub const verifyHmacSha256 = struct {
            pub const Input = *const zx_type_319;
            pub const Output = bool;
            pub const InputValue = zx_type_319;
            pub const OutputValue = bool;
        };
        pub const verifyHmacSha512 = struct {
            pub const Input = *const zx_type_319;
            pub const Output = bool;
            pub const InputValue = zx_type_319;
            pub const OutputValue = bool;
        };
        pub const hmacSha256 = struct {
            pub const Input = *const zx_type_320;
            pub const Output = []const u8;
            pub const InputValue = zx_type_320;
            pub const OutputValue = []const u8;
        };
        pub const hmacSha512 = struct {
            pub const Input = *const zx_type_320;
            pub const Output = []const u8;
            pub const InputValue = zx_type_320;
            pub const OutputValue = []const u8;
        };
        pub const hkdfSha256 = struct {
            pub const Input = *const zx_type_321;
            pub const Output = []const u8;
            pub const InputValue = zx_type_321;
            pub const OutputValue = []const u8;
        };
        pub const hkdfSha512 = struct {
            pub const Input = *const zx_type_321;
            pub const Output = []const u8;
            pub const InputValue = zx_type_321;
            pub const OutputValue = []const u8;
        };
        pub const pbkdf2Sha256 = struct {
            pub const Input = *const zx_type_322;
            pub const Output = []const u8;
            pub const InputValue = zx_type_322;
            pub const OutputValue = []const u8;
        };
        pub const pbkdf2Sha512 = struct {
            pub const Input = *const zx_type_322;
            pub const Output = []const u8;
            pub const InputValue = zx_type_322;
            pub const OutputValue = []const u8;
        };
        pub const encryptAes128Gcm = struct {
            pub const Input = *const zx_type_323;
            pub const Output = *const zx_type_324;
            pub const InputValue = zx_type_323;
            pub const OutputValue = zx_type_324;
        };
        pub const decryptAes128Gcm = struct {
            pub const Input = *const zx_type_325;
            pub const Output = []const u8;
            pub const InputValue = zx_type_325;
            pub const OutputValue = []const u8;
        };
        pub const encryptAes256Gcm = struct {
            pub const Input = *const zx_type_323;
            pub const Output = *const zx_type_324;
            pub const InputValue = zx_type_323;
            pub const OutputValue = zx_type_324;
        };
        pub const decryptAes256Gcm = struct {
            pub const Input = *const zx_type_325;
            pub const Output = []const u8;
            pub const InputValue = zx_type_325;
            pub const OutputValue = []const u8;
        };
        pub const encryptChaCha20Poly1305 = struct {
            pub const Input = *const zx_type_323;
            pub const Output = *const zx_type_324;
            pub const InputValue = zx_type_323;
            pub const OutputValue = zx_type_324;
        };
        pub const decryptChaCha20Poly1305 = struct {
            pub const Input = *const zx_type_325;
            pub const Output = []const u8;
            pub const InputValue = zx_type_325;
            pub const OutputValue = []const u8;
        };
        pub const scrypt = struct {
            pub const Input = *const zx_type_317;
            pub const Output = []const u8;
            pub const InputValue = zx_type_317;
            pub const OutputValue = []const u8;
        };
    };
    pub const @"std:encoding" = struct {
        pub const encodeBase64 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeBase64 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const encodeHex = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeHex = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const encodeUtf8 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeUtf8 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const sliceBytes = struct {
            pub const Input = *const zx_type_326;
            pub const Output = []const u8;
            pub const InputValue = zx_type_326;
            pub const OutputValue = []const u8;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
    pub const @"zig:floats" = struct {
    };
    pub const @"std:crypto" = struct {
        pub const ScryptOptions = zx_type_317;
    };
    pub const @"std:encoding" = struct {
    };
};

