pub const zx_type_11 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
};

pub const zx_type_15 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
};

pub const zx_type_16 = struct {
    base: *const zx_type_15,
    delta: *const zx_type_15,
};

pub const zx_type_17 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_18 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_19 = struct {
    base: *const zx_type_18,
    delta: *const zx_type_18,
};

pub const zx_type_20 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_21 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    second: u32,
};

pub const zx_type_22 = enum { Root, Dead, UpperInput, UpperOutput, Underscore, Allocator, Async, Await, Break, Cancel, Case, Concurrent, Const, Declare, Default, Delete, Do, Else, Ensures, Enum, Export, False, For, From, Function, If, Import, In, Insert, Io, Let, Loop, Match, New, Next, Null, Process, QueryMany, QueryOne, Requires, Return, Store, Switch, Throw, Throws, Transaction, True, Try, Type, Update, Var, While, };

pub const zx_type_23 = enum { Identifier, Keyword, Number, String, Template, Punctuation, Eof, };

pub const zx_type_24 = enum { None, OpenBrace, CloseBrace, OpenParen, CloseParen, OpenBracket, CloseBracket, Colon, Semicolon, Comma, Dot, Question, Plus, Minus, Star, Slash, Percent, Less, Greater, Assign, Not, Ampersand, Pipe, Arrow, Equal, NotEqual, LessEqual, GreaterEqual, Coalesce, And, Or, Spread, };

pub const zx_type_25 = struct {
    end: u64,
    start: u64,
};

pub const zx_type_26 = struct {
    dollar: bool,
    kind: zx_type_23,
    line_break: bool,
    span: *const zx_type_25,
    symbol: zx_type_24,
    word: zx_type_22,
};

pub const zx_type_27 = enum { Integer, FractionStart, Fraction, ExponentStart, ExponentDigits, Done, };

pub const zx_type_28 = struct {
    end: u64,
    last_byte: u8,
    phase: zx_type_27,
    separators_valid: bool,
};

pub const zx_type_29 = struct {
    diagnostic: []const u8,
    end: u64,
};

pub const zx_type_30 = enum { Idle, Identifier, Number, String, StringEscape, LineComment, BlockComment, Template, TemplateEscape, Interpolation, InterpolationString, InterpolationStringEscape, InterpolationLineComment, InterpolationBlockComment, };

pub const zx_type_31 = struct {
    code: []const u8,
    end: u64,
    message: []const u8,
    start: u64,
};

pub const zx_type_32 = struct {
    braces: u64,
    depth: u64,
    mode: zx_type_30,
    start: u64,
};

pub const zx_type_36 = struct {
    ahead_one: u8,
    ahead_two: u8,
    braces: u64,
    comments: []const *const zx_type_25,
    depth: u64,
    diagnostic: *const zx_type_31,
    dollar: bool,
    frames: []const *const zx_type_32,
    keyword_state: u64,
    line_break: bool,
    mode: zx_type_30,
    number: *const zx_type_28,
    offset: u64,
    skip_until: u64,
    source_length: u64,
    start: u64,
    symbol: zx_type_24,
    tokens: []const *const zx_type_26,
    warmed: u8,
};

pub const zx_type_37 = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    state: *const zx_type_36,
};

pub const zx_type_38 = struct {
    comments: []const *const zx_type_25,
    diagnostic: *const zx_type_31,
    tokens: []const *const zx_type_26,
};

pub const zx_type_39 = enum { Named, Object, Optional, List, Tuple, Application, };

pub const zx_type_40 = enum { Start, Name, Suffix, ListEnd, Field, FieldOptional, FieldColon, TupleItem, Done, };

pub const zx_type_41 = struct {
    child: u64,
    count: u64,
    head: u64,
    kind: zx_type_39,
    name: *const zx_type_25,
};

pub const zx_type_42 = struct {
    name: *const zx_type_25,
    previous: u64,
    value: u64,
};

pub const zx_type_43 = struct {
    previous: u64,
    value: u64,
};

pub const zx_type_45 = struct {
    fields: []const u64,
    heads: []const u64,
    items: []const u64,
};

pub const zx_type_49 = struct {
    fields: []const *const zx_type_42,
    items: []const *const zx_type_43,
    nodes: []const *const zx_type_41,
};

pub const zx_type_50 = struct {
    count: u64,
    field: *const zx_type_25,
    head: u64,
    kind: zx_type_39,
    name: *const zx_type_25,
    optional: bool,
};

pub const zx_type_51 = struct {
    depth: u64,
    diagnostic: *const zx_type_31,
    index: u64,
    name: *const zx_type_25,
    phase: zx_type_40,
    result: u64,
    start: u64,
    token: *const zx_type_26,
};

pub const zx_type_53 = struct {
    control: *const zx_type_51,
    frames: []const *const zx_type_50,
    tree: *const zx_type_49,
};

pub const zx_type_54 = enum { Start, Kind, Name, Open, Value, Member, Separator, Done, };

pub const zx_type_55 = struct {
    count: u64,
    enumeration: bool,
    first: u64,
    name: *const zx_type_25,
    span: *const zx_type_25,
    value: u64,
};

pub const zx_type_56 = struct {
    count: u64,
    depth: u64,
    diagnostic: *const zx_type_31,
    enumeration: bool,
    first: u64,
    index: u64,
    last_end: u64,
    name: *const zx_type_25,
    opening: u64,
    opening_index: u64,
    phase: zx_type_54,
    start: u64,
    token: *const zx_type_26,
    type_diagnostic: bool,
};

pub const zx_type_58 = struct {
    control: *const zx_type_56,
    declarations: []const *const zx_type_55,
    members: []const *const zx_type_25,
    types: *const zx_type_53,
};

pub const zx_type_59 = enum { Named, Object, Optional, List, Tuple, Enumeration, Application, };

pub const zx_type_60 = struct {
    end: u64,
    start: u64,
    text: []const u8,
};

pub const zx_type_61 = struct {
    enumeration: bool,
    index: u64,
};

pub const zx_type_62 = struct {
    child: *const zx_type_61,
    count: u64,
    kind: zx_type_59,
    name: *const zx_type_60,
    position: u64,
};

pub const zx_type_63 = struct {
    name: *const zx_type_60,
    next: u64,
    value: *const zx_type_61,
};

pub const zx_type_64 = struct {
    next: u64,
    value: *const zx_type_61,
};

pub const zx_type_65 = struct {
    name: *const zx_type_60,
    value: *const zx_type_61,
};

pub const zx_type_66 = struct {
    count: u64,
    first: u64,
};

pub const zx_type_73 = struct {
    declarations: []const *const zx_type_65,
    enumerations: []const *const zx_type_66,
    fields: []const *const zx_type_63,
    items: []const *const zx_type_64,
    members: []const *const zx_type_60,
    nodes: []const *const zx_type_62,
};

pub const zx_type_74 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    members: []const *const zx_type_25,
    order: *const zx_type_45,
    types: *const zx_type_49,
};

pub const zx_type_76 = struct {
    indexed: *const zx_type_74,
    native: ?*const zx_type_73,
};

pub const zx_type_77 = enum { Name, FinishName, Node, Wrap, Tuple, Object, };

pub const zx_type_78 = struct {
    ids: []const u32,
    names: []const []const u8,
};

pub const zx_type_79 = struct {
    aliases: *const zx_type_78,
    base: *const zx_type_18,
    native_interface: bool,
    resolved: *const zx_type_78,
    source: *const zx_type_76,
    visiting: []const []const u8,
};

pub const zx_type_80 = struct {
    children: u64,
    count: u64,
    declaration: *const zx_type_60,
    fields: u64,
    index: u64,
    list: bool,
    name: *const zx_type_60,
    operation: zx_type_77,
    position: u64,
    reference: *const zx_type_61,
    waiting: bool,
};

pub const zx_type_82 = struct {
    active: []const []const u8,
    cache: *const zx_type_78,
    context: *const zx_type_79,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    frames: []const *const zx_type_80,
    result: u32,
    scratch: *const zx_type_20,
};

pub const zx_type_83 = struct {
    cache: *const zx_type_78,
    context: *const zx_type_79,
    delta: *const zx_type_18,
    initialize: bool,
    name: *const zx_type_60,
    named: bool,
    reference: *const zx_type_61,
};

pub const zx_type_84 = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
};

pub const zx_type_85 = enum { Text, Expression, };

pub const zx_type_86 = enum { TemplateOpen, TemplateClose, InterpolationOpen, InterpolationClose, };

pub const zx_type_87 = struct {
    count: u64,
    head: u64,
    span: *const zx_type_25,
};

pub const zx_type_88 = struct {
    interpolation: u64,
    kind: zx_type_85,
    previous: u64,
    span: *const zx_type_25,
};

pub const zx_type_89 = struct {
    kind: zx_type_86,
    offset: u64,
    reference: u64,
};

pub const zx_type_93 = struct {
    events: []const *const zx_type_89,
    lexed: *const zx_type_38,
    parts: []const *const zx_type_88,
    templates: []const *const zx_type_87,
    token_templates: []const u64,
};

pub const zx_type_94 = struct {
    lexed: *const zx_type_38,
    span: *const zx_type_25,
    token_templates: []const u64,
};

pub const zx_type_96 = struct {
    interpolations: []const *const zx_type_94,
    lexed: *const zx_type_38,
    parts: []const *const zx_type_88,
    templates: []const *const zx_type_87,
    token_templates: []const u64,
};

pub const zx_type_97 = enum { None, Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, And, Or, };

pub const zx_type_98 = enum { None, Coalesce, Logical, };

pub const zx_type_99 = struct {
    family: zx_type_98,
    operator: zx_type_97,
    precedence: u8,
};

pub const zx_type_100 = struct {
    binary: *const zx_type_99,
    generic: bool,
    lambda: bool,
};

pub const zx_type_102 = struct {
    after_identifier: bool,
    arrow: bool,
    hints: []const *const zx_type_100,
    parameter_start: bool,
};

pub const zx_type_104 = struct {
    hints: []const *const zx_type_100,
    interpolation_hints: []const []const *const zx_type_100,
    lexical: *const zx_type_96,
};

pub const zx_type_105 = enum { Number, String, Boolean, Null, Identifier, Field, Index, List, Call, Lambda, Template, Unary, Binary, Conditional, Match, Object, StateBlock, Capture, Async, Await, Cancel, };

pub const zx_type_106 = enum { BeginBinary, Primary, Postfix, Returning, FieldName, Arguments, ObjectName, ObjectColon, LambdaParameter, LambdaSeparator, LambdaArrow, LambdaBody, Callback, StateBlock, MatchStart, MatchCondition, MatchFallbackArrow, MatchEnd, GenericType, GenericCall, TemplateGather, TemplatePart, Done, };

pub const zx_type_107 = enum { BinaryLeft, BinaryRight, Unary, Group, Index, Arguments, ObjectValue, OptionsValue, Lambda, ConditionalYes, ConditionalNo, MatchSubject, MatchCondition, MatchResult, MatchFallback, Template, TemplatePart, Interpolation, Capture, Async, Await, Cancel, };

pub const zx_type_108 = struct {
    count: u64,
    depth: u64,
    first: u64,
    flag: bool,
    head: u64,
    kind: zx_type_105,
    name: *const zx_type_25,
    operator: zx_type_97,
    second: u64,
    span: *const zx_type_25,
    third: u64,
    type_argument: u64,
};

pub const zx_type_109 = struct {
    name: *const zx_type_25,
    previous: u64,
    spread: bool,
    value: u64,
};

pub const zx_type_110 = struct {
    name: *const zx_type_25,
    previous: u64,
};

pub const zx_type_111 = struct {
    expression: bool,
    previous: u64,
    span: *const zx_type_25,
    value: u64,
};

pub const zx_type_112 = struct {
    condition: u64,
    previous: u64,
    result: u64,
};

pub const zx_type_118 = struct {
    arms: []const *const zx_type_112,
    fields: []const *const zx_type_109,
    items: []const *const zx_type_43,
    nodes: []const *const zx_type_108,
    parameters: []const *const zx_type_110,
    parts: []const *const zx_type_111,
};

pub const zx_type_119 = struct {
    allow_lambda: bool,
    callback: bool,
    condition: bool,
    count: u64,
    cursor: u64,
    depth: u64,
    end: u64,
    family: zx_type_98,
    first: u64,
    flag: bool,
    head: u64,
    index: u64,
    kind: zx_type_107,
    maximum: u64,
    minimum: u8,
    name: *const zx_type_25,
    operator: zx_type_97,
    reset_family: bool,
    second: u64,
    start: u64,
    stream: u64,
};

pub const zx_type_120 = struct {
    allow_lambda: bool,
    base_depth: u64,
    cursor: u64,
    depth: u64,
    diagnostic: *const zx_type_31,
    family: zx_type_98,
    fresh_family: bool,
    hint: *const zx_type_100,
    index: u64,
    last_end: u64,
    lexical_diagnostic: u64,
    minimum: u8,
    phase: zx_type_106,
    primary_start: u64,
    result: u64,
    root_index: u64,
    stream: u64,
    template: u64,
    template_count: u64,
    template_head: u64,
    template_maximum: u64,
    token: *const zx_type_26,
    type_argument: u64,
    type_diagnostic: bool,
};

pub const zx_type_122 = struct {
    control: *const zx_type_120,
    frames: []const *const zx_type_119,
    prepared: *const zx_type_104,
    tree: *const zx_type_118,
    types: *const zx_type_53,
};

pub const zx_type_123 = enum { Constant, Destructure, Result, Branch, Switch, StoreSet, Evaluate, StateUpdate, };

pub const zx_type_124 = enum { Root, Block, Statement, Case, };

pub const zx_type_125 = enum { BlockOpen, BlockNext, Statement, ConstName, ConstAfterName, PatternName, PatternSeparator, ConstAssign, ReturnValue, IfOpen, IfClose, IfElse, IfAlternative, SwitchOpen, SwitchClose, SwitchBrace, SwitchCase, CaseColon, CaseBody, CaseNext, StoreAssign, UpdateOperator, UpdateAssign, BeginValue, BeginCondition, BeginSwitch, BeginCase, Value, Expression, Type, EndStatement, Publish, Resume, Done, };

pub const zx_type_126 = struct {
    annotation: u64,
    count: u64,
    first: u64,
    head: u64,
    kind: zx_type_123,
    name: *const zx_type_25,
    operator: zx_type_97,
    second: u64,
    span: *const zx_type_25,
    third: u64,
};

pub const zx_type_127 = struct {
    previous: u64,
    span: *const zx_type_25,
};

pub const zx_type_128 = struct {
    body: u64,
    previous: u64,
    span: *const zx_type_25,
    value: u64,
};

pub const zx_type_132 = struct {
    blocks: []const *const zx_type_87,
    cases: []const *const zx_type_128,
    items: []const *const zx_type_43,
    names: []const *const zx_type_127,
    statements: []const *const zx_type_126,
};

pub const zx_type_133 = struct {
    annotation: u64,
    count: u64,
    depth: u64,
    first: u64,
    head: u64,
    kind: zx_type_124,
    name: *const zx_type_25,
    operator: zx_type_97,
    phase: zx_type_125,
    second: u64,
    start: u64,
    statement: zx_type_123,
    third: u64,
};

pub const zx_type_134 = struct {
    diagnostic: *const zx_type_31,
    expression_diagnostic: bool,
    phase: zx_type_125,
    result: u64,
    @"resume": zx_type_125,
    state_block: bool,
};

pub const zx_type_136 = struct {
    control: *const zx_type_134,
    expression: *const zx_type_120,
    expression_frames: []const *const zx_type_119,
    frame: *const zx_type_133,
    frames: []const *const zx_type_133,
};

pub const zx_type_138 = struct {
    control: *const zx_type_134,
    expression: *const zx_type_122,
    frame: *const zx_type_133,
    frames: []const *const zx_type_133,
    suspended: []const *const zx_type_136,
    tree: *const zx_type_132,
};

pub const zx_type_139 = enum { Open, Input, Colon, InputName, ParameterEnd, StoreOpen, StoreName, StoreClose, StoreEnd, Close, ResultColon, ResultName, Contract, ContractOpen, Predicate, ContractClose, Done, };

pub const zx_type_140 = struct {
    ensures: bool,
    predicate: u64,
    span: *const zx_type_25,
};

pub const zx_type_141 = struct {
    contract_start: u64,
    diagnostic: *const zx_type_31,
    ensures: bool,
    expression_diagnostic: bool,
    has_ensures: bool,
    has_store: bool,
    phase: zx_type_139,
    token: *const zx_type_26,
};

pub const zx_type_143 = struct {
    body: *const zx_type_132,
    contracts: []const *const zx_type_140,
    control: *const zx_type_141,
    expression: *const zx_type_122,
};

pub const zx_type_144 = enum { Start, Binding, Name, Separator, From, Path, End, Done, };

pub const zx_type_145 = enum { Function, Enumeration, TypeOnly, };

pub const zx_type_146 = struct {
    count: u64,
    first: u64,
    kind: zx_type_145,
    path: *const zx_type_25,
    span: *const zx_type_25,
};

pub const zx_type_147 = struct {
    count: u64,
    diagnostic: *const zx_type_31,
    first: u64,
    index: u64,
    named: bool,
    opening: *const zx_type_25,
    path: *const zx_type_25,
    phase: zx_type_144,
    start: u64,
    token: *const zx_type_26,
    type_only: bool,
};

pub const zx_type_149 = struct {
    control: *const zx_type_147,
    imports: []const *const zx_type_146,
    names: []const *const zx_type_25,
};

pub const zx_type_151 = struct {
    blocks: *const zx_type_132,
    body: ?u64,
    comments: []const *const zx_type_25,
    contracts: []const *const zx_type_140,
    declarations: []const *const zx_type_55,
    diagnostic: *const zx_type_31,
    expressions: *const zx_type_118,
    function_start: u64,
    has_store: bool,
    import_names: []const *const zx_type_25,
    imports: []const *const zx_type_146,
    members: []const *const zx_type_25,
    tokens: []const *const zx_type_26,
    type_order: *const zx_type_45,
    types: *const zx_type_49,
};

pub const zx_type_152 = struct {
    blocks: *const zx_type_132,
    comments: []const *const zx_type_25,
    diagnostic: *const zx_type_31,
    expressions: *const zx_type_118,
    result: u64,
    tokens: []const *const zx_type_26,
    type_order: *const zx_type_45,
    types: *const zx_type_49,
};

pub const zx_type_153 = struct {
    aliases: *const zx_type_78,
    bytes: []const u8,
    nominal_base: *const zx_type_15,
    nominal_origin: *const zx_type_11,
    shared: bool,
    syntax: *const zx_type_151,
    type_base: *const zx_type_18,
};

pub const zx_type_154 = struct {
    origin: *const zx_type_11,
    origins: *const zx_type_15,
    request: *const zx_type_83,
    shared: bool,
};

pub const zx_type_155 = struct {
    name: *const zx_type_60,
    operation: zx_type_77,
    reference: *const zx_type_61,
};

pub const zx_type_156 = struct {
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_157 = struct {
    code: []const u8,
    message: []const u8,
    name: *const zx_type_60,
    state: *const zx_type_82,
};

pub const zx_type_158 = struct { []const u8, u64, u64, };

pub const zx_type_159 = struct {
    source: []const u8,
    span: *const zx_type_25,
};

pub const zx_type_160 = struct {
    index: u64,
    source: *const zx_type_76,
};

pub const zx_type_161 = struct {
    limit: u64,
    name: []const u8,
    source: *const zx_type_76,
};

pub const zx_type_162 = struct {
    found: bool,
    index: u64,
};

pub const zx_type_163 = struct {
    index: u64,
    state: *const zx_type_82,
};

pub const zx_type_164 = struct {
    children: []const u32,
    fields: *const zx_type_20,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_165 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_166 = struct {
    delta: *const zx_type_18,
    id: u32,
};

pub const zx_type_167 = struct {
    children: []const u32,
    count: u64,
    field_names: []const []const u8,
    field_types: []const u32,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    names: []const []const u8,
    offset: u64,
    second: u32,
};

pub const zx_type_168 = struct {
    left: *const zx_type_167,
    right: *const zx_type_167,
};

pub const zx_type_169 = struct {
    index: u64,
    table: *const zx_type_18,
};

pub const zx_type_170 = struct {
    candidate: *const zx_type_164,
    id: u32,
    tables: *const zx_type_19,
};

pub const zx_type_171 = struct {
    candidate: *const zx_type_164,
    tables: *const zx_type_19,
};

pub const zx_type_172 = struct {
    candidate: *const zx_type_164,
    delta: *const zx_type_18,
};

pub const zx_type_173 = struct {
    left: []const u8,
    right: []const u8,
};

pub const zx_type_174 = struct {
    code: []const u8,
    message: []const u8,
};

pub const zx_type_175 = struct {
    candidate: *const zx_type_164,
    table: *const zx_type_18,
};

pub const zx_type_176 = struct {
    delta: *const zx_type_18,
    diagnostic: *const zx_type_174,
    id: u32,
};

pub const zx_type_177 = struct {
    id: u32,
    tables: *const zx_type_19,
};

pub const zx_type_179 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: *const zx_type_19,
};

pub const zx_type_180 = struct {
    id: u32,
    native_references: bool,
    tables: *const zx_type_19,
};

pub const zx_type_181 = enum { None, TaskContainer, VoidList, TaskTuple, TaskObject, };

pub const zx_type_182 = struct {
    candidate: *const zx_type_164,
    state: *const zx_type_82,
};

pub const zx_type_183 = struct {
    enumeration: u64,
    index: u64,
    source: *const zx_type_76,
};

pub const zx_type_184 = struct {
    reference: *const zx_type_61,
    source: *const zx_type_76,
};

pub const zx_type_185 = struct {
    cache: *const zx_type_78,
    name: []const u8,
};

pub const zx_type_186 = struct {
    frame: *const zx_type_80,
    state: *const zx_type_82,
};

pub const zx_type_187 = struct {
    position: u64,
    source: *const zx_type_76,
};

pub const zx_type_188 = enum { Missing, Found, Conflict, };

pub const zx_type_189 = struct {
    id: u32,
    status: zx_type_188,
};

pub const zx_type_190 = struct {
    base: *const zx_type_18,
    delta: *const zx_type_18,
    origin: *const zx_type_11,
    origins: *const zx_type_15,
};

pub const zx_type_191 = struct {
    conflict: bool,
    delta: *const zx_type_18,
    mapping: []const u32,
    origins: *const zx_type_15,
};

pub const zx_type_192 = struct {
    first: u64,
    ids: []const u32,
};

pub const zx_type_193 = struct {
    id: u32,
    mapping: *const zx_type_192,
};

pub const zx_type_194 = struct {
    delta: *const zx_type_18,
    mapping: *const zx_type_192,
    source: *const zx_type_167,
};

pub const zx_type_195 = struct {
    mapping: *const zx_type_192,
    source: *const zx_type_167,
    target: *const zx_type_167,
};

pub const zx_type_196 = struct {
    mapping: *const zx_type_192,
    origin: *const zx_type_11,
    origins: *const zx_type_16,
    source: *const zx_type_167,
    tables: *const zx_type_19,
};

pub const zx_type_197 = struct {
    cache: *const zx_type_78,
    mapping: *const zx_type_192,
};

pub const zx_type_198 = struct {
    cache: *const zx_type_78,
    context: *const zx_type_79,
    delta: *const zx_type_18,
    nominal_delta: *const zx_type_15,
};

pub const zx_type_199 = struct {
    diagnostic: *const zx_type_31,
    input_type: u32,
    output_type: u32,
    span: *const zx_type_25,
    types: *const zx_type_198,
};

pub const zx_type_200 = struct {
    syntax: *const zx_type_151,
    types: *const zx_type_198,
};

pub const zx_type_201 = struct {
    name: []const u8,
    span: *const zx_type_25,
    types: *const zx_type_198,
};

pub const zx_type_202 = struct {
    name: []const u8,
    types: *const zx_type_198,
};

pub const zx_type_203 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_204 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_205 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_206 = enum { Negate, Not, };

pub const zx_type_207 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_216 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_207,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_204,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_203,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_205,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_206,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_217 = enum { Copy, Borrowed, Owned, };

pub const zx_type_219 = struct {
    names: []const []const u8,
    ownership: []const zx_type_217,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_220 = enum { Requires, Ensures, };

pub const zx_type_224 = struct {
    expressions: []const *const zx_type_216,
    kinds: []const zx_type_220,
    predicates: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    symbols: []const *const zx_type_219,
};

pub const zx_type_225 = enum { Evaluate, Constant, Parallel, Destructure, Branch, Switch, StoreSet, Result, };

pub const zx_type_227 = struct {
    block_count: []const u32,
    block_first: []const u32,
    branch_conditions: []const u32,
    branch_no: []const u32,
    branch_yes: []const u32,
    case_bodies: []const u32,
    case_values: []const ?u32,
    constant_symbols: []const u32,
    constant_values: []const u32,
    destructure_count: []const u32,
    destructure_first: []const u32,
    destructure_symbols: []const ?u32,
    destructure_values: []const u32,
    evaluations: []const u32,
    parallel_count: []const u32,
    parallel_first: []const u32,
    parallel_symbols: []const ?u32,
    parallel_values: []const u32,
    results: []const ?u32,
    selection_count: []const u32,
    selection_exhaustive: []const bool,
    selection_first: []const u32,
    selection_subjects: []const u32,
    setter_slots: []const u32,
    setter_values: []const u32,
    statement_kinds: []const zx_type_225,
    statement_payloads: []const u32,
};

pub const zx_type_235 = struct {
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_217,
};

pub const zx_type_236 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_240 = struct {
    contracts: []const *const zx_type_224,
    control: []const *const zx_type_227,
    expressions: []const *const zx_type_216,
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_fallible: []const bool,
    native_modules: []const ?u32,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_217,
    roots: []const ?u32,
    stores: []const *const zx_type_236,
};

pub const zx_type_241 = struct {
    ids: []const u32,
    input_types: []const u32,
    names: []const []const u8,
    namespaces: []const ?[]const u8,
    output_types: []const u32,
};

pub const zx_type_242 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    type_ids: []const ?u32,
    type_names: []const ?[]const u8,
    writable: []const bool,
};

pub const zx_type_243 = struct {
    aliases: *const zx_type_78,
    function_imports: *const zx_type_241,
    functions: *const zx_type_240,
    nominal_base: *const zx_type_15,
    nominal_origin: *const zx_type_11,
    shared: bool,
    store_bindings: *const zx_type_242,
    store_type_count: u64,
    type_base: *const zx_type_18,
};

pub const zx_type_244 = struct {
    bytes: []const u8,
    context: *const zx_type_243,
    file_name: []const u8,
    syntax: *const zx_type_151,
};

pub const zx_type_245 = struct {
    bindings: *const zx_type_242,
    index: u64,
    type_count: u64,
    types: *const zx_type_198,
};

pub const zx_type_246 = struct {
    code: []const u8,
    id: u32,
    message: []const u8,
};

pub const zx_type_247 = struct {
    context: *const zx_type_243,
    signature: *const zx_type_199,
};

pub const zx_type_248 = struct {
    diagnostic: *const zx_type_31,
    stores: *const zx_type_236,
};

pub const zx_type_249 = struct {
    has_store: bool,
    span: *const zx_type_25,
    stores: *const zx_type_236,
};

pub const zx_type_250 = struct {
    allow_store: bool,
    diagnostic: *const zx_type_31,
    stores: *const zx_type_236,
};

pub const zx_type_251 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
};

pub const zx_type_252 = struct {
    captures: u64,
    nonnull: u64,
};

pub const zx_type_253 = struct {
    conditions: []const u64,
    facts: *const zx_type_251,
    truths: []const bool,
};

pub const zx_type_254 = struct {
    first: []const ?u32,
    floors: []const u64,
    last: []const ?u32,
    parents: []const ?u32,
    starts: []const u64,
};

pub const zx_type_255 = struct {
    next: []const ?u32,
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
};

pub const zx_type_256 = struct {
    bindings: *const zx_type_255,
    current: ?u32,
    frames: *const zx_type_254,
};

pub const zx_type_257 = struct {
    active: []const u32,
    allow_store: bool,
    captures: *const zx_type_256,
    control: *const zx_type_227,
    expression_bindings: []const u32,
    expression_units: []const []const u8,
    expressions: *const zx_type_216,
    lambda_depth: u64,
    output_type: u32,
    refinement: *const zx_type_253,
    scope_floor: u64,
    stores: *const zx_type_236,
    symbols: *const zx_type_219,
};

pub const zx_type_258 = struct {
    allow_store: bool,
    signature: *const zx_type_199,
    stores: *const zx_type_236,
};

pub const zx_type_259 = struct {
    name: []const u8,
    ownership: zx_type_217,
    span_end: u64,
    span_start: u64,
    table: *const zx_type_219,
    type_id: u32,
};

pub const zx_type_260 = struct {
    id: u32,
    table: *const zx_type_219,
};

pub const zx_type_261 = struct {
    local: *const zx_type_257,
    name: *const zx_type_60,
    scope_start: u64,
    type_id: u32,
};

pub const zx_type_262 = struct {
    diagnostic: *const zx_type_31,
    id: u32,
    local: *const zx_type_257,
};

pub const zx_type_263 = struct {
    diagnostic: *const zx_type_31,
    input_type: u32,
    local: *const zx_type_257,
    types: *const zx_type_198,
};

pub const zx_type_264 = struct {
    diagnostic: *const zx_type_31,
    module: *const zx_type_244,
    types: *const zx_type_198,
};

pub const zx_type_265 = struct {
    contracts: *const zx_type_224,
    names: []const []const u8,
    ownership: zx_type_217,
    root: ?u32,
    state: *const zx_type_263,
    type_only: bool,
    types: []const u32,
};

pub const zx_type_266 = struct {
    state: *const zx_type_263,
    type_only: bool,
};

pub const zx_type_267 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_216,
    limit: u64,
};

pub const zx_type_268 = struct {
    expressions: []const *const zx_type_216,
    native_concurrent: []const bool,
    native_modules: []const ?u32,
    stores: []const *const zx_type_236,
};

pub const zx_type_269 = struct {
    concurrent: bool,
    functions: *const zx_type_268,
};

pub const zx_type_270 = struct {
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
};

pub const zx_type_271 = struct {
    body: u32,
    captures: *const zx_type_270,
    parameters: []const u32,
};

pub const zx_type_272 = struct {
    borrows: []const bool,
    symbols: []const ?u32,
    values: []const u32,
};

pub const zx_type_273 = struct {
    callback: *const zx_type_271,
    ignored: ?u32,
    initial: ?u32,
    kind: zx_type_205,
    result_type: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
    target: u32,
};

pub const zx_type_274 = struct {
    arguments: []const u64,
    capture_frame: u32,
    expected: ?u32,
    kind: zx_type_205,
    node: u64,
    parameters: []const u32,
    result_type: u32,
    second: ?u32,
    target: u32,
};

pub const zx_type_275 = struct {
    active: u64,
    captures: ?u32,
    depth: u64,
    floor: u64,
};

pub const zx_type_276 = struct {
    condition: u32,
    condition_node: u64,
    condition_parameter: u32,
    context: *const zx_type_275,
    initial: u32,
    initial_node: u64,
    node: u64,
    parameter: u32,
    postcondition: bool,
    step_node: u64,
};

pub const zx_type_277 = struct {
    expression: u32,
    read_value: bool,
};

pub const zx_type_278 = struct {
    index: u32,
    kind: zx_type_203,
    value: u32,
};

pub const zx_type_280 = struct {
    places: []const *const zx_type_278,
    statement: u64,
    target: u32,
};

pub const zx_type_281 = struct {
    condition: u32,
    mark: *const zx_type_252,
    state_symbol: u32,
    statement: u64,
    yes: u32,
};

pub const zx_type_282 = struct {
    cases: []const u64,
    conditions: []const u32,
    fallback: ?u32,
    index: u64,
    results: []const u32,
    state_symbol: u32,
    statement: u64,
    subject: u32,
};

pub const zx_type_283 = struct {
    active_mark: u64,
    binding_mark: u64,
    facts_mark: *const zx_type_252,
    next: u64,
    source_block: u64,
    state_symbol: u32,
    statements: []const u64,
};

pub const zx_type_285 = struct {
    bindings: *const zx_type_272,
    frames: []const *const zx_type_283,
};

pub const zx_type_286 = struct {
    names: []const []const u8,
    values: []const u32,
};

pub const zx_type_287 = struct {
    blocks: *const zx_type_132,
    bytes: []const u8,
    tree: *const zx_type_118,
};

pub const zx_type_288 = struct {
    expected: ?u32,
    node: u64,
    source: *const zx_type_287,
    state: *const zx_type_263,
};

pub const zx_type_289 = enum { Evaluate, Complete, StateBlock, ScopeNext, StateSwitch, Done, };

pub const zx_type_290 = enum { Coerce, Unary, Field, IndexTarget, IndexValue, BinaryLeft, BinaryRight, Condition, Yes, No, MatchSubject, MatchCondition, MatchResult, MatchFallback, Sequence, Object, Imported, MethodTarget, ListArgument, Template, TaskValue, CaptureValue, AsyncBody, ParallelBody, TransformSecond, TransformBody, IterationInitial, IterationCondition, IterationStep, StateEvaluate, StateConstant, StateDestructure, StateTarget, StateValue, StateCondition, StateYes, StateNo, StateSubject, StateLabel, StateCase, };

pub const zx_type_291 = struct {
    expected: u32,
    span: *const zx_type_25,
};

pub const zx_type_292 = struct {
    node: u64,
    target: u32,
};

pub const zx_type_293 = struct {
    left: u32,
    mark: *const zx_type_252,
    node: u64,
};

pub const zx_type_294 = struct {
    condition: u32,
    expected: ?u32,
    mark: *const zx_type_252,
    node: u64,
    yes: u32,
};

pub const zx_type_295 = struct {
    arms: []const u64,
    conditions: []const u32,
    expected: ?u32,
    index: u64,
    node: u64,
    results: []const u32,
    subject: ?u32,
};

pub const zx_type_296 = struct {
    element: ?u32,
    index: u64,
    items: []const u64,
    node: u64,
    tuple: ?u32,
    values: []const u32,
};

pub const zx_type_297 = struct {
    entries: *const zx_type_286,
    evaluation: []const u32,
    fields: []const u64,
    hint: ?u32,
    index: u64,
    node: u64,
};

pub const zx_type_298 = struct {
    arguments: []const u64,
    import_index: u64,
    index: u64,
    node: u64,
    tuple: bool,
    values: []const u32,
};

pub const zx_type_299 = struct {
    expected: ?u32,
    node: u64,
    target: u32,
};

pub const zx_type_300 = struct {
    arguments: []const u64,
    hints: []const u32,
    index: u64,
    kind: zx_type_204,
    node: u64,
    replacement: bool,
    target: u32,
    values: []const u32,
};

pub const zx_type_301 = struct {
    index: u64,
    node: u64,
    parts: []const u64,
    values: []const u32,
};

pub const zx_type_302 = struct {
    active: u64,
    captures: ?u32,
    depth: u64,
    facts: *const zx_type_252,
    floor: u64,
};

pub const zx_type_303 = struct {
    first: u64,
    node: u64,
    symbol_count: u64,
};

pub const zx_type_304 = struct {
    fields: []const u64,
    first: u64,
    index: u64,
    names: []const []const u8,
    node: u64,
    symbol_count: u64,
    tasks: []const u32,
    type_names: []const []const u8,
    types: []const u32,
};

pub const zx_type_324 = struct {
    actions: []const zx_type_290,
    asynchronous: []const *const zx_type_303,
    binaries: []const *const zx_type_293,
    branches: []const *const zx_type_281,
    coercions: []const *const zx_type_291,
    conditionals: []const *const zx_type_294,
    imported: []const *const zx_type_298,
    indices: []const *const zx_type_292,
    iterations: []const *const zx_type_276,
    lists: []const *const zx_type_300,
    methods: []const *const zx_type_299,
    objects: []const *const zx_type_297,
    parallels: []const *const zx_type_304,
    selections: []const *const zx_type_295,
    sequences: []const *const zx_type_296,
    singles: []const u64,
    statements: []const u64,
    switches: []const *const zx_type_282,
    templates: []const *const zx_type_301,
    transforms: []const *const zx_type_274,
    updates: []const *const zx_type_280,
};

pub const zx_type_325 = struct {
    boundary: *const zx_type_302,
    concurrent: []const bool,
    expected: ?u32,
    frames: *const zx_type_324,
    functions: *const zx_type_240,
    imports: *const zx_type_241,
    node: u64,
    phase: zx_type_289,
    scopes: *const zx_type_285,
    source: *const zx_type_287,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_326 = struct {
    functions: *const zx_type_240,
    imports: *const zx_type_241,
    request: *const zx_type_288,
};

pub const zx_type_327 = struct {
    blocks: u64,
    branches: u64,
    cases: u64,
    constants: u64,
    destructure_symbols: u64,
    destructures: u64,
    evaluations: u64,
    parallel_values: u64,
    parallels: u64,
    results: u64,
    selections: u64,
    setters: u64,
    statements: u64,
};

pub const zx_type_328 = struct {
    count: u64,
    head: u64,
    items: []const *const zx_type_43,
};

pub const zx_type_329 = struct {
    active_mark: u64,
    facts_mark: *const zx_type_252,
    next: u64,
    pending_mark: *const zx_type_327,
    source_block: u64,
    statements: []const u64,
};

pub const zx_type_331 = struct {
    frames: []const *const zx_type_329,
    pending: *const zx_type_227,
    returns: []const bool,
};

pub const zx_type_332 = struct {
    block: u64,
    blocks: *const zx_type_331,
    local: *const zx_type_257,
    tree: *const zx_type_132,
};

pub const zx_type_333 = enum { Next, Expression, Resume, Selection, Done, };

pub const zx_type_334 = enum { Constant, Destructure, Evaluate, Result, Setter, Condition, Yes, No, Subject, Label, Case, };

pub const zx_type_335 = struct {
    condition: u32,
    mark: *const zx_type_252,
    statement: u64,
    yes: u32,
};

pub const zx_type_336 = struct {
    bodies: []const u32,
    cases: []const u64,
    fallback: bool,
    index: u64,
    labels: []const u32,
    statement: u64,
    subject: u32,
    values: []const ?u32,
};

pub const zx_type_340 = struct {
    actions: []const zx_type_334,
    blocks: *const zx_type_331,
    branches: []const *const zx_type_335,
    expression: *const zx_type_325,
    phase: zx_type_333,
    selections: []const *const zx_type_336,
    slot: u32,
    statement: u64,
    value: u32,
};

pub const zx_type_341 = struct {
    block: u64,
    functions: *const zx_type_240,
    imports: *const zx_type_241,
    source: *const zx_type_287,
    state: *const zx_type_263,
};

pub const zx_type_342 = struct {
    span_end: u64,
    span_start: u64,
    type_id: u32,
};

pub const zx_type_343 = struct {
    id: u32,
    table: *const zx_type_216,
};

pub const zx_type_344 = enum { Some, Capture, AwaitTask, CancelTask, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Length, };

pub const zx_type_345 = enum { List, Tuple, Template, };

pub const zx_type_346 = struct {
    kind: zx_type_203,
    metadata: *const zx_type_342,
    payload: u32,
    table: *const zx_type_216,
};

pub const zx_type_347 = struct {
    kind: zx_type_344,
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    value: u32,
};

pub const zx_type_348 = struct {
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_349 = struct {
    expected: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_350 = struct {
    body: u32,
    captures: []const u32,
    metadata: *const zx_type_342,
    table: *const zx_type_216,
};

pub const zx_type_351 = struct {
    candidate: *const zx_type_164,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_352 = struct {
    id: u32,
    state: *const zx_type_263,
};

pub const zx_type_353 = struct {
    count: u64,
    slots: []const u64,
};

pub const zx_type_354 = enum { Expression, Function, Block, };

pub const zx_type_355 = struct {
    count: u64,
    index: u64,
    operation: zx_type_354,
    source: u64,
};

pub const zx_type_356 = struct {
    control: *const zx_type_227,
    expressions: *const zx_type_216,
    returns: []const bool,
    visited: *const zx_type_353,
};

pub const zx_type_357 = struct {
    functions: *const zx_type_240,
    types: *const zx_type_19,
};

pub const zx_type_360 = struct {
    called: *const zx_type_353,
    context: *const zx_type_357,
    frames: []const *const zx_type_355,
    names: []const []const u8,
    sources: []const *const zx_type_356,
    unknown: bool,
};

pub const zx_type_361 = struct {
    context: *const zx_type_357,
    contracts: *const zx_type_224,
    control: *const zx_type_227,
    expression: u32,
    expressions: *const zx_type_216,
    program: bool,
    root: ?u32,
    stores: bool,
};

pub const zx_type_362 = struct {
    control: *const zx_type_227,
    returns: []const bool,
    selection: u64,
};

pub const zx_type_363 = struct {
    control: *const zx_type_227,
    expressions: *const zx_type_216,
    state: *const zx_type_360,
};

pub const zx_type_364 = struct {
    source: u64,
    state: *const zx_type_360,
};

pub const zx_type_365 = struct {
    contracts: *const zx_type_224,
    state: *const zx_type_360,
};

pub const zx_type_366 = struct {
    frame: *const zx_type_355,
    state: *const zx_type_360,
};

pub const zx_type_367 = struct {
    id: u32,
    seen: *const zx_type_353,
};

pub const zx_type_368 = struct {
    fresh: bool,
    seen: *const zx_type_353,
};

pub const zx_type_369 = struct {
    expressions: *const zx_type_216,
    index: u64,
};

pub const zx_type_370 = struct {
    names: []const []const u8,
    tables: *const zx_type_19,
    type_id: u32,
};

pub const zx_type_371 = struct {
    expressions: *const zx_type_216,
    index: u64,
    names: []const []const u8,
    tables: *const zx_type_19,
};

pub const zx_type_372 = struct {
    index: u64,
    state: *const zx_type_360,
};

pub const zx_type_373 = struct {
    functions: *const zx_type_240,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_374 = struct {
    concurrent: []const bool,
    first: u64,
    span: *const zx_type_25,
    state: *const zx_type_263,
    symbol_count: u64,
};

pub const zx_type_375 = struct {
    captures: []const u32,
    state: *const zx_type_263,
};

pub const zx_type_376 = struct {
    body: u32,
    concurrent: []const bool,
    first: u64,
    functions: *const zx_type_240,
    span: *const zx_type_25,
    state: *const zx_type_263,
    symbol_count: u64,
};

pub const zx_type_377 = struct {
    facts: *const zx_type_251,
    mark: *const zx_type_252,
};

pub const zx_type_378 = struct {
    left: u32,
    metadata: *const zx_type_342,
    operator: zx_type_207,
    right: u32,
    table: *const zx_type_216,
};

pub const zx_type_379 = struct {
    comparison: bool,
    equality: bool,
    logical: bool,
};

pub const zx_type_380 = struct {
    tables: *const zx_type_19,
    type_id: u32,
};

pub const zx_type_381 = struct {
    left: u32,
    operator: zx_type_207,
    right: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_382 = struct {
    facts: *const zx_type_251,
    symbol: u32,
};

pub const zx_type_383 = struct {
    expressions: *const zx_type_216,
    facts: *const zx_type_251,
    payload: u64,
    truth: bool,
};

pub const zx_type_384 = struct {
    condition: u64,
    expressions: *const zx_type_216,
    state: *const zx_type_253,
    truth: bool,
};

pub const zx_type_385 = struct {
    left: u32,
    operator: zx_type_207,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_386 = struct {
    expected: u32,
    state: *const zx_type_263,
};

pub const zx_type_387 = struct {
    action: zx_type_290,
    work: *const zx_type_325,
};

pub const zx_type_388 = struct {
    count: u64,
    element: u32,
    list: u32,
    name: []const u8,
};

pub const zx_type_389 = struct {
    code: []const u8,
    hints: []const u32,
    kind: zx_type_204,
    message: []const u8,
    replacement: bool,
};

pub const zx_type_390 = struct {
    head: u64,
    items: []const *const zx_type_43,
};

pub const zx_type_391 = struct {
    arguments: []const u32,
    kind: zx_type_204,
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    target: u32,
};

pub const zx_type_392 = struct {
    index: u32,
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    target: u32,
    value: u32,
};

pub const zx_type_393 = struct {
    kind: zx_type_204,
    replacement: bool,
    span: *const zx_type_25,
    state: *const zx_type_263,
    target: u32,
    values: []const u32,
};

pub const zx_type_394 = struct {
    expected: ?u32,
    types: *const zx_type_198,
};

pub const zx_type_395 = struct {
    frame: u32,
    local: *const zx_type_257,
};

pub const zx_type_396 = struct {
    node: u64,
    source: *const zx_type_287,
    state: *const zx_type_263,
    types: []const u32,
};

pub const zx_type_397 = struct {
    body: u64,
    frame: u32,
    parameters: []const u32,
    state: *const zx_type_263,
};

pub const zx_type_398 = struct {
    expected: ?u32,
    kind: zx_type_205,
    second: ?u32,
    state: *const zx_type_263,
    target: u32,
};

pub const zx_type_399 = struct {
    body: ?u32,
    parameters: []const u32,
    result: u32,
};

pub const zx_type_400 = struct {
    name: []const u8,
    work: *const zx_type_325,
};

pub const zx_type_401 = struct {
    condition: u32,
    metadata: *const zx_type_342,
    no: u32,
    table: *const zx_type_216,
    yes: u32,
};

pub const zx_type_402 = struct {
    facts: *const zx_type_251,
    symbol: u32,
    tables: *const zx_type_19,
    type_id: u32,
};

pub const zx_type_403 = struct {
    local: *const zx_type_257,
    name: []const u8,
};

pub const zx_type_404 = struct {
    node: u64,
    path: []const u8,
    source: *const zx_type_287,
};

pub const zx_type_405 = struct {
    local: *const zx_type_257,
    node: u64,
    source: *const zx_type_287,
};

pub const zx_type_406 = struct {
    symbol: ?u32,
    unit: bool,
};

pub const zx_type_407 = enum { Probe, Fallback, Field, Index, Task, Optional, MatchLiteral, };

pub const zx_type_408 = struct {
    node: u64,
    operation: zx_type_407,
};

pub const zx_type_409 = struct {
    imports: *const zx_type_241,
    source: *const zx_type_287,
    state: *const zx_type_263,
};

pub const zx_type_411 = struct {
    context: *const zx_type_409,
    frames: []const *const zx_type_408,
    result: ?u32,
};

pub const zx_type_412 = struct {
    callee: u64,
    context: *const zx_type_409,
};

pub const zx_type_413 = struct {
    context: *const zx_type_409,
    node: u64,
};

pub const zx_type_414 = struct {
    handled: bool,
    type_id: ?u32,
};

pub const zx_type_415 = struct {
    node: u64,
    work: *const zx_type_411,
};

pub const zx_type_416 = struct {
    floating: bool,
    separators: bool,
};

pub const zx_type_417 = struct {
    left: u64,
    right: u64,
    source: *const zx_type_287,
};

pub const zx_type_418 = struct {
    node: u64,
    source: *const zx_type_287,
};

pub const zx_type_419 = struct {
    context: *const zx_type_409,
    frame: *const zx_type_408,
    type_id: u32,
};

pub const zx_type_420 = struct {
    context: *const zx_type_409,
    expected: ?u32,
    node: u64,
};

pub const zx_type_421 = struct {
    argument: u32,
    function_id: u32,
    metadata: *const zx_type_342,
    stores: []const u32,
    table: *const zx_type_216,
};

pub const zx_type_422 = struct {
    metadata: *const zx_type_342,
    optional: bool,
    table: *const zx_type_216,
};

pub const zx_type_423 = struct {
    kind: zx_type_345,
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    values: []const u32,
};

pub const zx_type_424 = struct {
    body: u32,
    condition: u32,
    condition_parameter: u32,
    initial: u32,
    metadata: *const zx_type_342,
    parameter: u32,
    postcondition: bool,
    table: *const zx_type_216,
};

pub const zx_type_425 = struct {
    node: u64,
    source: *const zx_type_287,
    state: *const zx_type_263,
    type_id: u32,
    updating: bool,
};

pub const zx_type_426 = struct {
    body: u64,
    context: *const zx_type_275,
    parameter: u32,
    state: *const zx_type_263,
};

pub const zx_type_427 = struct {
    context: *const zx_type_275,
    local: *const zx_type_257,
};

pub const zx_type_428 = struct {
    conditions: []const u32,
    fallback: u32,
    metadata: *const zx_type_342,
    results: []const u32,
    subject: ?u32,
    table: *const zx_type_216,
};

pub const zx_type_429 = struct {
    entries: *const zx_type_286,
    name: []const u8,
    value: u32,
};

pub const zx_type_430 = struct {
    index: u32,
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    target: u32,
    tuple: bool,
};

pub const zx_type_431 = struct {
    entries: *const zx_type_286,
    span: *const zx_type_25,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_432 = struct {
    entries: *const zx_type_286,
    state: *const zx_type_263,
};

pub const zx_type_433 = struct {
    evaluation: []const u32,
    indices: []const u32,
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    values: []const u32,
};

pub const zx_type_434 = struct {
    entries: *const zx_type_286,
    evaluation: []const u32,
    hint: ?u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_435 = struct {
    entries: *const zx_type_286,
    evaluation: []const u32,
    state: *const zx_type_263,
};

pub const zx_type_436 = struct {
    fields: []const ?u32,
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    tasks: []const u32,
};

pub const zx_type_437 = struct {
    functions: *const zx_type_240,
    operand: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_438 = struct {
    metadata: *const zx_type_342,
    operand: u32,
    operator: zx_type_206,
    table: *const zx_type_216,
};

pub const zx_type_439 = struct {
    negative: bool,
    operand: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_440 = struct {
    name: *const zx_type_60,
    span: *const zx_type_25,
    state: *const zx_type_263,
    target: u32,
};

pub const zx_type_441 = struct {
    index: u32,
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    target: u32,
};

pub const zx_type_442 = struct {
    index: u32,
    index_span: *const zx_type_25,
    span: *const zx_type_25,
    state: *const zx_type_263,
    target: u32,
};

pub const zx_type_443 = struct {
    span: *const zx_type_25,
    state: *const zx_type_263,
    target: u32,
};

pub const zx_type_444 = struct {
    cancellation: bool,
    operand: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_445 = struct {
    local: *const zx_type_257,
    name: *const zx_type_60,
    scope_start: u64,
    scopes: *const zx_type_285,
    value: u32,
};

pub const zx_type_446 = struct {
    diagnostic: *const zx_type_31,
    local: *const zx_type_257,
    scopes: *const zx_type_285,
    symbol: u32,
};

pub const zx_type_447 = struct {
    err: u32,
    facts: *const zx_type_251,
    result: u32,
};

pub const zx_type_448 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_216,
    facts: *const zx_type_251,
    result: ?u32,
    value: u64,
};

pub const zx_type_449 = struct {
    local: *const zx_type_257,
    name: *const zx_type_60,
    scopes: *const zx_type_285,
};

pub const zx_type_450 = struct {
    local: *const zx_type_257,
    scopes: *const zx_type_285,
    value: u32,
};

pub const zx_type_451 = struct {
    diagnostic: *const zx_type_31,
    local: *const zx_type_257,
    scopes: *const zx_type_285,
    value: u32,
};

pub const zx_type_452 = struct {
    scopes: *const zx_type_285,
    source: *const zx_type_287,
    state: *const zx_type_263,
    statement: u64,
    value: u32,
};

pub const zx_type_453 = struct {
    scopes: *const zx_type_285,
    state: *const zx_type_263,
};

pub const zx_type_454 = struct {
    scopes: *const zx_type_285,
    value: u32,
};

pub const zx_type_455 = struct {
    span: *const zx_type_25,
    state: *const zx_type_263,
    symbol: u32,
};

pub const zx_type_456 = struct {
    local: *const zx_type_257,
    scopes: *const zx_type_285,
    span: *const zx_type_25,
    value: u32,
};

pub const zx_type_457 = struct {
    diagnostic: *const zx_type_31,
    local: *const zx_type_257,
    scopes: *const zx_type_285,
};

pub const zx_type_458 = struct {
    block: u64,
    local: *const zx_type_257,
    scopes: *const zx_type_285,
    state_symbol: u32,
    tree: *const zx_type_132,
};

pub const zx_type_459 = struct {
    expressions: *const zx_type_216,
    left: u64,
    right: u64,
};

pub const zx_type_460 = struct {
    previous: []const u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_461 = struct {
    read_value: bool,
    state: *const zx_type_263,
    state_symbol: u32,
    target: u32,
};

pub const zx_type_463 = struct {
    diagnostic: *const zx_type_31,
    frames: []const *const zx_type_277,
};

pub const zx_type_464 = struct {
    read_value: bool,
    scopes: *const zx_type_285,
    state: *const zx_type_263,
    state_symbol: u32,
    target: u32,
};

pub const zx_type_465 = struct {
    places: []const *const zx_type_278,
    scopes: *const zx_type_285,
    state: *const zx_type_263,
};

pub const zx_type_466 = struct {
    parent: u32,
    selected: u32,
    state: *const zx_type_263,
    tuple: bool,
    value: u32,
};

pub const zx_type_467 = struct {
    places: []const *const zx_type_278,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_468 = struct {
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    value: []const u8,
};

pub const zx_type_469 = struct {
    source: []const u8,
    template: bool,
};

pub const zx_type_470 = struct {
    source: []const u8,
    span: *const zx_type_25,
    state: *const zx_type_263,
    template: bool,
};

pub const zx_type_471 = struct {
    name: []const u8,
    ownership: zx_type_217,
    span: *const zx_type_25,
    state: *const zx_type_263,
    type_id: u32,
};

pub const zx_type_472 = struct {
    state: *const zx_type_263,
    symbol: u32,
};

pub const zx_type_473 = struct {
    bindings: *const zx_type_272,
    source: u32,
    state: *const zx_type_263,
};

pub const zx_type_474 = struct {
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    value: bool,
};

pub const zx_type_475 = struct {
    span: *const zx_type_25,
    state: *const zx_type_263,
    value: bool,
};

pub const zx_type_476 = struct {
    metadata: *const zx_type_342,
    negative: bool,
    table: *const zx_type_216,
    value: u64,
};

pub const zx_type_477 = struct {
    span: *const zx_type_25,
    state: *const zx_type_263,
    value: u64,
};

pub const zx_type_478 = struct {
    initial: ?u32,
    kind: zx_type_205,
    result_type: u32,
    source: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_479 = struct {
    fields: *const zx_type_286,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_480 = struct {
    span: *const zx_type_25,
    state: *const zx_type_263,
    values: []const u32,
};

pub const zx_type_481 = struct {
    captures: []const u32,
    initial: ?u32,
    kind: zx_type_205,
    result: u32,
    source: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_482 = struct {
    initial: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_483 = struct {
    condition_parameter: u32,
    parameter: u32,
    state: *const zx_type_263,
};

pub const zx_type_484 = struct {
    kind: zx_type_205,
    parameter: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_485 = struct {
    callback: *const zx_type_271,
    kind: zx_type_205,
    parameter: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_486 = struct {
    bindings: *const zx_type_272,
    current: u32,
    index: u32,
    item: u32,
    previous: u32,
    source: u32,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_487 = struct {
    span: *const zx_type_25,
    state: *const zx_type_263,
    target: u32,
    value: u32,
};

pub const zx_type_488 = struct {
    item: u32,
    kind: zx_type_205,
    previous: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_489 = struct {
    captures: bool,
    current: u32,
    index: u32,
    result: u32,
    source: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_490 = struct {
    borrows: []const bool,
    metadata: *const zx_type_342,
    result: u32,
    symbols: []const ?u32,
    table: *const zx_type_216,
    values: []const u32,
};

pub const zx_type_491 = struct {
    bindings: *const zx_type_272,
    current: u32,
    result: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_492 = struct {
    bindings: *const zx_type_272,
    body: u32,
    condition: u32,
    condition_parameter: u32,
    initial: u32,
    parameter: u32,
    result_type: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_493 = struct {
    captures: *const zx_type_256,
    frame: u32,
};

pub const zx_type_494 = struct {
    body: u32,
    frame: u32,
    kind: zx_type_205,
    parameters: []const u32,
    result_type: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_495 = struct {
    callback: *const zx_type_271,
    result_type: u32,
    state: *const zx_type_263,
};

pub const zx_type_496 = struct {
    captures: *const zx_type_256,
    frame: u32,
    source: u32,
    target: u32,
    value: u32,
};

pub const zx_type_497 = struct {
    captures: *const zx_type_256,
    frame: u32,
    source: u32,
};

pub const zx_type_498 = struct {
    frame: u32,
    source: u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_499 = struct {
    frame: u32,
    local: *const zx_type_257,
    name: []const u8,
};

pub const zx_type_500 = struct {
    name: *const zx_type_60,
    state: *const zx_type_263,
};

pub const zx_type_501 = struct {
    state: *const zx_type_263,
    symbol: ?u32,
};

pub const zx_type_502 = struct {
    expected: ?u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_503 = struct {
    metadata: *const zx_type_342,
    table: *const zx_type_216,
    value: f64,
};

pub const zx_type_504 = struct {
    digit: u64,
    limbs: []const u64,
};

pub const zx_type_505 = struct {
    limbs: []const u64,
    overflow: bool,
};

pub const zx_type_506 = struct {
    significant: u64,
    trailing: u64,
};

pub const zx_type_507 = struct {
    bytes: []const u8,
    precision: u64,
};

pub const zx_type_510 = struct {
    bytes: []const u8,
    negative: bool,
    single: bool,
};

pub const zx_type_511 = struct {
    message: []const u8,
    value: f64,
};

pub const zx_type_512 = struct {
    id: u32,
    negative: bool,
};

pub const zx_type_513 = struct {
    floating: bool,
    id: u32,
    integer: bool,
    signed: bool,
};

pub const zx_type_514 = struct {
    floating: f64,
    integer: u64,
    message: []const u8,
    target: *const zx_type_513,
};

pub const zx_type_515 = struct {
    expected: ?u32,
    floating: bool,
    negative: bool,
};

pub const zx_type_516 = struct {
    expected: ?u32,
    negative: bool,
    source: []const u8,
};

pub const zx_type_517 = struct {
    expected: ?u32,
    negative: bool,
    source: []const u8,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_518 = struct {
    node: u64,
    source: *const zx_type_287,
    state: *const zx_type_263,
};

pub const zx_type_519 = struct {
    slot: u32,
    state: *const zx_type_263,
};

pub const zx_type_520 = struct {
    error_member: bool,
    name: *const zx_type_60,
    span: *const zx_type_25,
    state: *const zx_type_263,
    type_id: u32,
};

pub const zx_type_521 = struct {
    handled: bool,
    result: *const zx_type_348,
};

pub const zx_type_522 = struct {
    found: bool,
    state: *const zx_type_263,
};

pub const zx_type_523 = struct {
    imports: *const zx_type_241,
    name: []const u8,
    namespace: ?[]const u8,
};

pub const zx_type_524 = struct {
    found: bool,
    index: u64,
    known_namespace: bool,
};

pub const zx_type_525 = enum { Imported, Method, Loop, Parallel, Failed, };

pub const zx_type_526 = struct {
    index: u64,
    route: zx_type_525,
    state: *const zx_type_263,
};

pub const zx_type_527 = struct {
    imports: *const zx_type_241,
    name: *const zx_type_60,
    state: *const zx_type_263,
};

pub const zx_type_528 = struct {
    imports: *const zx_type_241,
    node: u64,
    source: *const zx_type_287,
    state: *const zx_type_263,
};

pub const zx_type_529 = struct {
    index: u64,
    work: *const zx_type_325,
};

pub const zx_type_530 = struct {
    condition: u64,
    diagnostic: *const zx_type_31,
    initial: u64,
    postcondition: bool,
    step: u64,
};

pub const zx_type_531 = struct {
    local: *const zx_type_257,
    scopes: *const zx_type_285,
    span: *const zx_type_25,
};

pub const zx_type_532 = struct {
    reference: u64,
    state: *const zx_type_263,
};

pub const zx_type_533 = struct {
    node: u64,
    source: *const zx_type_287,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_534 = struct {
    first: u64,
    table: *const zx_type_227,
};

pub const zx_type_535 = struct {
    id: u32,
    table: *const zx_type_227,
};

pub const zx_type_536 = struct {
    kind: zx_type_225,
    payload: u32,
    table: *const zx_type_227,
};

pub const zx_type_537 = struct {
    condition: u32,
    no: u32,
    table: *const zx_type_227,
    yes: u32,
};

pub const zx_type_538 = struct {
    symbol: u32,
    table: *const zx_type_227,
    value: u32,
};

pub const zx_type_539 = struct {
    symbols: []const ?u32,
    table: *const zx_type_227,
    value: u32,
};

pub const zx_type_540 = struct {
    table: *const zx_type_227,
    value: u32,
};

pub const zx_type_541 = struct {
    symbols: []const ?u32,
    table: *const zx_type_227,
    values: []const u32,
};

pub const zx_type_542 = struct {
    table: *const zx_type_227,
    value: ?u32,
};

pub const zx_type_543 = struct {
    bodies: []const u32,
    exhaustive: bool,
    subject: u32,
    table: *const zx_type_227,
    values: []const ?u32,
};

pub const zx_type_544 = struct {
    slot: u32,
    table: *const zx_type_227,
    value: u32,
};

pub const zx_type_545 = struct {
    index: u64,
    source: *const zx_type_227,
    target: *const zx_type_227,
};

pub const zx_type_546 = struct {
    mark: *const zx_type_327,
    table: *const zx_type_227,
};

pub const zx_type_547 = struct {
    first: u64,
    returns: []const bool,
    table: *const zx_type_227,
};

pub const zx_type_548 = struct {
    control: *const zx_type_227,
    mark: *const zx_type_327,
    pending: *const zx_type_227,
    returns: []const bool,
};

pub const zx_type_549 = struct {
    control: *const zx_type_227,
    id: u32,
    pending: *const zx_type_227,
    returns: []const bool,
};

pub const zx_type_550 = struct {
    blocks: *const zx_type_331,
    local: *const zx_type_257,
};

pub const zx_type_551 = struct {
    blocks: *const zx_type_331,
    id: u32,
    local: *const zx_type_257,
};

pub const zx_type_552 = struct {
    blocks: *const zx_type_331,
    tree: *const zx_type_132,
};

pub const zx_type_553 = struct {
    blocks: *const zx_type_331,
    diagnostic: *const zx_type_31,
    done: bool,
    source: u64,
};

pub const zx_type_554 = struct {
    blocks: *const zx_type_331,
    span: *const zx_type_25,
    state: *const zx_type_263,
    value: ?u32,
};

pub const zx_type_555 = struct {
    blocks: *const zx_type_331,
    state: *const zx_type_263,
};

pub const zx_type_556 = struct {
    expected: ?u32,
    node: u64,
    work: *const zx_type_325,
};

pub const zx_type_557 = struct {
    action: zx_type_334,
    body: *const zx_type_340,
    expected: ?u32,
    node: u64,
};

pub const zx_type_558 = struct {
    blocks: *const zx_type_331,
    name: *const zx_type_60,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_559 = struct {
    blocks: *const zx_type_331,
    source: *const zx_type_287,
    state: *const zx_type_263,
    statement: u64,
    value: u32,
};

pub const zx_type_560 = struct {
    blocks: *const zx_type_331,
    span: *const zx_type_25,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_561 = struct {
    action: zx_type_334,
    body: *const zx_type_340,
};

pub const zx_type_562 = struct {
    body: *const zx_type_340,
    span: *const zx_type_25,
};

pub const zx_type_563 = struct {
    root: ?u32,
    state: *const zx_type_263,
};

pub const zx_type_564 = struct {
    diagnostic: *const zx_type_31,
    types: *const zx_type_198,
};

pub const zx_type_565 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    state: *const zx_type_564,
};

pub const zx_type_566 = struct {
    names: []const []const u8,
    state: *const zx_type_564,
    types: []const u32,
};

pub const zx_type_567 = struct {
    aliases: *const zx_type_78,
    contracts: *const zx_type_224,
    items: []const *const zx_type_140,
    source: *const zx_type_287,
    state: *const zx_type_263,
};

pub const zx_type_568 = struct {
    items: []const *const zx_type_140,
    names: []const []const u8,
    source: *const zx_type_287,
    state: *const zx_type_263,
    types: []const u32,
};

pub const zx_type_569 = struct {
    aliases: *const zx_type_78,
    contract: *const zx_type_140,
    input_type: u32,
    output_type: u32,
    source: *const zx_type_287,
    types: *const zx_type_198,
};

pub const zx_type_570 = struct {
    diagnostic: *const zx_type_31,
    expressions: *const zx_type_216,
    predicate: u32,
    symbols: *const zx_type_219,
    types: *const zx_type_198,
};

pub const zx_type_571 = struct {
    expressions: *const zx_type_216,
    kind: zx_type_220,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_219,
    table: *const zx_type_224,
};

pub const zx_type_572 = struct {
    contracts: *const zx_type_224,
    state: *const zx_type_263,
};

pub const zx_type_573 = struct {
    ownership: []const zx_type_217,
    stores: []const *const zx_type_236,
};

pub const zx_type_574 = struct {
    body: ?u32,
    control: *const zx_type_227,
    expressions: *const zx_type_216,
    functions: *const zx_type_573,
    symbols: *const zx_type_219,
    type_only: bool,
    types: *const zx_type_19,
};

pub const zx_type_575 = struct {
    functions: *const zx_type_240,
    root: ?u32,
    state: *const zx_type_263,
    type_only: bool,
};

pub const zx_type_576 = struct {
    id: u64,
    types: *const zx_type_19,
};

pub const zx_type_577 = struct {
    expression: u64,
    expressions: *const zx_type_216,
    index: u64,
};

pub const zx_type_578 = struct {
    expression: u64,
    found: bool,
};

pub const zx_type_579 = struct {
    expression: u64,
    expressions: *const zx_type_216,
    locals: []const bool,
};

pub const zx_type_580 = struct {
    expression: u64,
    program: *const zx_type_574,
};

pub const zx_type_581 = struct {
    count: []const u64,
    first: []const u64,
    symbols: []const u64,
};

pub const zx_type_582 = enum { Copy, Borrowed, Owned, Loaned, Moved, };

pub const zx_type_583 = enum { Assign, Borrow, Freeze, };

pub const zx_type_584 = struct {
    children: []const u64,
    field_indices: []const u64,
    parents: []const u64,
    references: []const bool,
    siblings: []const u64,
    types: []const u32,
};

pub const zx_type_586 = struct {
    id: u64,
    layout: *const zx_type_584,
    operation: zx_type_583,
    states: []const zx_type_582,
    value: zx_type_582,
};

pub const zx_type_587 = struct {
    count: []const u64,
    first: []const u64,
    positions: []const u64,
};

pub const zx_type_588 = struct {
    cached: *const zx_type_587,
    heads: []const u64,
    next: []const u64,
    tree: *const zx_type_584,
};

pub const zx_type_589 = struct {
    cached: *const zx_type_587,
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    tree: *const zx_type_584,
    values: []const u64,
};

pub const zx_type_590 = enum { Heads, Symbols, Expressions, Evaluation, };

pub const zx_type_591 = struct {
    program: *const zx_type_574,
    references: []const bool,
};

pub const zx_type_592 = struct {
    capacity: u64,
    field: u64,
    parent: u64,
};

pub const zx_type_593 = struct {
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_594 = struct {
    field: u64,
    parent: u64,
};

pub const zx_type_595 = struct {
    found: bool,
    slot: u64,
    value: u64,
};

pub const zx_type_596 = struct {
    index: *const zx_type_593,
    key: *const zx_type_594,
};

pub const zx_type_597 = struct {
    expressions: *const zx_type_216,
    id: u64,
};

pub const zx_type_598 = struct {
    index: u32,
    target: u64,
};

pub const zx_type_599 = enum { Expression, AncestorStart, Ancestor, Root, Path, Ensure, Grow, Clear, Rehash, };

pub const zx_type_600 = struct {
    active: bool,
    ancestor: u64,
    bindings: []const u64,
    cached: *const zx_type_587,
    capacity: u64,
    child_expression: u64,
    children: []const u64,
    cursor: u64,
    direct: bool,
    expression: u64,
    field_indices: []const u64,
    heads: []const u64,
    key_fields: []const u64,
    key_parents: []const u64,
    next: []const u64,
    parent: u64,
    parents: []const u64,
    path: []const u64,
    path_index: u64,
    phase: zx_type_599,
    place_types: []const u32,
    program: *const zx_type_574,
    record: u64,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_601 = struct {
    first: u64,
    slots: []const u64,
};

pub const zx_type_602 = struct {
    program: *const zx_type_574,
    references: []const bool,
    roots: *const zx_type_588,
};

pub const zx_type_603 = struct {
    children: []const u64,
    count: []const u64,
    first: []const u64,
    shells: []const zx_type_582,
    states: []const zx_type_582,
    types: []const u32,
};

pub const zx_type_604 = struct {
    fact: u64,
    forest: *const zx_type_603,
};

pub const zx_type_605 = struct {
    fact: u64,
    forest: *const zx_type_603,
    index: u64,
    reference: bool,
};

pub const zx_type_606 = struct {
    index: u64,
    type_id: u32,
    types: *const zx_type_19,
};

pub const zx_type_607 = struct {
    left: zx_type_582,
    right: zx_type_582,
};

pub const zx_type_608 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_603,
    shell: zx_type_582,
    type_id: u32,
};

pub const zx_type_609 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    forest: *const zx_type_603,
    shell: zx_type_582,
    type_id: u32,
};

pub const zx_type_610 = struct {
    fact: u64,
    forest: *const zx_type_603,
    index: u64,
    references: []const bool,
    type_id: u32,
    types: *const zx_type_19,
    value: u64,
};

pub const zx_type_611 = struct {
    facts: []const u64,
    forest: *const zx_type_603,
    states: []const zx_type_582,
};

pub const zx_type_612 = struct {
    fact: u64,
    id: u64,
    layout: *const zx_type_584,
    references: []const bool,
    storage: *const zx_type_611,
    types: *const zx_type_19,
};

pub const zx_type_613 = struct {
    capacity: u64,
    left: u64,
    right: u64,
};

pub const zx_type_614 = enum { Join, Read, Borrow, Freeze, ReleaseAllLoans, ReleaseNewLoans, };

pub const zx_type_615 = struct {
    left: []const u64,
    right: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_616 = struct {
    cache: *const zx_type_615,
    left: u64,
    right: u64,
};

pub const zx_type_617 = struct {
    cache: *const zx_type_615,
    left: u64,
    right: u64,
    value: u64,
};

pub const zx_type_618 = struct {
    count: u64,
    values: []const u64,
};

pub const zx_type_619 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: *const zx_type_603,
    references: []const bool,
    shell: zx_type_582,
    type_id: u32,
    types: *const zx_type_19,
};

pub const zx_type_620 = struct {
    action: zx_type_614,
    left: zx_type_582,
    right: zx_type_582,
};

pub const zx_type_621 = struct {
    action: zx_type_614,
    forest: *const zx_type_603,
    left: u64,
    references: []const bool,
    right: u64,
    types: *const zx_type_19,
};

pub const zx_type_622 = enum { States, Memo, Both, };

pub const zx_type_623 = enum { RestoreStates, MergeStates, ReleaseNewLoans, ReleaseAllLoans, RestoreMemo, };

pub const zx_type_624 = struct {
    facts: []const u64,
    memo: []const u64,
    memo_count: []const u64,
    memo_first: []const u64,
    state_count: []const u64,
    state_first: []const u64,
};

pub const zx_type_625 = struct {
    facts: []const u64,
    forest: *const zx_type_603,
    memo: []const u64,
    states: []const zx_type_582,
    trail: []const u64,
};

pub const zx_type_626 = struct {
    memory: *const zx_type_625,
    snapshots: *const zx_type_624,
};

pub const zx_type_627 = struct {
    fact: u64,
    id: u64,
    layout: *const zx_type_584,
    memory: *const zx_type_625,
    operation: zx_type_583,
    references: []const bool,
    types: *const zx_type_19,
};

pub const zx_type_628 = struct {
    layout: *const zx_type_589,
    program: *const zx_type_574,
    references: []const bool,
};

pub const zx_type_629 = enum { Block, Statement, Release, Value, Finish, Project, Captured, Copy, Borrowed, Constant, Result, Store, Destructure, Borrow, Aggregate, Sequence, SequenceResult, IndexTarget, IndexResult, BranchCondition, BranchYes, BranchNo, CallResult, BinaryLeft, BinaryRight, ConditionalCondition, ConditionalYes, ConditionalNo, UpdateResult, ScopeBinding, ScopeResult, ScopeFinish, TaskCapture, TaskFinish, ParallelBranch, ObjectEvaluation, ObjectCached, ObjectField, ObjectFieldResult, ObjectFinish, Invocation, InvocationResult, CollectionTarget, CollectionArgument, CollectionResult, CollectionFreeze, SwitchSubject, SwitchCase, SwitchResult, MatchSubject, MatchArm, MatchCondition, MatchResult, MatchFinish, IterationInitial, IterationRound, IterationAdvance, IterationCondition, IterationBody, IterationFinish, TransformTarget, TransformInitial, TransformParameter, TransformBody, TransformFinish, };

pub const zx_type_630 = struct {
    action: zx_type_629,
    index: u64,
    moving: bool,
    subject: u64,
};

pub const zx_type_632 = struct {
    actions: []const zx_type_629,
    indices: []const u64,
    moving: []const bool,
    subjects: []const u64,
};

pub const zx_type_633 = struct {
    complete: bool,
    expression: u64,
    failed: bool,
    output: zx_type_582,
    stores_owned: bool,
};

pub const zx_type_634 = struct {
    action: zx_type_623,
    frame: u64,
    layout: *const zx_type_584,
    memory: *const zx_type_625,
    references: []const bool,
    stack: *const zx_type_624,
    types: *const zx_type_19,
};

pub const zx_type_635 = struct {
    frame: u64,
    stack: *const zx_type_624,
};

pub const zx_type_636 = struct {
    capture: zx_type_622,
    memory: *const zx_type_625,
    stack: *const zx_type_624,
};

pub const zx_type_637 = struct {
    frame: *const zx_type_630,
    work: *const zx_type_632,
};

pub const zx_type_638 = struct {
    count: []const u64,
    first: []const u64,
};

pub const zx_type_639 = struct {
    boundaries: []const u64,
    count: []const u64,
    entries: []const u64,
    exits: []const u64,
    facts: []const u64,
    first: []const u64,
    heads: []const u64,
    outputs: []const u64,
    roots: []const u64,
    seen: []const bool,
};

pub const zx_type_640 = enum { Statements, Values, Callbacks, Branches, Calls, Collections, Objects, Scope, Tasks, Expression, Invalid, };

pub const zx_type_641 = struct {
    active: bool,
    builders: *const zx_type_638,
    complete: bool,
    domains: *const zx_type_581,
    expression: u64,
    failed: bool,
    layout: *const zx_type_589,
    loops: *const zx_type_639,
    memory: *const zx_type_625,
    program: *const zx_type_574,
    references: []const bool,
    returned: zx_type_582,
    returns: []const bool,
    snapshots: *const zx_type_624,
    stores_owned: bool,
    value: u64,
    values: []const u64,
    work: *const zx_type_632,
};

pub const zx_type_642 = struct {
    frame: u64,
    layout: *const zx_type_584,
    memory: *const zx_type_625,
    merge: bool,
    references: []const bool,
    stack: *const zx_type_624,
    types: *const zx_type_19,
};

pub const zx_type_643 = struct {
    index: u64,
    loops: *const zx_type_639,
    memory: *const zx_type_625,
    references: []const bool,
    types: *const zx_type_19,
    value: u64,
};

pub const zx_type_644 = struct {
    forest: *const zx_type_603,
    loops: *const zx_type_639,
};

pub const zx_type_645 = struct {
    condition: bool,
    expression: u64,
    index: u64,
    machine: *const zx_type_641,
    value: u64,
};

pub const zx_type_646 = struct {
    boundary: u64,
    memory: *const zx_type_625,
    snapshots: *const zx_type_624,
    work: *const zx_type_632,
};

pub const zx_type_647 = struct {
    changed: bool,
    forest: *const zx_type_603,
    loops: *const zx_type_639,
};

pub const zx_type_648 = struct {
    domains: *const zx_type_581,
    exiting: bool,
    expression: u64,
    index: u64,
    layout: *const zx_type_584,
    loops: *const zx_type_639,
    memory: *const zx_type_625,
    references: []const bool,
    snapshots: *const zx_type_624,
    types: *const zx_type_19,
};

pub const zx_type_649 = struct {
    domains: *const zx_type_581,
    entry: u64,
    expression: u64,
    layout: *const zx_type_584,
    loops: *const zx_type_639,
    memory: *const zx_type_625,
    program: *const zx_type_574,
    value: u64,
};

pub const zx_type_650 = enum { Next, Query, Descend, Expand, Enter, Done, };

pub const zx_type_651 = struct {
    active: bool,
    cursors: []const u64,
    expression: u64,
    expressions: *const zx_type_216,
    facts: []const u64,
    forest: *const zx_type_603,
    layout: *const zx_type_589,
    memo: []const u64,
    permanent: bool,
    phase: zx_type_650,
    position: u64,
    query: u64,
    references: []const bool,
    root: u64,
    states: []const zx_type_582,
    trail: []const u64,
    types: *const zx_type_19,
    work: []const u64,
};

pub const zx_type_652 = struct {
    expression: u64,
    expressions: *const zx_type_216,
    index: u64,
    permanent: bool,
};

pub const zx_type_653 = struct {
    expression: u64,
    expressions: *const zx_type_216,
    layout: *const zx_type_589,
    memory: *const zx_type_625,
    permanent: bool,
    references: []const bool,
    types: *const zx_type_19,
};

pub const zx_type_654 = struct {
    expression: u64,
    expressions: *const zx_type_216,
    layout: *const zx_type_589,
    memo: []const u64,
    trail: []const u64,
};

pub const zx_type_655 = struct {
    found: bool,
    position: u64,
    trail: []const u64,
};

pub const zx_type_656 = struct {
    current: zx_type_582,
    moving: bool,
    position: u64,
    symbols: *const zx_type_219,
    types: *const zx_type_19,
};

pub const zx_type_657 = struct {
    assign: bool,
    assigned: zx_type_582,
    failed: bool,
    value: zx_type_582,
};

pub const zx_type_658 = struct {
    builders: *const zx_type_638,
    count: u64,
    forest: *const zx_type_603,
};

pub const zx_type_659 = struct {
    builders: *const zx_type_638,
    forest: *const zx_type_603,
};

pub const zx_type_660 = enum { Operands, Containers, Control, };

pub const zx_type_661 = struct {
    container: bool,
    frame: *const zx_type_630,
    kind: zx_type_203,
    machine: *const zx_type_641,
    payload: u64,
};

pub const zx_type_662 = struct {
    builders: *const zx_type_638,
    forest: *const zx_type_603,
    type_id: u32,
};

pub const zx_type_663 = struct {
    builders: *const zx_type_638,
    fact: u64,
    forest: *const zx_type_603,
};

pub const zx_type_664 = struct {
    domains: *const zx_type_581,
    layout: *const zx_type_589,
    program: *const zx_type_574,
    references: []const bool,
    returns: []const bool,
    runtime: *const zx_type_626,
};

pub const zx_type_665 = struct {
    outcome: *const zx_type_633,
    state: *const zx_type_263,
};

pub const zx_type_666 = struct {
    ownership: zx_type_217,
    state: *const zx_type_263,
};

pub const zx_type_667 = struct {
    control: *const zx_type_227,
    expressions: *const zx_type_216,
    root: ?u32,
    stores: *const zx_type_236,
    symbols: *const zx_type_219,
};

pub const zx_type_668 = struct {
    expressions: *const zx_type_216,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_219,
};

pub const zx_type_669 = struct {
    body: *const zx_type_667,
    contracts: *const zx_type_224,
    diagnostic: *const zx_type_31,
    export_names: []const []const u8,
    export_types: []const u32,
    input_type: u32,
    nominal_delta: *const zx_type_15,
    output_ownership: zx_type_217,
    output_type: u32,
    type_delta: *const zx_type_18,
    type_only: bool,
};

pub const zx_type_670 = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
    origins: *const zx_type_15,
};

pub const zx_type_671 = struct {
    base: *const zx_type_18,
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    id: u32,
    origin: *const zx_type_11,
    origins: *const zx_type_15,
};

pub const zx_type_672 = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
    origins: *const zx_type_15,
    publish: bool,
};

pub const zx_type_673 = struct {
    diagnostic: *const zx_type_31,
    local: *const zx_type_257,
};

pub const zx_type_674 = struct {
    context: *const zx_type_243,
    has_store: bool,
    signature: *const zx_type_199,
};

pub const zx_type_675 = struct {
    allow_store: bool,
    has_body: bool,
    signature: *const zx_type_199,
    stores: *const zx_type_236,
};

pub const zx_type_676 = struct {
    block: u64,
    functions: *const zx_type_240,
    imports: *const zx_type_241,
    source: *const zx_type_287,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_677 = struct {
    contract: *const zx_type_140,
    output_type: u32,
    state: *const zx_type_263,
};

pub const zx_type_678 = struct {
    domains: *const zx_type_581,
    layout: *const zx_type_589,
    references: []const bool,
    returns: []const bool,
};

pub const zx_type_679 = struct {
    memory: *const zx_type_625,
    prepared: *const zx_type_678,
    snapshots: *const zx_type_624,
};

pub const zx_type_680 = struct {
    analysis: *const zx_type_265,
    module: *const zx_type_244,
};

pub const zx_type_681 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_682 = struct { []const u8, []const u8, };

pub const zx_type_683 = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    selected: u64,
    source: *const zx_type_76,
};

pub const zx_type_684 = struct { []const []const u8, []const []const u8, };

pub const zx_type_685 = struct {
    count: u64,
    index: u64,
    state: *const zx_type_82,
};

pub const zx_type_686 = struct { *const zx_type_82, };

pub const zx_type_687 = struct { *const zx_type_82, *const zx_type_82, };

pub const zx_type_688 = struct { *const zx_type_82, *const zx_type_82, *const zx_type_82, };

pub const zx_type_689 = struct { []const []const u8, void, };

pub const zx_type_690 = struct { []const u32, void, };

pub const zx_type_691 = struct { []const []const u8, ?[]const u8, };

pub const zx_type_693 = struct { []const *const zx_type_80, ?*const zx_type_80, };

pub const zx_type_694 = struct {
    equal: bool,
    index: u64,
    left: *const zx_type_167,
    right: *const zx_type_167,
};

pub const zx_type_695 = struct {
    candidate: *const zx_type_164,
    count: u64,
    found: bool,
    id: u32,
    index: u64,
    tables: *const zx_type_19,
};

pub const zx_type_696 = struct { []const u8, void, };

pub const zx_type_697 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    limit: u64,
    right: []const u8,
};

pub const zx_type_698 = struct {
    building: bool,
    count: u64,
    names: []const []const u8,
    remaining: u64,
    root: u64,
    sifting: bool,
    types: []const u32,
};

pub const zx_type_699 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
};

pub const zx_type_700 = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: *const zx_type_19,
    target: zx_type_17,
};

pub const zx_type_701 = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: *const zx_type_19,
};

pub const zx_type_702 = struct { []const bool, void, };

pub const zx_type_703 = struct {
    children: []const u32,
    found: bool,
    index: u64,
    tables: *const zx_type_19,
};

pub const zx_type_704 = struct {
    count: u64,
    diagnostic: *const zx_type_31,
    enumeration: u64,
    index: u64,
    names: []const []const u8,
    source: *const zx_type_76,
};

pub const zx_type_705 = struct {
    cache: *const zx_type_78,
    found: bool,
    id: u32,
    index: u64,
    name: []const u8,
};

pub const zx_type_706 = struct { []const *const zx_type_80, void, };

pub const zx_type_707 = struct { []const u32, []const u32, };

pub const zx_type_708 = struct { *const zx_type_83, };

pub const zx_type_709 = struct { *const zx_type_83, *const zx_type_82, };

pub const zx_type_710 = struct { *const zx_type_83, *const zx_type_82, *const zx_type_82, };

pub const zx_type_711 = struct { *const zx_type_83, *const zx_type_82, *const zx_type_82, *const zx_type_82, };

pub const zx_type_712 = struct {
    count: u64,
    delta: *const zx_type_18,
    index: u64,
    mapping: *const zx_type_192,
    source: *const zx_type_167,
};

pub const zx_type_713 = struct {
    equal: bool,
    index: u64,
    mapping: *const zx_type_192,
    source: *const zx_type_167,
    target: *const zx_type_167,
};

pub const zx_type_714 = struct {
    count: u64,
    id: u32,
    index: u64,
    input: *const zx_type_196,
    nominal: bool,
    status: zx_type_188,
};

pub const zx_type_715 = struct {
    conflict: bool,
    delta: *const zx_type_18,
    index: u64,
    input: *const zx_type_190,
    mapping: []const u32,
    origins: *const zx_type_15,
};

pub const zx_type_716 = struct {
    cache: *const zx_type_78,
    ids: []const u32,
    index: u64,
    mapping: *const zx_type_192,
};

pub const zx_type_717 = struct { *const zx_type_671, };

pub const zx_type_718 = struct { *const zx_type_671, *const zx_type_191, };

pub const zx_type_719 = struct { *const zx_type_671, *const zx_type_191, *const zx_type_78, };

pub const zx_type_720 = struct { *const zx_type_671, *const zx_type_191, *const zx_type_78, u32, };

pub const zx_type_721 = struct { *const zx_type_154, };

pub const zx_type_722 = struct { *const zx_type_154, *const zx_type_84, };

pub const zx_type_723 = struct { *const zx_type_154, *const zx_type_84, *const zx_type_670, };

pub const zx_type_724 = struct { *const zx_type_153, };

pub const zx_type_725 = struct { *const zx_type_153, *const zx_type_154, };

pub const zx_type_726 = struct { *const zx_type_153, *const zx_type_154, *const zx_type_672, };

pub const zx_type_727 = struct { *const zx_type_200, };

pub const zx_type_728 = struct { *const zx_type_200, *const zx_type_199, };

pub const zx_type_729 = struct { *const zx_type_200, *const zx_type_199, *const zx_type_154, };

pub const zx_type_730 = struct { *const zx_type_200, *const zx_type_199, *const zx_type_154, *const zx_type_672, };

pub const zx_type_731 = struct { *const zx_type_200, *const zx_type_199, *const zx_type_672, };

pub const zx_type_732 = struct { *const zx_type_200, *const zx_type_199, *const zx_type_672, *const zx_type_154, };

pub const zx_type_733 = struct { *const zx_type_200, *const zx_type_199, *const zx_type_672, *const zx_type_154, *const zx_type_672, };

pub const zx_type_734 = struct { *const zx_type_200, *const zx_type_199, *const zx_type_672, *const zx_type_672, };

pub const zx_type_735 = struct {
    found: bool,
    handles: []const []const u8,
    index: u64,
    paths: []const []const u8,
    target: u64,
};

pub const zx_type_736 = struct {
    diagnostic: *const zx_type_31,
    index: u64,
    input: *const zx_type_247,
    stores: *const zx_type_236,
};

pub const zx_type_737 = struct { *const zx_type_674, };

pub const zx_type_738 = struct { *const zx_type_674, *const zx_type_248, };

pub const zx_type_739 = struct { *const zx_type_674, *const zx_type_248, *const zx_type_250, };

pub const zx_type_740 = struct { []const u64, void, };

pub const zx_type_741 = struct { []const zx_type_217, void, };

pub const zx_type_742 = struct {
    active: []const u32,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_743 = struct { *const zx_type_675, };

pub const zx_type_744 = struct { *const zx_type_675, *const zx_type_257, };

pub const zx_type_745 = struct { *const zx_type_675, *const zx_type_257, *const zx_type_262, };

pub const zx_type_746 = struct { *const zx_type_244, };

pub const zx_type_747 = struct { *const zx_type_244, *const zx_type_564, };

pub const zx_type_748 = struct { *const zx_type_244, *const zx_type_564, *const zx_type_199, };

pub const zx_type_749 = struct { *const zx_type_244, *const zx_type_564, *const zx_type_199, *const zx_type_250, };

pub const zx_type_750 = struct { *const zx_type_244, *const zx_type_564, *const zx_type_199, *const zx_type_250, *const zx_type_673, };

pub const zx_type_751 = struct { *const zx_type_244, *const zx_type_564, *const zx_type_199, *const zx_type_250, *const zx_type_263, };

pub const zx_type_752 = struct { *const zx_type_244, *const zx_type_564, *const zx_type_199, *const zx_type_263, };

pub const zx_type_753 = struct { *const zx_type_244, *const zx_type_564, *const zx_type_263, };

pub const zx_type_754 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_216,
    index: u64,
    limit: u64,
    valid: bool,
};

pub const zx_type_755 = struct {
    index: u64,
    result: []const bool,
    source: []const ?u32,
};

pub const zx_type_756 = struct {
    concurrent: bool,
    functions: *const zx_type_268,
    index: u64,
    values: []const bool,
};

pub const zx_type_757 = struct {
    head: u64,
    items: []const *const zx_type_43,
    remaining: u64,
    statements: []const u64,
};

pub const zx_type_758 = struct { []const *const zx_type_329, void, };

pub const zx_type_759 = struct { []const zx_type_203, void, };

pub const zx_type_760 = struct {
    actual: u32,
    expected: u32,
    failed: bool,
    tables: *const zx_type_19,
    wrappers: []const u32,
};

pub const zx_type_761 = struct {
    index: u64,
    span: *const zx_type_25,
    table: *const zx_type_216,
    value: u32,
    wrappers: []const u32,
};

pub const zx_type_762 = struct {
    all: bool,
    bodies: []const u32,
    end: u64,
    index: u64,
    returns: []const bool,
};

pub const zx_type_763 = struct {
    block: u64,
    control: *const zx_type_227,
    returns: []const bool,
};

pub const zx_type_764 = struct { []const *const zx_type_356, void, };

pub const zx_type_765 = struct {
    contracts: *const zx_type_224,
    index: u64,
    state: *const zx_type_360,
};

pub const zx_type_766 = struct { []const *const zx_type_355, void, };

pub const zx_type_767 = struct {
    control: *const zx_type_227,
    first: u64,
    frames: []const *const zx_type_355,
    index: u64,
    source: u64,
};

pub const zx_type_768 = struct {
    capacity: u64,
    slots: []const u64,
};

pub const zx_type_769 = struct {
    index: u64,
    previous: []const u64,
    slots: []const u64,
};

pub const zx_type_770 = struct {
    position: u64,
    slots: []const u64,
};

pub const zx_type_771 = struct { []const u64, []const u64, };

pub const zx_type_772 = struct {
    key: u64,
    position: u64,
    slots: []const u64,
};

pub const zx_type_773 = struct {
    end: u64,
    index: u64,
    table: *const zx_type_216,
    values: []const u32,
};

pub const zx_type_774 = struct {
    end: u64,
    expressions: *const zx_type_216,
    index: u64,
    names: []const []const u8,
    tables: *const zx_type_19,
};

pub const zx_type_775 = struct { []const *const zx_type_356, []const *const zx_type_356, };

pub const zx_type_776 = struct {
    frames: []const *const zx_type_355,
    index: u64,
    source: u64,
    values: []const u32,
};

pub const zx_type_778 = struct { []const *const zx_type_355, ?*const zx_type_355, };

pub const zx_type_779 = struct {
    index: u64,
    names: []const []const u8,
    values: []const []const u8,
};

pub const zx_type_780 = struct { *const zx_type_361, };

pub const zx_type_781 = struct { *const zx_type_361, *const zx_type_360, };

pub const zx_type_782 = struct { *const zx_type_361, *const zx_type_360, *const zx_type_360, };

pub const zx_type_783 = struct { *const zx_type_361, *const zx_type_360, *const zx_type_360, ?[]const []const u8, };

pub const zx_type_784 = struct {
    captures: []const u32,
    concurrent: []const bool,
    index: u64,
    span: *const zx_type_25,
    state: *const zx_type_263,
    symbols: u64,
};

pub const zx_type_785 = struct {
    found: bool,
    index: u64,
    symbol: u32,
    values: []const u32,
};

pub const zx_type_787 = struct { []const *const zx_type_303, ?*const zx_type_303, };

pub const zx_type_788 = struct { []const zx_type_207, void, };

pub const zx_type_789 = struct {
    comparable: bool,
    done: bool,
    id: u32,
    tables: *const zx_type_19,
};

pub const zx_type_790 = struct {
    facts: *const zx_type_251,
    index: u64,
    symbol: u32,
};

pub const zx_type_791 = struct {
    expressions: *const zx_type_216,
    state: *const zx_type_253,
};

pub const zx_type_792 = struct { []const u64, ?u64, };

pub const zx_type_794 = struct { []const bool, ?bool, };

pub const zx_type_795 = struct { []const zx_type_290, void, };

pub const zx_type_796 = struct { []const *const zx_type_293, []const *const zx_type_293, };

pub const zx_type_798 = struct { []const *const zx_type_293, ?*const zx_type_293, };

pub const zx_type_799 = struct {
    head: u64,
    items: []const *const zx_type_43,
    values: []const u64,
};

pub const zx_type_800 = struct { []const zx_type_204, void, };

pub const zx_type_802 = struct { []const *const zx_type_300, ?*const zx_type_300, };

pub const zx_type_803 = struct {
    done: bool,
    id: u32,
    tables: *const zx_type_19,
};

pub const zx_type_804 = struct { []const ?u32, void, };

pub const zx_type_805 = struct {
    head: u64,
    ids: []const u64,
    tree: *const zx_type_118,
};

pub const zx_type_806 = struct {
    index: u64,
    order: []const u64,
    parameters: []const u32,
    source: *const zx_type_287,
    start: u64,
    state: *const zx_type_263,
    types: []const u32,
};

pub const zx_type_807 = struct { []const zx_type_217, []const zx_type_217, };

pub const zx_type_808 = struct { []const *const zx_type_274, []const *const zx_type_274, };

pub const zx_type_810 = struct { []const *const zx_type_299, ?*const zx_type_299, };

pub const zx_type_811 = struct { []const *const zx_type_274, void, };

pub const zx_type_812 = struct { []const *const zx_type_300, void, };

pub const zx_type_813 = struct {
    found: ?u32,
    index: u64,
    local: *const zx_type_257,
    name: []const u8,
};

pub const zx_type_814 = struct {
    done: bool,
    end: u64,
    matches: bool,
    node: u64,
    path: []const u8,
    source: *const zx_type_287,
};

pub const zx_type_815 = struct {
    end: u64,
    equal: bool,
    index: u64,
    path: []const u8,
    size: u64,
    source: []const u8,
    start: u64,
};

pub const zx_type_816 = struct {
    node: u64,
    tree: *const zx_type_118,
};

pub const zx_type_817 = struct {
    bindings: []const u32,
    index: u64,
    local: ?u32,
    names: []const []const u8,
    node: u64,
    source: *const zx_type_287,
    symbol: ?u32,
    unit: bool,
    units: []const []const u8,
};

pub const zx_type_818 = struct {
    imports: *const zx_type_241,
    index: u64,
    name: []const u8,
    namespace: ?[]const u8,
    result: ?u32,
};

pub const zx_type_819 = struct {
    index: u64,
    name: []const u8,
    owner: []const u8,
    stores: *const zx_type_236,
    type_id: ?u32,
};

pub const zx_type_820 = struct { []const *const zx_type_408, void, };

pub const zx_type_821 = struct {
    frames: []const *const zx_type_408,
    head: u64,
    tree: *const zx_type_118,
};

pub const zx_type_822 = struct {
    floating: bool,
    index: u64,
    separators: bool,
    source: []const u8,
};

pub const zx_type_823 = struct {
    floating: bool,
    index: u64,
    nodes: []const u64,
    signed: bool,
    source: *const zx_type_287,
};

pub const zx_type_824 = struct {
    fallback: u64,
    head: u64,
    source: *const zx_type_287,
    type_id: ?u32,
};

pub const zx_type_825 = struct {
    negative: bool,
    offset: u64,
    seen: bool,
    source: []const u8,
    started: bool,
    valid: bool,
    value: u64,
};

pub const zx_type_826 = struct {
    count: u64,
    first: u64,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_828 = struct { []const *const zx_type_408, ?*const zx_type_408, };

pub const zx_type_829 = struct { []const *const zx_type_294, []const *const zx_type_294, };

pub const zx_type_831 = struct { []const *const zx_type_294, ?*const zx_type_294, };

pub const zx_type_833 = struct { []const *const zx_type_298, ?*const zx_type_298, };

pub const zx_type_834 = struct { []const *const zx_type_298, []const *const zx_type_298, };

pub const zx_type_835 = struct { []const *const zx_type_276, []const *const zx_type_276, };

pub const zx_type_837 = struct { []const *const zx_type_276, ?*const zx_type_276, };

pub const zx_type_838 = struct { []const *const zx_type_300, []const *const zx_type_300, };

pub const zx_type_839 = struct { []const *const zx_type_295, []const *const zx_type_295, };

pub const zx_type_841 = struct { []const *const zx_type_295, ?*const zx_type_295, };

pub const zx_type_842 = struct {
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_843 = struct {
    count: u64,
    entries: *const zx_type_286,
    expressions: *const zx_type_216,
    first: u64,
    index: u64,
    names: []const []const u8,
    span: *const zx_type_25,
    types: []const u32,
    value: u32,
};

pub const zx_type_844 = struct {
    count: u64,
    entries: *const zx_type_286,
    evaluation: []const u32,
    first: u64,
    index: u64,
    names: []const []const u8,
    span: *const zx_type_25,
    state: *const zx_type_263,
    types: []const u32,
};

pub const zx_type_845 = struct {
    index: u64,
    output: []const u32,
    types: []const u32,
    values: []const u32,
};

pub const zx_type_846 = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    indices: []const u32,
    names: []const []const u8,
};

pub const zx_type_848 = struct { []const *const zx_type_297, ?*const zx_type_297, };

pub const zx_type_849 = struct { []const *const zx_type_297, []const *const zx_type_297, };

pub const zx_type_850 = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    indices: []const ?u32,
    names: []const []const u8,
};

pub const zx_type_851 = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    name: []const u8,
};

pub const zx_type_853 = struct { []const *const zx_type_304, ?*const zx_type_304, };

pub const zx_type_854 = struct { []const *const zx_type_304, []const *const zx_type_304, };

pub const zx_type_855 = struct { []const zx_type_206, void, };

pub const zx_type_856 = struct { []const *const zx_type_292, []const *const zx_type_292, };

pub const zx_type_858 = struct { []const *const zx_type_292, ?*const zx_type_292, };

pub const zx_type_859 = struct { []const u32, ?u32, };

pub const zx_type_860 = struct {
    head: u64,
    ids: []const u64,
    names: []const *const zx_type_127,
};

pub const zx_type_861 = struct {
    first: u64,
    index: u64,
    order: []const u64,
    saved: u32,
    scopes: *const zx_type_285,
    source: *const zx_type_287,
    start: u64,
    state: *const zx_type_263,
    symbols: []const ?u32,
    types: []const u32,
};

pub const zx_type_862 = struct { []const *const zx_type_283, []const *const zx_type_283, };

pub const zx_type_863 = struct { []const *const zx_type_283, void, };

pub const zx_type_864 = struct { []const *const zx_type_281, []const *const zx_type_281, };

pub const zx_type_866 = struct { []const *const zx_type_281, ?*const zx_type_281, };

pub const zx_type_867 = struct {
    expressions: *const zx_type_216,
    found: bool,
    index: u64,
    previous: []const u32,
    value: u64,
};

pub const zx_type_869 = struct { []const *const zx_type_282, ?*const zx_type_282, };

pub const zx_type_870 = struct { []const *const zx_type_282, []const *const zx_type_282, };

pub const zx_type_871 = struct {
    diagnostic: *const zx_type_31,
    done: bool,
    expressions: *const zx_type_216,
    frames: []const *const zx_type_277,
    read_value: bool,
    symbol: u32,
    tables: *const zx_type_19,
    target: u32,
};

pub const zx_type_872 = struct { []const *const zx_type_277, void, };

pub const zx_type_873 = struct {
    frames: []const *const zx_type_277,
    index: u64,
    places: []const *const zx_type_278,
    scopes: *const zx_type_285,
    state: *const zx_type_263,
};

pub const zx_type_874 = struct { []const *const zx_type_278, void, };

pub const zx_type_875 = struct { []const *const zx_type_278, []const *const zx_type_278, };

pub const zx_type_876 = struct {
    count: u64,
    expressions: *const zx_type_216,
    first: u64,
    index: u64,
    indices: []const u32,
    metadata: *const zx_type_342,
    parent: u32,
    selected: u64,
    table: *const zx_type_18,
    tuple: bool,
    value: u32,
    values: []const u32,
};

pub const zx_type_877 = struct {
    index: u64,
    places: []const *const zx_type_278,
    state: *const zx_type_263,
    value: u32,
};

pub const zx_type_878 = struct { []const *const zx_type_280, []const *const zx_type_280, };

pub const zx_type_880 = struct { []const *const zx_type_280, ?*const zx_type_280, };

pub const zx_type_882 = struct { []const *const zx_type_296, ?*const zx_type_296, };

pub const zx_type_883 = struct { []const *const zx_type_296, []const *const zx_type_296, };

pub const zx_type_884 = struct {
    index: u64,
    rewrite: bool,
    source: []const u8,
    template: bool,
};

pub const zx_type_885 = struct {
    bytes: []const u8,
    index: u64,
    source: []const u8,
    template: bool,
};

pub const zx_type_886 = struct {
    frame: *const zx_type_301,
    source: *const zx_type_287,
    span: *const zx_type_25,
    state: *const zx_type_263,
};

pub const zx_type_888 = struct { []const *const zx_type_301, ?*const zx_type_301, };

pub const zx_type_889 = struct { []const *const zx_type_301, []const *const zx_type_301, };

pub const zx_type_890 = struct {
    fields: []const u32,
    index: u64,
    types: []const u32,
    values: []const u32,
};

pub const zx_type_891 = struct {
    count: u64,
    fields: *const zx_type_286,
    first: u64,
    index: u64,
    indices: []const u32,
    names: []const []const u8,
    values: []const u32,
};

pub const zx_type_892 = struct {
    bindings: *const zx_type_272,
    context: u32,
    index: u64,
    span: *const zx_type_25,
    state: *const zx_type_263,
    targets: []const u32,
};

pub const zx_type_893 = struct {
    bindings: *const zx_type_272,
    index: u64,
    parameters: []const u32,
    reducing: bool,
    values: []const u32,
};

pub const zx_type_894 = struct { *const zx_type_485, };

pub const zx_type_895 = struct { *const zx_type_485, *const zx_type_486, };

pub const zx_type_896 = struct { *const zx_type_485, *const zx_type_486, *const zx_type_348, };

pub const zx_type_897 = struct { *const zx_type_485, *const zx_type_486, *const zx_type_348, *const zx_type_348, };

pub const zx_type_898 = struct { *const zx_type_485, *const zx_type_486, *const zx_type_348, *const zx_type_348, *const zx_type_348, };

pub const zx_type_899 = struct { *const zx_type_273, };

pub const zx_type_900 = struct { *const zx_type_273, *const zx_type_473, };

pub const zx_type_901 = struct { *const zx_type_273, *const zx_type_473, *const zx_type_348, };

pub const zx_type_902 = struct { *const zx_type_273, *const zx_type_473, *const zx_type_348, *const zx_type_348, };

pub const zx_type_903 = struct { *const zx_type_273, *const zx_type_473, *const zx_type_348, *const zx_type_348, *const zx_type_483, };

pub const zx_type_904 = struct { *const zx_type_273, *const zx_type_473, *const zx_type_348, *const zx_type_348, *const zx_type_483, *const zx_type_348, };

pub const zx_type_905 = struct { *const zx_type_273, *const zx_type_473, *const zx_type_348, *const zx_type_348, *const zx_type_483, *const zx_type_348, *const zx_type_348, };

pub const zx_type_906 = struct { *const zx_type_273, *const zx_type_473, *const zx_type_348, *const zx_type_348, *const zx_type_483, *const zx_type_348, *const zx_type_348, *const zx_type_348, };

pub const zx_type_907 = struct {
    bindings: *const zx_type_255,
    row: ?u32,
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
};

pub const zx_type_909 = struct { []const *const zx_type_274, ?*const zx_type_274, };

pub const zx_type_911 = struct { []const zx_type_290, ?zx_type_290, };

pub const zx_type_913 = struct { []const *const zx_type_291, ?*const zx_type_291, };

pub const zx_type_914 = struct { []const ?u32, []const ?u32, };

pub const zx_type_915 = struct {
    bindings: *const zx_type_255,
    found: ?u32,
    row: ?u32,
    source: u32,
};

pub const zx_type_916 = struct {
    floor: u64,
    found: ?u32,
    index: u64,
    local: *const zx_type_257,
    name: []const u8,
};

pub const zx_type_917 = struct {
    frame: ?u32,
    local: *const zx_type_257,
    name: []const u8,
    path: []const u32,
    symbol: ?u32,
};

pub const zx_type_918 = struct {
    index: u64,
    path: []const u32,
    span: *const zx_type_25,
    state: *const zx_type_263,
    symbol: u32,
};

pub const zx_type_919 = struct {
    found: bool,
    index: u64,
    local: *const zx_type_257,
    name: []const u8,
};

pub const zx_type_920 = struct { []const f64, void, };

pub const zx_type_921 = struct {
    bytes: []const u8,
    index: u64,
    source: []const u8,
};

pub const zx_type_922 = struct {
    carry: u64,
    index: u64,
    limbs: []const u64,
};

pub const zx_type_923 = struct {
    bits: u64,
    value: u64,
};

pub const zx_type_924 = struct {
    index: u64,
    limbs: []const u64,
};

pub const zx_type_925 = struct {
    count: u64,
    value: u64,
};

pub const zx_type_926 = struct {
    bytes: []const u8,
    index: u64,
    invalid: bool,
    limbs: []const u64,
};

pub const zx_type_927 = struct {
    handle: []const u8,
    handles: []const []const u8,
    index: u64,
};

pub const zx_type_928 = struct {
    active: []const u32,
    floor: u64,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_929 = struct {
    found: bool,
    imports: *const zx_type_241,
    index: u64,
    known_namespace: bool,
    name: []const u8,
    namespace: ?[]const u8,
};

pub const zx_type_930 = struct { []const *const zx_type_298, void, };

pub const zx_type_931 = struct {
    condition: ?u64,
    diagnostic: *const zx_type_31,
    fields: []const u64,
    index: u64,
    postcondition: bool,
    source: *const zx_type_287,
    step: ?u64,
};

pub const zx_type_932 = struct { []const *const zx_type_276, void, };

pub const zx_type_933 = struct {
    fields: []const *const zx_type_109,
    head: u64,
    ids: []const u64,
};

pub const zx_type_934 = struct { []const *const zx_type_304, void, };

pub const zx_type_935 = struct { []const *const zx_type_299, void, };

pub const zx_type_936 = struct {
    arms: []const u64,
    head: u64,
    tree: *const zx_type_118,
};

pub const zx_type_937 = struct { []const *const zx_type_295, void, };

pub const zx_type_938 = struct {
    fields: []const u64,
    head: u64,
    tree: *const zx_type_118,
};

pub const zx_type_939 = struct { []const *const zx_type_297, void, };

pub const zx_type_940 = struct {
    head: u64,
    items: []const u64,
    tree: *const zx_type_118,
};

pub const zx_type_941 = struct { []const *const zx_type_296, void, };

pub const zx_type_942 = struct {
    head: u64,
    parts: []const u64,
    tree: *const zx_type_118,
};

pub const zx_type_943 = struct { []const *const zx_type_301, void, };

pub const zx_type_944 = struct { []const *const zx_type_291, void, };

pub const zx_type_945 = struct { []const *const zx_type_303, void, };

pub const zx_type_946 = struct { []const *const zx_type_292, void, };

pub const zx_type_947 = struct { []const *const zx_type_293, void, };

pub const zx_type_948 = struct { []const *const zx_type_294, void, };

pub const zx_type_949 = struct { []const bool, []const bool, };

pub const zx_type_951 = struct { []const *const zx_type_283, ?*const zx_type_283, };

pub const zx_type_952 = struct { []const *const zx_type_280, void, };

pub const zx_type_953 = struct { []const *const zx_type_281, void, };

pub const zx_type_954 = struct {
    cases: []const *const zx_type_128,
    head: u64,
    ids: []const u64,
};

pub const zx_type_955 = struct { []const *const zx_type_282, void, };

pub const zx_type_956 = struct {
    found: bool,
    index: u64,
    node: u64,
    paths: []const []const u8,
    source: *const zx_type_287,
};

pub const zx_type_957 = struct { []const zx_type_225, void, };

pub const zx_type_958 = struct { []const zx_type_225, []const zx_type_225, };

pub const zx_type_960 = struct { []const *const zx_type_329, ?*const zx_type_329, };

pub const zx_type_961 = struct { []const *const zx_type_329, []const *const zx_type_329, };

pub const zx_type_962 = struct { []const zx_type_334, void, };

pub const zx_type_963 = struct { []const *const zx_type_336, void, };

pub const zx_type_964 = struct { []const *const zx_type_335, void, };

pub const zx_type_965 = struct {
    first: u64,
    index: u64,
    order: []const u64,
    source: *const zx_type_287,
    start: u64,
    state: *const zx_type_263,
    symbols: []const ?u32,
    types: []const u32,
};

pub const zx_type_966 = struct { []const *const zx_type_335, []const *const zx_type_335, };

pub const zx_type_968 = struct { []const *const zx_type_335, ?*const zx_type_335, };

pub const zx_type_969 = struct { []const *const zx_type_336, []const *const zx_type_336, };

pub const zx_type_971 = struct { []const zx_type_334, ?zx_type_334, };

pub const zx_type_973 = struct { []const *const zx_type_336, ?*const zx_type_336, };

pub const zx_type_974 = struct { *const zx_type_676, };

pub const zx_type_975 = struct { *const zx_type_676, *const zx_type_340, };

pub const zx_type_976 = struct { *const zx_type_676, *const zx_type_340, *const zx_type_340, };

pub const zx_type_977 = struct { *const zx_type_676, *const zx_type_340, *const zx_type_340, *const zx_type_563, };

pub const zx_type_978 = struct { *const zx_type_680, };

pub const zx_type_979 = struct { *const zx_type_680, *const zx_type_563, };

pub const zx_type_980 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    index: u64,
    names: []const []const u8,
    state: *const zx_type_564,
    types: []const u32,
};

pub const zx_type_981 = struct { *const zx_type_680, *const zx_type_566, };

pub const zx_type_982 = struct { *const zx_type_677, };

pub const zx_type_983 = struct { *const zx_type_677, *const zx_type_262, };

pub const zx_type_984 = struct { *const zx_type_677, *const zx_type_262, *const zx_type_262, };

pub const zx_type_985 = struct { *const zx_type_677, *const zx_type_262, *const zx_type_263, };

pub const zx_type_986 = struct {
    diagnostic: *const zx_type_31,
    expressions: *const zx_type_216,
    index: u64,
};

pub const zx_type_987 = struct { *const zx_type_569, };

pub const zx_type_988 = struct { *const zx_type_569, *const zx_type_263, };

pub const zx_type_989 = struct { *const zx_type_569, *const zx_type_263, *const zx_type_263, };

pub const zx_type_990 = struct { *const zx_type_569, *const zx_type_263, *const zx_type_263, *const zx_type_325, };

pub const zx_type_991 = struct { *const zx_type_569, *const zx_type_263, *const zx_type_263, *const zx_type_325, *const zx_type_325, };

pub const zx_type_992 = struct { *const zx_type_569, *const zx_type_263, *const zx_type_263, *const zx_type_325, *const zx_type_325, *const zx_type_570, };

pub const zx_type_993 = struct { *const zx_type_569, *const zx_type_263, *const zx_type_263, *const zx_type_570, };

pub const zx_type_994 = struct { []const zx_type_220, void, };

pub const zx_type_995 = struct { []const *const zx_type_219, void, };

pub const zx_type_996 = struct { []const *const zx_type_216, void, };

pub const zx_type_997 = struct {
    index: u64,
    work: *const zx_type_567,
};

pub const zx_type_998 = struct { *const zx_type_568, };

pub const zx_type_999 = struct { *const zx_type_568, *const zx_type_567, };

pub const zx_type_1000 = struct { *const zx_type_568, *const zx_type_567, *const zx_type_572, };

pub const zx_type_1001 = struct { *const zx_type_680, *const zx_type_572, };

pub const zx_type_1002 = struct {
    target: *const zx_type_21,
    types: *const zx_type_19,
};

pub const zx_type_1003 = struct {
    index: u64,
    references: []const bool,
    types: *const zx_type_19,
};

pub const zx_type_1004 = struct {
    count: u64,
    expressions: *const zx_type_216,
    index: u64,
    kind: zx_type_203,
    locals: []const bool,
    payload: u64,
};

pub const zx_type_1005 = struct {
    body: u64,
    condition: u64,
    count: u64,
    locals: []const bool,
    reachable: []const bool,
    symbols: u64,
};

pub const zx_type_1006 = struct {
    expressions: *const zx_type_216,
    index: u64,
    locals: []const bool,
    reachable: []const bool,
    remaining: u64,
};

pub const zx_type_1007 = struct {
    count: []const u64,
    first: []const u64,
    index: u64,
    program: *const zx_type_574,
    symbols: []const u64,
};

pub const zx_type_1008 = struct {
    index: u64,
    locals: []const bool,
    symbols: []const u64,
};

pub const zx_type_1009 = struct {
    active: bool,
    cached_count: []const u64,
    cached_first: []const u64,
    cached_positions: []const u64,
    children: []const u64,
    field_indices: []const u64,
    heads: []const u64,
    index: u64,
    item: u64,
    next: []const u64,
    parents: []const u64,
    phase: zx_type_590,
    place_types: []const u32,
    program: *const zx_type_574,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    tails: []const u64,
};

pub const zx_type_1010 = struct {
    active: bool,
    found: bool,
    index: *const zx_type_593,
    key: *const zx_type_594,
    slot: u64,
    value: u64,
};

pub const zx_type_1011 = struct { *const zx_type_574, };

pub const zx_type_1012 = struct { *const zx_type_574, []const bool, };

pub const zx_type_1013 = struct { *const zx_type_574, []const bool, []const bool, };

pub const zx_type_1014 = struct { *const zx_type_574, []const bool, []const bool, *const zx_type_581, };

pub const zx_type_1015 = struct { *const zx_type_574, []const bool, []const bool, *const zx_type_581, *const zx_type_588, };

pub const zx_type_1016 = struct { *const zx_type_574, []const bool, []const bool, *const zx_type_581, *const zx_type_588, *const zx_type_589, };

pub const zx_type_1017 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_603,
    index: u64,
    state: zx_type_582,
};

pub const zx_type_1018 = struct { []const zx_type_582, void, };

pub const zx_type_1019 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    index: u64,
    source: []const u64,
};

pub const zx_type_1020 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    forest: *const zx_type_603,
    index: u64,
    references: []const bool,
    target: u64,
    type_id: u32,
    types: *const zx_type_19,
    value: u64,
};

pub const zx_type_1021 = struct {
    active: bool,
    ascending: bool,
    fact: u64,
    facts: []const u64,
    forest: *const zx_type_603,
    id: u64,
    layout: *const zx_type_584,
    leaving: bool,
    references: []const bool,
    root: u64,
    states: []const zx_type_582,
    types: *const zx_type_19,
};

pub const zx_type_1022 = struct {
    active: bool,
    cache: *const zx_type_615,
    found: bool,
    left: u64,
    right: u64,
    slot: u64,
    value: u64,
};

pub const zx_type_1023 = struct {
    active: bool,
    cache: *const zx_type_615,
    capacity: u64,
    grow: bool,
    index: u64,
    left: u64,
    right: u64,
    value: u64,
};

pub const zx_type_1024 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: *const zx_type_603,
    index: u64,
    references: []const bool,
    same: bool,
    type_id: u32,
    types: *const zx_type_19,
};

pub const zx_type_1025 = struct {
    action: zx_type_614,
    cache: *const zx_type_615,
    children: []const u64,
    first: []const u64,
    forest: *const zx_type_603,
    indices: []const u64,
    left: []const u64,
    paired: bool,
    references: []const bool,
    right: []const u64,
    types: *const zx_type_19,
    value: u64,
};

pub const zx_type_1026 = struct {
    expressions: u64,
    facts: []const u64,
    memo: []const u64,
    places: u64,
    states: []const zx_type_582,
};

pub const zx_type_1027 = struct { *const zx_type_574, *const zx_type_678, };

pub const zx_type_1028 = struct { *const zx_type_574, *const zx_type_678, *const zx_type_626, };

pub const zx_type_1029 = struct {
    action: zx_type_623,
    count: u64,
    index: u64,
    layout: *const zx_type_584,
    memo_first: u64,
    memory: *const zx_type_625,
    references: []const bool,
    rewrite_action: zx_type_614,
    saved: *const zx_type_624,
    state_first: u64,
    types: *const zx_type_19,
};

pub const zx_type_1031 = struct { []const zx_type_629, ?zx_type_629, };

pub const zx_type_1032 = struct { []const zx_type_629, void, };

pub const zx_type_1033 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_603,
    index: u64,
    merge: bool,
    parents: []const u64,
    references: []const bool,
    saved: []const u64,
    source: []const u64,
    types: *const zx_type_19,
};

pub const zx_type_1034 = struct {
    activation: u64,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: *const zx_type_603,
    index: u64,
    loops: *const zx_type_639,
    references: []const bool,
    seen: bool,
    types: *const zx_type_19,
    value: u64,
};

pub const zx_type_1035 = struct {
    activation: u64,
    changed: bool,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: *const zx_type_603,
    index: u64,
    loops: *const zx_type_639,
    references: []const bool,
    types: *const zx_type_19,
    value: u64,
};

pub const zx_type_1036 = struct {
    count: u64,
    facts: []const u64,
    first: u64,
    index: u64,
    layout: *const zx_type_584,
    local_first: u64,
    locals: u64,
    memory: *const zx_type_625,
    references: []const bool,
    roots: []const u64,
    symbols: []const u64,
    types: *const zx_type_19,
};

pub const zx_type_1037 = struct {
    count: u64,
    flags: []const bool,
    symbols: u64,
};

pub const zx_type_1038 = struct {
    count: u64,
    first: u64,
    flags: []const bool,
    index: u64,
    symbols: []const u64,
};

pub const zx_type_1039 = struct {
    flags: []const bool,
    index: u64,
    memo: []const u64,
    parents: []const u64,
};

pub const zx_type_1040 = struct {
    id: u64,
    parents: []const u64,
};

pub const zx_type_1041 = struct {
    facts: []const u64,
    flags: []const bool,
    index: u64,
    outputs: []const u64,
    roots: []const u64,
    source: []const u64,
};

pub const zx_type_1042 = struct {
    found: bool,
    index: u64,
    slots: *const zx_type_236,
};

pub const zx_type_1043 = struct {
    active: bool,
    ascending: bool,
    expression: u64,
    expressions: *const zx_type_216,
    found: bool,
    layout: *const zx_type_589,
    memo: []const u64,
    position: u64,
    trail: []const u64,
};

pub const zx_type_1044 = struct {
    children: []const u64,
    count: u64,
    index: u64,
};

pub const zx_type_1045 = struct { *const zx_type_574, *const zx_type_679, };

pub const zx_type_1046 = struct { *const zx_type_574, *const zx_type_679, *const zx_type_633, };

pub const zx_type_1047 = struct { *const zx_type_575, };

pub const zx_type_1048 = struct { *const zx_type_575, *const zx_type_574, };

pub const zx_type_1049 = struct { *const zx_type_575, *const zx_type_574, *const zx_type_633, };

pub const zx_type_1050 = struct { *const zx_type_575, *const zx_type_574, *const zx_type_633, *const zx_type_666, };

pub const zx_type_1051 = struct { *const zx_type_680, *const zx_type_666, };

pub const zx_type_1052 = struct { *const zx_type_244, *const zx_type_263, };

pub const zx_type_1053 = struct { *const zx_type_244, *const zx_type_263, *const zx_type_265, };

pub const zx_type_1054 = struct { *const zx_type_244, *const zx_type_263, *const zx_type_265, *const zx_type_265, };

pub const zx_type_1055 = struct { *const zx_type_244, *const zx_type_263, *const zx_type_265, *const zx_type_265, *const zx_type_265, };

pub const zx_type_1056 = struct { *const zx_type_244, *const zx_type_263, *const zx_type_265, *const zx_type_265, *const zx_type_265, *const zx_type_265, };

pub const zx_type_1057 = struct { *const zx_type_244, *const zx_type_263, *const zx_type_265, *const zx_type_265, *const zx_type_265, *const zx_type_265, *const zx_type_265, };

pub const zx_type_1058 = struct { *const zx_type_244, *const zx_type_263, *const zx_type_265, *const zx_type_265, *const zx_type_265, *const zx_type_265, *const zx_type_265, *const zx_type_669, };

pub const value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_11 = null,
};

pub const value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
    zx_origin: ?*const zx_type_15 = null,
};

pub const value_zx_type_16_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53 = struct {
    base: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    delta: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    base: *const zx_type_18,
    delta: *const zx_type_18,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_21_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_21 = null,
};

pub const value_zx_type_28_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    end: u64,
    last_byte: u8,
    phase: zx_type_27,
    separators_valid: bool,
    zx_origin: ?*const zx_type_28 = null,
};

pub const value_zx_type_29_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    diagnostic: []const u8,
    end: u64,
    zx_origin: ?*const zx_type_29 = null,
};

pub const value_zx_type_36_14f151be98723b44a65ef54272e86f37e634a51c57971b7cdbf77db5daef53fc = struct {
    ahead_one: u8,
    ahead_two: u8,
    braces: u64,
    comments: []const *const zx_type_25,
    depth: u64,
    diagnostic: *const zx_type_31,
    dollar: bool,
    frames: []const *const zx_type_32,
    keyword_state: u64,
    line_break: bool,
    mode: zx_type_30,
    number: value_zx_type_28_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    offset: u64,
    skip_until: u64,
    source_length: u64,
    start: u64,
    symbol: zx_type_24,
    tokens: []const *const zx_type_26,
    warmed: u8,
    zx_origin: ?*const zx_type_36 = null,
};

pub const value_zx_type_37_e1ffa7811185b0059f03a475523fa4c6e0b5b5a864f30612add6a83cb730f9cf = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    state: value_zx_type_36_14f151be98723b44a65ef54272e86f37e634a51c57971b7cdbf77db5daef53fc,
    zx_origin: ?*const zx_type_37 = null,
};

pub const value_zx_type_45_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    fields: []const u64,
    heads: []const u64,
    items: []const u64,
    zx_origin: ?*const zx_type_45 = null,
};

pub const value_zx_type_49_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    fields: []const *const zx_type_42,
    items: []const *const zx_type_43,
    nodes: []const *const zx_type_41,
    zx_origin: ?*const zx_type_49 = null,
};

pub const value_zx_type_51_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    depth: u64,
    diagnostic: *const zx_type_31,
    index: u64,
    name: *const zx_type_25,
    phase: zx_type_40,
    result: u64,
    start: u64,
    token: *const zx_type_26,
    zx_origin: ?*const zx_type_51 = null,
};

pub const value_zx_type_53_3d4acdf86258039cbdbe5c274a8acd76d0c1d090dc7f46092a910e9027d72b99 = struct {
    control: value_zx_type_51_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    frames: []const *const zx_type_50,
    tree: value_zx_type_49_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_53 = null,
};

pub const value_zx_type_56_1f6cf931ff1653b987809c8802c1c5135603b2eaa9fca3d6a77de94ccab3545b = struct {
    count: u64,
    depth: u64,
    diagnostic: *const zx_type_31,
    enumeration: bool,
    first: u64,
    index: u64,
    last_end: u64,
    name: *const zx_type_25,
    opening: u64,
    opening_index: u64,
    phase: zx_type_54,
    start: u64,
    token: *const zx_type_26,
    type_diagnostic: bool,
    zx_origin: ?*const zx_type_56 = null,
};

pub const value_zx_type_58_d4c36911b9e29c07c9fb12b56567bd5ba9d6014af03c3a6e74374757c00d5bea = struct {
    control: value_zx_type_56_1f6cf931ff1653b987809c8802c1c5135603b2eaa9fca3d6a77de94ccab3545b,
    declarations: []const *const zx_type_55,
    members: []const *const zx_type_25,
    types: value_zx_type_53_3d4acdf86258039cbdbe5c274a8acd76d0c1d090dc7f46092a910e9027d72b99,
    zx_origin: ?*const zx_type_58 = null,
};

pub const value_zx_type_73_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    declarations: []const *const zx_type_65,
    enumerations: []const *const zx_type_66,
    fields: []const *const zx_type_63,
    items: []const *const zx_type_64,
    members: []const *const zx_type_60,
    nodes: []const *const zx_type_62,
    zx_origin: ?*const zx_type_73 = null,
};

pub const value_zx_type_74_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    members: []const *const zx_type_25,
    order: value_zx_type_45_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_49_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_74 = null,
};

pub const value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203 = struct {
    indexed: value_zx_type_74_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97,
    native: ?value_zx_type_73_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_76 = null,
};

pub const value_zx_type_79_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441 = struct {
    aliases: *const zx_type_78,
    base: *const zx_type_18,
    native_interface: bool,
    resolved: *const zx_type_78,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    visiting: []const []const u8,
    zx_origin: ?*const zx_type_79 = null,
};

pub const value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72 = struct {
    active: []const []const u8,
    cache: *const zx_type_78,
    context: value_zx_type_79_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    frames: []const *const zx_type_80,
    result: u32,
    scratch: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_82 = null,
};

pub const value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2 = struct {
    cache: *const zx_type_78,
    context: value_zx_type_79_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441,
    delta: *const zx_type_18,
    initialize: bool,
    name: *const zx_type_60,
    named: bool,
    reference: *const zx_type_61,
    zx_origin: ?*const zx_type_83 = null,
};

pub const value_zx_type_84_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
    zx_origin: ?*const zx_type_84 = null,
};

pub const value_zx_type_93_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    events: []const *const zx_type_89,
    lexed: *const zx_type_38,
    parts: []const *const zx_type_88,
    templates: []const *const zx_type_87,
    token_templates: []const u64,
    zx_origin: ?*const zx_type_93 = null,
};

pub const value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    interpolations: []const *const zx_type_94,
    lexed: *const zx_type_38,
    parts: []const *const zx_type_88,
    templates: []const *const zx_type_87,
    token_templates: []const u64,
    zx_origin: ?*const zx_type_96 = null,
};

pub const value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    after_identifier: bool,
    arrow: bool,
    hints: []const *const zx_type_100,
    parameter_start: bool,
    zx_origin: ?*const zx_type_102 = null,
};

pub const value_zx_type_104_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1 = struct {
    hints: []const *const zx_type_100,
    interpolation_hints: []const []const *const zx_type_100,
    lexical: value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_104 = null,
};

pub const value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    arms: []const *const zx_type_112,
    fields: []const *const zx_type_109,
    items: []const *const zx_type_43,
    nodes: []const *const zx_type_108,
    parameters: []const *const zx_type_110,
    parts: []const *const zx_type_111,
    zx_origin: ?*const zx_type_118 = null,
};

pub const value_zx_type_122_b14d81bd852082d928c7e97a3a48f317953fa9f765bc0c0407cdb3f926b69b5e = struct {
    control: *const zx_type_120,
    frames: []const *const zx_type_119,
    prepared: value_zx_type_104_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1,
    tree: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_53_3d4acdf86258039cbdbe5c274a8acd76d0c1d090dc7f46092a910e9027d72b99,
    zx_origin: ?*const zx_type_122 = null,
};

pub const value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    blocks: []const *const zx_type_87,
    cases: []const *const zx_type_128,
    items: []const *const zx_type_43,
    names: []const *const zx_type_127,
    statements: []const *const zx_type_126,
    zx_origin: ?*const zx_type_132 = null,
};

pub const value_zx_type_138_8479351ede6be59f4cda24c2c469bcb9266110074e57ce839eee441715fb7524 = struct {
    control: *const zx_type_134,
    expression: value_zx_type_122_b14d81bd852082d928c7e97a3a48f317953fa9f765bc0c0407cdb3f926b69b5e,
    frame: *const zx_type_133,
    frames: []const *const zx_type_133,
    suspended: []const *const zx_type_136,
    tree: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_138 = null,
};

pub const value_zx_type_141_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    contract_start: u64,
    diagnostic: *const zx_type_31,
    ensures: bool,
    expression_diagnostic: bool,
    has_ensures: bool,
    has_store: bool,
    phase: zx_type_139,
    token: *const zx_type_26,
    zx_origin: ?*const zx_type_141 = null,
};

pub const value_zx_type_143_2b945e954668d79a1828a63af686318e734737f524f3484029ebbdb1c25be8f2 = struct {
    body: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    contracts: []const *const zx_type_140,
    control: value_zx_type_141_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    expression: value_zx_type_122_b14d81bd852082d928c7e97a3a48f317953fa9f765bc0c0407cdb3f926b69b5e,
    zx_origin: ?*const zx_type_143 = null,
};

pub const value_zx_type_147_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d = struct {
    count: u64,
    diagnostic: *const zx_type_31,
    first: u64,
    index: u64,
    named: bool,
    opening: *const zx_type_25,
    path: *const zx_type_25,
    phase: zx_type_144,
    start: u64,
    token: *const zx_type_26,
    type_only: bool,
    zx_origin: ?*const zx_type_147 = null,
};

pub const value_zx_type_149_74ed739624cff66047721e4df18908cd0e813cc99bd4a24ae4f125763c8bb979 = struct {
    control: value_zx_type_147_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d,
    imports: []const *const zx_type_146,
    names: []const *const zx_type_25,
    zx_origin: ?*const zx_type_149 = null,
};

pub const value_zx_type_151_3191ede17c96f03fe92fcee2a142bf07dadade62fc1258eb19ab63856e0a826a = struct {
    blocks: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    body: ?u64,
    comments: []const *const zx_type_25,
    contracts: []const *const zx_type_140,
    declarations: []const *const zx_type_55,
    diagnostic: *const zx_type_31,
    expressions: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    function_start: u64,
    has_store: bool,
    import_names: []const *const zx_type_25,
    imports: []const *const zx_type_146,
    members: []const *const zx_type_25,
    tokens: []const *const zx_type_26,
    type_order: value_zx_type_45_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_49_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_151 = null,
};

pub const value_zx_type_152_d14aba735b0c187625e56713e243f7433aa1db3df3f6db783432ba1fe4c75e84 = struct {
    blocks: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    comments: []const *const zx_type_25,
    diagnostic: *const zx_type_31,
    expressions: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    result: u64,
    tokens: []const *const zx_type_26,
    type_order: value_zx_type_45_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_49_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_152 = null,
};

pub const value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1 = struct {
    aliases: *const zx_type_78,
    bytes: []const u8,
    nominal_base: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    nominal_origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    shared: bool,
    syntax: value_zx_type_151_3191ede17c96f03fe92fcee2a142bf07dadade62fc1258eb19ab63856e0a826a,
    type_base: *const zx_type_18,
    zx_origin: ?*const zx_type_153 = null,
};

pub const value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380 = struct {
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    request: value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2,
    shared: bool,
    zx_origin: ?*const zx_type_154 = null,
};

pub const value_zx_type_155_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    name: *const zx_type_60,
    operation: zx_type_77,
    reference: *const zx_type_61,
    zx_origin: ?*const zx_type_155 = null,
};

pub const value_zx_type_156_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_156 = null,
};

pub const value_zx_type_157_ce77ce34d8b07d2d8cf3d14edad6ab93dcb0763a67b7d556988b9d1c501ca5d6 = struct {
    code: []const u8,
    message: []const u8,
    name: *const zx_type_60,
    state: value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_157 = null,
};

pub const value_zx_type_159_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    source: []const u8,
    span: *const zx_type_25,
    zx_origin: ?*const zx_type_159 = null,
};

pub const value_zx_type_160_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    index: u64,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_160 = null,
};

pub const value_zx_type_161_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b = struct {
    limit: u64,
    name: []const u8,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_161 = null,
};

pub const value_zx_type_162_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    index: u64,
    zx_origin: ?*const zx_type_162 = null,
};

pub const value_zx_type_163_1f89c88e8344df3ff0e1ae6aeca43f8d4c75d21269ca1cbbd88f24f6f34f4e80 = struct {
    index: u64,
    state: value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_163 = null,
};

pub const value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_164 = null,
};

pub const value_zx_type_165_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_165 = null,
};

pub const value_zx_type_166_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    delta: *const zx_type_18,
    id: u32,
    zx_origin: ?*const zx_type_166 = null,
};

pub const value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d = struct {
    children: []const u32,
    count: u64,
    field_names: []const []const u8,
    field_types: []const u32,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    names: []const []const u8,
    offset: u64,
    second: u32,
    zx_origin: ?*const zx_type_167 = null,
};

pub const value_zx_type_168_6f975b180818098029dbaef75bb89bfea5e3cb89ee69a1d9370d1963760c4a33 = struct {
    left: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    right: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_168 = null,
};

pub const value_zx_type_169_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u64,
    table: *const zx_type_18,
    zx_origin: ?*const zx_type_169 = null,
};

pub const value_zx_type_170_2c4a87f781c651962259ae1ef67d878ae312a61c3d14b66307e5fd0a9c7f1e1e = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    id: u32,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_170 = null,
};

pub const value_zx_type_171_f9f434bc9d0869ee4fe93b8f2d75449d97ec21cc1ea12455f1df810be7821e22 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_171 = null,
};

pub const value_zx_type_172_655f2c15f8b96113ed59dee46636710e0c7433f1f71d56fc2c400bda5a955e85 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    delta: *const zx_type_18,
    zx_origin: ?*const zx_type_172 = null,
};

pub const value_zx_type_173_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_173 = null,
};

pub const value_zx_type_174_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    code: []const u8,
    message: []const u8,
    zx_origin: ?*const zx_type_174 = null,
};

pub const value_zx_type_175_655f2c15f8b96113ed59dee46636710e0c7433f1f71d56fc2c400bda5a955e85 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    table: *const zx_type_18,
    zx_origin: ?*const zx_type_175 = null,
};

pub const value_zx_type_176_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    delta: *const zx_type_18,
    diagnostic: value_zx_type_174_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    id: u32,
    zx_origin: ?*const zx_type_176 = null,
};

pub const value_zx_type_177_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u32,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_177 = null,
};

pub const value_zx_type_179_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_179 = null,
};

pub const value_zx_type_180_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    id: u32,
    native_references: bool,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_180 = null,
};

pub const value_zx_type_182_5443cbe39f2296ef486982bb05040a6b5c31305900fd32c8ae6836a1865363f0 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    state: value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_182 = null,
};

pub const value_zx_type_183_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b = struct {
    enumeration: u64,
    index: u64,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_183 = null,
};

pub const value_zx_type_184_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    reference: *const zx_type_61,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_184 = null,
};

pub const value_zx_type_185_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    cache: *const zx_type_78,
    name: []const u8,
    zx_origin: ?*const zx_type_185 = null,
};

pub const value_zx_type_186_1f89c88e8344df3ff0e1ae6aeca43f8d4c75d21269ca1cbbd88f24f6f34f4e80 = struct {
    frame: *const zx_type_80,
    state: value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_186 = null,
};

pub const value_zx_type_187_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    position: u64,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_187 = null,
};

pub const value_zx_type_189_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    status: zx_type_188,
    zx_origin: ?*const zx_type_189 = null,
};

pub const value_zx_type_190_edb46a81e3a9250d692663665486205b0963b7c46abe2f9b6643551737beb15e = struct {
    base: *const zx_type_18,
    delta: *const zx_type_18,
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_190 = null,
};

pub const value_zx_type_191_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922 = struct {
    conflict: bool,
    delta: *const zx_type_18,
    mapping: []const u32,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_191 = null,
};

pub const value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    first: u64,
    ids: []const u32,
    zx_origin: ?*const zx_type_192 = null,
};

pub const value_zx_type_193_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u32,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_193 = null,
};

pub const value_zx_type_194_fbdd0bbee4e5905ca68915c135c8f5ba02cf4ff8d787022f425a507d94539e8c = struct {
    delta: *const zx_type_18,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    source: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_194 = null,
};

pub const value_zx_type_195_f3e136596bb913040d3acf380956e911a786d1381833906adfd4791f1895a977 = struct {
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    source: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    target: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_195 = null,
};

pub const value_zx_type_196_2f01dc5af85efb2d97af6c7b092cb0b1f9d76fe55ba3ba47bf7d26986d7815c8 = struct {
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_16_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53,
    source: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_196 = null,
};

pub const value_zx_type_197_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    cache: *const zx_type_78,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_197 = null,
};

pub const value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7 = struct {
    cache: *const zx_type_78,
    context: value_zx_type_79_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441,
    delta: *const zx_type_18,
    nominal_delta: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_198 = null,
};

pub const value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3 = struct {
    diagnostic: *const zx_type_31,
    input_type: u32,
    output_type: u32,
    span: *const zx_type_25,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_199 = null,
};

pub const value_zx_type_200_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b = struct {
    syntax: value_zx_type_151_3191ede17c96f03fe92fcee2a142bf07dadade62fc1258eb19ab63856e0a826a,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_200 = null,
};

pub const value_zx_type_201_0ea70a654c996b481d21adcf7d737d39c48dd562c004794b63fd546bbbe193d3 = struct {
    name: []const u8,
    span: *const zx_type_25,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_201 = null,
};

pub const value_zx_type_202_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06 = struct {
    name: []const u8,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_202 = null,
};

pub const value_zx_type_235_27f6baed02dfb16b8bbeaef695a80d4899de28e19dde605fcd26d176c6e70749 = struct {
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_217,
    zx_origin: ?*const zx_type_235 = null,
};

pub const value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731 = struct {
    contracts: []const *const zx_type_224,
    control: []const *const zx_type_227,
    expressions: []const *const zx_type_216,
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_fallible: []const bool,
    native_modules: []const ?u32,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_217,
    roots: []const ?u32,
    stores: []const *const zx_type_236,
    zx_origin: ?*const zx_type_240 = null,
};

pub const value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    ids: []const u32,
    input_types: []const u32,
    names: []const []const u8,
    namespaces: []const ?[]const u8,
    output_types: []const u32,
    zx_origin: ?*const zx_type_241 = null,
};

pub const value_zx_type_242_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    type_ids: []const ?u32,
    type_names: []const ?[]const u8,
    writable: []const bool,
    zx_origin: ?*const zx_type_242 = null,
};

pub const value_zx_type_243_3a357295bc15378c8d9379bded45bab4c78ce157dc22ada26dc5eacb7e5e2528 = struct {
    aliases: *const zx_type_78,
    function_imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    functions: value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    nominal_base: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    nominal_origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    shared: bool,
    store_bindings: value_zx_type_242_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    store_type_count: u64,
    type_base: *const zx_type_18,
    zx_origin: ?*const zx_type_243 = null,
};

pub const value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4 = struct {
    bytes: []const u8,
    context: value_zx_type_243_3a357295bc15378c8d9379bded45bab4c78ce157dc22ada26dc5eacb7e5e2528,
    file_name: []const u8,
    syntax: value_zx_type_151_3191ede17c96f03fe92fcee2a142bf07dadade62fc1258eb19ab63856e0a826a,
    zx_origin: ?*const zx_type_244 = null,
};

pub const value_zx_type_245_fb9444ae20bb9c07873a4198c8ceb44a0a5d3acdf3cba00c822c567b3e88453d = struct {
    bindings: value_zx_type_242_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    type_count: u64,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_245 = null,
};

pub const value_zx_type_246_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    code: []const u8,
    id: u32,
    message: []const u8,
    zx_origin: ?*const zx_type_246 = null,
};

pub const value_zx_type_247_d17529268506104b33086a1bf700d239b7345719d8dc3014bc934df596f972c4 = struct {
    context: value_zx_type_243_3a357295bc15378c8d9379bded45bab4c78ce157dc22ada26dc5eacb7e5e2528,
    signature: value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3,
    zx_origin: ?*const zx_type_247 = null,
};

pub const value_zx_type_248_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    diagnostic: *const zx_type_31,
    stores: *const zx_type_236,
    zx_origin: ?*const zx_type_248 = null,
};

pub const value_zx_type_249_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    has_store: bool,
    span: *const zx_type_25,
    stores: *const zx_type_236,
    zx_origin: ?*const zx_type_249 = null,
};

pub const value_zx_type_250_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    allow_store: bool,
    diagnostic: *const zx_type_31,
    stores: *const zx_type_236,
    zx_origin: ?*const zx_type_250 = null,
};

pub const value_zx_type_251_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
    zx_origin: ?*const zx_type_251 = null,
};

pub const value_zx_type_253_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    conditions: []const u64,
    facts: value_zx_type_251_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    truths: []const bool,
    zx_origin: ?*const zx_type_253 = null,
};

pub const value_zx_type_254_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    first: []const ?u32,
    floors: []const u64,
    last: []const ?u32,
    parents: []const ?u32,
    starts: []const u64,
    zx_origin: ?*const zx_type_254 = null,
};

pub const value_zx_type_255_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    next: []const ?u32,
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_255 = null,
};

pub const value_zx_type_256_386c6731c19530fd8432acc84ff31b97d6ba880a96c10f7bdfa1616ee45da0f0 = struct {
    bindings: value_zx_type_255_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    current: ?u32,
    frames: value_zx_type_254_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_256 = null,
};

pub const value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69 = struct {
    active: []const u32,
    allow_store: bool,
    captures: value_zx_type_256_386c6731c19530fd8432acc84ff31b97d6ba880a96c10f7bdfa1616ee45da0f0,
    control: *const zx_type_227,
    expression_bindings: []const u32,
    expression_units: []const []const u8,
    expressions: *const zx_type_216,
    lambda_depth: u64,
    output_type: u32,
    refinement: value_zx_type_253_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    scope_floor: u64,
    stores: *const zx_type_236,
    symbols: *const zx_type_219,
    zx_origin: ?*const zx_type_257 = null,
};

pub const value_zx_type_258_539d28689d73e2d7988f395928c455fd14b02556a112f989000e7ec15641f78b = struct {
    allow_store: bool,
    signature: value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3,
    stores: *const zx_type_236,
    zx_origin: ?*const zx_type_258 = null,
};

pub const value_zx_type_259_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    name: []const u8,
    ownership: zx_type_217,
    span_end: u64,
    span_start: u64,
    table: *const zx_type_219,
    type_id: u32,
    zx_origin: ?*const zx_type_259 = null,
};

pub const value_zx_type_260_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    table: *const zx_type_219,
    zx_origin: ?*const zx_type_260 = null,
};

pub const value_zx_type_261_946d687d0c4ea3809039d5317ed7d2aba883a417cff00079d9283aa71ce54d7c = struct {
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: *const zx_type_60,
    scope_start: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_261 = null,
};

pub const value_zx_type_262_6c42e587ea37fcf9cebd3363bae951bc8d27c8514466872e4d2dccf9f350e428 = struct {
    diagnostic: *const zx_type_31,
    id: u32,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    zx_origin: ?*const zx_type_262 = null,
};

pub const value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed = struct {
    diagnostic: *const zx_type_31,
    input_type: u32,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_263 = null,
};

pub const value_zx_type_264_e3d960a538bc0725c13492fd4a28129ec1161eec31e7bb72a90b2d4b821d4284 = struct {
    diagnostic: *const zx_type_31,
    module: value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_264 = null,
};

pub const value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21 = struct {
    contracts: *const zx_type_224,
    names: []const []const u8,
    ownership: zx_type_217,
    root: ?u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    type_only: bool,
    types: []const u32,
    zx_origin: ?*const zx_type_265 = null,
};

pub const value_zx_type_266_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae = struct {
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    type_only: bool,
    zx_origin: ?*const zx_type_266 = null,
};

pub const value_zx_type_267_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_216,
    limit: u64,
    zx_origin: ?*const zx_type_267 = null,
};

pub const value_zx_type_268_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: []const *const zx_type_216,
    native_concurrent: []const bool,
    native_modules: []const ?u32,
    stores: []const *const zx_type_236,
    zx_origin: ?*const zx_type_268 = null,
};

pub const value_zx_type_269_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = struct {
    concurrent: bool,
    functions: value_zx_type_268_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_269 = null,
};

pub const value_zx_type_270_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_270 = null,
};

pub const value_zx_type_271_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    body: u32,
    captures: value_zx_type_270_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    parameters: []const u32,
    zx_origin: ?*const zx_type_271 = null,
};

pub const value_zx_type_272_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    borrows: []const bool,
    symbols: []const ?u32,
    values: []const u32,
    zx_origin: ?*const zx_type_272 = null,
};

pub const value_zx_type_273_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117 = struct {
    callback: value_zx_type_271_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    ignored: ?u32,
    initial: ?u32,
    kind: zx_type_205,
    result_type: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    zx_origin: ?*const zx_type_273 = null,
};

pub const value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct {
    bindings: value_zx_type_272_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    frames: []const *const zx_type_283,
    zx_origin: ?*const zx_type_285 = null,
};

pub const value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f = struct {
    blocks: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    bytes: []const u8,
    tree: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_287 = null,
};

pub const value_zx_type_288_d1d3079bb818786c6de7fe35a1b30dd3ac1d301e4180de5d8f3c6ef6b6a70962 = struct {
    expected: ?u32,
    node: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_288 = null,
};

pub const value_zx_type_302_37d199f1b50bfa5590430fb1ebc517221eb0ddef3e4e99045f9c200d682d2ab3 = struct {
    active: u64,
    captures: ?u32,
    depth: u64,
    facts: *const zx_type_252,
    floor: u64,
    zx_origin: ?*const zx_type_302 = null,
};

pub const value_zx_type_324_6652383135ce0d60d191e68b6c98178f0216e42ab6c6b6ba57bc43fe23362021 = struct {
    actions: []const zx_type_290,
    asynchronous: []const *const zx_type_303,
    binaries: []const *const zx_type_293,
    branches: []const *const zx_type_281,
    coercions: []const *const zx_type_291,
    conditionals: []const *const zx_type_294,
    imported: []const *const zx_type_298,
    indices: []const *const zx_type_292,
    iterations: []const *const zx_type_276,
    lists: []const *const zx_type_300,
    methods: []const *const zx_type_299,
    objects: []const *const zx_type_297,
    parallels: []const *const zx_type_304,
    selections: []const *const zx_type_295,
    sequences: []const *const zx_type_296,
    singles: []const u64,
    statements: []const u64,
    switches: []const *const zx_type_282,
    templates: []const *const zx_type_301,
    transforms: []const *const zx_type_274,
    updates: []const *const zx_type_280,
    zx_origin: ?*const zx_type_324 = null,
};

pub const value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519 = struct {
    boundary: value_zx_type_302_37d199f1b50bfa5590430fb1ebc517221eb0ddef3e4e99045f9c200d682d2ab3,
    concurrent: []const bool,
    expected: ?u32,
    frames: value_zx_type_324_6652383135ce0d60d191e68b6c98178f0216e42ab6c6b6ba57bc43fe23362021,
    functions: value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    node: u64,
    phase: zx_type_289,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_325 = null,
};

pub const value_zx_type_326_a986431fc03b854e809a69648942c955b0d0576700ff151ca27f5ac1b466e8cc = struct {
    functions: value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    request: value_zx_type_288_d1d3079bb818786c6de7fe35a1b30dd3ac1d301e4180de5d8f3c6ef6b6a70962,
    zx_origin: ?*const zx_type_326 = null,
};

pub const value_zx_type_328_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    head: u64,
    items: []const *const zx_type_43,
    zx_origin: ?*const zx_type_328 = null,
};

pub const value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    frames: []const *const zx_type_329,
    pending: *const zx_type_227,
    returns: []const bool,
    zx_origin: ?*const zx_type_331 = null,
};

pub const value_zx_type_332_27b7012a26a73d97bac7467afd13b6a2da60e01ed0b842a63e3c18cfb1539446 = struct {
    block: u64,
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    tree: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_332 = null,
};

pub const value_zx_type_340_25fcf08c59c51140437c0c0f32db29701c62088cf889cabda7295d6d4cf49981 = struct {
    actions: []const zx_type_334,
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    branches: []const *const zx_type_335,
    expression: value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519,
    phase: zx_type_333,
    selections: []const *const zx_type_336,
    slot: u32,
    statement: u64,
    value: u32,
    zx_origin: ?*const zx_type_340 = null,
};

pub const value_zx_type_341_d3c7acf9e8d71dccd4fb902b4beee5200f637b6017f3a0e5521c8ee990af941a = struct {
    block: u64,
    functions: value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_341 = null,
};

pub const value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    span_end: u64,
    span_start: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_342 = null,
};

pub const value_zx_type_343_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    table: *const zx_type_216,
    zx_origin: ?*const zx_type_343 = null,
};

pub const value_zx_type_346_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    kind: zx_type_203,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    payload: u32,
    table: *const zx_type_216,
    zx_origin: ?*const zx_type_346 = null,
};

pub const value_zx_type_347_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    kind: zx_type_344,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    value: u32,
    zx_origin: ?*const zx_type_347 = null,
};

pub const value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae = struct {
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_348 = null,
};

pub const value_zx_type_349_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    expected: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_349 = null,
};

pub const value_zx_type_350_cf7f91935142e682a287d5d100dd4ce0b0109b30ee54eeca5ee330715975db08 = struct {
    body: u32,
    captures: []const u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    zx_origin: ?*const zx_type_350 = null,
};

pub const value_zx_type_351_b7022e5f7e6d6017e6486dabb7679bffcfe40734ccee3cfd445f9f3f9dd5c4b7 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_351 = null,
};

pub const value_zx_type_352_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    id: u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_352 = null,
};

pub const value_zx_type_357_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b = struct {
    functions: value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_357 = null,
};

pub const value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290 = struct {
    called: *const zx_type_353,
    context: value_zx_type_357_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b,
    frames: []const *const zx_type_355,
    names: []const []const u8,
    sources: []const *const zx_type_356,
    unknown: bool,
    zx_origin: ?*const zx_type_360 = null,
};

pub const value_zx_type_361_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea = struct {
    context: value_zx_type_357_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b,
    contracts: *const zx_type_224,
    control: *const zx_type_227,
    expression: u32,
    expressions: *const zx_type_216,
    program: bool,
    root: ?u32,
    stores: bool,
    zx_origin: ?*const zx_type_361 = null,
};

pub const value_zx_type_362_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    control: *const zx_type_227,
    returns: []const bool,
    selection: u64,
    zx_origin: ?*const zx_type_362 = null,
};

pub const value_zx_type_363_5821a6631fd0a2b5d5f68275f533e0b86f2430edbf1471339d13b94e742690d5 = struct {
    control: *const zx_type_227,
    expressions: *const zx_type_216,
    state: value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_363 = null,
};

pub const value_zx_type_364_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    source: u64,
    state: value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_364 = null,
};

pub const value_zx_type_365_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    contracts: *const zx_type_224,
    state: value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_365 = null,
};

pub const value_zx_type_366_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    frame: *const zx_type_355,
    state: value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_366 = null,
};

pub const value_zx_type_367_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    seen: *const zx_type_353,
    zx_origin: ?*const zx_type_367 = null,
};

pub const value_zx_type_368_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    fresh: bool,
    seen: *const zx_type_353,
    zx_origin: ?*const zx_type_368 = null,
};

pub const value_zx_type_369_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expressions: *const zx_type_216,
    index: u64,
    zx_origin: ?*const zx_type_369 = null,
};

pub const value_zx_type_370_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    names: []const []const u8,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    type_id: u32,
    zx_origin: ?*const zx_type_370 = null,
};

pub const value_zx_type_371_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    expressions: *const zx_type_216,
    index: u64,
    names: []const []const u8,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_371 = null,
};

pub const value_zx_type_372_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    index: u64,
    state: value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_372 = null,
};

pub const value_zx_type_373_61e72feecd2c7ea08919f23f45020799258e07ca40609f3ec3c2a2c121ab638d = struct {
    functions: value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_373 = null,
};

pub const value_zx_type_374_c10b56468fcdfc340efd837bc2bb5a1d1abf702877c05f5181a62bc3537de488 = struct {
    concurrent: []const bool,
    first: u64,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol_count: u64,
    zx_origin: ?*const zx_type_374 = null,
};

pub const value_zx_type_375_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    captures: []const u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_375 = null,
};

pub const value_zx_type_376_7e8ae8be50002306e9d0962406982db1fcca8341a5a0201e018f4d4519b03356 = struct {
    body: u32,
    concurrent: []const bool,
    first: u64,
    functions: value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol_count: u64,
    zx_origin: ?*const zx_type_376 = null,
};

pub const value_zx_type_377_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct {
    facts: value_zx_type_251_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    mark: *const zx_type_252,
    zx_origin: ?*const zx_type_377 = null,
};

pub const value_zx_type_378_8a0e8171bb34be7cea5536924946825257889020009cc44d8989d27b14418fbd = struct {
    left: u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    operator: zx_type_207,
    right: u32,
    table: *const zx_type_216,
    zx_origin: ?*const zx_type_378 = null,
};

pub const value_zx_type_379_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    comparison: bool,
    equality: bool,
    logical: bool,
    zx_origin: ?*const zx_type_379 = null,
};

pub const value_zx_type_380_758dce47268ce260391b79fcce19430100f29f81aa06dca556ac6c937c9b34ac = struct {
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    type_id: u32,
    zx_origin: ?*const zx_type_380 = null,
};

pub const value_zx_type_381_d3beea0968cbeae3a086396c9e5ffff3a98358d00a82ff4e47174659d0a5d370 = struct {
    left: u32,
    operator: zx_type_207,
    right: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_381 = null,
};

pub const value_zx_type_382_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct {
    facts: value_zx_type_251_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    symbol: u32,
    zx_origin: ?*const zx_type_382 = null,
};

pub const value_zx_type_383_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    expressions: *const zx_type_216,
    facts: value_zx_type_251_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    payload: u64,
    truth: bool,
    zx_origin: ?*const zx_type_383 = null,
};

pub const value_zx_type_384_180c8db61327c5ec28c1dd7044b5cf087f6bf11c71b70daa8f83a901fbf86853 = struct {
    condition: u64,
    expressions: *const zx_type_216,
    state: value_zx_type_253_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    truth: bool,
    zx_origin: ?*const zx_type_384 = null,
};

pub const value_zx_type_385_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    left: u32,
    operator: zx_type_207,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_385 = null,
};

pub const value_zx_type_386_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    expected: u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_386 = null,
};

pub const value_zx_type_387_398405e4d778524902904773ea675b0aeac3ad17463e51a805f63f94da7e856a = struct {
    action: zx_type_290,
    work: value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519,
    zx_origin: ?*const zx_type_387 = null,
};

pub const value_zx_type_388_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    element: u32,
    list: u32,
    name: []const u8,
    zx_origin: ?*const zx_type_388 = null,
};

pub const value_zx_type_389_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    code: []const u8,
    hints: []const u32,
    kind: zx_type_204,
    message: []const u8,
    replacement: bool,
    zx_origin: ?*const zx_type_389 = null,
};

pub const value_zx_type_390_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    head: u64,
    items: []const *const zx_type_43,
    zx_origin: ?*const zx_type_390 = null,
};

pub const value_zx_type_391_4cc958f044815e7193e188aa8d2b374a7d7b5bdc35e292ff41875ed7f5ad06b2 = struct {
    arguments: []const u32,
    kind: zx_type_204,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    target: u32,
    zx_origin: ?*const zx_type_391 = null,
};

pub const value_zx_type_392_8a0e8171bb34be7cea5536924946825257889020009cc44d8989d27b14418fbd = struct {
    index: u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    target: u32,
    value: u32,
    zx_origin: ?*const zx_type_392 = null,
};

pub const value_zx_type_393_320140e206741eb6a6c49f977db0f2408310cbbb6bc0068879af58c7913c6479 = struct {
    kind: zx_type_204,
    replacement: bool,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    values: []const u32,
    zx_origin: ?*const zx_type_393 = null,
};

pub const value_zx_type_394_1d596865a15a49bb75fc16c90a7dd21003bff94dbdf67563e2b022d273d3f10d = struct {
    expected: ?u32,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_394 = null,
};

pub const value_zx_type_395_8aa5028c1fa4881a2d1ecd5dd1891a11196fbe0a82cd5a6fb884bc582c9c12b3 = struct {
    frame: u32,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    zx_origin: ?*const zx_type_395 = null,
};

pub const value_zx_type_396_f03d027d90539c51366482b018ae66dc2f472151ba6834d7ee9d5e68f39bc19f = struct {
    node: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    types: []const u32,
    zx_origin: ?*const zx_type_396 = null,
};

pub const value_zx_type_397_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    body: u64,
    frame: u32,
    parameters: []const u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_397 = null,
};

pub const value_zx_type_398_031052d85d43fe0b78cc9d16de0b727534577b1c00a37aff1c2ad91211744f4a = struct {
    expected: ?u32,
    kind: zx_type_205,
    second: ?u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    zx_origin: ?*const zx_type_398 = null,
};

pub const value_zx_type_399_5de783d1563b20987c6dd1466aa53bc335bc49cdf5213bb1c1cc310c808cd9fd = struct {
    body: ?u32,
    parameters: []const u32,
    result: u32,
    zx_origin: ?*const zx_type_399 = null,
};

pub const value_zx_type_400_398405e4d778524902904773ea675b0aeac3ad17463e51a805f63f94da7e856a = struct {
    name: []const u8,
    work: value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519,
    zx_origin: ?*const zx_type_400 = null,
};

pub const value_zx_type_401_8a0e8171bb34be7cea5536924946825257889020009cc44d8989d27b14418fbd = struct {
    condition: u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    no: u32,
    table: *const zx_type_216,
    yes: u32,
    zx_origin: ?*const zx_type_401 = null,
};

pub const value_zx_type_402_208aa70893ffd89deeb12476fa37935a6d473e7b89bb1e3e05e8d4835750280d = struct {
    facts: value_zx_type_251_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    symbol: u32,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    type_id: u32,
    zx_origin: ?*const zx_type_402 = null,
};

pub const value_zx_type_403_66dd4c90d45184bc766e20e49e9a6da896057c0f8267927eca5c31ac05ae261e = struct {
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    zx_origin: ?*const zx_type_403 = null,
};

pub const value_zx_type_404_63d147828f65d3607200b5ba26d827f7ceddb4bcc75a4c77c08a3e4e2680fe3d = struct {
    node: u64,
    path: []const u8,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_404 = null,
};

pub const value_zx_type_405_a5e97b5d148979078fb526bf8b0a3f2e3879dc81aae4d331b8d02ba4a40dbdbf = struct {
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    node: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_405 = null,
};

pub const value_zx_type_406_b697f8130174a859aa6986a4ae35912f4dbf2e3d0251d6c8876d483068ea65bd = struct {
    symbol: ?u32,
    unit: bool,
    zx_origin: ?*const zx_type_406 = null,
};

pub const value_zx_type_409_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a = struct {
    imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_409 = null,
};

pub const value_zx_type_411_d6f05b6a7468cda4e0cb0471293b5bc9c924753364f601fd75acaf11c9c13f34 = struct {
    context: value_zx_type_409_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a,
    frames: []const *const zx_type_408,
    result: ?u32,
    zx_origin: ?*const zx_type_411 = null,
};

pub const value_zx_type_412_c4fdb933f579107fe690837d45be4bfbc2ab7010fb3d9757ce268ea44cbe7a71 = struct {
    callee: u64,
    context: value_zx_type_409_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a,
    zx_origin: ?*const zx_type_412 = null,
};

pub const value_zx_type_413_e8147ecb68420dc730dce1b61adbbf549a04cf8791e4c2684653218e80bf9ade = struct {
    context: value_zx_type_409_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a,
    node: u64,
    zx_origin: ?*const zx_type_413 = null,
};

pub const value_zx_type_414_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct {
    handled: bool,
    type_id: ?u32,
    zx_origin: ?*const zx_type_414 = null,
};

pub const value_zx_type_415_a4e28b9aa9bec82279c7697dfd19ce9bb7344a5a9111c1bc7390c1d7bb70d5e6 = struct {
    node: u64,
    work: value_zx_type_411_d6f05b6a7468cda4e0cb0471293b5bc9c924753364f601fd75acaf11c9c13f34,
    zx_origin: ?*const zx_type_415 = null,
};

pub const value_zx_type_416_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    floating: bool,
    separators: bool,
    zx_origin: ?*const zx_type_416 = null,
};

pub const value_zx_type_417_63d147828f65d3607200b5ba26d827f7ceddb4bcc75a4c77c08a3e4e2680fe3d = struct {
    left: u64,
    right: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_417 = null,
};

pub const value_zx_type_418_d1334bc45f95292594200d1d386af54ad2694049d5073c61166233cf0c59cca5 = struct {
    node: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_418 = null,
};

pub const value_zx_type_419_857eb865ac7e63d23c084d39c9d182e776e834af701d182a80c35ea041ec42c4 = struct {
    context: value_zx_type_409_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a,
    frame: *const zx_type_408,
    type_id: u32,
    zx_origin: ?*const zx_type_419 = null,
};

pub const value_zx_type_420_d483752daf6f2499abf5821d84984c199ae0e80e071318f70d6eaad6c9a6f411 = struct {
    context: value_zx_type_409_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a,
    expected: ?u32,
    node: u64,
    zx_origin: ?*const zx_type_420 = null,
};

pub const value_zx_type_421_4cc958f044815e7193e188aa8d2b374a7d7b5bdc35e292ff41875ed7f5ad06b2 = struct {
    argument: u32,
    function_id: u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    stores: []const u32,
    table: *const zx_type_216,
    zx_origin: ?*const zx_type_421 = null,
};

pub const value_zx_type_422_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    optional: bool,
    table: *const zx_type_216,
    zx_origin: ?*const zx_type_422 = null,
};

pub const value_zx_type_423_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    kind: zx_type_345,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    values: []const u32,
    zx_origin: ?*const zx_type_423 = null,
};

pub const value_zx_type_424_fd7a6dc827118410c36e21cce8ddad7179973d8786aa21dfc2a8c2f51f48f835 = struct {
    body: u32,
    condition: u32,
    condition_parameter: u32,
    initial: u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    parameter: u32,
    postcondition: bool,
    table: *const zx_type_216,
    zx_origin: ?*const zx_type_424 = null,
};

pub const value_zx_type_425_6d8b876cf043ee5d5e88ca2f8429bbfe364811df5a12532f9673eae08f9ea7be = struct {
    node: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    type_id: u32,
    updating: bool,
    zx_origin: ?*const zx_type_425 = null,
};

pub const value_zx_type_426_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    body: u64,
    context: *const zx_type_275,
    parameter: u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_426 = null,
};

pub const value_zx_type_427_8aa5028c1fa4881a2d1ecd5dd1891a11196fbe0a82cd5a6fb884bc582c9c12b3 = struct {
    context: *const zx_type_275,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    zx_origin: ?*const zx_type_427 = null,
};

pub const value_zx_type_428_cf2c185f503109ab892b84b39da09b633a610070b4dacaa8d4793767c39471d5 = struct {
    conditions: []const u32,
    fallback: u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    results: []const u32,
    subject: ?u32,
    table: *const zx_type_216,
    zx_origin: ?*const zx_type_428 = null,
};

pub const value_zx_type_429_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    entries: *const zx_type_286,
    name: []const u8,
    value: u32,
    zx_origin: ?*const zx_type_429 = null,
};

pub const value_zx_type_430_8a0e8171bb34be7cea5536924946825257889020009cc44d8989d27b14418fbd = struct {
    index: u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    target: u32,
    tuple: bool,
    zx_origin: ?*const zx_type_430 = null,
};

pub const value_zx_type_431_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    entries: *const zx_type_286,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_431 = null,
};

pub const value_zx_type_432_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    entries: *const zx_type_286,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_432 = null,
};

pub const value_zx_type_433_4cc958f044815e7193e188aa8d2b374a7d7b5bdc35e292ff41875ed7f5ad06b2 = struct {
    evaluation: []const u32,
    indices: []const u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    values: []const u32,
    zx_origin: ?*const zx_type_433 = null,
};

pub const value_zx_type_434_f61a34c050d4f456cdc1f1b11a4488c1a69373c43cb0a50164ff3b85629ae16c = struct {
    entries: *const zx_type_286,
    evaluation: []const u32,
    hint: ?u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_434 = null,
};

pub const value_zx_type_435_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    entries: *const zx_type_286,
    evaluation: []const u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_435 = null,
};

pub const value_zx_type_436_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    fields: []const ?u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    tasks: []const u32,
    zx_origin: ?*const zx_type_436 = null,
};

pub const value_zx_type_437_de45a800d67dbd5a954a7ea2592b79ae8578b35193363bc4e40f5e0050e78b60 = struct {
    functions: value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    operand: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_437 = null,
};

pub const value_zx_type_438_514b8247d8ac45dc9a48b26ab84281962bbd77a9d5481b83c41f75eb0f777c3e = struct {
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    operand: u32,
    operator: zx_type_206,
    table: *const zx_type_216,
    zx_origin: ?*const zx_type_438 = null,
};

pub const value_zx_type_439_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    negative: bool,
    operand: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_439 = null,
};

pub const value_zx_type_440_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    name: *const zx_type_60,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    zx_origin: ?*const zx_type_440 = null,
};

pub const value_zx_type_441_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    index: u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    target: u32,
    zx_origin: ?*const zx_type_441 = null,
};

pub const value_zx_type_442_c10b56468fcdfc340efd837bc2bb5a1d1abf702877c05f5181a62bc3537de488 = struct {
    index: u32,
    index_span: *const zx_type_25,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    zx_origin: ?*const zx_type_442 = null,
};

pub const value_zx_type_443_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    zx_origin: ?*const zx_type_443 = null,
};

pub const value_zx_type_444_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    cancellation: bool,
    operand: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_444 = null,
};

pub const value_zx_type_445_8c1d402feed71d5be501dd118718c8941180b5b47dbfeceb6cb3fb71882a9add = struct {
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: *const zx_type_60,
    scope_start: u64,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    value: u32,
    zx_origin: ?*const zx_type_445 = null,
};

pub const value_zx_type_446_071bfa4a6872a664aae79520a5231728ab2c1ead6d3e44b0c51bf20b4067b027 = struct {
    diagnostic: *const zx_type_31,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    symbol: u32,
    zx_origin: ?*const zx_type_446 = null,
};

pub const value_zx_type_447_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    err: u32,
    facts: value_zx_type_251_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: u32,
    zx_origin: ?*const zx_type_447 = null,
};

pub const value_zx_type_448_073d891ba45095e5915c165198921d39ae001c11a900ba5941237395e3848750 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_216,
    facts: value_zx_type_251_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: ?u32,
    value: u64,
    zx_origin: ?*const zx_type_448 = null,
};

pub const value_zx_type_449_c5dd19f4e7f36f068d5a7a3ffb0d98e2195433b7ead24ca3660081c76dc44acf = struct {
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: *const zx_type_60,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    zx_origin: ?*const zx_type_449 = null,
};

pub const value_zx_type_450_b7b2ab1b57db04a2d9173a45213e4ebf3682ff85da6e9f0f4545139fbb3fa85b = struct {
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    value: u32,
    zx_origin: ?*const zx_type_450 = null,
};

pub const value_zx_type_451_071bfa4a6872a664aae79520a5231728ab2c1ead6d3e44b0c51bf20b4067b027 = struct {
    diagnostic: *const zx_type_31,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    value: u32,
    zx_origin: ?*const zx_type_451 = null,
};

pub const value_zx_type_452_e5a82e07a2f8fa078df5034296876c7e922c6afafdc6dc91c02ffcd9117e463d = struct {
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    statement: u64,
    value: u32,
    zx_origin: ?*const zx_type_452 = null,
};

pub const value_zx_type_453_c558d374130410987b090947fa981755686fb618962601d0de6c2613a44c4785 = struct {
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_453 = null,
};

pub const value_zx_type_454_1a6760d00bf1c9003cbcfb5abdde768513d5a3da8c714d4e24fc2174f9a67d14 = struct {
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    value: u32,
    zx_origin: ?*const zx_type_454 = null,
};

pub const value_zx_type_455_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol: u32,
    zx_origin: ?*const zx_type_455 = null,
};

pub const value_zx_type_456_ef418fd216c53fd927fb13f77762d8888382f3c1957ef5c6ba04865917651a2d = struct {
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    span: *const zx_type_25,
    value: u32,
    zx_origin: ?*const zx_type_456 = null,
};

pub const value_zx_type_457_70368df1a566c9de055a94a3e9adf4361ddab8e71140bdb84b7925d6f0a19d05 = struct {
    diagnostic: *const zx_type_31,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    zx_origin: ?*const zx_type_457 = null,
};

pub const value_zx_type_458_7b8b63d14d9fdc158cc85548dfa2416c1d843e86616a3cc0633f7b8ca55231de = struct {
    block: u64,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    state_symbol: u32,
    tree: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_458 = null,
};

pub const value_zx_type_459_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expressions: *const zx_type_216,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_459 = null,
};

pub const value_zx_type_460_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    previous: []const u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_460 = null,
};

pub const value_zx_type_461_ed2ab87d2bb47c97942d4ee504ffba775c1edbfbfa8ebf1e4e97e5cf49214553 = struct {
    read_value: bool,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    state_symbol: u32,
    target: u32,
    zx_origin: ?*const zx_type_461 = null,
};

pub const value_zx_type_463_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    diagnostic: *const zx_type_31,
    frames: []const *const zx_type_277,
    zx_origin: ?*const zx_type_463 = null,
};

pub const value_zx_type_464_29b8bb2c9220c4b8f09be5148fdae78d6fe459dc123072bc4d45410b5a846b96 = struct {
    read_value: bool,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    state_symbol: u32,
    target: u32,
    zx_origin: ?*const zx_type_464 = null,
};

pub const value_zx_type_465_67fdbd174b3a8e88ef9b945e32fb70a796e4af2ede9a634500cb0b7c6b54ad6a = struct {
    places: []const *const zx_type_278,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_465 = null,
};

pub const value_zx_type_466_8f0278930ba6adb4eb4098f36d8f2cdeec2915ef557ad5c3bd4f7b2c6c11f572 = struct {
    parent: u32,
    selected: u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    tuple: bool,
    value: u32,
    zx_origin: ?*const zx_type_466 = null,
};

pub const value_zx_type_467_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    places: []const *const zx_type_278,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_467 = null,
};

pub const value_zx_type_468_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    value: []const u8,
    zx_origin: ?*const zx_type_468 = null,
};

pub const value_zx_type_469_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    source: []const u8,
    template: bool,
    zx_origin: ?*const zx_type_469 = null,
};

pub const value_zx_type_470_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    source: []const u8,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    template: bool,
    zx_origin: ?*const zx_type_470 = null,
};

pub const value_zx_type_471_c10b56468fcdfc340efd837bc2bb5a1d1abf702877c05f5181a62bc3537de488 = struct {
    name: []const u8,
    ownership: zx_type_217,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    type_id: u32,
    zx_origin: ?*const zx_type_471 = null,
};

pub const value_zx_type_472_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae = struct {
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol: u32,
    zx_origin: ?*const zx_type_472 = null,
};

pub const value_zx_type_473_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e = struct {
    bindings: value_zx_type_272_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    source: u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_473 = null,
};

pub const value_zx_type_474_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    value: bool,
    zx_origin: ?*const zx_type_474 = null,
};

pub const value_zx_type_475_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: bool,
    zx_origin: ?*const zx_type_475 = null,
};

pub const value_zx_type_476_514b8247d8ac45dc9a48b26ab84281962bbd77a9d5481b83c41f75eb0f777c3e = struct {
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    negative: bool,
    table: *const zx_type_216,
    value: u64,
    zx_origin: ?*const zx_type_476 = null,
};

pub const value_zx_type_477_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u64,
    zx_origin: ?*const zx_type_477 = null,
};

pub const value_zx_type_478_8115a2d724b597ff41263498f187c33ab1f087573c7d9a86c7ce96ceb5c8795f = struct {
    initial: ?u32,
    kind: zx_type_205,
    result_type: u32,
    source: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_478 = null,
};

pub const value_zx_type_479_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    fields: *const zx_type_286,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_479 = null,
};

pub const value_zx_type_480_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    values: []const u32,
    zx_origin: ?*const zx_type_480 = null,
};

pub const value_zx_type_481_7da9860be73e1d08e73da929e35fdaf7b5e10e03f0836665c51e514d78561a02 = struct {
    captures: []const u32,
    initial: ?u32,
    kind: zx_type_205,
    result: u32,
    source: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_481 = null,
};

pub const value_zx_type_482_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    initial: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_482 = null,
};

pub const value_zx_type_483_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    condition_parameter: u32,
    parameter: u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_483 = null,
};

pub const value_zx_type_484_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    kind: zx_type_205,
    parameter: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_484 = null,
};

pub const value_zx_type_485_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be = struct {
    callback: value_zx_type_271_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    kind: zx_type_205,
    parameter: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_485 = null,
};

pub const value_zx_type_486_a77e4162e607846786e14298a59c2e743a9752ef2fe6c98ae39887af0965c62c = struct {
    bindings: value_zx_type_272_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    current: u32,
    index: u32,
    item: u32,
    previous: u32,
    source: u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_486 = null,
};

pub const value_zx_type_487_ed2ab87d2bb47c97942d4ee504ffba775c1edbfbfa8ebf1e4e97e5cf49214553 = struct {
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    value: u32,
    zx_origin: ?*const zx_type_487 = null,
};

pub const value_zx_type_488_6bd979ddc38e9089ff343580aac7bbd290f506083ba1a522db596260b01dd22c = struct {
    item: u32,
    kind: zx_type_205,
    previous: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_488 = null,
};

pub const value_zx_type_489_5cbbc1e9c27f413358ca0364e5d2761d90343019c7ebd851830bd8b4023d818f = struct {
    captures: bool,
    current: u32,
    index: u32,
    result: u32,
    source: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_489 = null,
};

pub const value_zx_type_490_e71f3c44de88c731e7dbd31a1c034dc4e45cf9665e42d098bb8ba1b5ab878432 = struct {
    borrows: []const bool,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: u32,
    symbols: []const ?u32,
    table: *const zx_type_216,
    values: []const u32,
    zx_origin: ?*const zx_type_490 = null,
};

pub const value_zx_type_491_6d20ea482b833343b6028f7ee62eab338d8b454ae1dc5d197ef5c4b0547d062a = struct {
    bindings: value_zx_type_272_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    current: u32,
    result: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_491 = null,
};

pub const value_zx_type_492_02fc6614916cf53341130ecc0059ef28f684d013009cec2774f9ca5992c86c75 = struct {
    bindings: value_zx_type_272_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    body: u32,
    condition: u32,
    condition_parameter: u32,
    initial: u32,
    parameter: u32,
    result_type: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_492 = null,
};

pub const value_zx_type_493_96d93c32fedaebeb2e4335c6d4d02fbd166df43f1d9b9d167683516e6395793b = struct {
    captures: value_zx_type_256_386c6731c19530fd8432acc84ff31b97d6ba880a96c10f7bdfa1616ee45da0f0,
    frame: u32,
    zx_origin: ?*const zx_type_493 = null,
};

pub const value_zx_type_494_5cbbc1e9c27f413358ca0364e5d2761d90343019c7ebd851830bd8b4023d818f = struct {
    body: u32,
    frame: u32,
    kind: zx_type_205,
    parameters: []const u32,
    result_type: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_494 = null,
};

pub const value_zx_type_495_428e5f177681a4ece7b981df4c9b9917c0d51dd97564d93b590ba699d90f2b09 = struct {
    callback: value_zx_type_271_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    result_type: u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_495 = null,
};

pub const value_zx_type_496_8cc4942feb3b1fbbdb34610cb34c8018caeefae663b336ddcaf49c9715307c10 = struct {
    captures: value_zx_type_256_386c6731c19530fd8432acc84ff31b97d6ba880a96c10f7bdfa1616ee45da0f0,
    frame: u32,
    source: u32,
    target: u32,
    value: u32,
    zx_origin: ?*const zx_type_496 = null,
};

pub const value_zx_type_497_6393b1ac4c4256c8e70334e24894634855403fe8966d04dc252b47af11666264 = struct {
    captures: value_zx_type_256_386c6731c19530fd8432acc84ff31b97d6ba880a96c10f7bdfa1616ee45da0f0,
    frame: u32,
    source: u32,
    zx_origin: ?*const zx_type_497 = null,
};

pub const value_zx_type_498_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    frame: u32,
    source: u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_498 = null,
};

pub const value_zx_type_499_2bcfb17f8b5ada61753c7081b6d0a8994c8d4f122d1680941f810eb98e83ddca = struct {
    frame: u32,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    zx_origin: ?*const zx_type_499 = null,
};

pub const value_zx_type_500_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    name: *const zx_type_60,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_500 = null,
};

pub const value_zx_type_501_74ffaeb805922b745ff90f54cea71a77e4a1cff9fb0b01f504a23a5a4c263f8a = struct {
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol: ?u32,
    zx_origin: ?*const zx_type_501 = null,
};

pub const value_zx_type_502_cc2662a39a44280a9cc0900a7644cc7e5d856b6b16e6eed126424914cce8abd9 = struct {
    expected: ?u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_502 = null,
};

pub const value_zx_type_503_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_216,
    value: f64,
    zx_origin: ?*const zx_type_503 = null,
};

pub const value_zx_type_504_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    digit: u64,
    limbs: []const u64,
    zx_origin: ?*const zx_type_504 = null,
};

pub const value_zx_type_505_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    limbs: []const u64,
    overflow: bool,
    zx_origin: ?*const zx_type_505 = null,
};

pub const value_zx_type_506_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    significant: u64,
    trailing: u64,
    zx_origin: ?*const zx_type_506 = null,
};

pub const value_zx_type_507_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    bytes: []const u8,
    precision: u64,
    zx_origin: ?*const zx_type_507 = null,
};

pub const value_zx_type_510_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    bytes: []const u8,
    negative: bool,
    single: bool,
    zx_origin: ?*const zx_type_510 = null,
};

pub const value_zx_type_511_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    message: []const u8,
    value: f64,
    zx_origin: ?*const zx_type_511 = null,
};

pub const value_zx_type_512_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    negative: bool,
    zx_origin: ?*const zx_type_512 = null,
};

pub const value_zx_type_513_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    floating: bool,
    id: u32,
    integer: bool,
    signed: bool,
    zx_origin: ?*const zx_type_513 = null,
};

pub const value_zx_type_514_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922 = struct {
    floating: f64,
    integer: u64,
    message: []const u8,
    target: value_zx_type_513_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_514 = null,
};

pub const value_zx_type_515_5de783d1563b20987c6dd1466aa53bc335bc49cdf5213bb1c1cc310c808cd9fd = struct {
    expected: ?u32,
    floating: bool,
    negative: bool,
    zx_origin: ?*const zx_type_515 = null,
};

pub const value_zx_type_516_5de783d1563b20987c6dd1466aa53bc335bc49cdf5213bb1c1cc310c808cd9fd = struct {
    expected: ?u32,
    negative: bool,
    source: []const u8,
    zx_origin: ?*const zx_type_516 = null,
};

pub const value_zx_type_517_ebd7909577121487cee25f683f0a438ae6c5ac0acdf76a3ad6d079c94f8e07d5 = struct {
    expected: ?u32,
    negative: bool,
    source: []const u8,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_517 = null,
};

pub const value_zx_type_518_4a95a80a22abf19024e87679087d49375865ea3a9a1d6f11df28c643cd2bf19f = struct {
    node: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_518 = null,
};

pub const value_zx_type_519_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    slot: u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_519 = null,
};

pub const value_zx_type_520_c10b56468fcdfc340efd837bc2bb5a1d1abf702877c05f5181a62bc3537de488 = struct {
    error_member: bool,
    name: *const zx_type_60,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    type_id: u32,
    zx_origin: ?*const zx_type_520 = null,
};

pub const value_zx_type_521_4fa39ae4b3818fe82b441b9ff0fab0ef61fac8155f5719f07b7c9207c0d82355 = struct {
    handled: bool,
    result: value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae,
    zx_origin: ?*const zx_type_521 = null,
};

pub const value_zx_type_522_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    found: bool,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_522 = null,
};

pub const value_zx_type_523_d6e75a67ef3ff977d850655cf9d97725e7186d6275235af73e7042cd0fa75ba2 = struct {
    imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    name: []const u8,
    namespace: ?[]const u8,
    zx_origin: ?*const zx_type_523 = null,
};

pub const value_zx_type_524_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    index: u64,
    known_namespace: bool,
    zx_origin: ?*const zx_type_524 = null,
};

pub const value_zx_type_526_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    index: u64,
    route: zx_type_525,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_526 = null,
};

pub const value_zx_type_527_2c9e656b34818e8ea4d644375dcec12913bfb4a556cf3342b7be1fc9100ea365 = struct {
    imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    name: *const zx_type_60,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_527 = null,
};

pub const value_zx_type_528_48a506a01538af1e5c678d6cbd5b59ad6af05a7cddb3962430a08d42a64a6e94 = struct {
    imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    node: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_528 = null,
};

pub const value_zx_type_529_398405e4d778524902904773ea675b0aeac3ad17463e51a805f63f94da7e856a = struct {
    index: u64,
    work: value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519,
    zx_origin: ?*const zx_type_529 = null,
};

pub const value_zx_type_530_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    condition: u64,
    diagnostic: *const zx_type_31,
    initial: u64,
    postcondition: bool,
    step: u64,
    zx_origin: ?*const zx_type_530 = null,
};

pub const value_zx_type_531_b7b2ab1b57db04a2d9173a45213e4ebf3682ff85da6e9f0f4545139fbb3fa85b = struct {
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    span: *const zx_type_25,
    zx_origin: ?*const zx_type_531 = null,
};

pub const value_zx_type_532_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    reference: u64,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_532 = null,
};

pub const value_zx_type_533_6b377024a652d6223d88a2d381b58933d303496773134218a4819ded26bc33a9 = struct {
    node: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_533 = null,
};

pub const value_zx_type_534_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    first: u64,
    table: *const zx_type_227,
    zx_origin: ?*const zx_type_534 = null,
};

pub const value_zx_type_535_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    table: *const zx_type_227,
    zx_origin: ?*const zx_type_535 = null,
};

pub const value_zx_type_536_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    kind: zx_type_225,
    payload: u32,
    table: *const zx_type_227,
    zx_origin: ?*const zx_type_536 = null,
};

pub const value_zx_type_537_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    condition: u32,
    no: u32,
    table: *const zx_type_227,
    yes: u32,
    zx_origin: ?*const zx_type_537 = null,
};

pub const value_zx_type_538_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    symbol: u32,
    table: *const zx_type_227,
    value: u32,
    zx_origin: ?*const zx_type_538 = null,
};

pub const value_zx_type_539_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    symbols: []const ?u32,
    table: *const zx_type_227,
    value: u32,
    zx_origin: ?*const zx_type_539 = null,
};

pub const value_zx_type_540_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    table: *const zx_type_227,
    value: u32,
    zx_origin: ?*const zx_type_540 = null,
};

pub const value_zx_type_541_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    symbols: []const ?u32,
    table: *const zx_type_227,
    values: []const u32,
    zx_origin: ?*const zx_type_541 = null,
};

pub const value_zx_type_542_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct {
    table: *const zx_type_227,
    value: ?u32,
    zx_origin: ?*const zx_type_542 = null,
};

pub const value_zx_type_543_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    bodies: []const u32,
    exhaustive: bool,
    subject: u32,
    table: *const zx_type_227,
    values: []const ?u32,
    zx_origin: ?*const zx_type_543 = null,
};

pub const value_zx_type_544_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    slot: u32,
    table: *const zx_type_227,
    value: u32,
    zx_origin: ?*const zx_type_544 = null,
};

pub const value_zx_type_545_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    source: *const zx_type_227,
    target: *const zx_type_227,
    zx_origin: ?*const zx_type_545 = null,
};

pub const value_zx_type_546_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    mark: *const zx_type_327,
    table: *const zx_type_227,
    zx_origin: ?*const zx_type_546 = null,
};

pub const value_zx_type_547_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    first: u64,
    returns: []const bool,
    table: *const zx_type_227,
    zx_origin: ?*const zx_type_547 = null,
};

pub const value_zx_type_548_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    control: *const zx_type_227,
    mark: *const zx_type_327,
    pending: *const zx_type_227,
    returns: []const bool,
    zx_origin: ?*const zx_type_548 = null,
};

pub const value_zx_type_549_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    control: *const zx_type_227,
    id: u32,
    pending: *const zx_type_227,
    returns: []const bool,
    zx_origin: ?*const zx_type_549 = null,
};

pub const value_zx_type_550_52fa6beef097dbe29446bd7535633568b5ab6d9573b172c889ade0bf8af99bae = struct {
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    zx_origin: ?*const zx_type_550 = null,
};

pub const value_zx_type_551_9800b5743cab68be8ca8ffce0d0b75ae58f417a5634b4980a16984430f547810 = struct {
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    id: u32,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    zx_origin: ?*const zx_type_551 = null,
};

pub const value_zx_type_552_a191d6b2c3c095a2c8c816a62b7d2fc4a3a5b39437d5e716d9892de633a9f5e4 = struct {
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    tree: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_552 = null,
};

pub const value_zx_type_553_514b8247d8ac45dc9a48b26ab84281962bbd77a9d5481b83c41f75eb0f777c3e = struct {
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    diagnostic: *const zx_type_31,
    done: bool,
    source: u64,
    zx_origin: ?*const zx_type_553 = null,
};

pub const value_zx_type_554_240b2c00e01e776b3c1079691ee42cd9980fd961205aa91b0e8f7de32e3d733e = struct {
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: ?u32,
    zx_origin: ?*const zx_type_554 = null,
};

pub const value_zx_type_555_fd3b5d45be0fc3f8b73a3c4a1b0e0f371fad01ddcd0e0415af64852f42132bdb = struct {
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_555 = null,
};

pub const value_zx_type_556_db7461e6c9ac76a17e1af70e28afb7e67731821e224fb27f84dc1b64c3f5ee62 = struct {
    expected: ?u32,
    node: u64,
    work: value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519,
    zx_origin: ?*const zx_type_556 = null,
};

pub const value_zx_type_557_3fdd7a2931413f5b5193687f4c45686d3f9667405120667d4cc6ee36fc45931b = struct {
    action: zx_type_334,
    body: value_zx_type_340_25fcf08c59c51140437c0c0f32db29701c62088cf889cabda7295d6d4cf49981,
    expected: ?u32,
    node: u64,
    zx_origin: ?*const zx_type_557 = null,
};

pub const value_zx_type_558_54285689fa8e1f0c30bd23f9f6c47e05cd4039c0384d50c4ef8585a61d712dfa = struct {
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    name: *const zx_type_60,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_558 = null,
};

pub const value_zx_type_559_c04376752232fcd8b74d8d6ad6804e1bf90c651f7d495d2325e5542cac189526 = struct {
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    statement: u64,
    value: u32,
    zx_origin: ?*const zx_type_559 = null,
};

pub const value_zx_type_560_54285689fa8e1f0c30bd23f9f6c47e05cd4039c0384d50c4ef8585a61d712dfa = struct {
    blocks: value_zx_type_331_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_560 = null,
};

pub const value_zx_type_561_819940577c93a6601d02925a2d50d268b2824a426d88a6a49c4de3243b77023f = struct {
    action: zx_type_334,
    body: value_zx_type_340_25fcf08c59c51140437c0c0f32db29701c62088cf889cabda7295d6d4cf49981,
    zx_origin: ?*const zx_type_561 = null,
};

pub const value_zx_type_562_967dc08a2232df16d52e79ffb517071ea09c3579997dd17360d83c0e40781c62 = struct {
    body: value_zx_type_340_25fcf08c59c51140437c0c0f32db29701c62088cf889cabda7295d6d4cf49981,
    span: *const zx_type_25,
    zx_origin: ?*const zx_type_562 = null,
};

pub const value_zx_type_563_8b5789c4c2e37df89d770df0dc0023ac727b5fdccb37e9c3e3dfae2ea7f694b6 = struct {
    root: ?u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_563 = null,
};

pub const value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06 = struct {
    diagnostic: *const zx_type_31,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_564 = null,
};

pub const value_zx_type_565_2e61a7d9f47f8c697d801934be9cb7fec9e6a21a252e16894cc6812cd5ac8624 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    state: value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06,
    zx_origin: ?*const zx_type_565 = null,
};

pub const value_zx_type_566_cf4ab152ee80a8016752d39fd09af8928e2d7716ad96a00f10be66b0795e522c = struct {
    names: []const []const u8,
    state: value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06,
    types: []const u32,
    zx_origin: ?*const zx_type_566 = null,
};

pub const value_zx_type_567_7a135972523f4dd229b7135bf69702c9e43f2d141a9f6165f7389161c6ac3103 = struct {
    aliases: *const zx_type_78,
    contracts: *const zx_type_224,
    items: []const *const zx_type_140,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_567 = null,
};

pub const value_zx_type_568_4fee5884459e049a8923b407d2def0a2d096d39589fa0cafde3272173b799f75 = struct {
    items: []const *const zx_type_140,
    names: []const []const u8,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    types: []const u32,
    zx_origin: ?*const zx_type_568 = null,
};

pub const value_zx_type_569_0688cdc93fcb174a194199b1cd5068ba766b98ddfa06b9fc939ad58ef6f2932c = struct {
    aliases: *const zx_type_78,
    contract: *const zx_type_140,
    input_type: u32,
    output_type: u32,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_569 = null,
};

pub const value_zx_type_570_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3 = struct {
    diagnostic: *const zx_type_31,
    expressions: *const zx_type_216,
    predicate: u32,
    symbols: *const zx_type_219,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_570 = null,
};

pub const value_zx_type_571_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    expressions: *const zx_type_216,
    kind: zx_type_220,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_219,
    table: *const zx_type_224,
    zx_origin: ?*const zx_type_571 = null,
};

pub const value_zx_type_572_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    contracts: *const zx_type_224,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_572 = null,
};

pub const value_zx_type_573_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    ownership: []const zx_type_217,
    stores: []const *const zx_type_236,
    zx_origin: ?*const zx_type_573 = null,
};

pub const value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695 = struct {
    body: ?u32,
    control: *const zx_type_227,
    expressions: *const zx_type_216,
    functions: value_zx_type_573_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    symbols: *const zx_type_219,
    type_only: bool,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_574 = null,
};

pub const value_zx_type_575_25528cf02c143df190dcdbb07f8178a6266eeb9de924da1d1353e3ac8d12865e = struct {
    functions: value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    root: ?u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    type_only: bool,
    zx_origin: ?*const zx_type_575 = null,
};

pub const value_zx_type_576_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u64,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_576 = null,
};

pub const value_zx_type_577_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expression: u64,
    expressions: *const zx_type_216,
    index: u64,
    zx_origin: ?*const zx_type_577 = null,
};

pub const value_zx_type_578_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expression: u64,
    found: bool,
    zx_origin: ?*const zx_type_578 = null,
};

pub const value_zx_type_579_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expression: u64,
    expressions: *const zx_type_216,
    locals: []const bool,
    zx_origin: ?*const zx_type_579 = null,
};

pub const value_zx_type_580_e05028d9f2b1d7792bfed137694ab8e6051e740db09be899cd5c3c4ff8b94544 = struct {
    expression: u64,
    program: value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    zx_origin: ?*const zx_type_580 = null,
};

pub const value_zx_type_581_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u64,
    first: []const u64,
    symbols: []const u64,
    zx_origin: ?*const zx_type_581 = null,
};

pub const value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u64,
    field_indices: []const u64,
    parents: []const u64,
    references: []const bool,
    siblings: []const u64,
    types: []const u32,
    zx_origin: ?*const zx_type_584 = null,
};

pub const value_zx_type_586_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d = struct {
    id: u64,
    layout: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    operation: zx_type_583,
    states: []const zx_type_582,
    value: zx_type_582,
    zx_origin: ?*const zx_type_586 = null,
};

pub const value_zx_type_587_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u64,
    first: []const u64,
    positions: []const u64,
    zx_origin: ?*const zx_type_587 = null,
};

pub const value_zx_type_588_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937 = struct {
    cached: value_zx_type_587_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    heads: []const u64,
    next: []const u64,
    tree: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_588 = null,
};

pub const value_zx_type_589_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d = struct {
    cached: value_zx_type_587_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    tree: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    values: []const u64,
    zx_origin: ?*const zx_type_589 = null,
};

pub const value_zx_type_591_767b69074202a272a12100b84e23109da965767802298cfb5e4fed280635514e = struct {
    program: value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    zx_origin: ?*const zx_type_591 = null,
};

pub const value_zx_type_592_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capacity: u64,
    field: u64,
    parent: u64,
    zx_origin: ?*const zx_type_592 = null,
};

pub const value_zx_type_593_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_593 = null,
};

pub const value_zx_type_594_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    field: u64,
    parent: u64,
    zx_origin: ?*const zx_type_594 = null,
};

pub const value_zx_type_595_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_595 = null,
};

pub const value_zx_type_596_0093e0155d66cb511a94de9e5d1d5b400f76ae0078e86bc776bc6b8934ee5924 = struct {
    index: value_zx_type_593_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    key: value_zx_type_594_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_596 = null,
};

pub const value_zx_type_597_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expressions: *const zx_type_216,
    id: u64,
    zx_origin: ?*const zx_type_597 = null,
};

pub const value_zx_type_598_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u32,
    target: u64,
    zx_origin: ?*const zx_type_598 = null,
};

pub const value_zx_type_600_66dcc527b00a87c3c2a5109b4a3924ac4c4d43c09f84caa10ed23e5ea63930cf = struct {
    active: bool,
    ancestor: u64,
    bindings: []const u64,
    cached: value_zx_type_587_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    capacity: u64,
    child_expression: u64,
    children: []const u64,
    cursor: u64,
    direct: bool,
    expression: u64,
    field_indices: []const u64,
    heads: []const u64,
    key_fields: []const u64,
    key_parents: []const u64,
    next: []const u64,
    parent: u64,
    parents: []const u64,
    path: []const u64,
    path_index: u64,
    phase: zx_type_599,
    place_types: []const u32,
    program: value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    record: u64,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_600 = null,
};

pub const value_zx_type_601_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    first: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_601 = null,
};

pub const value_zx_type_602_08ae4a5c88157bebdfb632c2939fd9a2fdb6e48e4cc60655b08697fb2d0015fb = struct {
    program: value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    roots: value_zx_type_588_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937,
    zx_origin: ?*const zx_type_602 = null,
};

pub const value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u64,
    count: []const u64,
    first: []const u64,
    shells: []const zx_type_582,
    states: []const zx_type_582,
    types: []const u32,
    zx_origin: ?*const zx_type_603 = null,
};

pub const value_zx_type_604_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    fact: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_604 = null,
};

pub const value_zx_type_605_461a038225996c015433bf0a5fb2c9e6a36f43e598f85eccd7a2eee1e984e893 = struct {
    fact: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    reference: bool,
    zx_origin: ?*const zx_type_605 = null,
};

pub const value_zx_type_606_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    index: u64,
    type_id: u32,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_606 = null,
};

pub const value_zx_type_607_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    left: zx_type_582,
    right: zx_type_582,
    zx_origin: ?*const zx_type_607 = null,
};

pub const value_zx_type_608_df87d4e4c94482fd017e977a114eba826861ac6af356c343aea16855cac7c373 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    shell: zx_type_582,
    type_id: u32,
    zx_origin: ?*const zx_type_608 = null,
};

pub const value_zx_type_609_b1b23fbb7680b8cb1b3dadbfa986aa274ef1483cb6efee44a47ca580481a8e23 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    shell: zx_type_582,
    type_id: u32,
    zx_origin: ?*const zx_type_609 = null,
};

pub const value_zx_type_610_48e6facbc67e19905cc5d1979cc7988969acfd6e4bae54b78cb7684de3ebbbab = struct {
    fact: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    type_id: u32,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_610 = null,
};

pub const value_zx_type_611_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0 = struct {
    facts: []const u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    states: []const zx_type_582,
    zx_origin: ?*const zx_type_611 = null,
};

pub const value_zx_type_612_c7b60c00d717dc61a2a9736408d32321057c2522adc791850c9eae52b70181a8 = struct {
    fact: u64,
    id: u64,
    layout: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    references: []const bool,
    storage: value_zx_type_611_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_612 = null,
};

pub const value_zx_type_613_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capacity: u64,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_613 = null,
};

pub const value_zx_type_615_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    left: []const u64,
    right: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_615 = null,
};

pub const value_zx_type_616_9e473f196db28165f17fa02012d877e38b20b2fdd7fbf0bd932a3b8513569fa0 = struct {
    cache: value_zx_type_615_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_616 = null,
};

pub const value_zx_type_617_03d90fa68e4e68b677112113e76ce3e9fb7563db5d750228bd60f891663f8e20 = struct {
    cache: value_zx_type_615_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    left: u64,
    right: u64,
    value: u64,
    zx_origin: ?*const zx_type_617 = null,
};

pub const value_zx_type_618_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_618 = null,
};

pub const value_zx_type_619_0e14e5cdabbe38cb1c79f91fab9c5efb4effe8af60678a6b3d272d5ab52e2387 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    references: []const bool,
    shell: zx_type_582,
    type_id: u32,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_619 = null,
};

pub const value_zx_type_620_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    action: zx_type_614,
    left: zx_type_582,
    right: zx_type_582,
    zx_origin: ?*const zx_type_620 = null,
};

pub const value_zx_type_621_ec908cc2db7bcb55b295ba38c99a7117d8d48d2fedde568fd60bfa6cb2ebc669 = struct {
    action: zx_type_614,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    left: u64,
    references: []const bool,
    right: u64,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_621 = null,
};

pub const value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    facts: []const u64,
    memo: []const u64,
    memo_count: []const u64,
    memo_first: []const u64,
    state_count: []const u64,
    state_first: []const u64,
    zx_origin: ?*const zx_type_624 = null,
};

pub const value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d = struct {
    facts: []const u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memo: []const u64,
    states: []const zx_type_582,
    trail: []const u64,
    zx_origin: ?*const zx_type_625 = null,
};

pub const value_zx_type_626_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf = struct {
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    snapshots: value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_626 = null,
};

pub const value_zx_type_627_c2b2345f31a3ca9410ec1d01298fd1e422f335f176ffd7a4e0451d112beced1a = struct {
    fact: u64,
    id: u64,
    layout: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    operation: zx_type_583,
    references: []const bool,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_627 = null,
};

pub const value_zx_type_628_a0405b3f3da574378c4599f54a1cf52b9531f3ff33aefbd053cbddcca68d591c = struct {
    layout: value_zx_type_589_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    program: value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    zx_origin: ?*const zx_type_628 = null,
};

pub const value_zx_type_630_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    action: zx_type_629,
    index: u64,
    moving: bool,
    subject: u64,
    zx_origin: ?*const zx_type_630 = null,
};

pub const value_zx_type_632_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    actions: []const zx_type_629,
    indices: []const u64,
    moving: []const bool,
    subjects: []const u64,
    zx_origin: ?*const zx_type_632 = null,
};

pub const value_zx_type_633_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    complete: bool,
    expression: u64,
    failed: bool,
    output: zx_type_582,
    stores_owned: bool,
    zx_origin: ?*const zx_type_633 = null,
};

pub const value_zx_type_634_9ca4da4ade6ce39392bcd565b92026186825f5515fba0d69864aa5bdd2c0c8c0 = struct {
    action: zx_type_623,
    frame: u64,
    layout: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    stack: value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_634 = null,
};

pub const value_zx_type_635_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    frame: u64,
    stack: value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_635 = null,
};

pub const value_zx_type_636_38e16b7ca832d5cab2cdd1573bdea3003d7c88255f2146bd1c658c5474aa0153 = struct {
    capture: zx_type_622,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    stack: value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_636 = null,
};

pub const value_zx_type_637_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53 = struct {
    frame: value_zx_type_630_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    work: value_zx_type_632_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_637 = null,
};

pub const value_zx_type_638_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: []const u64,
    first: []const u64,
    zx_origin: ?*const zx_type_638 = null,
};

pub const value_zx_type_639_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d = struct {
    boundaries: []const u64,
    count: []const u64,
    entries: []const u64,
    exits: []const u64,
    facts: []const u64,
    first: []const u64,
    heads: []const u64,
    outputs: []const u64,
    roots: []const u64,
    seen: []const bool,
    zx_origin: ?*const zx_type_639 = null,
};

pub const value_zx_type_641_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3 = struct {
    active: bool,
    builders: value_zx_type_638_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    complete: bool,
    domains: value_zx_type_581_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    expression: u64,
    failed: bool,
    layout: value_zx_type_589_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    loops: value_zx_type_639_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    program: value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    returned: zx_type_582,
    returns: []const bool,
    snapshots: value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    stores_owned: bool,
    value: u64,
    values: []const u64,
    work: value_zx_type_632_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_641 = null,
};

pub const value_zx_type_642_a338d1ab71f88877331d772f98bd14da65b1786b2be70c874f8b7e12b86f2f1f = struct {
    frame: u64,
    layout: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    merge: bool,
    references: []const bool,
    stack: value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_642 = null,
};

pub const value_zx_type_643_c24243ffcb91606794657c93d9112ec4c334bd9de6c46889f83dc67ca369b0a0 = struct {
    index: u64,
    loops: value_zx_type_639_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_643 = null,
};

pub const value_zx_type_644_e0ee3b7694a94ee6184c97b78a601ea953f2ec41d003a59e2d2c20bd608416ca = struct {
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_639_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_644 = null,
};

pub const value_zx_type_645_3d04dd43b3d06a3225ea47bfd43abc7af1e40baf278abd1b107975826d4f1dbb = struct {
    condition: bool,
    expression: u64,
    index: u64,
    machine: value_zx_type_641_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3,
    value: u64,
    zx_origin: ?*const zx_type_645 = null,
};

pub const value_zx_type_646_240efbbbf7810640b6fc01ce36bdc99bfbeb5720a9917ff0491c9572a913a019 = struct {
    boundary: u64,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    snapshots: value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    work: value_zx_type_632_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_646 = null,
};

pub const value_zx_type_647_4d3f012ce1af010aa08025827bda50d8f143763669bc2e4b561dcc5658f0bb6a = struct {
    changed: bool,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_639_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_647 = null,
};

pub const value_zx_type_648_9ea6e119697e5089b2d71b0128c4d91826c989da87b1481dc0d5f340ecdd8edd = struct {
    domains: value_zx_type_581_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    exiting: bool,
    expression: u64,
    index: u64,
    layout: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_639_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    snapshots: value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_648 = null,
};

pub const value_zx_type_649_889643ab829a1c5bfcc90b79c286ed0a794313db5ea714f0972ac74b5720a859 = struct {
    domains: value_zx_type_581_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    entry: u64,
    expression: u64,
    layout: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_639_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    program: value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    value: u64,
    zx_origin: ?*const zx_type_649 = null,
};

pub const value_zx_type_651_4158841c74e882000927bc9fb2cfef48d50f106f07c7898967375498c5ede5cb = struct {
    active: bool,
    cursors: []const u64,
    expression: u64,
    expressions: *const zx_type_216,
    facts: []const u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    layout: value_zx_type_589_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    permanent: bool,
    phase: zx_type_650,
    position: u64,
    query: u64,
    references: []const bool,
    root: u64,
    states: []const zx_type_582,
    trail: []const u64,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    work: []const u64,
    zx_origin: ?*const zx_type_651 = null,
};

pub const value_zx_type_652_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expression: u64,
    expressions: *const zx_type_216,
    index: u64,
    permanent: bool,
    zx_origin: ?*const zx_type_652 = null,
};

pub const value_zx_type_653_0d6d611f2caeee490761bbb5ea443b6881e3d712a7de202a9d02b0df984686e1 = struct {
    expression: u64,
    expressions: *const zx_type_216,
    layout: value_zx_type_589_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    permanent: bool,
    references: []const bool,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_653 = null,
};

pub const value_zx_type_654_ba054a92466517afadfa71eb48b1a69236032a9b3b84f6ef89ed7b3a38acc13a = struct {
    expression: u64,
    expressions: *const zx_type_216,
    layout: value_zx_type_589_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_654 = null,
};

pub const value_zx_type_655_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    position: u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_655 = null,
};

pub const value_zx_type_656_7498e4f806a7d6cb548387280423a75175fc5b80ec06eb4213ab0655a938538d = struct {
    current: zx_type_582,
    moving: bool,
    position: u64,
    symbols: *const zx_type_219,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_656 = null,
};

pub const value_zx_type_657_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    assign: bool,
    assigned: zx_type_582,
    failed: bool,
    value: zx_type_582,
    zx_origin: ?*const zx_type_657 = null,
};

pub const value_zx_type_658_548d03a1c937aa175a4ae6dc65848134fd43039f0f2deb8397102cde1a357280 = struct {
    builders: value_zx_type_638_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    count: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_658 = null,
};

pub const value_zx_type_659_9b2f070bd0a5a2314312b35bc5cd00be816db0248310d896c611be777eb24dfc = struct {
    builders: value_zx_type_638_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_659 = null,
};

pub const value_zx_type_661_3d9243068d042715091b3bc26eced84b2276542fa4ce6ed7c77bd25c76818046 = struct {
    container: bool,
    frame: value_zx_type_630_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    kind: zx_type_203,
    machine: value_zx_type_641_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3,
    payload: u64,
    zx_origin: ?*const zx_type_661 = null,
};

pub const value_zx_type_662_190073c195a96e0748b52805b1cbcc6366d97081df0f6eda8af2362d81577f30 = struct {
    builders: value_zx_type_638_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    type_id: u32,
    zx_origin: ?*const zx_type_662 = null,
};

pub const value_zx_type_663_548d03a1c937aa175a4ae6dc65848134fd43039f0f2deb8397102cde1a357280 = struct {
    builders: value_zx_type_638_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    fact: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_663 = null,
};

pub const value_zx_type_664_9c68fc8229a3cb9544086ee9d74623a5845e02f8d7b0c7e22830b51be4e668ef = struct {
    domains: value_zx_type_581_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    layout: value_zx_type_589_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    program: value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    returns: []const bool,
    runtime: value_zx_type_626_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf,
    zx_origin: ?*const zx_type_664 = null,
};

pub const value_zx_type_665_1ea31d9a4373a8a2d6567244ece57ae6415a5b0cf74a64103f4b2767cf8e0a88 = struct {
    outcome: value_zx_type_633_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_665 = null,
};

pub const value_zx_type_666_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    ownership: zx_type_217,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_666 = null,
};

pub const value_zx_type_667_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80 = struct {
    control: *const zx_type_227,
    expressions: *const zx_type_216,
    root: ?u32,
    stores: *const zx_type_236,
    symbols: *const zx_type_219,
    zx_origin: ?*const zx_type_667 = null,
};

pub const value_zx_type_668_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_216,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_219,
    zx_origin: ?*const zx_type_668 = null,
};

pub const value_zx_type_669_7b2f1e8e138e90625e80ca60c3f20204ae02fbf6e71d133be9439692824ff408 = struct {
    body: value_zx_type_667_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80,
    contracts: *const zx_type_224,
    diagnostic: *const zx_type_31,
    export_names: []const []const u8,
    export_types: []const u32,
    input_type: u32,
    nominal_delta: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    output_ownership: zx_type_217,
    output_type: u32,
    type_delta: *const zx_type_18,
    type_only: bool,
    zx_origin: ?*const zx_type_669 = null,
};

pub const value_zx_type_670_56c79498c37c5667191d97e794b32d1e25a0a9ed76677cf81f818eabc8e5fe2f = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_670 = null,
};

pub const value_zx_type_671_5f3fab7672bc9f4282fc2bfebcc6766a78f4338d475a4aef0a532ed1976e547e = struct {
    base: *const zx_type_18,
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    id: u32,
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_671 = null,
};

pub const value_zx_type_672_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554 = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    publish: bool,
    zx_origin: ?*const zx_type_672 = null,
};

pub const value_zx_type_673_8aa5028c1fa4881a2d1ecd5dd1891a11196fbe0a82cd5a6fb884bc582c9c12b3 = struct {
    diagnostic: *const zx_type_31,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    zx_origin: ?*const zx_type_673 = null,
};

pub const value_zx_type_674_ec615383c8067a6fa0583a594da6078e5095e3267cd3f2d02b250da248f0676f = struct {
    context: value_zx_type_243_3a357295bc15378c8d9379bded45bab4c78ce157dc22ada26dc5eacb7e5e2528,
    has_store: bool,
    signature: value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3,
    zx_origin: ?*const zx_type_674 = null,
};

pub const value_zx_type_675_82c8f6e218ea5815d38054d6edc19df0035692f9932a02567c9fd273ebc0a015 = struct {
    allow_store: bool,
    has_body: bool,
    signature: value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3,
    stores: *const zx_type_236,
    zx_origin: ?*const zx_type_675 = null,
};

pub const value_zx_type_676_dc19aca6288fa6210d4f477624d77a156a3220aaa2b953dece7140541e04cca6 = struct {
    block: u64,
    functions: value_zx_type_240_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_676 = null,
};

pub const value_zx_type_677_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    contract: *const zx_type_140,
    output_type: u32,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_677 = null,
};

pub const value_zx_type_678_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a = struct {
    domains: value_zx_type_581_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    layout: value_zx_type_589_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    references: []const bool,
    returns: []const bool,
    zx_origin: ?*const zx_type_678 = null,
};

pub const value_zx_type_679_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134 = struct {
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    prepared: value_zx_type_678_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a,
    snapshots: value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_679 = null,
};

pub const value_zx_type_680_a8bc082d1822f14eea9dd469eba364f8aaab6572f900a6cddfe41b6ceb6cb5ad = struct {
    analysis: value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21,
    module: value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4,
    zx_origin: ?*const zx_type_680 = null,
};

pub const value_zx_type_681_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_681 = null,
};

pub const value_zx_type_682_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, []const u8, ?*const zx_type_682, };

pub const value_zx_type_683_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    selected: u64,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_683 = null,
};

pub const value_zx_type_684_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, []const []const u8, ?*const zx_type_684, };

pub const value_zx_type_685_c112291784b95a088b8165381f6507d0f20b29ff9da2fb78d0ffff47dfc8012c = struct {
    count: u64,
    index: u64,
    state: value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_685 = null,
};

pub const value_zx_type_686_069a7ea61cfb445517edf055c511f09555d98c65d5dabbbf56f319da889b646f = struct { value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_686, };

pub const value_zx_type_687_997a00fdf8ac3d8f5d11296afb04111770aaaddeb73f1727104ad7827dfb64b9 = struct { value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_687, };

pub const value_zx_type_688_07d29144135453d3b73bd99c103d4e9e7f95f2b78fa387faa9e763801bc07ebe = struct { value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_688, };

pub const value_zx_type_689_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, void, ?*const zx_type_689, };

pub const value_zx_type_690_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, void, ?*const zx_type_690, };

pub const value_zx_type_691_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const []const u8, ?[]const u8, ?*const zx_type_691, };

pub const value_zx_type_693_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_80, ?*const zx_type_80, ?*const zx_type_693, };

pub const value_zx_type_694_713639bf2340277cb2fc17b55239d7eafff49067cfedc85ab5bd099cd1d4078d = struct {
    equal: bool,
    index: u64,
    left: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    right: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_694 = null,
};

pub const value_zx_type_695_0e70c693f6adee041b71153b65d39c537ba5de74cae3bc9eba48950bd94db775 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    count: u64,
    found: bool,
    id: u32,
    index: u64,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_695 = null,
};

pub const value_zx_type_696_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, void, ?*const zx_type_696, };

pub const value_zx_type_697_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    limit: u64,
    right: []const u8,
    zx_origin: ?*const zx_type_697 = null,
};

pub const value_zx_type_698_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    building: bool,
    count: u64,
    names: []const []const u8,
    remaining: u64,
    root: u64,
    sifting: bool,
    types: []const u32,
    zx_origin: ?*const zx_type_698 = null,
};

pub const value_zx_type_699_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
    zx_origin: ?*const zx_type_699 = null,
};

pub const value_zx_type_700_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    target: zx_type_17,
    zx_origin: ?*const zx_type_700 = null,
};

pub const value_zx_type_701_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_701 = null,
};

pub const value_zx_type_702_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, void, ?*const zx_type_702, };

pub const value_zx_type_703_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    children: []const u32,
    found: bool,
    index: u64,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_703 = null,
};

pub const value_zx_type_704_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = struct {
    count: u64,
    diagnostic: *const zx_type_31,
    enumeration: u64,
    index: u64,
    names: []const []const u8,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_704 = null,
};

pub const value_zx_type_705_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    cache: *const zx_type_78,
    found: bool,
    id: u32,
    index: u64,
    name: []const u8,
    zx_origin: ?*const zx_type_705 = null,
};

pub const value_zx_type_706_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_80, void, ?*const zx_type_706, };

pub const value_zx_type_707_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, []const u32, ?*const zx_type_707, };

pub const value_zx_type_708_90fe70fa5d2d4c69af4dc354ff484cde4f742eadfc88af37b0709510fab97410 = struct { value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, ?*const zx_type_708, };

pub const value_zx_type_709_1b7a94226e1adb4685c1fa613f3f77c323dc421ecdbae8cfe9089c85d51102d0 = struct { value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_709, };

pub const value_zx_type_710_bfc1740ffee8c8ed5a138d86c027163d38443f5478ce225817f6bca9761197af = struct { value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_710, };

pub const value_zx_type_711_f9b0821e8e8c23d3efb7e66c63da1fdac46b8458b9acbca9413e99ea98017969 = struct { value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_711, };

pub const value_zx_type_712_a3fe0196c6a98cfbd9a56f1317fcde22066a51e3316d0e7cfcb4f577c5514d51 = struct {
    count: u64,
    delta: *const zx_type_18,
    index: u64,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    source: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_712 = null,
};

pub const value_zx_type_713_2946eb56f574decc3beba0a63587d6aae87c317cb8009b9a0f5cb9d43419d82b = struct {
    equal: bool,
    index: u64,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    source: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    target: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_713 = null,
};

pub const value_zx_type_714_088f15199dcba55be3978f31a93503ede4d44a0b4a0de0a77763261b7a067457 = struct {
    count: u64,
    id: u32,
    index: u64,
    input: value_zx_type_196_2f01dc5af85efb2d97af6c7b092cb0b1f9d76fe55ba3ba47bf7d26986d7815c8,
    nominal: bool,
    status: zx_type_188,
    zx_origin: ?*const zx_type_714 = null,
};

pub const value_zx_type_715_79b27826adb70cc6a7983ee71225ce16c523afb5eb5c7a9b9c97368b767ca3ed = struct {
    conflict: bool,
    delta: *const zx_type_18,
    index: u64,
    input: value_zx_type_190_edb46a81e3a9250d692663665486205b0963b7c46abe2f9b6643551737beb15e,
    mapping: []const u32,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_715 = null,
};

pub const value_zx_type_716_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    cache: *const zx_type_78,
    ids: []const u32,
    index: u64,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_716 = null,
};

pub const value_zx_type_717_6f2481ba9940bd2da192eaf8958b6391d367d01df05d805f5ef26cfbf718de7e = struct { value_zx_type_671_5f3fab7672bc9f4282fc2bfebcc6766a78f4338d475a4aef0a532ed1976e547e, ?*const zx_type_717, };

pub const value_zx_type_718_487e144abcf7b3c4f2ca7aab6bdc89e64a59232c2c0352991a87f722ddb6bd06 = struct { value_zx_type_671_5f3fab7672bc9f4282fc2bfebcc6766a78f4338d475a4aef0a532ed1976e547e, value_zx_type_191_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922, ?*const zx_type_718, };

pub const value_zx_type_719_a131eceb6b89ca74a723085e2d8102410a529ed5cc6f0f423950df93552e6949 = struct { value_zx_type_671_5f3fab7672bc9f4282fc2bfebcc6766a78f4338d475a4aef0a532ed1976e547e, value_zx_type_191_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922, *const zx_type_78, ?*const zx_type_719, };

pub const value_zx_type_720_41b7d28f331f01f75420a6252ecc7a2111231505c4af92f595c8de342905a75d = struct { value_zx_type_671_5f3fab7672bc9f4282fc2bfebcc6766a78f4338d475a4aef0a532ed1976e547e, value_zx_type_191_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922, *const zx_type_78, u32, ?*const zx_type_720, };

pub const value_zx_type_721_41ec322f90878c59bb89c3f34a72452bd6c2155a538712e3bfed837562ed34b4 = struct { value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, ?*const zx_type_721, };

pub const value_zx_type_722_b2d09c3ab85e0936afb4a7cf680a994e7cdfb41628b56ddc477c90e6c2137e23 = struct { value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, value_zx_type_84_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, ?*const zx_type_722, };

pub const value_zx_type_723_ed7965c10a3305ddeb26dc57e8c378252f301142168e1f9860f1391f5dc9de9b = struct { value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, value_zx_type_84_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_670_56c79498c37c5667191d97e794b32d1e25a0a9ed76677cf81f818eabc8e5fe2f, ?*const zx_type_723, };

pub const value_zx_type_724_ebda8f5d9040583b3510f8e9c7e91fe8b479137d958985c590a16f9d2d5161dc = struct { value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1, ?*const zx_type_724, };

pub const value_zx_type_725_2b61d0f8be4897c10787470ae0c8863817ff7a29b91be11e54e2ca7e137dc259 = struct { value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, ?*const zx_type_725, };

pub const value_zx_type_726_91c704f6e0ae6c09e7e8724276aee9f189aa910f74fc37b07e00a86a93a89115 = struct { value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, value_zx_type_672_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, ?*const zx_type_726, };

pub const value_zx_type_727_e7430df5f09133acc89066a4936bae8fb9366dbcd73ff7d6fa8294b824765d42 = struct { value_zx_type_200_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, ?*const zx_type_727, };

pub const value_zx_type_728_fffe9972c909e11f7d04cc7ffc011451e4727a7b4e9d7e4877dab78f44512de8 = struct { value_zx_type_200_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, ?*const zx_type_728, };

pub const value_zx_type_729_26c7a84ddb13da1c89ef21645814fcba257b9c230975d97fe8accde190679fe7 = struct { value_zx_type_200_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, ?*const zx_type_729, };

pub const value_zx_type_730_02e0c5bafba240f4f38be82a88fbf6d59969a87344ce828a0d958ef7d4dd8e88 = struct { value_zx_type_200_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, value_zx_type_672_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, ?*const zx_type_730, };

pub const value_zx_type_731_9c7fcbe03413e0e23adcd3198506aaea02fc55e171b19e6a169c97b531cee443 = struct { value_zx_type_200_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_672_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, ?*const zx_type_731, };

pub const value_zx_type_732_4d8c4b73175ba3eaa16d96cac2868ce36bcd4fb0e2e703e2f2fe680bdbaa8c09 = struct { value_zx_type_200_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_672_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, ?*const zx_type_732, };

pub const value_zx_type_733_5b65ceaa8b163558bb127e5e3e2f256e5d651d3418e90b2e6ae8f5b399099bc1 = struct { value_zx_type_200_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_672_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, value_zx_type_672_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, ?*const zx_type_733, };

pub const value_zx_type_734_36df866b92e594bff4ff7a1d977d57e2bf8050d286d69a1ee191611e870c32ee = struct { value_zx_type_200_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_672_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, value_zx_type_672_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, ?*const zx_type_734, };

pub const value_zx_type_735_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    found: bool,
    handles: []const []const u8,
    index: u64,
    paths: []const []const u8,
    target: u64,
    zx_origin: ?*const zx_type_735 = null,
};

pub const value_zx_type_736_c2f006d5991659e96b5897d554849bc18b3f9d182e861b3e08c8ba6ea5975a2b = struct {
    diagnostic: *const zx_type_31,
    index: u64,
    input: value_zx_type_247_d17529268506104b33086a1bf700d239b7345719d8dc3014bc934df596f972c4,
    stores: *const zx_type_236,
    zx_origin: ?*const zx_type_736 = null,
};

pub const value_zx_type_737_4f7808036f3d487a92cb0f678fba8a20496899cbb27eba7c8b9f93d914406b77 = struct { value_zx_type_674_ec615383c8067a6fa0583a594da6078e5095e3267cd3f2d02b250da248f0676f, ?*const zx_type_737, };

pub const value_zx_type_738_3b97121fd94c3622a140cd609487de85cdfe466414619c676aea152eb3b9885e = struct { value_zx_type_674_ec615383c8067a6fa0583a594da6078e5095e3267cd3f2d02b250da248f0676f, value_zx_type_248_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, ?*const zx_type_738, };

pub const value_zx_type_739_bc5dbd2f73f5117b63dca6d23ee2d0e5b96dd1f66328f7f7216ff498c7268d16 = struct { value_zx_type_674_ec615383c8067a6fa0583a594da6078e5095e3267cd3f2d02b250da248f0676f, value_zx_type_248_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_250_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_739, };

pub const value_zx_type_740_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_740, };

pub const value_zx_type_741_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_217, void, ?*const zx_type_741, };

pub const value_zx_type_742_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    active: []const u32,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_742 = null,
};

pub const value_zx_type_743_dc9cb3caefc74e7babdc911119e66f893bac1b66813892285d54f6091ebdc5b8 = struct { value_zx_type_675_82c8f6e218ea5815d38054d6edc19df0035692f9932a02567c9fd273ebc0a015, ?*const zx_type_743, };

pub const value_zx_type_744_4f6c2029dc7a1f57bdc62d851325eaccb9378ec6f21b56e63c9f0cf1ecd336b4 = struct { value_zx_type_675_82c8f6e218ea5815d38054d6edc19df0035692f9932a02567c9fd273ebc0a015, value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69, ?*const zx_type_744, };

pub const value_zx_type_745_4c9adabd8520fa1d36a07c5b04a72bc732767e6b5da18fe5714525a18a55edad = struct { value_zx_type_675_82c8f6e218ea5815d38054d6edc19df0035692f9932a02567c9fd273ebc0a015, value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69, value_zx_type_262_6c42e587ea37fcf9cebd3363bae951bc8d27c8514466872e4d2dccf9f350e428, ?*const zx_type_745, };

pub const value_zx_type_746_9d0006b83d37d433992c1cc39eddd32522f73259d0edec12edd637eb199a7cd4 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, ?*const zx_type_746, };

pub const value_zx_type_747_7589f1d47a648a8b2c34814aaf8b2a6773017d2ad156abe8cb48142c96415b07 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, ?*const zx_type_747, };

pub const value_zx_type_748_13dbeb5f721c524a6060eafed961aeb676d2241135230c66dea4c9487d626c97 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, ?*const zx_type_748, };

pub const value_zx_type_749_feead93210a74435e99f8cb7003af79aa6de3c194959e787fb9e53bfd669d6f2 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_250_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_749, };

pub const value_zx_type_750_2cfe52fbed31cc8841c0ec5ffee07b91e230546df1e269594ec794c003feb1c3 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_250_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_673_8aa5028c1fa4881a2d1ecd5dd1891a11196fbe0a82cd5a6fb884bc582c9c12b3, ?*const zx_type_750, };

pub const value_zx_type_751_f94ec295fd9a7a065fc9d66a6551dbea1011552a7d7d2471ba4585cd0678f2e4 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_250_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, ?*const zx_type_751, };

pub const value_zx_type_752_df824ca0fef1fd7c18c5249648716a7a2ae515e05fef95ab9ac7ae98d5e761d4 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, value_zx_type_199_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, ?*const zx_type_752, };

pub const value_zx_type_753_b52edf2e5ed37221d84f1717149bc750d92931e04775a6dd6faeb7cf0be0a9fb = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, ?*const zx_type_753, };

pub const value_zx_type_754_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_216,
    index: u64,
    limit: u64,
    valid: bool,
    zx_origin: ?*const zx_type_754 = null,
};

pub const value_zx_type_755_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const bool,
    source: []const ?u32,
    zx_origin: ?*const zx_type_755 = null,
};

pub const value_zx_type_756_3a2d3372119d766901b9e73d1d1a1cb69e32e364aec8da316dab97f3e55fcf11 = struct {
    concurrent: bool,
    functions: value_zx_type_268_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    index: u64,
    values: []const bool,
    zx_origin: ?*const zx_type_756 = null,
};

pub const value_zx_type_757_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    head: u64,
    items: []const *const zx_type_43,
    remaining: u64,
    statements: []const u64,
    zx_origin: ?*const zx_type_757 = null,
};

pub const value_zx_type_758_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_329, void, ?*const zx_type_758, };

pub const value_zx_type_759_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_203, void, ?*const zx_type_759, };

pub const value_zx_type_760_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = struct {
    actual: u32,
    expected: u32,
    failed: bool,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    wrappers: []const u32,
    zx_origin: ?*const zx_type_760 = null,
};

pub const value_zx_type_761_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    span: *const zx_type_25,
    table: *const zx_type_216,
    value: u32,
    wrappers: []const u32,
    zx_origin: ?*const zx_type_761 = null,
};

pub const value_zx_type_762_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    all: bool,
    bodies: []const u32,
    end: u64,
    index: u64,
    returns: []const bool,
    zx_origin: ?*const zx_type_762 = null,
};

pub const value_zx_type_763_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    block: u64,
    control: *const zx_type_227,
    returns: []const bool,
    zx_origin: ?*const zx_type_763 = null,
};

pub const value_zx_type_764_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_356, void, ?*const zx_type_764, };

pub const value_zx_type_765_5821a6631fd0a2b5d5f68275f533e0b86f2430edbf1471339d13b94e742690d5 = struct {
    contracts: *const zx_type_224,
    index: u64,
    state: value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_765 = null,
};

pub const value_zx_type_766_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_355, void, ?*const zx_type_766, };

pub const value_zx_type_767_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    control: *const zx_type_227,
    first: u64,
    frames: []const *const zx_type_355,
    index: u64,
    source: u64,
    zx_origin: ?*const zx_type_767 = null,
};

pub const value_zx_type_768_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    capacity: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_768 = null,
};

pub const value_zx_type_769_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    previous: []const u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_769 = null,
};

pub const value_zx_type_770_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    position: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_770 = null,
};

pub const value_zx_type_771_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, []const u64, ?*const zx_type_771, };

pub const value_zx_type_772_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    key: u64,
    position: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_772 = null,
};

pub const value_zx_type_773_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    end: u64,
    index: u64,
    table: *const zx_type_216,
    values: []const u32,
    zx_origin: ?*const zx_type_773 = null,
};

pub const value_zx_type_774_7498e4f806a7d6cb548387280423a75175fc5b80ec06eb4213ab0655a938538d = struct {
    end: u64,
    expressions: *const zx_type_216,
    index: u64,
    names: []const []const u8,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_774 = null,
};

pub const value_zx_type_775_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_356, []const *const zx_type_356, ?*const zx_type_775, };

pub const value_zx_type_776_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    frames: []const *const zx_type_355,
    index: u64,
    source: u64,
    values: []const u32,
    zx_origin: ?*const zx_type_776 = null,
};

pub const value_zx_type_778_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_355, ?*const zx_type_355, ?*const zx_type_778, };

pub const value_zx_type_779_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    names: []const []const u8,
    values: []const []const u8,
    zx_origin: ?*const zx_type_779 = null,
};

pub const value_zx_type_780_b06e51454feef7fdf7d9b33c62cb112de772e5d9de51777f095ab91e73b9d4a4 = struct { value_zx_type_361_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, ?*const zx_type_780, };

pub const value_zx_type_781_559c4a2367a0e05791ca87aafe7d7cdb8a8bef28a8e16e6f7fcc6220ff365f00 = struct { value_zx_type_361_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?*const zx_type_781, };

pub const value_zx_type_782_7e470e8ae35bc1ae71064e0d2c7f58ebb3ee66a2637521f4043452e64e35c605 = struct { value_zx_type_361_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?*const zx_type_782, };

pub const value_zx_type_783_6327aad74f053b917836b19aec6a569c09585fbbc9966097f141db1ae3eef3e6 = struct { value_zx_type_361_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, value_zx_type_360_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?[]const []const u8, ?*const zx_type_783, };

pub const value_zx_type_784_6bd979ddc38e9089ff343580aac7bbd290f506083ba1a522db596260b01dd22c = struct {
    captures: []const u32,
    concurrent: []const bool,
    index: u64,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbols: u64,
    zx_origin: ?*const zx_type_784 = null,
};

pub const value_zx_type_785_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    found: bool,
    index: u64,
    symbol: u32,
    values: []const u32,
    zx_origin: ?*const zx_type_785 = null,
};

pub const value_zx_type_787_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_303, ?*const zx_type_303, ?*const zx_type_787, };

pub const value_zx_type_788_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_207, void, ?*const zx_type_788, };

pub const value_zx_type_789_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    comparable: bool,
    done: bool,
    id: u32,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_789 = null,
};

pub const value_zx_type_790_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    facts: value_zx_type_251_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    symbol: u32,
    zx_origin: ?*const zx_type_790 = null,
};

pub const value_zx_type_791_4373da08621bcbc23abd1852eb2d5ba558f05027208e827b7568eb84bcb01181 = struct {
    expressions: *const zx_type_216,
    state: value_zx_type_253_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    zx_origin: ?*const zx_type_791 = null,
};

pub const value_zx_type_792_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u64, ?u64, ?*const zx_type_792, };

pub const value_zx_type_794_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const bool, ?bool, ?*const zx_type_794, };

pub const value_zx_type_795_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_290, void, ?*const zx_type_795, };

pub const value_zx_type_796_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_293, []const *const zx_type_293, ?*const zx_type_796, };

pub const value_zx_type_798_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_293, ?*const zx_type_293, ?*const zx_type_798, };

pub const value_zx_type_799_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    head: u64,
    items: []const *const zx_type_43,
    values: []const u64,
    zx_origin: ?*const zx_type_799 = null,
};

pub const value_zx_type_800_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_204, void, ?*const zx_type_800, };

pub const value_zx_type_802_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_300, ?*const zx_type_300, ?*const zx_type_802, };

pub const value_zx_type_803_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    done: bool,
    id: u32,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_803 = null,
};

pub const value_zx_type_804_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?u32, void, ?*const zx_type_804, };

pub const value_zx_type_805_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    head: u64,
    ids: []const u64,
    tree: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_805 = null,
};

pub const value_zx_type_806_0baf43f3d33ac4f0e304448bc488db6ef2f4f56bdeadfb1e3c6d28d21146b517 = struct {
    index: u64,
    order: []const u64,
    parameters: []const u32,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    start: u64,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    types: []const u32,
    zx_origin: ?*const zx_type_806 = null,
};

pub const value_zx_type_807_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_217, []const zx_type_217, ?*const zx_type_807, };

pub const value_zx_type_808_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_274, []const *const zx_type_274, ?*const zx_type_808, };

pub const value_zx_type_810_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_299, ?*const zx_type_299, ?*const zx_type_810, };

pub const value_zx_type_811_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_274, void, ?*const zx_type_811, };

pub const value_zx_type_812_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_300, void, ?*const zx_type_812, };

pub const value_zx_type_813_bdda99bcf93d154ace4e82689f18514c6aef827e9905b839439fdb204788378d = struct {
    found: ?u32,
    index: u64,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    zx_origin: ?*const zx_type_813 = null,
};

pub const value_zx_type_814_e2199116c4df1fbf6b79ada1c538756c5bb7ce66c8becb7428e7b0269042524f = struct {
    done: bool,
    end: u64,
    matches: bool,
    node: u64,
    path: []const u8,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_814 = null,
};

pub const value_zx_type_815_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    end: u64,
    equal: bool,
    index: u64,
    path: []const u8,
    size: u64,
    source: []const u8,
    start: u64,
    zx_origin: ?*const zx_type_815 = null,
};

pub const value_zx_type_816_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    node: u64,
    tree: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_816 = null,
};

pub const value_zx_type_817_98162e3b291b362b1be268664dcae441df176033bcb3f4ad0cc295c0f8f21860 = struct {
    bindings: []const u32,
    index: u64,
    local: ?u32,
    names: []const []const u8,
    node: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    symbol: ?u32,
    unit: bool,
    units: []const []const u8,
    zx_origin: ?*const zx_type_817 = null,
};

pub const value_zx_type_818_bdf11028d7edf63a86b591ebd231881ed231979a6ab2be7bd107b8f8b578b5cf = struct {
    imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    index: u64,
    name: []const u8,
    namespace: ?[]const u8,
    result: ?u32,
    zx_origin: ?*const zx_type_818 = null,
};

pub const value_zx_type_819_4465fc637d9223ac98ffb2dcac0bb3ae1a3507c97bbbb5f308bde59bd8c0db24 = struct {
    index: u64,
    name: []const u8,
    owner: []const u8,
    stores: *const zx_type_236,
    type_id: ?u32,
    zx_origin: ?*const zx_type_819 = null,
};

pub const value_zx_type_820_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_408, void, ?*const zx_type_820, };

pub const value_zx_type_821_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    frames: []const *const zx_type_408,
    head: u64,
    tree: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_821 = null,
};

pub const value_zx_type_822_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    floating: bool,
    index: u64,
    separators: bool,
    source: []const u8,
    zx_origin: ?*const zx_type_822 = null,
};

pub const value_zx_type_823_7c66a3cb5e44aab8edd226d8256d0daabeaa161477f0b38f3d49c352a8750ddd = struct {
    floating: bool,
    index: u64,
    nodes: []const u64,
    signed: bool,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_823 = null,
};

pub const value_zx_type_824_31a5bb298f65bcca8355220f42cbed1d9c8fb3cc0856538ed6740f52bea20b41 = struct {
    fallback: u64,
    head: u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    type_id: ?u32,
    zx_origin: ?*const zx_type_824 = null,
};

pub const value_zx_type_825_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    negative: bool,
    offset: u64,
    seen: bool,
    source: []const u8,
    started: bool,
    valid: bool,
    value: u64,
    zx_origin: ?*const zx_type_825 = null,
};

pub const value_zx_type_826_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    first: u64,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_826 = null,
};

pub const value_zx_type_828_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_408, ?*const zx_type_408, ?*const zx_type_828, };

pub const value_zx_type_829_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_294, []const *const zx_type_294, ?*const zx_type_829, };

pub const value_zx_type_831_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_294, ?*const zx_type_294, ?*const zx_type_831, };

pub const value_zx_type_833_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_298, ?*const zx_type_298, ?*const zx_type_833, };

pub const value_zx_type_834_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_298, []const *const zx_type_298, ?*const zx_type_834, };

pub const value_zx_type_835_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_276, []const *const zx_type_276, ?*const zx_type_835, };

pub const value_zx_type_837_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_276, ?*const zx_type_276, ?*const zx_type_837, };

pub const value_zx_type_838_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_300, []const *const zx_type_300, ?*const zx_type_838, };

pub const value_zx_type_839_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_295, []const *const zx_type_295, ?*const zx_type_839, };

pub const value_zx_type_841_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_295, ?*const zx_type_295, ?*const zx_type_841, };

pub const value_zx_type_842_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_842 = null,
};

pub const value_zx_type_843_36e32a7d36ecb8b71dbe7e25a4158128c7836c2521d5fee40349f25f49cdbf83 = struct {
    count: u64,
    entries: *const zx_type_286,
    expressions: *const zx_type_216,
    first: u64,
    index: u64,
    names: []const []const u8,
    span: *const zx_type_25,
    types: []const u32,
    value: u32,
    zx_origin: ?*const zx_type_843 = null,
};

pub const value_zx_type_844_58ef347c61db31ca5ea618c4e523002df95e3d2676181d87628d3eee1f05edef = struct {
    count: u64,
    entries: *const zx_type_286,
    evaluation: []const u32,
    first: u64,
    index: u64,
    names: []const []const u8,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    types: []const u32,
    zx_origin: ?*const zx_type_844 = null,
};

pub const value_zx_type_845_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    output: []const u32,
    types: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_845 = null,
};

pub const value_zx_type_846_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    indices: []const u32,
    names: []const []const u8,
    zx_origin: ?*const zx_type_846 = null,
};

pub const value_zx_type_848_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_297, ?*const zx_type_297, ?*const zx_type_848, };

pub const value_zx_type_849_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_297, []const *const zx_type_297, ?*const zx_type_849, };

pub const value_zx_type_850_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    indices: []const ?u32,
    names: []const []const u8,
    zx_origin: ?*const zx_type_850 = null,
};

pub const value_zx_type_851_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    name: []const u8,
    zx_origin: ?*const zx_type_851 = null,
};

pub const value_zx_type_853_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_304, ?*const zx_type_304, ?*const zx_type_853, };

pub const value_zx_type_854_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_304, []const *const zx_type_304, ?*const zx_type_854, };

pub const value_zx_type_855_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_206, void, ?*const zx_type_855, };

pub const value_zx_type_856_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_292, []const *const zx_type_292, ?*const zx_type_856, };

pub const value_zx_type_858_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_292, ?*const zx_type_292, ?*const zx_type_858, };

pub const value_zx_type_859_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u32, ?u32, ?*const zx_type_859, };

pub const value_zx_type_860_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    head: u64,
    ids: []const u64,
    names: []const *const zx_type_127,
    zx_origin: ?*const zx_type_860 = null,
};

pub const value_zx_type_861_3cf4ab3384f85d536427bbf94775a364291e2e976d07b6ba4ce3a0bde60c9a23 = struct {
    first: u64,
    index: u64,
    order: []const u64,
    saved: u32,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    start: u64,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbols: []const ?u32,
    types: []const u32,
    zx_origin: ?*const zx_type_861 = null,
};

pub const value_zx_type_862_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_283, []const *const zx_type_283, ?*const zx_type_862, };

pub const value_zx_type_863_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_283, void, ?*const zx_type_863, };

pub const value_zx_type_864_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_281, []const *const zx_type_281, ?*const zx_type_864, };

pub const value_zx_type_866_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_281, ?*const zx_type_281, ?*const zx_type_866, };

pub const value_zx_type_867_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_216,
    found: bool,
    index: u64,
    previous: []const u32,
    value: u64,
    zx_origin: ?*const zx_type_867 = null,
};

pub const value_zx_type_869_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_282, ?*const zx_type_282, ?*const zx_type_869, };

pub const value_zx_type_870_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_282, []const *const zx_type_282, ?*const zx_type_870, };

pub const value_zx_type_871_9be0cbf8f65799eaec939714507e681c309c047ed5caa6a25e1f3fcb9bb77bbd = struct {
    diagnostic: *const zx_type_31,
    done: bool,
    expressions: *const zx_type_216,
    frames: []const *const zx_type_277,
    read_value: bool,
    symbol: u32,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    target: u32,
    zx_origin: ?*const zx_type_871 = null,
};

pub const value_zx_type_872_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_277, void, ?*const zx_type_872, };

pub const value_zx_type_873_e959e660250ea2c38eebc15197975dc40fca3c1eaea3e75064cc2976d3108df9 = struct {
    frames: []const *const zx_type_277,
    index: u64,
    places: []const *const zx_type_278,
    scopes: value_zx_type_285_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_873 = null,
};

pub const value_zx_type_874_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_278, void, ?*const zx_type_874, };

pub const value_zx_type_875_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_278, []const *const zx_type_278, ?*const zx_type_875, };

pub const value_zx_type_876_f5e52abeececd02ffdc4c45617da5eb5314fc9768ade4904d8fbfd910922c82e = struct {
    count: u64,
    expressions: *const zx_type_216,
    first: u64,
    index: u64,
    indices: []const u32,
    metadata: value_zx_type_342_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    parent: u32,
    selected: u64,
    table: *const zx_type_18,
    tuple: bool,
    value: u32,
    values: []const u32,
    zx_origin: ?*const zx_type_876 = null,
};

pub const value_zx_type_877_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    index: u64,
    places: []const *const zx_type_278,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_877 = null,
};

pub const value_zx_type_878_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_280, []const *const zx_type_280, ?*const zx_type_878, };

pub const value_zx_type_880_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_280, ?*const zx_type_280, ?*const zx_type_880, };

pub const value_zx_type_882_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_296, ?*const zx_type_296, ?*const zx_type_882, };

pub const value_zx_type_883_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_296, []const *const zx_type_296, ?*const zx_type_883, };

pub const value_zx_type_884_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    rewrite: bool,
    source: []const u8,
    template: bool,
    zx_origin: ?*const zx_type_884 = null,
};

pub const value_zx_type_885_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    bytes: []const u8,
    index: u64,
    source: []const u8,
    template: bool,
    zx_origin: ?*const zx_type_885 = null,
};

pub const value_zx_type_886_6b377024a652d6223d88a2d381b58933d303496773134218a4819ded26bc33a9 = struct {
    frame: *const zx_type_301,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_886 = null,
};

pub const value_zx_type_888_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_301, ?*const zx_type_301, ?*const zx_type_888, };

pub const value_zx_type_889_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_301, []const *const zx_type_301, ?*const zx_type_889, };

pub const value_zx_type_890_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    fields: []const u32,
    index: u64,
    types: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_890 = null,
};

pub const value_zx_type_891_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    count: u64,
    fields: *const zx_type_286,
    first: u64,
    index: u64,
    indices: []const u32,
    names: []const []const u8,
    values: []const u32,
    zx_origin: ?*const zx_type_891 = null,
};

pub const value_zx_type_892_62eb0bd048c00d4bd5a9d380474a21cd2439b8e1eb81b546c8adfcdd2e7fd525 = struct {
    bindings: value_zx_type_272_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    context: u32,
    index: u64,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    targets: []const u32,
    zx_origin: ?*const zx_type_892 = null,
};

pub const value_zx_type_893_5e11fd03bacccdbb2280a648f039ef89d25acbb81946e58c24b4fff298b40cb5 = struct {
    bindings: value_zx_type_272_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    parameters: []const u32,
    reducing: bool,
    values: []const u32,
    zx_origin: ?*const zx_type_893 = null,
};

pub const value_zx_type_894_bb3d08a9d210071122fcf4b6334aeb326db723ac4738083846e7f76296942d8a = struct { value_zx_type_485_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be, ?*const zx_type_894, };

pub const value_zx_type_895_c20f7901727429a64bd5c9a3511d6c2afaa12810bba72af2a34e0317a130a091 = struct { value_zx_type_485_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be, value_zx_type_486_a77e4162e607846786e14298a59c2e743a9752ef2fe6c98ae39887af0965c62c, ?*const zx_type_895, };

pub const value_zx_type_896_3e2f95de7047baf1a7fa6ace8e72579debf51c3a0e346b407c7139908cae79b8 = struct { value_zx_type_485_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be, value_zx_type_486_a77e4162e607846786e14298a59c2e743a9752ef2fe6c98ae39887af0965c62c, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_896, };

pub const value_zx_type_897_ef800787bf4272e120a2a808feeb5a6d3b9861c7dc2b3c28627e9017fd650685 = struct { value_zx_type_485_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be, value_zx_type_486_a77e4162e607846786e14298a59c2e743a9752ef2fe6c98ae39887af0965c62c, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_897, };

pub const value_zx_type_898_bd633bfbf84777411fdc6c682c43927d5ca69f87e6e589e58867dce54bfb004c = struct { value_zx_type_485_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be, value_zx_type_486_a77e4162e607846786e14298a59c2e743a9752ef2fe6c98ae39887af0965c62c, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_898, };

pub const value_zx_type_899_fff74499e9dffad0184af283e05aa9c7369e1426eec866594e10632235337c41 = struct { value_zx_type_273_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, ?*const zx_type_899, };

pub const value_zx_type_900_8d9346352232c8e7c3ef88d5b43378ffdbb71107b32f9096d7c0b082216517ff = struct { value_zx_type_273_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_473_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, ?*const zx_type_900, };

pub const value_zx_type_901_92dd839f9e33c2416dbb94d1e8619a26990e165c6afdfe4682d05d1961a7e6ea = struct { value_zx_type_273_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_473_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_901, };

pub const value_zx_type_902_66506a907204c4d67000ee625e975f8ff9e10b7672db030701121810df7bec97 = struct { value_zx_type_273_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_473_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_902, };

pub const value_zx_type_903_8ff59d43ad8ec447fb0ed9c0728a847046e3011573ebe272ddf4f35368b95d20 = struct { value_zx_type_273_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_473_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_483_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, ?*const zx_type_903, };

pub const value_zx_type_904_f5dd8cd85f0ebeab84f9d3e3b086ee2a6d9567bb743407e1884a2103dd7e1311 = struct { value_zx_type_273_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_473_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_483_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_904, };

pub const value_zx_type_905_4491fd18fcb5fea3e4da1fc84cb0adbe65f680ef96f50af43c2e5549dca2ef74 = struct { value_zx_type_273_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_473_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_483_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_905, };

pub const value_zx_type_906_4fc54855ed54e369b5f2add3c52ac7e9efc1a4b5843d0300e08ed38d43255c78 = struct { value_zx_type_273_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_473_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_483_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_348_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_906, };

pub const value_zx_type_907_d7317231acbaea954b8aa77221704d1f17ed961b3ebe42150f79e53d34997a08 = struct {
    bindings: value_zx_type_255_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    row: ?u32,
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_907 = null,
};

pub const value_zx_type_909_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_274, ?*const zx_type_274, ?*const zx_type_909, };

pub const value_zx_type_911_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const zx_type_290, ?zx_type_290, ?*const zx_type_911, };

pub const value_zx_type_913_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_291, ?*const zx_type_291, ?*const zx_type_913, };

pub const value_zx_type_914_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?u32, []const ?u32, ?*const zx_type_914, };

pub const value_zx_type_915_963ce4ff9ea7f93f347b5e6ba3bb449b7465b6c311531cab8541fc7b96cf273f = struct {
    bindings: value_zx_type_255_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    found: ?u32,
    row: ?u32,
    source: u32,
    zx_origin: ?*const zx_type_915 = null,
};

pub const value_zx_type_916_86a7b3113d22c4f5c71c881410c90c0e7cd5e9a4faebfbc40f2c395532e20d52 = struct {
    floor: u64,
    found: ?u32,
    index: u64,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    zx_origin: ?*const zx_type_916 = null,
};

pub const value_zx_type_917_bcd4d35e777eb2934f239c98ebc1f91b1dd4109c366ae594abc6d3c6c946efd0 = struct {
    frame: ?u32,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    path: []const u32,
    symbol: ?u32,
    zx_origin: ?*const zx_type_917 = null,
};

pub const value_zx_type_918_c10b56468fcdfc340efd837bc2bb5a1d1abf702877c05f5181a62bc3537de488 = struct {
    index: u64,
    path: []const u32,
    span: *const zx_type_25,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol: u32,
    zx_origin: ?*const zx_type_918 = null,
};

pub const value_zx_type_919_3691146d03d1eaa2c0c3b46f9fab32112bcab6edf4654c6245fcc77a52e03758 = struct {
    found: bool,
    index: u64,
    local: value_zx_type_257_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    zx_origin: ?*const zx_type_919 = null,
};

pub const value_zx_type_920_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const f64, void, ?*const zx_type_920, };

pub const value_zx_type_921_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    bytes: []const u8,
    index: u64,
    source: []const u8,
    zx_origin: ?*const zx_type_921 = null,
};

pub const value_zx_type_922_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    carry: u64,
    index: u64,
    limbs: []const u64,
    zx_origin: ?*const zx_type_922 = null,
};

pub const value_zx_type_923_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    bits: u64,
    value: u64,
    zx_origin: ?*const zx_type_923 = null,
};

pub const value_zx_type_924_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u64,
    limbs: []const u64,
    zx_origin: ?*const zx_type_924 = null,
};

pub const value_zx_type_925_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    value: u64,
    zx_origin: ?*const zx_type_925 = null,
};

pub const value_zx_type_926_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    bytes: []const u8,
    index: u64,
    invalid: bool,
    limbs: []const u64,
    zx_origin: ?*const zx_type_926 = null,
};

pub const value_zx_type_927_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    handle: []const u8,
    handles: []const []const u8,
    index: u64,
    zx_origin: ?*const zx_type_927 = null,
};

pub const value_zx_type_928_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    active: []const u32,
    floor: u64,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_928 = null,
};

pub const value_zx_type_929_6c35bd65687b543bd880afd6526cdd3358740165380c62eed517e4ec12458ab1 = struct {
    found: bool,
    imports: value_zx_type_241_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    index: u64,
    known_namespace: bool,
    name: []const u8,
    namespace: ?[]const u8,
    zx_origin: ?*const zx_type_929 = null,
};

pub const value_zx_type_930_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_298, void, ?*const zx_type_930, };

pub const value_zx_type_931_aa6c764a8238ceeee1b28212d5066b2c415c3d6a543dc2594694476b133f3b0d = struct {
    condition: ?u64,
    diagnostic: *const zx_type_31,
    fields: []const u64,
    index: u64,
    postcondition: bool,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    step: ?u64,
    zx_origin: ?*const zx_type_931 = null,
};

pub const value_zx_type_932_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_276, void, ?*const zx_type_932, };

pub const value_zx_type_933_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    fields: []const *const zx_type_109,
    head: u64,
    ids: []const u64,
    zx_origin: ?*const zx_type_933 = null,
};

pub const value_zx_type_934_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_304, void, ?*const zx_type_934, };

pub const value_zx_type_935_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_299, void, ?*const zx_type_935, };

pub const value_zx_type_936_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    arms: []const u64,
    head: u64,
    tree: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_936 = null,
};

pub const value_zx_type_937_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_295, void, ?*const zx_type_937, };

pub const value_zx_type_938_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    fields: []const u64,
    head: u64,
    tree: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_938 = null,
};

pub const value_zx_type_939_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_297, void, ?*const zx_type_939, };

pub const value_zx_type_940_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    head: u64,
    items: []const u64,
    tree: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_940 = null,
};

pub const value_zx_type_941_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_296, void, ?*const zx_type_941, };

pub const value_zx_type_942_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    head: u64,
    parts: []const u64,
    tree: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_942 = null,
};

pub const value_zx_type_943_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_301, void, ?*const zx_type_943, };

pub const value_zx_type_944_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_291, void, ?*const zx_type_944, };

pub const value_zx_type_945_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_303, void, ?*const zx_type_945, };

pub const value_zx_type_946_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_292, void, ?*const zx_type_946, };

pub const value_zx_type_947_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_293, void, ?*const zx_type_947, };

pub const value_zx_type_948_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_294, void, ?*const zx_type_948, };

pub const value_zx_type_949_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, []const bool, ?*const zx_type_949, };

pub const value_zx_type_951_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_283, ?*const zx_type_283, ?*const zx_type_951, };

pub const value_zx_type_952_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_280, void, ?*const zx_type_952, };

pub const value_zx_type_953_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_281, void, ?*const zx_type_953, };

pub const value_zx_type_954_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    cases: []const *const zx_type_128,
    head: u64,
    ids: []const u64,
    zx_origin: ?*const zx_type_954 = null,
};

pub const value_zx_type_955_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_282, void, ?*const zx_type_955, };

pub const value_zx_type_956_7c66a3cb5e44aab8edd226d8256d0daabeaa161477f0b38f3d49c352a8750ddd = struct {
    found: bool,
    index: u64,
    node: u64,
    paths: []const []const u8,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_956 = null,
};

pub const value_zx_type_957_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_225, void, ?*const zx_type_957, };

pub const value_zx_type_958_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_225, []const zx_type_225, ?*const zx_type_958, };

pub const value_zx_type_960_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_329, ?*const zx_type_329, ?*const zx_type_960, };

pub const value_zx_type_961_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_329, []const *const zx_type_329, ?*const zx_type_961, };

pub const value_zx_type_962_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_334, void, ?*const zx_type_962, };

pub const value_zx_type_963_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_336, void, ?*const zx_type_963, };

pub const value_zx_type_964_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_335, void, ?*const zx_type_964, };

pub const value_zx_type_965_ed0bad44ae50bda4e63f7b3559598912794ee592c424da9229d8fbf437db16a4 = struct {
    first: u64,
    index: u64,
    order: []const u64,
    source: value_zx_type_287_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    start: u64,
    state: value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbols: []const ?u32,
    types: []const u32,
    zx_origin: ?*const zx_type_965 = null,
};

pub const value_zx_type_966_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_335, []const *const zx_type_335, ?*const zx_type_966, };

pub const value_zx_type_968_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_335, ?*const zx_type_335, ?*const zx_type_968, };

pub const value_zx_type_969_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_336, []const *const zx_type_336, ?*const zx_type_969, };

pub const value_zx_type_971_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const zx_type_334, ?zx_type_334, ?*const zx_type_971, };

pub const value_zx_type_973_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_336, ?*const zx_type_336, ?*const zx_type_973, };

pub const value_zx_type_974_7fc27f16f6dca3271807fb4d87cf9dced3137e42d072b53a66bc5f806e814bf3 = struct { value_zx_type_676_dc19aca6288fa6210d4f477624d77a156a3220aaa2b953dece7140541e04cca6, ?*const zx_type_974, };

pub const value_zx_type_975_f54c9f6921aceaf0ab8bdc5ca24ea82d69eb2aa5ff07da23a592aa3e6f1bf9d7 = struct { value_zx_type_676_dc19aca6288fa6210d4f477624d77a156a3220aaa2b953dece7140541e04cca6, value_zx_type_340_25fcf08c59c51140437c0c0f32db29701c62088cf889cabda7295d6d4cf49981, ?*const zx_type_975, };

pub const value_zx_type_976_14eb42e9668a1bfafb25e766a6708c87b9b203662c4b4e9c0c4fb679c91e0187 = struct { value_zx_type_676_dc19aca6288fa6210d4f477624d77a156a3220aaa2b953dece7140541e04cca6, value_zx_type_340_25fcf08c59c51140437c0c0f32db29701c62088cf889cabda7295d6d4cf49981, value_zx_type_340_25fcf08c59c51140437c0c0f32db29701c62088cf889cabda7295d6d4cf49981, ?*const zx_type_976, };

pub const value_zx_type_977_f9c63c3578ac8be38db239fc6dbdc2a2bebf16e98c1f7e86fb7241aa605a9249 = struct { value_zx_type_676_dc19aca6288fa6210d4f477624d77a156a3220aaa2b953dece7140541e04cca6, value_zx_type_340_25fcf08c59c51140437c0c0f32db29701c62088cf889cabda7295d6d4cf49981, value_zx_type_340_25fcf08c59c51140437c0c0f32db29701c62088cf889cabda7295d6d4cf49981, value_zx_type_563_8b5789c4c2e37df89d770df0dc0023ac727b5fdccb37e9c3e3dfae2ea7f694b6, ?*const zx_type_977, };

pub const value_zx_type_978_39eaad6ae25f75874ee5eba1960aceb56c56ae5d9bc203396893ac4369fdc10c = struct { value_zx_type_680_a8bc082d1822f14eea9dd469eba364f8aaab6572f900a6cddfe41b6ceb6cb5ad, ?*const zx_type_978, };

pub const value_zx_type_979_2e5facc5dee2eb1e70a1dbac675ff69ff6cffe14db36096ca0beba4b4277394b = struct { value_zx_type_680_a8bc082d1822f14eea9dd469eba364f8aaab6572f900a6cddfe41b6ceb6cb5ad, value_zx_type_563_8b5789c4c2e37df89d770df0dc0023ac727b5fdccb37e9c3e3dfae2ea7f694b6, ?*const zx_type_979, };

pub const value_zx_type_980_26c432f22e1355cd92b94e1e9662e733933dfa13383067717933fd8faffc0d1e = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    index: u64,
    names: []const []const u8,
    state: value_zx_type_564_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06,
    types: []const u32,
    zx_origin: ?*const zx_type_980 = null,
};

pub const value_zx_type_981_3b28148f52fb9ed326659dce1e6c675bfd41dfd9e51039eb3b0d78e828ae784d = struct { value_zx_type_680_a8bc082d1822f14eea9dd469eba364f8aaab6572f900a6cddfe41b6ceb6cb5ad, value_zx_type_566_cf4ab152ee80a8016752d39fd09af8928e2d7716ad96a00f10be66b0795e522c, ?*const zx_type_981, };

pub const value_zx_type_982_4be9661e489ed3ce80575771185f7b45d37d738575bfd276c56d43d4bf2cfef3 = struct { value_zx_type_677_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, ?*const zx_type_982, };

pub const value_zx_type_983_48e2c0f5bd3a4fe54518b8de4418a7b86bb13e78fcde6c0cc36d374b0fdf1045 = struct { value_zx_type_677_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, value_zx_type_262_6c42e587ea37fcf9cebd3363bae951bc8d27c8514466872e4d2dccf9f350e428, ?*const zx_type_983, };

pub const value_zx_type_984_9b5e383069490003af0e86e7b3d987efbb4952542f2345bf2b6ca6b3a4818542 = struct { value_zx_type_677_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, value_zx_type_262_6c42e587ea37fcf9cebd3363bae951bc8d27c8514466872e4d2dccf9f350e428, value_zx_type_262_6c42e587ea37fcf9cebd3363bae951bc8d27c8514466872e4d2dccf9f350e428, ?*const zx_type_984, };

pub const value_zx_type_985_6ea68a5af361f915d221225ec4acf6470a304dd10111145d1c3043624fc33586 = struct { value_zx_type_677_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, value_zx_type_262_6c42e587ea37fcf9cebd3363bae951bc8d27c8514466872e4d2dccf9f350e428, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, ?*const zx_type_985, };

pub const value_zx_type_986_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    diagnostic: *const zx_type_31,
    expressions: *const zx_type_216,
    index: u64,
    zx_origin: ?*const zx_type_986 = null,
};

pub const value_zx_type_987_42be058395f45895782c9bb1e3a87ced5230f71e0e86ba92491a12d5cb2a1cb8 = struct { value_zx_type_569_0688cdc93fcb174a194199b1cd5068ba766b98ddfa06b9fc939ad58ef6f2932c, ?*const zx_type_987, };

pub const value_zx_type_988_953442536f5844865df105727fb9c384016a34370750b8ab07c21f85d317dd78 = struct { value_zx_type_569_0688cdc93fcb174a194199b1cd5068ba766b98ddfa06b9fc939ad58ef6f2932c, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, ?*const zx_type_988, };

pub const value_zx_type_989_c1e8bbf5f12a60250900295413fbfcb089911841698e4fbba3f65b02537e5750 = struct { value_zx_type_569_0688cdc93fcb174a194199b1cd5068ba766b98ddfa06b9fc939ad58ef6f2932c, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, ?*const zx_type_989, };

pub const value_zx_type_990_61a80eeb390f1901c3da8a5ce0e5710bb834850320fe4679c9011f04cdfd790d = struct { value_zx_type_569_0688cdc93fcb174a194199b1cd5068ba766b98ddfa06b9fc939ad58ef6f2932c, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519, ?*const zx_type_990, };

pub const value_zx_type_991_000ee1a383222f11fe176d964189e8ffde067dda4f192e0c958a52a611729cd5 = struct { value_zx_type_569_0688cdc93fcb174a194199b1cd5068ba766b98ddfa06b9fc939ad58ef6f2932c, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519, value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519, ?*const zx_type_991, };

pub const value_zx_type_992_72aacfc8aa96f7e34f612fdfaf77fabcaa726314f106d1e409ad337e159d57a2 = struct { value_zx_type_569_0688cdc93fcb174a194199b1cd5068ba766b98ddfa06b9fc939ad58ef6f2932c, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519, value_zx_type_325_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519, value_zx_type_570_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, ?*const zx_type_992, };

pub const value_zx_type_993_049bba9dc35b21e7922e5770f094b1c3e0d1c956525d3620dde6415940c61299 = struct { value_zx_type_569_0688cdc93fcb174a194199b1cd5068ba766b98ddfa06b9fc939ad58ef6f2932c, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_570_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, ?*const zx_type_993, };

pub const value_zx_type_994_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_220, void, ?*const zx_type_994, };

pub const value_zx_type_995_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_219, void, ?*const zx_type_995, };

pub const value_zx_type_996_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_216, void, ?*const zx_type_996, };

pub const value_zx_type_997_566bce48228bf853f5f451cdd0fc981caa561774d735dabde02ad480d7cde45b = struct {
    index: u64,
    work: value_zx_type_567_7a135972523f4dd229b7135bf69702c9e43f2d141a9f6165f7389161c6ac3103,
    zx_origin: ?*const zx_type_997 = null,
};

pub const value_zx_type_998_48e3a9191a6bd7115eff51128245fc9d30a25ab206a8eca0e1632e6ad7c2d7d8 = struct { value_zx_type_568_4fee5884459e049a8923b407d2def0a2d096d39589fa0cafde3272173b799f75, ?*const zx_type_998, };

pub const value_zx_type_999_750f36897e94be691111132e8cb9569a1dbe5650f021fd411bcc8cc74775bc08 = struct { value_zx_type_568_4fee5884459e049a8923b407d2def0a2d096d39589fa0cafde3272173b799f75, value_zx_type_567_7a135972523f4dd229b7135bf69702c9e43f2d141a9f6165f7389161c6ac3103, ?*const zx_type_999, };

pub const value_zx_type_1000_7825b04f811151710248609ec77ea6658fddeefc50fc9c339927f8c0065f48be = struct { value_zx_type_568_4fee5884459e049a8923b407d2def0a2d096d39589fa0cafde3272173b799f75, value_zx_type_567_7a135972523f4dd229b7135bf69702c9e43f2d141a9f6165f7389161c6ac3103, value_zx_type_572_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b, ?*const zx_type_1000, };

pub const value_zx_type_1001_f366c2aa537444e7e293f096b6f29cb669f9a2c1734a4c99e1755775e08e4b8d = struct { value_zx_type_680_a8bc082d1822f14eea9dd469eba364f8aaab6572f900a6cddfe41b6ceb6cb5ad, value_zx_type_572_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b, ?*const zx_type_1001, };

pub const value_zx_type_1002_4854cde39e36b19a70d421960f863c814d73da5cf3181d8fbe8174fcb46ecdcd = struct {
    target: value_zx_type_21_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_1002 = null,
};

pub const value_zx_type_1003_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    index: u64,
    references: []const bool,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_1003 = null,
};

pub const value_zx_type_1004_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    expressions: *const zx_type_216,
    index: u64,
    kind: zx_type_203,
    locals: []const bool,
    payload: u64,
    zx_origin: ?*const zx_type_1004 = null,
};

pub const value_zx_type_1005_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    body: u64,
    condition: u64,
    count: u64,
    locals: []const bool,
    reachable: []const bool,
    symbols: u64,
    zx_origin: ?*const zx_type_1005 = null,
};

pub const value_zx_type_1006_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_216,
    index: u64,
    locals: []const bool,
    reachable: []const bool,
    remaining: u64,
    zx_origin: ?*const zx_type_1006 = null,
};

pub const value_zx_type_1007_d42088e18bb5c05cf1e3a3d9851c1dd08d41eae9e1223a6150bd284f2dc08b77 = struct {
    count: []const u64,
    first: []const u64,
    index: u64,
    program: value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    symbols: []const u64,
    zx_origin: ?*const zx_type_1007 = null,
};

pub const value_zx_type_1008_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    locals: []const bool,
    symbols: []const u64,
    zx_origin: ?*const zx_type_1008 = null,
};

pub const value_zx_type_1009_4c9a900895778ef8a8b8af9807bd68428ea35c59b77acdf07c33728d1d771352 = struct {
    active: bool,
    cached_count: []const u64,
    cached_first: []const u64,
    cached_positions: []const u64,
    children: []const u64,
    field_indices: []const u64,
    heads: []const u64,
    index: u64,
    item: u64,
    next: []const u64,
    parents: []const u64,
    phase: zx_type_590,
    place_types: []const u32,
    program: value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    tails: []const u64,
    zx_origin: ?*const zx_type_1009 = null,
};

pub const value_zx_type_1010_1b2191a44235c6e6b65e1ae9ab1c3d223553737681d5d92d9e9cae41a381d262 = struct {
    active: bool,
    found: bool,
    index: value_zx_type_593_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    key: value_zx_type_594_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_1010 = null,
};

pub const value_zx_type_1011_2a73385728db51fa9518b55ca4dd797e91049a447a89c6c5efe9d790e5c08e2e = struct { value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, ?*const zx_type_1011, };

pub const value_zx_type_1012_767b69074202a272a12100b84e23109da965767802298cfb5e4fed280635514e = struct { value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, ?*const zx_type_1012, };

pub const value_zx_type_1013_46b777fb29a6ec83f56ee22ad77d1bbbd13caf8e6a27064012c94c0eb1544938 = struct { value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, ?*const zx_type_1013, };

pub const value_zx_type_1014_18fcb2898d1d7204e87db706f073fcf51d79752c11063fe602073e375e06acd1 = struct { value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_581_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_1014, };

pub const value_zx_type_1015_2cde30861016700fbcc37ec0e53f358a870f83b3d9276e54dca5abfa42381dbf = struct { value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_581_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_588_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937, ?*const zx_type_1015, };

pub const value_zx_type_1016_fc9d1607bfc29c393e85973469418c6449deb36cf03f440f10859d1b0e6cf2c1 = struct { value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_581_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_588_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937, value_zx_type_589_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d, ?*const zx_type_1016, };

pub const value_zx_type_1017_df87d4e4c94482fd017e977a114eba826861ac6af356c343aea16855cac7c373 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    state: zx_type_582,
    zx_origin: ?*const zx_type_1017 = null,
};

pub const value_zx_type_1018_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_582, void, ?*const zx_type_1018, };

pub const value_zx_type_1019_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    children: []const u64,
    count: u64,
    first: u64,
    index: u64,
    source: []const u64,
    zx_origin: ?*const zx_type_1019 = null,
};

pub const value_zx_type_1020_03ceda26995807c2aa6530d3178a20e89911f37af4bad09be3c9b210bc3682ce = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    target: u64,
    type_id: u32,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_1020 = null,
};

pub const value_zx_type_1021_20d7d99279e33ed98c39ff3a89f60b0602618a66dfe76434242c1e24534deee7 = struct {
    active: bool,
    ascending: bool,
    fact: u64,
    facts: []const u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    id: u64,
    layout: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    leaving: bool,
    references: []const bool,
    root: u64,
    states: []const zx_type_582,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_1021 = null,
};

pub const value_zx_type_1022_b96c48974ce17ef2b8be551c68efc904286af193386b87a21ad68406a5672c15 = struct {
    active: bool,
    cache: value_zx_type_615_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    found: bool,
    left: u64,
    right: u64,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_1022 = null,
};

pub const value_zx_type_1023_4b4ea4009453ea5e4d3d79e2158cdc223b3d2c1404741f1be6d92e28595818e4 = struct {
    active: bool,
    cache: value_zx_type_615_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    capacity: u64,
    grow: bool,
    index: u64,
    left: u64,
    right: u64,
    value: u64,
    zx_origin: ?*const zx_type_1023 = null,
};

pub const value_zx_type_1024_fddf701302546dc5c12ecdb7d8719eb57b5e534ac713eb9744231ee909d8dc70 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    same: bool,
    type_id: u32,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_1024 = null,
};

pub const value_zx_type_1025_b3760cb020967af5517f45e8ca01d64dcc589438ca8342340b78221ceef17d6a = struct {
    action: zx_type_614,
    cache: value_zx_type_615_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    children: []const u64,
    first: []const u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    indices: []const u64,
    left: []const u64,
    paired: bool,
    references: []const bool,
    right: []const u64,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_1025 = null,
};

pub const value_zx_type_1026_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: u64,
    facts: []const u64,
    memo: []const u64,
    places: u64,
    states: []const zx_type_582,
    zx_origin: ?*const zx_type_1026 = null,
};

pub const value_zx_type_1027_84331d6a4a43806456ffa46c6afa1bd16dcd6bebddd17f96d6eddd9ac3c6fff1 = struct { value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_678_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a, ?*const zx_type_1027, };

pub const value_zx_type_1028_56d3a3384af94c4c5beea8da80c665c922686500c24f911e92fe4db704c5a3bf = struct { value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_678_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a, value_zx_type_626_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf, ?*const zx_type_1028, };

pub const value_zx_type_1029_797fedc00020e01168f99323a87b071e9e1bdebae23b4195463f8ae8c1241ef7 = struct {
    action: zx_type_623,
    count: u64,
    index: u64,
    layout: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memo_first: u64,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    rewrite_action: zx_type_614,
    saved: value_zx_type_624_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    state_first: u64,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_1029 = null,
};

pub const value_zx_type_1031_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const zx_type_629, ?zx_type_629, ?*const zx_type_1031, };

pub const value_zx_type_1032_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_629, void, ?*const zx_type_1032, };

pub const value_zx_type_1033_463372a636e1a2c93bbb2070e2204f09a436eef0f006e94b3d11fa862ef159e2 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    merge: bool,
    parents: []const u64,
    references: []const bool,
    saved: []const u64,
    source: []const u64,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_1033 = null,
};

pub const value_zx_type_1034_2b3f0033db751cf78256c30d401a1a8639ee63997cf1909aeaff24112d21a8c6 = struct {
    activation: u64,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    loops: value_zx_type_639_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    references: []const bool,
    seen: bool,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_1034 = null,
};

pub const value_zx_type_1035_57c8216039667f25f8124cd801f82d6db9b8e64f4e9aa500df6f0cbf67657227 = struct {
    activation: u64,
    changed: bool,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: value_zx_type_603_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    loops: value_zx_type_639_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    references: []const bool,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_1035 = null,
};

pub const value_zx_type_1036_87c1c976ed99693bb0b79319ced55961e2f09cd998a5c93ecc538e2ca8eb719e = struct {
    count: u64,
    facts: []const u64,
    first: u64,
    index: u64,
    layout: value_zx_type_584_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    local_first: u64,
    locals: u64,
    memory: value_zx_type_625_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    roots: []const u64,
    symbols: []const u64,
    types: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_1036 = null,
};

pub const value_zx_type_1037_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    flags: []const bool,
    symbols: u64,
    zx_origin: ?*const zx_type_1037 = null,
};

pub const value_zx_type_1038_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    first: u64,
    flags: []const bool,
    index: u64,
    symbols: []const u64,
    zx_origin: ?*const zx_type_1038 = null,
};

pub const value_zx_type_1039_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    flags: []const bool,
    index: u64,
    memo: []const u64,
    parents: []const u64,
    zx_origin: ?*const zx_type_1039 = null,
};

pub const value_zx_type_1040_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u64,
    parents: []const u64,
    zx_origin: ?*const zx_type_1040 = null,
};

pub const value_zx_type_1041_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    facts: []const u64,
    flags: []const bool,
    index: u64,
    outputs: []const u64,
    roots: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_1041 = null,
};

pub const value_zx_type_1042_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    index: u64,
    slots: *const zx_type_236,
    zx_origin: ?*const zx_type_1042 = null,
};

pub const value_zx_type_1043_45c9de4479c865238cef7a36dce7217ac4de64b83f4320ae5b044d7e2faff701 = struct {
    active: bool,
    ascending: bool,
    expression: u64,
    expressions: *const zx_type_216,
    found: bool,
    layout: value_zx_type_589_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    position: u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_1043 = null,
};

pub const value_zx_type_1044_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    children: []const u64,
    count: u64,
    index: u64,
    zx_origin: ?*const zx_type_1044 = null,
};

pub const value_zx_type_1045_39e74984115c929e88eabd575698c342998222fa7ee1c2957f496eb4bea9c312 = struct { value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_679_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134, ?*const zx_type_1045, };

pub const value_zx_type_1046_3ef121c2969f416beec22224e6006647d628ebbbd818e782fec8feea9c3aa01c = struct { value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_679_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134, value_zx_type_633_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_1046, };

pub const value_zx_type_1047_160428a57231117423c4da5fde434f9d815cd91e86e128ea52f6e3b6d897e125 = struct { value_zx_type_575_25528cf02c143df190dcdbb07f8178a6266eeb9de924da1d1353e3ac8d12865e, ?*const zx_type_1047, };

pub const value_zx_type_1048_02918707d826c91fbf58c72f433616917cb64037004705d8fa90644e6d74254c = struct { value_zx_type_575_25528cf02c143df190dcdbb07f8178a6266eeb9de924da1d1353e3ac8d12865e, value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, ?*const zx_type_1048, };

pub const value_zx_type_1049_acc2bd3135242d73aa7ba67785b6a50ab8da3eebcb2f671a98a23fa21b95e783 = struct { value_zx_type_575_25528cf02c143df190dcdbb07f8178a6266eeb9de924da1d1353e3ac8d12865e, value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_633_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_1049, };

pub const value_zx_type_1050_688536ea7b18e6357009711d2a355f71fae68d6bd384d1f67e13d35332816e26 = struct { value_zx_type_575_25528cf02c143df190dcdbb07f8178a6266eeb9de924da1d1353e3ac8d12865e, value_zx_type_574_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_633_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_666_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b, ?*const zx_type_1050, };

pub const value_zx_type_1051_f366c2aa537444e7e293f096b6f29cb669f9a2c1734a4c99e1755775e08e4b8d = struct { value_zx_type_680_a8bc082d1822f14eea9dd469eba364f8aaab6572f900a6cddfe41b6ceb6cb5ad, value_zx_type_666_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b, ?*const zx_type_1051, };

pub const value_zx_type_1052_d6a827c356ef2692e9d360642c9190e2e2b7355133d1df3880f6397688d48a43 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, ?*const zx_type_1052, };

pub const value_zx_type_1053_2a18dd4b375519adb1d9044bbb734898f28375364b265010d4257a748caab288 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, ?*const zx_type_1053, };

pub const value_zx_type_1054_b5ec089b4faf048826435fcb5432b4bfb50ff3540954e63d9a3187e74f0bf74e = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, ?*const zx_type_1054, };

pub const value_zx_type_1055_3fc08003e5663ccf284626c92288f6f1acbe915396fc2f5f477d7abe654030bc = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, ?*const zx_type_1055, };

pub const value_zx_type_1056_3620c16f18e311e1fcd235fb8dc8eeb0d1d80db74f7dfd867356c701c943ef37 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, ?*const zx_type_1056, };

pub const value_zx_type_1057_6b17edf3dcc46aa28b432192e41deeb7f97cccb0506e29c861e513eebd8509c4 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, ?*const zx_type_1057, };

pub const value_zx_type_1058_4aa8b07fc77ad4f369f1e04d2b291f3064585f7f31abf04cca30575aff979c11 = struct { value_zx_type_244_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4, value_zx_type_263_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_265_14b98763f32408d81796dae5df179a1aac0196a5eebea99db49f483ed986ac21, value_zx_type_669_7b2f1e8e138e90625e80ca60c3f20204ae02fbf6e71d133be9439692824ff408, ?*const zx_type_1058, };

pub const native = struct {
    pub const @"std:encoding" = struct {
        pub const encodeBase64 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeBase64 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const encodeHex = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeHex = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const encodeUtf8 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeUtf8 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const sliceBytes = struct {
            pub const Input = *const zx_type_158;
            pub const Output = []const u8;
            pub const InputValue = zx_type_158;
            pub const OutputValue = []const u8;
        };
    };
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
    pub const @"zig:floats" = struct {
        pub const narrow = struct {
            pub const Input = f64;
            pub const Output = f32;
            pub const InputValue = f64;
            pub const OutputValue = f32;
        };
        pub const widen = struct {
            pub const Input = f32;
            pub const Output = f64;
            pub const InputValue = f32;
            pub const OutputValue = f64;
        };
        pub const isFinite = struct {
            pub const Input = f64;
            pub const Output = bool;
            pub const InputValue = f64;
            pub const OutputValue = bool;
        };
        pub const parse32 = struct {
            pub const Input = []const u8;
            pub const Output = ?f32;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f32;
        };
        pub const parse64 = struct {
            pub const Input = []const u8;
            pub const Output = ?f64;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f64;
        };
    };
};

pub const layouts = struct {
    pub const @"std:encoding" = struct {
    };
    pub const @"zig:integers" = struct {
    };
    pub const @"zig:floats" = struct {
    };
};

