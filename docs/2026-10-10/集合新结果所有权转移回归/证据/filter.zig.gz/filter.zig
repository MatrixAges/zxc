const std = @import("std");

const zx_type_12 = struct {
    count: u64,
    values: []const u64,
};

const zx_type_13 = struct {
    count: u64,
    round: u64,
    values: []const u64,
};

const zx_type_14 = struct {
    original: []const u64,
    values: []const u64,
};

const zx_type_15 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
};

const zx_type_16 = struct { []const u64, void, };

const value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    round: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    original: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_15 = null,
};

const value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_16, };

pub const Input = *const zx_type_12;

pub const State = *const zx_type_13;

pub const Output = *const zx_type_14;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .round = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .original = zx_shape_11, .values = zx_shape_11, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_11, .source = zx_shape_11, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_0, }, };

pub const input_shape = zx_shape_12;

pub const output_shape = zx_shape_14;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_12) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_14 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_8: *const zx_type_13 = block_65: {
        const operand_33 = block_60: {
            const value_2: []const u64 = (in).values;

            break :block_60 block_59: {
                const operand_40 = block_39: {
                    const operand_35 = value_2;
                    const operand_36 = @as(u64, 0);
                    const operand_37 = block_38: {
                        break :block_38 (try (allocator).dupe(u64, (&[_]u64{})));
                    };

                    break :block_39 zx_type_15{ .index = operand_36, .result = operand_37, .source = operand_35, };
                };

                var state_capacity_41: (std).ArrayList(u64) = .empty;

                var state_capacity_started_42 = false;

                defer (state_capacity_41).deinit(allocator);

                var state_34: value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_40).index, .result = (operand_40).result, .source = (operand_40).source, .zx_origin = (&operand_40), };

                while (((state_34).index < @as(u64, ((state_34).source).len))) {
                    state_34 = block_57: {
                        const value_5: u64 = block_56: {
                            const operand_54 = (state_34).source;
                            const operand_55 = (state_34).index;

                            if ((operand_55 >= (operand_54).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_56 (operand_54)[@intCast(operand_55)];
                        };
                        const value_1: u64 = block_53: {
                            break :block_53 value_5;
                        };
                        const value_6: bool = (@rem(block_52: {
                            break :block_52 value_1;
                        }, @as(u64, 2)) == @as(u64, 0));

                        break :block_57 block_51: {
                            const operand_43 = (state_34).source;
                            const operand_44 = ((state_34).index + @as(u64, 1));
                            const operand_45 = (if (block_46: {
                                break :block_46 value_6;
                            }) (block_50: {
                                const operand_47 = (state_34).result;
                                const operand_49 = block_48: {
                                    break :block_48 value_5;
                                };

                                _ = (try ((std).math).add(usize, (operand_47).len, 1));

                                if ((!state_capacity_started_42)) {
                                    (try (state_capacity_41).ensureTotalCapacityPrecise(allocator, ((operand_40).source).len));

                                    (try (state_capacity_41).appendSlice(allocator, operand_47));

                                    state_capacity_started_42 = true;
                                } else {
                                    ((state_capacity_41).items).len = (operand_47).len;
                                }

                                (try (state_capacity_41).append(allocator, operand_49));

                                break :block_50 @as(value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_41).items, {}, null, });
                            }).@"0" else (state_34).result);

                            break :block_51 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_44, .result = operand_45, .source = operand_43, });
                        };
                    };
                }

                var state_owned_58: []const u64 = (&[_]u64{});

                errdefer (allocator).free(state_owned_58);

                if (state_capacity_started_42) {
                    ((state_capacity_41).items).len = ((state_34).result).len;

                    state_owned_58 = (try (state_capacity_41).toOwnedSlice(allocator));
                }

                if (state_capacity_started_42) {
                    state_34 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_34).index, .result = state_owned_58, .source = (state_34).source, };
                }

                break :block_59 (state_34).result;
            };
        };
        const operand_61 = @as(u64, 0);
        const operand_62 = (in).count;

        break :block_65 block_64: {
            const operand_63 = (try (allocator).create(zx_type_13));

            (operand_63).* = @as(zx_type_13, zx_type_13{ .values = operand_33, .round = operand_61, .count = operand_62, });

            break :block_64 @as(*const zx_type_13, operand_63);
        };
    };
    const value_17: *const zx_type_13 = block_32: {
        const operand_8 = value_8;

        var state_items_10: []u64 = undefined;

        var state_items_started_11 = false;

        var state_7: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (operand_8).count, .round = (operand_8).round, .values = (operand_8).values, .zx_origin = operand_8, };

        var state_changed_9 = false;

        while (((state_7).round < (state_7).count)) {
            state_7 = block_28: {
                const value_11: []const u64 = (state_7).values;
                const value_12: u64 = @as(u64, 0);
                const value_13: u64 = block_27: {
                    const operand_25 = block_23: {
                        break :block_23 value_11;
                    };
                    const operand_26 = block_24: {
                        break :block_24 value_12;
                    };

                    if ((operand_26 >= (operand_25).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_27 (operand_25)[@intCast(operand_26)];
                };
                const value_14: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_22: {
                    break :block_22 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (state_7).count, .round = (state_7).round, .values = block_21: {
                        const operand_15 = block_14: {
                            break :block_14 value_11;
                        };
                        const operand_17 = block_16: {
                            break :block_16 value_12;
                        };

                        if ((operand_17 >= (operand_15).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_19 = (block_18: {
                            break :block_18 value_13;
                        } + @as(u64, 1));

                        break :block_21 block_20: {
                            if ((!state_items_started_11)) {
                                state_items_10 = (try (allocator).dupe(u64, operand_15));

                                state_items_started_11 = true;
                            }

                            (state_items_10)[@intCast(operand_17)] = operand_19;

                            break :block_20 state_items_10;
                        };
                    }, });
                };
                const value_15: u64 = (value_14).round;
                const value_16: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_13: {
                    break :block_13 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (value_14).count, .round = (block_12: {
                        break :block_12 value_15;
                    } + @as(u64, 1)), .values = (value_14).values, });
                };

                break :block_28 value_16;
            };

            state_changed_9 = true;
        }

        break :block_32 (if (state_changed_9) block_31: {
            break :block_31 (if (((state_7).zx_origin != null)) (state_7).zx_origin.? else block_30: {
                const operand_29 = (try (allocator).create(zx_type_13));

                (operand_29).* = zx_type_13{ .count = (state_7).count, .round = (state_7).round, .values = (state_7).values, };

                break :block_30 @as(*const zx_type_13, operand_29);
            });
        } else operand_8);
    };

    return block_6: {
        const operand_2 = (in).values;
        const operand_3 = (value_17).values;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create(zx_type_14));

            (operand_4).* = @as(zx_type_14, zx_type_14{ .original = operand_2, .values = operand_3, });

            break :block_5 @as(*const zx_type_14, operand_4);
        };
    };
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_8: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_125: {
        const operand_94 = block_122: {
            const value_2: []const u64 = (in).values;

            break :block_122 block_121: {
                const operand_102 = block_101: {
                    const operand_96 = block_97: {
                        break :block_97 value_2;
                    };
                    const operand_98 = @as(u64, 0);
                    const operand_99 = block_100: {
                        break :block_100 (try (allocator).dupe(u64, (&[_]u64{})));
                    };

                    break :block_101 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_98, .result = operand_99, .source = operand_96, });
                };

                var state_capacity_103: (std).ArrayList(u64) = .empty;

                var state_capacity_started_104 = false;

                defer (state_capacity_103).deinit(allocator);

                var state_95: value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_102;

                while (((state_95).index < @as(u64, ((state_95).source).len))) {
                    state_95 = block_119: {
                        const value_5: u64 = block_118: {
                            const operand_116 = (state_95).source;
                            const operand_117 = (state_95).index;

                            if ((operand_117 >= (operand_116).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_118 (operand_116)[@intCast(operand_117)];
                        };
                        const value_1: u64 = block_115: {
                            break :block_115 value_5;
                        };
                        const value_6: bool = (@rem(block_114: {
                            break :block_114 value_1;
                        }, @as(u64, 2)) == @as(u64, 0));

                        break :block_119 block_113: {
                            const operand_105 = (state_95).source;
                            const operand_106 = ((state_95).index + @as(u64, 1));
                            const operand_107 = (if (block_108: {
                                break :block_108 value_6;
                            }) (block_112: {
                                const operand_109 = (state_95).result;
                                const operand_111 = block_110: {
                                    break :block_110 value_5;
                                };

                                _ = (try ((std).math).add(usize, (operand_109).len, 1));

                                if ((!state_capacity_started_104)) {
                                    (try (state_capacity_103).ensureTotalCapacityPrecise(allocator, ((operand_102).source).len));

                                    (try (state_capacity_103).appendSlice(allocator, operand_109));

                                    state_capacity_started_104 = true;
                                } else {
                                    ((state_capacity_103).items).len = (operand_109).len;
                                }

                                (try (state_capacity_103).append(allocator, operand_111));

                                break :block_112 @as(value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_103).items, {}, null, });
                            }).@"0" else (state_95).result);

                            break :block_113 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_106, .result = operand_107, .source = operand_105, });
                        };
                    };
                }

                var state_owned_120: []const u64 = (&[_]u64{});

                errdefer (allocator).free(state_owned_120);

                if (state_capacity_started_104) {
                    ((state_capacity_103).items).len = ((state_95).result).len;

                    state_owned_120 = (try (state_capacity_103).toOwnedSlice(allocator));
                }

                if (state_capacity_started_104) {
                    state_95 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_95).index, .result = state_owned_120, .source = (state_95).source, };
                }

                break :block_121 (state_95).result;
            };
        };
        const operand_123 = @as(u64, 0);
        const operand_124 = (in).count;

        break :block_125 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .values = operand_94, .round = operand_123, .count = operand_124, });
    };
    const value_17: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_93: {
        const operand_71 = value_8;

        var state_items_73: []u64 = undefined;

        var state_items_started_74 = false;

        var state_70: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_71;

        var state_changed_72 = false;

        while (((state_70).round < (state_70).count)) {
            state_70 = block_91: {
                const value_11: []const u64 = (state_70).values;
                const value_12: u64 = @as(u64, 0);
                const value_13: u64 = block_90: {
                    const operand_88 = block_86: {
                        break :block_86 value_11;
                    };
                    const operand_89 = block_87: {
                        break :block_87 value_12;
                    };

                    if ((operand_89 >= (operand_88).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_90 (operand_88)[@intCast(operand_89)];
                };
                const value_14: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_85: {
                    break :block_85 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (state_70).count, .round = (state_70).round, .values = block_84: {
                        const operand_78 = block_77: {
                            break :block_77 value_11;
                        };
                        const operand_80 = block_79: {
                            break :block_79 value_12;
                        };

                        if ((operand_80 >= (operand_78).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_82 = (block_81: {
                            break :block_81 value_13;
                        } + @as(u64, 1));

                        break :block_84 block_83: {
                            if ((!state_items_started_74)) {
                                state_items_73 = (try (allocator).dupe(u64, operand_78));

                                state_items_started_74 = true;
                            }

                            (state_items_73)[@intCast(operand_80)] = operand_82;

                            break :block_83 state_items_73;
                        };
                    }, });
                };
                const value_15: u64 = (value_14).round;
                const value_16: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_76: {
                    break :block_76 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (value_14).count, .round = (block_75: {
                        break :block_75 value_15;
                    } + @as(u64, 1)), .values = (value_14).values, });
                };

                break :block_91 value_16;
            };

            state_changed_72 = true;
        }

        break :block_93 (if (state_changed_72) state_70 else operand_71);
    };

    return block_69: {
        const operand_67 = (in).values;
        const operand_68 = (value_17).values;

        break :block_69 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .original = operand_67, .values = operand_68, });
    };
}

