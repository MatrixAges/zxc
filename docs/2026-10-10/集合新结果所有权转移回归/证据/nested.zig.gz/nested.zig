const std = @import("std");

const zx_type_12 = struct {
    count: u64,
    values: []const u64,
};

const zx_type_13 = struct {
    values: []const u64,
};

const zx_type_14 = struct {
    box: *const zx_type_13,
    count: u64,
    round: u64,
};

const zx_type_15 = struct {
    original: []const u64,
    values: []const u64,
};

const zx_type_16 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
};

const zx_type_17 = struct { []const u64, void, };

const value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = struct {
    values: []const u64,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51 = struct {
    box: value_zx_type_13_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744,
    count: u64,
    round: u64,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_15_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    original: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_15 = null,
};

const value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_16 = null,
};

const value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_17, };

pub const Input = *const zx_type_12;

pub const State = *const zx_type_14;

pub const Output = *const zx_type_15;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .values = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .box = zx_shape_13, .count = zx_shape_5, .round = zx_shape_5, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .original = zx_shape_11, .values = zx_shape_11, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_11, .source = zx_shape_11, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_0, }, };

pub const input_shape = zx_shape_12;

pub const output_shape = zx_shape_15;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_12) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_15 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_8: *const zx_type_14 = block_63: {
        const operand_28 = block_58: {
            const operand_29 = block_55: {
                const value_2: []const u64 = (in).values;

                break :block_55 block_54: {
                    const operand_36 = block_35: {
                        const operand_31 = value_2;
                        const operand_32 = @as(u64, 0);
                        const operand_33 = block_34: {
                            break :block_34 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_35 zx_type_16{ .index = operand_32, .result = operand_33, .source = operand_31, };
                    };

                    var state_capacity_37: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_38 = false;

                    defer (state_capacity_37).deinit(allocator);

                    var state_30: value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_36).index, .result = (operand_36).result, .source = (operand_36).source, .zx_origin = (&operand_36), };

                    while (((state_30).index < @as(u64, ((state_30).source).len))) {
                        state_30 = block_52: {
                            const value_5: u64 = block_51: {
                                const operand_49 = (state_30).source;
                                const operand_50 = (state_30).index;

                                if ((operand_50 >= (operand_49).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_51 (operand_49)[@intCast(operand_50)];
                            };
                            const value_1: u64 = block_48: {
                                break :block_48 value_5;
                            };
                            const value_6: u64 = (block_47: {
                                break :block_47 value_1;
                            } + @as(u64, 1));

                            break :block_52 block_46: {
                                const operand_39 = (state_30).source;
                                const operand_40 = ((state_30).index + @as(u64, 1));
                                const operand_41 = (block_45: {
                                    const operand_42 = (state_30).result;
                                    const operand_44 = block_43: {
                                        break :block_43 value_6;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_42).len, 1));

                                    if ((!state_capacity_started_38)) {
                                        (try (state_capacity_37).ensureTotalCapacityPrecise(allocator, ((operand_36).source).len));

                                        (try (state_capacity_37).appendSlice(allocator, operand_42));

                                        state_capacity_started_38 = true;
                                    } else {
                                        ((state_capacity_37).items).len = (operand_42).len;
                                    }

                                    (try (state_capacity_37).append(allocator, operand_44));

                                    break :block_45 @as(value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_37).items, {}, null, });
                                }).@"0";

                                break :block_46 @as(value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_40, .result = operand_41, .source = operand_39, });
                            };
                        };
                    }

                    var state_owned_53: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_53);

                    if (state_capacity_started_38) {
                        ((state_capacity_37).items).len = ((state_30).result).len;

                        state_owned_53 = (try (state_capacity_37).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_38) {
                        state_30 = value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_30).index, .result = state_owned_53, .source = (state_30).source, };
                    }

                    break :block_54 (state_30).result;
                };
            };

            break :block_58 block_57: {
                const operand_56 = (try (allocator).create(zx_type_13));

                (operand_56).* = @as(zx_type_13, zx_type_13{ .values = operand_29, });

                break :block_57 @as(*const zx_type_13, operand_56);
            };
        };
        const operand_59 = @as(u64, 0);
        const operand_60 = (in).count;

        break :block_63 block_62: {
            const operand_61 = (try (allocator).create(zx_type_14));

            (operand_61).* = @as(zx_type_14, zx_type_14{ .box = operand_28, .round = operand_59, .count = operand_60, });

            break :block_62 @as(*const zx_type_14, operand_61);
        };
    };

    return block_27: {
        const state_type_3 = struct {
            values: []const u64,
        };
        const state_type_4 = struct {
            box: state_type_3,
            count: u64,
            round: u64,
        };
        const operand_6 = block_5: {
            const operand_2 = value_8;

            break :block_5 state_type_4{ .box = state_type_3{ .values = ((operand_2).box).values, }, .count = (operand_2).count, .round = (operand_2).round, };
        };

        var state_items_8: []u64 = undefined;

        var state_items_started_9 = false;

        var state_1: state_type_4 = operand_6;

        var state_changed_7 = false;

        while (((state_1).round < (state_1).count)) {
            state_1 = block_21: {
                const value_11: []const u64 = ((state_1).box).values;
                const value_12: u64 = @as(u64, 0);
                const value_13: u64 = block_20: {
                    const operand_18 = value_11;
                    const operand_19 = value_12;

                    if ((operand_19 >= (operand_18).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_20 (operand_18)[@intCast(operand_19)];
                };
                const value_14: state_type_4 = block_17: {
                    break :block_17 state_type_4{ .box = block_16: {
                        break :block_16 state_type_3{ .values = block_15: {
                            const operand_11 = value_11;
                            const operand_12 = value_12;

                            if ((operand_12 >= (operand_11).len)) {
                                return error.IndexOutOfBounds;
                            }

                            const operand_13 = (value_13 + @as(u64, 1));

                            break :block_15 block_14: {
                                if ((!state_items_started_9)) {
                                    state_items_8 = (try (allocator).dupe(u64, operand_11));

                                    state_items_started_9 = true;
                                }

                                (state_items_8)[@intCast(operand_12)] = operand_13;

                                break :block_14 state_items_8;
                            };
                        }, };
                    }, .count = (state_1).count, .round = (state_1).round, };
                };
                const value_15: u64 = (value_14).round;
                const value_16: state_type_4 = block_10: {
                    break :block_10 state_type_4{ .box = (value_14).box, .count = (value_14).count, .round = (value_15 + @as(u64, 1)), };
                };

                break :block_21 value_16;
            };

            state_changed_7 = true;
        }

        break :block_27 block_26: {
            const operand_22 = (in).values;
            const operand_23 = ((state_1).box).values;

            break :block_26 block_25: {
                const operand_24 = (try (allocator).create(zx_type_15));

                (operand_24).* = @as(zx_type_15, zx_type_15{ .original = operand_22, .values = operand_23, });

                break :block_25 @as(*const zx_type_15, operand_24);
            };
        };
    };
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_15_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_8: value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51 = block_125: {
        const operand_93 = block_122: {
            const operand_94 = block_121: {
                const value_2: []const u64 = (in).values;

                break :block_121 block_120: {
                    const operand_102 = block_101: {
                        const operand_96 = block_97: {
                            break :block_97 value_2;
                        };
                        const operand_98 = @as(u64, 0);
                        const operand_99 = block_100: {
                            break :block_100 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_101 @as(value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_98, .result = operand_99, .source = operand_96, });
                    };

                    var state_capacity_103: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_104 = false;

                    defer (state_capacity_103).deinit(allocator);

                    var state_95: value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_102;

                    while (((state_95).index < @as(u64, ((state_95).source).len))) {
                        state_95 = block_118: {
                            const value_5: u64 = block_117: {
                                const operand_115 = (state_95).source;
                                const operand_116 = (state_95).index;

                                if ((operand_116 >= (operand_115).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_117 (operand_115)[@intCast(operand_116)];
                            };
                            const value_1: u64 = block_114: {
                                break :block_114 value_5;
                            };
                            const value_6: u64 = (block_113: {
                                break :block_113 value_1;
                            } + @as(u64, 1));

                            break :block_118 block_112: {
                                const operand_105 = (state_95).source;
                                const operand_106 = ((state_95).index + @as(u64, 1));
                                const operand_107 = (block_111: {
                                    const operand_108 = (state_95).result;
                                    const operand_110 = block_109: {
                                        break :block_109 value_6;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_108).len, 1));

                                    if ((!state_capacity_started_104)) {
                                        (try (state_capacity_103).ensureTotalCapacityPrecise(allocator, ((operand_102).source).len));

                                        (try (state_capacity_103).appendSlice(allocator, operand_108));

                                        state_capacity_started_104 = true;
                                    } else {
                                        ((state_capacity_103).items).len = (operand_108).len;
                                    }

                                    (try (state_capacity_103).append(allocator, operand_110));

                                    break :block_111 @as(value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_103).items, {}, null, });
                                }).@"0";

                                break :block_112 @as(value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_106, .result = operand_107, .source = operand_105, });
                            };
                        };
                    }

                    var state_owned_119: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_119);

                    if (state_capacity_started_104) {
                        ((state_capacity_103).items).len = ((state_95).result).len;

                        state_owned_119 = (try (state_capacity_103).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_104) {
                        state_95 = value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_95).index, .result = state_owned_119, .source = (state_95).source, };
                    }

                    break :block_120 (state_95).result;
                };
            };

            break :block_122 @as(value_zx_type_13_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744, value_zx_type_13_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744{ .values = operand_94, });
        };
        const operand_123 = @as(u64, 0);
        const operand_124 = (in).count;

        break :block_125 @as(value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51, value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51{ .box = operand_93, .round = operand_123, .count = operand_124, });
    };
    const value_17: value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51 = block_92: {
        const operand_69 = value_8;

        var state_items_71: []u64 = undefined;

        var state_items_started_72 = false;

        var state_68: value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51 = operand_69;

        var state_changed_70 = false;

        while (((state_68).round < (state_68).count)) {
            state_68 = block_90: {
                const value_11: []const u64 = ((state_68).box).values;
                const value_12: u64 = @as(u64, 0);
                const value_13: u64 = block_89: {
                    const operand_87 = block_85: {
                        break :block_85 value_11;
                    };
                    const operand_88 = block_86: {
                        break :block_86 value_12;
                    };

                    if ((operand_88 >= (operand_87).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_89 (operand_87)[@intCast(operand_88)];
                };
                const value_14: value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51 = block_84: {
                    break :block_84 @as(value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51, value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51{ .box = block_83: {
                        break :block_83 @as(value_zx_type_13_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744, value_zx_type_13_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744{ .values = block_82: {
                            const operand_76 = block_75: {
                                break :block_75 value_11;
                            };
                            const operand_78 = block_77: {
                                break :block_77 value_12;
                            };

                            if ((operand_78 >= (operand_76).len)) {
                                return error.IndexOutOfBounds;
                            }

                            const operand_80 = (block_79: {
                                break :block_79 value_13;
                            } + @as(u64, 1));

                            break :block_82 block_81: {
                                if ((!state_items_started_72)) {
                                    state_items_71 = (try (allocator).dupe(u64, operand_76));

                                    state_items_started_72 = true;
                                }

                                (state_items_71)[@intCast(operand_78)] = operand_80;

                                break :block_81 state_items_71;
                            };
                        }, });
                    }, .count = (state_68).count, .round = (state_68).round, });
                };
                const value_15: u64 = (value_14).round;
                const value_16: value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51 = block_74: {
                    break :block_74 @as(value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51, value_zx_type_14_da4f6cbfd2d4ebf788d2b2d5d9b3a11982b170757908d63d97a60cca80f89e51{ .box = (value_14).box, .count = (value_14).count, .round = (block_73: {
                        break :block_73 value_15;
                    } + @as(u64, 1)), });
                };

                break :block_90 value_16;
            };

            state_changed_70 = true;
        }

        break :block_92 (if (state_changed_70) state_68 else operand_69);
    };

    return block_67: {
        const operand_65 = (in).values;
        const operand_66 = ((value_17).box).values;

        break :block_67 @as(value_zx_type_15_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_15_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .original = operand_65, .values = operand_66, });
    };
}

