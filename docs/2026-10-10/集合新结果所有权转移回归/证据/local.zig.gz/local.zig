const std = @import("std");

const zx_type_12 = struct {
    count: u64,
    values: []const u64,
};

const zx_type_13 = struct {
    count: u64,
    round: u64,
    values: []const u64,
};

const zx_type_14 = struct {
    original: []const u64,
    values: []const u64,
};

const zx_type_15 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
};

const zx_type_16 = struct { []const u64, void, };

const value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    round: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    original: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_15 = null,
};

const value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_16, };

pub const Input = *const zx_type_12;

pub const State = *const zx_type_13;

pub const Output = *const zx_type_14;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .round = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .original = zx_shape_11, .values = zx_shape_11, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_11, .source = zx_shape_11, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_0, }, };

pub const input_shape = zx_shape_12;

pub const output_shape = zx_shape_14;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_12) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_14 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_8: []const u64 = block_64: {
        const value_2: []const u64 = (in).values;

        break :block_64 block_63: {
            const operand_45 = block_44: {
                const operand_40 = value_2;
                const operand_41 = @as(u64, 0);
                const operand_42 = block_43: {
                    break :block_43 (try (allocator).dupe(u64, (&[_]u64{})));
                };

                break :block_44 zx_type_15{ .index = operand_41, .result = operand_42, .source = operand_40, };
            };

            var state_capacity_46: (std).ArrayList(u64) = .empty;

            var state_capacity_started_47 = false;

            defer (state_capacity_46).deinit(allocator);

            var state_39: value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_45).index, .result = (operand_45).result, .source = (operand_45).source, .zx_origin = (&operand_45), };

            while (((state_39).index < @as(u64, ((state_39).source).len))) {
                state_39 = block_61: {
                    const value_5: u64 = block_60: {
                        const operand_58 = (state_39).source;
                        const operand_59 = (state_39).index;

                        if ((operand_59 >= (operand_58).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_60 (operand_58)[@intCast(operand_59)];
                    };
                    const value_1: u64 = block_57: {
                        break :block_57 value_5;
                    };
                    const value_6: u64 = (block_56: {
                        break :block_56 value_1;
                    } + @as(u64, 1));

                    break :block_61 block_55: {
                        const operand_48 = (state_39).source;
                        const operand_49 = ((state_39).index + @as(u64, 1));
                        const operand_50 = (block_54: {
                            const operand_51 = (state_39).result;
                            const operand_53 = block_52: {
                                break :block_52 value_6;
                            };

                            _ = (try ((std).math).add(usize, (operand_51).len, 1));

                            if ((!state_capacity_started_47)) {
                                (try (state_capacity_46).ensureTotalCapacityPrecise(allocator, ((operand_45).source).len));

                                (try (state_capacity_46).appendSlice(allocator, operand_51));

                                state_capacity_started_47 = true;
                            } else {
                                ((state_capacity_46).items).len = (operand_51).len;
                            }

                            (try (state_capacity_46).append(allocator, operand_53));

                            break :block_54 @as(value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_46).items, {}, null, });
                        }).@"0";

                        break :block_55 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_49, .result = operand_50, .source = operand_48, });
                    };
                };
            }

            var state_owned_62: []const u64 = (&[_]u64{});

            errdefer (allocator).free(state_owned_62);

            if (state_capacity_started_47) {
                ((state_capacity_46).items).len = ((state_39).result).len;

                state_owned_62 = (try (state_capacity_46).toOwnedSlice(allocator));
            }

            if (state_capacity_started_47) {
                state_39 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_39).index, .result = state_owned_62, .source = (state_39).source, };
            }

            break :block_63 (state_39).result;
        };
    };
    const value_9: []const u64 = value_8;
    const value_10: *const zx_type_13 = block_38: {
        const operand_33 = value_9;
        const operand_34 = @as(u64, 0);
        const operand_35 = (in).count;

        break :block_38 block_37: {
            const operand_36 = (try (allocator).create(zx_type_13));

            (operand_36).* = @as(zx_type_13, zx_type_13{ .values = operand_33, .round = operand_34, .count = operand_35, });

            break :block_37 @as(*const zx_type_13, operand_36);
        };
    };
    const value_19: *const zx_type_13 = block_32: {
        const operand_8 = value_10;

        var state_items_10: []u64 = undefined;

        var state_items_started_11 = false;

        var state_7: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (operand_8).count, .round = (operand_8).round, .values = (operand_8).values, .zx_origin = operand_8, };

        var state_changed_9 = false;

        while (((state_7).round < (state_7).count)) {
            state_7 = block_28: {
                const value_13: []const u64 = (state_7).values;
                const value_14: u64 = @as(u64, 0);
                const value_15: u64 = block_27: {
                    const operand_25 = block_23: {
                        break :block_23 value_13;
                    };
                    const operand_26 = block_24: {
                        break :block_24 value_14;
                    };

                    if ((operand_26 >= (operand_25).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_27 (operand_25)[@intCast(operand_26)];
                };
                const value_16: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_22: {
                    break :block_22 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (state_7).count, .round = (state_7).round, .values = block_21: {
                        const operand_15 = block_14: {
                            break :block_14 value_13;
                        };
                        const operand_17 = block_16: {
                            break :block_16 value_14;
                        };

                        if ((operand_17 >= (operand_15).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_19 = (block_18: {
                            break :block_18 value_15;
                        } + @as(u64, 1));

                        break :block_21 block_20: {
                            if ((!state_items_started_11)) {
                                state_items_10 = (try (allocator).dupe(u64, operand_15));

                                state_items_started_11 = true;
                            }

                            (state_items_10)[@intCast(operand_17)] = operand_19;

                            break :block_20 state_items_10;
                        };
                    }, });
                };
                const value_17: u64 = (value_16).round;
                const value_18: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_13: {
                    break :block_13 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (value_16).count, .round = (block_12: {
                        break :block_12 value_17;
                    } + @as(u64, 1)), .values = (value_16).values, });
                };

                break :block_28 value_18;
            };

            state_changed_9 = true;
        }

        break :block_32 (if (state_changed_9) block_31: {
            break :block_31 (if (((state_7).zx_origin != null)) (state_7).zx_origin.? else block_30: {
                const operand_29 = (try (allocator).create(zx_type_13));

                (operand_29).* = zx_type_13{ .count = (state_7).count, .round = (state_7).round, .values = (state_7).values, };

                break :block_30 @as(*const zx_type_13, operand_29);
            });
        } else operand_8);
    };

    return block_6: {
        const operand_2 = (in).values;
        const operand_3 = (value_19).values;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create(zx_type_14));

            (operand_4).* = @as(zx_type_14, zx_type_14{ .original = operand_2, .values = operand_3, });

            break :block_5 @as(*const zx_type_14, operand_4);
        };
    };
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_8: []const u64 = block_125: {
        const value_2: []const u64 = (in).values;

        break :block_125 block_124: {
            const operand_106 = block_105: {
                const operand_100 = block_101: {
                    break :block_101 value_2;
                };
                const operand_102 = @as(u64, 0);
                const operand_103 = block_104: {
                    break :block_104 (try (allocator).dupe(u64, (&[_]u64{})));
                };

                break :block_105 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_102, .result = operand_103, .source = operand_100, });
            };

            var state_capacity_107: (std).ArrayList(u64) = .empty;

            var state_capacity_started_108 = false;

            defer (state_capacity_107).deinit(allocator);

            var state_99: value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_106;

            while (((state_99).index < @as(u64, ((state_99).source).len))) {
                state_99 = block_122: {
                    const value_5: u64 = block_121: {
                        const operand_119 = (state_99).source;
                        const operand_120 = (state_99).index;

                        if ((operand_120 >= (operand_119).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_121 (operand_119)[@intCast(operand_120)];
                    };
                    const value_1: u64 = block_118: {
                        break :block_118 value_5;
                    };
                    const value_6: u64 = (block_117: {
                        break :block_117 value_1;
                    } + @as(u64, 1));

                    break :block_122 block_116: {
                        const operand_109 = (state_99).source;
                        const operand_110 = ((state_99).index + @as(u64, 1));
                        const operand_111 = (block_115: {
                            const operand_112 = (state_99).result;
                            const operand_114 = block_113: {
                                break :block_113 value_6;
                            };

                            _ = (try ((std).math).add(usize, (operand_112).len, 1));

                            if ((!state_capacity_started_108)) {
                                (try (state_capacity_107).ensureTotalCapacityPrecise(allocator, ((operand_106).source).len));

                                (try (state_capacity_107).appendSlice(allocator, operand_112));

                                state_capacity_started_108 = true;
                            } else {
                                ((state_capacity_107).items).len = (operand_112).len;
                            }

                            (try (state_capacity_107).append(allocator, operand_114));

                            break :block_115 @as(value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_107).items, {}, null, });
                        }).@"0";

                        break :block_116 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_110, .result = operand_111, .source = operand_109, });
                    };
                };
            }

            var state_owned_123: []const u64 = (&[_]u64{});

            errdefer (allocator).free(state_owned_123);

            if (state_capacity_started_108) {
                ((state_capacity_107).items).len = ((state_99).result).len;

                state_owned_123 = (try (state_capacity_107).toOwnedSlice(allocator));
            }

            if (state_capacity_started_108) {
                state_99 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_99).index, .result = state_owned_123, .source = (state_99).source, };
            }

            break :block_124 (state_99).result;
        };
    };
    const value_9: []const u64 = block_98: {
        break :block_98 value_8;
    };
    const value_10: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_97: {
        const operand_93 = block_94: {
            break :block_94 value_9;
        };
        const operand_95 = @as(u64, 0);
        const operand_96 = (in).count;

        break :block_97 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .values = operand_93, .round = operand_95, .count = operand_96, });
    };
    const value_19: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_92: {
        const operand_70 = value_10;

        var state_items_72: []u64 = undefined;

        var state_items_started_73 = false;

        var state_69: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_70;

        var state_changed_71 = false;

        while (((state_69).round < (state_69).count)) {
            state_69 = block_90: {
                const value_13: []const u64 = (state_69).values;
                const value_14: u64 = @as(u64, 0);
                const value_15: u64 = block_89: {
                    const operand_87 = block_85: {
                        break :block_85 value_13;
                    };
                    const operand_88 = block_86: {
                        break :block_86 value_14;
                    };

                    if ((operand_88 >= (operand_87).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_89 (operand_87)[@intCast(operand_88)];
                };
                const value_16: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_84: {
                    break :block_84 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (state_69).count, .round = (state_69).round, .values = block_83: {
                        const operand_77 = block_76: {
                            break :block_76 value_13;
                        };
                        const operand_79 = block_78: {
                            break :block_78 value_14;
                        };

                        if ((operand_79 >= (operand_77).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_81 = (block_80: {
                            break :block_80 value_15;
                        } + @as(u64, 1));

                        break :block_83 block_82: {
                            if ((!state_items_started_73)) {
                                state_items_72 = (try (allocator).dupe(u64, operand_77));

                                state_items_started_73 = true;
                            }

                            (state_items_72)[@intCast(operand_79)] = operand_81;

                            break :block_82 state_items_72;
                        };
                    }, });
                };
                const value_17: u64 = (value_16).round;
                const value_18: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_75: {
                    break :block_75 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (value_16).count, .round = (block_74: {
                        break :block_74 value_17;
                    } + @as(u64, 1)), .values = (value_16).values, });
                };

                break :block_90 value_18;
            };

            state_changed_71 = true;
        }

        break :block_92 (if (state_changed_71) state_69 else operand_70);
    };

    return block_68: {
        const operand_66 = (in).values;
        const operand_67 = (value_19).values;

        break :block_68 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .original = operand_66, .values = operand_67, });
    };
}

