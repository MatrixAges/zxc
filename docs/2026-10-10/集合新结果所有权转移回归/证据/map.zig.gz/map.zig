const std = @import("std");

const zx_type_12 = struct {
    count: u64,
    values: []const u64,
};

const zx_type_13 = struct {
    count: u64,
    round: u64,
    values: []const u64,
};

const zx_type_14 = struct {
    original: []const u64,
    values: []const u64,
};

const zx_type_15 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
};

const zx_type_16 = struct { []const u64, void, };

const value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    round: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    original: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_15 = null,
};

const value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_16, };

pub const Input = *const zx_type_12;

pub const State = *const zx_type_13;

pub const Output = *const zx_type_14;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .round = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .original = zx_shape_11, .values = zx_shape_11, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_11, .source = zx_shape_11, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_0, }, };

pub const input_shape = zx_shape_12;

pub const output_shape = zx_shape_14;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_12) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_14 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_8: *const zx_type_13 = block_64: {
        const operand_33 = block_59: {
            const value_2: []const u64 = (in).values;

            break :block_59 block_58: {
                const operand_40 = block_39: {
                    const operand_35 = value_2;
                    const operand_36 = @as(u64, 0);
                    const operand_37 = block_38: {
                        break :block_38 (try (allocator).dupe(u64, (&[_]u64{})));
                    };

                    break :block_39 zx_type_15{ .index = operand_36, .result = operand_37, .source = operand_35, };
                };

                var state_capacity_41: (std).ArrayList(u64) = .empty;

                var state_capacity_started_42 = false;

                defer (state_capacity_41).deinit(allocator);

                var state_34: value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_40).index, .result = (operand_40).result, .source = (operand_40).source, .zx_origin = (&operand_40), };

                while (((state_34).index < @as(u64, ((state_34).source).len))) {
                    state_34 = block_56: {
                        const value_5: u64 = block_55: {
                            const operand_53 = (state_34).source;
                            const operand_54 = (state_34).index;

                            if ((operand_54 >= (operand_53).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_55 (operand_53)[@intCast(operand_54)];
                        };
                        const value_1: u64 = block_52: {
                            break :block_52 value_5;
                        };
                        const value_6: u64 = (block_51: {
                            break :block_51 value_1;
                        } + @as(u64, 1));

                        break :block_56 block_50: {
                            const operand_43 = (state_34).source;
                            const operand_44 = ((state_34).index + @as(u64, 1));
                            const operand_45 = (block_49: {
                                const operand_46 = (state_34).result;
                                const operand_48 = block_47: {
                                    break :block_47 value_6;
                                };

                                _ = (try ((std).math).add(usize, (operand_46).len, 1));

                                if ((!state_capacity_started_42)) {
                                    (try (state_capacity_41).ensureTotalCapacityPrecise(allocator, ((operand_40).source).len));

                                    (try (state_capacity_41).appendSlice(allocator, operand_46));

                                    state_capacity_started_42 = true;
                                } else {
                                    ((state_capacity_41).items).len = (operand_46).len;
                                }

                                (try (state_capacity_41).append(allocator, operand_48));

                                break :block_49 @as(value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_41).items, {}, null, });
                            }).@"0";

                            break :block_50 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_44, .result = operand_45, .source = operand_43, });
                        };
                    };
                }

                var state_owned_57: []const u64 = (&[_]u64{});

                errdefer (allocator).free(state_owned_57);

                if (state_capacity_started_42) {
                    ((state_capacity_41).items).len = ((state_34).result).len;

                    state_owned_57 = (try (state_capacity_41).toOwnedSlice(allocator));
                }

                if (state_capacity_started_42) {
                    state_34 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_34).index, .result = state_owned_57, .source = (state_34).source, };
                }

                break :block_58 (state_34).result;
            };
        };
        const operand_60 = @as(u64, 0);
        const operand_61 = (in).count;

        break :block_64 block_63: {
            const operand_62 = (try (allocator).create(zx_type_13));

            (operand_62).* = @as(zx_type_13, zx_type_13{ .values = operand_33, .round = operand_60, .count = operand_61, });

            break :block_63 @as(*const zx_type_13, operand_62);
        };
    };
    const value_17: *const zx_type_13 = block_32: {
        const operand_8 = value_8;

        var state_items_10: []u64 = undefined;

        var state_items_started_11 = false;

        var state_7: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (operand_8).count, .round = (operand_8).round, .values = (operand_8).values, .zx_origin = operand_8, };

        var state_changed_9 = false;

        while (((state_7).round < (state_7).count)) {
            state_7 = block_28: {
                const value_11: []const u64 = (state_7).values;
                const value_12: u64 = @as(u64, 0);
                const value_13: u64 = block_27: {
                    const operand_25 = block_23: {
                        break :block_23 value_11;
                    };
                    const operand_26 = block_24: {
                        break :block_24 value_12;
                    };

                    if ((operand_26 >= (operand_25).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_27 (operand_25)[@intCast(operand_26)];
                };
                const value_14: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_22: {
                    break :block_22 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (state_7).count, .round = (state_7).round, .values = block_21: {
                        const operand_15 = block_14: {
                            break :block_14 value_11;
                        };
                        const operand_17 = block_16: {
                            break :block_16 value_12;
                        };

                        if ((operand_17 >= (operand_15).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_19 = (block_18: {
                            break :block_18 value_13;
                        } + @as(u64, 1));

                        break :block_21 block_20: {
                            if ((!state_items_started_11)) {
                                state_items_10 = (try (allocator).dupe(u64, operand_15));

                                state_items_started_11 = true;
                            }

                            (state_items_10)[@intCast(operand_17)] = operand_19;

                            break :block_20 state_items_10;
                        };
                    }, });
                };
                const value_15: u64 = (value_14).round;
                const value_16: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_13: {
                    break :block_13 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (value_14).count, .round = (block_12: {
                        break :block_12 value_15;
                    } + @as(u64, 1)), .values = (value_14).values, });
                };

                break :block_28 value_16;
            };

            state_changed_9 = true;
        }

        break :block_32 (if (state_changed_9) block_31: {
            break :block_31 (if (((state_7).zx_origin != null)) (state_7).zx_origin.? else block_30: {
                const operand_29 = (try (allocator).create(zx_type_13));

                (operand_29).* = zx_type_13{ .count = (state_7).count, .round = (state_7).round, .values = (state_7).values, };

                break :block_30 @as(*const zx_type_13, operand_29);
            });
        } else operand_8);
    };

    return block_6: {
        const operand_2 = (in).values;
        const operand_3 = (value_17).values;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create(zx_type_14));

            (operand_4).* = @as(zx_type_14, zx_type_14{ .original = operand_2, .values = operand_3, });

            break :block_5 @as(*const zx_type_14, operand_4);
        };
    };
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_8: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_123: {
        const operand_93 = block_120: {
            const value_2: []const u64 = (in).values;

            break :block_120 block_119: {
                const operand_101 = block_100: {
                    const operand_95 = block_96: {
                        break :block_96 value_2;
                    };
                    const operand_97 = @as(u64, 0);
                    const operand_98 = block_99: {
                        break :block_99 (try (allocator).dupe(u64, (&[_]u64{})));
                    };

                    break :block_100 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_97, .result = operand_98, .source = operand_95, });
                };

                var state_capacity_102: (std).ArrayList(u64) = .empty;

                var state_capacity_started_103 = false;

                defer (state_capacity_102).deinit(allocator);

                var state_94: value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_101;

                while (((state_94).index < @as(u64, ((state_94).source).len))) {
                    state_94 = block_117: {
                        const value_5: u64 = block_116: {
                            const operand_114 = (state_94).source;
                            const operand_115 = (state_94).index;

                            if ((operand_115 >= (operand_114).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_116 (operand_114)[@intCast(operand_115)];
                        };
                        const value_1: u64 = block_113: {
                            break :block_113 value_5;
                        };
                        const value_6: u64 = (block_112: {
                            break :block_112 value_1;
                        } + @as(u64, 1));

                        break :block_117 block_111: {
                            const operand_104 = (state_94).source;
                            const operand_105 = ((state_94).index + @as(u64, 1));
                            const operand_106 = (block_110: {
                                const operand_107 = (state_94).result;
                                const operand_109 = block_108: {
                                    break :block_108 value_6;
                                };

                                _ = (try ((std).math).add(usize, (operand_107).len, 1));

                                if ((!state_capacity_started_103)) {
                                    (try (state_capacity_102).ensureTotalCapacityPrecise(allocator, ((operand_101).source).len));

                                    (try (state_capacity_102).appendSlice(allocator, operand_107));

                                    state_capacity_started_103 = true;
                                } else {
                                    ((state_capacity_102).items).len = (operand_107).len;
                                }

                                (try (state_capacity_102).append(allocator, operand_109));

                                break :block_110 @as(value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_102).items, {}, null, });
                            }).@"0";

                            break :block_111 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_105, .result = operand_106, .source = operand_104, });
                        };
                    };
                }

                var state_owned_118: []const u64 = (&[_]u64{});

                errdefer (allocator).free(state_owned_118);

                if (state_capacity_started_103) {
                    ((state_capacity_102).items).len = ((state_94).result).len;

                    state_owned_118 = (try (state_capacity_102).toOwnedSlice(allocator));
                }

                if (state_capacity_started_103) {
                    state_94 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_94).index, .result = state_owned_118, .source = (state_94).source, };
                }

                break :block_119 (state_94).result;
            };
        };
        const operand_121 = @as(u64, 0);
        const operand_122 = (in).count;

        break :block_123 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .values = operand_93, .round = operand_121, .count = operand_122, });
    };
    const value_17: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_92: {
        const operand_70 = value_8;

        var state_items_72: []u64 = undefined;

        var state_items_started_73 = false;

        var state_69: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_70;

        var state_changed_71 = false;

        while (((state_69).round < (state_69).count)) {
            state_69 = block_90: {
                const value_11: []const u64 = (state_69).values;
                const value_12: u64 = @as(u64, 0);
                const value_13: u64 = block_89: {
                    const operand_87 = block_85: {
                        break :block_85 value_11;
                    };
                    const operand_88 = block_86: {
                        break :block_86 value_12;
                    };

                    if ((operand_88 >= (operand_87).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_89 (operand_87)[@intCast(operand_88)];
                };
                const value_14: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_84: {
                    break :block_84 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (state_69).count, .round = (state_69).round, .values = block_83: {
                        const operand_77 = block_76: {
                            break :block_76 value_11;
                        };
                        const operand_79 = block_78: {
                            break :block_78 value_12;
                        };

                        if ((operand_79 >= (operand_77).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_81 = (block_80: {
                            break :block_80 value_13;
                        } + @as(u64, 1));

                        break :block_83 block_82: {
                            if ((!state_items_started_73)) {
                                state_items_72 = (try (allocator).dupe(u64, operand_77));

                                state_items_started_73 = true;
                            }

                            (state_items_72)[@intCast(operand_79)] = operand_81;

                            break :block_82 state_items_72;
                        };
                    }, });
                };
                const value_15: u64 = (value_14).round;
                const value_16: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_75: {
                    break :block_75 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (value_14).count, .round = (block_74: {
                        break :block_74 value_15;
                    } + @as(u64, 1)), .values = (value_14).values, });
                };

                break :block_90 value_16;
            };

            state_changed_71 = true;
        }

        break :block_92 (if (state_changed_71) state_69 else operand_70);
    };

    return block_68: {
        const operand_66 = (in).values;
        const operand_67 = (value_17).values;

        break :block_68 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .original = operand_66, .values = operand_67, });
    };
}

