const std = @import("std");

const zx_type_12 = struct {
    count: u64,
    values: []const u64,
};

const zx_type_13 = struct { []const u64, u64, };

const zx_type_14 = struct {
    count: u64,
    pair: *const zx_type_13,
};

const zx_type_15 = struct {
    original: []const u64,
    values: []const u64,
};

const zx_type_16 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
};

const zx_type_17 = struct { []const u64, void, };

const value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, u64, ?*const zx_type_13, };

const value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    count: u64,
    pair: value_zx_type_13_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_15_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    original: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_15 = null,
};

const value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_16 = null,
};

const value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_17, };

pub const Input = *const zx_type_12;

pub const State = *const zx_type_14;

pub const Output = *const zx_type_15;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_5, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .pair = zx_shape_13, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .original = zx_shape_11, .values = zx_shape_11, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_11, .source = zx_shape_11, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_0, }, };

pub const input_shape = zx_shape_12;

pub const output_shape = zx_shape_15;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_12) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_15 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_8: *const zx_type_14 = block_68: {
        const operand_33 = block_64: {
            const operand_60 = block_59: {
                const value_2: []const u64 = (in).values;

                break :block_59 block_58: {
                    const operand_40 = block_39: {
                        const operand_35 = value_2;
                        const operand_36 = @as(u64, 0);
                        const operand_37 = block_38: {
                            break :block_38 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_39 zx_type_16{ .index = operand_36, .result = operand_37, .source = operand_35, };
                    };

                    var state_capacity_41: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_42 = false;

                    defer (state_capacity_41).deinit(allocator);

                    var state_34: value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_40).index, .result = (operand_40).result, .source = (operand_40).source, .zx_origin = (&operand_40), };

                    while (((state_34).index < @as(u64, ((state_34).source).len))) {
                        state_34 = block_56: {
                            const value_5: u64 = block_55: {
                                const operand_53 = (state_34).source;
                                const operand_54 = (state_34).index;

                                if ((operand_54 >= (operand_53).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_55 (operand_53)[@intCast(operand_54)];
                            };
                            const value_1: u64 = block_52: {
                                break :block_52 value_5;
                            };
                            const value_6: u64 = (block_51: {
                                break :block_51 value_1;
                            } + @as(u64, 1));

                            break :block_56 block_50: {
                                const operand_43 = (state_34).source;
                                const operand_44 = ((state_34).index + @as(u64, 1));
                                const operand_45 = (block_49: {
                                    const operand_46 = (state_34).result;
                                    const operand_48 = block_47: {
                                        break :block_47 value_6;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_46).len, 1));

                                    if ((!state_capacity_started_42)) {
                                        (try (state_capacity_41).ensureTotalCapacityPrecise(allocator, ((operand_40).source).len));

                                        (try (state_capacity_41).appendSlice(allocator, operand_46));

                                        state_capacity_started_42 = true;
                                    } else {
                                        ((state_capacity_41).items).len = (operand_46).len;
                                    }

                                    (try (state_capacity_41).append(allocator, operand_48));

                                    break :block_49 @as(value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_41).items, {}, null, });
                                }).@"0";

                                break :block_50 @as(value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_44, .result = operand_45, .source = operand_43, });
                            };
                        };
                    }

                    var state_owned_57: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_57);

                    if (state_capacity_started_42) {
                        ((state_capacity_41).items).len = ((state_34).result).len;

                        state_owned_57 = (try (state_capacity_41).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_42) {
                        state_34 = value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_34).index, .result = state_owned_57, .source = (state_34).source, };
                    }

                    break :block_58 (state_34).result;
                };
            };
            const operand_61 = @as(u64, 0);

            break :block_64 block_63: {
                const operand_62 = (try (allocator).create(zx_type_13));

                (operand_62).* = @as(zx_type_13, .{ operand_60, operand_61, });

                break :block_63 @as(*const zx_type_13, operand_62);
            };
        };
        const operand_65 = (in).count;

        break :block_68 block_67: {
            const operand_66 = (try (allocator).create(zx_type_14));

            (operand_66).* = @as(zx_type_14, zx_type_14{ .pair = operand_33, .count = operand_65, });

            break :block_67 @as(*const zx_type_14, operand_66);
        };
    };

    return block_32: {
        const state_type_3 = struct { []const u64, u64, };
        const state_type_4 = struct {
            count: u64,
            pair: state_type_3,
        };
        const operand_6 = block_5: {
            const operand_2 = value_8;

            break :block_5 state_type_4{ .count = (operand_2).count, .pair = @as(state_type_3, .{ ((operand_2).pair).@"0", ((operand_2).pair).@"1", }), };
        };

        var state_items_8: []u64 = undefined;

        var state_items_started_9 = false;

        var state_1: state_type_4 = operand_6;

        var state_changed_7 = false;

        while ((((state_1).pair).@"1" < (state_1).count)) {
            state_1 = block_26: {
                const value_11: []const u64 = ((state_1).pair).@"0";
                const value_12: u64 = @as(u64, 0);
                const value_13: u64 = block_25: {
                    const operand_23 = value_11;
                    const operand_24 = value_12;

                    if ((operand_24 >= (operand_23).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_25 (operand_23)[@intCast(operand_24)];
                };
                const value_14: state_type_4 = block_22: {
                    break :block_22 state_type_4{ .count = (state_1).count, .pair = block_21: {
                        const operand_19 = block_18: {
                            const operand_14 = value_11;
                            const operand_15 = value_12;

                            if ((operand_15 >= (operand_14).len)) {
                                return error.IndexOutOfBounds;
                            }

                            const operand_16 = (value_13 + @as(u64, 1));

                            break :block_18 block_17: {
                                if ((!state_items_started_9)) {
                                    state_items_8 = (try (allocator).dupe(u64, operand_14));

                                    state_items_started_9 = true;
                                }

                                (state_items_8)[@intCast(operand_15)] = operand_16;

                                break :block_17 state_items_8;
                            };
                        };
                        const operand_20 = ((state_1).pair).@"1";

                        break :block_21 @as(state_type_3, .{ operand_19, operand_20, });
                    }, };
                };
                const value_15: u64 = ((value_14).pair).@"1";
                const value_16: state_type_4 = block_13: {
                    break :block_13 state_type_4{ .count = (value_14).count, .pair = block_12: {
                        const operand_10 = ((value_14).pair).@"0";
                        const operand_11 = (value_15 + @as(u64, 1));

                        break :block_12 @as(state_type_3, .{ operand_10, operand_11, });
                    }, };
                };

                break :block_26 value_16;
            };

            state_changed_7 = true;
        }

        break :block_32 block_31: {
            const operand_27 = (in).values;
            const operand_28 = ((state_1).pair).@"0";

            break :block_31 block_30: {
                const operand_29 = (try (allocator).create(zx_type_15));

                (operand_29).* = @as(zx_type_15, zx_type_15{ .original = operand_27, .values = operand_28, });

                break :block_30 @as(*const zx_type_15, operand_29);
            };
        };
    };
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_15_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_8: value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = block_135: {
        const operand_103 = block_133: {
            const operand_131 = block_130: {
                const value_2: []const u64 = (in).values;

                break :block_130 block_129: {
                    const operand_111 = block_110: {
                        const operand_105 = block_106: {
                            break :block_106 value_2;
                        };
                        const operand_107 = @as(u64, 0);
                        const operand_108 = block_109: {
                            break :block_109 (try (allocator).dupe(u64, (&[_]u64{})));
                        };

                        break :block_110 @as(value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_107, .result = operand_108, .source = operand_105, });
                    };

                    var state_capacity_112: (std).ArrayList(u64) = .empty;

                    var state_capacity_started_113 = false;

                    defer (state_capacity_112).deinit(allocator);

                    var state_104: value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_111;

                    while (((state_104).index < @as(u64, ((state_104).source).len))) {
                        state_104 = block_127: {
                            const value_5: u64 = block_126: {
                                const operand_124 = (state_104).source;
                                const operand_125 = (state_104).index;

                                if ((operand_125 >= (operand_124).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_126 (operand_124)[@intCast(operand_125)];
                            };
                            const value_1: u64 = block_123: {
                                break :block_123 value_5;
                            };
                            const value_6: u64 = (block_122: {
                                break :block_122 value_1;
                            } + @as(u64, 1));

                            break :block_127 block_121: {
                                const operand_114 = (state_104).source;
                                const operand_115 = ((state_104).index + @as(u64, 1));
                                const operand_116 = (block_120: {
                                    const operand_117 = (state_104).result;
                                    const operand_119 = block_118: {
                                        break :block_118 value_6;
                                    };

                                    _ = (try ((std).math).add(usize, (operand_117).len, 1));

                                    if ((!state_capacity_started_113)) {
                                        (try (state_capacity_112).ensureTotalCapacityPrecise(allocator, ((operand_111).source).len));

                                        (try (state_capacity_112).appendSlice(allocator, operand_117));

                                        state_capacity_started_113 = true;
                                    } else {
                                        ((state_capacity_112).items).len = (operand_117).len;
                                    }

                                    (try (state_capacity_112).append(allocator, operand_119));

                                    break :block_120 @as(value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_112).items, {}, null, });
                                }).@"0";

                                break :block_121 @as(value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_115, .result = operand_116, .source = operand_114, });
                            };
                        };
                    }

                    var state_owned_128: []const u64 = (&[_]u64{});

                    errdefer (allocator).free(state_owned_128);

                    if (state_capacity_started_113) {
                        ((state_capacity_112).items).len = ((state_104).result).len;

                        state_owned_128 = (try (state_capacity_112).toOwnedSlice(allocator));
                    }

                    if (state_capacity_started_113) {
                        state_104 = value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_104).index, .result = state_owned_128, .source = (state_104).source, };
                    }

                    break :block_129 (state_104).result;
                };
            };
            const operand_132 = @as(u64, 0);

            break :block_133 @as(value_zx_type_13_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_131, operand_132, null, });
        };
        const operand_134 = (in).count;

        break :block_135 @as(value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec, value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec{ .pair = operand_103, .count = operand_134, });
    };
    const value_17: value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = block_102: {
        const operand_74 = value_8;

        var state_items_76: []u64 = undefined;

        var state_items_started_77 = false;

        var state_73: value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = operand_74;

        var state_changed_75 = false;

        while ((((state_73).pair).@"1" < (state_73).count)) {
            state_73 = block_100: {
                const value_11: []const u64 = ((state_73).pair).@"0";
                const value_12: u64 = @as(u64, 0);
                const value_13: u64 = block_99: {
                    const operand_97 = block_95: {
                        break :block_95 value_11;
                    };
                    const operand_98 = block_96: {
                        break :block_96 value_12;
                    };

                    if ((operand_98 >= (operand_97).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_99 (operand_97)[@intCast(operand_98)];
                };
                const value_14: value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = block_94: {
                    break :block_94 @as(value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec, value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec{ .count = (state_73).count, .pair = block_93: {
                        const operand_91 = block_90: {
                            const operand_84 = block_83: {
                                break :block_83 value_11;
                            };
                            const operand_86 = block_85: {
                                break :block_85 value_12;
                            };

                            if ((operand_86 >= (operand_84).len)) {
                                return error.IndexOutOfBounds;
                            }

                            const operand_88 = (block_87: {
                                break :block_87 value_13;
                            } + @as(u64, 1));

                            break :block_90 block_89: {
                                if ((!state_items_started_77)) {
                                    state_items_76 = (try (allocator).dupe(u64, operand_84));

                                    state_items_started_77 = true;
                                }

                                (state_items_76)[@intCast(operand_86)] = operand_88;

                                break :block_89 state_items_76;
                            };
                        };
                        const operand_92 = ((state_73).pair).@"1";

                        break :block_93 @as(value_zx_type_13_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_91, operand_92, null, });
                    }, });
                };
                const value_15: u64 = ((value_14).pair).@"1";
                const value_16: value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = block_82: {
                    break :block_82 @as(value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec, value_zx_type_14_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec{ .count = (value_14).count, .pair = block_81: {
                        const operand_78 = ((value_14).pair).@"0";
                        const operand_80 = (block_79: {
                            break :block_79 value_15;
                        } + @as(u64, 1));

                        break :block_81 @as(value_zx_type_13_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_78, operand_80, null, });
                    }, });
                };

                break :block_100 value_16;
            };

            state_changed_75 = true;
        }

        break :block_102 (if (state_changed_75) state_73 else operand_74);
    };

    return block_72: {
        const operand_70 = (in).values;
        const operand_71 = ((value_17).pair).@"0";

        break :block_72 @as(value_zx_type_15_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_15_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .original = operand_70, .values = operand_71, });
    };
}

