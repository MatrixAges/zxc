const std = @import("std");

const zx_type_12 = struct {
    count: u64,
    values: []const u64,
};

const zx_type_13 = struct {
    count: u64,
    fresh: []const u64,
    round: u64,
    values: []const u64,
};

const zx_type_14 = struct {
    original: []const u64,
    values: []const u64,
};

const zx_type_15 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
};

const zx_type_16 = struct { []const u64, void, };

const zx_type_17 = struct {
    round: u64,
    values: []const u64,
};

const value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    fresh: []const u64,
    round: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    original: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_15 = null,
};

const value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_16, };

const value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    round: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_17 = null,
};

pub const Input = *const zx_type_12;

pub const State = *const zx_type_13;

pub const Output = *const zx_type_14;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .fresh = zx_shape_11, .round = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .original = zx_shape_11, .values = zx_shape_11, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_11, .source = zx_shape_11, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_0, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .round = zx_shape_5, .values = zx_shape_11, }, };

pub const input_shape = zx_shape_12;

pub const output_shape = zx_shape_14;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_12) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_14 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_8: []const u64 = block_77: {
        const value_2: []const u64 = (in).values;

        break :block_77 block_76: {
            const operand_58 = block_57: {
                const operand_53 = value_2;
                const operand_54 = @as(u64, 0);
                const operand_55 = block_56: {
                    break :block_56 (try (allocator).dupe(u64, (&[_]u64{})));
                };

                break :block_57 zx_type_15{ .index = operand_54, .result = operand_55, .source = operand_53, };
            };

            var state_capacity_59: (std).ArrayList(u64) = .empty;

            var state_capacity_started_60 = false;

            defer (state_capacity_59).deinit(allocator);

            var state_52: value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_58).index, .result = (operand_58).result, .source = (operand_58).source, .zx_origin = (&operand_58), };

            while (((state_52).index < @as(u64, ((state_52).source).len))) {
                state_52 = block_74: {
                    const value_5: u64 = block_73: {
                        const operand_71 = (state_52).source;
                        const operand_72 = (state_52).index;

                        if ((operand_72 >= (operand_71).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_73 (operand_71)[@intCast(operand_72)];
                    };
                    const value_1: u64 = block_70: {
                        break :block_70 value_5;
                    };
                    const value_6: u64 = (block_69: {
                        break :block_69 value_1;
                    } + @as(u64, 1));

                    break :block_74 block_68: {
                        const operand_61 = (state_52).source;
                        const operand_62 = ((state_52).index + @as(u64, 1));
                        const operand_63 = (block_67: {
                            const operand_64 = (state_52).result;
                            const operand_66 = block_65: {
                                break :block_65 value_6;
                            };

                            _ = (try ((std).math).add(usize, (operand_64).len, 1));

                            if ((!state_capacity_started_60)) {
                                (try (state_capacity_59).ensureTotalCapacityPrecise(allocator, ((operand_58).source).len));

                                (try (state_capacity_59).appendSlice(allocator, operand_64));

                                state_capacity_started_60 = true;
                            } else {
                                ((state_capacity_59).items).len = (operand_64).len;
                            }

                            (try (state_capacity_59).append(allocator, operand_66));

                            break :block_67 @as(value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_59).items, {}, null, });
                        }).@"0";

                        break :block_68 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_62, .result = operand_63, .source = operand_61, });
                    };
                };
            }

            var state_owned_75: []const u64 = (&[_]u64{});

            errdefer (allocator).free(state_owned_75);

            if (state_capacity_started_60) {
                ((state_capacity_59).items).len = ((state_52).result).len;

                state_owned_75 = (try (state_capacity_59).toOwnedSlice(allocator));
            }

            if (state_capacity_started_60) {
                state_52 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_52).index, .result = state_owned_75, .source = (state_52).source, };
            }

            break :block_76 (state_52).result;
        };
    };
    const value_9: *const zx_type_13 = block_51: {
        const operand_45 = (in).values;
        const operand_46 = value_8;
        const operand_47 = @as(u64, 0);
        const operand_48 = (in).count;

        break :block_51 block_50: {
            const operand_49 = (try (allocator).create(zx_type_13));

            (operand_49).* = @as(zx_type_13, zx_type_13{ .values = operand_45, .fresh = operand_46, .round = operand_47, .count = operand_48, });

            break :block_50 @as(*const zx_type_13, operand_49);
        };
    };
    const value_24: *const zx_type_13 = block_44: {
        const operand_8 = value_9;

        var state_7: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (operand_8).count, .fresh = (operand_8).fresh, .round = (operand_8).round, .values = (operand_8).values, .zx_origin = operand_8, };

        var state_changed_9 = false;

        while (((state_7).round < (state_7).count)) {
            state_7 = block_40: {
                const value_20: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_39: {
                    const operand_17 = block_16: {
                        const operand_14 = (state_7).fresh;
                        const operand_15 = @as(u64, 0);

                        break :block_16 @as(value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .values = operand_14, .round = operand_15, });
                    };

                    var state_items_19: []u64 = undefined;

                    var state_items_started_20 = false;

                    var state_13: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = operand_17;

                    var state_changed_18 = false;

                    while (((state_13).round < @as(u64, 3))) {
                        state_13 = block_37: {
                            const value_14: []const u64 = (state_13).values;
                            const value_15: u64 = @as(u64, 0);
                            const value_16: u64 = block_36: {
                                const operand_34 = block_32: {
                                    break :block_32 value_14;
                                };
                                const operand_35 = block_33: {
                                    break :block_33 value_15;
                                };

                                if ((operand_35 >= (operand_34).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_36 (operand_34)[@intCast(operand_35)];
                            };
                            const value_17: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_31: {
                                break :block_31 @as(value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .round = (state_13).round, .values = block_30: {
                                    const operand_24 = block_23: {
                                        break :block_23 value_14;
                                    };
                                    const operand_26 = block_25: {
                                        break :block_25 value_15;
                                    };

                                    if ((operand_26 >= (operand_24).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    const operand_28 = (block_27: {
                                        break :block_27 value_16;
                                    } + @as(u64, 1));

                                    break :block_30 block_29: {
                                        if ((!state_items_started_20)) {
                                            state_items_19 = (try (allocator).dupe(u64, operand_24));

                                            state_items_started_20 = true;
                                        }

                                        (state_items_19)[@intCast(operand_26)] = operand_28;

                                        break :block_29 state_items_19;
                                    };
                                }, });
                            };
                            const value_18: u64 = (value_17).round;
                            const value_19: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_22: {
                                break :block_22 @as(value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .round = (block_21: {
                                    break :block_21 value_18;
                                } + @as(u64, 1)), .values = (value_17).values, });
                            };

                            break :block_37 value_19;
                        };

                        state_changed_18 = true;
                    }

                    break :block_39 (if (state_changed_18) state_13 else operand_17);
                };
                const value_21: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_12: {
                    break :block_12 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (state_7).count, .fresh = (state_7).fresh, .round = (state_7).round, .values = (value_20).values, });
                };
                const value_22: u64 = (value_21).round;
                const value_23: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_11: {
                    break :block_11 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (value_21).count, .fresh = (value_21).fresh, .round = (block_10: {
                        break :block_10 value_22;
                    } + @as(u64, 1)), .values = (value_21).values, });
                };

                break :block_40 value_23;
            };

            state_changed_9 = true;
        }

        break :block_44 (if (state_changed_9) block_43: {
            break :block_43 (if (((state_7).zx_origin != null)) (state_7).zx_origin.? else block_42: {
                const operand_41 = (try (allocator).create(zx_type_13));

                (operand_41).* = zx_type_13{ .count = (state_7).count, .fresh = (state_7).fresh, .round = (state_7).round, .values = (state_7).values, };

                break :block_42 @as(*const zx_type_13, operand_41);
            });
        } else operand_8);
    };

    return block_6: {
        const operand_2 = (in).values;
        const operand_3 = (value_24).values;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create(zx_type_14));

            (operand_4).* = @as(zx_type_14, zx_type_14{ .original = operand_2, .values = operand_3, });

            break :block_5 @as(*const zx_type_14, operand_4);
        };
    };
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_8: []const u64 = block_150: {
        const value_2: []const u64 = (in).values;

        break :block_150 block_149: {
            const operand_131 = block_130: {
                const operand_125 = block_126: {
                    break :block_126 value_2;
                };
                const operand_127 = @as(u64, 0);
                const operand_128 = block_129: {
                    break :block_129 (try (allocator).dupe(u64, (&[_]u64{})));
                };

                break :block_130 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_127, .result = operand_128, .source = operand_125, });
            };

            var state_capacity_132: (std).ArrayList(u64) = .empty;

            var state_capacity_started_133 = false;

            defer (state_capacity_132).deinit(allocator);

            var state_124: value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_131;

            while (((state_124).index < @as(u64, ((state_124).source).len))) {
                state_124 = block_147: {
                    const value_5: u64 = block_146: {
                        const operand_144 = (state_124).source;
                        const operand_145 = (state_124).index;

                        if ((operand_145 >= (operand_144).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_146 (operand_144)[@intCast(operand_145)];
                    };
                    const value_1: u64 = block_143: {
                        break :block_143 value_5;
                    };
                    const value_6: u64 = (block_142: {
                        break :block_142 value_1;
                    } + @as(u64, 1));

                    break :block_147 block_141: {
                        const operand_134 = (state_124).source;
                        const operand_135 = ((state_124).index + @as(u64, 1));
                        const operand_136 = (block_140: {
                            const operand_137 = (state_124).result;
                            const operand_139 = block_138: {
                                break :block_138 value_6;
                            };

                            _ = (try ((std).math).add(usize, (operand_137).len, 1));

                            if ((!state_capacity_started_133)) {
                                (try (state_capacity_132).ensureTotalCapacityPrecise(allocator, ((operand_131).source).len));

                                (try (state_capacity_132).appendSlice(allocator, operand_137));

                                state_capacity_started_133 = true;
                            } else {
                                ((state_capacity_132).items).len = (operand_137).len;
                            }

                            (try (state_capacity_132).append(allocator, operand_139));

                            break :block_140 @as(value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_132).items, {}, null, });
                        }).@"0";

                        break :block_141 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_135, .result = operand_136, .source = operand_134, });
                    };
                };
            }

            var state_owned_148: []const u64 = (&[_]u64{});

            errdefer (allocator).free(state_owned_148);

            if (state_capacity_started_133) {
                ((state_capacity_132).items).len = ((state_124).result).len;

                state_owned_148 = (try (state_capacity_132).toOwnedSlice(allocator));
            }

            if (state_capacity_started_133) {
                state_124 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_124).index, .result = state_owned_148, .source = (state_124).source, };
            }

            break :block_149 (state_124).result;
        };
    };
    const value_9: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_123: {
        const operand_118 = (in).values;
        const operand_119 = block_120: {
            break :block_120 value_8;
        };
        const operand_121 = @as(u64, 0);
        const operand_122 = (in).count;

        break :block_123 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .values = operand_118, .fresh = operand_119, .round = operand_121, .count = operand_122, });
    };
    const value_24: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_117: {
        const operand_83 = value_9;

        var state_82: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = operand_83;

        var state_changed_84 = false;

        while (((state_82).round < (state_82).count)) {
            state_82 = block_115: {
                const value_20: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_114: {
                    const operand_92 = block_91: {
                        const operand_89 = (state_82).fresh;
                        const operand_90 = @as(u64, 0);

                        break :block_91 @as(value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .values = operand_89, .round = operand_90, });
                    };

                    var state_items_94: []u64 = undefined;

                    var state_items_started_95 = false;

                    var state_88: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = operand_92;

                    var state_changed_93 = false;

                    while (((state_88).round < @as(u64, 3))) {
                        state_88 = block_112: {
                            const value_14: []const u64 = (state_88).values;
                            const value_15: u64 = @as(u64, 0);
                            const value_16: u64 = block_111: {
                                const operand_109 = block_107: {
                                    break :block_107 value_14;
                                };
                                const operand_110 = block_108: {
                                    break :block_108 value_15;
                                };

                                if ((operand_110 >= (operand_109).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_111 (operand_109)[@intCast(operand_110)];
                            };
                            const value_17: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_106: {
                                break :block_106 @as(value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .round = (state_88).round, .values = block_105: {
                                    const operand_99 = block_98: {
                                        break :block_98 value_14;
                                    };
                                    const operand_101 = block_100: {
                                        break :block_100 value_15;
                                    };

                                    if ((operand_101 >= (operand_99).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    const operand_103 = (block_102: {
                                        break :block_102 value_16;
                                    } + @as(u64, 1));

                                    break :block_105 block_104: {
                                        if ((!state_items_started_95)) {
                                            state_items_94 = (try (allocator).dupe(u64, operand_99));

                                            state_items_started_95 = true;
                                        }

                                        (state_items_94)[@intCast(operand_101)] = operand_103;

                                        break :block_104 state_items_94;
                                    };
                                }, });
                            };
                            const value_18: u64 = (value_17).round;
                            const value_19: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_97: {
                                break :block_97 @as(value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .round = (block_96: {
                                    break :block_96 value_18;
                                } + @as(u64, 1)), .values = (value_17).values, });
                            };

                            break :block_112 value_19;
                        };

                        state_changed_93 = true;
                    }

                    break :block_114 (if (state_changed_93) state_88 else operand_92);
                };
                const value_21: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_87: {
                    break :block_87 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (state_82).count, .fresh = (state_82).fresh, .round = (state_82).round, .values = (value_20).values, });
                };
                const value_22: u64 = (value_21).round;
                const value_23: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_86: {
                    break :block_86 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (value_21).count, .fresh = (value_21).fresh, .round = (block_85: {
                        break :block_85 value_22;
                    } + @as(u64, 1)), .values = (value_21).values, });
                };

                break :block_115 value_23;
            };

            state_changed_84 = true;
        }

        break :block_117 (if (state_changed_84) state_82 else operand_83);
    };

    return block_81: {
        const operand_79 = (in).values;
        const operand_80 = (value_24).values;

        break :block_81 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .original = operand_79, .values = operand_80, });
    };
}

