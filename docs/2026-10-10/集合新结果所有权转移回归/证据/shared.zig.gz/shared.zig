const std = @import("std");

const zx_type_12 = struct {
    count: u64,
    values: []const u64,
};

const zx_type_13 = struct {
    count: u64,
    original: []const u64,
    round: u64,
    values: []const u64,
};

const zx_type_14 = struct {
    original: []const u64,
    values: []const u64,
};

const zx_type_15 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
};

const zx_type_16 = struct { []const u64, void, };

const value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    original: []const u64,
    round: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    original: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_15 = null,
};

const value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_16, };

pub const Input = *const zx_type_12;

pub const State = *const zx_type_13;

pub const Output = *const zx_type_14;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .original = zx_shape_11, .round = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .original = zx_shape_11, .values = zx_shape_11, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_11, .source = zx_shape_11, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_0, }, };

pub const input_shape = zx_shape_12;

pub const output_shape = zx_shape_14;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_12) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_14 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_8: []const u64 = block_65: {
        const value_2: []const u64 = (in).values;

        break :block_65 block_64: {
            const operand_46 = block_45: {
                const operand_41 = value_2;
                const operand_42 = @as(u64, 0);
                const operand_43 = block_44: {
                    break :block_44 (try (allocator).dupe(u64, (&[_]u64{})));
                };

                break :block_45 zx_type_15{ .index = operand_42, .result = operand_43, .source = operand_41, };
            };

            var state_capacity_47: (std).ArrayList(u64) = .empty;

            var state_capacity_started_48 = false;

            defer (state_capacity_47).deinit(allocator);

            var state_40: value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_46).index, .result = (operand_46).result, .source = (operand_46).source, .zx_origin = (&operand_46), };

            while (((state_40).index < @as(u64, ((state_40).source).len))) {
                state_40 = block_62: {
                    const value_5: u64 = block_61: {
                        const operand_59 = (state_40).source;
                        const operand_60 = (state_40).index;

                        if ((operand_60 >= (operand_59).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_61 (operand_59)[@intCast(operand_60)];
                    };
                    const value_1: u64 = block_58: {
                        break :block_58 value_5;
                    };
                    const value_6: u64 = (block_57: {
                        break :block_57 value_1;
                    } + @as(u64, 1));

                    break :block_62 block_56: {
                        const operand_49 = (state_40).source;
                        const operand_50 = ((state_40).index + @as(u64, 1));
                        const operand_51 = (block_55: {
                            const operand_52 = (state_40).result;
                            const operand_54 = block_53: {
                                break :block_53 value_6;
                            };

                            _ = (try ((std).math).add(usize, (operand_52).len, 1));

                            if ((!state_capacity_started_48)) {
                                (try (state_capacity_47).ensureTotalCapacityPrecise(allocator, ((operand_46).source).len));

                                (try (state_capacity_47).appendSlice(allocator, operand_52));

                                state_capacity_started_48 = true;
                            } else {
                                ((state_capacity_47).items).len = (operand_52).len;
                            }

                            (try (state_capacity_47).append(allocator, operand_54));

                            break :block_55 @as(value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_47).items, {}, null, });
                        }).@"0";

                        break :block_56 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_50, .result = operand_51, .source = operand_49, });
                    };
                };
            }

            var state_owned_63: []const u64 = (&[_]u64{});

            errdefer (allocator).free(state_owned_63);

            if (state_capacity_started_48) {
                ((state_capacity_47).items).len = ((state_40).result).len;

                state_owned_63 = (try (state_capacity_47).toOwnedSlice(allocator));
            }

            if (state_capacity_started_48) {
                state_40 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_40).index, .result = state_owned_63, .source = (state_40).source, };
            }

            break :block_64 (state_40).result;
        };
    };
    const value_9: *const zx_type_13 = block_39: {
        const operand_33 = value_8;
        const operand_34 = @as(u64, 0);
        const operand_35 = (in).count;
        const operand_36 = value_8;

        break :block_39 block_38: {
            const operand_37 = (try (allocator).create(zx_type_13));

            (operand_37).* = @as(zx_type_13, zx_type_13{ .values = operand_33, .round = operand_34, .count = operand_35, .original = operand_36, });

            break :block_38 @as(*const zx_type_13, operand_37);
        };
    };
    const value_18: *const zx_type_13 = block_32: {
        const operand_8 = value_9;

        var state_items_10: []u64 = undefined;

        var state_items_started_11 = false;

        var state_7: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (operand_8).count, .original = (operand_8).original, .round = (operand_8).round, .values = (operand_8).values, .zx_origin = operand_8, };

        var state_changed_9 = false;

        while (((state_7).round < (state_7).count)) {
            state_7 = block_28: {
                const value_12: []const u64 = (state_7).values;
                const value_13: u64 = @as(u64, 0);
                const value_14: u64 = block_27: {
                    const operand_25 = block_23: {
                        break :block_23 value_12;
                    };
                    const operand_26 = block_24: {
                        break :block_24 value_13;
                    };

                    if ((operand_26 >= (operand_25).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_27 (operand_25)[@intCast(operand_26)];
                };
                const value_15: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_22: {
                    break :block_22 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (state_7).count, .original = (state_7).original, .round = (state_7).round, .values = block_21: {
                        const operand_15 = block_14: {
                            break :block_14 value_12;
                        };
                        const operand_17 = block_16: {
                            break :block_16 value_13;
                        };

                        if ((operand_17 >= (operand_15).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_19 = (block_18: {
                            break :block_18 value_14;
                        } + @as(u64, 1));

                        break :block_21 block_20: {
                            if ((!state_items_started_11)) {
                                state_items_10 = (try (allocator).dupe(u64, operand_15));

                                state_items_started_11 = true;
                            }

                            (state_items_10)[@intCast(operand_17)] = operand_19;

                            break :block_20 state_items_10;
                        };
                    }, });
                };
                const value_16: u64 = (value_15).round;
                const value_17: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_13: {
                    break :block_13 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (value_15).count, .original = (value_15).original, .round = (block_12: {
                        break :block_12 value_16;
                    } + @as(u64, 1)), .values = (value_15).values, });
                };

                break :block_28 value_17;
            };

            state_changed_9 = true;
        }

        break :block_32 (if (state_changed_9) block_31: {
            break :block_31 (if (((state_7).zx_origin != null)) (state_7).zx_origin.? else block_30: {
                const operand_29 = (try (allocator).create(zx_type_13));

                (operand_29).* = zx_type_13{ .count = (state_7).count, .original = (state_7).original, .round = (state_7).round, .values = (state_7).values, };

                break :block_30 @as(*const zx_type_13, operand_29);
            });
        } else operand_8);
    };

    return block_6: {
        const operand_2 = (value_18).original;
        const operand_3 = (value_18).values;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create(zx_type_14));

            (operand_4).* = @as(zx_type_14, zx_type_14{ .original = operand_2, .values = operand_3, });

            break :block_5 @as(*const zx_type_14, operand_4);
        };
    };
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_8: []const u64 = block_127: {
        const value_2: []const u64 = (in).values;

        break :block_127 block_126: {
            const operand_108 = block_107: {
                const operand_102 = block_103: {
                    break :block_103 value_2;
                };
                const operand_104 = @as(u64, 0);
                const operand_105 = block_106: {
                    break :block_106 (try (allocator).dupe(u64, (&[_]u64{})));
                };

                break :block_107 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_104, .result = operand_105, .source = operand_102, });
            };

            var state_capacity_109: (std).ArrayList(u64) = .empty;

            var state_capacity_started_110 = false;

            defer (state_capacity_109).deinit(allocator);

            var state_101: value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_108;

            while (((state_101).index < @as(u64, ((state_101).source).len))) {
                state_101 = block_124: {
                    const value_5: u64 = block_123: {
                        const operand_121 = (state_101).source;
                        const operand_122 = (state_101).index;

                        if ((operand_122 >= (operand_121).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_123 (operand_121)[@intCast(operand_122)];
                    };
                    const value_1: u64 = block_120: {
                        break :block_120 value_5;
                    };
                    const value_6: u64 = (block_119: {
                        break :block_119 value_1;
                    } + @as(u64, 1));

                    break :block_124 block_118: {
                        const operand_111 = (state_101).source;
                        const operand_112 = ((state_101).index + @as(u64, 1));
                        const operand_113 = (block_117: {
                            const operand_114 = (state_101).result;
                            const operand_116 = block_115: {
                                break :block_115 value_6;
                            };

                            _ = (try ((std).math).add(usize, (operand_114).len, 1));

                            if ((!state_capacity_started_110)) {
                                (try (state_capacity_109).ensureTotalCapacityPrecise(allocator, ((operand_108).source).len));

                                (try (state_capacity_109).appendSlice(allocator, operand_114));

                                state_capacity_started_110 = true;
                            } else {
                                ((state_capacity_109).items).len = (operand_114).len;
                            }

                            (try (state_capacity_109).append(allocator, operand_116));

                            break :block_117 @as(value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_109).items, {}, null, });
                        }).@"0";

                        break :block_118 @as(value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_112, .result = operand_113, .source = operand_111, });
                    };
                };
            }

            var state_owned_125: []const u64 = (&[_]u64{});

            errdefer (allocator).free(state_owned_125);

            if (state_capacity_started_110) {
                ((state_capacity_109).items).len = ((state_101).result).len;

                state_owned_125 = (try (state_capacity_109).toOwnedSlice(allocator));
            }

            if (state_capacity_started_110) {
                state_101 = value_zx_type_15_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_101).index, .result = state_owned_125, .source = (state_101).source, };
            }

            break :block_126 (state_101).result;
        };
    };
    const value_9: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_100: {
        const operand_94 = block_95: {
            break :block_95 value_8;
        };
        const operand_96 = @as(u64, 0);
        const operand_97 = (in).count;
        const operand_98 = block_99: {
            break :block_99 value_8;
        };

        break :block_100 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .values = operand_94, .round = operand_96, .count = operand_97, .original = operand_98, });
    };
    const value_18: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_93: {
        const operand_71 = value_9;

        var state_items_73: []u64 = undefined;

        var state_items_started_74 = false;

        var state_70: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = operand_71;

        var state_changed_72 = false;

        while (((state_70).round < (state_70).count)) {
            state_70 = block_91: {
                const value_12: []const u64 = (state_70).values;
                const value_13: u64 = @as(u64, 0);
                const value_14: u64 = block_90: {
                    const operand_88 = block_86: {
                        break :block_86 value_12;
                    };
                    const operand_89 = block_87: {
                        break :block_87 value_13;
                    };

                    if ((operand_89 >= (operand_88).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_90 (operand_88)[@intCast(operand_89)];
                };
                const value_15: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_85: {
                    break :block_85 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (state_70).count, .original = (state_70).original, .round = (state_70).round, .values = block_84: {
                        const operand_78 = block_77: {
                            break :block_77 value_12;
                        };
                        const operand_80 = block_79: {
                            break :block_79 value_13;
                        };

                        if ((operand_80 >= (operand_78).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_82 = (block_81: {
                            break :block_81 value_14;
                        } + @as(u64, 1));

                        break :block_84 block_83: {
                            if ((!state_items_started_74)) {
                                state_items_73 = (try (allocator).dupe(u64, operand_78));

                                state_items_started_74 = true;
                            }

                            (state_items_73)[@intCast(operand_80)] = operand_82;

                            break :block_83 state_items_73;
                        };
                    }, });
                };
                const value_16: u64 = (value_15).round;
                const value_17: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_76: {
                    break :block_76 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (value_15).count, .original = (value_15).original, .round = (block_75: {
                        break :block_75 value_16;
                    } + @as(u64, 1)), .values = (value_15).values, });
                };

                break :block_91 value_17;
            };

            state_changed_72 = true;
        }

        break :block_93 (if (state_changed_72) state_70 else operand_71);
    };

    return block_69: {
        const operand_67 = (value_18).original;
        const operand_68 = (value_18).values;

        break :block_69 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .original = operand_67, .values = operand_68, });
    };
}

