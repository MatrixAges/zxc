const std = @import("std");

const zx_type_12 = struct {
    count: u64,
    values: []const u64,
};

const zx_type_13 = struct {
    count: u64,
    round: u64,
    values: []const u64,
};

const zx_type_14 = struct {
    original: []const u64,
    values: []const u64,
};

const value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    round: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    original: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_14 = null,
};

pub const Input = *const zx_type_12;

pub const State = *const zx_type_13;

pub const Output = *const zx_type_14;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .round = zx_shape_5, .values = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .original = zx_shape_11, .values = zx_shape_11, }, };

pub const input_shape = zx_shape_12;

pub const output_shape = zx_shape_14;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_12) error{ IndexOutOfBounds, OutOfMemory, }!*const zx_type_14 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: *const zx_type_13 = block_38: {
        const operand_33 = (in).values;
        const operand_34 = @as(u64, 0);
        const operand_35 = (in).count;

        break :block_38 block_37: {
            const operand_36 = (try (allocator).create(zx_type_13));

            (operand_36).* = @as(zx_type_13, zx_type_13{ .values = operand_33, .round = operand_34, .count = operand_35, });

            break :block_37 @as(*const zx_type_13, operand_36);
        };
    };
    const value_10: *const zx_type_13 = block_32: {
        const operand_8 = value_1;

        var state_items_10: []u64 = undefined;

        var state_items_started_11 = false;

        var state_7: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (operand_8).count, .round = (operand_8).round, .values = (operand_8).values, .zx_origin = operand_8, };

        var state_changed_9 = false;

        while (((state_7).round < (state_7).count)) {
            state_7 = block_28: {
                const value_4: []const u64 = (state_7).values;
                const value_5: u64 = @as(u64, 0);
                const value_6: u64 = block_27: {
                    const operand_25 = block_23: {
                        break :block_23 value_4;
                    };
                    const operand_26 = block_24: {
                        break :block_24 value_5;
                    };

                    if ((operand_26 >= (operand_25).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_27 (operand_25)[@intCast(operand_26)];
                };
                const value_7: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_22: {
                    break :block_22 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (state_7).count, .round = (state_7).round, .values = block_21: {
                        const operand_15 = block_14: {
                            break :block_14 value_4;
                        };
                        const operand_17 = block_16: {
                            break :block_16 value_5;
                        };

                        if ((operand_17 >= (operand_15).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_19 = (block_18: {
                            break :block_18 value_6;
                        } + @as(u64, 1));

                        break :block_21 block_20: {
                            if ((!state_items_started_11)) {
                                state_items_10 = (try (allocator).dupe(u64, operand_15));

                                state_items_started_11 = true;
                            }

                            (state_items_10)[@intCast(operand_17)] = operand_19;

                            break :block_20 state_items_10;
                        };
                    }, });
                };
                const value_8: u64 = (value_7).round;
                const value_9: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_13: {
                    break :block_13 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (value_7).count, .round = (block_12: {
                        break :block_12 value_8;
                    } + @as(u64, 1)), .values = (value_7).values, });
                };

                break :block_28 value_9;
            };

            state_changed_9 = true;
        }

        break :block_32 (if (state_changed_9) block_31: {
            break :block_31 (if (((state_7).zx_origin != null)) (state_7).zx_origin.? else block_30: {
                const operand_29 = (try (allocator).create(zx_type_13));

                (operand_29).* = zx_type_13{ .count = (state_7).count, .round = (state_7).round, .values = (state_7).values, };

                break :block_30 @as(*const zx_type_13, operand_29);
            });
        } else operand_8);
    };

    return block_6: {
        const operand_2 = (in).values;
        const operand_3 = (value_10).values;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create(zx_type_14));

            (operand_4).* = @as(zx_type_14, zx_type_14{ .original = operand_2, .values = operand_3, });

            break :block_5 @as(*const zx_type_14, operand_4);
        };
    };
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814) error{ IndexOutOfBounds, OutOfMemory, }!value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_1: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_70: {
        const operand_67 = (in).values;
        const operand_68 = @as(u64, 0);
        const operand_69 = (in).count;

        break :block_70 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .values = operand_67, .round = operand_68, .count = operand_69, });
    };
    const value_10: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_66: {
        const operand_44 = value_1;

        var state_items_46: []u64 = undefined;

        var state_items_started_47 = false;

        var state_43: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_44;

        var state_changed_45 = false;

        while (((state_43).round < (state_43).count)) {
            state_43 = block_64: {
                const value_4: []const u64 = (state_43).values;
                const value_5: u64 = @as(u64, 0);
                const value_6: u64 = block_63: {
                    const operand_61 = block_59: {
                        break :block_59 value_4;
                    };
                    const operand_62 = block_60: {
                        break :block_60 value_5;
                    };

                    if ((operand_62 >= (operand_61).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_63 (operand_61)[@intCast(operand_62)];
                };
                const value_7: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_58: {
                    break :block_58 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (state_43).count, .round = (state_43).round, .values = block_57: {
                        const operand_51 = block_50: {
                            break :block_50 value_4;
                        };
                        const operand_53 = block_52: {
                            break :block_52 value_5;
                        };

                        if ((operand_53 >= (operand_51).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_55 = (block_54: {
                            break :block_54 value_6;
                        } + @as(u64, 1));

                        break :block_57 block_56: {
                            if ((!state_items_started_47)) {
                                state_items_46 = (try (allocator).dupe(u64, operand_51));

                                state_items_started_47 = true;
                            }

                            (state_items_46)[@intCast(operand_53)] = operand_55;

                            break :block_56 state_items_46;
                        };
                    }, });
                };
                const value_8: u64 = (value_7).round;
                const value_9: value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_49: {
                    break :block_49 @as(value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_13_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (value_7).count, .round = (block_48: {
                        break :block_48 value_8;
                    } + @as(u64, 1)), .values = (value_7).values, });
                };

                break :block_64 value_9;
            };

            state_changed_45 = true;
        }

        break :block_66 (if (state_changed_45) state_43 else operand_44);
    };

    return block_42: {
        const operand_40 = (in).values;
        const operand_41 = (value_10).values;

        break :block_42 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .original = operand_40, .values = operand_41, });
    };
}

