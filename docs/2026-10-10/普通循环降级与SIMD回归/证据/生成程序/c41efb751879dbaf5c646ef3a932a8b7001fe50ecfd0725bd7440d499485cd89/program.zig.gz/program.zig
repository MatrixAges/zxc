const std = @import("std");

const zx_abi = @import("zxc_abi");

pub const Input = []const f32;

pub const Output = *const (zx_abi).zx_type_3cd3b6b687a2a82c40da7a8221473fc779db0a84159857bc4bf80a6f1598e9de;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_8, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .add = zx_shape_11, .broadcast = zx_shape_11, .cancellation = zx_shape_11, .chain = zx_shape_11, .conditional = zx_shape_11, .divide = zx_shape_11, .grouped = zx_shape_11, .identity = zx_shape_11, .multiply = zx_shape_11, .negative = zx_shape_11, .subtract = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_11, .source = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_0, }, };

pub const input_shape = zx_shape_11;

pub const output_shape = zx_shape_12;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: []const f32) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_3cd3b6b687a2a82c40da7a8221473fc779db0a84159857bc4bf80a6f1598e9de {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();

    return block_359: {
        const operand_1 = block_27: {
            const value_2: []const f32 = in;

            break :block_27 block_26: {
                const operand_8 = block_7: {
                    const operand_3 = value_2;
                    const operand_4 = @as(u64, 0);
                    const operand_5 = block_6: {
                        break :block_6 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_7 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_4, .result = operand_5, .source = operand_3, };
                };

                var state_capacity_9: (std).ArrayList(f32) = .empty;

                var state_capacity_started_10 = false;

                defer (state_capacity_9).deinit(allocator);

                var state_2: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_8).index, .result = (operand_8).result, .source = (operand_8).source, .zx_origin = (&operand_8), };

                while (((state_2).index < @as(u64, ((state_2).source).len))) {
                    state_2 = block_24: {
                        const value_5: f32 = block_23: {
                            const operand_21 = (state_2).source;
                            const operand_22 = (state_2).index;

                            if ((operand_22 >= (operand_21).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_23 (operand_21)[@intCast(operand_22)];
                        };
                        const value_1: f32 = block_20: {
                            break :block_20 value_5;
                        };
                        const value_6: f32 = block_19: {
                            break :block_19 value_1;
                        };

                        break :block_24 block_18: {
                            const operand_11 = (state_2).source;
                            const operand_12 = ((state_2).index + @as(u64, 1));
                            const operand_13 = (block_17: {
                                const operand_14 = (state_2).result;
                                const operand_16 = block_15: {
                                    break :block_15 value_6;
                                };

                                _ = (try ((std).math).add(usize, (operand_14).len, 1));

                                if ((!state_capacity_started_10)) {
                                    (try (state_capacity_9).ensureTotalCapacityPrecise(allocator, ((operand_8).source).len));

                                    (try (state_capacity_9).appendSlice(allocator, operand_14));

                                    state_capacity_started_10 = true;
                                } else {
                                    ((state_capacity_9).items).len = (operand_14).len;
                                }

                                (try (state_capacity_9).append(allocator, operand_16));

                                break :block_17 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_9).items, {}, null, });
                            }).@"0";

                            break :block_18 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_12, .result = operand_13, .source = operand_11, });
                        };
                    };
                }

                var state_owned_25: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_25);

                if (state_capacity_started_10) {
                    ((state_capacity_9).items).len = ((state_2).result).len;

                    state_owned_25 = (try (state_capacity_9).toOwnedSlice(allocator));
                }

                if (state_capacity_started_10) {
                    state_2 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_2).index, .result = state_owned_25, .source = (state_2).source, };
                }

                break :block_26 (state_2).result;
            };
        };
        const operand_28 = block_55: {
            const value_9: []const f32 = in;

            break :block_55 block_54: {
                const operand_35 = block_34: {
                    const operand_30 = value_9;
                    const operand_31 = @as(u64, 0);
                    const operand_32 = block_33: {
                        break :block_33 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_34 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_31, .result = operand_32, .source = operand_30, };
                };

                var state_capacity_37: (std).ArrayList(f32) = .empty;

                var state_capacity_started_38 = false;

                defer (state_capacity_37).deinit(allocator);

                var state_29: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_35).index, .result = (operand_35).result, .source = (operand_35).source, .zx_origin = (&operand_35), };

                while (((state_29).index < @as(u64, ((state_29).source).len))) {
                    state_29 = block_52: {
                        const value_12: f32 = block_51: {
                            const operand_49 = (state_29).source;
                            const operand_50 = (state_29).index;

                            if ((operand_50 >= (operand_49).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_51 (operand_49)[@intCast(operand_50)];
                        };
                        const value_8: f32 = block_48: {
                            break :block_48 value_12;
                        };
                        const value_13: f32 = (-block_47: {
                            break :block_47 value_8;
                        });

                        break :block_52 block_46: {
                            const operand_39 = (state_29).source;
                            const operand_40 = ((state_29).index + @as(u64, 1));
                            const operand_41 = (block_45: {
                                const operand_42 = (state_29).result;
                                const operand_44 = block_43: {
                                    break :block_43 value_13;
                                };

                                _ = (try ((std).math).add(usize, (operand_42).len, 1));

                                if ((!state_capacity_started_38)) {
                                    (try (state_capacity_37).ensureTotalCapacityPrecise(allocator, ((operand_35).source).len));

                                    (try (state_capacity_37).appendSlice(allocator, operand_42));

                                    state_capacity_started_38 = true;
                                } else {
                                    ((state_capacity_37).items).len = (operand_42).len;
                                }

                                (try (state_capacity_37).append(allocator, operand_44));

                                break :block_45 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_37).items, {}, null, });
                            }).@"0";

                            break :block_46 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_40, .result = operand_41, .source = operand_39, });
                        };
                    };
                }

                var state_owned_53: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_53);

                if (state_capacity_started_38) {
                    ((state_capacity_37).items).len = ((state_29).result).len;

                    state_owned_53 = (try (state_capacity_37).toOwnedSlice(allocator));
                }

                if (state_capacity_started_38) {
                    state_29 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_29).index, .result = state_owned_53, .source = (state_29).source, };
                }

                break :block_54 (state_29).result;
            };
        };
        const operand_56 = block_82: {
            const value_16: []const f32 = in;

            break :block_82 block_81: {
                const operand_63 = block_62: {
                    const operand_58 = value_16;
                    const operand_59 = @as(u64, 0);
                    const operand_60 = block_61: {
                        break :block_61 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_62 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_59, .result = operand_60, .source = operand_58, };
                };

                var state_capacity_66: (std).ArrayList(f32) = .empty;

                var state_capacity_started_67 = false;

                defer (state_capacity_66).deinit(allocator);

                var state_57: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_63).index, .result = (operand_63).result, .source = (operand_63).source, .zx_origin = (&operand_63), };

                while (((state_57).index < @as(u64, ((state_57).source).len))) {
                    state_57 = block_79: {
                        _ = block_78: {
                            const operand_76 = (state_57).source;
                            const operand_77 = (state_57).index;

                            if ((operand_77 >= (operand_76).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_78 (operand_76)[@intCast(operand_77)];
                        };

                        const value_20: f32 = @as(f32, @as(f64, @bitCast(@as(u64, 4609434218613702656))));

                        break :block_79 block_75: {
                            const operand_68 = (state_57).source;
                            const operand_69 = ((state_57).index + @as(u64, 1));
                            const operand_70 = (block_74: {
                                const operand_71 = (state_57).result;
                                const operand_73 = block_72: {
                                    break :block_72 value_20;
                                };

                                _ = (try ((std).math).add(usize, (operand_71).len, 1));

                                if ((!state_capacity_started_67)) {
                                    (try (state_capacity_66).ensureTotalCapacityPrecise(allocator, ((operand_63).source).len));

                                    (try (state_capacity_66).appendSlice(allocator, operand_71));

                                    state_capacity_started_67 = true;
                                } else {
                                    ((state_capacity_66).items).len = (operand_71).len;
                                }

                                (try (state_capacity_66).append(allocator, operand_73));

                                break :block_74 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_66).items, {}, null, });
                            }).@"0";

                            break :block_75 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_69, .result = operand_70, .source = operand_68, });
                        };
                    };
                }

                var state_owned_80: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_80);

                if (state_capacity_started_67) {
                    ((state_capacity_66).items).len = ((state_57).result).len;

                    state_owned_80 = (try (state_capacity_66).toOwnedSlice(allocator));
                }

                if (state_capacity_started_67) {
                    state_57 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_57).index, .result = state_owned_80, .source = (state_57).source, };
                }

                break :block_81 (state_57).result;
            };
        };
        const operand_83 = block_112: {
            const value_23: []const f32 = in;

            break :block_112 block_111: {
                const operand_90 = block_89: {
                    const operand_85 = value_23;
                    const operand_86 = @as(u64, 0);
                    const operand_87 = block_88: {
                        break :block_88 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_89 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_86, .result = operand_87, .source = operand_85, };
                };

                var state_capacity_94: (std).ArrayList(f32) = .empty;

                var state_capacity_started_95 = false;

                defer (state_capacity_94).deinit(allocator);

                var state_84: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_90).index, .result = (operand_90).result, .source = (operand_90).source, .zx_origin = (&operand_90), };

                while (((state_84).index < @as(u64, ((state_84).source).len))) {
                    state_84 = block_109: {
                        const value_26: f32 = block_108: {
                            const operand_106 = (state_84).source;
                            const operand_107 = (state_84).index;

                            if ((operand_107 >= (operand_106).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_108 (operand_106)[@intCast(operand_107)];
                        };
                        const value_22: f32 = block_105: {
                            break :block_105 value_26;
                        };
                        const value_27: f32 = (block_104: {
                            break :block_104 value_22;
                        } + @as(f32, @as(f64, @bitCast(@as(u64, 4609434218613702656)))));

                        break :block_109 block_103: {
                            const operand_96 = (state_84).source;
                            const operand_97 = ((state_84).index + @as(u64, 1));
                            const operand_98 = (block_102: {
                                const operand_99 = (state_84).result;
                                const operand_101 = block_100: {
                                    break :block_100 value_27;
                                };

                                _ = (try ((std).math).add(usize, (operand_99).len, 1));

                                if ((!state_capacity_started_95)) {
                                    (try (state_capacity_94).ensureTotalCapacityPrecise(allocator, ((operand_90).source).len));

                                    (try (state_capacity_94).appendSlice(allocator, operand_99));

                                    state_capacity_started_95 = true;
                                } else {
                                    ((state_capacity_94).items).len = (operand_99).len;
                                }

                                (try (state_capacity_94).append(allocator, operand_101));

                                break :block_102 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_94).items, {}, null, });
                            }).@"0";

                            break :block_103 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_97, .result = operand_98, .source = operand_96, });
                        };
                    };
                }

                var state_owned_110: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_110);

                if (state_capacity_started_95) {
                    ((state_capacity_94).items).len = ((state_84).result).len;

                    state_owned_110 = (try (state_capacity_94).toOwnedSlice(allocator));
                }

                if (state_capacity_started_95) {
                    state_84 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_84).index, .result = state_owned_110, .source = (state_84).source, };
                }

                break :block_111 (state_84).result;
            };
        };
        const operand_113 = block_143: {
            const value_30: []const f32 = in;

            break :block_143 block_142: {
                const operand_120 = block_119: {
                    const operand_115 = value_30;
                    const operand_116 = @as(u64, 0);
                    const operand_117 = block_118: {
                        break :block_118 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_119 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_116, .result = operand_117, .source = operand_115, };
                };

                var state_capacity_125: (std).ArrayList(f32) = .empty;

                var state_capacity_started_126 = false;

                defer (state_capacity_125).deinit(allocator);

                var state_114: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_120).index, .result = (operand_120).result, .source = (operand_120).source, .zx_origin = (&operand_120), };

                while (((state_114).index < @as(u64, ((state_114).source).len))) {
                    state_114 = block_140: {
                        const value_33: f32 = block_139: {
                            const operand_137 = (state_114).source;
                            const operand_138 = (state_114).index;

                            if ((operand_138 >= (operand_137).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_139 (operand_137)[@intCast(operand_138)];
                        };
                        const value_29: f32 = block_136: {
                            break :block_136 value_33;
                        };
                        const value_34: f32 = (@as(f32, @as(f64, @bitCast(@as(u64, 4609434218613702656)))) - block_135: {
                            break :block_135 value_29;
                        });

                        break :block_140 block_134: {
                            const operand_127 = (state_114).source;
                            const operand_128 = ((state_114).index + @as(u64, 1));
                            const operand_129 = (block_133: {
                                const operand_130 = (state_114).result;
                                const operand_132 = block_131: {
                                    break :block_131 value_34;
                                };

                                _ = (try ((std).math).add(usize, (operand_130).len, 1));

                                if ((!state_capacity_started_126)) {
                                    (try (state_capacity_125).ensureTotalCapacityPrecise(allocator, ((operand_120).source).len));

                                    (try (state_capacity_125).appendSlice(allocator, operand_130));

                                    state_capacity_started_126 = true;
                                } else {
                                    ((state_capacity_125).items).len = (operand_130).len;
                                }

                                (try (state_capacity_125).append(allocator, operand_132));

                                break :block_133 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_125).items, {}, null, });
                            }).@"0";

                            break :block_134 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_128, .result = operand_129, .source = operand_127, });
                        };
                    };
                }

                var state_owned_141: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_141);

                if (state_capacity_started_126) {
                    ((state_capacity_125).items).len = ((state_114).result).len;

                    state_owned_141 = (try (state_capacity_125).toOwnedSlice(allocator));
                }

                if (state_capacity_started_126) {
                    state_114 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_114).index, .result = state_owned_141, .source = (state_114).source, };
                }

                break :block_142 (state_114).result;
            };
        };
        const operand_144 = block_176: {
            const value_37: []const f32 = in;

            break :block_176 block_175: {
                const operand_151 = block_150: {
                    const operand_146 = value_37;
                    const operand_147 = @as(u64, 0);
                    const operand_148 = block_149: {
                        break :block_149 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_150 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_147, .result = operand_148, .source = operand_146, };
                };

                var state_capacity_157: (std).ArrayList(f32) = .empty;

                var state_capacity_started_158 = false;

                defer (state_capacity_157).deinit(allocator);

                var state_145: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_151).index, .result = (operand_151).result, .source = (operand_151).source, .zx_origin = (&operand_151), };

                while (((state_145).index < @as(u64, ((state_145).source).len))) {
                    state_145 = block_173: {
                        const value_40: f32 = block_172: {
                            const operand_170 = (state_145).source;
                            const operand_171 = (state_145).index;

                            if ((operand_171 >= (operand_170).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_172 (operand_170)[@intCast(operand_171)];
                        };
                        const value_36: f32 = block_169: {
                            break :block_169 value_40;
                        };
                        const value_41: f32 = (block_167: {
                            break :block_167 value_36;
                        } * block_168: {
                            break :block_168 value_36;
                        });

                        break :block_173 block_166: {
                            const operand_159 = (state_145).source;
                            const operand_160 = ((state_145).index + @as(u64, 1));
                            const operand_161 = (block_165: {
                                const operand_162 = (state_145).result;
                                const operand_164 = block_163: {
                                    break :block_163 value_41;
                                };

                                _ = (try ((std).math).add(usize, (operand_162).len, 1));

                                if ((!state_capacity_started_158)) {
                                    (try (state_capacity_157).ensureTotalCapacityPrecise(allocator, ((operand_151).source).len));

                                    (try (state_capacity_157).appendSlice(allocator, operand_162));

                                    state_capacity_started_158 = true;
                                } else {
                                    ((state_capacity_157).items).len = (operand_162).len;
                                }

                                (try (state_capacity_157).append(allocator, operand_164));

                                break :block_165 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_157).items, {}, null, });
                            }).@"0";

                            break :block_166 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_160, .result = operand_161, .source = operand_159, });
                        };
                    };
                }

                var state_owned_174: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_174);

                if (state_capacity_started_158) {
                    ((state_capacity_157).items).len = ((state_145).result).len;

                    state_owned_174 = (try (state_capacity_157).toOwnedSlice(allocator));
                }

                if (state_capacity_started_158) {
                    state_145 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_145).index, .result = state_owned_174, .source = (state_145).source, };
                }

                break :block_175 (state_145).result;
            };
        };
        const operand_177 = block_209: {
            const value_44: []const f32 = in;

            break :block_209 block_208: {
                const operand_184 = block_183: {
                    const operand_179 = value_44;
                    const operand_180 = @as(u64, 0);
                    const operand_181 = block_182: {
                        break :block_182 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_183 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_180, .result = operand_181, .source = operand_179, };
                };

                var state_capacity_191: (std).ArrayList(f32) = .empty;

                var state_capacity_started_192 = false;

                defer (state_capacity_191).deinit(allocator);

                var state_178: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_184).index, .result = (operand_184).result, .source = (operand_184).source, .zx_origin = (&operand_184), };

                while (((state_178).index < @as(u64, ((state_178).source).len))) {
                    state_178 = block_206: {
                        const value_47: f32 = block_205: {
                            const operand_203 = (state_178).source;
                            const operand_204 = (state_178).index;

                            if ((operand_204 >= (operand_203).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_205 (operand_203)[@intCast(operand_204)];
                        };
                        const value_43: f32 = block_202: {
                            break :block_202 value_47;
                        };
                        const value_48: f32 = (block_201: {
                            break :block_201 value_43;
                        } / @as(f32, @as(f64, @bitCast(@as(u64, 4611686018427387904)))));

                        break :block_206 block_200: {
                            const operand_193 = (state_178).source;
                            const operand_194 = ((state_178).index + @as(u64, 1));
                            const operand_195 = (block_199: {
                                const operand_196 = (state_178).result;
                                const operand_198 = block_197: {
                                    break :block_197 value_48;
                                };

                                _ = (try ((std).math).add(usize, (operand_196).len, 1));

                                if ((!state_capacity_started_192)) {
                                    (try (state_capacity_191).ensureTotalCapacityPrecise(allocator, ((operand_184).source).len));

                                    (try (state_capacity_191).appendSlice(allocator, operand_196));

                                    state_capacity_started_192 = true;
                                } else {
                                    ((state_capacity_191).items).len = (operand_196).len;
                                }

                                (try (state_capacity_191).append(allocator, operand_198));

                                break :block_199 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_191).items, {}, null, });
                            }).@"0";

                            break :block_200 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_194, .result = operand_195, .source = operand_193, });
                        };
                    };
                }

                var state_owned_207: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_207);

                if (state_capacity_started_192) {
                    ((state_capacity_191).items).len = ((state_178).result).len;

                    state_owned_207 = (try (state_capacity_191).toOwnedSlice(allocator));
                }

                if (state_capacity_started_192) {
                    state_178 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_178).index, .result = state_owned_207, .source = (state_178).source, };
                }

                break :block_208 (state_178).result;
            };
        };
        const operand_210 = block_245: {
            const value_51: []const f32 = in;

            break :block_245 block_244: {
                const operand_217 = block_216: {
                    const operand_212 = value_51;
                    const operand_213 = @as(u64, 0);
                    const operand_214 = block_215: {
                        break :block_215 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_216 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_213, .result = operand_214, .source = operand_212, };
                };

                var state_capacity_225: (std).ArrayList(f32) = .empty;

                var state_capacity_started_226 = false;

                defer (state_capacity_225).deinit(allocator);

                var state_211: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_217).index, .result = (operand_217).result, .source = (operand_217).source, .zx_origin = (&operand_217), };

                while (((state_211).index < @as(u64, ((state_211).source).len))) {
                    state_211 = block_242: {
                        const value_54: f32 = block_241: {
                            const operand_239 = (state_211).source;
                            const operand_240 = (state_211).index;

                            if ((operand_240 >= (operand_239).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_241 (operand_239)[@intCast(operand_240)];
                        };
                        const value_50: f32 = block_238: {
                            break :block_238 value_54;
                        };
                        const value_55: f32 = ((block_235: {
                            break :block_235 value_50;
                        } * block_236: {
                            break :block_236 value_50;
                        }) + block_237: {
                            break :block_237 value_50;
                        });

                        break :block_242 block_234: {
                            const operand_227 = (state_211).source;
                            const operand_228 = ((state_211).index + @as(u64, 1));
                            const operand_229 = (block_233: {
                                const operand_230 = (state_211).result;
                                const operand_232 = block_231: {
                                    break :block_231 value_55;
                                };

                                _ = (try ((std).math).add(usize, (operand_230).len, 1));

                                if ((!state_capacity_started_226)) {
                                    (try (state_capacity_225).ensureTotalCapacityPrecise(allocator, ((operand_217).source).len));

                                    (try (state_capacity_225).appendSlice(allocator, operand_230));

                                    state_capacity_started_226 = true;
                                } else {
                                    ((state_capacity_225).items).len = (operand_230).len;
                                }

                                (try (state_capacity_225).append(allocator, operand_232));

                                break :block_233 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_225).items, {}, null, });
                            }).@"0";

                            break :block_234 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_228, .result = operand_229, .source = operand_227, });
                        };
                    };
                }

                var state_owned_243: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_243);

                if (state_capacity_started_226) {
                    ((state_capacity_225).items).len = ((state_211).result).len;

                    state_owned_243 = (try (state_capacity_225).toOwnedSlice(allocator));
                }

                if (state_capacity_started_226) {
                    state_211 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_211).index, .result = state_owned_243, .source = (state_211).source, };
                }

                break :block_244 (state_211).result;
            };
        };
        const operand_246 = block_281: {
            const value_58: []const f32 = in;

            break :block_281 block_280: {
                const operand_253 = block_252: {
                    const operand_248 = value_58;
                    const operand_249 = @as(u64, 0);
                    const operand_250 = block_251: {
                        break :block_251 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_252 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_249, .result = operand_250, .source = operand_248, };
                };

                var state_capacity_262: (std).ArrayList(f32) = .empty;

                var state_capacity_started_263 = false;

                defer (state_capacity_262).deinit(allocator);

                var state_247: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_253).index, .result = (operand_253).result, .source = (operand_253).source, .zx_origin = (&operand_253), };

                while (((state_247).index < @as(u64, ((state_247).source).len))) {
                    state_247 = block_278: {
                        const value_61: f32 = block_277: {
                            const operand_275 = (state_247).source;
                            const operand_276 = (state_247).index;

                            if ((operand_276 >= (operand_275).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_277 (operand_275)[@intCast(operand_276)];
                        };
                        const value_57: f32 = block_274: {
                            break :block_274 value_61;
                        };
                        const value_62: f32 = ((block_272: {
                            break :block_272 value_57;
                        } + @as(f32, @as(f64, @bitCast(@as(u64, 4609434218613702656))))) * (block_273: {
                            break :block_273 value_57;
                        } - @as(f32, @as(f64, @bitCast(@as(u64, 4609434218613702656))))));

                        break :block_278 block_271: {
                            const operand_264 = (state_247).source;
                            const operand_265 = ((state_247).index + @as(u64, 1));
                            const operand_266 = (block_270: {
                                const operand_267 = (state_247).result;
                                const operand_269 = block_268: {
                                    break :block_268 value_62;
                                };

                                _ = (try ((std).math).add(usize, (operand_267).len, 1));

                                if ((!state_capacity_started_263)) {
                                    (try (state_capacity_262).ensureTotalCapacityPrecise(allocator, ((operand_253).source).len));

                                    (try (state_capacity_262).appendSlice(allocator, operand_267));

                                    state_capacity_started_263 = true;
                                } else {
                                    ((state_capacity_262).items).len = (operand_267).len;
                                }

                                (try (state_capacity_262).append(allocator, operand_269));

                                break :block_270 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_262).items, {}, null, });
                            }).@"0";

                            break :block_271 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_265, .result = operand_266, .source = operand_264, });
                        };
                    };
                }

                var state_owned_279: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_279);

                if (state_capacity_started_263) {
                    ((state_capacity_262).items).len = ((state_247).result).len;

                    state_owned_279 = (try (state_capacity_262).toOwnedSlice(allocator));
                }

                if (state_capacity_started_263) {
                    state_247 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_247).index, .result = state_owned_279, .source = (state_247).source, };
                }

                break :block_280 (state_247).result;
            };
        };
        const operand_282 = block_317: {
            const value_65: []const f32 = in;

            break :block_317 block_316: {
                const operand_289 = block_288: {
                    const operand_284 = value_65;
                    const operand_285 = @as(u64, 0);
                    const operand_286 = block_287: {
                        break :block_287 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_288 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_285, .result = operand_286, .source = operand_284, };
                };

                var state_capacity_299: (std).ArrayList(f32) = .empty;

                var state_capacity_started_300 = false;

                defer (state_capacity_299).deinit(allocator);

                var state_283: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_289).index, .result = (operand_289).result, .source = (operand_289).source, .zx_origin = (&operand_289), };

                while (((state_283).index < @as(u64, ((state_283).source).len))) {
                    state_283 = block_314: {
                        const value_68: f32 = block_313: {
                            const operand_311 = (state_283).source;
                            const operand_312 = (state_283).index;

                            if ((operand_312 >= (operand_311).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_313 (operand_311)[@intCast(operand_312)];
                        };
                        const value_64: f32 = block_310: {
                            break :block_310 value_68;
                        };
                        const value_69: f32 = ((block_309: {
                            break :block_309 value_64;
                        } + @as(f32, @as(f64, @bitCast(@as(u64, 4715268809856909312))))) - @as(f32, @as(f64, @bitCast(@as(u64, 4715268809856909312)))));

                        break :block_314 block_308: {
                            const operand_301 = (state_283).source;
                            const operand_302 = ((state_283).index + @as(u64, 1));
                            const operand_303 = (block_307: {
                                const operand_304 = (state_283).result;
                                const operand_306 = block_305: {
                                    break :block_305 value_69;
                                };

                                _ = (try ((std).math).add(usize, (operand_304).len, 1));

                                if ((!state_capacity_started_300)) {
                                    (try (state_capacity_299).ensureTotalCapacityPrecise(allocator, ((operand_289).source).len));

                                    (try (state_capacity_299).appendSlice(allocator, operand_304));

                                    state_capacity_started_300 = true;
                                } else {
                                    ((state_capacity_299).items).len = (operand_304).len;
                                }

                                (try (state_capacity_299).append(allocator, operand_306));

                                break :block_307 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_299).items, {}, null, });
                            }).@"0";

                            break :block_308 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_302, .result = operand_303, .source = operand_301, });
                        };
                    };
                }

                var state_owned_315: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_315);

                if (state_capacity_started_300) {
                    ((state_capacity_299).items).len = ((state_283).result).len;

                    state_owned_315 = (try (state_capacity_299).toOwnedSlice(allocator));
                }

                if (state_capacity_started_300) {
                    state_283 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_283).index, .result = state_owned_315, .source = (state_283).source, };
                }

                break :block_316 (state_283).result;
            };
        };
        const operand_318 = block_356: {
            const value_72: []const f32 = in;

            break :block_356 block_355: {
                const operand_325 = block_324: {
                    const operand_320 = value_72;
                    const operand_321 = @as(u64, 0);
                    const operand_322 = block_323: {
                        break :block_323 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_324 (zx_abi).zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d{ .index = operand_321, .result = operand_322, .source = operand_320, };
                };

                var state_capacity_336: (std).ArrayList(f32) = .empty;

                var state_capacity_started_337 = false;

                defer (state_capacity_336).deinit(allocator);

                var state_319: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (operand_325).index, .result = (operand_325).result, .source = (operand_325).source, .zx_origin = (&operand_325), };

                while (((state_319).index < @as(u64, ((state_319).source).len))) {
                    state_319 = block_353: {
                        const value_75: f32 = block_352: {
                            const operand_350 = (state_319).source;
                            const operand_351 = (state_319).index;

                            if ((operand_351 >= (operand_350).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_352 (operand_350)[@intCast(operand_351)];
                        };
                        const value_71: f32 = block_349: {
                            break :block_349 value_75;
                        };
                        const value_76: f32 = (if ((block_346: {
                            break :block_346 value_71;
                        } < @as(f32, @as(f64, @bitCast(@as(u64, 0)))))) (-block_347: {
                            break :block_347 value_71;
                        }) else block_348: {
                            break :block_348 value_71;
                        });

                        break :block_353 block_345: {
                            const operand_338 = (state_319).source;
                            const operand_339 = ((state_319).index + @as(u64, 1));
                            const operand_340 = (block_344: {
                                const operand_341 = (state_319).result;
                                const operand_343 = block_342: {
                                    break :block_342 value_76;
                                };

                                _ = (try ((std).math).add(usize, (operand_341).len, 1));

                                if ((!state_capacity_started_337)) {
                                    (try (state_capacity_336).ensureTotalCapacityPrecise(allocator, ((operand_325).source).len));

                                    (try (state_capacity_336).appendSlice(allocator, operand_341));

                                    state_capacity_started_337 = true;
                                } else {
                                    ((state_capacity_336).items).len = (operand_341).len;
                                }

                                (try (state_capacity_336).append(allocator, operand_343));

                                break :block_344 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_336).items, {}, null, });
                            }).@"0";

                            break :block_345 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_339, .result = operand_340, .source = operand_338, });
                        };
                    };
                }

                var state_owned_354: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_354);

                if (state_capacity_started_337) {
                    ((state_capacity_336).items).len = ((state_319).result).len;

                    state_owned_354 = (try (state_capacity_336).toOwnedSlice(allocator));
                }

                if (state_capacity_started_337) {
                    state_319 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_319).index, .result = state_owned_354, .source = (state_319).source, };
                }

                break :block_355 (state_319).result;
            };
        };

        break :block_359 block_358: {
            const operand_357 = (try (allocator).create((zx_abi).zx_type_3cd3b6b687a2a82c40da7a8221473fc779db0a84159857bc4bf80a6f1598e9de));

            (operand_357).* = @as((zx_abi).zx_type_3cd3b6b687a2a82c40da7a8221473fc779db0a84159857bc4bf80a6f1598e9de, (zx_abi).zx_type_3cd3b6b687a2a82c40da7a8221473fc779db0a84159857bc4bf80a6f1598e9de{ .identity = operand_1, .negative = operand_28, .broadcast = operand_56, .add = operand_83, .subtract = operand_113, .multiply = operand_144, .divide = operand_177, .chain = operand_210, .grouped = operand_246, .cancellation = operand_282, .conditional = operand_318, });

            break :block_358 @as(*const (zx_abi).zx_type_3cd3b6b687a2a82c40da7a8221473fc779db0a84159857bc4bf80a6f1598e9de, operand_357);
        };
    };
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: []const f32) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_3cd3b6b687a2a82c40da7a8221473fc779db0a84159857bc4bf80a6f1598e9de_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d {
    @setRuntimeSafety(true);

    return block_672: {
        const operand_360 = block_387: {
            const value_2: []const f32 = in;

            break :block_387 block_386: {
                const operand_368 = block_367: {
                    const operand_362 = block_363: {
                        break :block_363 value_2;
                    };
                    const operand_364 = @as(u64, 0);
                    const operand_365 = block_366: {
                        break :block_366 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_367 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_364, .result = operand_365, .source = operand_362, });
                };

                var state_capacity_369: (std).ArrayList(f32) = .empty;

                var state_capacity_started_370 = false;

                defer (state_capacity_369).deinit(allocator);

                var state_361: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_368;

                while (((state_361).index < @as(u64, ((state_361).source).len))) {
                    state_361 = block_384: {
                        const value_5: f32 = block_383: {
                            const operand_381 = (state_361).source;
                            const operand_382 = (state_361).index;

                            if ((operand_382 >= (operand_381).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_383 (operand_381)[@intCast(operand_382)];
                        };
                        const value_1: f32 = block_380: {
                            break :block_380 value_5;
                        };
                        const value_6: f32 = block_379: {
                            break :block_379 value_1;
                        };

                        break :block_384 block_378: {
                            const operand_371 = (state_361).source;
                            const operand_372 = ((state_361).index + @as(u64, 1));
                            const operand_373 = (block_377: {
                                const operand_374 = (state_361).result;
                                const operand_376 = block_375: {
                                    break :block_375 value_6;
                                };

                                _ = (try ((std).math).add(usize, (operand_374).len, 1));

                                if ((!state_capacity_started_370)) {
                                    (try (state_capacity_369).ensureTotalCapacityPrecise(allocator, ((operand_368).source).len));

                                    (try (state_capacity_369).appendSlice(allocator, operand_374));

                                    state_capacity_started_370 = true;
                                } else {
                                    ((state_capacity_369).items).len = (operand_374).len;
                                }

                                (try (state_capacity_369).append(allocator, operand_376));

                                break :block_377 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_369).items, {}, null, });
                            }).@"0";

                            break :block_378 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_372, .result = operand_373, .source = operand_371, });
                        };
                    };
                }

                var state_owned_385: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_385);

                if (state_capacity_started_370) {
                    ((state_capacity_369).items).len = ((state_361).result).len;

                    state_owned_385 = (try (state_capacity_369).toOwnedSlice(allocator));
                }

                if (state_capacity_started_370) {
                    state_361 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_361).index, .result = state_owned_385, .source = (state_361).source, };
                }

                break :block_386 (state_361).result;
            };
        };
        const operand_388 = block_415: {
            const value_9: []const f32 = in;

            break :block_415 block_414: {
                const operand_396 = block_395: {
                    const operand_390 = block_391: {
                        break :block_391 value_9;
                    };
                    const operand_392 = @as(u64, 0);
                    const operand_393 = block_394: {
                        break :block_394 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_395 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_392, .result = operand_393, .source = operand_390, });
                };

                var state_capacity_397: (std).ArrayList(f32) = .empty;

                var state_capacity_started_398 = false;

                defer (state_capacity_397).deinit(allocator);

                var state_389: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_396;

                while (((state_389).index < @as(u64, ((state_389).source).len))) {
                    state_389 = block_412: {
                        const value_12: f32 = block_411: {
                            const operand_409 = (state_389).source;
                            const operand_410 = (state_389).index;

                            if ((operand_410 >= (operand_409).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_411 (operand_409)[@intCast(operand_410)];
                        };
                        const value_8: f32 = block_408: {
                            break :block_408 value_12;
                        };
                        const value_13: f32 = (-block_407: {
                            break :block_407 value_8;
                        });

                        break :block_412 block_406: {
                            const operand_399 = (state_389).source;
                            const operand_400 = ((state_389).index + @as(u64, 1));
                            const operand_401 = (block_405: {
                                const operand_402 = (state_389).result;
                                const operand_404 = block_403: {
                                    break :block_403 value_13;
                                };

                                _ = (try ((std).math).add(usize, (operand_402).len, 1));

                                if ((!state_capacity_started_398)) {
                                    (try (state_capacity_397).ensureTotalCapacityPrecise(allocator, ((operand_396).source).len));

                                    (try (state_capacity_397).appendSlice(allocator, operand_402));

                                    state_capacity_started_398 = true;
                                } else {
                                    ((state_capacity_397).items).len = (operand_402).len;
                                }

                                (try (state_capacity_397).append(allocator, operand_404));

                                break :block_405 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_397).items, {}, null, });
                            }).@"0";

                            break :block_406 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_400, .result = operand_401, .source = operand_399, });
                        };
                    };
                }

                var state_owned_413: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_413);

                if (state_capacity_started_398) {
                    ((state_capacity_397).items).len = ((state_389).result).len;

                    state_owned_413 = (try (state_capacity_397).toOwnedSlice(allocator));
                }

                if (state_capacity_started_398) {
                    state_389 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_389).index, .result = state_owned_413, .source = (state_389).source, };
                }

                break :block_414 (state_389).result;
            };
        };
        const operand_416 = block_441: {
            const value_16: []const f32 = in;

            break :block_441 block_440: {
                const operand_424 = block_423: {
                    const operand_418 = block_419: {
                        break :block_419 value_16;
                    };
                    const operand_420 = @as(u64, 0);
                    const operand_421 = block_422: {
                        break :block_422 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_423 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_420, .result = operand_421, .source = operand_418, });
                };

                var state_capacity_425: (std).ArrayList(f32) = .empty;

                var state_capacity_started_426 = false;

                defer (state_capacity_425).deinit(allocator);

                var state_417: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_424;

                while (((state_417).index < @as(u64, ((state_417).source).len))) {
                    state_417 = block_438: {
                        _ = block_437: {
                            const operand_435 = (state_417).source;
                            const operand_436 = (state_417).index;

                            if ((operand_436 >= (operand_435).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_437 (operand_435)[@intCast(operand_436)];
                        };

                        const value_20: f32 = @as(f32, @as(f64, @bitCast(@as(u64, 4609434218613702656))));

                        break :block_438 block_434: {
                            const operand_427 = (state_417).source;
                            const operand_428 = ((state_417).index + @as(u64, 1));
                            const operand_429 = (block_433: {
                                const operand_430 = (state_417).result;
                                const operand_432 = block_431: {
                                    break :block_431 value_20;
                                };

                                _ = (try ((std).math).add(usize, (operand_430).len, 1));

                                if ((!state_capacity_started_426)) {
                                    (try (state_capacity_425).ensureTotalCapacityPrecise(allocator, ((operand_424).source).len));

                                    (try (state_capacity_425).appendSlice(allocator, operand_430));

                                    state_capacity_started_426 = true;
                                } else {
                                    ((state_capacity_425).items).len = (operand_430).len;
                                }

                                (try (state_capacity_425).append(allocator, operand_432));

                                break :block_433 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_425).items, {}, null, });
                            }).@"0";

                            break :block_434 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_428, .result = operand_429, .source = operand_427, });
                        };
                    };
                }

                var state_owned_439: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_439);

                if (state_capacity_started_426) {
                    ((state_capacity_425).items).len = ((state_417).result).len;

                    state_owned_439 = (try (state_capacity_425).toOwnedSlice(allocator));
                }

                if (state_capacity_started_426) {
                    state_417 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_417).index, .result = state_owned_439, .source = (state_417).source, };
                }

                break :block_440 (state_417).result;
            };
        };
        const operand_442 = block_469: {
            const value_23: []const f32 = in;

            break :block_469 block_468: {
                const operand_450 = block_449: {
                    const operand_444 = block_445: {
                        break :block_445 value_23;
                    };
                    const operand_446 = @as(u64, 0);
                    const operand_447 = block_448: {
                        break :block_448 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_449 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_446, .result = operand_447, .source = operand_444, });
                };

                var state_capacity_451: (std).ArrayList(f32) = .empty;

                var state_capacity_started_452 = false;

                defer (state_capacity_451).deinit(allocator);

                var state_443: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_450;

                while (((state_443).index < @as(u64, ((state_443).source).len))) {
                    state_443 = block_466: {
                        const value_26: f32 = block_465: {
                            const operand_463 = (state_443).source;
                            const operand_464 = (state_443).index;

                            if ((operand_464 >= (operand_463).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_465 (operand_463)[@intCast(operand_464)];
                        };
                        const value_22: f32 = block_462: {
                            break :block_462 value_26;
                        };
                        const value_27: f32 = (block_461: {
                            break :block_461 value_22;
                        } + @as(f32, @as(f64, @bitCast(@as(u64, 4609434218613702656)))));

                        break :block_466 block_460: {
                            const operand_453 = (state_443).source;
                            const operand_454 = ((state_443).index + @as(u64, 1));
                            const operand_455 = (block_459: {
                                const operand_456 = (state_443).result;
                                const operand_458 = block_457: {
                                    break :block_457 value_27;
                                };

                                _ = (try ((std).math).add(usize, (operand_456).len, 1));

                                if ((!state_capacity_started_452)) {
                                    (try (state_capacity_451).ensureTotalCapacityPrecise(allocator, ((operand_450).source).len));

                                    (try (state_capacity_451).appendSlice(allocator, operand_456));

                                    state_capacity_started_452 = true;
                                } else {
                                    ((state_capacity_451).items).len = (operand_456).len;
                                }

                                (try (state_capacity_451).append(allocator, operand_458));

                                break :block_459 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_451).items, {}, null, });
                            }).@"0";

                            break :block_460 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_454, .result = operand_455, .source = operand_453, });
                        };
                    };
                }

                var state_owned_467: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_467);

                if (state_capacity_started_452) {
                    ((state_capacity_451).items).len = ((state_443).result).len;

                    state_owned_467 = (try (state_capacity_451).toOwnedSlice(allocator));
                }

                if (state_capacity_started_452) {
                    state_443 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_443).index, .result = state_owned_467, .source = (state_443).source, };
                }

                break :block_468 (state_443).result;
            };
        };
        const operand_470 = block_497: {
            const value_30: []const f32 = in;

            break :block_497 block_496: {
                const operand_478 = block_477: {
                    const operand_472 = block_473: {
                        break :block_473 value_30;
                    };
                    const operand_474 = @as(u64, 0);
                    const operand_475 = block_476: {
                        break :block_476 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_477 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_474, .result = operand_475, .source = operand_472, });
                };

                var state_capacity_479: (std).ArrayList(f32) = .empty;

                var state_capacity_started_480 = false;

                defer (state_capacity_479).deinit(allocator);

                var state_471: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_478;

                while (((state_471).index < @as(u64, ((state_471).source).len))) {
                    state_471 = block_494: {
                        const value_33: f32 = block_493: {
                            const operand_491 = (state_471).source;
                            const operand_492 = (state_471).index;

                            if ((operand_492 >= (operand_491).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_493 (operand_491)[@intCast(operand_492)];
                        };
                        const value_29: f32 = block_490: {
                            break :block_490 value_33;
                        };
                        const value_34: f32 = (@as(f32, @as(f64, @bitCast(@as(u64, 4609434218613702656)))) - block_489: {
                            break :block_489 value_29;
                        });

                        break :block_494 block_488: {
                            const operand_481 = (state_471).source;
                            const operand_482 = ((state_471).index + @as(u64, 1));
                            const operand_483 = (block_487: {
                                const operand_484 = (state_471).result;
                                const operand_486 = block_485: {
                                    break :block_485 value_34;
                                };

                                _ = (try ((std).math).add(usize, (operand_484).len, 1));

                                if ((!state_capacity_started_480)) {
                                    (try (state_capacity_479).ensureTotalCapacityPrecise(allocator, ((operand_478).source).len));

                                    (try (state_capacity_479).appendSlice(allocator, operand_484));

                                    state_capacity_started_480 = true;
                                } else {
                                    ((state_capacity_479).items).len = (operand_484).len;
                                }

                                (try (state_capacity_479).append(allocator, operand_486));

                                break :block_487 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_479).items, {}, null, });
                            }).@"0";

                            break :block_488 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_482, .result = operand_483, .source = operand_481, });
                        };
                    };
                }

                var state_owned_495: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_495);

                if (state_capacity_started_480) {
                    ((state_capacity_479).items).len = ((state_471).result).len;

                    state_owned_495 = (try (state_capacity_479).toOwnedSlice(allocator));
                }

                if (state_capacity_started_480) {
                    state_471 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_471).index, .result = state_owned_495, .source = (state_471).source, };
                }

                break :block_496 (state_471).result;
            };
        };
        const operand_498 = block_526: {
            const value_37: []const f32 = in;

            break :block_526 block_525: {
                const operand_506 = block_505: {
                    const operand_500 = block_501: {
                        break :block_501 value_37;
                    };
                    const operand_502 = @as(u64, 0);
                    const operand_503 = block_504: {
                        break :block_504 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_505 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_502, .result = operand_503, .source = operand_500, });
                };

                var state_capacity_507: (std).ArrayList(f32) = .empty;

                var state_capacity_started_508 = false;

                defer (state_capacity_507).deinit(allocator);

                var state_499: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_506;

                while (((state_499).index < @as(u64, ((state_499).source).len))) {
                    state_499 = block_523: {
                        const value_40: f32 = block_522: {
                            const operand_520 = (state_499).source;
                            const operand_521 = (state_499).index;

                            if ((operand_521 >= (operand_520).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_522 (operand_520)[@intCast(operand_521)];
                        };
                        const value_36: f32 = block_519: {
                            break :block_519 value_40;
                        };
                        const value_41: f32 = (block_517: {
                            break :block_517 value_36;
                        } * block_518: {
                            break :block_518 value_36;
                        });

                        break :block_523 block_516: {
                            const operand_509 = (state_499).source;
                            const operand_510 = ((state_499).index + @as(u64, 1));
                            const operand_511 = (block_515: {
                                const operand_512 = (state_499).result;
                                const operand_514 = block_513: {
                                    break :block_513 value_41;
                                };

                                _ = (try ((std).math).add(usize, (operand_512).len, 1));

                                if ((!state_capacity_started_508)) {
                                    (try (state_capacity_507).ensureTotalCapacityPrecise(allocator, ((operand_506).source).len));

                                    (try (state_capacity_507).appendSlice(allocator, operand_512));

                                    state_capacity_started_508 = true;
                                } else {
                                    ((state_capacity_507).items).len = (operand_512).len;
                                }

                                (try (state_capacity_507).append(allocator, operand_514));

                                break :block_515 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_507).items, {}, null, });
                            }).@"0";

                            break :block_516 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_510, .result = operand_511, .source = operand_509, });
                        };
                    };
                }

                var state_owned_524: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_524);

                if (state_capacity_started_508) {
                    ((state_capacity_507).items).len = ((state_499).result).len;

                    state_owned_524 = (try (state_capacity_507).toOwnedSlice(allocator));
                }

                if (state_capacity_started_508) {
                    state_499 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_499).index, .result = state_owned_524, .source = (state_499).source, };
                }

                break :block_525 (state_499).result;
            };
        };
        const operand_527 = block_554: {
            const value_44: []const f32 = in;

            break :block_554 block_553: {
                const operand_535 = block_534: {
                    const operand_529 = block_530: {
                        break :block_530 value_44;
                    };
                    const operand_531 = @as(u64, 0);
                    const operand_532 = block_533: {
                        break :block_533 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_534 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_531, .result = operand_532, .source = operand_529, });
                };

                var state_capacity_536: (std).ArrayList(f32) = .empty;

                var state_capacity_started_537 = false;

                defer (state_capacity_536).deinit(allocator);

                var state_528: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_535;

                while (((state_528).index < @as(u64, ((state_528).source).len))) {
                    state_528 = block_551: {
                        const value_47: f32 = block_550: {
                            const operand_548 = (state_528).source;
                            const operand_549 = (state_528).index;

                            if ((operand_549 >= (operand_548).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_550 (operand_548)[@intCast(operand_549)];
                        };
                        const value_43: f32 = block_547: {
                            break :block_547 value_47;
                        };
                        const value_48: f32 = (block_546: {
                            break :block_546 value_43;
                        } / @as(f32, @as(f64, @bitCast(@as(u64, 4611686018427387904)))));

                        break :block_551 block_545: {
                            const operand_538 = (state_528).source;
                            const operand_539 = ((state_528).index + @as(u64, 1));
                            const operand_540 = (block_544: {
                                const operand_541 = (state_528).result;
                                const operand_543 = block_542: {
                                    break :block_542 value_48;
                                };

                                _ = (try ((std).math).add(usize, (operand_541).len, 1));

                                if ((!state_capacity_started_537)) {
                                    (try (state_capacity_536).ensureTotalCapacityPrecise(allocator, ((operand_535).source).len));

                                    (try (state_capacity_536).appendSlice(allocator, operand_541));

                                    state_capacity_started_537 = true;
                                } else {
                                    ((state_capacity_536).items).len = (operand_541).len;
                                }

                                (try (state_capacity_536).append(allocator, operand_543));

                                break :block_544 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_536).items, {}, null, });
                            }).@"0";

                            break :block_545 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_539, .result = operand_540, .source = operand_538, });
                        };
                    };
                }

                var state_owned_552: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_552);

                if (state_capacity_started_537) {
                    ((state_capacity_536).items).len = ((state_528).result).len;

                    state_owned_552 = (try (state_capacity_536).toOwnedSlice(allocator));
                }

                if (state_capacity_started_537) {
                    state_528 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_528).index, .result = state_owned_552, .source = (state_528).source, };
                }

                break :block_553 (state_528).result;
            };
        };
        const operand_555 = block_584: {
            const value_51: []const f32 = in;

            break :block_584 block_583: {
                const operand_563 = block_562: {
                    const operand_557 = block_558: {
                        break :block_558 value_51;
                    };
                    const operand_559 = @as(u64, 0);
                    const operand_560 = block_561: {
                        break :block_561 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_562 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_559, .result = operand_560, .source = operand_557, });
                };

                var state_capacity_564: (std).ArrayList(f32) = .empty;

                var state_capacity_started_565 = false;

                defer (state_capacity_564).deinit(allocator);

                var state_556: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_563;

                while (((state_556).index < @as(u64, ((state_556).source).len))) {
                    state_556 = block_581: {
                        const value_54: f32 = block_580: {
                            const operand_578 = (state_556).source;
                            const operand_579 = (state_556).index;

                            if ((operand_579 >= (operand_578).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_580 (operand_578)[@intCast(operand_579)];
                        };
                        const value_50: f32 = block_577: {
                            break :block_577 value_54;
                        };
                        const value_55: f32 = ((block_574: {
                            break :block_574 value_50;
                        } * block_575: {
                            break :block_575 value_50;
                        }) + block_576: {
                            break :block_576 value_50;
                        });

                        break :block_581 block_573: {
                            const operand_566 = (state_556).source;
                            const operand_567 = ((state_556).index + @as(u64, 1));
                            const operand_568 = (block_572: {
                                const operand_569 = (state_556).result;
                                const operand_571 = block_570: {
                                    break :block_570 value_55;
                                };

                                _ = (try ((std).math).add(usize, (operand_569).len, 1));

                                if ((!state_capacity_started_565)) {
                                    (try (state_capacity_564).ensureTotalCapacityPrecise(allocator, ((operand_563).source).len));

                                    (try (state_capacity_564).appendSlice(allocator, operand_569));

                                    state_capacity_started_565 = true;
                                } else {
                                    ((state_capacity_564).items).len = (operand_569).len;
                                }

                                (try (state_capacity_564).append(allocator, operand_571));

                                break :block_572 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_564).items, {}, null, });
                            }).@"0";

                            break :block_573 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_567, .result = operand_568, .source = operand_566, });
                        };
                    };
                }

                var state_owned_582: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_582);

                if (state_capacity_started_565) {
                    ((state_capacity_564).items).len = ((state_556).result).len;

                    state_owned_582 = (try (state_capacity_564).toOwnedSlice(allocator));
                }

                if (state_capacity_started_565) {
                    state_556 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_556).index, .result = state_owned_582, .source = (state_556).source, };
                }

                break :block_583 (state_556).result;
            };
        };
        const operand_585 = block_613: {
            const value_58: []const f32 = in;

            break :block_613 block_612: {
                const operand_593 = block_592: {
                    const operand_587 = block_588: {
                        break :block_588 value_58;
                    };
                    const operand_589 = @as(u64, 0);
                    const operand_590 = block_591: {
                        break :block_591 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_592 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_589, .result = operand_590, .source = operand_587, });
                };

                var state_capacity_594: (std).ArrayList(f32) = .empty;

                var state_capacity_started_595 = false;

                defer (state_capacity_594).deinit(allocator);

                var state_586: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_593;

                while (((state_586).index < @as(u64, ((state_586).source).len))) {
                    state_586 = block_610: {
                        const value_61: f32 = block_609: {
                            const operand_607 = (state_586).source;
                            const operand_608 = (state_586).index;

                            if ((operand_608 >= (operand_607).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_609 (operand_607)[@intCast(operand_608)];
                        };
                        const value_57: f32 = block_606: {
                            break :block_606 value_61;
                        };
                        const value_62: f32 = ((block_604: {
                            break :block_604 value_57;
                        } + @as(f32, @as(f64, @bitCast(@as(u64, 4609434218613702656))))) * (block_605: {
                            break :block_605 value_57;
                        } - @as(f32, @as(f64, @bitCast(@as(u64, 4609434218613702656))))));

                        break :block_610 block_603: {
                            const operand_596 = (state_586).source;
                            const operand_597 = ((state_586).index + @as(u64, 1));
                            const operand_598 = (block_602: {
                                const operand_599 = (state_586).result;
                                const operand_601 = block_600: {
                                    break :block_600 value_62;
                                };

                                _ = (try ((std).math).add(usize, (operand_599).len, 1));

                                if ((!state_capacity_started_595)) {
                                    (try (state_capacity_594).ensureTotalCapacityPrecise(allocator, ((operand_593).source).len));

                                    (try (state_capacity_594).appendSlice(allocator, operand_599));

                                    state_capacity_started_595 = true;
                                } else {
                                    ((state_capacity_594).items).len = (operand_599).len;
                                }

                                (try (state_capacity_594).append(allocator, operand_601));

                                break :block_602 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_594).items, {}, null, });
                            }).@"0";

                            break :block_603 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_597, .result = operand_598, .source = operand_596, });
                        };
                    };
                }

                var state_owned_611: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_611);

                if (state_capacity_started_595) {
                    ((state_capacity_594).items).len = ((state_586).result).len;

                    state_owned_611 = (try (state_capacity_594).toOwnedSlice(allocator));
                }

                if (state_capacity_started_595) {
                    state_586 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_586).index, .result = state_owned_611, .source = (state_586).source, };
                }

                break :block_612 (state_586).result;
            };
        };
        const operand_614 = block_641: {
            const value_65: []const f32 = in;

            break :block_641 block_640: {
                const operand_622 = block_621: {
                    const operand_616 = block_617: {
                        break :block_617 value_65;
                    };
                    const operand_618 = @as(u64, 0);
                    const operand_619 = block_620: {
                        break :block_620 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_621 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_618, .result = operand_619, .source = operand_616, });
                };

                var state_capacity_623: (std).ArrayList(f32) = .empty;

                var state_capacity_started_624 = false;

                defer (state_capacity_623).deinit(allocator);

                var state_615: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_622;

                while (((state_615).index < @as(u64, ((state_615).source).len))) {
                    state_615 = block_638: {
                        const value_68: f32 = block_637: {
                            const operand_635 = (state_615).source;
                            const operand_636 = (state_615).index;

                            if ((operand_636 >= (operand_635).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_637 (operand_635)[@intCast(operand_636)];
                        };
                        const value_64: f32 = block_634: {
                            break :block_634 value_68;
                        };
                        const value_69: f32 = ((block_633: {
                            break :block_633 value_64;
                        } + @as(f32, @as(f64, @bitCast(@as(u64, 4715268809856909312))))) - @as(f32, @as(f64, @bitCast(@as(u64, 4715268809856909312)))));

                        break :block_638 block_632: {
                            const operand_625 = (state_615).source;
                            const operand_626 = ((state_615).index + @as(u64, 1));
                            const operand_627 = (block_631: {
                                const operand_628 = (state_615).result;
                                const operand_630 = block_629: {
                                    break :block_629 value_69;
                                };

                                _ = (try ((std).math).add(usize, (operand_628).len, 1));

                                if ((!state_capacity_started_624)) {
                                    (try (state_capacity_623).ensureTotalCapacityPrecise(allocator, ((operand_622).source).len));

                                    (try (state_capacity_623).appendSlice(allocator, operand_628));

                                    state_capacity_started_624 = true;
                                } else {
                                    ((state_capacity_623).items).len = (operand_628).len;
                                }

                                (try (state_capacity_623).append(allocator, operand_630));

                                break :block_631 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_623).items, {}, null, });
                            }).@"0";

                            break :block_632 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_626, .result = operand_627, .source = operand_625, });
                        };
                    };
                }

                var state_owned_639: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_639);

                if (state_capacity_started_624) {
                    ((state_capacity_623).items).len = ((state_615).result).len;

                    state_owned_639 = (try (state_capacity_623).toOwnedSlice(allocator));
                }

                if (state_capacity_started_624) {
                    state_615 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_615).index, .result = state_owned_639, .source = (state_615).source, };
                }

                break :block_640 (state_615).result;
            };
        };
        const operand_642 = block_671: {
            const value_72: []const f32 = in;

            break :block_671 block_670: {
                const operand_650 = block_649: {
                    const operand_644 = block_645: {
                        break :block_645 value_72;
                    };
                    const operand_646 = @as(u64, 0);
                    const operand_647 = block_648: {
                        break :block_648 (try (allocator).dupe(f32, (&[_]f32{})));
                    };

                    break :block_649 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_646, .result = operand_647, .source = operand_644, });
                };

                var state_capacity_651: (std).ArrayList(f32) = .empty;

                var state_capacity_started_652 = false;

                defer (state_capacity_651).deinit(allocator);

                var state_643: (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = operand_650;

                while (((state_643).index < @as(u64, ((state_643).source).len))) {
                    state_643 = block_668: {
                        const value_75: f32 = block_667: {
                            const operand_665 = (state_643).source;
                            const operand_666 = (state_643).index;

                            if ((operand_666 >= (operand_665).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_667 (operand_665)[@intCast(operand_666)];
                        };
                        const value_71: f32 = block_664: {
                            break :block_664 value_75;
                        };
                        const value_76: f32 = (if ((block_661: {
                            break :block_661 value_71;
                        } < @as(f32, @as(f64, @bitCast(@as(u64, 0)))))) (-block_662: {
                            break :block_662 value_71;
                        }) else block_663: {
                            break :block_663 value_71;
                        });

                        break :block_668 block_660: {
                            const operand_653 = (state_643).source;
                            const operand_654 = ((state_643).index + @as(u64, 1));
                            const operand_655 = (block_659: {
                                const operand_656 = (state_643).result;
                                const operand_658 = block_657: {
                                    break :block_657 value_76;
                                };

                                _ = (try ((std).math).add(usize, (operand_656).len, 1));

                                if ((!state_capacity_started_652)) {
                                    (try (state_capacity_651).ensureTotalCapacityPrecise(allocator, ((operand_650).source).len));

                                    (try (state_capacity_651).appendSlice(allocator, operand_656));

                                    state_capacity_started_652 = true;
                                } else {
                                    ((state_capacity_651).items).len = (operand_656).len;
                                }

                                (try (state_capacity_651).append(allocator, operand_658));

                                break :block_659 @as((zx_abi).value_zx_type_a4dbe298e3f67b60605d28427f13eba1fc966ddda59256d3a38b4b6b9f4fe72b_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_651).items, {}, null, });
                            }).@"0";

                            break :block_660 @as((zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = operand_654, .result = operand_655, .source = operand_653, });
                        };
                    };
                }

                var state_owned_669: []const f32 = (&[_]f32{});

                errdefer (allocator).free(state_owned_669);

                if (state_capacity_started_652) {
                    ((state_capacity_651).items).len = ((state_643).result).len;

                    state_owned_669 = (try (state_capacity_651).toOwnedSlice(allocator));
                }

                if (state_capacity_started_652) {
                    state_643 = (zx_abi).value_zx_type_17a857e1360e6a21724f33aff464322a44b51df77429199883cfe97a2681388d_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .index = (state_643).index, .result = state_owned_669, .source = (state_643).source, };
                }

                break :block_670 (state_643).result;
            };
        };

        break :block_672 @as((zx_abi).value_zx_type_3cd3b6b687a2a82c40da7a8221473fc779db0a84159857bc4bf80a6f1598e9de_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d, (zx_abi).value_zx_type_3cd3b6b687a2a82c40da7a8221473fc779db0a84159857bc4bf80a6f1598e9de_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d{ .identity = operand_360, .negative = operand_388, .broadcast = operand_416, .add = operand_442, .subtract = operand_470, .multiply = operand_498, .divide = operand_527, .chain = operand_555, .grouped = operand_585, .cancellation = operand_614, .conditional = operand_642, });
    };
}

