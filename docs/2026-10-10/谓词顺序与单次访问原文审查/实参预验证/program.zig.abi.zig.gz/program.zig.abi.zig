pub const zx_type_12 = struct {
    index: u64,
    item: i64,
    source: []const i64,
};

pub const zx_type_13 = struct {
    items: []const i64,
};

pub const zx_type_14 = struct {
    index: u64,
    result: bool,
    source: []const i64,
};

pub const value_zx_type_13_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = struct {
    items: []const i64,
    zx_origin: ?*const zx_type_13 = null,
};

pub const value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: bool,
    source: []const i64,
    zx_origin: ?*const zx_type_14 = null,
};

pub const native_by_identity = struct {
    pub const @"zig:zxc_native_2e1607573f51bbdb442a1a886cc548914f341cf4348e0b8d2aa49cfdfb33c7fb" = struct {
        pub const source = struct {
            pub const Input = []const i64;
            pub const Output = []const i64;
            pub const InputValue = []const i64;
            pub const OutputValue = []const i64;
        };
        pub const visit = struct {
            pub const Input = *const zx_type_12;
            pub const Output = bool;
            pub const InputValue = zx_type_12;
            pub const OutputValue = bool;
        };
        pub const context = struct {
            pub const Input = void;
            pub const Output = void;
            pub const InputValue = void;
            pub const OutputValue = void;
        };
    };
};

pub const layouts_by_identity = struct {
    pub const @"zig:zxc_native_2e1607573f51bbdb442a1a886cc548914f341cf4348e0b8d2aa49cfdfb33c7fb" = struct {
    };
};

pub const native = struct {
    pub const @"zig:host" = (native_by_identity).@"zig:zxc_native_2e1607573f51bbdb442a1a886cc548914f341cf4348e0b8d2aa49cfdfb33c7fb";
};

pub const layouts = struct {
    pub const @"zig:host" = (layouts_by_identity).@"zig:zxc_native_2e1607573f51bbdb442a1a886cc548914f341cf4348e0b8d2aa49cfdfb33c7fb";
};

