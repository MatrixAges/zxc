pub const zx_type_11 = enum { Root, Dead, UpperInput, UpperOutput, Underscore, Allocator, Async, Await, Break, Cancel, Case, Concurrent, Const, Declare, Default, Delete, Do, Else, Ensures, Enum, Export, False, For, From, Function, If, Import, In, Insert, Io, Let, Loop, Match, New, Next, Null, Process, QueryMany, QueryOne, Requires, Return, Store, Switch, Throw, Throws, Transaction, True, Try, Type, Update, Var, While, };

pub const zx_type_12 = enum { Identifier, Keyword, Number, String, Template, Punctuation, Eof, };

pub const zx_type_13 = enum { None, OpenBrace, CloseBrace, OpenParen, CloseParen, OpenBracket, CloseBracket, Colon, Semicolon, Comma, Dot, Question, Plus, Minus, Star, Slash, Percent, Less, Greater, Assign, Not, Ampersand, Pipe, Arrow, Equal, NotEqual, LessEqual, GreaterEqual, Coalesce, And, Or, Spread, };

pub const zx_type_14 = struct {
    end: u64,
    start: u64,
};

pub const zx_type_15 = struct {
    dollar: bool,
    kind: zx_type_12,
    line_break: bool,
    span: *const zx_type_14,
    symbol: zx_type_13,
    word: zx_type_11,
};

pub const zx_type_16 = enum { Integer, FractionStart, Fraction, ExponentStart, ExponentDigits, Done, };

pub const zx_type_17 = struct {
    end: u64,
    last_byte: u8,
    phase: zx_type_16,
    separators_valid: bool,
};

pub const zx_type_18 = struct {
    diagnostic: []const u8,
    end: u64,
};

pub const zx_type_19 = enum { Idle, Identifier, Number, String, StringEscape, LineComment, BlockComment, Template, TemplateEscape, Interpolation, InterpolationString, InterpolationStringEscape, InterpolationLineComment, InterpolationBlockComment, };

pub const zx_type_20 = struct {
    code: []const u8,
    end: u64,
    message: []const u8,
    start: u64,
};

pub const zx_type_21 = struct {
    braces: u64,
    depth: u64,
    mode: zx_type_19,
    start: u64,
};

pub const zx_type_25 = struct {
    ahead_one: u8,
    ahead_two: u8,
    braces: u64,
    comments: []const *const zx_type_14,
    depth: u64,
    diagnostic: *const zx_type_20,
    dollar: bool,
    frames: []const *const zx_type_21,
    keyword_state: u64,
    line_break: bool,
    mode: zx_type_19,
    number: *const zx_type_17,
    offset: u64,
    skip_until: u64,
    source_length: u64,
    start: u64,
    symbol: zx_type_13,
    tokens: []const *const zx_type_15,
    warmed: u8,
};

pub const zx_type_26 = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    state: *const zx_type_25,
};

pub const zx_type_27 = struct {
    comments: []const *const zx_type_14,
    diagnostic: *const zx_type_20,
    tokens: []const *const zx_type_15,
};

pub const zx_type_28 = enum { Named, Object, Optional, List, Tuple, Application, };

pub const zx_type_29 = enum { Start, Name, Suffix, ListEnd, Field, FieldOptional, FieldColon, TupleItem, Done, };

pub const zx_type_30 = struct {
    child: u64,
    count: u64,
    head: u64,
    kind: zx_type_28,
    name: *const zx_type_14,
};

pub const zx_type_31 = struct {
    name: *const zx_type_14,
    previous: u64,
    value: u64,
};

pub const zx_type_32 = struct {
    previous: u64,
    value: u64,
};

pub const zx_type_34 = struct {
    fields: []const u64,
    heads: []const u64,
    items: []const u64,
};

pub const zx_type_38 = struct {
    fields: []const *const zx_type_31,
    items: []const *const zx_type_32,
    nodes: []const *const zx_type_30,
};

pub const zx_type_39 = struct {
    count: u64,
    field: *const zx_type_14,
    head: u64,
    kind: zx_type_28,
    name: *const zx_type_14,
    optional: bool,
};

pub const zx_type_40 = struct {
    depth: u64,
    diagnostic: *const zx_type_20,
    index: u64,
    name: *const zx_type_14,
    phase: zx_type_29,
    result: u64,
    start: u64,
    token: *const zx_type_15,
};

pub const zx_type_42 = struct {
    control: *const zx_type_40,
    frames: []const *const zx_type_39,
    tree: *const zx_type_38,
};

pub const zx_type_43 = enum { Start, Kind, Name, Open, Value, Member, Separator, Done, };

pub const zx_type_44 = struct {
    count: u64,
    enumeration: bool,
    first: u64,
    name: *const zx_type_14,
    span: *const zx_type_14,
    value: u64,
};

pub const zx_type_45 = struct {
    count: u64,
    depth: u64,
    diagnostic: *const zx_type_20,
    enumeration: bool,
    first: u64,
    index: u64,
    last_end: u64,
    name: *const zx_type_14,
    opening: u64,
    opening_index: u64,
    phase: zx_type_43,
    start: u64,
    token: *const zx_type_15,
    type_diagnostic: bool,
};

pub const zx_type_47 = struct {
    control: *const zx_type_45,
    declarations: []const *const zx_type_44,
    members: []const *const zx_type_14,
    types: *const zx_type_42,
};

pub const zx_type_48 = enum { Named, Object, Optional, List, Tuple, Enumeration, Application, };

pub const zx_type_49 = struct {
    end: u64,
    start: u64,
    text: []const u8,
};

pub const zx_type_50 = struct {
    enumeration: bool,
    index: u64,
};

pub const zx_type_51 = struct {
    child: *const zx_type_50,
    count: u64,
    kind: zx_type_48,
    name: *const zx_type_49,
    position: u64,
};

pub const zx_type_52 = struct {
    name: *const zx_type_49,
    next: u64,
    value: *const zx_type_50,
};

pub const zx_type_53 = struct {
    next: u64,
    value: *const zx_type_50,
};

pub const zx_type_54 = struct {
    name: *const zx_type_49,
    value: *const zx_type_50,
};

pub const zx_type_55 = struct {
    count: u64,
    first: u64,
};

pub const zx_type_62 = struct {
    declarations: []const *const zx_type_54,
    enumerations: []const *const zx_type_55,
    fields: []const *const zx_type_52,
    items: []const *const zx_type_53,
    members: []const *const zx_type_49,
    nodes: []const *const zx_type_51,
};

pub const zx_type_64 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_44,
    members: []const *const zx_type_14,
    order: *const zx_type_34,
    types: *const zx_type_38,
};

pub const zx_type_66 = struct {
    indexed: *const zx_type_64,
    native: ?*const zx_type_62,
};

pub const zx_type_67 = enum { Declarations, Start, Declare, Function, Name, Open, Inject, Parameter, Colon, ParameterType, Separator, OutputColon, OutputType, Throws, ErrorOpen, ErrorName, ErrorSeparator, Concurrent, End, Done, };

pub const zx_type_68 = struct {
    allocator_argument: bool,
    concurrent: bool,
    count: u64,
    error_count: u64,
    errors_present: bool,
    fallible: bool,
    first_error: u64,
    first_parameter: u64,
    io_argument: bool,
    name: *const zx_type_14,
    output: u64,
    process_argument: bool,
};

pub const zx_type_69 = struct {
    name: *const zx_type_14,
    value: u64,
};

pub const zx_type_70 = struct {
    current: *const zx_type_68,
    diagnostic: *const zx_type_20,
    index: u64,
    injected: u64,
    parameter: *const zx_type_14,
    phase: zx_type_67,
};

pub const zx_type_73 = struct {
    control: *const zx_type_70,
    declarations: *const zx_type_47,
    errors: []const *const zx_type_14,
    functions: []const *const zx_type_68,
    lexed: *const zx_type_27,
    parameters: []const *const zx_type_69,
};

pub const zx_type_74 = struct {
    declarations: []const *const zx_type_44,
    diagnostic: *const zx_type_20,
    errors: []const *const zx_type_14,
    functions: []const *const zx_type_68,
    members: []const *const zx_type_14,
    parameters: []const *const zx_type_69,
    type_order: *const zx_type_34,
    types: *const zx_type_38,
};

pub const zx_type_75 = struct {
    count: u64,
    first: u64,
    parameters: []const *const zx_type_69,
    source: *const zx_type_66,
};

pub const zx_type_79 = struct {
    aliases: []const ?[]const u8,
    enumerations: []const bool,
    nodes: []const u64,
};

pub const zx_type_80 = struct {
    names: []const ?[]const u8,
    source: *const zx_type_66,
    valid: bool,
    work: *const zx_type_79,
};

pub const zx_type_81 = struct {
    names: []const ?[]const u8,
    valid: bool,
};

pub const zx_type_82 = struct { []const u8, u64, u64, };

pub const zx_type_83 = struct {
    source: []const u8,
    span: *const zx_type_14,
};

pub const zx_type_84 = struct {
    index: u64,
    source: *const zx_type_66,
};

pub const zx_type_85 = struct {
    limit: u64,
    name: []const u8,
    source: *const zx_type_66,
};

pub const zx_type_86 = struct {
    found: bool,
    index: u64,
};

pub const zx_type_87 = struct {
    reference: *const zx_type_50,
    source: *const zx_type_66,
};

pub const zx_type_88 = struct {
    position: u64,
    source: *const zx_type_66,
};

pub const zx_type_89 = struct {
    left: []const u8,
    right: []const u8,
};

pub const zx_type_90 = struct {
    count: u64,
    object: bool,
    position: u64,
    source: *const zx_type_66,
};

pub const zx_type_91 = struct {
    count: u64,
    object: bool,
    position: u64,
    state: *const zx_type_80,
};

pub const zx_type_92 = struct {
    aliases: []const ?[]const u8,
    enumerations: []const bool,
    input: *const zx_type_75,
    nodes: []const u64,
    remaining: u64,
};

pub const zx_type_93 = struct { []const u64, void, };

pub const zx_type_94 = struct { []const bool, void, };

pub const zx_type_95 = struct { []const ?[]const u8, void, };

pub const zx_type_96 = struct { []const u8, []const u8, };

pub const zx_type_97 = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    selected: u64,
    source: *const zx_type_66,
};

pub const zx_type_98 = struct {
    active: bool,
    reference: *const zx_type_50,
    source: *const zx_type_66,
    valid: bool,
};

pub const zx_type_99 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    limit: u64,
    right: []const u8,
};

pub const zx_type_101 = struct {
    index: u64,
    input: *const zx_type_90,
    names: []const []const u8,
    position: u64,
    positions: []const u64,
};

pub const zx_type_102 = struct { []const []const u8, void, };

pub const zx_type_103 = struct {
    building: bool,
    count: u64,
    names: []const []const u8,
    positions: []const u64,
    remaining: u64,
    root: u64,
    sifting: bool,
};

pub const zx_type_104 = struct {
    object: bool,
    positions: []const u64,
    remaining: u64,
    state: *const zx_type_80,
};

pub const zx_type_106 = struct { []const u64, ?u64, };

pub const zx_type_108 = struct { []const bool, ?bool, };

pub const zx_type_110 = struct { []const ?[]const u8, ??[]const u8, };

pub const zx_type_111 = struct { *const zx_type_75, };

pub const zx_type_112 = struct { *const zx_type_75, *const zx_type_80, };

pub const zx_type_113 = struct { *const zx_type_75, *const zx_type_80, *const zx_type_81, };

pub const value_zx_type_17_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    end: u64,
    last_byte: u8,
    phase: zx_type_16,
    separators_valid: bool,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    diagnostic: []const u8,
    end: u64,
    zx_origin: ?*const zx_type_18 = null,
};

pub const value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    code: []const u8,
    end: u64,
    message: []const u8,
    start: u64,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_25_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955 = struct {
    ahead_one: u8,
    ahead_two: u8,
    braces: u64,
    comments: []const *const zx_type_14,
    depth: u64,
    diagnostic: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    dollar: bool,
    frames: []const *const zx_type_21,
    keyword_state: u64,
    line_break: bool,
    mode: zx_type_19,
    number: value_zx_type_17_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    offset: u64,
    skip_until: u64,
    source_length: u64,
    start: u64,
    symbol: zx_type_13,
    tokens: []const *const zx_type_15,
    warmed: u8,
    zx_origin: ?*const zx_type_25 = null,
};

pub const value_zx_type_26_6864d01f2cdb65ac396bbf72151d3cc46cc2d575ab41fc4f09cde10c9e6a568c = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    state: value_zx_type_25_365095b2e4102717a2ad1cafad625c26abf7b31bf03c46b384a7c46916802955,
    zx_origin: ?*const zx_type_26 = null,
};

pub const value_zx_type_27_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = struct {
    comments: []const *const zx_type_14,
    diagnostic: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    tokens: []const *const zx_type_15,
    zx_origin: ?*const zx_type_27 = null,
};

pub const value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    fields: []const u64,
    heads: []const u64,
    items: []const u64,
    zx_origin: ?*const zx_type_34 = null,
};

pub const value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    fields: []const *const zx_type_31,
    items: []const *const zx_type_32,
    nodes: []const *const zx_type_30,
    zx_origin: ?*const zx_type_38 = null,
};

pub const value_zx_type_40_4b4ea4009453ea5e4d3d79e2158cdc223b3d2c1404741f1be6d92e28595818e4 = struct {
    depth: u64,
    diagnostic: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    index: u64,
    name: *const zx_type_14,
    phase: zx_type_29,
    result: u64,
    start: u64,
    token: *const zx_type_15,
    zx_origin: ?*const zx_type_40 = null,
};

pub const value_zx_type_42_db7570c1a55b3d0290113419e01ef4c6880014f077ed48f5b1ab9774bac9d7ce = struct {
    control: value_zx_type_40_4b4ea4009453ea5e4d3d79e2158cdc223b3d2c1404741f1be6d92e28595818e4,
    frames: []const *const zx_type_39,
    tree: value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_42 = null,
};

pub const value_zx_type_45_9ca813e01b11b7c501ba04f1348219dca11711a58782910ea92dabe63f7cbea2 = struct {
    count: u64,
    depth: u64,
    diagnostic: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    enumeration: bool,
    first: u64,
    index: u64,
    last_end: u64,
    name: *const zx_type_14,
    opening: u64,
    opening_index: u64,
    phase: zx_type_43,
    start: u64,
    token: *const zx_type_15,
    type_diagnostic: bool,
    zx_origin: ?*const zx_type_45 = null,
};

pub const value_zx_type_47_eda4e2b18226103f7356fe8cf64ab9bb0f9f51c3d4661c599d2c29c5b8b91363 = struct {
    control: value_zx_type_45_9ca813e01b11b7c501ba04f1348219dca11711a58782910ea92dabe63f7cbea2,
    declarations: []const *const zx_type_44,
    members: []const *const zx_type_14,
    types: value_zx_type_42_db7570c1a55b3d0290113419e01ef4c6880014f077ed48f5b1ab9774bac9d7ce,
    zx_origin: ?*const zx_type_47 = null,
};

pub const value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    declarations: []const *const zx_type_54,
    enumerations: []const *const zx_type_55,
    fields: []const *const zx_type_52,
    items: []const *const zx_type_53,
    members: []const *const zx_type_49,
    nodes: []const *const zx_type_51,
    zx_origin: ?*const zx_type_62 = null,
};

pub const value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_44,
    members: []const *const zx_type_14,
    order: value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_64 = null,
};

pub const value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203 = struct {
    indexed: value_zx_type_64_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97,
    native: ?value_zx_type_62_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_66 = null,
};

pub const value_zx_type_70_53843cfacaa3f9899c3b0b8cb3558dd9fcf4a0f43263e76a9210b1feff9fafe7 = struct {
    current: *const zx_type_68,
    diagnostic: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    index: u64,
    injected: u64,
    parameter: *const zx_type_14,
    phase: zx_type_67,
    zx_origin: ?*const zx_type_70 = null,
};

pub const value_zx_type_73_8fe59e2dd03023159d131f29ffaebe43ed902ad4a9069d0ba6459f359591423b = struct {
    control: value_zx_type_70_53843cfacaa3f9899c3b0b8cb3558dd9fcf4a0f43263e76a9210b1feff9fafe7,
    declarations: value_zx_type_47_eda4e2b18226103f7356fe8cf64ab9bb0f9f51c3d4661c599d2c29c5b8b91363,
    errors: []const *const zx_type_14,
    functions: []const *const zx_type_68,
    lexed: value_zx_type_27_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb,
    parameters: []const *const zx_type_69,
    zx_origin: ?*const zx_type_73 = null,
};

pub const value_zx_type_74_fe9e06a8fdc90727154f5c36eeed504f3f3f85d06401ca34a827b8e236267aa3 = struct {
    declarations: []const *const zx_type_44,
    diagnostic: value_zx_type_20_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    errors: []const *const zx_type_14,
    functions: []const *const zx_type_68,
    members: []const *const zx_type_14,
    parameters: []const *const zx_type_69,
    type_order: value_zx_type_34_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_38_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_74 = null,
};

pub const value_zx_type_75_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0 = struct {
    count: u64,
    first: u64,
    parameters: []const *const zx_type_69,
    source: value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_75 = null,
};

pub const value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    aliases: []const ?[]const u8,
    enumerations: []const bool,
    nodes: []const u64,
    zx_origin: ?*const zx_type_79 = null,
};

pub const value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654 = struct {
    names: []const ?[]const u8,
    source: value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    valid: bool,
    work: value_zx_type_79_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_80 = null,
};

pub const value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const ?[]const u8,
    valid: bool,
    zx_origin: ?*const zx_type_81 = null,
};

pub const value_zx_type_83_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    source: []const u8,
    span: *const zx_type_14,
    zx_origin: ?*const zx_type_83 = null,
};

pub const value_zx_type_84_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    index: u64,
    source: value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_84 = null,
};

pub const value_zx_type_85_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b = struct {
    limit: u64,
    name: []const u8,
    source: value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_85 = null,
};

pub const value_zx_type_86_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    index: u64,
    zx_origin: ?*const zx_type_86 = null,
};

pub const value_zx_type_87_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    reference: *const zx_type_50,
    source: value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_87 = null,
};

pub const value_zx_type_88_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    position: u64,
    source: value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_88 = null,
};

pub const value_zx_type_89_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_89 = null,
};

pub const value_zx_type_90_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0 = struct {
    count: u64,
    object: bool,
    position: u64,
    source: value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_90 = null,
};

pub const value_zx_type_91_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = struct {
    count: u64,
    object: bool,
    position: u64,
    state: value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654,
    zx_origin: ?*const zx_type_91 = null,
};

pub const value_zx_type_92_99d89bf6dd190d581b03ed02e2754a99b9cfe748c1f871278e17714ff3bb1dba = struct {
    aliases: []const ?[]const u8,
    enumerations: []const bool,
    input: value_zx_type_75_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0,
    nodes: []const u64,
    remaining: u64,
    zx_origin: ?*const zx_type_92 = null,
};

pub const value_zx_type_93_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_93, };

pub const value_zx_type_94_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, void, ?*const zx_type_94, };

pub const value_zx_type_95_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?[]const u8, void, ?*const zx_type_95, };

pub const value_zx_type_96_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, []const u8, ?*const zx_type_96, };

pub const value_zx_type_97_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    selected: u64,
    source: value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_97 = null,
};

pub const value_zx_type_98_afc6f36ce53e4c115e83f77d717fc69695f9c11e83c4bc8f9529fe173b294c15 = struct {
    active: bool,
    reference: *const zx_type_50,
    source: value_zx_type_66_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    valid: bool,
    zx_origin: ?*const zx_type_98 = null,
};

pub const value_zx_type_99_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    limit: u64,
    right: []const u8,
    zx_origin: ?*const zx_type_99 = null,
};

pub const value_zx_type_101_35a1a5cf7455798cf4b9a36f33d2e0d8c8984c15f640a5661b782d9513fa15c6 = struct {
    index: u64,
    input: value_zx_type_90_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0,
    names: []const []const u8,
    position: u64,
    positions: []const u64,
    zx_origin: ?*const zx_type_101 = null,
};

pub const value_zx_type_102_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, void, ?*const zx_type_102, };

pub const value_zx_type_103_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    building: bool,
    count: u64,
    names: []const []const u8,
    positions: []const u64,
    remaining: u64,
    root: u64,
    sifting: bool,
    zx_origin: ?*const zx_type_103 = null,
};

pub const value_zx_type_104_649a0e8e47c50d016b5c6131dd4164aa7f9794f3e4e556effd8965aea1dc90be = struct {
    object: bool,
    positions: []const u64,
    remaining: u64,
    state: value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654,
    zx_origin: ?*const zx_type_104 = null,
};

pub const value_zx_type_106_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u64, ?u64, ?*const zx_type_106, };

pub const value_zx_type_108_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const bool, ?bool, ?*const zx_type_108, };

pub const value_zx_type_110_0ead5c3e32ca21061f2b402fc0323ef9d029d1f9d6cf2ad57aaa7d0abfe63cec = struct { []const ?[]const u8, ??[]const u8, ?*const zx_type_110, };

pub const value_zx_type_111_19efa7f5cf930f40b6f6856336c16b6715e791f780e591754c7b4886e3ee3582 = struct { value_zx_type_75_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0, ?*const zx_type_111, };

pub const value_zx_type_112_b03a131641cf8ddc01c620cf64f4f81920caf9f38625c793ebdac5dee80701d2 = struct { value_zx_type_75_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0, value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, ?*const zx_type_112, };

pub const value_zx_type_113_4d0f95055f27488e67085419c6960d869e6e1a334913768b2af565fcba20e869 = struct { value_zx_type_75_cbd089ef3ab97c2eb4b6cfedd85013a60083fee17fbf303ab7db7e37b752b8c0, value_zx_type_80_0a90242482c59a37fe1e35bf620dc1e86c0b3bfaa51ca7bce3d27e830f933654, value_zx_type_81_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, ?*const zx_type_113, };

pub const native = struct {
    pub const @"std:encoding" = struct {
        pub const encodeBase64 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeBase64 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const encodeHex = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeHex = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const encodeUtf8 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeUtf8 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const sliceBytes = struct {
            pub const Input = *const zx_type_82;
            pub const Output = []const u8;
            pub const InputValue = zx_type_82;
            pub const OutputValue = []const u8;
        };
    };
};

pub const layouts = struct {
    pub const @"std:encoding" = struct {
    };
};

