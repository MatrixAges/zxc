const std = @import("std");

const zx_type_11 = struct {
    end: u64,
    parent: bool,
    start: u64,
};

const zx_type_13 = struct {
    dots: bool,
    offset: u64,
    segments: []const *const zx_type_11,
    start: u64,
};

const zx_type_14 = struct {
    parents: u64,
    segments: []const *const zx_type_11,
};

const zx_type_15 = struct {
    byte: u8,
    state: *const zx_type_13,
};

const zx_type_17 = struct {
    end: u64,
    parent: bool,
    start: u64,
    state: *const zx_type_14,
};

const zx_type_18 = struct {
    segments: []const *const zx_type_11,
    valid: bool,
};

const zx_type_19 = struct { []const *const zx_type_11, void, };

const zx_type_20 = struct {
    index: u64,
    result: *const zx_type_13,
    source: []const u8,
};

const zx_type_21 = struct {
    index: u64,
    result: *const zx_type_14,
    source: []const *const zx_type_11,
};

const zx_type_22 = struct { []const u8, };

const zx_type_23 = struct { []const u8, []const *const zx_type_11, };

const zx_type_24 = struct { []const u8, []const *const zx_type_11, *const zx_type_18, };

const value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    dots: bool,
    offset: u64,
    segments: []const *const zx_type_11,
    start: u64,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    parents: u64,
    segments: []const *const zx_type_11,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_15_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = struct {
    byte: u8,
    state: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_15 = null,
};

const value_zx_type_17_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    end: u64,
    parent: bool,
    start: u64,
    state: value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_17 = null,
};

const value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    segments: []const *const zx_type_11,
    valid: bool,
    zx_origin: ?*const zx_type_18 = null,
};

const value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_11, void, ?*const zx_type_19, };

const value_zx_type_20_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = struct {
    index: u64,
    result: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    source: []const u8,
    zx_origin: ?*const zx_type_20 = null,
};

const value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    index: u64,
    result: value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    source: []const *const zx_type_11,
    zx_origin: ?*const zx_type_21 = null,
};

const value_zx_type_22_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = struct { []const u8, ?*const zx_type_22, };

const value_zx_type_23_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, []const *const zx_type_11, ?*const zx_type_23, };

const value_zx_type_24_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct { []const u8, []const *const zx_type_11, value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, ?*const zx_type_24, };

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .object, .fields = .{ .end = zx_shape_5, .parent = zx_shape_1, .start = zx_shape_5, }, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_11, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .dots = zx_shape_1, .offset = zx_shape_5, .segments = zx_shape_12, .start = zx_shape_5, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .parents = zx_shape_5, .segments = zx_shape_12, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .byte = zx_shape_2, .state = zx_shape_13, }, };

const zx_shape_16 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .end = zx_shape_5, .parent = zx_shape_1, .start = zx_shape_5, .state = zx_shape_14, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .segments = zx_shape_12, .valid = zx_shape_1, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_12, .@"1" = zx_shape_0, }, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_13, .source = zx_shape_16, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_14, .source = zx_shape_12, }, };

const zx_shape_22 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_16, }, };

const zx_shape_23 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_16, .@"1" = zx_shape_12, }, };

const zx_shape_24 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_16, .@"1" = zx_shape_12, .@"2" = zx_shape_18, }, };

pub const input_shape = zx_shape_16;

pub const output_shape = zx_shape_18;

pub const Input = []const u8;

pub const Output = *const zx_type_18;

fn function_0(allocator: ((std).mem).Allocator, in: *const zx_type_13) error{ OutOfMemory, Overflow, }!*const zx_type_13 {
    @setRuntimeSafety(true);

    const value_1: u64 = ((in).offset - (in).start);

    if (((value_1 == @as(u64, 0)) or ((in).dots and (value_1 == @as(u64, 1))))) {
        return in;
    }

    const value_2: []const *const zx_type_11 = (block_17: {
        const operand_8 = (in).segments;
        const operand_15 = block_14: {
            const operand_9 = (in).start;
            const operand_10 = (in).offset;
            const operand_11 = ((in).dots and (value_1 == @as(u64, 2)));

            break :block_14 block_13: {
                const operand_12 = (try (allocator).create(zx_type_11));

                (operand_12).* = @as(zx_type_11, zx_type_11{ .start = operand_9, .end = operand_10, .parent = operand_11, });

                break :block_13 @as(*const zx_type_11, operand_12);
            };
        };
        const operand_16 = (try (allocator).alloc(*const zx_type_11, (try ((std).math).add(usize, (operand_8).len, 1))));

        @memcpy((operand_16)[0..(operand_8).len], operand_8);

        (operand_16)[(operand_8).len] = operand_15;

        break :block_17 @as(zx_type_19, .{ operand_16, {}, });
    }).@"0";

    return block_7: {
        const operand_1 = (in).offset;
        const operand_2 = (in).start;
        const operand_3 = (in).dots;
        const operand_4 = value_2;

        break :block_7 block_6: {
            const operand_5 = (try (allocator).create(zx_type_13));

            (operand_5).* = @as(zx_type_13, zx_type_13{ .offset = operand_1, .start = operand_2, .dots = operand_3, .segments = operand_4, });

            break :block_6 @as(*const zx_type_13, operand_5);
        };
    };
}

fn function_0_value(allocator: ((std).mem).Allocator, in: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165) error{ OutOfMemory, Overflow, }!value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    const value_1: u64 = ((in).offset - (in).start);

    if (((block_35: {
        break :block_35 value_1;
    } == @as(u64, 0)) or ((in).dots and (block_36: {
        break :block_36 value_1;
    } == @as(u64, 1))))) {
        return in;
    }

    const value_2: []const *const zx_type_11 = (block_34: {
        const operand_24 = (in).segments;
        const operand_32 = block_31: {
            const operand_25 = (in).start;
            const operand_26 = (in).offset;
            const operand_27 = ((in).dots and (block_28: {
                break :block_28 value_1;
            } == @as(u64, 2)));

            break :block_31 block_30: {
                const operand_29 = (try (allocator).create(zx_type_11));

                (operand_29).* = @as(zx_type_11, zx_type_11{ .start = operand_25, .end = operand_26, .parent = operand_27, });

                break :block_30 @as(*const zx_type_11, operand_29);
            };
        };
        const operand_33 = (try (allocator).alloc(*const zx_type_11, (try ((std).math).add(usize, (operand_24).len, 1))));

        @memcpy((operand_33)[0..(operand_24).len], operand_24);

        (operand_33)[(operand_24).len] = operand_32;

        break :block_34 @as(value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_33, {}, null, });
    }).@"0";

    return block_23: {
        const operand_18 = (in).offset;
        const operand_19 = (in).start;
        const operand_20 = (in).dots;
        const operand_21 = block_22: {
            break :block_22 value_2;
        };

        break :block_23 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .offset = operand_18, .start = operand_19, .dots = operand_20, .segments = operand_21, });
    };
}

fn function_0_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_11),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    const value_1: u64 = ((in).offset - (in).start);

    if (((block_64: {
        break :block_64 value_1;
    } == @as(u64, 0)) or ((in).dots and (block_65: {
        break :block_65 value_1;
    } == @as(u64, 1))))) {
        return in;
    }

    const value_2: []const *const zx_type_11 = @as([]const *const zx_type_11, (if (((buffers).lane_0 != null)) block_52: {
        const operand_43 = (in).segments;
        const operand_51 = block_50: {
            const operand_44 = (in).start;
            const operand_45 = (in).offset;
            const operand_46 = ((in).dots and (block_47: {
                break :block_47 value_1;
            } == @as(u64, 2)));

            break :block_50 block_49: {
                const operand_48 = (try (allocator).create(zx_type_11));

                (operand_48).* = @as(zx_type_11, zx_type_11{ .start = operand_44, .end = operand_45, .parent = operand_46, });

                break :block_49 @as(*const zx_type_11, operand_48);
            };
        };

        _ = (try ((std).math).add(usize, (operand_43).len, 1));

        if ((!(((buffers).lane_0.?).started).*)) {
            (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_43));

            (((buffers).lane_0.?).started).* = true;
        } else {
            (((((buffers).lane_0.?).buffer).*).items).len = (operand_43).len;
        }

        (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_51));

        break :block_52 ((((buffers).lane_0.?).buffer).*).items;
    } else (block_63: {
        const operand_53 = (in).segments;
        const operand_61 = block_60: {
            const operand_54 = (in).start;
            const operand_55 = (in).offset;
            const operand_56 = ((in).dots and (block_57: {
                break :block_57 value_1;
            } == @as(u64, 2)));

            break :block_60 block_59: {
                const operand_58 = (try (allocator).create(zx_type_11));

                (operand_58).* = @as(zx_type_11, zx_type_11{ .start = operand_54, .end = operand_55, .parent = operand_56, });

                break :block_59 @as(*const zx_type_11, operand_58);
            };
        };
        const operand_62 = (try (allocator).alloc(*const zx_type_11, (try ((std).math).add(usize, (operand_53).len, 1))));

        @memcpy((operand_62)[0..(operand_53).len], operand_53);

        (operand_62)[(operand_53).len] = operand_61;

        break :block_63 @as(value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_62, {}, null, });
    }).@"0"));

    return block_42: {
        const operand_37 = (in).offset;
        const operand_38 = (in).start;
        const operand_39 = (in).dots;
        const operand_40 = block_41: {
            break :block_41 value_2;
        };

        break :block_42 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .offset = operand_37, .start = operand_38, .dots = operand_39, .segments = operand_40, });
    };
}

fn function_0_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_13, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_11),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_13 {
    @setRuntimeSafety(true);

    const value_1: u64 = ((in).offset - (in).start);

    if (((value_1 == @as(u64, 0)) or ((in).dots and (value_1 == @as(u64, 1))))) {
        return in;
    }

    const value_2: []const *const zx_type_11 = @as([]const *const zx_type_11, (if (((buffers).lane_0 != null)) block_81: {
        const operand_73 = (in).segments;
        const operand_80 = block_79: {
            const operand_74 = (in).start;
            const operand_75 = (in).offset;
            const operand_76 = ((in).dots and (value_1 == @as(u64, 2)));

            break :block_79 block_78: {
                const operand_77 = (try (allocator).create(zx_type_11));

                (operand_77).* = @as(zx_type_11, zx_type_11{ .start = operand_74, .end = operand_75, .parent = operand_76, });

                break :block_78 @as(*const zx_type_11, operand_77);
            };
        };

        _ = (try ((std).math).add(usize, (operand_73).len, 1));

        if ((!(((buffers).lane_0.?).started).*)) {
            (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_73));

            (((buffers).lane_0.?).started).* = true;
        } else {
            (((((buffers).lane_0.?).buffer).*).items).len = (operand_73).len;
        }

        (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_80));

        break :block_81 ((((buffers).lane_0.?).buffer).*).items;
    } else (block_91: {
        const operand_82 = (in).segments;
        const operand_89 = block_88: {
            const operand_83 = (in).start;
            const operand_84 = (in).offset;
            const operand_85 = ((in).dots and (value_1 == @as(u64, 2)));

            break :block_88 block_87: {
                const operand_86 = (try (allocator).create(zx_type_11));

                (operand_86).* = @as(zx_type_11, zx_type_11{ .start = operand_83, .end = operand_84, .parent = operand_85, });

                break :block_87 @as(*const zx_type_11, operand_86);
            };
        };
        const operand_90 = (try (allocator).alloc(*const zx_type_11, (try ((std).math).add(usize, (operand_82).len, 1))));

        @memcpy((operand_90)[0..(operand_82).len], operand_82);

        (operand_90)[(operand_82).len] = operand_89;

        break :block_91 @as(zx_type_19, .{ operand_90, {}, });
    }).@"0"));

    return block_72: {
        const operand_66 = (in).offset;
        const operand_67 = (in).start;
        const operand_68 = (in).dots;
        const operand_69 = value_2;

        break :block_72 block_71: {
            const operand_70 = (try (allocator).create(zx_type_13));

            (operand_70).* = @as(zx_type_13, zx_type_13{ .offset = operand_66, .start = operand_67, .dots = operand_68, .segments = operand_69, });

            break :block_71 @as(*const zx_type_13, operand_70);
        };
    };
}

fn function_1(allocator: ((std).mem).Allocator, in: *const zx_type_15) error{ OutOfMemory, Overflow, }!*const zx_type_13 {
    @setRuntimeSafety(true);

    if (((in).byte == @as(u8, 47))) {
        const value_1: *const zx_type_13 = block_18: {
            const operand_14 = (in).state;
            const operand_15 = (try function_0_value(allocator, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .dots = (operand_14).dots, .offset = (operand_14).offset, .segments = (operand_14).segments, .start = (operand_14).start, .zx_origin = operand_14, }));

            break :block_18 (if (((operand_15).zx_origin != null)) (operand_15).zx_origin.? else block_17: {
                const operand_16 = (try (allocator).create(zx_type_13));

                (operand_16).* = zx_type_13{ .dots = (operand_15).dots, .offset = (operand_15).offset, .segments = (operand_15).segments, .start = (operand_15).start, };

                break :block_17 @as(*const zx_type_13, operand_16);
            });
        };
        const value_2: u64 = ((value_1).offset + @as(u64, 1));

        return block_13: {
            const operand_7 = value_2;
            const operand_8 = value_2;
            const operand_9 = true;
            const operand_10 = (value_1).segments;

            break :block_13 block_12: {
                const operand_11 = (try (allocator).create(zx_type_13));

                (operand_11).* = @as(zx_type_13, zx_type_13{ .offset = operand_7, .start = operand_8, .dots = operand_9, .segments = operand_10, });

                break :block_12 @as(*const zx_type_13, operand_11);
            };
        };
    }

    const value_3: u64 = (((in).state).offset + @as(u64, 1));
    const value_4: bool = (((in).state).dots and ((in).byte == @as(u8, 46)));

    return block_6: {
        const operand_1 = (in).state;
        const operand_2 = value_3;
        const operand_3 = value_4;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create(zx_type_13));

            (operand_4).* = @as(zx_type_13, zx_type_13{ .dots = operand_3, .offset = operand_2, .segments = (operand_1).segments, .start = (operand_1).start, });

            break :block_5 @as(*const zx_type_13, operand_4);
        };
    };
}

fn function_1_value(allocator: ((std).mem).Allocator, in: value_zx_type_15_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b) error{ OutOfMemory, Overflow, }!value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    if (((in).byte == @as(u8, 47))) {
        const value_1: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_32: {
            break :block_32 (try function_0_value(allocator, (in).state));
        };
        const value_2: u64 = ((value_1).offset + @as(u64, 1));

        return block_31: {
            const operand_25 = block_26: {
                break :block_26 value_2;
            };
            const operand_27 = block_28: {
                break :block_28 value_2;
            };
            const operand_29 = true;
            const operand_30 = (value_1).segments;

            break :block_31 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .offset = operand_25, .start = operand_27, .dots = operand_29, .segments = operand_30, });
        };
    }

    const value_3: u64 = (((in).state).offset + @as(u64, 1));
    const value_4: bool = (((in).state).dots and ((in).byte == @as(u8, 46)));

    return block_24: {
        const operand_19 = (in).state;
        const operand_20 = block_21: {
            break :block_21 value_3;
        };
        const operand_22 = block_23: {
            break :block_23 value_4;
        };

        break :block_24 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .dots = operand_22, .offset = operand_20, .segments = (operand_19).segments, .start = (operand_19).start, });
    };
}

fn function_1_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_15_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_11),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    if (((in).byte == @as(u8, 47))) {
        const value_1: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, block_46: {
            break :block_46 (try function_0_buffered(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), }));
        });
        const value_2: u64 = ((value_1).offset + @as(u64, 1));

        return block_45: {
            const operand_39 = block_40: {
                break :block_40 value_2;
            };
            const operand_41 = block_42: {
                break :block_42 value_2;
            };
            const operand_43 = true;
            const operand_44 = (value_1).segments;

            break :block_45 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .offset = operand_39, .start = operand_41, .dots = operand_43, .segments = operand_44, });
        };
    }

    const value_3: u64 = (((in).state).offset + @as(u64, 1));
    const value_4: bool = (((in).state).dots and ((in).byte == @as(u8, 46)));

    return block_38: {
        const operand_33 = (in).state;
        const operand_34 = block_35: {
            break :block_35 value_3;
        };
        const operand_36 = block_37: {
            break :block_37 value_4;
        };

        break :block_38 @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .dots = operand_36, .offset = operand_34, .segments = (operand_33).segments, .start = (operand_33).start, });
    };
}

fn function_1_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_15, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_11),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_13 {
    @setRuntimeSafety(true);

    if (((in).byte == @as(u8, 47))) {
        const value_1: *const zx_type_13 = (try function_0_buffered_pointer(allocator, (in).state, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), }));
        const value_2: u64 = ((value_1).offset + @as(u64, 1));

        return block_59: {
            const operand_53 = value_2;
            const operand_54 = value_2;
            const operand_55 = true;
            const operand_56 = (value_1).segments;

            break :block_59 block_58: {
                const operand_57 = (try (allocator).create(zx_type_13));

                (operand_57).* = @as(zx_type_13, zx_type_13{ .offset = operand_53, .start = operand_54, .dots = operand_55, .segments = operand_56, });

                break :block_58 @as(*const zx_type_13, operand_57);
            };
        };
    }

    const value_3: u64 = (((in).state).offset + @as(u64, 1));
    const value_4: bool = (((in).state).dots and ((in).byte == @as(u8, 46)));

    return block_52: {
        const operand_47 = (in).state;
        const operand_48 = value_3;
        const operand_49 = value_4;

        break :block_52 block_51: {
            const operand_50 = (try (allocator).create(zx_type_13));

            (operand_50).* = @as(zx_type_13, zx_type_13{ .dots = operand_49, .offset = operand_48, .segments = (operand_47).segments, .start = (operand_47).start, });

            break :block_51 @as(*const zx_type_13, operand_50);
        };
    };
}

fn function_2(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, Overflow, }![]const *const zx_type_11 {
    @setRuntimeSafety(true);

    const value_1: []const *const zx_type_11 = block_46: {
        break :block_46 (try (allocator).dupe(*const zx_type_11, (&[_]*const zx_type_11{})));
    };
    const value_2: *const zx_type_13 = block_45: {
        const operand_39 = @as(u64, 0);
        const operand_40 = @as(u64, 0);
        const operand_41 = true;
        const operand_42 = value_1;

        break :block_45 block_44: {
            const operand_43 = (try (allocator).create(zx_type_13));

            (operand_43).* = @as(zx_type_13, zx_type_13{ .offset = operand_39, .start = operand_40, .dots = operand_41, .segments = operand_42, });

            break :block_44 @as(*const zx_type_13, operand_43);
        };
    };
    const value_11: *const zx_type_13 = block_38: {
        const operand_34 = block_33: {
            const value_5: []const u8 = in;
            const value_10: *const zx_type_20 = block_32: {
                const operand_8 = block_7: {
                    const operand_2 = value_5;
                    const operand_3 = @as(u64, 0);
                    const operand_4 = value_2;

                    break :block_7 block_6: {
                        const operand_5 = (try (allocator).create(zx_type_20));

                        (operand_5).* = @as(zx_type_20, zx_type_20{ .index = operand_3, .result = operand_4, .source = operand_2, });

                        break :block_6 @as(*const zx_type_20, operand_5);
                    };
                };

                var state_capacity_10: (std).ArrayList(*const zx_type_11) = .empty;

                var state_capacity_started_11 = false;

                defer (state_capacity_10).deinit(allocator);

                var state_1: value_zx_type_20_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb = value_zx_type_20_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb{ .index = (operand_8).index, .result = value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .dots = ((operand_8).result).dots, .offset = ((operand_8).result).offset, .segments = ((operand_8).result).segments, .start = ((operand_8).result).start, .zx_origin = (operand_8).result, }, .source = (operand_8).source, .zx_origin = operand_8, };

                var state_changed_9 = false;

                while (((state_1).index < @as(u64, ((state_1).source).len))) {
                    state_1 = block_25: {
                        const value_8: u8 = block_24: {
                            const operand_22 = (state_1).source;
                            const operand_23 = (state_1).index;

                            if ((operand_23 >= (operand_22).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_24 (operand_22)[@intCast(operand_23)];
                        };
                        const value_3: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (state_1).result;
                        const value_4: u8 = block_21: {
                            break :block_21 value_8;
                        };
                        const value_9: value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, block_20: {
                            break :block_20 (try function_1_buffered(allocator, block_19: {
                                const operand_16 = value_3;
                                const operand_17 = block_18: {
                                    break :block_18 value_4;
                                };

                                break :block_19 @as(value_zx_type_15_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b, value_zx_type_15_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b{ .state = operand_16, .byte = operand_17, });
                            }, .{ .lane_0 = .{ .buffer = (&state_capacity_10), .started = (&state_capacity_started_11), }, }));
                        });

                        break :block_25 block_15: {
                            const operand_12 = (state_1).source;
                            const operand_13 = ((state_1).index + @as(u64, 1));
                            const operand_14 = value_9;

                            break :block_15 @as(value_zx_type_20_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb, value_zx_type_20_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb{ .index = operand_13, .result = operand_14, .source = operand_12, });
                        };
                    };

                    state_changed_9 = true;
                }

                var state_owned_26: []const *const zx_type_11 = (&[_]*const zx_type_11{});

                errdefer (allocator).free(state_owned_26);

                if (state_capacity_started_11) {
                    ((state_capacity_10).items).len = (((state_1).result).segments).len;

                    state_owned_26 = (try (state_capacity_10).toOwnedSlice(allocator));
                }

                if (state_capacity_started_11) {
                    state_1 = value_zx_type_20_b1e142daee037f4e878cbf299a1fbc548ca07053d40ed23b14bc9b2e5836ecbb{ .index = (state_1).index, .result = @as(value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .dots = ((state_1).result).dots, .offset = ((state_1).result).offset, .segments = state_owned_26, .start = ((state_1).result).start, }), .source = (state_1).source, };
                }

                break :block_32 (if (state_changed_9) block_31: {
                    break :block_31 (if (((state_1).zx_origin != null)) (state_1).zx_origin.? else block_30: {
                        const operand_29 = (try (allocator).create(zx_type_20));

                        (operand_29).* = zx_type_20{ .index = (state_1).index, .result = (if ((((state_1).result).zx_origin != null)) ((state_1).result).zx_origin.? else block_28: {
                            const operand_27 = (try (allocator).create(zx_type_13));

                            (operand_27).* = zx_type_13{ .dots = ((state_1).result).dots, .offset = ((state_1).result).offset, .segments = ((state_1).result).segments, .start = ((state_1).result).start, };

                            break :block_28 @as(*const zx_type_13, operand_27);
                        }), .source = (state_1).source, };

                        break :block_30 @as(*const zx_type_20, operand_29);
                    });
                } else operand_8);
            };

            break :block_33 (value_10).result;
        };
        const operand_35 = (try function_0_value(allocator, value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .dots = (operand_34).dots, .offset = (operand_34).offset, .segments = (operand_34).segments, .start = (operand_34).start, .zx_origin = operand_34, }));

        break :block_38 (if (((operand_35).zx_origin != null)) (operand_35).zx_origin.? else block_37: {
            const operand_36 = (try (allocator).create(zx_type_13));

            (operand_36).* = zx_type_13{ .dots = (operand_35).dots, .offset = (operand_35).offset, .segments = (operand_35).segments, .start = (operand_35).start, };

            break :block_37 @as(*const zx_type_13, operand_36);
        });
    };

    return (value_11).segments;
}

fn function_3(allocator: ((std).mem).Allocator, in: *const zx_type_17) error{ OutOfMemory, Overflow, }!*const zx_type_14 {
    @setRuntimeSafety(true);

    if ((in).parent) {
        const value_1: u64 = (((in).state).parents + @as(u64, 1));

        return block_25: {
            const operand_21 = (in).state;
            const operand_22 = value_1;

            break :block_25 block_24: {
                const operand_23 = (try (allocator).create(zx_type_14));

                (operand_23).* = @as(zx_type_14, zx_type_14{ .parents = operand_22, .segments = (operand_21).segments, });

                break :block_24 @as(*const zx_type_14, operand_23);
            };
        };
    }

    if ((((in).state).parents != @as(u64, 0))) {
        const value_2: u64 = (((in).state).parents - @as(u64, 1));

        return block_20: {
            const operand_16 = (in).state;
            const operand_17 = value_2;

            break :block_20 block_19: {
                const operand_18 = (try (allocator).create(zx_type_14));

                (operand_18).* = @as(zx_type_14, zx_type_14{ .parents = operand_17, .segments = (operand_16).segments, });

                break :block_19 @as(*const zx_type_14, operand_18);
            };
        };
    }

    return block_15: {
        const operand_1 = ((in).state).parents;
        const operand_2 = (block_12: {
            const operand_3 = ((in).state).segments;
            const operand_10 = block_9: {
                const operand_4 = (in).start;
                const operand_5 = (in).end;
                const operand_6 = false;

                break :block_9 block_8: {
                    const operand_7 = (try (allocator).create(zx_type_11));

                    (operand_7).* = @as(zx_type_11, zx_type_11{ .start = operand_4, .end = operand_5, .parent = operand_6, });

                    break :block_8 @as(*const zx_type_11, operand_7);
                };
            };
            const operand_11 = (try (allocator).alloc(*const zx_type_11, (try ((std).math).add(usize, (operand_3).len, 1))));

            @memcpy((operand_11)[0..(operand_3).len], operand_3);

            (operand_11)[(operand_3).len] = operand_10;

            break :block_12 @as(zx_type_19, .{ operand_11, {}, });
        }).@"0";

        break :block_15 block_14: {
            const operand_13 = (try (allocator).create(zx_type_14));

            (operand_13).* = @as(zx_type_14, zx_type_14{ .parents = operand_1, .segments = operand_2, });

            break :block_14 @as(*const zx_type_14, operand_13);
        };
    };
}

fn function_3_value(allocator: ((std).mem).Allocator, in: value_zx_type_17_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363) error{ OutOfMemory, Overflow, }!value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    if ((in).parent) {
        const value_1: u64 = (((in).state).parents + @as(u64, 1));

        return block_46: {
            const operand_43 = (in).state;
            const operand_44 = block_45: {
                break :block_45 value_1;
            };

            break :block_46 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .parents = operand_44, .segments = (operand_43).segments, });
        };
    }

    if ((((in).state).parents != @as(u64, 0))) {
        const value_2: u64 = (((in).state).parents - @as(u64, 1));

        return block_42: {
            const operand_39 = (in).state;
            const operand_40 = block_41: {
                break :block_41 value_2;
            };

            break :block_42 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .parents = operand_40, .segments = (operand_39).segments, });
        };
    }

    return block_38: {
        const operand_26 = ((in).state).parents;
        const operand_27 = (block_37: {
            const operand_28 = ((in).state).segments;
            const operand_35 = block_34: {
                const operand_29 = (in).start;
                const operand_30 = (in).end;
                const operand_31 = false;

                break :block_34 block_33: {
                    const operand_32 = (try (allocator).create(zx_type_11));

                    (operand_32).* = @as(zx_type_11, zx_type_11{ .start = operand_29, .end = operand_30, .parent = operand_31, });

                    break :block_33 @as(*const zx_type_11, operand_32);
                };
            };
            const operand_36 = (try (allocator).alloc(*const zx_type_11, (try ((std).math).add(usize, (operand_28).len, 1))));

            @memcpy((operand_36)[0..(operand_28).len], operand_28);

            (operand_36)[(operand_28).len] = operand_35;

            break :block_37 @as(value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_36, {}, null, });
        }).@"0";

        break :block_38 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .parents = operand_26, .segments = operand_27, });
    };
}

fn function_3_buffered(allocator: ((std).mem).Allocator, in: value_zx_type_17_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_11),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    if ((in).parent) {
        const value_1: u64 = (((in).state).parents + @as(u64, 1));

        return block_76: {
            const operand_73 = (in).state;
            const operand_74 = block_75: {
                break :block_75 value_1;
            };

            break :block_76 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .parents = operand_74, .segments = (operand_73).segments, });
        };
    }

    if ((((in).state).parents != @as(u64, 0))) {
        const value_2: u64 = (((in).state).parents - @as(u64, 1));

        return block_72: {
            const operand_69 = (in).state;
            const operand_70 = block_71: {
                break :block_71 value_2;
            };

            break :block_72 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .parents = operand_70, .segments = (operand_69).segments, });
        };
    }

    return block_68: {
        const operand_47 = ((in).state).parents;
        const operand_48 = @as([]const *const zx_type_11, (if (((buffers).lane_0 != null)) block_57: {
            const operand_49 = ((in).state).segments;
            const operand_56 = block_55: {
                const operand_50 = (in).start;
                const operand_51 = (in).end;
                const operand_52 = false;

                break :block_55 block_54: {
                    const operand_53 = (try (allocator).create(zx_type_11));

                    (operand_53).* = @as(zx_type_11, zx_type_11{ .start = operand_50, .end = operand_51, .parent = operand_52, });

                    break :block_54 @as(*const zx_type_11, operand_53);
                };
            };

            _ = (try ((std).math).add(usize, (operand_49).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_49));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_49).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_56));

            break :block_57 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_67: {
            const operand_58 = ((in).state).segments;
            const operand_65 = block_64: {
                const operand_59 = (in).start;
                const operand_60 = (in).end;
                const operand_61 = false;

                break :block_64 block_63: {
                    const operand_62 = (try (allocator).create(zx_type_11));

                    (operand_62).* = @as(zx_type_11, zx_type_11{ .start = operand_59, .end = operand_60, .parent = operand_61, });

                    break :block_63 @as(*const zx_type_11, operand_62);
                };
            };
            const operand_66 = (try (allocator).alloc(*const zx_type_11, (try ((std).math).add(usize, (operand_58).len, 1))));

            @memcpy((operand_66)[0..(operand_58).len], operand_58);

            (operand_66)[(operand_58).len] = operand_65;

            break :block_67 @as(value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_66, {}, null, });
        }).@"0"));

        break :block_68 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .parents = operand_47, .segments = operand_48, });
    };
}

fn function_3_buffered_pointer(allocator: ((std).mem).Allocator, in: *const zx_type_17, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(*const zx_type_11),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const zx_type_14 {
    @setRuntimeSafety(true);

    if ((in).parent) {
        const value_1: u64 = (((in).state).parents + @as(u64, 1));

        return block_110: {
            const operand_106 = (in).state;
            const operand_107 = value_1;

            break :block_110 block_109: {
                const operand_108 = (try (allocator).create(zx_type_14));

                (operand_108).* = @as(zx_type_14, zx_type_14{ .parents = operand_107, .segments = (operand_106).segments, });

                break :block_109 @as(*const zx_type_14, operand_108);
            };
        };
    }

    if ((((in).state).parents != @as(u64, 0))) {
        const value_2: u64 = (((in).state).parents - @as(u64, 1));

        return block_105: {
            const operand_101 = (in).state;
            const operand_102 = value_2;

            break :block_105 block_104: {
                const operand_103 = (try (allocator).create(zx_type_14));

                (operand_103).* = @as(zx_type_14, zx_type_14{ .parents = operand_102, .segments = (operand_101).segments, });

                break :block_104 @as(*const zx_type_14, operand_103);
            };
        };
    }

    return block_100: {
        const operand_77 = ((in).state).parents;
        const operand_78 = @as([]const *const zx_type_11, (if (((buffers).lane_0 != null)) block_87: {
            const operand_79 = ((in).state).segments;
            const operand_86 = block_85: {
                const operand_80 = (in).start;
                const operand_81 = (in).end;
                const operand_82 = false;

                break :block_85 block_84: {
                    const operand_83 = (try (allocator).create(zx_type_11));

                    (operand_83).* = @as(zx_type_11, zx_type_11{ .start = operand_80, .end = operand_81, .parent = operand_82, });

                    break :block_84 @as(*const zx_type_11, operand_83);
                };
            };

            _ = (try ((std).math).add(usize, (operand_79).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_79));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_79).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_86));

            break :block_87 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_97: {
            const operand_88 = ((in).state).segments;
            const operand_95 = block_94: {
                const operand_89 = (in).start;
                const operand_90 = (in).end;
                const operand_91 = false;

                break :block_94 block_93: {
                    const operand_92 = (try (allocator).create(zx_type_11));

                    (operand_92).* = @as(zx_type_11, zx_type_11{ .start = operand_89, .end = operand_90, .parent = operand_91, });

                    break :block_93 @as(*const zx_type_11, operand_92);
                };
            };
            const operand_96 = (try (allocator).alloc(*const zx_type_11, (try ((std).math).add(usize, (operand_88).len, 1))));

            @memcpy((operand_96)[0..(operand_88).len], operand_88);

            (operand_96)[(operand_88).len] = operand_95;

            break :block_97 @as(zx_type_19, .{ operand_96, {}, });
        }).@"0"));

        break :block_100 block_99: {
            const operand_98 = (try (allocator).create(zx_type_14));

            (operand_98).* = @as(zx_type_14, zx_type_14{ .parents = operand_77, .segments = operand_78, });

            break :block_99 @as(*const zx_type_14, operand_98);
        };
    };
}

fn function_4(allocator: ((std).mem).Allocator, in: []const *const zx_type_11) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_18 {
    @setRuntimeSafety(true);

    const value_1: []const *const zx_type_11 = block_54: {
        break :block_54 (try (allocator).dupe(*const zx_type_11, (&[_]*const zx_type_11{})));
    };
    const value_2: *const zx_type_14 = block_53: {
        const operand_49 = @as(u64, 0);
        const operand_50 = value_1;

        break :block_53 block_52: {
            const operand_51 = (try (allocator).create(zx_type_14));

            (operand_51).* = @as(zx_type_14, zx_type_14{ .parents = operand_49, .segments = operand_50, });

            break :block_52 @as(*const zx_type_14, operand_51);
        };
    };
    const value_11: *const zx_type_14 = block_48: {
        const value_5: []const *const zx_type_11 = (block_47: {
            const operand_45 = in;
            const operand_46 = (try (allocator).alloc(*const zx_type_11, (operand_45).len));

            @memcpy(operand_46, operand_45);

            ((std).mem).reverse(*const zx_type_11, operand_46);

            break :block_47 @as(zx_type_19, .{ operand_46, {}, });
        }).@"0";
        const value_10: *const zx_type_21 = block_44: {
            const operand_16 = block_15: {
                const operand_10 = value_5;
                const operand_11 = @as(u64, 0);
                const operand_12 = value_2;

                break :block_15 block_14: {
                    const operand_13 = (try (allocator).create(zx_type_21));

                    (operand_13).* = @as(zx_type_21, zx_type_21{ .index = operand_11, .result = operand_12, .source = operand_10, });

                    break :block_14 @as(*const zx_type_21, operand_13);
                };
            };

            var state_capacity_18: (std).ArrayList(*const zx_type_11) = .empty;

            var state_capacity_started_19 = false;

            defer (state_capacity_18).deinit(allocator);

            var state_9: value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1{ .index = (operand_16).index, .result = value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .parents = ((operand_16).result).parents, .segments = ((operand_16).result).segments, .zx_origin = (operand_16).result, }, .source = (operand_16).source, .zx_origin = operand_16, };

            var state_changed_17 = false;

            while (((state_9).index < @as(u64, ((state_9).source).len))) {
                state_9 = block_37: {
                    const value_8: *const zx_type_11 = block_36: {
                        const operand_34 = (state_9).source;
                        const operand_35 = (state_9).index;

                        if ((operand_35 >= (operand_34).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_36 (operand_34)[@intCast(operand_35)];
                    };
                    const value_3: value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = (state_9).result;
                    const value_4: *const zx_type_11 = block_33: {
                        break :block_33 value_8;
                    };
                    const value_9: value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, block_32: {
                        break :block_32 (try function_3_buffered(allocator, block_31: {
                            const operand_24 = value_3;
                            const operand_25 = (block_26: {
                                break :block_26 value_4;
                            }).start;
                            const operand_27 = (block_28: {
                                break :block_28 value_4;
                            }).end;
                            const operand_29 = (block_30: {
                                break :block_30 value_4;
                            }).parent;

                            break :block_31 @as(value_zx_type_17_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363, value_zx_type_17_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363{ .state = operand_24, .start = operand_25, .end = operand_27, .parent = operand_29, });
                        }, .{ .lane_0 = .{ .buffer = (&state_capacity_18), .started = (&state_capacity_started_19), }, }));
                    });

                    break :block_37 block_23: {
                        const operand_20 = (state_9).source;
                        const operand_21 = ((state_9).index + @as(u64, 1));
                        const operand_22 = value_9;

                        break :block_23 @as(value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1, value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1{ .index = operand_21, .result = operand_22, .source = operand_20, });
                    };
                };

                state_changed_17 = true;
            }

            var state_owned_38: []const *const zx_type_11 = (&[_]*const zx_type_11{});

            errdefer (allocator).free(state_owned_38);

            if (state_capacity_started_19) {
                ((state_capacity_18).items).len = (((state_9).result).segments).len;

                state_owned_38 = (try (state_capacity_18).toOwnedSlice(allocator));
            }

            if (state_capacity_started_19) {
                state_9 = value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1{ .index = (state_9).index, .result = @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .parents = ((state_9).result).parents, .segments = state_owned_38, }), .source = (state_9).source, };
            }

            break :block_44 (if (state_changed_17) block_43: {
                break :block_43 (if (((state_9).zx_origin != null)) (state_9).zx_origin.? else block_42: {
                    const operand_41 = (try (allocator).create(zx_type_21));

                    (operand_41).* = zx_type_21{ .index = (state_9).index, .result = (if ((((state_9).result).zx_origin != null)) ((state_9).result).zx_origin.? else block_40: {
                        const operand_39 = (try (allocator).create(zx_type_14));

                        (operand_39).* = zx_type_14{ .parents = ((state_9).result).parents, .segments = ((state_9).result).segments, };

                        break :block_40 @as(*const zx_type_14, operand_39);
                    }), .source = (state_9).source, };

                    break :block_42 @as(*const zx_type_21, operand_41);
                });
            } else operand_16);
        };

        break :block_48 (value_10).result;
    };

    return block_8: {
        const operand_1 = ((value_11).parents == @as(u64, 0));
        const operand_2 = (block_5: {
            const operand_3 = (value_11).segments;
            const operand_4 = (try (allocator).alloc(*const zx_type_11, (operand_3).len));

            @memcpy(operand_4, operand_3);

            ((std).mem).reverse(*const zx_type_11, operand_4);

            break :block_5 @as(zx_type_19, .{ operand_4, {}, });
        }).@"0";

        break :block_8 block_7: {
            const operand_6 = (try (allocator).create(zx_type_18));

            (operand_6).* = @as(zx_type_18, zx_type_18{ .valid = operand_1, .segments = operand_2, });

            break :block_7 @as(*const zx_type_18, operand_6);
        };
    };
}

fn function_4_value(allocator: ((std).mem).Allocator, in: []const *const zx_type_11) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_1: []const *const zx_type_11 = block_100: {
        break :block_100 (try (allocator).dupe(*const zx_type_11, (&[_]*const zx_type_11{})));
    };
    const value_2: value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_99: {
        const operand_96 = @as(u64, 0);
        const operand_97 = block_98: {
            break :block_98 value_1;
        };

        break :block_99 @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .parents = operand_96, .segments = operand_97, });
    };
    const value_11: value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_95: {
        const value_5: []const *const zx_type_11 = (block_94: {
            const operand_92 = in;
            const operand_93 = (try (allocator).alloc(*const zx_type_11, (operand_92).len));

            @memcpy(operand_93, operand_92);

            ((std).mem).reverse(*const zx_type_11, operand_93);

            break :block_94 @as(value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_93, {}, null, });
        }).@"0";
        const value_10: value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = block_91: {
            const operand_67 = block_66: {
                const operand_62 = block_63: {
                    break :block_63 value_5;
                };
                const operand_64 = @as(u64, 0);
                const operand_65 = value_2;

                break :block_66 @as(value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1, value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1{ .index = operand_64, .result = operand_65, .source = operand_62, });
            };

            var state_capacity_69: (std).ArrayList(*const zx_type_11) = .empty;

            var state_capacity_started_70 = false;

            defer (state_capacity_69).deinit(allocator);

            var state_61: value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = operand_67;

            var state_changed_68 = false;

            while (((state_61).index < @as(u64, ((state_61).source).len))) {
                state_61 = block_88: {
                    const value_8: zx_type_11 = (block_87: {
                        const operand_85 = (state_61).source;
                        const operand_86 = (state_61).index;

                        if ((operand_86 >= (operand_85).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_87 (operand_85)[@intCast(operand_86)];
                    }).*;
                    const value_3: value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = (state_61).result;
                    const value_4: zx_type_11 = (block_84: {
                        break :block_84 (&value_8);
                    }).*;
                    const value_9: value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, block_83: {
                        break :block_83 (try function_3_buffered(allocator, block_82: {
                            const operand_75 = value_3;
                            const operand_76 = (block_77: {
                                break :block_77 (&value_4);
                            }).start;
                            const operand_78 = (block_79: {
                                break :block_79 (&value_4);
                            }).end;
                            const operand_80 = (block_81: {
                                break :block_81 (&value_4);
                            }).parent;

                            break :block_82 @as(value_zx_type_17_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363, value_zx_type_17_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363{ .state = operand_75, .start = operand_76, .end = operand_78, .parent = operand_80, });
                        }, .{ .lane_0 = .{ .buffer = (&state_capacity_69), .started = (&state_capacity_started_70), }, }));
                    });

                    break :block_88 block_74: {
                        const operand_71 = (state_61).source;
                        const operand_72 = ((state_61).index + @as(u64, 1));
                        const operand_73 = value_9;

                        break :block_74 @as(value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1, value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1{ .index = operand_72, .result = operand_73, .source = operand_71, });
                    };
                };

                state_changed_68 = true;
            }

            var state_owned_89: []const *const zx_type_11 = (&[_]*const zx_type_11{});

            errdefer (allocator).free(state_owned_89);

            if (state_capacity_started_70) {
                ((state_capacity_69).items).len = (((state_61).result).segments).len;

                state_owned_89 = (try (state_capacity_69).toOwnedSlice(allocator));
            }

            if (state_capacity_started_70) {
                state_61 = value_zx_type_21_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1{ .index = (state_61).index, .result = @as(value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .parents = ((state_61).result).parents, .segments = state_owned_89, }), .source = (state_61).source, };
            }

            break :block_91 (if (state_changed_68) state_61 else operand_67);
        };

        break :block_95 (value_10).result;
    };

    return block_60: {
        const operand_55 = ((value_11).parents == @as(u64, 0));
        const operand_56 = (block_59: {
            const operand_57 = (value_11).segments;
            const operand_58 = (try (allocator).alloc(*const zx_type_11, (operand_57).len));

            @memcpy(operand_58, operand_57);

            ((std).mem).reverse(*const zx_type_11, operand_58);

            break :block_59 @as(value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_58, {}, null, });
        }).@"0";

        break :block_60 @as(value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .valid = operand_55, .segments = operand_56, });
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const zx_type_18 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: []const *const zx_type_11 = (try function_2(allocator, in));
    const value_2: *const zx_type_18 = block_5: {
        const operand_1 = value_1;
        const operand_2 = (try function_4_value(allocator, operand_1));

        break :block_5 (if (((operand_2).zx_origin != null)) (operand_2).zx_origin.? else block_4: {
            const operand_3 = (try (allocator).create(zx_type_18));

            (operand_3).* = zx_type_18{ .segments = (operand_2).segments, .valid = (operand_2).valid, };

            break :block_4 @as(*const zx_type_18, operand_3);
        });
    };

    return value_2;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_1: []const *const zx_type_11 = block_9: {
        const operand_8 = in;

        break :block_9 (try function_2(allocator, operand_8));
    };
    const value_2: value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_7: {
        break :block_7 (try function_4_value(allocator, block_6: {
            break :block_6 value_1;
        }));
    };

    return value_2;
}

