pub const zx_type_11 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
};

pub const zx_type_15 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
};

pub const zx_type_16 = struct {
    base: *const zx_type_15,
    delta: *const zx_type_15,
};

pub const zx_type_17 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_18 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_19 = struct {
    base: *const zx_type_18,
    delta: *const zx_type_18,
};

pub const zx_type_20 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_21 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    second: u32,
};

pub const zx_type_22 = enum { Root, Dead, UpperInput, UpperOutput, Underscore, Allocator, Async, Await, Break, Cancel, Case, Concurrent, Const, Declare, Default, Delete, Do, Else, Ensures, Enum, Export, False, For, From, Function, If, Import, In, Insert, Io, Let, Loop, Match, New, Next, Null, Process, QueryMany, QueryOne, Requires, Return, Store, Switch, Throw, Throws, Transaction, True, Try, Type, Update, Var, While, };

pub const zx_type_23 = enum { Identifier, Keyword, Number, String, Template, Punctuation, Eof, };

pub const zx_type_24 = enum { None, OpenBrace, CloseBrace, OpenParen, CloseParen, OpenBracket, CloseBracket, Colon, Semicolon, Comma, Dot, Question, Plus, Minus, Star, Slash, Percent, Less, Greater, Assign, Not, Ampersand, Pipe, Arrow, Equal, NotEqual, LessEqual, GreaterEqual, Coalesce, And, Or, Spread, };

pub const zx_type_25 = struct {
    end: u64,
    start: u64,
};

pub const zx_type_26 = struct {
    dollar: bool,
    kind: zx_type_23,
    line_break: bool,
    span: *const zx_type_25,
    symbol: zx_type_24,
    word: zx_type_22,
};

pub const zx_type_27 = enum { Integer, FractionStart, Fraction, ExponentStart, ExponentDigits, Done, };

pub const zx_type_28 = struct {
    end: u64,
    last_byte: u8,
    phase: zx_type_27,
    separators_valid: bool,
};

pub const zx_type_29 = struct {
    diagnostic: []const u8,
    end: u64,
};

pub const zx_type_30 = enum { Idle, Identifier, Number, String, StringEscape, LineComment, BlockComment, Template, TemplateEscape, Interpolation, InterpolationString, InterpolationStringEscape, InterpolationLineComment, InterpolationBlockComment, };

pub const zx_type_31 = struct {
    code: []const u8,
    end: u64,
    message: []const u8,
    start: u64,
};

pub const zx_type_32 = struct {
    braces: u64,
    depth: u64,
    mode: zx_type_30,
    start: u64,
};

pub const zx_type_36 = struct {
    ahead_one: u8,
    ahead_two: u8,
    braces: u64,
    comments: []const *const zx_type_25,
    depth: u64,
    diagnostic: *const zx_type_31,
    dollar: bool,
    frames: []const *const zx_type_32,
    keyword_state: u64,
    line_break: bool,
    mode: zx_type_30,
    number: *const zx_type_28,
    offset: u64,
    skip_until: u64,
    source_length: u64,
    start: u64,
    symbol: zx_type_24,
    tokens: []const *const zx_type_26,
    warmed: u8,
};

pub const zx_type_37 = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    state: *const zx_type_36,
};

pub const zx_type_38 = struct {
    comments: []const *const zx_type_25,
    diagnostic: *const zx_type_31,
    tokens: []const *const zx_type_26,
};

pub const zx_type_39 = enum { Named, Object, Optional, List, Tuple, Application, };

pub const zx_type_40 = enum { Start, Name, Suffix, ListEnd, Field, FieldOptional, FieldColon, TupleItem, Done, };

pub const zx_type_41 = struct {
    child: u64,
    count: u64,
    head: u64,
    kind: zx_type_39,
    name: *const zx_type_25,
};

pub const zx_type_42 = struct {
    name: *const zx_type_25,
    previous: u64,
    value: u64,
};

pub const zx_type_43 = struct {
    previous: u64,
    value: u64,
};

pub const zx_type_45 = struct {
    fields: []const u64,
    heads: []const u64,
    items: []const u64,
};

pub const zx_type_49 = struct {
    fields: []const *const zx_type_42,
    items: []const *const zx_type_43,
    nodes: []const *const zx_type_41,
};

pub const zx_type_50 = struct {
    count: u64,
    field: *const zx_type_25,
    head: u64,
    kind: zx_type_39,
    name: *const zx_type_25,
    optional: bool,
};

pub const zx_type_51 = struct {
    depth: u64,
    diagnostic: *const zx_type_31,
    index: u64,
    name: *const zx_type_25,
    phase: zx_type_40,
    result: u64,
    start: u64,
    token: *const zx_type_26,
};

pub const zx_type_53 = struct {
    control: *const zx_type_51,
    frames: []const *const zx_type_50,
    tree: *const zx_type_49,
};

pub const zx_type_54 = enum { Start, Kind, Name, Open, Value, Member, Separator, Done, };

pub const zx_type_55 = struct {
    count: u64,
    enumeration: bool,
    first: u64,
    name: *const zx_type_25,
    span: *const zx_type_25,
    value: u64,
};

pub const zx_type_56 = struct {
    count: u64,
    depth: u64,
    diagnostic: *const zx_type_31,
    enumeration: bool,
    first: u64,
    index: u64,
    last_end: u64,
    name: *const zx_type_25,
    opening: u64,
    opening_index: u64,
    phase: zx_type_54,
    start: u64,
    token: *const zx_type_26,
    type_diagnostic: bool,
};

pub const zx_type_58 = struct {
    control: *const zx_type_56,
    declarations: []const *const zx_type_55,
    members: []const *const zx_type_25,
    types: *const zx_type_53,
};

pub const zx_type_59 = enum { Named, Object, Optional, List, Tuple, Enumeration, Application, };

pub const zx_type_60 = struct {
    end: u64,
    start: u64,
    text: []const u8,
};

pub const zx_type_61 = struct {
    enumeration: bool,
    index: u64,
};

pub const zx_type_62 = struct {
    child: *const zx_type_61,
    count: u64,
    kind: zx_type_59,
    name: *const zx_type_60,
    position: u64,
};

pub const zx_type_63 = struct {
    name: *const zx_type_60,
    next: u64,
    value: *const zx_type_61,
};

pub const zx_type_64 = struct {
    next: u64,
    value: *const zx_type_61,
};

pub const zx_type_65 = struct {
    name: *const zx_type_60,
    value: *const zx_type_61,
};

pub const zx_type_66 = struct {
    count: u64,
    first: u64,
};

pub const zx_type_73 = struct {
    declarations: []const *const zx_type_65,
    enumerations: []const *const zx_type_66,
    fields: []const *const zx_type_63,
    items: []const *const zx_type_64,
    members: []const *const zx_type_60,
    nodes: []const *const zx_type_62,
};

pub const zx_type_74 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    members: []const *const zx_type_25,
    order: *const zx_type_45,
    types: *const zx_type_49,
};

pub const zx_type_76 = struct {
    indexed: *const zx_type_74,
    native: ?*const zx_type_73,
};

pub const zx_type_77 = enum { Name, FinishName, Node, Wrap, Tuple, Object, };

pub const zx_type_78 = struct {
    ids: []const u32,
    names: []const []const u8,
};

pub const zx_type_79 = struct {
    aliases: *const zx_type_78,
    base: *const zx_type_18,
    native_interface: bool,
    resolved: *const zx_type_78,
    source: *const zx_type_76,
    visiting: []const []const u8,
};

pub const zx_type_80 = struct {
    children: u64,
    count: u64,
    declaration: *const zx_type_60,
    fields: u64,
    index: u64,
    list: bool,
    name: *const zx_type_60,
    operation: zx_type_77,
    position: u64,
    reference: *const zx_type_61,
    waiting: bool,
};

pub const zx_type_82 = struct {
    active: []const []const u8,
    cache: *const zx_type_78,
    context: *const zx_type_79,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    frames: []const *const zx_type_80,
    result: u32,
    scratch: *const zx_type_20,
};

pub const zx_type_83 = struct {
    cache: *const zx_type_78,
    context: *const zx_type_79,
    delta: *const zx_type_18,
    initialize: bool,
    name: *const zx_type_60,
    named: bool,
    reference: *const zx_type_61,
};

pub const zx_type_84 = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
};

pub const zx_type_85 = enum { Text, Expression, };

pub const zx_type_86 = enum { TemplateOpen, TemplateClose, InterpolationOpen, InterpolationClose, };

pub const zx_type_87 = struct {
    count: u64,
    head: u64,
    span: *const zx_type_25,
};

pub const zx_type_88 = struct {
    interpolation: u64,
    kind: zx_type_85,
    previous: u64,
    span: *const zx_type_25,
};

pub const zx_type_89 = struct {
    kind: zx_type_86,
    offset: u64,
    reference: u64,
};

pub const zx_type_93 = struct {
    events: []const *const zx_type_89,
    lexed: *const zx_type_38,
    parts: []const *const zx_type_88,
    templates: []const *const zx_type_87,
    token_templates: []const u64,
};

pub const zx_type_94 = struct {
    lexed: *const zx_type_38,
    span: *const zx_type_25,
    token_templates: []const u64,
};

pub const zx_type_96 = struct {
    interpolations: []const *const zx_type_94,
    lexed: *const zx_type_38,
    parts: []const *const zx_type_88,
    templates: []const *const zx_type_87,
    token_templates: []const u64,
};

pub const zx_type_97 = enum { None, Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, And, Or, };

pub const zx_type_98 = enum { None, Coalesce, Logical, };

pub const zx_type_99 = struct {
    family: zx_type_98,
    operator: zx_type_97,
    precedence: u8,
};

pub const zx_type_100 = struct {
    binary: *const zx_type_99,
    generic: bool,
    lambda: bool,
};

pub const zx_type_102 = struct {
    after_identifier: bool,
    arrow: bool,
    hints: []const *const zx_type_100,
    parameter_start: bool,
};

pub const zx_type_104 = struct {
    hints: []const *const zx_type_100,
    interpolation_hints: []const []const *const zx_type_100,
    lexical: *const zx_type_96,
};

pub const zx_type_105 = enum { Number, String, Boolean, Null, Identifier, Field, Index, List, Call, Lambda, Template, Unary, Binary, Conditional, Match, Object, StateBlock, Capture, Async, Await, Cancel, };

pub const zx_type_106 = enum { BeginBinary, Primary, Postfix, Returning, FieldName, Arguments, ObjectName, ObjectColon, LambdaParameter, LambdaSeparator, LambdaArrow, LambdaBody, Callback, StateBlock, MatchStart, MatchCondition, MatchFallbackArrow, MatchEnd, GenericType, GenericCall, TemplateGather, TemplatePart, Done, };

pub const zx_type_107 = enum { BinaryLeft, BinaryRight, Unary, Group, Index, Arguments, ObjectValue, OptionsValue, Lambda, ConditionalYes, ConditionalNo, MatchSubject, MatchCondition, MatchResult, MatchFallback, Template, TemplatePart, Interpolation, Capture, Async, Await, Cancel, };

pub const zx_type_108 = struct {
    count: u64,
    depth: u64,
    first: u64,
    flag: bool,
    head: u64,
    kind: zx_type_105,
    name: *const zx_type_25,
    operator: zx_type_97,
    second: u64,
    span: *const zx_type_25,
    third: u64,
    type_argument: u64,
};

pub const zx_type_109 = struct {
    name: *const zx_type_25,
    previous: u64,
    spread: bool,
    value: u64,
};

pub const zx_type_110 = struct {
    name: *const zx_type_25,
    previous: u64,
};

pub const zx_type_111 = struct {
    expression: bool,
    previous: u64,
    span: *const zx_type_25,
    value: u64,
};

pub const zx_type_112 = struct {
    condition: u64,
    previous: u64,
    result: u64,
};

pub const zx_type_118 = struct {
    arms: []const *const zx_type_112,
    fields: []const *const zx_type_109,
    items: []const *const zx_type_43,
    nodes: []const *const zx_type_108,
    parameters: []const *const zx_type_110,
    parts: []const *const zx_type_111,
};

pub const zx_type_119 = struct {
    allow_lambda: bool,
    callback: bool,
    condition: bool,
    count: u64,
    cursor: u64,
    depth: u64,
    end: u64,
    family: zx_type_98,
    first: u64,
    flag: bool,
    head: u64,
    index: u64,
    kind: zx_type_107,
    maximum: u64,
    minimum: u8,
    name: *const zx_type_25,
    operator: zx_type_97,
    reset_family: bool,
    second: u64,
    start: u64,
    stream: u64,
};

pub const zx_type_120 = struct {
    allow_lambda: bool,
    base_depth: u64,
    cursor: u64,
    depth: u64,
    diagnostic: *const zx_type_31,
    family: zx_type_98,
    fresh_family: bool,
    hint: *const zx_type_100,
    index: u64,
    last_end: u64,
    lexical_diagnostic: u64,
    minimum: u8,
    phase: zx_type_106,
    primary_start: u64,
    result: u64,
    root_index: u64,
    stream: u64,
    template: u64,
    template_count: u64,
    template_head: u64,
    template_maximum: u64,
    token: *const zx_type_26,
    type_argument: u64,
    type_diagnostic: bool,
};

pub const zx_type_122 = struct {
    control: *const zx_type_120,
    frames: []const *const zx_type_119,
    prepared: *const zx_type_104,
    tree: *const zx_type_118,
    types: *const zx_type_53,
};

pub const zx_type_123 = enum { Constant, Destructure, Result, Branch, Switch, StoreSet, Evaluate, StateUpdate, };

pub const zx_type_124 = enum { Root, Block, Statement, Case, };

pub const zx_type_125 = enum { BlockOpen, BlockNext, Statement, ConstName, ConstAfterName, PatternName, PatternSeparator, ConstAssign, ReturnValue, IfOpen, IfClose, IfElse, IfAlternative, SwitchOpen, SwitchClose, SwitchBrace, SwitchCase, CaseColon, CaseBody, CaseNext, StoreAssign, UpdateOperator, UpdateAssign, BeginValue, BeginCondition, BeginSwitch, BeginCase, Value, Expression, Type, EndStatement, Publish, Resume, Done, };

pub const zx_type_126 = struct {
    annotation: u64,
    count: u64,
    first: u64,
    head: u64,
    kind: zx_type_123,
    name: *const zx_type_25,
    operator: zx_type_97,
    second: u64,
    span: *const zx_type_25,
    third: u64,
};

pub const zx_type_127 = struct {
    previous: u64,
    span: *const zx_type_25,
};

pub const zx_type_128 = struct {
    body: u64,
    previous: u64,
    span: *const zx_type_25,
    value: u64,
};

pub const zx_type_132 = struct {
    blocks: []const *const zx_type_87,
    cases: []const *const zx_type_128,
    items: []const *const zx_type_43,
    names: []const *const zx_type_127,
    statements: []const *const zx_type_126,
};

pub const zx_type_133 = struct {
    annotation: u64,
    count: u64,
    depth: u64,
    first: u64,
    head: u64,
    kind: zx_type_124,
    name: *const zx_type_25,
    operator: zx_type_97,
    phase: zx_type_125,
    second: u64,
    start: u64,
    statement: zx_type_123,
    third: u64,
};

pub const zx_type_134 = struct {
    diagnostic: *const zx_type_31,
    expression_diagnostic: bool,
    phase: zx_type_125,
    result: u64,
    @"resume": zx_type_125,
    state_block: bool,
};

pub const zx_type_136 = struct {
    control: *const zx_type_134,
    expression: *const zx_type_120,
    expression_frames: []const *const zx_type_119,
    frame: *const zx_type_133,
    frames: []const *const zx_type_133,
};

pub const zx_type_138 = struct {
    control: *const zx_type_134,
    expression: *const zx_type_122,
    frame: *const zx_type_133,
    frames: []const *const zx_type_133,
    suspended: []const *const zx_type_136,
    tree: *const zx_type_132,
};

pub const zx_type_139 = enum { Open, Input, Colon, InputName, ParameterEnd, StoreOpen, StoreName, StoreClose, StoreEnd, Close, ResultColon, ResultName, Contract, ContractOpen, Predicate, ContractClose, Done, };

pub const zx_type_140 = struct {
    ensures: bool,
    predicate: u64,
    span: *const zx_type_25,
};

pub const zx_type_141 = struct {
    contract_start: u64,
    diagnostic: *const zx_type_31,
    ensures: bool,
    expression_diagnostic: bool,
    has_ensures: bool,
    has_store: bool,
    phase: zx_type_139,
    token: *const zx_type_26,
};

pub const zx_type_143 = struct {
    body: *const zx_type_132,
    contracts: []const *const zx_type_140,
    control: *const zx_type_141,
    expression: *const zx_type_122,
};

pub const zx_type_144 = enum { Start, Binding, Name, Separator, From, Path, End, Done, };

pub const zx_type_145 = enum { Function, Enumeration, TypeOnly, };

pub const zx_type_146 = struct {
    count: u64,
    first: u64,
    kind: zx_type_145,
    path: *const zx_type_25,
    span: *const zx_type_25,
};

pub const zx_type_147 = struct {
    count: u64,
    diagnostic: *const zx_type_31,
    first: u64,
    index: u64,
    named: bool,
    opening: *const zx_type_25,
    path: *const zx_type_25,
    phase: zx_type_144,
    start: u64,
    token: *const zx_type_26,
    type_only: bool,
};

pub const zx_type_149 = struct {
    control: *const zx_type_147,
    imports: []const *const zx_type_146,
    names: []const *const zx_type_25,
};

pub const zx_type_151 = struct {
    blocks: *const zx_type_132,
    body: ?u64,
    comments: []const *const zx_type_25,
    contracts: []const *const zx_type_140,
    declarations: []const *const zx_type_55,
    diagnostic: *const zx_type_31,
    expressions: *const zx_type_118,
    function_start: u64,
    has_store: bool,
    import_names: []const *const zx_type_25,
    imports: []const *const zx_type_146,
    members: []const *const zx_type_25,
    tokens: []const *const zx_type_26,
    type_order: *const zx_type_45,
    types: *const zx_type_49,
};

pub const zx_type_152 = struct {
    blocks: *const zx_type_132,
    comments: []const *const zx_type_25,
    diagnostic: *const zx_type_31,
    expressions: *const zx_type_118,
    result: u64,
    tokens: []const *const zx_type_26,
    type_order: *const zx_type_45,
    types: *const zx_type_49,
};

pub const zx_type_153 = struct {
    aliases: *const zx_type_78,
    bytes: []const u8,
    nominal_base: *const zx_type_15,
    nominal_origin: *const zx_type_11,
    shared: bool,
    syntax: *const zx_type_151,
    type_base: *const zx_type_18,
};

pub const zx_type_154 = struct {
    origin: *const zx_type_11,
    origins: *const zx_type_15,
    request: *const zx_type_83,
    shared: bool,
};

pub const zx_type_155 = struct {
    name: *const zx_type_60,
    operation: zx_type_77,
    reference: *const zx_type_61,
};

pub const zx_type_156 = struct {
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_157 = struct {
    code: []const u8,
    message: []const u8,
    name: *const zx_type_60,
    state: *const zx_type_82,
};

pub const zx_type_158 = struct { []const u8, u64, u64, };

pub const zx_type_159 = struct {
    source: []const u8,
    span: *const zx_type_25,
};

pub const zx_type_160 = struct {
    index: u64,
    source: *const zx_type_76,
};

pub const zx_type_161 = struct {
    limit: u64,
    name: []const u8,
    source: *const zx_type_76,
};

pub const zx_type_162 = struct {
    found: bool,
    index: u64,
};

pub const zx_type_163 = struct {
    index: u64,
    state: *const zx_type_82,
};

pub const zx_type_164 = struct {
    children: []const u32,
    fields: *const zx_type_20,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_165 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_166 = struct {
    delta: *const zx_type_18,
    id: u32,
};

pub const zx_type_167 = struct {
    children: []const u32,
    count: u64,
    field_names: []const []const u8,
    field_types: []const u32,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    names: []const []const u8,
    offset: u64,
    second: u32,
};

pub const zx_type_168 = struct {
    left: *const zx_type_167,
    right: *const zx_type_167,
};

pub const zx_type_169 = struct {
    index: u64,
    table: *const zx_type_18,
};

pub const zx_type_170 = struct {
    candidate: *const zx_type_164,
    id: u32,
    tables: *const zx_type_19,
};

pub const zx_type_171 = struct {
    candidate: *const zx_type_164,
    tables: *const zx_type_19,
};

pub const zx_type_172 = struct {
    candidate: *const zx_type_164,
    delta: *const zx_type_18,
};

pub const zx_type_173 = struct {
    left: []const u8,
    right: []const u8,
};

pub const zx_type_174 = struct {
    code: []const u8,
    message: []const u8,
};

pub const zx_type_175 = struct {
    candidate: *const zx_type_164,
    table: *const zx_type_18,
};

pub const zx_type_176 = struct {
    delta: *const zx_type_18,
    diagnostic: *const zx_type_174,
    id: u32,
};

pub const zx_type_177 = struct {
    id: u32,
    tables: *const zx_type_19,
};

pub const zx_type_179 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: *const zx_type_19,
};

pub const zx_type_180 = struct {
    id: u32,
    native_references: bool,
    tables: *const zx_type_19,
};

pub const zx_type_181 = enum { None, TaskContainer, VoidList, TaskTuple, TaskObject, };

pub const zx_type_182 = struct {
    candidate: *const zx_type_164,
    state: *const zx_type_82,
};

pub const zx_type_183 = struct {
    enumeration: u64,
    index: u64,
    source: *const zx_type_76,
};

pub const zx_type_184 = struct {
    reference: *const zx_type_61,
    source: *const zx_type_76,
};

pub const zx_type_185 = struct {
    cache: *const zx_type_78,
    name: []const u8,
};

pub const zx_type_186 = struct {
    frame: *const zx_type_80,
    state: *const zx_type_82,
};

pub const zx_type_187 = struct {
    position: u64,
    source: *const zx_type_76,
};

pub const zx_type_188 = enum { Missing, Found, Conflict, };

pub const zx_type_189 = struct {
    id: u32,
    status: zx_type_188,
};

pub const zx_type_190 = struct {
    base: *const zx_type_18,
    delta: *const zx_type_18,
    origin: *const zx_type_11,
    origins: *const zx_type_15,
};

pub const zx_type_191 = struct {
    conflict: bool,
    delta: *const zx_type_18,
    mapping: []const u32,
    origins: *const zx_type_15,
};

pub const zx_type_192 = struct {
    first: u64,
    ids: []const u32,
};

pub const zx_type_193 = struct {
    id: u32,
    mapping: *const zx_type_192,
};

pub const zx_type_194 = struct {
    delta: *const zx_type_18,
    mapping: *const zx_type_192,
    source: *const zx_type_167,
};

pub const zx_type_195 = struct {
    mapping: *const zx_type_192,
    source: *const zx_type_167,
    target: *const zx_type_167,
};

pub const zx_type_196 = struct {
    mapping: *const zx_type_192,
    origin: *const zx_type_11,
    origins: *const zx_type_16,
    source: *const zx_type_167,
    tables: *const zx_type_19,
};

pub const zx_type_197 = struct {
    cache: *const zx_type_78,
    mapping: *const zx_type_192,
};

pub const zx_type_198 = struct {
    cache: *const zx_type_78,
    context: *const zx_type_79,
    delta: *const zx_type_18,
    nominal_delta: *const zx_type_15,
};

pub const zx_type_199 = struct {
    diagnostic: *const zx_type_31,
    export_names: []const []const u8,
    export_types: []const u32,
    has_store: bool,
    input_type: u32,
    nominal_delta: *const zx_type_15,
    output_type: u32,
    type_delta: *const zx_type_18,
    type_only: bool,
};

pub const zx_type_200 = struct {
    diagnostic: *const zx_type_31,
    syntax: *const zx_type_151,
    types: *const zx_type_198,
};

pub const zx_type_201 = struct {
    diagnostic: *const zx_type_31,
    input_type: u32,
    output_type: u32,
    span: *const zx_type_25,
    types: *const zx_type_198,
};

pub const zx_type_202 = struct {
    syntax: *const zx_type_151,
    types: *const zx_type_198,
};

pub const zx_type_203 = struct {
    name: []const u8,
    span: *const zx_type_25,
    types: *const zx_type_198,
};

pub const zx_type_204 = struct {
    diagnostic: *const zx_type_31,
    types: *const zx_type_198,
};

pub const zx_type_205 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    state: *const zx_type_204,
};

pub const zx_type_206 = struct {
    names: []const []const u8,
    state: *const zx_type_204,
    types: []const u32,
};

pub const zx_type_207 = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
    origins: *const zx_type_15,
};

pub const zx_type_208 = struct {
    base: *const zx_type_18,
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    id: u32,
    origin: *const zx_type_11,
    origins: *const zx_type_15,
};

pub const zx_type_209 = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
    origins: *const zx_type_15,
    publish: bool,
};

pub const zx_type_210 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_211 = struct { []const u8, []const u8, };

pub const zx_type_212 = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    selected: u64,
    source: *const zx_type_76,
};

pub const zx_type_213 = struct { []const []const u8, []const []const u8, };

pub const zx_type_214 = struct {
    count: u64,
    index: u64,
    state: *const zx_type_82,
};

pub const zx_type_215 = struct { *const zx_type_82, };

pub const zx_type_216 = struct { *const zx_type_82, *const zx_type_82, };

pub const zx_type_217 = struct { *const zx_type_82, *const zx_type_82, *const zx_type_82, };

pub const zx_type_218 = struct { []const []const u8, void, };

pub const zx_type_219 = struct { []const u32, void, };

pub const zx_type_221 = struct { []const []const u8, ?[]const u8, };

pub const zx_type_223 = struct { []const *const zx_type_80, ?*const zx_type_80, };

pub const zx_type_224 = struct {
    equal: bool,
    index: u64,
    left: *const zx_type_167,
    right: *const zx_type_167,
};

pub const zx_type_225 = struct {
    candidate: *const zx_type_164,
    count: u64,
    found: bool,
    id: u32,
    index: u64,
    tables: *const zx_type_19,
};

pub const zx_type_226 = struct { []const u8, void, };

pub const zx_type_227 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    limit: u64,
    right: []const u8,
};

pub const zx_type_228 = struct {
    building: bool,
    count: u64,
    names: []const []const u8,
    remaining: u64,
    root: u64,
    sifting: bool,
    types: []const u32,
};

pub const zx_type_229 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
};

pub const zx_type_230 = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: *const zx_type_19,
    target: zx_type_17,
};

pub const zx_type_231 = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: *const zx_type_19,
};

pub const zx_type_232 = struct { []const bool, void, };

pub const zx_type_233 = struct {
    children: []const u32,
    found: bool,
    index: u64,
    tables: *const zx_type_19,
};

pub const zx_type_234 = struct {
    count: u64,
    diagnostic: *const zx_type_31,
    enumeration: u64,
    index: u64,
    names: []const []const u8,
    source: *const zx_type_76,
};

pub const zx_type_235 = struct {
    cache: *const zx_type_78,
    found: bool,
    id: u32,
    index: u64,
    name: []const u8,
};

pub const zx_type_236 = struct { []const *const zx_type_80, void, };

pub const zx_type_237 = struct { []const u32, []const u32, };

pub const zx_type_238 = struct { *const zx_type_83, };

pub const zx_type_239 = struct { *const zx_type_83, *const zx_type_82, };

pub const zx_type_240 = struct { *const zx_type_83, *const zx_type_82, *const zx_type_82, };

pub const zx_type_241 = struct { *const zx_type_83, *const zx_type_82, *const zx_type_82, *const zx_type_82, };

pub const zx_type_242 = struct {
    count: u64,
    delta: *const zx_type_18,
    index: u64,
    mapping: *const zx_type_192,
    source: *const zx_type_167,
};

pub const zx_type_243 = struct {
    equal: bool,
    index: u64,
    mapping: *const zx_type_192,
    source: *const zx_type_167,
    target: *const zx_type_167,
};

pub const zx_type_244 = struct {
    count: u64,
    id: u32,
    index: u64,
    input: *const zx_type_196,
    nominal: bool,
    status: zx_type_188,
};

pub const zx_type_245 = struct {
    conflict: bool,
    delta: *const zx_type_18,
    index: u64,
    input: *const zx_type_190,
    mapping: []const u32,
    origins: *const zx_type_15,
};

pub const zx_type_246 = struct {
    cache: *const zx_type_78,
    ids: []const u32,
    index: u64,
    mapping: *const zx_type_192,
};

pub const zx_type_247 = struct { *const zx_type_208, };

pub const zx_type_248 = struct { *const zx_type_208, *const zx_type_191, };

pub const zx_type_249 = struct { *const zx_type_208, *const zx_type_191, *const zx_type_78, };

pub const zx_type_250 = struct { *const zx_type_208, *const zx_type_191, *const zx_type_78, u32, };

pub const zx_type_251 = struct { *const zx_type_154, };

pub const zx_type_252 = struct { *const zx_type_154, *const zx_type_84, };

pub const zx_type_253 = struct { *const zx_type_154, *const zx_type_84, *const zx_type_207, };

pub const zx_type_254 = struct { *const zx_type_153, };

pub const zx_type_255 = struct { *const zx_type_153, *const zx_type_154, };

pub const zx_type_256 = struct { *const zx_type_153, *const zx_type_154, *const zx_type_209, };

pub const zx_type_257 = struct { *const zx_type_202, };

pub const zx_type_258 = struct { *const zx_type_202, *const zx_type_201, };

pub const zx_type_259 = struct { *const zx_type_202, *const zx_type_201, *const zx_type_154, };

pub const zx_type_260 = struct { *const zx_type_202, *const zx_type_201, *const zx_type_154, *const zx_type_209, };

pub const zx_type_261 = struct { *const zx_type_202, *const zx_type_201, *const zx_type_209, };

pub const zx_type_262 = struct { *const zx_type_202, *const zx_type_201, *const zx_type_209, *const zx_type_154, };

pub const zx_type_263 = struct { *const zx_type_202, *const zx_type_201, *const zx_type_209, *const zx_type_154, *const zx_type_209, };

pub const zx_type_264 = struct { *const zx_type_202, *const zx_type_201, *const zx_type_209, *const zx_type_209, };

pub const zx_type_265 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    index: u64,
    names: []const []const u8,
    state: *const zx_type_204,
    types: []const u32,
};

pub const zx_type_266 = struct { *const zx_type_153, *const zx_type_204, };

pub const zx_type_267 = struct { *const zx_type_153, *const zx_type_204, *const zx_type_199, };

pub const zx_type_268 = struct { *const zx_type_153, *const zx_type_204, *const zx_type_199, *const zx_type_201, };

pub const zx_type_269 = struct { *const zx_type_153, *const zx_type_204, *const zx_type_199, *const zx_type_201, *const zx_type_206, };

pub const value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_11 = null,
};

pub const value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
    zx_origin: ?*const zx_type_15 = null,
};

pub const value_zx_type_16_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53 = struct {
    base: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    delta: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    base: *const zx_type_18,
    delta: *const zx_type_18,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_21_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_21 = null,
};

pub const value_zx_type_28_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    end: u64,
    last_byte: u8,
    phase: zx_type_27,
    separators_valid: bool,
    zx_origin: ?*const zx_type_28 = null,
};

pub const value_zx_type_29_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    diagnostic: []const u8,
    end: u64,
    zx_origin: ?*const zx_type_29 = null,
};

pub const value_zx_type_36_14f151be98723b44a65ef54272e86f37e634a51c57971b7cdbf77db5daef53fc = struct {
    ahead_one: u8,
    ahead_two: u8,
    braces: u64,
    comments: []const *const zx_type_25,
    depth: u64,
    diagnostic: *const zx_type_31,
    dollar: bool,
    frames: []const *const zx_type_32,
    keyword_state: u64,
    line_break: bool,
    mode: zx_type_30,
    number: value_zx_type_28_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    offset: u64,
    skip_until: u64,
    source_length: u64,
    start: u64,
    symbol: zx_type_24,
    tokens: []const *const zx_type_26,
    warmed: u8,
    zx_origin: ?*const zx_type_36 = null,
};

pub const value_zx_type_37_e1ffa7811185b0059f03a475523fa4c6e0b5b5a864f30612add6a83cb730f9cf = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    state: value_zx_type_36_14f151be98723b44a65ef54272e86f37e634a51c57971b7cdbf77db5daef53fc,
    zx_origin: ?*const zx_type_37 = null,
};

pub const value_zx_type_45_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    fields: []const u64,
    heads: []const u64,
    items: []const u64,
    zx_origin: ?*const zx_type_45 = null,
};

pub const value_zx_type_49_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    fields: []const *const zx_type_42,
    items: []const *const zx_type_43,
    nodes: []const *const zx_type_41,
    zx_origin: ?*const zx_type_49 = null,
};

pub const value_zx_type_51_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    depth: u64,
    diagnostic: *const zx_type_31,
    index: u64,
    name: *const zx_type_25,
    phase: zx_type_40,
    result: u64,
    start: u64,
    token: *const zx_type_26,
    zx_origin: ?*const zx_type_51 = null,
};

pub const value_zx_type_53_3d4acdf86258039cbdbe5c274a8acd76d0c1d090dc7f46092a910e9027d72b99 = struct {
    control: value_zx_type_51_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    frames: []const *const zx_type_50,
    tree: value_zx_type_49_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_53 = null,
};

pub const value_zx_type_56_1f6cf931ff1653b987809c8802c1c5135603b2eaa9fca3d6a77de94ccab3545b = struct {
    count: u64,
    depth: u64,
    diagnostic: *const zx_type_31,
    enumeration: bool,
    first: u64,
    index: u64,
    last_end: u64,
    name: *const zx_type_25,
    opening: u64,
    opening_index: u64,
    phase: zx_type_54,
    start: u64,
    token: *const zx_type_26,
    type_diagnostic: bool,
    zx_origin: ?*const zx_type_56 = null,
};

pub const value_zx_type_58_d4c36911b9e29c07c9fb12b56567bd5ba9d6014af03c3a6e74374757c00d5bea = struct {
    control: value_zx_type_56_1f6cf931ff1653b987809c8802c1c5135603b2eaa9fca3d6a77de94ccab3545b,
    declarations: []const *const zx_type_55,
    members: []const *const zx_type_25,
    types: value_zx_type_53_3d4acdf86258039cbdbe5c274a8acd76d0c1d090dc7f46092a910e9027d72b99,
    zx_origin: ?*const zx_type_58 = null,
};

pub const value_zx_type_73_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    declarations: []const *const zx_type_65,
    enumerations: []const *const zx_type_66,
    fields: []const *const zx_type_63,
    items: []const *const zx_type_64,
    members: []const *const zx_type_60,
    nodes: []const *const zx_type_62,
    zx_origin: ?*const zx_type_73 = null,
};

pub const value_zx_type_74_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    members: []const *const zx_type_25,
    order: value_zx_type_45_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_49_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_74 = null,
};

pub const value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203 = struct {
    indexed: value_zx_type_74_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97,
    native: ?value_zx_type_73_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_76 = null,
};

pub const value_zx_type_79_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441 = struct {
    aliases: *const zx_type_78,
    base: *const zx_type_18,
    native_interface: bool,
    resolved: *const zx_type_78,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    visiting: []const []const u8,
    zx_origin: ?*const zx_type_79 = null,
};

pub const value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72 = struct {
    active: []const []const u8,
    cache: *const zx_type_78,
    context: value_zx_type_79_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    frames: []const *const zx_type_80,
    result: u32,
    scratch: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_82 = null,
};

pub const value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2 = struct {
    cache: *const zx_type_78,
    context: value_zx_type_79_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441,
    delta: *const zx_type_18,
    initialize: bool,
    name: *const zx_type_60,
    named: bool,
    reference: *const zx_type_61,
    zx_origin: ?*const zx_type_83 = null,
};

pub const value_zx_type_84_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
    zx_origin: ?*const zx_type_84 = null,
};

pub const value_zx_type_93_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    events: []const *const zx_type_89,
    lexed: *const zx_type_38,
    parts: []const *const zx_type_88,
    templates: []const *const zx_type_87,
    token_templates: []const u64,
    zx_origin: ?*const zx_type_93 = null,
};

pub const value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    interpolations: []const *const zx_type_94,
    lexed: *const zx_type_38,
    parts: []const *const zx_type_88,
    templates: []const *const zx_type_87,
    token_templates: []const u64,
    zx_origin: ?*const zx_type_96 = null,
};

pub const value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    after_identifier: bool,
    arrow: bool,
    hints: []const *const zx_type_100,
    parameter_start: bool,
    zx_origin: ?*const zx_type_102 = null,
};

pub const value_zx_type_104_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1 = struct {
    hints: []const *const zx_type_100,
    interpolation_hints: []const []const *const zx_type_100,
    lexical: value_zx_type_96_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_104 = null,
};

pub const value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    arms: []const *const zx_type_112,
    fields: []const *const zx_type_109,
    items: []const *const zx_type_43,
    nodes: []const *const zx_type_108,
    parameters: []const *const zx_type_110,
    parts: []const *const zx_type_111,
    zx_origin: ?*const zx_type_118 = null,
};

pub const value_zx_type_122_b14d81bd852082d928c7e97a3a48f317953fa9f765bc0c0407cdb3f926b69b5e = struct {
    control: *const zx_type_120,
    frames: []const *const zx_type_119,
    prepared: value_zx_type_104_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1,
    tree: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_53_3d4acdf86258039cbdbe5c274a8acd76d0c1d090dc7f46092a910e9027d72b99,
    zx_origin: ?*const zx_type_122 = null,
};

pub const value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    blocks: []const *const zx_type_87,
    cases: []const *const zx_type_128,
    items: []const *const zx_type_43,
    names: []const *const zx_type_127,
    statements: []const *const zx_type_126,
    zx_origin: ?*const zx_type_132 = null,
};

pub const value_zx_type_138_8479351ede6be59f4cda24c2c469bcb9266110074e57ce839eee441715fb7524 = struct {
    control: *const zx_type_134,
    expression: value_zx_type_122_b14d81bd852082d928c7e97a3a48f317953fa9f765bc0c0407cdb3f926b69b5e,
    frame: *const zx_type_133,
    frames: []const *const zx_type_133,
    suspended: []const *const zx_type_136,
    tree: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_138 = null,
};

pub const value_zx_type_141_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    contract_start: u64,
    diagnostic: *const zx_type_31,
    ensures: bool,
    expression_diagnostic: bool,
    has_ensures: bool,
    has_store: bool,
    phase: zx_type_139,
    token: *const zx_type_26,
    zx_origin: ?*const zx_type_141 = null,
};

pub const value_zx_type_143_2b945e954668d79a1828a63af686318e734737f524f3484029ebbdb1c25be8f2 = struct {
    body: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    contracts: []const *const zx_type_140,
    control: value_zx_type_141_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    expression: value_zx_type_122_b14d81bd852082d928c7e97a3a48f317953fa9f765bc0c0407cdb3f926b69b5e,
    zx_origin: ?*const zx_type_143 = null,
};

pub const value_zx_type_147_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d = struct {
    count: u64,
    diagnostic: *const zx_type_31,
    first: u64,
    index: u64,
    named: bool,
    opening: *const zx_type_25,
    path: *const zx_type_25,
    phase: zx_type_144,
    start: u64,
    token: *const zx_type_26,
    type_only: bool,
    zx_origin: ?*const zx_type_147 = null,
};

pub const value_zx_type_149_74ed739624cff66047721e4df18908cd0e813cc99bd4a24ae4f125763c8bb979 = struct {
    control: value_zx_type_147_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d,
    imports: []const *const zx_type_146,
    names: []const *const zx_type_25,
    zx_origin: ?*const zx_type_149 = null,
};

pub const value_zx_type_151_3191ede17c96f03fe92fcee2a142bf07dadade62fc1258eb19ab63856e0a826a = struct {
    blocks: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    body: ?u64,
    comments: []const *const zx_type_25,
    contracts: []const *const zx_type_140,
    declarations: []const *const zx_type_55,
    diagnostic: *const zx_type_31,
    expressions: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    function_start: u64,
    has_store: bool,
    import_names: []const *const zx_type_25,
    imports: []const *const zx_type_146,
    members: []const *const zx_type_25,
    tokens: []const *const zx_type_26,
    type_order: value_zx_type_45_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_49_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_151 = null,
};

pub const value_zx_type_152_d14aba735b0c187625e56713e243f7433aa1db3df3f6db783432ba1fe4c75e84 = struct {
    blocks: value_zx_type_132_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    comments: []const *const zx_type_25,
    diagnostic: *const zx_type_31,
    expressions: value_zx_type_118_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    result: u64,
    tokens: []const *const zx_type_26,
    type_order: value_zx_type_45_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_49_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_152 = null,
};

pub const value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1 = struct {
    aliases: *const zx_type_78,
    bytes: []const u8,
    nominal_base: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    nominal_origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    shared: bool,
    syntax: value_zx_type_151_3191ede17c96f03fe92fcee2a142bf07dadade62fc1258eb19ab63856e0a826a,
    type_base: *const zx_type_18,
    zx_origin: ?*const zx_type_153 = null,
};

pub const value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380 = struct {
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    request: value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2,
    shared: bool,
    zx_origin: ?*const zx_type_154 = null,
};

pub const value_zx_type_155_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    name: *const zx_type_60,
    operation: zx_type_77,
    reference: *const zx_type_61,
    zx_origin: ?*const zx_type_155 = null,
};

pub const value_zx_type_156_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_156 = null,
};

pub const value_zx_type_157_ce77ce34d8b07d2d8cf3d14edad6ab93dcb0763a67b7d556988b9d1c501ca5d6 = struct {
    code: []const u8,
    message: []const u8,
    name: *const zx_type_60,
    state: value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_157 = null,
};

pub const value_zx_type_159_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    source: []const u8,
    span: *const zx_type_25,
    zx_origin: ?*const zx_type_159 = null,
};

pub const value_zx_type_160_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    index: u64,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_160 = null,
};

pub const value_zx_type_161_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b = struct {
    limit: u64,
    name: []const u8,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_161 = null,
};

pub const value_zx_type_162_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    index: u64,
    zx_origin: ?*const zx_type_162 = null,
};

pub const value_zx_type_163_1f89c88e8344df3ff0e1ae6aeca43f8d4c75d21269ca1cbbd88f24f6f34f4e80 = struct {
    index: u64,
    state: value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_163 = null,
};

pub const value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_164 = null,
};

pub const value_zx_type_165_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_165 = null,
};

pub const value_zx_type_166_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    delta: *const zx_type_18,
    id: u32,
    zx_origin: ?*const zx_type_166 = null,
};

pub const value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d = struct {
    children: []const u32,
    count: u64,
    field_names: []const []const u8,
    field_types: []const u32,
    first: u32,
    kind: zx_type_17,
    label: []const u8,
    names: []const []const u8,
    offset: u64,
    second: u32,
    zx_origin: ?*const zx_type_167 = null,
};

pub const value_zx_type_168_6f975b180818098029dbaef75bb89bfea5e3cb89ee69a1d9370d1963760c4a33 = struct {
    left: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    right: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_168 = null,
};

pub const value_zx_type_169_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u64,
    table: *const zx_type_18,
    zx_origin: ?*const zx_type_169 = null,
};

pub const value_zx_type_170_2c4a87f781c651962259ae1ef67d878ae312a61c3d14b66307e5fd0a9c7f1e1e = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    id: u32,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_170 = null,
};

pub const value_zx_type_171_f9f434bc9d0869ee4fe93b8f2d75449d97ec21cc1ea12455f1df810be7821e22 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_171 = null,
};

pub const value_zx_type_172_655f2c15f8b96113ed59dee46636710e0c7433f1f71d56fc2c400bda5a955e85 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    delta: *const zx_type_18,
    zx_origin: ?*const zx_type_172 = null,
};

pub const value_zx_type_173_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_173 = null,
};

pub const value_zx_type_174_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    code: []const u8,
    message: []const u8,
    zx_origin: ?*const zx_type_174 = null,
};

pub const value_zx_type_175_655f2c15f8b96113ed59dee46636710e0c7433f1f71d56fc2c400bda5a955e85 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    table: *const zx_type_18,
    zx_origin: ?*const zx_type_175 = null,
};

pub const value_zx_type_176_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    delta: *const zx_type_18,
    diagnostic: value_zx_type_174_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    id: u32,
    zx_origin: ?*const zx_type_176 = null,
};

pub const value_zx_type_177_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u32,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_177 = null,
};

pub const value_zx_type_179_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_179 = null,
};

pub const value_zx_type_180_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    id: u32,
    native_references: bool,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_180 = null,
};

pub const value_zx_type_182_5443cbe39f2296ef486982bb05040a6b5c31305900fd32c8ae6836a1865363f0 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    state: value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_182 = null,
};

pub const value_zx_type_183_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b = struct {
    enumeration: u64,
    index: u64,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_183 = null,
};

pub const value_zx_type_184_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    reference: *const zx_type_61,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_184 = null,
};

pub const value_zx_type_185_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    cache: *const zx_type_78,
    name: []const u8,
    zx_origin: ?*const zx_type_185 = null,
};

pub const value_zx_type_186_1f89c88e8344df3ff0e1ae6aeca43f8d4c75d21269ca1cbbd88f24f6f34f4e80 = struct {
    frame: *const zx_type_80,
    state: value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_186 = null,
};

pub const value_zx_type_187_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    position: u64,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_187 = null,
};

pub const value_zx_type_189_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    status: zx_type_188,
    zx_origin: ?*const zx_type_189 = null,
};

pub const value_zx_type_190_edb46a81e3a9250d692663665486205b0963b7c46abe2f9b6643551737beb15e = struct {
    base: *const zx_type_18,
    delta: *const zx_type_18,
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_190 = null,
};

pub const value_zx_type_191_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922 = struct {
    conflict: bool,
    delta: *const zx_type_18,
    mapping: []const u32,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_191 = null,
};

pub const value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    first: u64,
    ids: []const u32,
    zx_origin: ?*const zx_type_192 = null,
};

pub const value_zx_type_193_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u32,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_193 = null,
};

pub const value_zx_type_194_fbdd0bbee4e5905ca68915c135c8f5ba02cf4ff8d787022f425a507d94539e8c = struct {
    delta: *const zx_type_18,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    source: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_194 = null,
};

pub const value_zx_type_195_f3e136596bb913040d3acf380956e911a786d1381833906adfd4791f1895a977 = struct {
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    source: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    target: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_195 = null,
};

pub const value_zx_type_196_2f01dc5af85efb2d97af6c7b092cb0b1f9d76fe55ba3ba47bf7d26986d7815c8 = struct {
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_16_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53,
    source: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_196 = null,
};

pub const value_zx_type_197_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    cache: *const zx_type_78,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_197 = null,
};

pub const value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7 = struct {
    cache: *const zx_type_78,
    context: value_zx_type_79_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441,
    delta: *const zx_type_18,
    nominal_delta: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_198 = null,
};

pub const value_zx_type_199_ee565463f313c9d711932bf14a19be11863724c9e714899f504bb13d821874f0 = struct {
    diagnostic: *const zx_type_31,
    export_names: []const []const u8,
    export_types: []const u32,
    has_store: bool,
    input_type: u32,
    nominal_delta: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    output_type: u32,
    type_delta: *const zx_type_18,
    type_only: bool,
    zx_origin: ?*const zx_type_199 = null,
};

pub const value_zx_type_200_0aa0f914228dcbbd52c94345f912657f94d5a34cf58211ee7f1e81ca9cadfa69 = struct {
    diagnostic: *const zx_type_31,
    syntax: value_zx_type_151_3191ede17c96f03fe92fcee2a142bf07dadade62fc1258eb19ab63856e0a826a,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_200 = null,
};

pub const value_zx_type_201_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3 = struct {
    diagnostic: *const zx_type_31,
    input_type: u32,
    output_type: u32,
    span: *const zx_type_25,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_201 = null,
};

pub const value_zx_type_202_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b = struct {
    syntax: value_zx_type_151_3191ede17c96f03fe92fcee2a142bf07dadade62fc1258eb19ab63856e0a826a,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_202 = null,
};

pub const value_zx_type_203_0ea70a654c996b481d21adcf7d737d39c48dd562c004794b63fd546bbbe193d3 = struct {
    name: []const u8,
    span: *const zx_type_25,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_203 = null,
};

pub const value_zx_type_204_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06 = struct {
    diagnostic: *const zx_type_31,
    types: value_zx_type_198_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_204 = null,
};

pub const value_zx_type_205_2e61a7d9f47f8c697d801934be9cb7fec9e6a21a252e16894cc6812cd5ac8624 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    state: value_zx_type_204_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06,
    zx_origin: ?*const zx_type_205 = null,
};

pub const value_zx_type_206_cf4ab152ee80a8016752d39fd09af8928e2d7716ad96a00f10be66b0795e522c = struct {
    names: []const []const u8,
    state: value_zx_type_204_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06,
    types: []const u32,
    zx_origin: ?*const zx_type_206 = null,
};

pub const value_zx_type_207_56c79498c37c5667191d97e794b32d1e25a0a9ed76677cf81f818eabc8e5fe2f = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_207 = null,
};

pub const value_zx_type_208_5f3fab7672bc9f4282fc2bfebcc6766a78f4338d475a4aef0a532ed1976e547e = struct {
    base: *const zx_type_18,
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    id: u32,
    origin: value_zx_type_11_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_208 = null,
};

pub const value_zx_type_209_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554 = struct {
    cache: *const zx_type_78,
    delta: *const zx_type_18,
    diagnostic: *const zx_type_31,
    id: u32,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    publish: bool,
    zx_origin: ?*const zx_type_209 = null,
};

pub const value_zx_type_210_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_210 = null,
};

pub const value_zx_type_211_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, []const u8, ?*const zx_type_211, };

pub const value_zx_type_212_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    selected: u64,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_212 = null,
};

pub const value_zx_type_213_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, []const []const u8, ?*const zx_type_213, };

pub const value_zx_type_214_c112291784b95a088b8165381f6507d0f20b29ff9da2fb78d0ffff47dfc8012c = struct {
    count: u64,
    index: u64,
    state: value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_214 = null,
};

pub const value_zx_type_215_069a7ea61cfb445517edf055c511f09555d98c65d5dabbbf56f319da889b646f = struct { value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_215, };

pub const value_zx_type_216_997a00fdf8ac3d8f5d11296afb04111770aaaddeb73f1727104ad7827dfb64b9 = struct { value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_216, };

pub const value_zx_type_217_07d29144135453d3b73bd99c103d4e9e7f95f2b78fa387faa9e763801bc07ebe = struct { value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_217, };

pub const value_zx_type_218_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, void, ?*const zx_type_218, };

pub const value_zx_type_219_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, void, ?*const zx_type_219, };

pub const value_zx_type_221_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const []const u8, ?[]const u8, ?*const zx_type_221, };

pub const value_zx_type_223_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_80, ?*const zx_type_80, ?*const zx_type_223, };

pub const value_zx_type_224_713639bf2340277cb2fc17b55239d7eafff49067cfedc85ab5bd099cd1d4078d = struct {
    equal: bool,
    index: u64,
    left: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    right: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_224 = null,
};

pub const value_zx_type_225_0e70c693f6adee041b71153b65d39c537ba5de74cae3bc9eba48950bd94db775 = struct {
    candidate: value_zx_type_164_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    count: u64,
    found: bool,
    id: u32,
    index: u64,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_225 = null,
};

pub const value_zx_type_226_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, void, ?*const zx_type_226, };

pub const value_zx_type_227_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    limit: u64,
    right: []const u8,
    zx_origin: ?*const zx_type_227 = null,
};

pub const value_zx_type_228_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    building: bool,
    count: u64,
    names: []const []const u8,
    remaining: u64,
    root: u64,
    sifting: bool,
    types: []const u32,
    zx_origin: ?*const zx_type_228 = null,
};

pub const value_zx_type_229_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
    zx_origin: ?*const zx_type_229 = null,
};

pub const value_zx_type_230_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    target: zx_type_17,
    zx_origin: ?*const zx_type_230 = null,
};

pub const value_zx_type_231_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_231 = null,
};

pub const value_zx_type_232_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, void, ?*const zx_type_232, };

pub const value_zx_type_233_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    children: []const u32,
    found: bool,
    index: u64,
    tables: value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_233 = null,
};

pub const value_zx_type_234_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = struct {
    count: u64,
    diagnostic: *const zx_type_31,
    enumeration: u64,
    index: u64,
    names: []const []const u8,
    source: value_zx_type_76_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_234 = null,
};

pub const value_zx_type_235_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    cache: *const zx_type_78,
    found: bool,
    id: u32,
    index: u64,
    name: []const u8,
    zx_origin: ?*const zx_type_235 = null,
};

pub const value_zx_type_236_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_80, void, ?*const zx_type_236, };

pub const value_zx_type_237_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, []const u32, ?*const zx_type_237, };

pub const value_zx_type_238_90fe70fa5d2d4c69af4dc354ff484cde4f742eadfc88af37b0709510fab97410 = struct { value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, ?*const zx_type_238, };

pub const value_zx_type_239_1b7a94226e1adb4685c1fa613f3f77c323dc421ecdbae8cfe9089c85d51102d0 = struct { value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_239, };

pub const value_zx_type_240_bfc1740ffee8c8ed5a138d86c027163d38443f5478ce225817f6bca9761197af = struct { value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_240, };

pub const value_zx_type_241_f9b0821e8e8c23d3efb7e66c63da1fdac46b8458b9acbca9413e99ea98017969 = struct { value_zx_type_83_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_82_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_241, };

pub const value_zx_type_242_a3fe0196c6a98cfbd9a56f1317fcde22066a51e3316d0e7cfcb4f577c5514d51 = struct {
    count: u64,
    delta: *const zx_type_18,
    index: u64,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    source: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_242 = null,
};

pub const value_zx_type_243_2946eb56f574decc3beba0a63587d6aae87c317cb8009b9a0f5cb9d43419d82b = struct {
    equal: bool,
    index: u64,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    source: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    target: value_zx_type_167_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_243 = null,
};

pub const value_zx_type_244_088f15199dcba55be3978f31a93503ede4d44a0b4a0de0a77763261b7a067457 = struct {
    count: u64,
    id: u32,
    index: u64,
    input: value_zx_type_196_2f01dc5af85efb2d97af6c7b092cb0b1f9d76fe55ba3ba47bf7d26986d7815c8,
    nominal: bool,
    status: zx_type_188,
    zx_origin: ?*const zx_type_244 = null,
};

pub const value_zx_type_245_79b27826adb70cc6a7983ee71225ce16c523afb5eb5c7a9b9c97368b767ca3ed = struct {
    conflict: bool,
    delta: *const zx_type_18,
    index: u64,
    input: value_zx_type_190_edb46a81e3a9250d692663665486205b0963b7c46abe2f9b6643551737beb15e,
    mapping: []const u32,
    origins: value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_245 = null,
};

pub const value_zx_type_246_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    cache: *const zx_type_78,
    ids: []const u32,
    index: u64,
    mapping: value_zx_type_192_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_246 = null,
};

pub const value_zx_type_247_6f2481ba9940bd2da192eaf8958b6391d367d01df05d805f5ef26cfbf718de7e = struct { value_zx_type_208_5f3fab7672bc9f4282fc2bfebcc6766a78f4338d475a4aef0a532ed1976e547e, ?*const zx_type_247, };

pub const value_zx_type_248_487e144abcf7b3c4f2ca7aab6bdc89e64a59232c2c0352991a87f722ddb6bd06 = struct { value_zx_type_208_5f3fab7672bc9f4282fc2bfebcc6766a78f4338d475a4aef0a532ed1976e547e, value_zx_type_191_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922, ?*const zx_type_248, };

pub const value_zx_type_249_a131eceb6b89ca74a723085e2d8102410a529ed5cc6f0f423950df93552e6949 = struct { value_zx_type_208_5f3fab7672bc9f4282fc2bfebcc6766a78f4338d475a4aef0a532ed1976e547e, value_zx_type_191_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922, *const zx_type_78, ?*const zx_type_249, };

pub const value_zx_type_250_41b7d28f331f01f75420a6252ecc7a2111231505c4af92f595c8de342905a75d = struct { value_zx_type_208_5f3fab7672bc9f4282fc2bfebcc6766a78f4338d475a4aef0a532ed1976e547e, value_zx_type_191_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922, *const zx_type_78, u32, ?*const zx_type_250, };

pub const value_zx_type_251_41ec322f90878c59bb89c3f34a72452bd6c2155a538712e3bfed837562ed34b4 = struct { value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, ?*const zx_type_251, };

pub const value_zx_type_252_b2d09c3ab85e0936afb4a7cf680a994e7cdfb41628b56ddc477c90e6c2137e23 = struct { value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, value_zx_type_84_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, ?*const zx_type_252, };

pub const value_zx_type_253_ed7965c10a3305ddeb26dc57e8c378252f301142168e1f9860f1391f5dc9de9b = struct { value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, value_zx_type_84_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_207_56c79498c37c5667191d97e794b32d1e25a0a9ed76677cf81f818eabc8e5fe2f, ?*const zx_type_253, };

pub const value_zx_type_254_ebda8f5d9040583b3510f8e9c7e91fe8b479137d958985c590a16f9d2d5161dc = struct { value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1, ?*const zx_type_254, };

pub const value_zx_type_255_2b61d0f8be4897c10787470ae0c8863817ff7a29b91be11e54e2ca7e137dc259 = struct { value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, ?*const zx_type_255, };

pub const value_zx_type_256_91c704f6e0ae6c09e7e8724276aee9f189aa910f74fc37b07e00a86a93a89115 = struct { value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, value_zx_type_209_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, ?*const zx_type_256, };

pub const value_zx_type_257_e7430df5f09133acc89066a4936bae8fb9366dbcd73ff7d6fa8294b824765d42 = struct { value_zx_type_202_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, ?*const zx_type_257, };

pub const value_zx_type_258_fffe9972c909e11f7d04cc7ffc011451e4727a7b4e9d7e4877dab78f44512de8 = struct { value_zx_type_202_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_201_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, ?*const zx_type_258, };

pub const value_zx_type_259_26c7a84ddb13da1c89ef21645814fcba257b9c230975d97fe8accde190679fe7 = struct { value_zx_type_202_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_201_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, ?*const zx_type_259, };

pub const value_zx_type_260_02e0c5bafba240f4f38be82a88fbf6d59969a87344ce828a0d958ef7d4dd8e88 = struct { value_zx_type_202_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_201_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, value_zx_type_209_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, ?*const zx_type_260, };

pub const value_zx_type_261_9c7fcbe03413e0e23adcd3198506aaea02fc55e171b19e6a169c97b531cee443 = struct { value_zx_type_202_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_201_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_209_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, ?*const zx_type_261, };

pub const value_zx_type_262_4d8c4b73175ba3eaa16d96cac2868ce36bcd4fb0e2e703e2f2fe680bdbaa8c09 = struct { value_zx_type_202_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_201_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_209_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, ?*const zx_type_262, };

pub const value_zx_type_263_5b65ceaa8b163558bb127e5e3e2f256e5d651d3418e90b2e6ae8f5b399099bc1 = struct { value_zx_type_202_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_201_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_209_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, value_zx_type_154_151cf511ce56d16bf0e5c4b2eaac8ccd0d2c5da1f6779bce66bca5672c0f6380, value_zx_type_209_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, ?*const zx_type_263, };

pub const value_zx_type_264_36df866b92e594bff4ff7a1d977d57e2bf8050d286d69a1ee191611e870c32ee = struct { value_zx_type_202_2c4e3f0706edfba57324fe5b9b0ab05e372189c573981da2128b460d106c067b, value_zx_type_201_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_209_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, value_zx_type_209_45883014c2f29803857ff2d38bdc1c0ce44b73e301274465e4b4f75aa0856554, ?*const zx_type_264, };

pub const value_zx_type_265_26c432f22e1355cd92b94e1e9662e733933dfa13383067717933fd8faffc0d1e = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_55,
    index: u64,
    names: []const []const u8,
    state: value_zx_type_204_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06,
    types: []const u32,
    zx_origin: ?*const zx_type_265 = null,
};

pub const value_zx_type_266_c5f0fe9b7a0048368acd9d95e9ad4535c7827896e269b4d26d91e453013975e5 = struct { value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1, value_zx_type_204_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, ?*const zx_type_266, };

pub const value_zx_type_267_cc59257c697d997ac626dade72e1c3a14529be323e2489bf74be1c80c0512c2b = struct { value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1, value_zx_type_204_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, value_zx_type_199_ee565463f313c9d711932bf14a19be11863724c9e714899f504bb13d821874f0, ?*const zx_type_267, };

pub const value_zx_type_268_bca606c67319a21996f2d76634d79ad50015f98d39c6347c51e1faf86ef952fa = struct { value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1, value_zx_type_204_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, value_zx_type_199_ee565463f313c9d711932bf14a19be11863724c9e714899f504bb13d821874f0, value_zx_type_201_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, ?*const zx_type_268, };

pub const value_zx_type_269_1ff494cd6180ca69400c017b156ea248af182f2bf7a81511c53df3ab53f35466 = struct { value_zx_type_153_e65d4dd98e6caa5abdb2f6b602d260e4320300e9f0ffcb41d3f6ac3db1e955d1, value_zx_type_204_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06, value_zx_type_199_ee565463f313c9d711932bf14a19be11863724c9e714899f504bb13d821874f0, value_zx_type_201_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3, value_zx_type_206_cf4ab152ee80a8016752d39fd09af8928e2d7716ad96a00f10be66b0795e522c, ?*const zx_type_269, };

pub const native = struct {
    pub const @"std:encoding" = struct {
        pub const encodeBase64 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeBase64 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const encodeHex = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeHex = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const encodeUtf8 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeUtf8 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const sliceBytes = struct {
            pub const Input = *const zx_type_158;
            pub const Output = []const u8;
            pub const InputValue = zx_type_158;
            pub const OutputValue = []const u8;
        };
    };
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"std:encoding" = struct {
    };
    pub const @"zig:integers" = struct {
    };
};

