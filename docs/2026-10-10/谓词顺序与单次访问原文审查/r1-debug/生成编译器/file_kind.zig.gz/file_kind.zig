const std = @import("std");

const zx_type_12 = struct {
    offset: u64,
    source: []const u8,
    text: []const u8,
};

const zx_type_13 = struct {
    pattern: []const u8,
    source: []const u8,
};

const zx_type_14 = struct {
    pattern: []const u8,
    source: []const u8,
    start: u64,
};

const zx_type_15 = enum { App, Gateway, Store, Module, Invalid, };

const zx_type_16 = struct {
    index: u64,
    matches: bool,
    offset: u64,
    source: []const u8,
    text: []const u8,
};

const zx_type_17 = struct { []const u8, };

const zx_type_18 = struct { []const u8, zx_type_15, };

const value_zx_type_12_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    offset: u64,
    source: []const u8,
    text: []const u8,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    pattern: []const u8,
    source: []const u8,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    pattern: []const u8,
    source: []const u8,
    start: u64,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    matches: bool,
    offset: u64,
    source: []const u8,
    text: []const u8,
    zx_origin: ?*const zx_type_16 = null,
};

const value_zx_type_17_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = struct { []const u8, ?*const zx_type_17, };

const value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, zx_type_15, ?*const zx_type_18, };

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .offset = zx_shape_5, .source = zx_shape_11, .text = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .pattern = zx_shape_11, .source = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .pattern = zx_shape_11, .source = zx_shape_11, .start = zx_shape_5, }, };

const zx_shape_15 = .{ .kind = .scalar, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .matches = zx_shape_1, .offset = zx_shape_5, .source = zx_shape_11, .text = zx_shape_11, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_15, }, };

pub const input_shape = zx_shape_11;

pub const output_shape = zx_shape_15;

pub const Input = []const u8;

pub const Output = zx_type_15;

fn function_0(allocator: ((std).mem).Allocator, in: *const zx_type_12) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    if ((((in).offset > @as(u64, ((in).source).len)) or (@as(u64, ((in).text).len) > (@as(u64, ((in).source).len) - (in).offset)))) {
        return false;
    }

    return (block_24: {
        const operand_8 = block_7: {
            const operand_2 = (in).source;
            const operand_3 = (in).offset;
            const operand_4 = (in).text;
            const operand_5 = @as(u64, 0);
            const operand_6 = true;

            break :block_7 zx_type_16{ .source = operand_2, .offset = operand_3, .text = operand_4, .index = operand_5, .matches = operand_6, };
        };

        var state_1: value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .index = (operand_8).index, .matches = (operand_8).matches, .offset = (operand_8).offset, .source = (operand_8).source, .text = (operand_8).text, .zx_origin = (&operand_8), };

        while (((state_1).matches and ((state_1).index < @as(u64, ((state_1).text).len)))) {
            state_1 = block_21: {
                const value_3: bool = (block_17: {
                    const operand_15 = (state_1).source;
                    const operand_16 = ((state_1).offset + (state_1).index);

                    if ((operand_16 >= (operand_15).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_17 (operand_15)[@intCast(operand_16)];
                } == block_20: {
                    const operand_18 = (state_1).text;
                    const operand_19 = (state_1).index;

                    if ((operand_19 >= (operand_18).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_20 (operand_18)[@intCast(operand_19)];
                });
                const value_4: u64 = ((state_1).index + @as(u64, 1));
                const value_5: value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_14: {
                    const operand_9 = state_1;
                    const operand_10 = block_11: {
                        break :block_11 value_4;
                    };
                    const operand_12 = block_13: {
                        break :block_13 value_3;
                    };

                    break :block_14 @as(value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .index = operand_10, .matches = operand_12, .offset = (operand_9).offset, .source = (operand_9).source, .text = (operand_9).text, });
                };

                break :block_21 value_5;
            };
        }

        break :block_24 block_23: {
            break :block_23 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_22: {
                break :block_22 zx_type_16{ .index = (state_1).index, .matches = (state_1).matches, .offset = (state_1).offset, .source = (state_1).source, .text = (state_1).text, };
            });
        };
    }).matches;
}

fn function_1(allocator: ((std).mem).Allocator, in: *const zx_type_13) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if ((@as(u64, ((in).source).len) < @as(u64, ((in).pattern).len))) {
        return false;
    }

    return block_5: {
        const operand_1 = (in).source;
        const operand_2 = (@as(u64, ((in).source).len) - @as(u64, ((in).pattern).len));
        const operand_3 = (in).pattern;
        const operand_4 = zx_type_12{ .source = operand_1, .offset = operand_2, .text = operand_3, };

        break :block_5 (try function_0(allocator, (&operand_4)));
    };
}

fn function_2(allocator: ((std).mem).Allocator, in: *const zx_type_14) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    return (((@as(u64, ((in).source).len) - (in).start) == @as(u64, ((in).pattern).len)) and block_5: {
        const operand_1 = (in).source;
        const operand_2 = (in).start;
        const operand_3 = (in).pattern;
        const operand_4 = zx_type_12{ .source = operand_1, .offset = operand_2, .text = operand_3, };

        break :block_5 (try function_0(allocator, (&operand_4)));
    });
}

fn function_3(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!zx_type_15 {
    @setRuntimeSafety(true);

    if (block_17: {
        const operand_13 = in;
        const operand_14 = @as(u64, 0);
        const operand_15 = @as([]const u8, (comptime (&[_]u8{@as(u8, 97), @as(u8, 112), @as(u8, 112), @as(u8, 46), @as(u8, 114), @as(u8, 120), })));
        const operand_16 = zx_type_14{ .source = operand_13, .start = operand_14, .pattern = operand_15, };

        break :block_17 (try function_2(allocator, (&operand_16)));
    }) {
        return @as(zx_type_15, .App);
    }

    if (block_12: {
        const operand_9 = in;
        const operand_10 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 103), @as(u8, 97), @as(u8, 116), @as(u8, 101), @as(u8, 119), @as(u8, 97), @as(u8, 121), @as(u8, 46), @as(u8, 114), @as(u8, 120), })));
        const operand_11 = zx_type_13{ .source = operand_9, .pattern = operand_10, };

        break :block_12 (try function_1(allocator, (&operand_11)));
    }) {
        return @as(zx_type_15, .Gateway);
    }

    if (block_8: {
        const operand_5 = in;
        const operand_6 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 115), @as(u8, 116), @as(u8, 111), @as(u8, 114), @as(u8, 101), @as(u8, 46), @as(u8, 114), @as(u8, 120), })));
        const operand_7 = zx_type_13{ .source = operand_5, .pattern = operand_6, };

        break :block_8 (try function_1(allocator, (&operand_7)));
    }) {
        return @as(zx_type_15, .Store);
    }

    return (if (block_4: {
        const operand_1 = in;
        const operand_2 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 114), @as(u8, 120), })));
        const operand_3 = zx_type_13{ .source = operand_1, .pattern = operand_2, };

        break :block_4 (try function_1(allocator, (&operand_3)));
    }) @as(zx_type_15, .Module) else @as(zx_type_15, .Invalid));
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!zx_type_15 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: zx_type_15 = (try function_3(allocator, in));

    return value_1;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!zx_type_15 {
    @setRuntimeSafety(true);

    const value_1: zx_type_15 = (try function_3(allocator, in));

    return value_1;
}

