pub const zx_type_11 = enum { Source, Native, External, Compiled, };

pub const zx_type_14 = struct {
    count: u64,
    mapping: []const u64,
    order: []const u32,
};

pub const zx_type_17 = struct {
    keys: []const []const u8,
    kinds: []const zx_type_11,
};

pub const zx_type_18 = struct {
    specifiers: []const []const u8,
};

pub const zx_type_19 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_21 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_22 = struct {
    base: *const zx_type_21,
    delta: *const zx_type_21,
};

pub const zx_type_23 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_24 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_19,
    label: []const u8,
    second: u32,
};

pub const zx_type_25 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
};

pub const zx_type_26 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
};

pub const zx_type_27 = struct {
    base: *const zx_type_26,
    delta: *const zx_type_26,
};

pub const zx_type_28 = enum { Invalid, MissingOrigin, Ready, };

pub const zx_type_29 = struct {
    count: u64,
    mapping: []const u64,
    order: []const u32,
    origins: []const u64,
    status: zx_type_28,
};

pub const zx_type_31 = struct {
    maximum_count: u64,
    names: []const []const u8,
    origins: *const zx_type_26,
    roots: []const bool,
    scalar_count: u64,
    table: *const zx_type_21,
};

pub const zx_type_32 = struct {
    kinds: []const u8,
    scalar_count: u64,
};

pub const zx_type_33 = struct {
    ids: []const u64,
    ready: []const bool,
};

pub const zx_type_34 = struct {
    index: u64,
    pending: *const zx_type_33,
    table: *const zx_type_21,
};

pub const zx_type_35 = struct {
    index: u64,
    name: []const u8,
    names: []const []const u8,
    origins: *const zx_type_26,
};

pub const zx_type_36 = struct {
    index: u64,
    request: *const zx_type_31,
    state: *const zx_type_29,
};

pub const zx_type_37 = struct {
    request: *const zx_type_31,
    state: *const zx_type_29,
};

pub const zx_type_42 = struct {
    identities: []const ?[]const u8,
    import_names: []const []const u8,
    specifiers: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    type_namespaces: []const []const []const u8,
};

pub const zx_type_47 = struct {
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    output_types: []const u32,
};

pub const zx_type_48 = struct {
    index: u64,
    modules: *const zx_type_42,
    natives: *const zx_type_14,
    request: *const zx_type_31,
    state: *const zx_type_29,
};

pub const zx_type_49 = struct {
    natives: *const zx_type_14,
    state: *const zx_type_29,
};

pub const zx_type_50 = struct {
    modules: *const zx_type_42,
    natives: *const zx_type_14,
    request: *const zx_type_31,
    state: *const zx_type_29,
};

pub const zx_type_51 = struct {
    ids: []const u32,
    request: *const zx_type_31,
    state: *const zx_type_29,
};

pub const zx_type_52 = struct {
    index: u64,
    modules: *const zx_type_42,
};

pub const zx_type_53 = struct {
    dependencies: *const zx_type_17,
    modules: *const zx_type_42,
    natives: *const zx_type_14,
    request: *const zx_type_31,
    state: *const zx_type_29,
};

pub const zx_type_54 = struct {
    inputs: []const u32,
    native_modules: []const ?u32,
    outputs: []const u32,
};

pub const zx_type_55 = struct {
    ids: []const u32,
    inputs: []const u32,
    outputs: []const u32,
};

pub const zx_type_56 = struct {
    functions: *const zx_type_14,
    natives: *const zx_type_14,
    state: *const zx_type_29,
};

pub const zx_type_57 = struct {
    inputs: []const u32,
};

pub const zx_type_58 = struct {
    imports: *const zx_type_55,
    plan: *const zx_type_56,
    signatures: *const zx_type_54,
};

pub const zx_type_59 = struct {
    index: u64,
    modules: *const zx_type_42,
    plan: *const zx_type_56,
    request: *const zx_type_31,
    signatures: *const zx_type_54,
};

pub const zx_type_60 = struct {
    imports: *const zx_type_55,
    modules: *const zx_type_42,
    plan: *const zx_type_56,
    request: *const zx_type_31,
    signatures: *const zx_type_54,
};

pub const zx_type_61 = struct {
    plan: *const zx_type_29,
    table: *const zx_type_21,
};

pub const zx_type_62 = struct {
    origins: *const zx_type_26,
    plan: *const zx_type_29,
};

pub const zx_type_63 = struct {
    mapping: []const u64,
    values: []const u32,
};

pub const zx_type_65 = struct {
    mapping: []const u64,
    modules: *const zx_type_42,
    plan: *const zx_type_14,
};

pub const zx_type_67 = struct {
    input: u32,
    native_module: ?u32,
    natives: []const u64,
    output: u32,
    types: []const u64,
};

pub const zx_type_68 = struct {
    input: u32,
    native_module: ?u32,
    output: u32,
};

pub const zx_type_70 = enum { Copy, Borrowed, Owned, };

pub const zx_type_72 = struct {
    names: []const []const u8,
    ownership: []const zx_type_70,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_75 = struct {
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_70,
};

pub const zx_type_76 = struct {
    natives: []const u64,
    plan: *const zx_type_14,
    source: *const zx_type_75,
    types: []const u64,
};

pub const zx_type_78 = struct {
    dependencies: *const zx_type_17,
    modules: *const zx_type_42,
    natives: *const zx_type_14,
    request: *const zx_type_31,
    state: *const zx_type_29,
    type_imports: []const u32,
};

pub const zx_type_79 = struct {
    origins: *const zx_type_26,
    table: *const zx_type_21,
};

pub const zx_type_80 = struct {
    declarations: *const zx_type_75,
    dependencies: *const zx_type_17,
    function_imports: *const zx_type_55,
    modules: *const zx_type_42,
    request: *const zx_type_31,
    signatures: *const zx_type_54,
    type_imports: []const u32,
};

pub const zx_type_81 = struct {
    origins: *const zx_type_26,
    plan: *const zx_type_29,
    table: *const zx_type_21,
};

pub const zx_type_83 = struct {
    natives: ?*const zx_type_42,
    plan: *const zx_type_56,
    signatures: ?*const zx_type_75,
    value: ?*const zx_type_79,
};

pub const zx_type_84 = struct {
    index: u64,
    result: []const u64,
    source: []const []const u8,
};

pub const zx_type_85 = struct { []const u64, void, };

pub const zx_type_86 = struct {
    index: u64,
    result: []const u32,
    source: []const []const u8,
};

pub const zx_type_87 = struct { []const u32, void, };

pub const zx_type_88 = struct {
    index: u64,
    result: []const u64,
    source: []const u8,
};

pub const zx_type_89 = struct {
    index: u64,
    result: []const u32,
    source: []const u8,
};

pub const zx_type_90 = struct {
    index: u64,
    mapping: []const u64,
    order: []const u32,
    scalar_count: u64,
};

pub const zx_type_91 = struct { []const bool, void, };

pub const zx_type_92 = struct {
    first: u64,
    pending: *const zx_type_33,
    remaining: u64,
    values: []const u32,
};

pub const zx_type_93 = struct {
    id: u64,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    origins: *const zx_type_26,
    result: u64,
    valid: bool,
};

pub const zx_type_94 = struct {
    pending: *const zx_type_33,
    plan: *const zx_type_29,
    request: *const zx_type_31,
};

pub const zx_type_96 = struct { []const u64, ?u64, };

pub const zx_type_98 = struct { []const bool, ?bool, };

pub const zx_type_99 = struct {
    index: u64,
    plan: *const zx_type_29,
    request: *const zx_type_31,
};

pub const zx_type_100 = struct {
    index: u64,
    member: u64,
    natives: *const zx_type_14,
    plan: *const zx_type_29,
    request: *const zx_type_31,
    values: []const u32,
};

pub const zx_type_101 = struct {
    index: u64,
    member: u64,
    modules: *const zx_type_42,
    natives: *const zx_type_14,
    plan: *const zx_type_29,
    request: *const zx_type_31,
};

pub const zx_type_102 = struct { *const zx_type_50, };

pub const zx_type_103 = struct { *const zx_type_50, bool, };

pub const zx_type_104 = struct { *const zx_type_50, bool, *const zx_type_49, };

pub const zx_type_105 = struct {
    ids: []const u32,
    index: u64,
    plan: *const zx_type_29,
    request: *const zx_type_31,
};

pub const zx_type_106 = struct {
    dependencies: *const zx_type_17,
    found: bool,
    index: u64,
    module: u64,
    modules: *const zx_type_42,
    natives: *const zx_type_14,
    plan: *const zx_type_29,
    request: *const zx_type_31,
};

pub const zx_type_107 = struct { *const zx_type_53, };

pub const zx_type_108 = struct { *const zx_type_53, bool, };

pub const zx_type_109 = struct { *const zx_type_53, bool, *const zx_type_49, };

pub const zx_type_110 = struct { *const zx_type_78, };

pub const zx_type_111 = struct { *const zx_type_78, bool, };

pub const zx_type_112 = struct { *const zx_type_78, bool, *const zx_type_29, };

pub const zx_type_113 = struct { *const zx_type_78, bool, *const zx_type_29, *const zx_type_49, };

pub const zx_type_114 = struct {
    index: u64,
    result: []const u64,
    source: []const u32,
};

pub const zx_type_115 = struct {
    index: u64,
    result: []const u32,
    source: []const u32,
};

pub const zx_type_116 = struct {
    imports: *const zx_type_55,
    index: u64,
    modules: *const zx_type_42,
    plan: *const zx_type_56,
    request: *const zx_type_31,
    signatures: *const zx_type_54,
};

pub const zx_type_117 = struct { *const zx_type_60, };

pub const zx_type_118 = struct { *const zx_type_60, *const zx_type_56, };

pub const zx_type_119 = struct { *const zx_type_60, *const zx_type_56, bool, };

pub const zx_type_120 = struct { *const zx_type_60, *const zx_type_56, bool, *const zx_type_56, };

pub const zx_type_121 = struct { *const zx_type_80, };

pub const zx_type_122 = struct { *const zx_type_80, *const zx_type_14, };

pub const zx_type_123 = struct { *const zx_type_80, *const zx_type_14, *const zx_type_29, };

pub const zx_type_124 = struct { *const zx_type_80, *const zx_type_14, *const zx_type_29, *const zx_type_29, };

pub const zx_type_125 = struct { *const zx_type_80, *const zx_type_14, *const zx_type_29, *const zx_type_29, *const zx_type_49, };

pub const zx_type_126 = struct { *const zx_type_80, *const zx_type_14, *const zx_type_29, *const zx_type_29, *const zx_type_49, *const zx_type_49, };

pub const zx_type_127 = struct { *const zx_type_80, *const zx_type_14, *const zx_type_29, *const zx_type_29, *const zx_type_49, *const zx_type_49, *const zx_type_14, };

pub const zx_type_128 = struct { *const zx_type_80, *const zx_type_14, *const zx_type_29, *const zx_type_29, *const zx_type_49, *const zx_type_49, *const zx_type_14, *const zx_type_56, };

pub const zx_type_129 = struct {
    index: u64,
    member: u64,
    plan: *const zx_type_29,
    source: *const zx_type_21,
    table: *const zx_type_21,
};

pub const zx_type_130 = struct { []const u8, void, };

pub const zx_type_131 = struct { []const []const u8, void, };

pub const zx_type_132 = struct {
    index: u64,
    origins: *const zx_type_26,
    plan: *const zx_type_29,
    source: *const zx_type_26,
};

pub const zx_type_133 = struct { *const zx_type_81, };

pub const zx_type_134 = struct { *const zx_type_81, *const zx_type_21, };

pub const zx_type_135 = struct { *const zx_type_81, *const zx_type_21, *const zx_type_26, };

pub const zx_type_136 = struct {
    index: u64,
    mapping: []const u64,
    source: []const u32,
    valid: bool,
    values: []const u32,
};

pub const zx_type_137 = struct {
    identities: []const ?[]const u8,
    import_names: []const []const u8,
    index: u64,
    mapping: []const u64,
    plan: *const zx_type_14,
    source: *const zx_type_42,
    specifiers: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    type_namespaces: []const []const []const u8,
    valid: bool,
};

pub const zx_type_138 = struct { []const ?[]const u8, void, };

pub const zx_type_139 = struct { []const []const u32, void, };

pub const zx_type_140 = struct { []const []const []const u8, void, };

pub const zx_type_141 = struct {
    files: []const []const u8,
    index: u64,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    natives: []const u64,
    output_types: []const u32,
    ownership: []const zx_type_70,
    plan: *const zx_type_14,
    source: *const zx_type_75,
    types: []const u64,
    valid: bool,
};

pub const zx_type_142 = struct { []const zx_type_70, void, };

pub const zx_type_143 = struct { []const ?[]const ?[]const u8, void, };

pub const zx_type_144 = struct { []const ?u32, void, };

pub const zx_type_145 = struct { []const ?[]const []const u8, void, };

pub const zx_type_146 = struct { *const zx_type_80, *const zx_type_56, };

pub const zx_type_147 = struct { *const zx_type_80, *const zx_type_56, bool, };

pub const zx_type_148 = struct { *const zx_type_80, *const zx_type_56, bool, *const zx_type_79, };

pub const zx_type_149 = struct { *const zx_type_80, *const zx_type_56, bool, *const zx_type_79, ?*const zx_type_42, };

pub const zx_type_150 = struct { *const zx_type_80, *const zx_type_56, bool, *const zx_type_79, ?*const zx_type_42, ?*const zx_type_75, };

pub const value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    keys: []const []const u8,
    kinds: []const zx_type_11,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = struct {
    specifiers: []const []const u8,
    zx_origin: ?*const zx_type_18 = null,
};

pub const value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
    zx_origin: ?*const zx_type_21 = null,
};

pub const value_zx_type_22_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9 = struct {
    base: value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    delta: value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_22 = null,
};

pub const value_zx_type_23_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_23 = null,
};

pub const value_zx_type_24_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_19,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_24 = null,
};

pub const value_zx_type_25_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_25 = null,
};

pub const value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
    zx_origin: ?*const zx_type_26 = null,
};

pub const value_zx_type_27_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53 = struct {
    base: value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    delta: value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_27 = null,
};

pub const value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    mapping: []const u64,
    order: []const u32,
    origins: []const u64,
    status: zx_type_28,
    zx_origin: ?*const zx_type_29 = null,
};

pub const value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4 = struct {
    maximum_count: u64,
    names: []const []const u8,
    origins: value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    roots: []const bool,
    scalar_count: u64,
    table: value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_31 = null,
};

pub const value_zx_type_32_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    kinds: []const u8,
    scalar_count: u64,
    zx_origin: ?*const zx_type_32 = null,
};

pub const value_zx_type_33_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    ids: []const u64,
    ready: []const bool,
    zx_origin: ?*const zx_type_33 = null,
};

pub const value_zx_type_34_42fa2b78c5b762528f51324e0d7689de1d0f7b212a338a1362994148235fde09 = struct {
    index: u64,
    pending: value_zx_type_33_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    table: value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_34 = null,
};

pub const value_zx_type_35_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922 = struct {
    index: u64,
    name: []const u8,
    names: []const []const u8,
    origins: value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_35 = null,
};

pub const value_zx_type_36_502ad46929df18ca653c0064ae55def33c43c51f1c1efbfb94b9f34c2bf6a772 = struct {
    index: u64,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    state: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_36 = null,
};

pub const value_zx_type_37_217019ce70f6dfb364347ba94de9f0f9a1084f81cb497c002f7b558b8d050a37 = struct {
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    state: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_37 = null,
};

pub const value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    identities: []const ?[]const u8,
    import_names: []const []const u8,
    specifiers: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    type_namespaces: []const []const []const u8,
    zx_origin: ?*const zx_type_42 = null,
};

pub const value_zx_type_47_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    output_types: []const u32,
    zx_origin: ?*const zx_type_47 = null,
};

pub const value_zx_type_48_55bfc9e14cb8d91201aa7b73399cd712dd748f622b2b13a04bd56d20b60685f7 = struct {
    index: u64,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    natives: *const zx_type_14,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    state: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_48 = null,
};

pub const value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603 = struct {
    natives: *const zx_type_14,
    state: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_49 = null,
};

pub const value_zx_type_50_67f1b729bc670b6b4e0fb44b92a032e4807cc4ea421f4d07048678c2a2c3e53d = struct {
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    natives: *const zx_type_14,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    state: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_50 = null,
};

pub const value_zx_type_51_502ad46929df18ca653c0064ae55def33c43c51f1c1efbfb94b9f34c2bf6a772 = struct {
    ids: []const u32,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    state: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_51 = null,
};

pub const value_zx_type_52_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    index: u64,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_52 = null,
};

pub const value_zx_type_53_83f71c6370e18a36540105f0cf1c7f2209310af8b727922db4b8f2efbca6ce7b = struct {
    dependencies: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    natives: *const zx_type_14,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    state: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_53 = null,
};

pub const value_zx_type_54_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    inputs: []const u32,
    native_modules: []const ?u32,
    outputs: []const u32,
    zx_origin: ?*const zx_type_54 = null,
};

pub const value_zx_type_55_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    ids: []const u32,
    inputs: []const u32,
    outputs: []const u32,
    zx_origin: ?*const zx_type_55 = null,
};

pub const value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1 = struct {
    functions: *const zx_type_14,
    natives: *const zx_type_14,
    state: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_56 = null,
};

pub const value_zx_type_57_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = struct {
    inputs: []const u32,
    zx_origin: ?*const zx_type_57 = null,
};

pub const value_zx_type_58_4229c7b0a522efe52b21769914973a10608a6c3a9546d91386da1825ffe02a9d = struct {
    imports: value_zx_type_55_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    plan: value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1,
    signatures: value_zx_type_54_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_58 = null,
};

pub const value_zx_type_59_c27f6f9c9bdfef2ec9e0395fa25730adf5a8536517c2916d7c1d3c0e66025c45 = struct {
    index: u64,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    plan: value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    signatures: value_zx_type_54_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_59 = null,
};

pub const value_zx_type_60_bfee558c630d61a0dcdc5034fde2b51fa155904695761e0b413c8a8108eb3cf9 = struct {
    imports: value_zx_type_55_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    plan: value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    signatures: value_zx_type_54_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_60 = null,
};

pub const value_zx_type_61_b91b3eda6ee3880a4ea80a4b04e4312e5fcc8ae9f3ca0889f1d8bfc6af5383a8 = struct {
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    table: value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_61 = null,
};

pub const value_zx_type_62_b7d95529cf68c9e3a7e71df510ccf3df527d7a2f631b532e6d68f19aea2b781e = struct {
    origins: value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_62 = null,
};

pub const value_zx_type_63_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    mapping: []const u64,
    values: []const u32,
    zx_origin: ?*const zx_type_63 = null,
};

pub const value_zx_type_65_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0 = struct {
    mapping: []const u64,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    plan: *const zx_type_14,
    zx_origin: ?*const zx_type_65 = null,
};

pub const value_zx_type_67_37d199f1b50bfa5590430fb1ebc517221eb0ddef3e4e99045f9c200d682d2ab3 = struct {
    input: u32,
    native_module: ?u32,
    natives: []const u64,
    output: u32,
    types: []const u64,
    zx_origin: ?*const zx_type_67 = null,
};

pub const value_zx_type_68_5dbc07934ac83e2d569db25381bd4985c9c9a705f335a8a6fc414c51bd0c6d10 = struct {
    input: u32,
    native_module: ?u32,
    output: u32,
    zx_origin: ?*const zx_type_68 = null,
};

pub const value_zx_type_72_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    names: []const []const u8,
    ownership: []const zx_type_70,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
    zx_origin: ?*const zx_type_72 = null,
};

pub const value_zx_type_75_27f6baed02dfb16b8bbeaef695a80d4899de28e19dde605fcd26d176c6e70749 = struct {
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_70,
    zx_origin: ?*const zx_type_75 = null,
};

pub const value_zx_type_76_c44dfbe1c0a3e870c0854b1cdbf171382d54eae741ad210718c1e1fc72d2a2a9 = struct {
    natives: []const u64,
    plan: *const zx_type_14,
    source: value_zx_type_75_27f6baed02dfb16b8bbeaef695a80d4899de28e19dde605fcd26d176c6e70749,
    types: []const u64,
    zx_origin: ?*const zx_type_76 = null,
};

pub const value_zx_type_78_28391567bf0e216c1e271b497c1dcc86729d79a436d5658f993c455abb87125f = struct {
    dependencies: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    natives: *const zx_type_14,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    state: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    type_imports: []const u32,
    zx_origin: ?*const zx_type_78 = null,
};

pub const value_zx_type_79_a82f5e9a3ab11d603308e125bf4eea2885465a9b5eed7c83605713a200b64ab1 = struct {
    origins: value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    table: value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_79 = null,
};

pub const value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4 = struct {
    declarations: value_zx_type_75_27f6baed02dfb16b8bbeaef695a80d4899de28e19dde605fcd26d176c6e70749,
    dependencies: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    function_imports: value_zx_type_55_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    signatures: value_zx_type_54_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    type_imports: []const u32,
    zx_origin: ?*const zx_type_80 = null,
};

pub const value_zx_type_81_0ca7378b76264c6be88cebd9e5787e34fb346a7035f2c0f6db97ba1986224915 = struct {
    origins: value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    table: value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_81 = null,
};

pub const value_zx_type_83_7962c8c313e6aaf27c14a1882a098e9535af8c8ab46b4bb3940169d4c5f8bd77 = struct {
    natives: ?value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    plan: value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1,
    signatures: ?value_zx_type_75_27f6baed02dfb16b8bbeaef695a80d4899de28e19dde605fcd26d176c6e70749,
    value: ?value_zx_type_79_a82f5e9a3ab11d603308e125bf4eea2885465a9b5eed7c83605713a200b64ab1,
    zx_origin: ?*const zx_type_83 = null,
};

pub const value_zx_type_84_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const []const u8,
    zx_origin: ?*const zx_type_84 = null,
};

pub const value_zx_type_85_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_85, };

pub const value_zx_type_86_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u32,
    source: []const []const u8,
    zx_origin: ?*const zx_type_86 = null,
};

pub const value_zx_type_87_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, void, ?*const zx_type_87, };

pub const value_zx_type_88_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u8,
    zx_origin: ?*const zx_type_88 = null,
};

pub const value_zx_type_89_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u32,
    source: []const u8,
    zx_origin: ?*const zx_type_89 = null,
};

pub const value_zx_type_90_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    mapping: []const u64,
    order: []const u32,
    scalar_count: u64,
    zx_origin: ?*const zx_type_90 = null,
};

pub const value_zx_type_91_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, void, ?*const zx_type_91, };

pub const value_zx_type_92_c5a2300cf5307649bd7a97bf709d5bc11bac4cc46c28151b6352040a077a30d5 = struct {
    first: u64,
    pending: value_zx_type_33_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    remaining: u64,
    values: []const u32,
    zx_origin: ?*const zx_type_92 = null,
};

pub const value_zx_type_93_892e891c747560dfbd09904485e5ce9e1f2522281a82ca7e4de3330e7ae61d84 = struct {
    id: u64,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    origins: value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    result: u64,
    valid: bool,
    zx_origin: ?*const zx_type_93 = null,
};

pub const value_zx_type_94_d33d9cb5b572650fb66bc376bb22793dd52ae9b7e0d1686e8d29bb18e2184da1 = struct {
    pending: value_zx_type_33_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    zx_origin: ?*const zx_type_94 = null,
};

pub const value_zx_type_96_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u64, ?u64, ?*const zx_type_96, };

pub const value_zx_type_98_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const bool, ?bool, ?*const zx_type_98, };

pub const value_zx_type_99_9ace509e8701eb011a350f5067203d2f278b3df569b87383206cbe4f4cead781 = struct {
    index: u64,
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    zx_origin: ?*const zx_type_99 = null,
};

pub const value_zx_type_100_ef3453e4704b34a9d51cbcbc54324b50a37591fb19c6d60de6b3a66f6aa78bbb = struct {
    index: u64,
    member: u64,
    natives: *const zx_type_14,
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    values: []const u32,
    zx_origin: ?*const zx_type_100 = null,
};

pub const value_zx_type_101_8f3b6124f8f63735f83a68f7b538bb5117952ea6f802c0fb990f6692e5e7bab6 = struct {
    index: u64,
    member: u64,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    natives: *const zx_type_14,
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    zx_origin: ?*const zx_type_101 = null,
};

pub const value_zx_type_102_3fd28e677981ffcec283b4166a93c56624213b02f304d6a9f724783d20fa93d9 = struct { value_zx_type_50_67f1b729bc670b6b4e0fb44b92a032e4807cc4ea421f4d07048678c2a2c3e53d, ?*const zx_type_102, };

pub const value_zx_type_103_d30454e7c17fb24e22693c19990704502b2f56892acd79752fe595ce0c202a63 = struct { value_zx_type_50_67f1b729bc670b6b4e0fb44b92a032e4807cc4ea421f4d07048678c2a2c3e53d, bool, ?*const zx_type_103, };

pub const value_zx_type_104_09cd69704645e74e6293d16c04339445cc7c47a695a3ee91c8468aea97a8230f = struct { value_zx_type_50_67f1b729bc670b6b4e0fb44b92a032e4807cc4ea421f4d07048678c2a2c3e53d, bool, value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603, ?*const zx_type_104, };

pub const value_zx_type_105_799b45fae5a7781e2c2cf8c94cfd9f89a58956f40ba3a29cad08fc7a01b82e31 = struct {
    ids: []const u32,
    index: u64,
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    zx_origin: ?*const zx_type_105 = null,
};

pub const value_zx_type_106_6cd815c8785f69916380565996ada0240f00dd661e12d755b9a937d171547ea5 = struct {
    dependencies: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    found: bool,
    index: u64,
    module: u64,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    natives: *const zx_type_14,
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    zx_origin: ?*const zx_type_106 = null,
};

pub const value_zx_type_107_45e01b09525f7e7e4c1b2e2479fcdaa74fe9d5eaeee7c8eae40b0a368c348b5c = struct { value_zx_type_53_83f71c6370e18a36540105f0cf1c7f2209310af8b727922db4b8f2efbca6ce7b, ?*const zx_type_107, };

pub const value_zx_type_108_335123fba330353df2ab9b7771fd5a4dde2ca8f5845de01513447d0e6cf34cb2 = struct { value_zx_type_53_83f71c6370e18a36540105f0cf1c7f2209310af8b727922db4b8f2efbca6ce7b, bool, ?*const zx_type_108, };

pub const value_zx_type_109_80b97349bbc8b8b93544aa197f726fb33fc0091df08d451cd04aca442ded5809 = struct { value_zx_type_53_83f71c6370e18a36540105f0cf1c7f2209310af8b727922db4b8f2efbca6ce7b, bool, value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603, ?*const zx_type_109, };

pub const value_zx_type_110_9e437048bb7762ed8702049ec6b85938fe741c44bc6462c1eaec1a9fed1f655e = struct { value_zx_type_78_28391567bf0e216c1e271b497c1dcc86729d79a436d5658f993c455abb87125f, ?*const zx_type_110, };

pub const value_zx_type_111_323a4768ab08ea1a4b691cdbec8c3428f379683013596874917e0073fe25e99a = struct { value_zx_type_78_28391567bf0e216c1e271b497c1dcc86729d79a436d5658f993c455abb87125f, bool, ?*const zx_type_111, };

pub const value_zx_type_112_7e7d13d85f9f89b6212b7ab543c86f7f4a6462153f058f025b5cd27c31bc9a23 = struct { value_zx_type_78_28391567bf0e216c1e271b497c1dcc86729d79a436d5658f993c455abb87125f, bool, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_112, };

pub const value_zx_type_113_cc6147d47eaf3aa0237d3c9edd92c32ab92c2722554752724d50d42d4d8f1cd9 = struct { value_zx_type_78_28391567bf0e216c1e271b497c1dcc86729d79a436d5658f993c455abb87125f, bool, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603, ?*const zx_type_113, };

pub const value_zx_type_114_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u64,
    source: []const u32,
    zx_origin: ?*const zx_type_114 = null,
};

pub const value_zx_type_115_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const u32,
    source: []const u32,
    zx_origin: ?*const zx_type_115 = null,
};

pub const value_zx_type_116_a576473a61e37d68b60bceebbf55b8b203f1db80cec587081878d402d5df0591 = struct {
    imports: value_zx_type_55_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    modules: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    plan: value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1,
    request: value_zx_type_31_6d7922872f1a3a36957b85be74e9ae08da3cfef10fd2e2b5b1b19b38b7080fa4,
    signatures: value_zx_type_54_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_116 = null,
};

pub const value_zx_type_117_5feb5a394242bee3aeade272cc5deb0490794668d351f668bb77423882218e98 = struct { value_zx_type_60_bfee558c630d61a0dcdc5034fde2b51fa155904695761e0b413c8a8108eb3cf9, ?*const zx_type_117, };

pub const value_zx_type_118_c56997a1c74f9856ae723cd149a4c9fcd731c242c40a4d28ae9cc42fbe025f05 = struct { value_zx_type_60_bfee558c630d61a0dcdc5034fde2b51fa155904695761e0b413c8a8108eb3cf9, value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1, ?*const zx_type_118, };

pub const value_zx_type_119_08949053151dc6545b8fcf869f81089daf1798fd2950ed3d5abee504fb3b4f10 = struct { value_zx_type_60_bfee558c630d61a0dcdc5034fde2b51fa155904695761e0b413c8a8108eb3cf9, value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1, bool, ?*const zx_type_119, };

pub const value_zx_type_120_91278ac956d3484cfeb86044acbbec153052b9b4afcdfdf715a2249bb5f7276d = struct { value_zx_type_60_bfee558c630d61a0dcdc5034fde2b51fa155904695761e0b413c8a8108eb3cf9, value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1, bool, value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1, ?*const zx_type_120, };

pub const value_zx_type_121_d7e932ed183004230436885ca1e9a4a7430e5cb7d08daa8dafbaff8dd91281ab = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, ?*const zx_type_121, };

pub const value_zx_type_122_f3062a575c2081dd18f8cfe46881afbd518ad7ecc6f45e6b387fc2ffb7c43d3c = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, *const zx_type_14, ?*const zx_type_122, };

pub const value_zx_type_123_442df09fe46bfd8871c9057f64fa0727c1951225f30ba78bf9c48db55bb93fcc = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, *const zx_type_14, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_123, };

pub const value_zx_type_124_b0cd0b6b67c778715567d211f82cc00acbf6c4610b286f0825d26ccb31dca72d = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, *const zx_type_14, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_124, };

pub const value_zx_type_125_f82e53a9d6d195d21a75250d1791b1967e6f41142e5405211c02405465e7f3f7 = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, *const zx_type_14, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603, ?*const zx_type_125, };

pub const value_zx_type_126_d9b6f6353dc76608f012ee9e47e95e3d73a0dfc68bd67c780a207b9ef5829a65 = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, *const zx_type_14, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603, value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603, ?*const zx_type_126, };

pub const value_zx_type_127_3b6fcd8c1faad609a6f0edca1a723abae546e58212d894238bee38add469fc08 = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, *const zx_type_14, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603, value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603, *const zx_type_14, ?*const zx_type_127, };

pub const value_zx_type_128_ae8387161c4028aaae4177d682953520c562d2b0b795be3f150fac573e68d7d4 = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, *const zx_type_14, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603, value_zx_type_49_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603, *const zx_type_14, value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1, ?*const zx_type_128, };

pub const value_zx_type_129_ac9d125c7b370d8830e0c890745cd1005ca3a7d255941b130fced38eb02071d7 = struct {
    index: u64,
    member: u64,
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    source: value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    table: value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_129 = null,
};

pub const value_zx_type_130_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, void, ?*const zx_type_130, };

pub const value_zx_type_131_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, void, ?*const zx_type_131, };

pub const value_zx_type_132_dc7c1832d4eb23633087ab7cc04a44fb730e1e552a86307bf2d8e81781020c4b = struct {
    index: u64,
    origins: value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    plan: value_zx_type_29_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    source: value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_132 = null,
};

pub const value_zx_type_133_d247f75919a45330be489d58f069ec48cc4558eda52d2220039d2f570030f7a5 = struct { value_zx_type_81_0ca7378b76264c6be88cebd9e5787e34fb346a7035f2c0f6db97ba1986224915, ?*const zx_type_133, };

pub const value_zx_type_134_b13ee7bf7596ef83e02471c80d28b565b29cd77c4769bbee673243c051840136 = struct { value_zx_type_81_0ca7378b76264c6be88cebd9e5787e34fb346a7035f2c0f6db97ba1986224915, value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, ?*const zx_type_134, };

pub const value_zx_type_135_160156ba5a872391c6359e27dde64345a653fc645158e172d3257f4c6ea9e817 = struct { value_zx_type_81_0ca7378b76264c6be88cebd9e5787e34fb346a7035f2c0f6db97ba1986224915, value_zx_type_21_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, value_zx_type_26_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, ?*const zx_type_135, };

pub const value_zx_type_136_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    mapping: []const u64,
    source: []const u32,
    valid: bool,
    values: []const u32,
    zx_origin: ?*const zx_type_136 = null,
};

pub const value_zx_type_137_9766e7d2058b756110668aac325d24e5f1e27937e6421d8d9d58bf1ce90cba5f = struct {
    identities: []const ?[]const u8,
    import_names: []const []const u8,
    index: u64,
    mapping: []const u64,
    plan: *const zx_type_14,
    source: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    specifiers: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    type_namespaces: []const []const []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_137 = null,
};

pub const value_zx_type_138_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?[]const u8, void, ?*const zx_type_138, };

pub const value_zx_type_139_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u32, void, ?*const zx_type_139, };

pub const value_zx_type_140_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const []const u8, void, ?*const zx_type_140, };

pub const value_zx_type_141_aa9425f2f328fe8106c1b4e149a62407f1faebc40266f4df7dfc35944606ddb0 = struct {
    files: []const []const u8,
    index: u64,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    natives: []const u64,
    output_types: []const u32,
    ownership: []const zx_type_70,
    plan: *const zx_type_14,
    source: value_zx_type_75_27f6baed02dfb16b8bbeaef695a80d4899de28e19dde605fcd26d176c6e70749,
    types: []const u64,
    valid: bool,
    zx_origin: ?*const zx_type_141 = null,
};

pub const value_zx_type_142_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_70, void, ?*const zx_type_142, };

pub const value_zx_type_143_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?[]const ?[]const u8, void, ?*const zx_type_143, };

pub const value_zx_type_144_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?u32, void, ?*const zx_type_144, };

pub const value_zx_type_145_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?[]const []const u8, void, ?*const zx_type_145, };

pub const value_zx_type_146_fa313ac3e57900396a86ce5a7cae7eb911803cb2a40d5e6ad289be72ddac4365 = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1, ?*const zx_type_146, };

pub const value_zx_type_147_4e0b8d7bd18f6c79753a305c594c9e389838c2d0c5c7966f0426e9b920bfa794 = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1, bool, ?*const zx_type_147, };

pub const value_zx_type_148_bfcc0f6a8f96cbf4e9937b5f0e3a017755ff63a9f80b107a0478e5e7f18b6c4e = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1, bool, value_zx_type_79_a82f5e9a3ab11d603308e125bf4eea2885465a9b5eed7c83605713a200b64ab1, ?*const zx_type_148, };

pub const value_zx_type_149_2f0e8a7b9530ac6af7e6e35c5e3307757b547f3c6a57702a73175dd3d00bb3a6 = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1, bool, value_zx_type_79_a82f5e9a3ab11d603308e125bf4eea2885465a9b5eed7c83605713a200b64ab1, ?value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, ?*const zx_type_149, };

pub const value_zx_type_150_2f6d91c106472ee00da3b9b347879bd6b7297023ef1f51aabe1fcb321d81412a = struct { value_zx_type_80_ed117fdf9540dd1821cfc46479303c0e27048dab9e218e205a3b15d862268bd4, value_zx_type_56_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1, bool, value_zx_type_79_a82f5e9a3ab11d603308e125bf4eea2885465a9b5eed7c83605713a200b64ab1, ?value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, ?value_zx_type_75_27f6baed02dfb16b8bbeaef695a80d4899de28e19dde605fcd26d176c6e70749, ?*const zx_type_150, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
};

