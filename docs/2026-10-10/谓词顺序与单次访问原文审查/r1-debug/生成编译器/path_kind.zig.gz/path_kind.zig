const std = @import("std");

const zx_type_12 = struct {
    offset: u64,
    source: []const u8,
    text: []const u8,
};

const zx_type_13 = struct {
    pattern: []const u8,
    source: []const u8,
};

const zx_type_14 = struct {
    pattern: []const u8,
    source: []const u8,
    start: u64,
};

const zx_type_15 = enum { ModuleFile, ModuleReference, SpecialFile, StoreReference, FunctionReference, };

const zx_type_16 = struct {
    source: []const u8,
    start: u64,
};

const zx_type_17 = struct {
    kind: zx_type_15,
    path: []const u8,
    suffix: []const u8,
};

const zx_type_18 = struct {
    index: u64,
    matches: bool,
    offset: u64,
    source: []const u8,
    text: []const u8,
};

const zx_type_19 = struct {
    offset: u64,
    source: []const u8,
    start: u64,
    valid: bool,
};

const zx_type_20 = struct { *const zx_type_17, };

const zx_type_21 = struct { *const zx_type_17, bool, };

const value_zx_type_12_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    offset: u64,
    source: []const u8,
    text: []const u8,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    pattern: []const u8,
    source: []const u8,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    pattern: []const u8,
    source: []const u8,
    start: u64,
    zx_origin: ?*const zx_type_14 = null,
};

const value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    source: []const u8,
    start: u64,
    zx_origin: ?*const zx_type_16 = null,
};

const value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    kind: zx_type_15,
    path: []const u8,
    suffix: []const u8,
    zx_origin: ?*const zx_type_17 = null,
};

const value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    matches: bool,
    offset: u64,
    source: []const u8,
    text: []const u8,
    zx_origin: ?*const zx_type_18 = null,
};

const value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    offset: u64,
    source: []const u8,
    start: u64,
    valid: bool,
    zx_origin: ?*const zx_type_19 = null,
};

const value_zx_type_20_49129128bed2eab4847d5108d0ed3c4d32810f9cdd95b1d04dcc61383544ee70 = struct { value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_20, };

const value_zx_type_21_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct { value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, bool, ?*const zx_type_21, };

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .offset = zx_shape_5, .source = zx_shape_11, .text = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .pattern = zx_shape_11, .source = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .pattern = zx_shape_11, .source = zx_shape_11, .start = zx_shape_5, }, };

const zx_shape_15 = .{ .kind = .scalar, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .source = zx_shape_11, .start = zx_shape_5, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .kind = zx_shape_15, .path = zx_shape_11, .suffix = zx_shape_11, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .matches = zx_shape_1, .offset = zx_shape_5, .source = zx_shape_11, .text = zx_shape_11, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .offset = zx_shape_5, .source = zx_shape_11, .start = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_17, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_17, .@"1" = zx_shape_1, }, };

pub const input_shape = zx_shape_17;

pub const output_shape = zx_shape_1;

pub const Input = *const zx_type_17;

pub const Output = bool;

fn function_0(allocator: ((std).mem).Allocator, in: *const zx_type_12) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    if ((((in).offset > @as(u64, ((in).source).len)) or (@as(u64, ((in).text).len) > (@as(u64, ((in).source).len) - (in).offset)))) {
        return false;
    }

    return (block_24: {
        const operand_8 = block_7: {
            const operand_2 = (in).source;
            const operand_3 = (in).offset;
            const operand_4 = (in).text;
            const operand_5 = @as(u64, 0);
            const operand_6 = true;

            break :block_7 zx_type_18{ .source = operand_2, .offset = operand_3, .text = operand_4, .index = operand_5, .matches = operand_6, };
        };

        var state_1: value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .index = (operand_8).index, .matches = (operand_8).matches, .offset = (operand_8).offset, .source = (operand_8).source, .text = (operand_8).text, .zx_origin = (&operand_8), };

        while (((state_1).matches and ((state_1).index < @as(u64, ((state_1).text).len)))) {
            state_1 = block_21: {
                const value_3: bool = (block_17: {
                    const operand_15 = (state_1).source;
                    const operand_16 = ((state_1).offset + (state_1).index);

                    if ((operand_16 >= (operand_15).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_17 (operand_15)[@intCast(operand_16)];
                } == block_20: {
                    const operand_18 = (state_1).text;
                    const operand_19 = (state_1).index;

                    if ((operand_19 >= (operand_18).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_20 (operand_18)[@intCast(operand_19)];
                });
                const value_4: u64 = ((state_1).index + @as(u64, 1));
                const value_5: value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_14: {
                    const operand_9 = state_1;
                    const operand_10 = block_11: {
                        break :block_11 value_4;
                    };
                    const operand_12 = block_13: {
                        break :block_13 value_3;
                    };

                    break :block_14 @as(value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .index = operand_10, .matches = operand_12, .offset = (operand_9).offset, .source = (operand_9).source, .text = (operand_9).text, });
                };

                break :block_21 value_5;
            };
        }

        break :block_24 block_23: {
            break :block_23 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_22: {
                break :block_22 zx_type_18{ .index = (state_1).index, .matches = (state_1).matches, .offset = (state_1).offset, .source = (state_1).source, .text = (state_1).text, };
            });
        };
    }).matches;
}

fn function_1(allocator: ((std).mem).Allocator, in: *const zx_type_13) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if ((@as(u64, ((in).source).len) < @as(u64, ((in).pattern).len))) {
        return false;
    }

    return block_5: {
        const operand_1 = (in).source;
        const operand_2 = (@as(u64, ((in).source).len) - @as(u64, ((in).pattern).len));
        const operand_3 = (in).pattern;
        const operand_4 = zx_type_12{ .source = operand_1, .offset = operand_2, .text = operand_3, };

        break :block_5 (try function_0(allocator, (&operand_4)));
    };
}

fn function_2(allocator: ((std).mem).Allocator, in: *const zx_type_14) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    return (((@as(u64, ((in).source).len) - (in).start) == @as(u64, ((in).pattern).len)) and block_5: {
        const operand_1 = (in).source;
        const operand_2 = (in).start;
        const operand_3 = (in).pattern;
        const operand_4 = zx_type_12{ .source = operand_1, .offset = operand_2, .text = operand_3, };

        break :block_5 (try function_0(allocator, (&operand_4)));
    });
}

fn function_3(allocator: ((std).mem).Allocator, in: *const zx_type_16) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    return ((((((@as(u64, ((in).source).len) - (in).start) > @as(u64, 3)) and block_4: {
        const operand_1 = (in).source;
        const operand_2 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 114), @as(u8, 120), })));
        const operand_3 = zx_type_13{ .source = operand_1, .pattern = operand_2, };

        break :block_4 (try function_1(allocator, (&operand_3)));
    }) and (!block_9: {
        const operand_5 = (in).source;
        const operand_6 = (in).start;
        const operand_7 = @as([]const u8, (comptime (&[_]u8{@as(u8, 97), @as(u8, 112), @as(u8, 112), @as(u8, 46), @as(u8, 114), @as(u8, 120), })));
        const operand_8 = zx_type_14{ .source = operand_5, .start = operand_6, .pattern = operand_7, };

        break :block_9 (try function_2(allocator, (&operand_8)));
    })) and (!block_13: {
        const operand_10 = (in).source;
        const operand_11 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 103), @as(u8, 97), @as(u8, 116), @as(u8, 101), @as(u8, 119), @as(u8, 97), @as(u8, 121), @as(u8, 46), @as(u8, 114), @as(u8, 120), })));
        const operand_12 = zx_type_13{ .source = operand_10, .pattern = operand_11, };

        break :block_13 (try function_1(allocator, (&operand_12)));
    })) and (!block_17: {
        const operand_14 = (in).source;
        const operand_15 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 115), @as(u8, 116), @as(u8, 111), @as(u8, 114), @as(u8, 101), @as(u8, 46), @as(u8, 114), @as(u8, 120), })));
        const operand_16 = zx_type_13{ .source = operand_14, .pattern = operand_15, };

        break :block_17 (try function_1(allocator, (&operand_16)));
    }));
}

fn function_4(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    if ((((@as(u64, (in).len) == @as(u64, 0)) or (block_26: {
        const operand_24 = in;
        const operand_25 = @as(u64, 0);

        if ((operand_25 >= (operand_24).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_26 (operand_24)[@intCast(operand_25)];
    } == @as(u8, 47))) or (block_29: {
        const operand_27 = in;
        const operand_28 = (@as(u64, (in).len) - @as(u64, 1));

        if ((operand_28 >= (operand_27).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_29 (operand_27)[@intCast(operand_28)];
    } == @as(u8, 47)))) {
        return @as(u64, (in).len);
    }

    const value_9: zx_type_19 = block_23: {
        const operand_7 = block_6: {
            const operand_2 = in;
            const operand_3 = @as(u64, 0);
            const operand_4 = @as(u64, 0);
            const operand_5 = true;

            break :block_6 zx_type_19{ .source = operand_2, .offset = operand_3, .start = operand_4, .valid = operand_5, };
        };

        var state_1: value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .offset = (operand_7).offset, .source = (operand_7).source, .start = (operand_7).start, .valid = (operand_7).valid, .zx_origin = (&operand_7), };

        while (((state_1).valid and ((state_1).offset < @as(u64, ((state_1).source).len)))) {
            state_1 = block_20: {
                const value_3: u8 = block_19: {
                    const operand_17 = (state_1).source;
                    const operand_18 = (state_1).offset;

                    if ((operand_18 >= (operand_17).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_19 (operand_17)[@intCast(operand_18)];
                };
                const value_4: value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_16: {
                    break :block_16 @as(value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .offset = (state_1).offset, .source = (state_1).source, .start = (state_1).start, .valid = (((block_13: {
                        break :block_13 value_3;
                    } != @as(u8, 0)) and (block_14: {
                        break :block_14 value_3;
                    } != @as(u8, 58))) and (block_15: {
                        break :block_15 value_3;
                    } != @as(u8, 92))), });
                };
                const value_6: value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if ((block_10: {
                    break :block_10 value_3;
                } == @as(u8, 47))) block_12: {
                    const value_5: value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_11: {
                        break :block_11 @as(value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .offset = (value_4).offset, .source = (value_4).source, .start = ((value_4).offset + @as(u64, 1)), .valid = (value_4).valid, });
                    };

                    break :block_12 value_5;
                } else value_4);
                const value_7: u64 = (value_6).offset;
                const value_8: value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_9: {
                    break :block_9 @as(value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_19_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .offset = (block_8: {
                        break :block_8 value_7;
                    } + @as(u64, 1)), .source = (value_6).source, .start = (value_6).start, .valid = (value_6).valid, });
                };

                break :block_20 value_8;
            };
        }

        break :block_23 block_22: {
            break :block_22 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_21: {
                break :block_21 zx_type_19{ .offset = (state_1).offset, .source = (state_1).source, .start = (state_1).start, .valid = (state_1).valid, };
            });
        };
    };

    return (if (((&value_9)).valid) ((&value_9)).start else @as(u64, (in).len));
}

fn function_5(allocator: ((std).mem).Allocator, in: *const zx_type_17) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_4(allocator, (in).path));

    if ((value_1 == @as(u64, ((in).path).len))) {
        return false;
    }

    if (((in).kind == @as(zx_type_15, .SpecialFile))) {
        return (((@as(u64, ((in).path).len) - value_1) > @as(u64, ((in).suffix).len)) and block_44: {
            const operand_41 = (in).path;
            const operand_42 = (in).suffix;
            const operand_43 = zx_type_13{ .source = operand_41, .pattern = operand_42, };

            break :block_44 (try function_1(allocator, (&operand_43)));
        });
    }

    if (((in).kind == @as(zx_type_15, .ModuleFile))) {
        return block_40: {
            const operand_37 = (in).path;
            const operand_38 = value_1;
            const operand_39 = zx_type_16{ .source = operand_37, .start = operand_38, };

            break :block_40 (try function_3(allocator, (&operand_39)));
        };
    }

    const value_2: bool = block_36: {
        const operand_33 = (in).path;
        const operand_34 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 114), @as(u8, 120), })));
        const operand_35 = zx_type_13{ .source = operand_33, .pattern = operand_34, };

        break :block_36 (try function_1(allocator, (&operand_35)));
    };

    if ((((in).kind == @as(zx_type_15, .ModuleReference)) and value_2)) {
        return block_32: {
            const operand_29 = (in).path;
            const operand_30 = value_1;
            const operand_31 = zx_type_16{ .source = operand_29, .start = operand_30, };

            break :block_32 (try function_3(allocator, (&operand_31)));
        };
    }

    if ((block_23: {
        const operand_19 = (in).path;
        const operand_20 = value_1;
        const operand_21 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), })));
        const operand_22 = zx_type_14{ .source = operand_19, .start = operand_20, .pattern = operand_21, };

        break :block_23 (try function_2(allocator, (&operand_22)));
    } or block_28: {
        const operand_24 = (in).path;
        const operand_25 = value_1;
        const operand_26 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 46), })));
        const operand_27 = zx_type_14{ .source = operand_24, .start = operand_25, .pattern = operand_26, };

        break :block_28 (try function_2(allocator, (&operand_27)));
    })) {
        return false;
    }

    const switch_1 = (in).kind;

    if ((switch_1 == @as(zx_type_15, .ModuleReference))) {
        return (((!block_10: {
            const operand_6 = (in).path;
            const operand_7 = value_1;
            const operand_8 = @as([]const u8, (comptime (&[_]u8{@as(u8, 97), @as(u8, 112), @as(u8, 112), })));
            const operand_9 = zx_type_14{ .source = operand_6, .start = operand_7, .pattern = operand_8, };

            break :block_10 (try function_2(allocator, (&operand_9)));
        }) and (!block_14: {
            const operand_11 = (in).path;
            const operand_12 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 103), @as(u8, 97), @as(u8, 116), @as(u8, 101), @as(u8, 119), @as(u8, 97), @as(u8, 121), })));
            const operand_13 = zx_type_13{ .source = operand_11, .pattern = operand_12, };

            break :block_14 (try function_1(allocator, (&operand_13)));
        })) and (!block_18: {
            const operand_15 = (in).path;
            const operand_16 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 115), @as(u8, 116), @as(u8, 111), @as(u8, 114), @as(u8, 101), })));
            const operand_17 = zx_type_13{ .source = operand_15, .pattern = operand_16, };

            break :block_18 (try function_1(allocator, (&operand_17)));
        }));
    } else {
        if ((switch_1 == @as(zx_type_15, .StoreReference))) {
            return ((!value_2) or block_5: {
                const operand_2 = (in).path;
                const operand_3 = @as([]const u8, (comptime (&[_]u8{@as(u8, 46), @as(u8, 115), @as(u8, 116), @as(u8, 111), @as(u8, 114), @as(u8, 101), @as(u8, 46), @as(u8, 114), @as(u8, 120), })));
                const operand_4 = zx_type_13{ .source = operand_2, .pattern = operand_3, };

                break :block_5 (try function_1(allocator, (&operand_4)));
            });
        } else {
            if ((switch_1 == @as(zx_type_15, .FunctionReference))) {
                return (!value_2);
            } else {
                return false;
            }
        }
    }
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_17) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = (try function_5(allocator, in));

    return value_1;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: *const zx_type_17) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: bool = (try function_5(allocator, in));

    return value_1;
}

