const std = @import("std");

const zx_abi = @import("zxc_abi");

const zx_native = @import("host");

pub fn call(allocator: ((std).mem).Allocator, in: []const i64) error{ }![]const i64 {
    const native_result = (zx_native).source(in);

    _ = allocator;

    return native_result;
}

