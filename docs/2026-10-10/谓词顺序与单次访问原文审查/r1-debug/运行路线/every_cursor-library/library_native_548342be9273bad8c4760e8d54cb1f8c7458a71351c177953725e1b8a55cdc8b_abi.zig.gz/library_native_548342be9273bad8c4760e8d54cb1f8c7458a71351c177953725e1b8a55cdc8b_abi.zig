const canonical = @import("zxc_abi_canonical");

pub const zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054 = (canonical).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054;

pub const zx_type_29e983954018f5dbae2f2b502992cb534b81928d5ac5d5d98c5278a95f8d0629 = (canonical).zx_type_29e983954018f5dbae2f2b502992cb534b81928d5ac5d5d98c5278a95f8d0629;

pub const value_zx_type_29e983954018f5dbae2f2b502992cb534b81928d5ac5d5d98c5278a95f8d0629_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = (canonical).value_zx_type_29e983954018f5dbae2f2b502992cb534b81928d5ac5d5d98c5278a95f8d0629_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744;

pub const zx_type_6f29b97f56d4db3bd751242185c40590ad842b5ab153a6fcca934f711870a621 = (canonical).zx_type_6f29b97f56d4db3bd751242185c40590ad842b5ab153a6fcca934f711870a621;

pub const value_zx_type_6f29b97f56d4db3bd751242185c40590ad842b5ab153a6fcca934f711870a621_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (canonical).value_zx_type_6f29b97f56d4db3bd751242185c40590ad842b5ab153a6fcca934f711870a621_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292;

pub const native = struct {
    pub const @"zig:host" = ((canonical).native_by_identity).@"library:10:borrowed@1:zig:host";
};

pub const layouts = struct {
    pub const @"zig:host" = ((canonical).layouts_by_identity).@"library:10:borrowed@1:zig:host";
};

