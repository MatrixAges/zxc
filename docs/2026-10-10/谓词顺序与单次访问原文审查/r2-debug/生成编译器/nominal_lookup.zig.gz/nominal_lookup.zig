const std = @import("std");

const zx_native_0 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_14 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .field_names = zx_shape_14, .field_types = zx_shape_13, .first = zx_shape_13, .kinds = zx_shape_12, .labels = zx_shape_14, .names = zx_shape_14, .second = zx_shape_13, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .base = zx_shape_15, .delta = zx_shape_15, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .names = zx_shape_14, .types = zx_shape_13, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .delta = zx_shape_1, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .second = zx_shape_4, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .fields = zx_shape_17, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .names = zx_shape_14, .second = zx_shape_4, }, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .id = zx_shape_4, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .delta = zx_shape_15, .id = zx_shape_4, }, };

const zx_shape_22 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .count = zx_shape_5, .field_names = zx_shape_14, .field_types = zx_shape_13, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .names = zx_shape_14, .offset = zx_shape_5, .second = zx_shape_4, }, };

const zx_shape_23 = .{ .kind = .object, .fields = .{ .left = zx_shape_22, .right = zx_shape_22, }, };

const zx_shape_24 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .table = zx_shape_15, }, };

const zx_shape_25 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_19, .id = zx_shape_4, .tables = zx_shape_16, }, };

const zx_shape_26 = .{ .kind = .object, .fields = .{ .id = zx_shape_4, .tables = zx_shape_16, }, };

const zx_shape_27 = .{ .kind = .scalar, };

const zx_shape_28 = .{ .kind = .object, .fields = .{ .id = zx_shape_4, .status = zx_shape_27, }, };

const zx_shape_29 = .{ .kind = .object, .fields = .{ .kind = zx_shape_2, .member = zx_shape_10, .owner = zx_shape_10, }, };

const zx_shape_30 = .{ .kind = .object, .fields = .{ .ids = zx_shape_13, .kinds = zx_shape_12, .members = zx_shape_14, .owners = zx_shape_14, }, };

const zx_shape_31 = .{ .kind = .object, .fields = .{ .base = zx_shape_30, .delta = zx_shape_30, }, };

const zx_shape_32 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_19, .origin = zx_shape_29, .origins = zx_shape_31, .tables = zx_shape_16, }, };

const zx_shape_33 = .{ .kind = .object, .fields = .{ .equal = zx_shape_1, .index = zx_shape_5, .left = zx_shape_22, .right = zx_shape_22, }, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_19, .count = zx_shape_5, .id = zx_shape_4, .index = zx_shape_5, .origin = zx_shape_29, .origins = zx_shape_31, .status = zx_shape_27, .tables = zx_shape_16, }, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_32, }, };

const zx_shape_36 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_32, .@"1" = zx_shape_28, }, };

const zx_shape_37 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_32, .@"1" = zx_shape_28, .@"2" = zx_shape_5, }, };

pub const input_shape = zx_shape_32;

pub const output_shape = zx_shape_5;

pub const Input = *const (zx_abi).zx_type_32;

pub const Output = u64;

fn function_0(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: u8) error{ }!u64 {
    const native_result = (zx_native_0).widenByte(in);

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_19) error{ OutOfMemory, }!*const (zx_abi).zx_type_22 {
    @setRuntimeSafety(true);

    const value_1: u64 = block_15: {
        const operand_14 = (in).kind;

        break :block_15 (if ((operand_14 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_14 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_13: {
        const operand_1 = (in).kind;
        const operand_2 = (in).first;
        const operand_3 = (in).second;
        const operand_4 = (in).label;
        const operand_5 = @as(u64, 0);
        const operand_6 = value_1;
        const operand_7 = (in).children;
        const operand_8 = ((in).fields).names;
        const operand_9 = ((in).fields).types;
        const operand_10 = (in).names;

        break :block_13 block_12: {
            const operand_11 = (try (allocator).create((zx_abi).zx_type_22));

            (operand_11).* = @as((zx_abi).zx_type_22, (zx_abi).zx_type_22{ .kind = operand_1, .first = operand_2, .second = operand_3, .label = operand_4, .offset = operand_5, .count = operand_6, .children = operand_7, .field_names = operand_8, .field_types = operand_9, .names = operand_10, });

            break :block_12 @as(*const (zx_abi).zx_type_22, operand_11);
        };
    };
}

fn function_3_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384) error{ OutOfMemory, }!(zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: u64 = block_29: {
        const operand_28 = (in).kind;

        break :block_29 (if ((operand_28 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_28 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_27: {
        const operand_16 = (in).kind;
        const operand_17 = (in).first;
        const operand_18 = (in).second;
        const operand_19 = (in).label;
        const operand_20 = @as(u64, 0);
        const operand_21 = block_22: {
            break :block_22 value_1;
        };
        const operand_23 = (in).children;
        const operand_24 = ((in).fields).names;
        const operand_25 = ((in).fields).types;
        const operand_26 = (in).names;

        break :block_27 @as((zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_16, .first = operand_17, .second = operand_18, .label = operand_19, .offset = operand_20, .count = operand_21, .children = operand_23, .field_names = operand_24, .field_types = operand_25, .names = operand_26, });
    };
}

fn function_3_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ OutOfMemory, }!(zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    _ = allocator;

    _ = buffers;

    const value_1: u64 = block_43: {
        const operand_42 = (in).kind;

        break :block_43 (if ((operand_42 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_42 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_41: {
        const operand_30 = (in).kind;
        const operand_31 = (in).first;
        const operand_32 = (in).second;
        const operand_33 = (in).label;
        const operand_34 = @as(u64, 0);
        const operand_35 = block_36: {
            break :block_36 value_1;
        };
        const operand_37 = (in).children;
        const operand_38 = ((in).fields).names;
        const operand_39 = ((in).fields).types;
        const operand_40 = (in).names;

        break :block_41 @as((zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_30, .first = operand_31, .second = operand_32, .label = operand_33, .offset = operand_34, .count = operand_35, .children = operand_37, .field_names = operand_38, .field_types = operand_39, .names = operand_40, });
    };
}

fn function_3_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_19, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ OutOfMemory, }!*const (zx_abi).zx_type_22 {
    @setRuntimeSafety(true);

    _ = buffers;

    const value_1: u64 = block_58: {
        const operand_57 = (in).kind;

        break :block_58 (if ((operand_57 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_57 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_56: {
        const operand_44 = (in).kind;
        const operand_45 = (in).first;
        const operand_46 = (in).second;
        const operand_47 = (in).label;
        const operand_48 = @as(u64, 0);
        const operand_49 = value_1;
        const operand_50 = (in).children;
        const operand_51 = ((in).fields).names;
        const operand_52 = ((in).fields).types;
        const operand_53 = (in).names;

        break :block_56 block_55: {
            const operand_54 = (try (allocator).create((zx_abi).zx_type_22));

            (operand_54).* = @as((zx_abi).zx_type_22, (zx_abi).zx_type_22{ .kind = operand_44, .first = operand_45, .second = operand_46, .label = operand_47, .offset = operand_48, .count = operand_49, .children = operand_50, .field_names = operand_51, .field_types = operand_52, .names = operand_53, });

            break :block_55 @as(*const (zx_abi).zx_type_22, operand_54);
        };
    };
}

fn function_4(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_23) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: (zx_abi).zx_type_22 = ((in).left).*;
    const value_2: (zx_abi).zx_type_22 = ((in).right).*;

    if ((((&value_1)).kind != ((&value_2)).kind)) {
        return false;
    }

    if ((((((&value_1)).kind == @as((zx_abi).zx_type_11, .Scalar)) or (((&value_1)).kind == @as((zx_abi).zx_type_11, .Optional))) or (((&value_1)).kind == @as((zx_abi).zx_type_11, .List)))) {
        return (((&value_1)).first == ((&value_2)).first);
    }

    if ((((&value_1)).kind == @as((zx_abi).zx_type_11, .Task))) {
        return ((((&value_1)).first == ((&value_2)).first) and (((&value_1)).second == ((&value_2)).second));
    }

    if ((((&value_1)).kind == @as((zx_abi).zx_type_11, .NativeReference))) {
        return block_56: {
            const operand_54 = ((&value_1)).label;
            const operand_55 = ((&value_2)).label;

            break :block_56 ((std).mem).eql(u8, operand_54, operand_55);
        };
    }

    if (((((&value_1)).kind == @as((zx_abi).zx_type_11, .Enumeration)) and (!block_53: {
        const operand_51 = ((&value_1)).label;
        const operand_52 = ((&value_2)).label;

        break :block_53 ((std).mem).eql(u8, operand_51, operand_52);
    }))) {
        return false;
    }

    if ((((&value_1)).count != ((&value_2)).count)) {
        return false;
    }

    return block_50: {
        const state_type_2 = struct {
            children: []const u32,
            count: u64,
            field_names: []const []const u8,
            field_types: []const u32,
            first: u32,
            kind: (zx_abi).zx_type_11,
            label: []const u8,
            names: []const []const u8,
            offset: u64,
            second: u32,
        };
        const state_type_3 = struct {
            equal: bool,
            index: u64,
            left: state_type_2,
            right: state_type_2,
        };
        const operand_13 = block_12: {
            const operand_6 = block_5: {
                const operand_4 = (&value_1);

                break :block_5 state_type_2{ .children = (operand_4).children, .count = (operand_4).count, .field_names = (operand_4).field_names, .field_types = (operand_4).field_types, .first = (operand_4).first, .kind = (operand_4).kind, .label = (operand_4).label, .names = (operand_4).names, .offset = (operand_4).offset, .second = (operand_4).second, };
            };
            const operand_9 = block_8: {
                const operand_7 = (&value_2);

                break :block_8 state_type_2{ .children = (operand_7).children, .count = (operand_7).count, .field_names = (operand_7).field_names, .field_types = (operand_7).field_types, .first = (operand_7).first, .kind = (operand_7).kind, .label = (operand_7).label, .names = (operand_7).names, .offset = (operand_7).offset, .second = (operand_7).second, };
            };
            const operand_10 = @as(u64, 0);
            const operand_11 = true;

            break :block_12 state_type_3{ .left = operand_6, .right = operand_9, .index = operand_10, .equal = operand_11, };
        };

        var state_1: state_type_3 = operand_13;

        var state_changed_14 = false;

        while (((state_1).equal and ((state_1).index < ((state_1).left).count))) {
            state_1 = block_49: {
                const value_5: u64 = (((state_1).left).offset + (state_1).index);
                const value_6: u64 = (((state_1).right).offset + (state_1).index);
                const value_7: bool = block_48: {
                    const operand_17 = ((state_1).left).kind;

                    break :block_48 (if ((operand_17 == @as((zx_abi).zx_type_11, .Object))) (block_41: {
                        const operand_39 = block_35: {
                            const operand_33 = ((state_1).left).field_names;
                            const operand_34 = value_5;

                            if ((operand_34 >= (operand_33).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_35 (operand_33)[@intCast(operand_34)];
                        };
                        const operand_40 = block_38: {
                            const operand_36 = ((state_1).right).field_names;
                            const operand_37 = value_6;

                            if ((operand_37 >= (operand_36).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_38 (operand_36)[@intCast(operand_37)];
                        };

                        break :block_41 ((std).mem).eql(u8, operand_39, operand_40);
                    } and (block_44: {
                        const operand_42 = ((state_1).left).field_types;
                        const operand_43 = value_5;

                        if ((operand_43 >= (operand_42).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_44 (operand_42)[@intCast(operand_43)];
                    } == block_47: {
                        const operand_45 = ((state_1).right).field_types;
                        const operand_46 = value_6;

                        if ((operand_46 >= (operand_45).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_47 (operand_45)[@intCast(operand_46)];
                    })) else (if ((operand_17 == @as((zx_abi).zx_type_11, .Tuple))) (block_29: {
                        const operand_27 = ((state_1).left).children;
                        const operand_28 = value_5;

                        if ((operand_28 >= (operand_27).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_29 (operand_27)[@intCast(operand_28)];
                    } == block_32: {
                        const operand_30 = ((state_1).right).children;
                        const operand_31 = value_6;

                        if ((operand_31 >= (operand_30).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_32 (operand_30)[@intCast(operand_31)];
                    }) else block_26: {
                        const operand_24 = block_20: {
                            const operand_18 = ((state_1).left).names;
                            const operand_19 = value_5;

                            if ((operand_19 >= (operand_18).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_20 (operand_18)[@intCast(operand_19)];
                        };
                        const operand_25 = block_23: {
                            const operand_21 = ((state_1).right).names;
                            const operand_22 = value_6;

                            if ((operand_22 >= (operand_21).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_23 (operand_21)[@intCast(operand_22)];
                        };

                        break :block_26 ((std).mem).eql(u8, operand_24, operand_25);
                    }));
                };
                const value_8: state_type_3 = block_16: {
                    break :block_16 state_type_3{ .equal = value_7, .index = (state_1).index, .left = (state_1).left, .right = (state_1).right, };
                };
                const value_9: u64 = (value_8).index;
                const value_10: state_type_3 = block_15: {
                    break :block_15 state_type_3{ .equal = (value_8).equal, .index = (value_9 + @as(u64, 1)), .left = (value_8).left, .right = (value_8).right, };
                };

                break :block_49 value_10;
            };

            state_changed_14 = true;
        }

        break :block_50 (state_1).equal;
    };
}

fn function_5(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_11 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_2: {
        const operand_1 = in;

        break :block_2 (if ((operand_1 == @as(u8, 0))) @as((zx_abi).zx_type_11, .Scalar) else (if ((operand_1 == @as(u8, 1))) @as((zx_abi).zx_type_11, .Object) else (if ((operand_1 == @as(u8, 2))) @as((zx_abi).zx_type_11, .Optional) else (if ((operand_1 == @as(u8, 3))) @as((zx_abi).zx_type_11, .List) else (if ((operand_1 == @as(u8, 4))) @as((zx_abi).zx_type_11, .Tuple) else (if ((operand_1 == @as(u8, 5))) @as((zx_abi).zx_type_11, .ErrorSet) else (if ((operand_1 == @as(u8, 6))) @as((zx_abi).zx_type_11, .Task) else (if ((operand_1 == @as(u8, 7))) @as((zx_abi).zx_type_11, .Enumeration) else @as((zx_abi).zx_type_11, .NativeReference)))))))));
    };
}

fn function_6(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_11 {
    @setRuntimeSafety(true);

    return (try function_5(allocator, in));
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_24) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_22 {
    @setRuntimeSafety(true);

    return block_31: {
        const operand_1 = (try function_6(allocator, block_4: {
            const operand_2 = ((in).table).kinds;
            const operand_3 = (in).index;

            if ((operand_3 >= (operand_2).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_4 (operand_2)[@intCast(operand_3)];
        }));
        const operand_5 = block_8: {
            const operand_6 = ((in).table).first;
            const operand_7 = (in).index;

            if ((operand_7 >= (operand_6).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_8 (operand_6)[@intCast(operand_7)];
        };
        const operand_9 = block_12: {
            const operand_10 = ((in).table).second;
            const operand_11 = (in).index;

            if ((operand_11 >= (operand_10).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_12 (operand_10)[@intCast(operand_11)];
        };
        const operand_13 = block_16: {
            const operand_14 = ((in).table).labels;
            const operand_15 = (in).index;

            if ((operand_15 >= (operand_14).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_16 (operand_14)[@intCast(operand_15)];
        };
        const operand_17 = (try function_0(allocator, block_20: {
            const operand_18 = ((in).table).first;
            const operand_19 = (in).index;

            if ((operand_19 >= (operand_18).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_20 (operand_18)[@intCast(operand_19)];
        }));
        const operand_21 = (try function_0(allocator, block_24: {
            const operand_22 = ((in).table).second;
            const operand_23 = (in).index;

            if ((operand_23 >= (operand_22).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_24 (operand_22)[@intCast(operand_23)];
        }));
        const operand_25 = ((in).table).children;
        const operand_26 = ((in).table).field_names;
        const operand_27 = ((in).table).field_types;
        const operand_28 = ((in).table).names;

        break :block_31 block_30: {
            const operand_29 = (try (allocator).create((zx_abi).zx_type_22));

            (operand_29).* = @as((zx_abi).zx_type_22, (zx_abi).zx_type_22{ .kind = operand_1, .first = operand_5, .second = operand_9, .label = operand_13, .offset = operand_17, .count = operand_21, .children = operand_25, .field_names = operand_26, .field_types = operand_27, .names = operand_28, });

            break :block_30 @as(*const (zx_abi).zx_type_22, operand_29);
        };
    };
}

fn function_7_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_24_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    return block_60: {
        const operand_32 = (try function_6(allocator, block_35: {
            const operand_33 = ((in).table).kinds;
            const operand_34 = (in).index;

            if ((operand_34 >= (operand_33).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_35 (operand_33)[@intCast(operand_34)];
        }));
        const operand_36 = block_39: {
            const operand_37 = ((in).table).first;
            const operand_38 = (in).index;

            if ((operand_38 >= (operand_37).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_39 (operand_37)[@intCast(operand_38)];
        };
        const operand_40 = block_43: {
            const operand_41 = ((in).table).second;
            const operand_42 = (in).index;

            if ((operand_42 >= (operand_41).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_43 (operand_41)[@intCast(operand_42)];
        };
        const operand_44 = block_47: {
            const operand_45 = ((in).table).labels;
            const operand_46 = (in).index;

            if ((operand_46 >= (operand_45).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_47 (operand_45)[@intCast(operand_46)];
        };
        const operand_48 = (try function_0(allocator, block_51: {
            const operand_49 = ((in).table).first;
            const operand_50 = (in).index;

            if ((operand_50 >= (operand_49).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_51 (operand_49)[@intCast(operand_50)];
        }));
        const operand_52 = (try function_0(allocator, block_55: {
            const operand_53 = ((in).table).second;
            const operand_54 = (in).index;

            if ((operand_54 >= (operand_53).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_55 (operand_53)[@intCast(operand_54)];
        }));
        const operand_56 = ((in).table).children;
        const operand_57 = ((in).table).field_names;
        const operand_58 = ((in).table).field_types;
        const operand_59 = ((in).table).names;

        break :block_60 @as((zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_32, .first = operand_36, .second = operand_40, .label = operand_44, .offset = operand_48, .count = operand_52, .children = operand_56, .field_names = operand_57, .field_types = operand_58, .names = operand_59, });
    };
}

fn function_7_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_24_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    _ = buffers;

    return block_89: {
        const operand_61 = (try function_6(allocator, block_64: {
            const operand_62 = ((in).table).kinds;
            const operand_63 = (in).index;

            if ((operand_63 >= (operand_62).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_64 (operand_62)[@intCast(operand_63)];
        }));
        const operand_65 = block_68: {
            const operand_66 = ((in).table).first;
            const operand_67 = (in).index;

            if ((operand_67 >= (operand_66).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_68 (operand_66)[@intCast(operand_67)];
        };
        const operand_69 = block_72: {
            const operand_70 = ((in).table).second;
            const operand_71 = (in).index;

            if ((operand_71 >= (operand_70).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_72 (operand_70)[@intCast(operand_71)];
        };
        const operand_73 = block_76: {
            const operand_74 = ((in).table).labels;
            const operand_75 = (in).index;

            if ((operand_75 >= (operand_74).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_76 (operand_74)[@intCast(operand_75)];
        };
        const operand_77 = (try function_0(allocator, block_80: {
            const operand_78 = ((in).table).first;
            const operand_79 = (in).index;

            if ((operand_79 >= (operand_78).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_80 (operand_78)[@intCast(operand_79)];
        }));
        const operand_81 = (try function_0(allocator, block_84: {
            const operand_82 = ((in).table).second;
            const operand_83 = (in).index;

            if ((operand_83 >= (operand_82).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_84 (operand_82)[@intCast(operand_83)];
        }));
        const operand_85 = ((in).table).children;
        const operand_86 = ((in).table).field_names;
        const operand_87 = ((in).table).field_types;
        const operand_88 = ((in).table).names;

        break :block_89 @as((zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_61, .first = operand_65, .second = operand_69, .label = operand_73, .offset = operand_77, .count = operand_81, .children = operand_85, .field_names = operand_86, .field_types = operand_87, .names = operand_88, });
    };
}

fn function_7_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_24, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_22 {
    @setRuntimeSafety(true);

    _ = buffers;

    return block_120: {
        const operand_90 = (try function_6(allocator, block_93: {
            const operand_91 = ((in).table).kinds;
            const operand_92 = (in).index;

            if ((operand_92 >= (operand_91).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_93 (operand_91)[@intCast(operand_92)];
        }));
        const operand_94 = block_97: {
            const operand_95 = ((in).table).first;
            const operand_96 = (in).index;

            if ((operand_96 >= (operand_95).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_97 (operand_95)[@intCast(operand_96)];
        };
        const operand_98 = block_101: {
            const operand_99 = ((in).table).second;
            const operand_100 = (in).index;

            if ((operand_100 >= (operand_99).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_101 (operand_99)[@intCast(operand_100)];
        };
        const operand_102 = block_105: {
            const operand_103 = ((in).table).labels;
            const operand_104 = (in).index;

            if ((operand_104 >= (operand_103).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_105 (operand_103)[@intCast(operand_104)];
        };
        const operand_106 = (try function_0(allocator, block_109: {
            const operand_107 = ((in).table).first;
            const operand_108 = (in).index;

            if ((operand_108 >= (operand_107).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_109 (operand_107)[@intCast(operand_108)];
        }));
        const operand_110 = (try function_0(allocator, block_113: {
            const operand_111 = ((in).table).second;
            const operand_112 = (in).index;

            if ((operand_112 >= (operand_111).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_113 (operand_111)[@intCast(operand_112)];
        }));
        const operand_114 = ((in).table).children;
        const operand_115 = ((in).table).field_names;
        const operand_116 = ((in).table).field_types;
        const operand_117 = ((in).table).names;

        break :block_120 block_119: {
            const operand_118 = (try (allocator).create((zx_abi).zx_type_22));

            (operand_118).* = @as((zx_abi).zx_type_22, (zx_abi).zx_type_22{ .kind = operand_90, .first = operand_94, .second = operand_98, .label = operand_102, .offset = operand_106, .count = operand_110, .children = operand_114, .field_names = operand_115, .field_types = operand_116, .names = operand_117, });

            break :block_119 @as(*const (zx_abi).zx_type_22, operand_118);
        };
    };
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_25) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_0(allocator, (in).id));
    const value_2: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_3: bool = (value_1 >= value_2);
    const value_4: (zx_abi).zx_type_15 = (if (value_3) (((in).tables).delta).* else (((in).tables).base).*);
    const value_5: u64 = (if (value_3) (value_1 - value_2) else value_1);

    return block_13: {
        const operand_1 = (&value_4);
        const operand_2 = value_5;
        const operand_3 = (zx_abi).zx_type_24{ .table = operand_1, .index = operand_2, };
        const operand_4 = (&operand_3);
        const operand_5 = (try function_7_value(allocator, (zx_abi).value_zx_type_24_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77{ .index = (operand_4).index, .table = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_4).table).children, .field_names = ((operand_4).table).field_names, .field_types = ((operand_4).table).field_types, .first = ((operand_4).table).first, .kinds = ((operand_4).table).kinds, .labels = ((operand_4).table).labels, .names = ((operand_4).table).names, .second = ((operand_4).table).second, .zx_origin = (operand_4).table, }, .zx_origin = operand_4, }));

        var state_borrow_6: (zx_abi).zx_type_22 = undefined;

        state_borrow_6 = (zx_abi).zx_type_22{ .children = (operand_5).children, .count = (operand_5).count, .field_names = (operand_5).field_names, .field_types = (operand_5).field_types, .first = (operand_5).first, .kind = (operand_5).kind, .label = (operand_5).label, .names = (operand_5).names, .offset = (operand_5).offset, .second = (operand_5).second, };

        const operand_7 = ((operand_5).zx_origin orelse (&state_borrow_6));
        const operand_8 = (in).candidate;
        const operand_9 = (try function_3_value(allocator, (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_8).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_8).fields).names, .types = ((operand_8).fields).types, .zx_origin = (operand_8).fields, }, .first = (operand_8).first, .kind = (operand_8).kind, .label = (operand_8).label, .names = (operand_8).names, .second = (operand_8).second, .zx_origin = operand_8, }));

        var state_borrow_10: (zx_abi).zx_type_22 = undefined;

        state_borrow_10 = (zx_abi).zx_type_22{ .children = (operand_9).children, .count = (operand_9).count, .field_names = (operand_9).field_names, .field_types = (operand_9).field_types, .first = (operand_9).first, .kind = (operand_9).kind, .label = (operand_9).label, .names = (operand_9).names, .offset = (operand_9).offset, .second = (operand_9).second, };

        const operand_11 = ((operand_9).zx_origin orelse (&state_borrow_10));
        const operand_12 = (zx_abi).zx_type_23{ .left = operand_7, .right = operand_11, };

        break :block_13 (try function_4(allocator, (&operand_12)));
    };
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_26) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_18 {
    @setRuntimeSafety(true);

    const value_1: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_2: u64 = (try function_0(allocator, (in).id));
    const value_3: bool = (value_2 >= value_1);
    const value_4: *const (zx_abi).zx_type_15 = (if (value_3) ((in).tables).delta else ((in).tables).base);
    const value_5: u64 = (if (value_3) (value_2 - value_1) else value_2);

    return block_20: {
        const operand_1 = (try function_5(allocator, block_4: {
            const operand_2 = (value_4).kinds;
            const operand_3 = value_5;

            if ((operand_3 >= (operand_2).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_4 (operand_2)[@intCast(operand_3)];
        }));
        const operand_5 = block_8: {
            const operand_6 = (value_4).first;
            const operand_7 = value_5;

            if ((operand_7 >= (operand_6).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_8 (operand_6)[@intCast(operand_7)];
        };
        const operand_9 = block_12: {
            const operand_10 = (value_4).second;
            const operand_11 = value_5;

            if ((operand_11 >= (operand_10).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_12 (operand_10)[@intCast(operand_11)];
        };
        const operand_13 = block_16: {
            const operand_14 = (value_4).labels;
            const operand_15 = value_5;

            if ((operand_15 >= (operand_14).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_16 (operand_14)[@intCast(operand_15)];
        };
        const operand_17 = value_3;

        break :block_20 block_19: {
            const operand_18 = (try (allocator).create((zx_abi).zx_type_18));

            (operand_18).* = @as((zx_abi).zx_type_18, (zx_abi).zx_type_18{ .kind = operand_1, .first = operand_5, .second = operand_9, .label = operand_13, .delta = operand_17, });

            break :block_19 @as(*const (zx_abi).zx_type_18, operand_18);
        };
    };
}

fn function_9_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_26_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce {
    @setRuntimeSafety(true);

    const value_1: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_2: u64 = (try function_0(allocator, (in).id));
    const value_3: bool = (block_49: {
        break :block_49 value_2;
    } >= block_50: {
        break :block_50 value_1;
    });
    const value_4: (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = (if (block_48: {
        break :block_48 value_3;
    }) ((in).tables).delta else ((in).tables).base);
    const value_5: u64 = (if (block_44: {
        break :block_44 value_3;
    }) (block_45: {
        break :block_45 value_2;
    } - block_46: {
        break :block_46 value_1;
    }) else block_47: {
        break :block_47 value_2;
    });

    return block_43: {
        const operand_21 = (try function_5(allocator, block_25: {
            const operand_23 = (value_4).kinds;
            const operand_24 = block_22: {
                break :block_22 value_5;
            };

            if ((operand_24 >= (operand_23).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_25 (operand_23)[@intCast(operand_24)];
        }));
        const operand_26 = block_30: {
            const operand_28 = (value_4).first;
            const operand_29 = block_27: {
                break :block_27 value_5;
            };

            if ((operand_29 >= (operand_28).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_30 (operand_28)[@intCast(operand_29)];
        };
        const operand_31 = block_35: {
            const operand_33 = (value_4).second;
            const operand_34 = block_32: {
                break :block_32 value_5;
            };

            if ((operand_34 >= (operand_33).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_35 (operand_33)[@intCast(operand_34)];
        };
        const operand_36 = block_40: {
            const operand_38 = (value_4).labels;
            const operand_39 = block_37: {
                break :block_37 value_5;
            };

            if ((operand_39 >= (operand_38).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_40 (operand_38)[@intCast(operand_39)];
        };
        const operand_41 = block_42: {
            break :block_42 value_3;
        };

        break :block_43 @as((zx_abi).value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .kind = operand_21, .first = operand_26, .second = operand_31, .label = operand_36, .delta = operand_41, });
    };
}

fn function_10(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_26) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_18 {
    @setRuntimeSafety(true);

    return block_5: {
        const operand_1 = in;
        const operand_2 = (try function_9_value(allocator, (zx_abi).value_zx_type_26_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d{ .id = (operand_1).id, .tables = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).base).children, .field_names = (((operand_1).tables).base).field_names, .field_types = (((operand_1).tables).base).field_types, .first = (((operand_1).tables).base).first, .kinds = (((operand_1).tables).base).kinds, .labels = (((operand_1).tables).base).labels, .names = (((operand_1).tables).base).names, .second = (((operand_1).tables).base).second, .zx_origin = ((operand_1).tables).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).delta).children, .field_names = (((operand_1).tables).delta).field_names, .field_types = (((operand_1).tables).delta).field_types, .first = (((operand_1).tables).delta).first, .kinds = (((operand_1).tables).delta).kinds, .labels = (((operand_1).tables).delta).labels, .names = (((operand_1).tables).delta).names, .second = (((operand_1).tables).delta).second, .zx_origin = ((operand_1).tables).delta, }, .zx_origin = (operand_1).tables, }, .zx_origin = operand_1, }));

        break :block_5 (if (((operand_2).zx_origin != null)) (operand_2).zx_origin.? else block_4: {
            const operand_3 = (try (allocator).create((zx_abi).zx_type_18));

            (operand_3).* = (zx_abi).zx_type_18{ .delta = (operand_2).delta, .first = (operand_2).first, .kind = (operand_2).kind, .label = (operand_2).label, .second = (operand_2).second, };

            break :block_4 @as(*const (zx_abi).zx_type_18, operand_3);
        });
    };
}

fn function_10_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_26_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce {
    @setRuntimeSafety(true);

    return block_6: {
        break :block_6 (try function_9_value(allocator, in));
    };
}

fn function_11(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_32) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_28 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, ((((in).origins).base).ids).len) + @as(u64, ((((in).origins).delta).ids).len));
    const value_2: u32 = @as(u32, 0);

    return block_92: {
        const state_type_2 = struct {
            names: []const []const u8,
            types: []const u32,
        };
        const state_type_3 = struct {
            children: []const u32,
            fields: state_type_2,
            first: u32,
            kind: (zx_abi).zx_type_11,
            label: []const u8,
            names: []const []const u8,
            second: u32,
        };
        const state_type_4 = struct {
            kind: u8,
            member: []const u8,
            owner: []const u8,
        };
        const state_type_5 = struct {
            ids: []const u32,
            kinds: []const u8,
            members: []const []const u8,
            owners: []const []const u8,
        };
        const state_type_6 = struct {
            base: state_type_5,
            delta: state_type_5,
        };
        const state_type_7 = struct {
            children: []const u32,
            field_names: []const []const u8,
            field_types: []const u32,
            first: []const u32,
            kinds: []const u8,
            labels: []const []const u8,
            names: []const []const u8,
            second: []const u32,
        };
        const state_type_8 = struct {
            base: state_type_7,
            delta: state_type_7,
        };
        const state_type_9 = struct {
            candidate: state_type_3,
            count: u64,
            id: u32,
            index: u64,
            origin: state_type_4,
            origins: state_type_6,
            status: (zx_abi).zx_type_27,
            tables: state_type_8,
        };
        const state_type_11 = struct {
            candidate: state_type_3,
            origin: state_type_4,
            origins: state_type_6,
            tables: state_type_8,
        };
        const operand_28 = block_27: {
            const operand_13 = (block_12: {
                const operand_10 = in;

                break :block_12 state_type_11{ .candidate = state_type_3{ .children = ((operand_10).candidate).children, .fields = state_type_2{ .names = (((operand_10).candidate).fields).names, .types = (((operand_10).candidate).fields).types, }, .first = ((operand_10).candidate).first, .kind = ((operand_10).candidate).kind, .label = ((operand_10).candidate).label, .names = ((operand_10).candidate).names, .second = ((operand_10).candidate).second, }, .origin = state_type_4{ .kind = ((operand_10).origin).kind, .member = ((operand_10).origin).member, .owner = ((operand_10).origin).owner, }, .origins = state_type_6{ .base = state_type_5{ .ids = (((operand_10).origins).base).ids, .kinds = (((operand_10).origins).base).kinds, .members = (((operand_10).origins).base).members, .owners = (((operand_10).origins).base).owners, }, .delta = state_type_5{ .ids = (((operand_10).origins).delta).ids, .kinds = (((operand_10).origins).delta).kinds, .members = (((operand_10).origins).delta).members, .owners = (((operand_10).origins).delta).owners, }, }, .tables = state_type_8{ .base = state_type_7{ .children = (((operand_10).tables).base).children, .field_names = (((operand_10).tables).base).field_names, .field_types = (((operand_10).tables).base).field_types, .first = (((operand_10).tables).base).first, .kinds = (((operand_10).tables).base).kinds, .labels = (((operand_10).tables).base).labels, .names = (((operand_10).tables).base).names, .second = (((operand_10).tables).base).second, }, .delta = state_type_7{ .children = (((operand_10).tables).delta).children, .field_names = (((operand_10).tables).delta).field_names, .field_types = (((operand_10).tables).delta).field_types, .first = (((operand_10).tables).delta).first, .kinds = (((operand_10).tables).delta).kinds, .labels = (((operand_10).tables).delta).labels, .names = (((operand_10).tables).delta).names, .second = (((operand_10).tables).delta).second, }, }, };
            }).tables;
            const operand_16 = (block_15: {
                const operand_14 = in;

                break :block_15 state_type_11{ .candidate = state_type_3{ .children = ((operand_14).candidate).children, .fields = state_type_2{ .names = (((operand_14).candidate).fields).names, .types = (((operand_14).candidate).fields).types, }, .first = ((operand_14).candidate).first, .kind = ((operand_14).candidate).kind, .label = ((operand_14).candidate).label, .names = ((operand_14).candidate).names, .second = ((operand_14).candidate).second, }, .origin = state_type_4{ .kind = ((operand_14).origin).kind, .member = ((operand_14).origin).member, .owner = ((operand_14).origin).owner, }, .origins = state_type_6{ .base = state_type_5{ .ids = (((operand_14).origins).base).ids, .kinds = (((operand_14).origins).base).kinds, .members = (((operand_14).origins).base).members, .owners = (((operand_14).origins).base).owners, }, .delta = state_type_5{ .ids = (((operand_14).origins).delta).ids, .kinds = (((operand_14).origins).delta).kinds, .members = (((operand_14).origins).delta).members, .owners = (((operand_14).origins).delta).owners, }, }, .tables = state_type_8{ .base = state_type_7{ .children = (((operand_14).tables).base).children, .field_names = (((operand_14).tables).base).field_names, .field_types = (((operand_14).tables).base).field_types, .first = (((operand_14).tables).base).first, .kinds = (((operand_14).tables).base).kinds, .labels = (((operand_14).tables).base).labels, .names = (((operand_14).tables).base).names, .second = (((operand_14).tables).base).second, }, .delta = state_type_7{ .children = (((operand_14).tables).delta).children, .field_names = (((operand_14).tables).delta).field_names, .field_types = (((operand_14).tables).delta).field_types, .first = (((operand_14).tables).delta).first, .kinds = (((operand_14).tables).delta).kinds, .labels = (((operand_14).tables).delta).labels, .names = (((operand_14).tables).delta).names, .second = (((operand_14).tables).delta).second, }, }, };
            }).origins;
            const operand_19 = (block_18: {
                const operand_17 = in;

                break :block_18 state_type_11{ .candidate = state_type_3{ .children = ((operand_17).candidate).children, .fields = state_type_2{ .names = (((operand_17).candidate).fields).names, .types = (((operand_17).candidate).fields).types, }, .first = ((operand_17).candidate).first, .kind = ((operand_17).candidate).kind, .label = ((operand_17).candidate).label, .names = ((operand_17).candidate).names, .second = ((operand_17).candidate).second, }, .origin = state_type_4{ .kind = ((operand_17).origin).kind, .member = ((operand_17).origin).member, .owner = ((operand_17).origin).owner, }, .origins = state_type_6{ .base = state_type_5{ .ids = (((operand_17).origins).base).ids, .kinds = (((operand_17).origins).base).kinds, .members = (((operand_17).origins).base).members, .owners = (((operand_17).origins).base).owners, }, .delta = state_type_5{ .ids = (((operand_17).origins).delta).ids, .kinds = (((operand_17).origins).delta).kinds, .members = (((operand_17).origins).delta).members, .owners = (((operand_17).origins).delta).owners, }, }, .tables = state_type_8{ .base = state_type_7{ .children = (((operand_17).tables).base).children, .field_names = (((operand_17).tables).base).field_names, .field_types = (((operand_17).tables).base).field_types, .first = (((operand_17).tables).base).first, .kinds = (((operand_17).tables).base).kinds, .labels = (((operand_17).tables).base).labels, .names = (((operand_17).tables).base).names, .second = (((operand_17).tables).base).second, }, .delta = state_type_7{ .children = (((operand_17).tables).delta).children, .field_names = (((operand_17).tables).delta).field_names, .field_types = (((operand_17).tables).delta).field_types, .first = (((operand_17).tables).delta).first, .kinds = (((operand_17).tables).delta).kinds, .labels = (((operand_17).tables).delta).labels, .names = (((operand_17).tables).delta).names, .second = (((operand_17).tables).delta).second, }, }, };
            }).origin;
            const operand_22 = (block_21: {
                const operand_20 = in;

                break :block_21 state_type_11{ .candidate = state_type_3{ .children = ((operand_20).candidate).children, .fields = state_type_2{ .names = (((operand_20).candidate).fields).names, .types = (((operand_20).candidate).fields).types, }, .first = ((operand_20).candidate).first, .kind = ((operand_20).candidate).kind, .label = ((operand_20).candidate).label, .names = ((operand_20).candidate).names, .second = ((operand_20).candidate).second, }, .origin = state_type_4{ .kind = ((operand_20).origin).kind, .member = ((operand_20).origin).member, .owner = ((operand_20).origin).owner, }, .origins = state_type_6{ .base = state_type_5{ .ids = (((operand_20).origins).base).ids, .kinds = (((operand_20).origins).base).kinds, .members = (((operand_20).origins).base).members, .owners = (((operand_20).origins).base).owners, }, .delta = state_type_5{ .ids = (((operand_20).origins).delta).ids, .kinds = (((operand_20).origins).delta).kinds, .members = (((operand_20).origins).delta).members, .owners = (((operand_20).origins).delta).owners, }, }, .tables = state_type_8{ .base = state_type_7{ .children = (((operand_20).tables).base).children, .field_names = (((operand_20).tables).base).field_names, .field_types = (((operand_20).tables).base).field_types, .first = (((operand_20).tables).base).first, .kinds = (((operand_20).tables).base).kinds, .labels = (((operand_20).tables).base).labels, .names = (((operand_20).tables).base).names, .second = (((operand_20).tables).base).second, }, .delta = state_type_7{ .children = (((operand_20).tables).delta).children, .field_names = (((operand_20).tables).delta).field_names, .field_types = (((operand_20).tables).delta).field_types, .first = (((operand_20).tables).delta).first, .kinds = (((operand_20).tables).delta).kinds, .labels = (((operand_20).tables).delta).labels, .names = (((operand_20).tables).delta).names, .second = (((operand_20).tables).delta).second, }, }, };
            }).candidate;
            const operand_23 = value_1;
            const operand_24 = @as(u64, 0);
            const operand_25 = @as((zx_abi).zx_type_27, .Missing);
            const operand_26 = value_2;

            break :block_27 state_type_9{ .tables = operand_13, .origins = operand_16, .origin = operand_19, .candidate = operand_22, .count = operand_23, .index = operand_24, .status = operand_25, .id = operand_26, };
        };
        const state_type_35 = struct {
            candidate: state_type_3,
            id: u32,
            tables: state_type_8,
        };
        const state_type_49 = struct {
            id: u32,
            tables: state_type_8,
        };
        const state_type_63 = struct {
            delta: bool,
            first: u32,
            kind: (zx_abi).zx_type_11,
            label: []const u8,
            second: u32,
        };

        var state_1: state_type_9 = operand_28;

        var state_changed_29 = false;

        while ((((state_1).status == @as((zx_abi).zx_type_27, .Missing)) and ((state_1).index < (state_1).count))) {
            state_1 = block_86: {
                const value_5: u64 = @as(u64, ((((state_1).origins).base).ids).len);
                const value_6: bool = ((state_1).index >= value_5);
                const value_7: state_type_5 = (if (value_6) ((state_1).origins).delta else ((state_1).origins).base);
                const value_8: u64 = (if (value_6) ((state_1).index - value_5) else (state_1).index);
                const value_9: u32 = block_85: {
                    const operand_83 = (value_7).ids;
                    const operand_84 = value_8;

                    if ((operand_84 >= (operand_83).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_85 (operand_83)[@intCast(operand_84)];
                };
                const value_10: bool = (((block_70: {
                    const operand_68 = (value_7).kinds;
                    const operand_69 = value_8;

                    if ((operand_69 >= (operand_68).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_70 (operand_68)[@intCast(operand_69)];
                } == ((state_1).origin).kind) and block_76: {
                    const operand_74 = block_73: {
                        const operand_71 = (value_7).owners;
                        const operand_72 = value_8;

                        if ((operand_72 >= (operand_71).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_73 (operand_71)[@intCast(operand_72)];
                    };
                    const operand_75 = ((state_1).origin).owner;

                    break :block_76 ((std).mem).eql(u8, operand_74, operand_75);
                }) and block_82: {
                    const operand_80 = block_79: {
                        const operand_77 = (value_7).members;
                        const operand_78 = value_8;

                        if ((operand_78 >= (operand_77).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_79 (operand_77)[@intCast(operand_78)];
                    };
                    const operand_81 = ((state_1).origin).member;

                    break :block_82 ((std).mem).eql(u8, operand_80, operand_81);
                });
                const value_11: bool = (value_10 and block_67: {
                    const operand_65 = (block_64: {
                        const operand_53 = block_52: {
                            const operand_50 = (state_1).tables;
                            const operand_51 = value_9;

                            break :block_52 state_type_49{ .tables = operand_50, .id = operand_51, };
                        };
                        const operand_54 = (zx_abi).zx_type_15{ .children = (((operand_53).tables).base).children, .field_names = (((operand_53).tables).base).field_names, .field_types = (((operand_53).tables).base).field_types, .first = (((operand_53).tables).base).first, .kinds = (((operand_53).tables).base).kinds, .labels = (((operand_53).tables).base).labels, .names = (((operand_53).tables).base).names, .second = (((operand_53).tables).base).second, };
                        const operand_55 = (zx_abi).zx_type_15{ .children = (((operand_53).tables).delta).children, .field_names = (((operand_53).tables).delta).field_names, .field_types = (((operand_53).tables).delta).field_types, .first = (((operand_53).tables).delta).first, .kinds = (((operand_53).tables).delta).kinds, .labels = (((operand_53).tables).delta).labels, .names = (((operand_53).tables).delta).names, .second = (((operand_53).tables).delta).second, };
                        const operand_56 = (zx_abi).zx_type_16{ .base = (&operand_54), .delta = (&operand_55), };
                        const operand_57 = (zx_abi).zx_type_26{ .id = (operand_53).id, .tables = (&operand_56), };
                        const operand_62 = block_61: {
                            const operand_58 = (&operand_57);
                            const operand_59 = (try function_10_value(allocator, (zx_abi).value_zx_type_26_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d{ .id = (operand_58).id, .tables = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_58).tables).base).children, .field_names = (((operand_58).tables).base).field_names, .field_types = (((operand_58).tables).base).field_types, .first = (((operand_58).tables).base).first, .kinds = (((operand_58).tables).base).kinds, .labels = (((operand_58).tables).base).labels, .names = (((operand_58).tables).base).names, .second = (((operand_58).tables).base).second, .zx_origin = ((operand_58).tables).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_58).tables).delta).children, .field_names = (((operand_58).tables).delta).field_names, .field_types = (((operand_58).tables).delta).field_types, .first = (((operand_58).tables).delta).first, .kinds = (((operand_58).tables).delta).kinds, .labels = (((operand_58).tables).delta).labels, .names = (((operand_58).tables).delta).names, .second = (((operand_58).tables).delta).second, .zx_origin = ((operand_58).tables).delta, }, .zx_origin = (operand_58).tables, }, .zx_origin = operand_58, }));

                            break :block_61 (if (((operand_59).zx_origin != null)) ((operand_59).zx_origin.?).* else block_60: {
                                break :block_60 (zx_abi).zx_type_18{ .delta = (operand_59).delta, .first = (operand_59).first, .kind = (operand_59).kind, .label = (operand_59).label, .second = (operand_59).second, };
                            });
                        };

                        break :block_64 state_type_63{ .delta = (operand_62).delta, .first = (operand_62).first, .kind = (operand_62).kind, .label = (operand_62).label, .second = (operand_62).second, };
                    }).label;
                    const operand_66 = ((state_1).candidate).label;

                    break :block_67 ((std).mem).eql(u8, operand_65, operand_66);
                });
                const value_12: (zx_abi).zx_type_27 = (if ((!value_11)) @as((zx_abi).zx_type_27, .Missing) else (if (block_48: {
                    const operand_40 = block_39: {
                        const operand_36 = (state_1).tables;
                        const operand_37 = value_9;
                        const operand_38 = (state_1).candidate;

                        break :block_39 state_type_35{ .tables = operand_36, .id = operand_37, .candidate = operand_38, };
                    };
                    const operand_41 = (zx_abi).zx_type_17{ .names = (((operand_40).candidate).fields).names, .types = (((operand_40).candidate).fields).types, };
                    const operand_42 = (zx_abi).zx_type_19{ .children = ((operand_40).candidate).children, .fields = (&operand_41), .first = ((operand_40).candidate).first, .kind = ((operand_40).candidate).kind, .label = ((operand_40).candidate).label, .names = ((operand_40).candidate).names, .second = ((operand_40).candidate).second, };
                    const operand_43 = (zx_abi).zx_type_15{ .children = (((operand_40).tables).base).children, .field_names = (((operand_40).tables).base).field_names, .field_types = (((operand_40).tables).base).field_types, .first = (((operand_40).tables).base).first, .kinds = (((operand_40).tables).base).kinds, .labels = (((operand_40).tables).base).labels, .names = (((operand_40).tables).base).names, .second = (((operand_40).tables).base).second, };
                    const operand_44 = (zx_abi).zx_type_15{ .children = (((operand_40).tables).delta).children, .field_names = (((operand_40).tables).delta).field_names, .field_types = (((operand_40).tables).delta).field_types, .first = (((operand_40).tables).delta).first, .kinds = (((operand_40).tables).delta).kinds, .labels = (((operand_40).tables).delta).labels, .names = (((operand_40).tables).delta).names, .second = (((operand_40).tables).delta).second, };
                    const operand_45 = (zx_abi).zx_type_16{ .base = (&operand_43), .delta = (&operand_44), };
                    const operand_46 = (zx_abi).zx_type_25{ .candidate = (&operand_42), .id = (operand_40).id, .tables = (&operand_45), };
                    const operand_47 = (try function_8(allocator, (&operand_46)));

                    break :block_48 operand_47;
                }) @as((zx_abi).zx_type_27, .Found) else @as((zx_abi).zx_type_27, .Conflict)));
                const value_13: state_type_9 = block_34: {
                    const operand_30 = state_1;
                    const operand_31 = ((state_1).index + @as(u64, 1));
                    const operand_32 = value_12;
                    const operand_33 = (if (value_11) value_9 else (state_1).id);

                    break :block_34 state_type_9{ .candidate = (operand_30).candidate, .count = (operand_30).count, .id = operand_33, .index = operand_31, .origin = (operand_30).origin, .origins = (operand_30).origins, .status = operand_32, .tables = (operand_30).tables, };
                };

                break :block_86 value_13;
            };

            state_changed_29 = true;
        }

        break :block_92 block_91: {
            const operand_87 = (state_1).status;
            const operand_88 = (state_1).id;

            break :block_91 block_90: {
                const operand_89 = (try (allocator).create((zx_abi).zx_type_28));

                (operand_89).* = @as((zx_abi).zx_type_28, (zx_abi).zx_type_28{ .status = operand_87, .id = operand_88, });

                break :block_90 @as(*const (zx_abi).zx_type_28, operand_89);
            };
        };
    };
}

fn function_11_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_32_bd208de60d840cfc787ebffb6ff5afe0f3ea76a39636b572313b962e7b4577de) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_28_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, ((((in).origins).base).ids).len) + @as(u64, ((((in).origins).delta).ids).len));
    const value_2: u32 = @as(u32, 0);
    const value_14: (zx_abi).value_zx_type_34_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01 = block_177: {
        const operand_109 = block_108: {
            const operand_98 = (in).tables;
            const operand_99 = (in).origins;
            const operand_100 = (in).origin;
            const operand_101 = (in).candidate;
            const operand_102 = block_103: {
                break :block_103 value_1;
            };
            const operand_104 = @as(u64, 0);
            const operand_105 = @as((zx_abi).zx_type_27, .Missing);
            const operand_106 = block_107: {
                break :block_107 value_2;
            };

            break :block_108 @as((zx_abi).value_zx_type_34_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01, (zx_abi).value_zx_type_34_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01{ .tables = operand_98, .origins = operand_99, .origin = operand_100, .candidate = operand_101, .count = operand_102, .index = operand_104, .status = operand_105, .id = operand_106, });
        };

        var state_97: (zx_abi).value_zx_type_34_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01 = operand_109;

        var state_changed_110 = false;

        while ((((state_97).status == @as((zx_abi).zx_type_27, .Missing)) and ((state_97).index < (state_97).count))) {
            state_97 = block_175: {
                const value_5: u64 = @as(u64, ((((state_97).origins).base).ids).len);
                const value_6: bool = ((state_97).index >= block_174: {
                    break :block_174 value_5;
                });
                const value_7: (zx_abi).value_zx_type_30_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if (block_173: {
                    break :block_173 value_6;
                }) ((state_97).origins).delta else ((state_97).origins).base);
                const value_8: u64 = (if (block_171: {
                    break :block_171 value_6;
                }) ((state_97).index - block_172: {
                    break :block_172 value_5;
                }) else (state_97).index);
                const value_9: u32 = block_170: {
                    const operand_168 = (value_7).ids;
                    const operand_169 = block_167: {
                        break :block_167 value_8;
                    };

                    if ((operand_169 >= (operand_168).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_170 (operand_168)[@intCast(operand_169)];
                };
                const value_10: bool = (((block_152: {
                    const operand_150 = (value_7).kinds;
                    const operand_151 = block_149: {
                        break :block_149 value_8;
                    };

                    if ((operand_151 >= (operand_150).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_152 (operand_150)[@intCast(operand_151)];
                } == ((state_97).origin).kind) and block_159: {
                    const operand_157 = block_156: {
                        const operand_154 = (value_7).owners;
                        const operand_155 = block_153: {
                            break :block_153 value_8;
                        };

                        if ((operand_155 >= (operand_154).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_156 (operand_154)[@intCast(operand_155)];
                    };
                    const operand_158 = ((state_97).origin).owner;

                    break :block_159 ((std).mem).eql(u8, operand_157, operand_158);
                }) and block_166: {
                    const operand_164 = block_163: {
                        const operand_161 = (value_7).members;
                        const operand_162 = block_160: {
                            break :block_160 value_8;
                        };

                        if ((operand_162 >= (operand_161).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_163 (operand_161)[@intCast(operand_162)];
                    };
                    const operand_165 = ((state_97).origin).member;

                    break :block_166 ((std).mem).eql(u8, operand_164, operand_165);
                });
                const value_11: bool = (block_140: {
                    break :block_140 value_10;
                } and block_148: {
                    const operand_146 = (block_145: {
                        break :block_145 (try function_10_value(allocator, block_144: {
                            const operand_141 = (state_97).tables;
                            const operand_142 = block_143: {
                                break :block_143 value_9;
                            };

                            break :block_144 @as((zx_abi).value_zx_type_26_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d, (zx_abi).value_zx_type_26_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d{ .tables = operand_141, .id = operand_142, });
                        }));
                    }).label;
                    const operand_147 = ((state_97).candidate).label;

                    break :block_148 ((std).mem).eql(u8, operand_146, operand_147);
                });
                const value_12: (zx_abi).zx_type_27 = (if ((!block_139: {
                    break :block_139 value_11;
                })) @as((zx_abi).zx_type_27, .Missing) else (if (block_138: {
                    const operand_119 = (state_97).tables;

                    var state_borrow_120: (zx_abi).zx_type_15 = undefined;

                    state_borrow_120 = (zx_abi).zx_type_15{ .children = ((operand_119).base).children, .field_names = ((operand_119).base).field_names, .field_types = ((operand_119).base).field_types, .first = ((operand_119).base).first, .kinds = ((operand_119).base).kinds, .labels = ((operand_119).base).labels, .names = ((operand_119).base).names, .second = ((operand_119).base).second, };

                    var state_borrow_121: (zx_abi).zx_type_15 = undefined;

                    state_borrow_121 = (zx_abi).zx_type_15{ .children = ((operand_119).delta).children, .field_names = ((operand_119).delta).field_names, .field_types = ((operand_119).delta).field_types, .first = ((operand_119).delta).first, .kinds = ((operand_119).delta).kinds, .labels = ((operand_119).delta).labels, .names = ((operand_119).delta).names, .second = ((operand_119).delta).second, };

                    var state_borrow_122: (zx_abi).zx_type_16 = undefined;

                    state_borrow_122 = (zx_abi).zx_type_16{ .base = (((operand_119).base).zx_origin orelse (&state_borrow_120)), .delta = (((operand_119).delta).zx_origin orelse (&state_borrow_121)), };

                    const operand_123 = ((operand_119).zx_origin orelse (&state_borrow_122));
                    const operand_125 = block_124: {
                        break :block_124 value_9;
                    };
                    const operand_126 = (state_97).candidate;

                    var state_borrow_127: (zx_abi).zx_type_17 = undefined;

                    state_borrow_127 = (zx_abi).zx_type_17{ .names = ((operand_126).fields).names, .types = ((operand_126).fields).types, };

                    var state_borrow_128: (zx_abi).zx_type_19 = undefined;

                    state_borrow_128 = (zx_abi).zx_type_19{ .children = (operand_126).children, .fields = (((operand_126).fields).zx_origin orelse (&state_borrow_127)), .first = (operand_126).first, .kind = (operand_126).kind, .label = (operand_126).label, .names = (operand_126).names, .second = (operand_126).second, };

                    const operand_129 = ((operand_126).zx_origin orelse (&state_borrow_128));
                    const operand_130 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_123).base).children, .field_names = ((operand_123).base).field_names, .field_types = ((operand_123).base).field_types, .first = ((operand_123).base).first, .kinds = ((operand_123).base).kinds, .labels = ((operand_123).base).labels, .names = ((operand_123).base).names, .second = ((operand_123).base).second, .zx_origin = (operand_123).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_123).delta).children, .field_names = ((operand_123).delta).field_names, .field_types = ((operand_123).delta).field_types, .first = ((operand_123).delta).first, .kinds = ((operand_123).delta).kinds, .labels = ((operand_123).delta).labels, .names = ((operand_123).delta).names, .second = ((operand_123).delta).second, .zx_origin = (operand_123).delta, }, .zx_origin = operand_123, };

                    var state_borrow_131: (zx_abi).zx_type_15 = undefined;

                    state_borrow_131 = (zx_abi).zx_type_15{ .children = ((operand_130).base).children, .field_names = ((operand_130).base).field_names, .field_types = ((operand_130).base).field_types, .first = ((operand_130).base).first, .kinds = ((operand_130).base).kinds, .labels = ((operand_130).base).labels, .names = ((operand_130).base).names, .second = ((operand_130).base).second, };

                    var state_borrow_132: (zx_abi).zx_type_15 = undefined;

                    state_borrow_132 = (zx_abi).zx_type_15{ .children = ((operand_130).delta).children, .field_names = ((operand_130).delta).field_names, .field_types = ((operand_130).delta).field_types, .first = ((operand_130).delta).first, .kinds = ((operand_130).delta).kinds, .labels = ((operand_130).delta).labels, .names = ((operand_130).delta).names, .second = ((operand_130).delta).second, };

                    var state_borrow_133: (zx_abi).zx_type_16 = undefined;

                    state_borrow_133 = (zx_abi).zx_type_16{ .base = (((operand_130).base).zx_origin orelse (&state_borrow_131)), .delta = (((operand_130).delta).zx_origin orelse (&state_borrow_132)), };

                    const operand_134 = (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_129).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_129).fields).names, .types = ((operand_129).fields).types, .zx_origin = (operand_129).fields, }, .first = (operand_129).first, .kind = (operand_129).kind, .label = (operand_129).label, .names = (operand_129).names, .second = (operand_129).second, .zx_origin = operand_129, };

                    var state_borrow_135: (zx_abi).zx_type_17 = undefined;

                    state_borrow_135 = (zx_abi).zx_type_17{ .names = ((operand_134).fields).names, .types = ((operand_134).fields).types, };

                    var state_borrow_136: (zx_abi).zx_type_19 = undefined;

                    state_borrow_136 = (zx_abi).zx_type_19{ .children = (operand_134).children, .fields = (((operand_134).fields).zx_origin orelse (&state_borrow_135)), .first = (operand_134).first, .kind = (operand_134).kind, .label = (operand_134).label, .names = (operand_134).names, .second = (operand_134).second, };

                    const operand_137 = (zx_abi).zx_type_25{ .tables = ((operand_130).zx_origin orelse (&state_borrow_133)), .id = operand_125, .candidate = ((operand_134).zx_origin orelse (&state_borrow_136)), };

                    break :block_138 (try function_8(allocator, (&operand_137)));
                }) @as((zx_abi).zx_type_27, .Found) else @as((zx_abi).zx_type_27, .Conflict)));
                const value_13: (zx_abi).value_zx_type_34_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01 = block_118: {
                    const operand_111 = state_97;
                    const operand_112 = ((state_97).index + @as(u64, 1));
                    const operand_113 = block_114: {
                        break :block_114 value_12;
                    };
                    const operand_115 = (if (block_116: {
                        break :block_116 value_11;
                    }) block_117: {
                        break :block_117 value_9;
                    } else (state_97).id);

                    break :block_118 @as((zx_abi).value_zx_type_34_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01, (zx_abi).value_zx_type_34_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01{ .candidate = (operand_111).candidate, .count = (operand_111).count, .id = operand_115, .index = operand_112, .origin = (operand_111).origin, .origins = (operand_111).origins, .status = operand_113, .tables = (operand_111).tables, });
                };

                break :block_175 value_13;
            };

            state_changed_110 = true;
        }

        break :block_177 (if (state_changed_110) state_97 else operand_109);
    };

    return block_96: {
        const operand_94 = (value_14).status;
        const operand_95 = (value_14).id;

        break :block_96 @as((zx_abi).value_zx_type_28_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_28_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .status = operand_94, .id = operand_95, });
    };
}

fn function_12(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_28) error{ }!u64 {
    @setRuntimeSafety(true);

    return block_2: {
        const operand_1 = (in).status;

        break :block_2 (if ((operand_1 == @as((zx_abi).zx_type_27, .Missing))) @as(u64, 0) else (if ((operand_1 == @as((zx_abi).zx_type_27, .Conflict))) @as(u64, 1) else ((try function_0(allocator, (in).id)) + @as(u64, 2))));
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_32) error{ IndexOutOfBounds, OutOfMemory, }!u64 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: (zx_abi).zx_type_28 = block_4: {
        const operand_1 = in;
        const operand_2 = (try function_11_value(allocator, (zx_abi).value_zx_type_32_bd208de60d840cfc787ebffb6ff5afe0f3ea76a39636b572313b962e7b4577de{ .candidate = (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = ((operand_1).candidate).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = (((operand_1).candidate).fields).names, .types = (((operand_1).candidate).fields).types, .zx_origin = ((operand_1).candidate).fields, }, .first = ((operand_1).candidate).first, .kind = ((operand_1).candidate).kind, .label = ((operand_1).candidate).label, .names = ((operand_1).candidate).names, .second = ((operand_1).candidate).second, .zx_origin = (operand_1).candidate, }, .origin = (zx_abi).value_zx_type_29_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = ((operand_1).origin).kind, .member = ((operand_1).origin).member, .owner = ((operand_1).origin).owner, .zx_origin = (operand_1).origin, }, .origins = (zx_abi).value_zx_type_31_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53{ .base = (zx_abi).value_zx_type_30_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_1).origins).base).ids, .kinds = (((operand_1).origins).base).kinds, .members = (((operand_1).origins).base).members, .owners = (((operand_1).origins).base).owners, .zx_origin = ((operand_1).origins).base, }, .delta = (zx_abi).value_zx_type_30_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_1).origins).delta).ids, .kinds = (((operand_1).origins).delta).kinds, .members = (((operand_1).origins).delta).members, .owners = (((operand_1).origins).delta).owners, .zx_origin = ((operand_1).origins).delta, }, .zx_origin = (operand_1).origins, }, .tables = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).base).children, .field_names = (((operand_1).tables).base).field_names, .field_types = (((operand_1).tables).base).field_types, .first = (((operand_1).tables).base).first, .kinds = (((operand_1).tables).base).kinds, .labels = (((operand_1).tables).base).labels, .names = (((operand_1).tables).base).names, .second = (((operand_1).tables).base).second, .zx_origin = ((operand_1).tables).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).delta).children, .field_names = (((operand_1).tables).delta).field_names, .field_types = (((operand_1).tables).delta).field_types, .first = (((operand_1).tables).delta).first, .kinds = (((operand_1).tables).delta).kinds, .labels = (((operand_1).tables).delta).labels, .names = (((operand_1).tables).delta).names, .second = (((operand_1).tables).delta).second, .zx_origin = ((operand_1).tables).delta, }, .zx_origin = (operand_1).tables, }, .zx_origin = operand_1, }));

        break :block_4 (if (((operand_2).zx_origin != null)) ((operand_2).zx_origin.?).* else block_3: {
            break :block_3 (zx_abi).zx_type_28{ .id = (operand_2).id, .status = (operand_2).status, };
        });
    };
    const value_2: u64 = (try function_12(allocator, (&value_1)));

    return value_2;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_32) error{ IndexOutOfBounds, OutOfMemory, }!u64 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_28 = block_8: {
        const operand_5 = in;
        const operand_6 = (try function_11_value(allocator, (zx_abi).value_zx_type_32_bd208de60d840cfc787ebffb6ff5afe0f3ea76a39636b572313b962e7b4577de{ .candidate = (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = ((operand_5).candidate).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = (((operand_5).candidate).fields).names, .types = (((operand_5).candidate).fields).types, .zx_origin = ((operand_5).candidate).fields, }, .first = ((operand_5).candidate).first, .kind = ((operand_5).candidate).kind, .label = ((operand_5).candidate).label, .names = ((operand_5).candidate).names, .second = ((operand_5).candidate).second, .zx_origin = (operand_5).candidate, }, .origin = (zx_abi).value_zx_type_29_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = ((operand_5).origin).kind, .member = ((operand_5).origin).member, .owner = ((operand_5).origin).owner, .zx_origin = (operand_5).origin, }, .origins = (zx_abi).value_zx_type_31_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53{ .base = (zx_abi).value_zx_type_30_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_5).origins).base).ids, .kinds = (((operand_5).origins).base).kinds, .members = (((operand_5).origins).base).members, .owners = (((operand_5).origins).base).owners, .zx_origin = ((operand_5).origins).base, }, .delta = (zx_abi).value_zx_type_30_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_5).origins).delta).ids, .kinds = (((operand_5).origins).delta).kinds, .members = (((operand_5).origins).delta).members, .owners = (((operand_5).origins).delta).owners, .zx_origin = ((operand_5).origins).delta, }, .zx_origin = (operand_5).origins, }, .tables = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_5).tables).base).children, .field_names = (((operand_5).tables).base).field_names, .field_types = (((operand_5).tables).base).field_types, .first = (((operand_5).tables).base).first, .kinds = (((operand_5).tables).base).kinds, .labels = (((operand_5).tables).base).labels, .names = (((operand_5).tables).base).names, .second = (((operand_5).tables).base).second, .zx_origin = ((operand_5).tables).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_5).tables).delta).children, .field_names = (((operand_5).tables).delta).field_names, .field_types = (((operand_5).tables).delta).field_types, .first = (((operand_5).tables).delta).first, .kinds = (((operand_5).tables).delta).kinds, .labels = (((operand_5).tables).delta).labels, .names = (((operand_5).tables).delta).names, .second = (((operand_5).tables).delta).second, .zx_origin = ((operand_5).tables).delta, }, .zx_origin = (operand_5).tables, }, .zx_origin = operand_5, }));

        break :block_8 (if (((operand_6).zx_origin != null)) ((operand_6).zx_origin.?).* else block_7: {
            break :block_7 (zx_abi).zx_type_28{ .id = (operand_6).id, .status = (operand_6).status, };
        });
    };
    const value_2: u64 = (try function_12(allocator, (&value_1)));

    return value_2;
}

