pub const zx_type_11 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_12 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_13 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_14 = enum { Negate, Not, };

pub const zx_type_15 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_17 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
};

pub const zx_type_18 = struct {
    captures: u64,
    nonnull: u64,
};

pub const zx_type_19 = struct {
    err: u32,
    facts: *const zx_type_17,
    result: u32,
};

pub const zx_type_31 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_15,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_12,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_11,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_13,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_14,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_32 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_31,
    facts: *const zx_type_17,
    result: ?u32,
    value: u64,
};

pub const zx_type_33 = struct { []const u32, void, };

pub const zx_type_34 = struct { *const zx_type_32, };

pub const zx_type_35 = struct { *const zx_type_32, *const zx_type_17, };

pub const value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    captures: u64,
    nonnull: u64,
    zx_origin: ?*const zx_type_18 = null,
};

pub const value_zx_type_19_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    err: u32,
    facts: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: u32,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_31_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_15,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_12,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_11,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_13,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_14,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
    zx_origin: ?*const zx_type_31 = null,
};

pub const value_zx_type_32_8ec0d6c8cd037da98e2aea5b29ac9f207f0bcde67b8c7979e6ec00c4b87b66a9 = struct {
    count: u64,
    err: ?u32,
    expressions: value_zx_type_31_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788,
    facts: value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: ?u32,
    value: u64,
    zx_origin: ?*const zx_type_32 = null,
};

pub const value_zx_type_33_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, void, ?*const zx_type_33, };

pub const value_zx_type_34_782f485636d08998e322c77c0d132d8cc840ad45795be5094f4ae0c74257a17c = struct { value_zx_type_32_8ec0d6c8cd037da98e2aea5b29ac9f207f0bcde67b8c7979e6ec00c4b87b66a9, ?*const zx_type_34, };

pub const value_zx_type_35_0dea36268dc8ba04afd6297c05635c590ee2e620b4c9d3c5583e7d5836aec7e1 = struct { value_zx_type_32_8ec0d6c8cd037da98e2aea5b29ac9f207f0bcde67b8c7979e6ec00c4b87b66a9, value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_35, };

pub const native = struct {
};

pub const layouts = struct {
};

