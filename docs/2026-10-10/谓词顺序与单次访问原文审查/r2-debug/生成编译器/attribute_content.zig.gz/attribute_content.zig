const std = @import("std");

const zx_type_12 = struct {
    offset: u64,
    source: []const u8,
};

const zx_type_13 = struct { []const u8, };

const zx_type_14 = struct { []const u8, bool, };

const value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    offset: u64,
    source: []const u8,
    zx_origin: ?*const zx_type_12 = null,
};

const value_zx_type_13_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = struct { []const u8, ?*const zx_type_13, };

const value_zx_type_14_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, bool, ?*const zx_type_14, };

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .offset = zx_shape_5, .source = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_1, }, };

pub const input_shape = zx_shape_11;

pub const output_shape = zx_shape_1;

pub const Input = []const u8;

pub const Output = bool;

fn function_0(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_5: zx_type_12 = block_23: {
        const operand_5 = block_4: {
            const operand_2 = in;
            const operand_3 = @as(u64, 0);

            break :block_4 zx_type_12{ .source = operand_2, .offset = operand_3, };
        };

        var state_1: value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .offset = (operand_5).offset, .source = (operand_5).source, .zx_origin = (&operand_5), };

        while ((((state_1).offset < @as(u64, ((state_1).source).len)) and ((((block_8: {
            const operand_6 = (state_1).source;
            const operand_7 = (state_1).offset;

            if ((operand_7 >= (operand_6).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_8 (operand_6)[@intCast(operand_7)];
        } == @as(u8, 32)) or (block_11: {
            const operand_9 = (state_1).source;
            const operand_10 = (state_1).offset;

            if ((operand_10 >= (operand_9).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_11 (operand_9)[@intCast(operand_10)];
        } == @as(u8, 9))) or (block_14: {
            const operand_12 = (state_1).source;
            const operand_13 = (state_1).offset;

            if ((operand_13 >= (operand_12).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_14 (operand_12)[@intCast(operand_13)];
        } == @as(u8, 13))) or (block_17: {
            const operand_15 = (state_1).source;
            const operand_16 = (state_1).offset;

            if ((operand_16 >= (operand_15).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_17 (operand_15)[@intCast(operand_16)];
        } == @as(u8, 10))))) {
            state_1 = block_20: {
                const value_3: u64 = (state_1).offset;
                const value_4: value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = block_19: {
                    break :block_19 @as(value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, value_zx_type_12_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .offset = (block_18: {
                        break :block_18 value_3;
                    } + @as(u64, 1)), .source = (state_1).source, });
                };

                break :block_20 value_4;
            };
        }

        break :block_23 block_22: {
            break :block_22 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_21: {
                break :block_21 zx_type_12{ .offset = (state_1).offset, .source = (state_1).source, };
            });
        };
    };

    return (((&value_5)).offset < @as(u64, (((&value_5)).source).len));
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = (try function_0(allocator, in));

    return value_1;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: bool = (try function_0(allocator, in));

    return value_1;
}

