pub const zx_type_14 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_15 = struct {
    available: *const zx_type_14,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_14,
    slots: []const u32,
};

pub const zx_type_16 = struct {
    available: *const zx_type_14,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_14,
    slots: []const u32,
    valid: bool,
};

pub const zx_type_17 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
};

pub const zx_type_18 = struct { *const zx_type_15, };

pub const zx_type_19 = struct { *const zx_type_15, bool, };

pub const value_zx_type_14_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
    zx_origin: ?*const zx_type_14 = null,
};

pub const value_zx_type_15_e52ddc74181ff4e1b49826e1892b2c0e424d9fda6571df1b12710fd07408fb37 = struct {
    available: value_zx_type_14_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    count: u64,
    first: u64,
    orchestration: bool,
    required: value_zx_type_14_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    slots: []const u32,
    zx_origin: ?*const zx_type_15 = null,
};

pub const value_zx_type_16_a29d0f3b254b9a0ff9609a8298e02b1aae1580c6da44c76652526a187d6c06ec = struct {
    available: value_zx_type_14_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    count: u64,
    first: u64,
    index: u64,
    required: value_zx_type_14_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    slots: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_17_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_18c580dae6d9fc80842e26649dae1adda49c1f2329ce62753f309816ad2c747a = struct { value_zx_type_15_e52ddc74181ff4e1b49826e1892b2c0e424d9fda6571df1b12710fd07408fb37, ?*const zx_type_18, };

pub const value_zx_type_19_202b53648ed289685f0b7fff2ddeb6228d6114b311b3aff778ca9c43901c2f3b = struct { value_zx_type_15_e52ddc74181ff4e1b49826e1892b2c0e424d9fda6571df1b12710fd07408fb37, bool, ?*const zx_type_19, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
};

