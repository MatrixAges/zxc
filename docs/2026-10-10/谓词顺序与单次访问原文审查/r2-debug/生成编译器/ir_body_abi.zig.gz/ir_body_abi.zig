pub const zx_type_14 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_16 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
};

pub const zx_type_17 = enum { Copy, Borrowed, Owned, };

pub const zx_type_19 = struct {
    names: []const []const u8,
    ownership: []const zx_type_17,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_20 = struct {
    max_offset: u64,
    symbols: *const zx_type_19,
};

pub const zx_type_21 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_22 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_23 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_24 = enum { Negate, Not, };

pub const zx_type_25 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_34 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_25,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_22,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_21,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_23,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_24,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_35 = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_34,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
};

pub const zx_type_36 = struct {
    kind: zx_type_21,
    payload: u64,
    state: *const zx_type_35,
};

pub const zx_type_37 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
};

pub const zx_type_38 = struct {
    max_offset: u64,
    table: *const zx_type_34,
};

pub const zx_type_39 = enum { Evaluate, Constant, Parallel, Destructure, Branch, Switch, StoreSet, Result, };

pub const zx_type_41 = struct {
    block_count: []const u32,
    block_first: []const u32,
    branch_conditions: []const u32,
    branch_no: []const u32,
    branch_yes: []const u32,
    case_bodies: []const u32,
    case_values: []const ?u32,
    constant_symbols: []const u32,
    constant_values: []const u32,
    destructure_count: []const u32,
    destructure_first: []const u32,
    destructure_symbols: []const ?u32,
    destructure_values: []const u32,
    evaluations: []const u32,
    parallel_count: []const u32,
    parallel_first: []const u32,
    parallel_symbols: []const ?u32,
    parallel_values: []const u32,
    results: []const ?u32,
    selection_count: []const u32,
    selection_exhaustive: []const bool,
    selection_first: []const u32,
    selection_subjects: []const u32,
    setter_slots: []const u32,
    setter_values: []const u32,
    statement_kinds: []const zx_type_39,
    statement_payloads: []const u32,
};

pub const zx_type_42 = struct {
    block: u64,
    control: *const zx_type_41,
};

pub const zx_type_43 = struct {
    control: *const zx_type_41,
    root: ?u32,
};

pub const zx_type_44 = struct {
    count: u64,
    values: []const ?u32,
};

pub const zx_type_45 = struct {
    count: u64,
    values: []const u32,
};

pub const zx_type_46 = struct {
    control: *const zx_type_41,
    expressions: *const zx_type_34,
    root: ?u32,
    stores: *const zx_type_14,
    symbols: *const zx_type_19,
};

pub const zx_type_47 = struct {
    expressions: *const zx_type_34,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_19,
};

pub const zx_type_48 = struct {
    body: *const zx_type_46,
    max_offset: u64,
};

pub const zx_type_49 = struct {
    index: u64,
    input: *const zx_type_16,
    valid: bool,
};

pub const zx_type_50 = struct {
    index: u64,
    input: *const zx_type_37,
    next: u64,
    valid: bool,
};

pub const zx_type_51 = struct {
    block: u64,
    control: *const zx_type_41,
    end: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_52 = struct {
    block: u64,
    bodies: []const u32,
    end: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_53 = struct {
    branches: u64,
    constants: u64,
    control: *const zx_type_41,
    destructures: u64,
    evaluations: u64,
    index: u64,
    parallels: u64,
    results: u64,
    selections: u64,
    setters: u64,
    valid: bool,
};

pub const zx_type_54 = struct {
    block: u64,
    control: *const zx_type_41,
    valid: bool,
};

pub const zx_type_55 = struct {
    count: u64,
    depths: []const u64,
    owned: []const bool,
    root: u64,
};

pub const zx_type_56 = struct { []const bool, void, };

pub const zx_type_57 = struct { []const u64, void, };

pub const zx_type_58 = struct {
    block: u64,
    control: *const zx_type_41,
    depths: []const u64,
    edge: u64,
    index: u64,
    owned: []const bool,
    valid: bool,
};

pub const zx_type_59 = struct {
    index: u64,
    result: bool,
    source: []const bool,
};

pub const zx_type_60 = struct { *const zx_type_48, };

pub const zx_type_61 = struct { *const zx_type_48, bool, };

pub const zx_type_62 = struct { *const zx_type_48, bool, bool, };

pub const zx_type_63 = struct { *const zx_type_48, bool, bool, bool, };

pub const zx_type_64 = struct { *const zx_type_48, bool, bool, bool, bool, };

pub const zx_type_65 = struct { *const zx_type_48, bool, bool, bool, bool, bool, };

pub const zx_type_66 = struct {
    index: u64,
    input: *const zx_type_44,
    valid: bool,
};

pub const zx_type_67 = struct {
    index: u64,
    input: *const zx_type_45,
    valid: bool,
};

pub const value_zx_type_14_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
    zx_origin: ?*const zx_type_14 = null,
};

pub const value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    names: []const []const u8,
    ownership: []const zx_type_17,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_20_e766e5a134edd1a7902c0d5d489b919f656420f490d9e55c01ece70ba97e7603 = struct {
    max_offset: u64,
    symbols: value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_25,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_22,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_21,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_23,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_24,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
    zx_origin: ?*const zx_type_34 = null,
};

pub const value_zx_type_35_adc474bd7b756b536acf7abf124ff757ef93e26f801483a5d7e6fbf9f7e4856a = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
    zx_origin: ?*const zx_type_35 = null,
};

pub const value_zx_type_36_2e744ce04447749f8ba44dfa26005a60addf942c4fd9a5ea380ad4381b117608 = struct {
    kind: zx_type_21,
    payload: u64,
    state: value_zx_type_35_adc474bd7b756b536acf7abf124ff757ef93e26f801483a5d7e6fbf9f7e4856a,
    zx_origin: ?*const zx_type_36 = null,
};

pub const value_zx_type_37_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
    zx_origin: ?*const zx_type_37 = null,
};

pub const value_zx_type_38_f5bbf5e4882343ceb89187a60f31839e24220cb24afead07f3e0e70c78f7e8c1 = struct {
    max_offset: u64,
    table: value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788,
    zx_origin: ?*const zx_type_38 = null,
};

pub const value_zx_type_41_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6 = struct {
    block_count: []const u32,
    block_first: []const u32,
    branch_conditions: []const u32,
    branch_no: []const u32,
    branch_yes: []const u32,
    case_bodies: []const u32,
    case_values: []const ?u32,
    constant_symbols: []const u32,
    constant_values: []const u32,
    destructure_count: []const u32,
    destructure_first: []const u32,
    destructure_symbols: []const ?u32,
    destructure_values: []const u32,
    evaluations: []const u32,
    parallel_count: []const u32,
    parallel_first: []const u32,
    parallel_symbols: []const ?u32,
    parallel_values: []const u32,
    results: []const ?u32,
    selection_count: []const u32,
    selection_exhaustive: []const bool,
    selection_first: []const u32,
    selection_subjects: []const u32,
    setter_slots: []const u32,
    setter_values: []const u32,
    statement_kinds: []const zx_type_39,
    statement_payloads: []const u32,
    zx_origin: ?*const zx_type_41 = null,
};

pub const value_zx_type_42_07c44a73ee2c4c2497a7cb43351ad2303dc89e47ce0f8baaa1ac883a101a247b = struct {
    block: u64,
    control: value_zx_type_41_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6,
    zx_origin: ?*const zx_type_42 = null,
};

pub const value_zx_type_43_007775593f132d09a08666f9732cce1a3e60a48b5bd72a261b1710b8eab2db72 = struct {
    control: value_zx_type_41_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6,
    root: ?u32,
    zx_origin: ?*const zx_type_43 = null,
};

pub const value_zx_type_44_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const ?u32,
    zx_origin: ?*const zx_type_44 = null,
};

pub const value_zx_type_45_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u32,
    zx_origin: ?*const zx_type_45 = null,
};

pub const value_zx_type_46_7f0193cc9491310f4dd6c0fad70f1c6a2c037f27e30be61e63e99941c87c26b7 = struct {
    control: value_zx_type_41_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6,
    expressions: value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788,
    root: ?u32,
    stores: value_zx_type_14_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    symbols: value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_46 = null,
};

pub const value_zx_type_47_c442b395d9f51a3ae5ee040a59f72d24cb0089715c86e5add7a6f1cfb3d61e3e = struct {
    expressions: value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_47 = null,
};

pub const value_zx_type_48_9ea1ce9688e54942097e0c373726c7700de9b505460317f8c0d73f057cb24bd1 = struct {
    body: value_zx_type_46_7f0193cc9491310f4dd6c0fad70f1c6a2c037f27e30be61e63e99941c87c26b7,
    max_offset: u64,
    zx_origin: ?*const zx_type_48 = null,
};

pub const value_zx_type_49_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    index: u64,
    input: value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    valid: bool,
    zx_origin: ?*const zx_type_49 = null,
};

pub const value_zx_type_50_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    index: u64,
    input: value_zx_type_37_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    next: u64,
    valid: bool,
    zx_origin: ?*const zx_type_50 = null,
};

pub const value_zx_type_51_0a8f86c4b6fab1040f001e6c12833fe830423db2194a4a5d2d97118ec09aae91 = struct {
    block: u64,
    control: value_zx_type_41_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6,
    end: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_51 = null,
};

pub const value_zx_type_52_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    block: u64,
    bodies: []const u32,
    end: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_52 = null,
};

pub const value_zx_type_53_ed6725e9d8ae386350731e4fc469f6f2c1a9ab2cc8a6318c21fdd7b9a4667e6b = struct {
    branches: u64,
    constants: u64,
    control: value_zx_type_41_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6,
    destructures: u64,
    evaluations: u64,
    index: u64,
    parallels: u64,
    results: u64,
    selections: u64,
    setters: u64,
    valid: bool,
    zx_origin: ?*const zx_type_53 = null,
};

pub const value_zx_type_54_be9aceeda86ce7b31325b3ce00f596eb94f3ab60d8780a5c18400d8b002c8b2d = struct {
    block: u64,
    control: value_zx_type_41_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6,
    valid: bool,
    zx_origin: ?*const zx_type_54 = null,
};

pub const value_zx_type_55_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    depths: []const u64,
    owned: []const bool,
    root: u64,
    zx_origin: ?*const zx_type_55 = null,
};

pub const value_zx_type_56_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, void, ?*const zx_type_56, };

pub const value_zx_type_57_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_57, };

pub const value_zx_type_58_1687647ddacd2752200ddde0487ba5f0e43c53240c1a42ceaa51abba0384ef39 = struct {
    block: u64,
    control: value_zx_type_41_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6,
    depths: []const u64,
    edge: u64,
    index: u64,
    owned: []const bool,
    valid: bool,
    zx_origin: ?*const zx_type_58 = null,
};

pub const value_zx_type_59_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: bool,
    source: []const bool,
    zx_origin: ?*const zx_type_59 = null,
};

pub const value_zx_type_60_9e5f6682fe678e1519abbdb0bdba9a0e49de00645d505675e845d027457b9b51 = struct { value_zx_type_48_9ea1ce9688e54942097e0c373726c7700de9b505460317f8c0d73f057cb24bd1, ?*const zx_type_60, };

pub const value_zx_type_61_b1ecc6ff3fd0439fbbbd89b5e6b004d2b1d0511c17df331986fb822c7b601915 = struct { value_zx_type_48_9ea1ce9688e54942097e0c373726c7700de9b505460317f8c0d73f057cb24bd1, bool, ?*const zx_type_61, };

pub const value_zx_type_62_30143e3a261ec9c97f0b8ece22a62252f10c7e5d6792bfbc06516b6bb5b303f3 = struct { value_zx_type_48_9ea1ce9688e54942097e0c373726c7700de9b505460317f8c0d73f057cb24bd1, bool, bool, ?*const zx_type_62, };

pub const value_zx_type_63_149d2821bbb4e045ceee353e2df2b7ceb21c071be2e40177ad7dfa004603fa91 = struct { value_zx_type_48_9ea1ce9688e54942097e0c373726c7700de9b505460317f8c0d73f057cb24bd1, bool, bool, bool, ?*const zx_type_63, };

pub const value_zx_type_64_f320564ad632a9217836fb54b1226edec496fe0e2a8985b55c76611d75e48561 = struct { value_zx_type_48_9ea1ce9688e54942097e0c373726c7700de9b505460317f8c0d73f057cb24bd1, bool, bool, bool, bool, ?*const zx_type_64, };

pub const value_zx_type_65_bd5ed9c2400b413ddcb4fd83809232a3ca7979baf33553c4694b557948df8f82 = struct { value_zx_type_48_9ea1ce9688e54942097e0c373726c7700de9b505460317f8c0d73f057cb24bd1, bool, bool, bool, bool, bool, ?*const zx_type_65, };

pub const value_zx_type_66_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    index: u64,
    input: value_zx_type_44_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    valid: bool,
    zx_origin: ?*const zx_type_66 = null,
};

pub const value_zx_type_67_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    index: u64,
    input: value_zx_type_45_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    valid: bool,
    zx_origin: ?*const zx_type_67 = null,
};

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
};

