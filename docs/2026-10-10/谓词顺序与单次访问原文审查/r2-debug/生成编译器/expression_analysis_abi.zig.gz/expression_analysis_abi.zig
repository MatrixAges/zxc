pub const zx_type_11 = enum { Copy, Borrowed, Owned, };

pub const zx_type_16 = struct {
    names: []const []const u8,
    ownership: []const zx_type_11,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_17 = enum { Evaluate, Constant, Parallel, Destructure, Branch, Switch, StoreSet, Result, };

pub const zx_type_22 = struct {
    block_count: []const u32,
    block_first: []const u32,
    branch_conditions: []const u32,
    branch_no: []const u32,
    branch_yes: []const u32,
    case_bodies: []const u32,
    case_values: []const ?u32,
    constant_symbols: []const u32,
    constant_values: []const u32,
    destructure_count: []const u32,
    destructure_first: []const u32,
    destructure_symbols: []const ?u32,
    destructure_values: []const u32,
    evaluations: []const u32,
    parallel_count: []const u32,
    parallel_first: []const u32,
    parallel_symbols: []const ?u32,
    parallel_values: []const u32,
    results: []const ?u32,
    selection_count: []const u32,
    selection_exhaustive: []const bool,
    selection_first: []const u32,
    selection_subjects: []const u32,
    setter_slots: []const u32,
    setter_values: []const u32,
    statement_kinds: []const zx_type_17,
    statement_payloads: []const u32,
};

pub const zx_type_23 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_24 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_25 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_26 = enum { Negate, Not, };

pub const zx_type_27 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_34 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_27,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_24,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_23,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_25,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_26,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_35 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_36 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
};

pub const zx_type_37 = struct {
    captures: u64,
    nonnull: u64,
};

pub const zx_type_38 = struct {
    conditions: []const u64,
    facts: *const zx_type_36,
    truths: []const bool,
};

pub const zx_type_39 = struct {
    first: []const ?u32,
    floors: []const u64,
    last: []const ?u32,
    parents: []const ?u32,
    starts: []const u64,
};

pub const zx_type_40 = struct {
    next: []const ?u32,
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
};

pub const zx_type_41 = struct {
    bindings: *const zx_type_40,
    current: ?u32,
    frames: *const zx_type_39,
};

pub const zx_type_42 = struct {
    active: []const u32,
    allow_store: bool,
    captures: *const zx_type_41,
    control: *const zx_type_22,
    expression_bindings: []const u32,
    expression_units: []const []const u8,
    expressions: *const zx_type_34,
    lambda_depth: u64,
    output_type: u32,
    refinement: *const zx_type_38,
    scope_floor: u64,
    stores: *const zx_type_35,
    symbols: *const zx_type_16,
};

pub const zx_type_43 = enum { Root, Dead, UpperInput, UpperOutput, Underscore, Allocator, Async, Await, Break, Cancel, Case, Concurrent, Const, Declare, Default, Delete, Do, Else, Ensures, Enum, Export, False, For, From, Function, If, Import, In, Insert, Io, Let, Loop, Match, New, Next, Null, Process, QueryMany, QueryOne, Requires, Return, Store, Switch, Throw, Throws, Transaction, True, Try, Type, Update, Var, While, };

pub const zx_type_44 = enum { Identifier, Keyword, Number, String, Template, Punctuation, Eof, };

pub const zx_type_45 = enum { None, OpenBrace, CloseBrace, OpenParen, CloseParen, OpenBracket, CloseBracket, Colon, Semicolon, Comma, Dot, Question, Plus, Minus, Star, Slash, Percent, Less, Greater, Assign, Not, Ampersand, Pipe, Arrow, Equal, NotEqual, LessEqual, GreaterEqual, Coalesce, And, Or, Spread, };

pub const zx_type_46 = struct {
    end: u64,
    start: u64,
};

pub const zx_type_47 = struct {
    dollar: bool,
    kind: zx_type_44,
    line_break: bool,
    span: *const zx_type_46,
    symbol: zx_type_45,
    word: zx_type_43,
};

pub const zx_type_48 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_50 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_51 = struct {
    base: *const zx_type_50,
    delta: *const zx_type_50,
};

pub const zx_type_52 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_53 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_48,
    label: []const u8,
    second: u32,
};

pub const zx_type_54 = enum { Integer, FractionStart, Fraction, ExponentStart, ExponentDigits, Done, };

pub const zx_type_55 = struct {
    end: u64,
    last_byte: u8,
    phase: zx_type_54,
    separators_valid: bool,
};

pub const zx_type_56 = struct {
    diagnostic: []const u8,
    end: u64,
};

pub const zx_type_57 = enum { Idle, Identifier, Number, String, StringEscape, LineComment, BlockComment, Template, TemplateEscape, Interpolation, InterpolationString, InterpolationStringEscape, InterpolationLineComment, InterpolationBlockComment, };

pub const zx_type_58 = struct {
    code: []const u8,
    end: u64,
    message: []const u8,
    start: u64,
};

pub const zx_type_59 = struct {
    braces: u64,
    depth: u64,
    mode: zx_type_57,
    start: u64,
};

pub const zx_type_63 = struct {
    ahead_one: u8,
    ahead_two: u8,
    braces: u64,
    comments: []const *const zx_type_46,
    depth: u64,
    diagnostic: *const zx_type_58,
    dollar: bool,
    frames: []const *const zx_type_59,
    keyword_state: u64,
    line_break: bool,
    mode: zx_type_57,
    number: *const zx_type_55,
    offset: u64,
    skip_until: u64,
    source_length: u64,
    start: u64,
    symbol: zx_type_45,
    tokens: []const *const zx_type_47,
    warmed: u8,
};

pub const zx_type_64 = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    state: *const zx_type_63,
};

pub const zx_type_65 = struct {
    comments: []const *const zx_type_46,
    diagnostic: *const zx_type_58,
    tokens: []const *const zx_type_47,
};

pub const zx_type_66 = enum { Named, Object, Optional, List, Tuple, Application, };

pub const zx_type_67 = enum { Start, Name, Suffix, ListEnd, Field, FieldOptional, FieldColon, TupleItem, Done, };

pub const zx_type_68 = struct {
    child: u64,
    count: u64,
    head: u64,
    kind: zx_type_66,
    name: *const zx_type_46,
};

pub const zx_type_69 = struct {
    name: *const zx_type_46,
    previous: u64,
    value: u64,
};

pub const zx_type_70 = struct {
    previous: u64,
    value: u64,
};

pub const zx_type_71 = struct {
    fields: []const u64,
    heads: []const u64,
    items: []const u64,
};

pub const zx_type_75 = struct {
    fields: []const *const zx_type_69,
    items: []const *const zx_type_70,
    nodes: []const *const zx_type_68,
};

pub const zx_type_76 = struct {
    count: u64,
    field: *const zx_type_46,
    head: u64,
    kind: zx_type_66,
    name: *const zx_type_46,
    optional: bool,
};

pub const zx_type_77 = struct {
    depth: u64,
    diagnostic: *const zx_type_58,
    index: u64,
    name: *const zx_type_46,
    phase: zx_type_67,
    result: u64,
    start: u64,
    token: *const zx_type_47,
};

pub const zx_type_79 = struct {
    control: *const zx_type_77,
    frames: []const *const zx_type_76,
    tree: *const zx_type_75,
};

pub const zx_type_80 = enum { Start, Kind, Name, Open, Value, Member, Separator, Done, };

pub const zx_type_81 = struct {
    count: u64,
    enumeration: bool,
    first: u64,
    name: *const zx_type_46,
    span: *const zx_type_46,
    value: u64,
};

pub const zx_type_82 = struct {
    count: u64,
    depth: u64,
    diagnostic: *const zx_type_58,
    enumeration: bool,
    first: u64,
    index: u64,
    last_end: u64,
    name: *const zx_type_46,
    opening: u64,
    opening_index: u64,
    phase: zx_type_80,
    start: u64,
    token: *const zx_type_47,
    type_diagnostic: bool,
};

pub const zx_type_84 = struct {
    control: *const zx_type_82,
    declarations: []const *const zx_type_81,
    members: []const *const zx_type_46,
    types: *const zx_type_79,
};

pub const zx_type_85 = enum { Named, Object, Optional, List, Tuple, Enumeration, Application, };

pub const zx_type_86 = struct {
    end: u64,
    start: u64,
    text: []const u8,
};

pub const zx_type_87 = struct {
    enumeration: bool,
    index: u64,
};

pub const zx_type_88 = struct {
    child: *const zx_type_87,
    count: u64,
    kind: zx_type_85,
    name: *const zx_type_86,
    position: u64,
};

pub const zx_type_89 = struct {
    name: *const zx_type_86,
    next: u64,
    value: *const zx_type_87,
};

pub const zx_type_90 = struct {
    next: u64,
    value: *const zx_type_87,
};

pub const zx_type_91 = struct {
    name: *const zx_type_86,
    value: *const zx_type_87,
};

pub const zx_type_92 = struct {
    count: u64,
    first: u64,
};

pub const zx_type_99 = struct {
    declarations: []const *const zx_type_91,
    enumerations: []const *const zx_type_92,
    fields: []const *const zx_type_89,
    items: []const *const zx_type_90,
    members: []const *const zx_type_86,
    nodes: []const *const zx_type_88,
};

pub const zx_type_100 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_81,
    members: []const *const zx_type_46,
    order: *const zx_type_71,
    types: *const zx_type_75,
};

pub const zx_type_102 = struct {
    indexed: *const zx_type_100,
    native: ?*const zx_type_99,
};

pub const zx_type_103 = enum { Name, FinishName, Node, Wrap, Tuple, Object, };

pub const zx_type_104 = struct {
    ids: []const u32,
    names: []const []const u8,
};

pub const zx_type_105 = struct {
    aliases: *const zx_type_104,
    base: *const zx_type_50,
    native_interface: bool,
    resolved: *const zx_type_104,
    source: *const zx_type_102,
    visiting: []const []const u8,
};

pub const zx_type_106 = struct {
    children: u64,
    count: u64,
    declaration: *const zx_type_86,
    fields: u64,
    index: u64,
    list: bool,
    name: *const zx_type_86,
    operation: zx_type_103,
    position: u64,
    reference: *const zx_type_87,
    waiting: bool,
};

pub const zx_type_108 = struct {
    active: []const []const u8,
    cache: *const zx_type_104,
    context: *const zx_type_105,
    delta: *const zx_type_50,
    diagnostic: *const zx_type_58,
    frames: []const *const zx_type_106,
    result: u32,
    scratch: *const zx_type_52,
};

pub const zx_type_109 = struct {
    cache: *const zx_type_104,
    context: *const zx_type_105,
    delta: *const zx_type_50,
    initialize: bool,
    name: *const zx_type_86,
    named: bool,
    reference: *const zx_type_87,
};

pub const zx_type_110 = struct {
    cache: *const zx_type_104,
    delta: *const zx_type_50,
    diagnostic: *const zx_type_58,
    id: u32,
};

pub const zx_type_111 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
};

pub const zx_type_112 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
};

pub const zx_type_113 = struct {
    base: *const zx_type_112,
    delta: *const zx_type_112,
};

pub const zx_type_114 = struct {
    cache: *const zx_type_104,
    context: *const zx_type_105,
    delta: *const zx_type_50,
    nominal_delta: *const zx_type_112,
};

pub const zx_type_115 = struct {
    diagnostic: *const zx_type_58,
    input_type: u32,
    output_type: u32,
    span: *const zx_type_46,
    types: *const zx_type_114,
};

pub const zx_type_116 = struct {
    allow_store: bool,
    signature: *const zx_type_115,
    stores: *const zx_type_35,
};

pub const zx_type_117 = enum { Text, Expression, };

pub const zx_type_118 = enum { TemplateOpen, TemplateClose, InterpolationOpen, InterpolationClose, };

pub const zx_type_119 = struct {
    count: u64,
    head: u64,
    span: *const zx_type_46,
};

pub const zx_type_120 = struct {
    interpolation: u64,
    kind: zx_type_117,
    previous: u64,
    span: *const zx_type_46,
};

pub const zx_type_121 = struct {
    kind: zx_type_118,
    offset: u64,
    reference: u64,
};

pub const zx_type_125 = struct {
    events: []const *const zx_type_121,
    lexed: *const zx_type_65,
    parts: []const *const zx_type_120,
    templates: []const *const zx_type_119,
    token_templates: []const u64,
};

pub const zx_type_126 = struct {
    lexed: *const zx_type_65,
    span: *const zx_type_46,
    token_templates: []const u64,
};

pub const zx_type_128 = struct {
    interpolations: []const *const zx_type_126,
    lexed: *const zx_type_65,
    parts: []const *const zx_type_120,
    templates: []const *const zx_type_119,
    token_templates: []const u64,
};

pub const zx_type_129 = enum { None, Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, And, Or, };

pub const zx_type_130 = enum { None, Coalesce, Logical, };

pub const zx_type_131 = struct {
    family: zx_type_130,
    operator: zx_type_129,
    precedence: u8,
};

pub const zx_type_132 = struct {
    binary: *const zx_type_131,
    generic: bool,
    lambda: bool,
};

pub const zx_type_134 = struct {
    after_identifier: bool,
    arrow: bool,
    hints: []const *const zx_type_132,
    parameter_start: bool,
};

pub const zx_type_136 = struct {
    hints: []const *const zx_type_132,
    interpolation_hints: []const []const *const zx_type_132,
    lexical: *const zx_type_128,
};

pub const zx_type_137 = enum { Number, String, Boolean, Null, Identifier, Field, Index, List, Call, Lambda, Template, Unary, Binary, Conditional, Match, Object, StateBlock, Capture, Async, Await, Cancel, };

pub const zx_type_138 = enum { BeginBinary, Primary, Postfix, Returning, FieldName, Arguments, ObjectName, ObjectColon, LambdaParameter, LambdaSeparator, LambdaArrow, LambdaBody, Callback, StateBlock, MatchStart, MatchCondition, MatchFallbackArrow, MatchEnd, GenericType, GenericCall, TemplateGather, TemplatePart, Done, };

pub const zx_type_139 = enum { BinaryLeft, BinaryRight, Unary, Group, Index, Arguments, ObjectValue, OptionsValue, Lambda, ConditionalYes, ConditionalNo, MatchSubject, MatchCondition, MatchResult, MatchFallback, Template, TemplatePart, Interpolation, Capture, Async, Await, Cancel, };

pub const zx_type_140 = struct {
    count: u64,
    depth: u64,
    first: u64,
    flag: bool,
    head: u64,
    kind: zx_type_137,
    name: *const zx_type_46,
    operator: zx_type_129,
    second: u64,
    span: *const zx_type_46,
    third: u64,
    type_argument: u64,
};

pub const zx_type_141 = struct {
    name: *const zx_type_46,
    previous: u64,
    spread: bool,
    value: u64,
};

pub const zx_type_142 = struct {
    name: *const zx_type_46,
    previous: u64,
};

pub const zx_type_143 = struct {
    expression: bool,
    previous: u64,
    span: *const zx_type_46,
    value: u64,
};

pub const zx_type_144 = struct {
    condition: u64,
    previous: u64,
    result: u64,
};

pub const zx_type_150 = struct {
    arms: []const *const zx_type_144,
    fields: []const *const zx_type_141,
    items: []const *const zx_type_70,
    nodes: []const *const zx_type_140,
    parameters: []const *const zx_type_142,
    parts: []const *const zx_type_143,
};

pub const zx_type_151 = struct {
    allow_lambda: bool,
    callback: bool,
    condition: bool,
    count: u64,
    cursor: u64,
    depth: u64,
    end: u64,
    family: zx_type_130,
    first: u64,
    flag: bool,
    head: u64,
    index: u64,
    kind: zx_type_139,
    maximum: u64,
    minimum: u8,
    name: *const zx_type_46,
    operator: zx_type_129,
    reset_family: bool,
    second: u64,
    start: u64,
    stream: u64,
};

pub const zx_type_152 = struct {
    allow_lambda: bool,
    base_depth: u64,
    cursor: u64,
    depth: u64,
    diagnostic: *const zx_type_58,
    family: zx_type_130,
    fresh_family: bool,
    hint: *const zx_type_132,
    index: u64,
    last_end: u64,
    lexical_diagnostic: u64,
    minimum: u8,
    phase: zx_type_138,
    primary_start: u64,
    result: u64,
    root_index: u64,
    stream: u64,
    template: u64,
    template_count: u64,
    template_head: u64,
    template_maximum: u64,
    token: *const zx_type_47,
    type_argument: u64,
    type_diagnostic: bool,
};

pub const zx_type_154 = struct {
    control: *const zx_type_152,
    frames: []const *const zx_type_151,
    prepared: *const zx_type_136,
    tree: *const zx_type_150,
    types: *const zx_type_79,
};

pub const zx_type_155 = enum { Constant, Destructure, Result, Branch, Switch, StoreSet, Evaluate, StateUpdate, };

pub const zx_type_156 = enum { Root, Block, Statement, Case, };

pub const zx_type_157 = enum { BlockOpen, BlockNext, Statement, ConstName, ConstAfterName, PatternName, PatternSeparator, ConstAssign, ReturnValue, IfOpen, IfClose, IfElse, IfAlternative, SwitchOpen, SwitchClose, SwitchBrace, SwitchCase, CaseColon, CaseBody, CaseNext, StoreAssign, UpdateOperator, UpdateAssign, BeginValue, BeginCondition, BeginSwitch, BeginCase, Value, Expression, Type, EndStatement, Publish, Resume, Done, };

pub const zx_type_158 = struct {
    annotation: u64,
    count: u64,
    first: u64,
    head: u64,
    kind: zx_type_155,
    name: *const zx_type_46,
    operator: zx_type_129,
    second: u64,
    span: *const zx_type_46,
    third: u64,
};

pub const zx_type_159 = struct {
    previous: u64,
    span: *const zx_type_46,
};

pub const zx_type_160 = struct {
    body: u64,
    previous: u64,
    span: *const zx_type_46,
    value: u64,
};

pub const zx_type_164 = struct {
    blocks: []const *const zx_type_119,
    cases: []const *const zx_type_160,
    items: []const *const zx_type_70,
    names: []const *const zx_type_159,
    statements: []const *const zx_type_158,
};

pub const zx_type_165 = struct {
    annotation: u64,
    count: u64,
    depth: u64,
    first: u64,
    head: u64,
    kind: zx_type_156,
    name: *const zx_type_46,
    operator: zx_type_129,
    phase: zx_type_157,
    second: u64,
    start: u64,
    statement: zx_type_155,
    third: u64,
};

pub const zx_type_166 = struct {
    diagnostic: *const zx_type_58,
    expression_diagnostic: bool,
    phase: zx_type_157,
    result: u64,
    @"resume": zx_type_157,
    state_block: bool,
};

pub const zx_type_168 = struct {
    control: *const zx_type_166,
    expression: *const zx_type_152,
    expression_frames: []const *const zx_type_151,
    frame: *const zx_type_165,
    frames: []const *const zx_type_165,
};

pub const zx_type_170 = struct {
    control: *const zx_type_166,
    expression: *const zx_type_154,
    frame: *const zx_type_165,
    frames: []const *const zx_type_165,
    suspended: []const *const zx_type_168,
    tree: *const zx_type_164,
};

pub const zx_type_171 = enum { Open, Input, Colon, InputName, ParameterEnd, StoreOpen, StoreName, StoreClose, StoreEnd, Close, ResultColon, ResultName, Contract, ContractOpen, Predicate, ContractClose, Done, };

pub const zx_type_172 = struct {
    ensures: bool,
    predicate: u64,
    span: *const zx_type_46,
};

pub const zx_type_173 = struct {
    contract_start: u64,
    diagnostic: *const zx_type_58,
    ensures: bool,
    expression_diagnostic: bool,
    has_ensures: bool,
    has_store: bool,
    phase: zx_type_171,
    token: *const zx_type_47,
};

pub const zx_type_175 = struct {
    body: *const zx_type_164,
    contracts: []const *const zx_type_172,
    control: *const zx_type_173,
    expression: *const zx_type_154,
};

pub const zx_type_176 = enum { Start, Binding, Name, Separator, From, Path, End, Done, };

pub const zx_type_177 = enum { Function, Enumeration, TypeOnly, };

pub const zx_type_178 = struct {
    count: u64,
    first: u64,
    kind: zx_type_177,
    path: *const zx_type_46,
    span: *const zx_type_46,
};

pub const zx_type_179 = struct {
    count: u64,
    diagnostic: *const zx_type_58,
    first: u64,
    index: u64,
    named: bool,
    opening: *const zx_type_46,
    path: *const zx_type_46,
    phase: zx_type_176,
    start: u64,
    token: *const zx_type_47,
    type_only: bool,
};

pub const zx_type_181 = struct {
    control: *const zx_type_179,
    imports: []const *const zx_type_178,
    names: []const *const zx_type_46,
};

pub const zx_type_183 = struct {
    blocks: *const zx_type_164,
    body: ?u64,
    comments: []const *const zx_type_46,
    contracts: []const *const zx_type_172,
    declarations: []const *const zx_type_81,
    diagnostic: *const zx_type_58,
    expressions: *const zx_type_150,
    function_start: u64,
    has_store: bool,
    import_names: []const *const zx_type_46,
    imports: []const *const zx_type_178,
    members: []const *const zx_type_46,
    tokens: []const *const zx_type_47,
    type_order: *const zx_type_71,
    types: *const zx_type_75,
};

pub const zx_type_184 = struct {
    blocks: *const zx_type_164,
    comments: []const *const zx_type_46,
    diagnostic: *const zx_type_58,
    expressions: *const zx_type_150,
    result: u64,
    tokens: []const *const zx_type_47,
    type_order: *const zx_type_71,
    types: *const zx_type_75,
};

pub const zx_type_185 = struct {
    binding_names: []const []const u8,
    binding_types: []const u32,
    bytes: []const u8,
    expected: ?u32,
    linking: bool,
    maximum_type_count: u64,
    nonnull_bindings: []const []const u8,
    scalar_count: u64,
    syntax: *const zx_type_184,
    type_base: *const zx_type_50,
    unit_bindings: []const []const u8,
};

pub const zx_type_186 = struct {
    control: *const zx_type_22,
    expressions: *const zx_type_34,
    root: ?u32,
    stores: *const zx_type_35,
    symbols: *const zx_type_16,
};

pub const zx_type_187 = struct {
    expressions: *const zx_type_34,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_16,
};

pub const zx_type_188 = struct {
    diagnostic: *const zx_type_58,
    input_type: u32,
    local: *const zx_type_42,
    types: *const zx_type_114,
};

pub const zx_type_189 = struct {
    binding_values: []const u32,
    input_value: u32,
    ownership: zx_type_11,
    root: ?u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_190 = struct {
    body: *const zx_type_186,
    diagnostic: *const zx_type_58,
    input_type: u32,
    output_ownership: zx_type_11,
    output_type: u32,
    type_delta: *const zx_type_50,
};

pub const zx_type_191 = struct {
    maximum_count: u64,
    scalar_count: u64,
    table: *const zx_type_50,
};

pub const zx_type_192 = enum { Value, Callable, TypeDecl, };

pub const zx_type_193 = struct {
    kind: zx_type_192,
    name: []const u8,
};

pub const zx_type_194 = struct {
    left: []const u8,
    right: []const u8,
};

pub const zx_type_195 = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    table: *const zx_type_50,
};

pub const zx_type_196 = struct {
    count: u64,
    errors: bool,
    first: u64,
    values: []const []const u8,
};

pub const zx_type_197 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_50,
};

pub const zx_type_198 = struct {
    scalar_count: u64,
    table: *const zx_type_50,
};

pub const zx_type_199 = struct {
    name: *const zx_type_86,
    operation: zx_type_103,
    reference: *const zx_type_87,
};

pub const zx_type_200 = struct {
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_201 = struct {
    code: []const u8,
    message: []const u8,
    name: *const zx_type_86,
    state: *const zx_type_108,
};

pub const zx_type_202 = struct { []const u8, u64, u64, };

pub const zx_type_203 = struct {
    source: []const u8,
    span: *const zx_type_46,
};

pub const zx_type_204 = struct {
    index: u64,
    source: *const zx_type_102,
};

pub const zx_type_205 = struct {
    limit: u64,
    name: []const u8,
    source: *const zx_type_102,
};

pub const zx_type_206 = struct {
    found: bool,
    index: u64,
};

pub const zx_type_207 = struct {
    index: u64,
    state: *const zx_type_108,
};

pub const zx_type_208 = struct {
    children: []const u32,
    fields: *const zx_type_52,
    first: u32,
    kind: zx_type_48,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_209 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_210 = struct {
    delta: *const zx_type_50,
    id: u32,
};

pub const zx_type_211 = struct {
    children: []const u32,
    count: u64,
    field_names: []const []const u8,
    field_types: []const u32,
    first: u32,
    kind: zx_type_48,
    label: []const u8,
    names: []const []const u8,
    offset: u64,
    second: u32,
};

pub const zx_type_212 = struct {
    left: *const zx_type_211,
    right: *const zx_type_211,
};

pub const zx_type_213 = struct {
    index: u64,
    table: *const zx_type_50,
};

pub const zx_type_214 = struct {
    candidate: *const zx_type_208,
    id: u32,
    tables: *const zx_type_51,
};

pub const zx_type_215 = struct {
    candidate: *const zx_type_208,
    tables: *const zx_type_51,
};

pub const zx_type_216 = struct {
    candidate: *const zx_type_208,
    delta: *const zx_type_50,
};

pub const zx_type_217 = struct {
    code: []const u8,
    message: []const u8,
};

pub const zx_type_218 = struct {
    candidate: *const zx_type_208,
    table: *const zx_type_50,
};

pub const zx_type_219 = struct {
    delta: *const zx_type_50,
    diagnostic: *const zx_type_217,
    id: u32,
};

pub const zx_type_220 = struct {
    id: u32,
    tables: *const zx_type_51,
};

pub const zx_type_221 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: *const zx_type_51,
};

pub const zx_type_222 = struct {
    id: u32,
    native_references: bool,
    tables: *const zx_type_51,
};

pub const zx_type_223 = enum { None, TaskContainer, VoidList, TaskTuple, TaskObject, };

pub const zx_type_224 = struct {
    candidate: *const zx_type_208,
    state: *const zx_type_108,
};

pub const zx_type_225 = struct {
    enumeration: u64,
    index: u64,
    source: *const zx_type_102,
};

pub const zx_type_226 = struct {
    reference: *const zx_type_87,
    source: *const zx_type_102,
};

pub const zx_type_227 = struct {
    cache: *const zx_type_104,
    name: []const u8,
};

pub const zx_type_228 = struct {
    frame: *const zx_type_106,
    state: *const zx_type_108,
};

pub const zx_type_229 = struct {
    position: u64,
    source: *const zx_type_102,
};

pub const zx_type_230 = struct {
    analysis: *const zx_type_189,
    binding_types: []const u32,
    expected: ?u32,
};

pub const zx_type_231 = struct {
    candidate: *const zx_type_208,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_232 = struct {
    id: u32,
    state: *const zx_type_188,
};

pub const zx_type_233 = struct {
    analysis: *const zx_type_189,
    types: []const u32,
};

pub const zx_type_234 = struct {
    name: []const u8,
    ownership: zx_type_11,
    span_end: u64,
    span_start: u64,
    table: *const zx_type_16,
    type_id: u32,
};

pub const zx_type_235 = struct {
    id: u32,
    table: *const zx_type_16,
};

pub const zx_type_236 = struct {
    span_end: u64,
    span_start: u64,
    type_id: u32,
};

pub const zx_type_237 = struct {
    id: u32,
    table: *const zx_type_34,
};

pub const zx_type_238 = enum { Some, Capture, AwaitTask, CancelTask, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Length, };

pub const zx_type_239 = enum { List, Tuple, Template, };

pub const zx_type_240 = struct {
    kind: zx_type_23,
    metadata: *const zx_type_236,
    payload: u32,
    table: *const zx_type_34,
};

pub const zx_type_241 = struct {
    kind: zx_type_238,
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    value: u32,
};

pub const zx_type_242 = struct {
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_243 = struct {
    span: *const zx_type_46,
    state: *const zx_type_188,
    symbol: u32,
};

pub const zx_type_244 = struct {
    byte: u8,
    state: u64,
};

pub const zx_type_245 = struct {
    local: *const zx_type_42,
    name: []const u8,
    span: *const zx_type_46,
};

pub const zx_type_246 = struct {
    analysis: *const zx_type_189,
    names: []const []const u8,
};

pub const zx_type_247 = struct {
    index: u32,
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    target: u32,
    tuple: bool,
};

pub const zx_type_248 = struct {
    analysis: *const zx_type_189,
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_249 = struct {
    facts: *const zx_type_36,
    symbol: u32,
};

pub const zx_type_250 = struct {
    analysis: *const zx_type_189,
    bindings: []const []const u8,
    names: []const []const u8,
};

pub const zx_type_251 = enum { Requires, Ensures, };

pub const zx_type_255 = struct {
    expressions: []const *const zx_type_34,
    kinds: []const zx_type_251,
    predicates: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    symbols: []const *const zx_type_16,
};

pub const zx_type_263 = struct {
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_11,
};

pub const zx_type_267 = struct {
    contracts: []const *const zx_type_255,
    control: []const *const zx_type_22,
    expressions: []const *const zx_type_34,
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_fallible: []const bool,
    native_modules: []const ?u32,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_11,
    roots: []const ?u32,
    stores: []const *const zx_type_35,
};

pub const zx_type_268 = struct {
    ids: []const u32,
    input_types: []const u32,
    names: []const []const u8,
    namespaces: []const ?[]const u8,
    output_types: []const u32,
};

pub const zx_type_269 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    type_ids: []const ?u32,
    type_names: []const ?[]const u8,
    writable: []const bool,
};

pub const zx_type_270 = struct {
    aliases: *const zx_type_104,
    function_imports: *const zx_type_268,
    functions: *const zx_type_267,
    nominal_base: *const zx_type_112,
    nominal_origin: *const zx_type_111,
    shared: bool,
    store_bindings: *const zx_type_269,
    store_type_count: u64,
    type_base: *const zx_type_50,
};

pub const zx_type_271 = struct {
    bytes: []const u8,
    context: *const zx_type_270,
    file_name: []const u8,
    syntax: *const zx_type_183,
};

pub const zx_type_272 = struct {
    blocks: *const zx_type_164,
    bytes: []const u8,
    tree: *const zx_type_150,
};

pub const zx_type_273 = struct {
    expected: ?u32,
    node: u64,
    source: *const zx_type_272,
    state: *const zx_type_188,
};

pub const zx_type_274 = struct {
    analysis: *const zx_type_189,
    input: *const zx_type_185,
};

pub const zx_type_275 = struct {
    functions: *const zx_type_267,
    imports: *const zx_type_268,
    request: *const zx_type_273,
};

pub const zx_type_276 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_34,
    limit: u64,
};

pub const zx_type_277 = struct {
    expressions: []const *const zx_type_34,
    native_concurrent: []const bool,
    native_modules: []const ?u32,
    stores: []const *const zx_type_35,
};

pub const zx_type_278 = struct {
    concurrent: bool,
    functions: *const zx_type_277,
};

pub const zx_type_279 = struct {
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
};

pub const zx_type_280 = struct {
    body: u32,
    captures: *const zx_type_279,
    parameters: []const u32,
};

pub const zx_type_281 = struct {
    borrows: []const bool,
    symbols: []const ?u32,
    values: []const u32,
};

pub const zx_type_282 = struct {
    callback: *const zx_type_280,
    ignored: ?u32,
    initial: ?u32,
    kind: zx_type_25,
    result_type: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
    target: u32,
};

pub const zx_type_283 = struct {
    arguments: []const u64,
    capture_frame: u32,
    expected: ?u32,
    kind: zx_type_25,
    node: u64,
    parameters: []const u32,
    result_type: u32,
    second: ?u32,
    target: u32,
};

pub const zx_type_284 = struct {
    active: u64,
    captures: ?u32,
    depth: u64,
    floor: u64,
};

pub const zx_type_285 = struct {
    condition: u32,
    condition_node: u64,
    condition_parameter: u32,
    context: *const zx_type_284,
    initial: u32,
    initial_node: u64,
    node: u64,
    parameter: u32,
    postcondition: bool,
    step_node: u64,
};

pub const zx_type_286 = struct {
    expression: u32,
    read_value: bool,
};

pub const zx_type_287 = struct {
    index: u32,
    kind: zx_type_23,
    value: u32,
};

pub const zx_type_289 = struct {
    places: []const *const zx_type_287,
    statement: u64,
    target: u32,
};

pub const zx_type_290 = struct {
    condition: u32,
    mark: *const zx_type_37,
    state_symbol: u32,
    statement: u64,
    yes: u32,
};

pub const zx_type_291 = struct {
    cases: []const u64,
    conditions: []const u32,
    fallback: ?u32,
    index: u64,
    results: []const u32,
    state_symbol: u32,
    statement: u64,
    subject: u32,
};

pub const zx_type_292 = struct {
    active_mark: u64,
    binding_mark: u64,
    facts_mark: *const zx_type_37,
    next: u64,
    source_block: u64,
    state_symbol: u32,
    statements: []const u64,
};

pub const zx_type_294 = struct {
    bindings: *const zx_type_281,
    frames: []const *const zx_type_292,
};

pub const zx_type_295 = struct {
    names: []const []const u8,
    values: []const u32,
};

pub const zx_type_296 = enum { Evaluate, Complete, StateBlock, ScopeNext, StateSwitch, Done, };

pub const zx_type_297 = enum { Coerce, Unary, Field, IndexTarget, IndexValue, BinaryLeft, BinaryRight, Condition, Yes, No, MatchSubject, MatchCondition, MatchResult, MatchFallback, Sequence, Object, Imported, MethodTarget, ListArgument, Template, TaskValue, CaptureValue, AsyncBody, ParallelBody, TransformSecond, TransformBody, IterationInitial, IterationCondition, IterationStep, StateEvaluate, StateConstant, StateDestructure, StateTarget, StateValue, StateCondition, StateYes, StateNo, StateSubject, StateLabel, StateCase, };

pub const zx_type_298 = struct {
    expected: u32,
    span: *const zx_type_46,
};

pub const zx_type_299 = struct {
    node: u64,
    target: u32,
};

pub const zx_type_300 = struct {
    left: u32,
    mark: *const zx_type_37,
    node: u64,
};

pub const zx_type_301 = struct {
    condition: u32,
    expected: ?u32,
    mark: *const zx_type_37,
    node: u64,
    yes: u32,
};

pub const zx_type_302 = struct {
    arms: []const u64,
    conditions: []const u32,
    expected: ?u32,
    index: u64,
    node: u64,
    results: []const u32,
    subject: ?u32,
};

pub const zx_type_303 = struct {
    element: ?u32,
    index: u64,
    items: []const u64,
    node: u64,
    tuple: ?u32,
    values: []const u32,
};

pub const zx_type_304 = struct {
    entries: *const zx_type_295,
    evaluation: []const u32,
    fields: []const u64,
    hint: ?u32,
    index: u64,
    node: u64,
};

pub const zx_type_305 = struct {
    arguments: []const u64,
    import_index: u64,
    index: u64,
    node: u64,
    tuple: bool,
    values: []const u32,
};

pub const zx_type_306 = struct {
    expected: ?u32,
    node: u64,
    target: u32,
};

pub const zx_type_307 = struct {
    arguments: []const u64,
    hints: []const u32,
    index: u64,
    kind: zx_type_24,
    node: u64,
    replacement: bool,
    target: u32,
    values: []const u32,
};

pub const zx_type_308 = struct {
    index: u64,
    node: u64,
    parts: []const u64,
    values: []const u32,
};

pub const zx_type_309 = struct {
    active: u64,
    captures: ?u32,
    depth: u64,
    facts: *const zx_type_37,
    floor: u64,
};

pub const zx_type_310 = struct {
    first: u64,
    node: u64,
    symbol_count: u64,
};

pub const zx_type_311 = struct {
    fields: []const u64,
    first: u64,
    index: u64,
    names: []const []const u8,
    node: u64,
    symbol_count: u64,
    tasks: []const u32,
    type_names: []const []const u8,
    types: []const u32,
};

pub const zx_type_331 = struct {
    actions: []const zx_type_297,
    asynchronous: []const *const zx_type_310,
    binaries: []const *const zx_type_300,
    branches: []const *const zx_type_290,
    coercions: []const *const zx_type_298,
    conditionals: []const *const zx_type_301,
    imported: []const *const zx_type_305,
    indices: []const *const zx_type_299,
    iterations: []const *const zx_type_285,
    lists: []const *const zx_type_307,
    methods: []const *const zx_type_306,
    objects: []const *const zx_type_304,
    parallels: []const *const zx_type_311,
    selections: []const *const zx_type_302,
    sequences: []const *const zx_type_303,
    singles: []const u64,
    statements: []const u64,
    switches: []const *const zx_type_291,
    templates: []const *const zx_type_308,
    transforms: []const *const zx_type_283,
    updates: []const *const zx_type_289,
};

pub const zx_type_332 = struct {
    boundary: *const zx_type_309,
    concurrent: []const bool,
    expected: ?u32,
    frames: *const zx_type_331,
    functions: *const zx_type_267,
    imports: *const zx_type_268,
    node: u64,
    phase: zx_type_296,
    scopes: *const zx_type_294,
    source: *const zx_type_272,
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_333 = struct {
    expected: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_334 = struct {
    body: u32,
    captures: []const u32,
    metadata: *const zx_type_236,
    table: *const zx_type_34,
};

pub const zx_type_335 = struct {
    count: u64,
    slots: []const u64,
};

pub const zx_type_336 = enum { Expression, Function, Block, };

pub const zx_type_337 = struct {
    count: u64,
    index: u64,
    operation: zx_type_336,
    source: u64,
};

pub const zx_type_338 = struct {
    control: *const zx_type_22,
    expressions: *const zx_type_34,
    returns: []const bool,
    visited: *const zx_type_335,
};

pub const zx_type_339 = struct {
    functions: *const zx_type_267,
    types: *const zx_type_51,
};

pub const zx_type_342 = struct {
    called: *const zx_type_335,
    context: *const zx_type_339,
    frames: []const *const zx_type_337,
    names: []const []const u8,
    sources: []const *const zx_type_338,
    unknown: bool,
};

pub const zx_type_343 = struct {
    context: *const zx_type_339,
    contracts: *const zx_type_255,
    control: *const zx_type_22,
    expression: u32,
    expressions: *const zx_type_34,
    program: bool,
    root: ?u32,
    stores: bool,
};

pub const zx_type_344 = struct {
    control: *const zx_type_22,
    returns: []const bool,
    selection: u64,
};

pub const zx_type_345 = struct {
    control: *const zx_type_22,
    expressions: *const zx_type_34,
    state: *const zx_type_342,
};

pub const zx_type_346 = struct {
    source: u64,
    state: *const zx_type_342,
};

pub const zx_type_347 = struct {
    contracts: *const zx_type_255,
    state: *const zx_type_342,
};

pub const zx_type_348 = struct {
    frame: *const zx_type_337,
    state: *const zx_type_342,
};

pub const zx_type_349 = struct {
    id: u32,
    seen: *const zx_type_335,
};

pub const zx_type_350 = struct {
    fresh: bool,
    seen: *const zx_type_335,
};

pub const zx_type_351 = struct {
    expressions: *const zx_type_34,
    index: u64,
};

pub const zx_type_352 = struct {
    names: []const []const u8,
    tables: *const zx_type_51,
    type_id: u32,
};

pub const zx_type_353 = struct {
    expressions: *const zx_type_34,
    index: u64,
    names: []const []const u8,
    tables: *const zx_type_51,
};

pub const zx_type_354 = struct {
    index: u64,
    state: *const zx_type_342,
};

pub const zx_type_355 = struct {
    functions: *const zx_type_267,
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_356 = struct {
    concurrent: []const bool,
    first: u64,
    span: *const zx_type_46,
    state: *const zx_type_188,
    symbol_count: u64,
};

pub const zx_type_357 = struct {
    captures: []const u32,
    state: *const zx_type_188,
};

pub const zx_type_358 = struct {
    body: u32,
    concurrent: []const bool,
    first: u64,
    functions: *const zx_type_267,
    span: *const zx_type_46,
    state: *const zx_type_188,
    symbol_count: u64,
};

pub const zx_type_359 = struct {
    facts: *const zx_type_36,
    mark: *const zx_type_37,
};

pub const zx_type_360 = struct {
    left: u32,
    metadata: *const zx_type_236,
    operator: zx_type_27,
    right: u32,
    table: *const zx_type_34,
};

pub const zx_type_361 = struct {
    comparison: bool,
    equality: bool,
    logical: bool,
};

pub const zx_type_362 = struct {
    tables: *const zx_type_51,
    type_id: u32,
};

pub const zx_type_363 = struct {
    left: u32,
    operator: zx_type_27,
    right: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_364 = struct {
    expressions: *const zx_type_34,
    facts: *const zx_type_36,
    payload: u64,
    truth: bool,
};

pub const zx_type_365 = struct {
    condition: u64,
    expressions: *const zx_type_34,
    state: *const zx_type_38,
    truth: bool,
};

pub const zx_type_366 = struct {
    left: u32,
    operator: zx_type_27,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_367 = struct {
    expected: u32,
    state: *const zx_type_188,
};

pub const zx_type_368 = struct {
    action: zx_type_297,
    work: *const zx_type_332,
};

pub const zx_type_369 = struct {
    count: u64,
    element: u32,
    list: u32,
    name: []const u8,
};

pub const zx_type_370 = struct {
    code: []const u8,
    hints: []const u32,
    kind: zx_type_24,
    message: []const u8,
    replacement: bool,
};

pub const zx_type_371 = struct {
    head: u64,
    items: []const *const zx_type_70,
};

pub const zx_type_372 = struct {
    arguments: []const u32,
    kind: zx_type_24,
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    target: u32,
};

pub const zx_type_373 = struct {
    index: u32,
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    target: u32,
    value: u32,
};

pub const zx_type_374 = struct {
    kind: zx_type_24,
    replacement: bool,
    span: *const zx_type_46,
    state: *const zx_type_188,
    target: u32,
    values: []const u32,
};

pub const zx_type_375 = struct {
    expected: ?u32,
    types: *const zx_type_114,
};

pub const zx_type_376 = struct {
    local: *const zx_type_42,
    name: *const zx_type_86,
    scope_start: u64,
    type_id: u32,
};

pub const zx_type_377 = struct {
    diagnostic: *const zx_type_58,
    id: u32,
    local: *const zx_type_42,
};

pub const zx_type_378 = struct {
    frame: u32,
    local: *const zx_type_42,
};

pub const zx_type_379 = struct {
    node: u64,
    source: *const zx_type_272,
    state: *const zx_type_188,
    types: []const u32,
};

pub const zx_type_380 = struct {
    body: u64,
    frame: u32,
    parameters: []const u32,
    state: *const zx_type_188,
};

pub const zx_type_381 = struct {
    expected: ?u32,
    kind: zx_type_25,
    second: ?u32,
    state: *const zx_type_188,
    target: u32,
};

pub const zx_type_382 = struct {
    body: ?u32,
    parameters: []const u32,
    result: u32,
};

pub const zx_type_383 = struct {
    name: []const u8,
    work: *const zx_type_332,
};

pub const zx_type_384 = struct {
    condition: u32,
    metadata: *const zx_type_236,
    no: u32,
    table: *const zx_type_34,
    yes: u32,
};

pub const zx_type_385 = struct {
    facts: *const zx_type_36,
    symbol: u32,
    tables: *const zx_type_51,
    type_id: u32,
};

pub const zx_type_386 = struct {
    local: *const zx_type_42,
    name: []const u8,
};

pub const zx_type_387 = struct {
    node: u64,
    path: []const u8,
    source: *const zx_type_272,
};

pub const zx_type_388 = struct {
    local: *const zx_type_42,
    node: u64,
    source: *const zx_type_272,
};

pub const zx_type_389 = struct {
    symbol: ?u32,
    unit: bool,
};

pub const zx_type_390 = enum { Probe, Fallback, Field, Index, Task, Optional, MatchLiteral, };

pub const zx_type_391 = struct {
    node: u64,
    operation: zx_type_390,
};

pub const zx_type_392 = struct {
    imports: *const zx_type_268,
    source: *const zx_type_272,
    state: *const zx_type_188,
};

pub const zx_type_394 = struct {
    context: *const zx_type_392,
    frames: []const *const zx_type_391,
    result: ?u32,
};

pub const zx_type_395 = struct {
    callee: u64,
    context: *const zx_type_392,
};

pub const zx_type_396 = struct {
    context: *const zx_type_392,
    node: u64,
};

pub const zx_type_397 = struct {
    handled: bool,
    type_id: ?u32,
};

pub const zx_type_398 = struct {
    node: u64,
    work: *const zx_type_394,
};

pub const zx_type_399 = struct {
    floating: bool,
    separators: bool,
};

pub const zx_type_400 = struct {
    left: u64,
    right: u64,
    source: *const zx_type_272,
};

pub const zx_type_401 = struct {
    node: u64,
    source: *const zx_type_272,
};

pub const zx_type_402 = struct {
    context: *const zx_type_392,
    frame: *const zx_type_391,
    type_id: u32,
};

pub const zx_type_403 = struct {
    context: *const zx_type_392,
    expected: ?u32,
    node: u64,
};

pub const zx_type_404 = struct {
    argument: u32,
    function_id: u32,
    metadata: *const zx_type_236,
    stores: []const u32,
    table: *const zx_type_34,
};

pub const zx_type_405 = struct {
    metadata: *const zx_type_236,
    optional: bool,
    table: *const zx_type_34,
};

pub const zx_type_406 = struct {
    kind: zx_type_239,
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    values: []const u32,
};

pub const zx_type_407 = struct {
    body: u32,
    condition: u32,
    condition_parameter: u32,
    initial: u32,
    metadata: *const zx_type_236,
    parameter: u32,
    postcondition: bool,
    table: *const zx_type_34,
};

pub const zx_type_408 = struct {
    node: u64,
    source: *const zx_type_272,
    state: *const zx_type_188,
    type_id: u32,
    updating: bool,
};

pub const zx_type_409 = struct {
    body: u64,
    context: *const zx_type_284,
    parameter: u32,
    state: *const zx_type_188,
};

pub const zx_type_410 = struct {
    context: *const zx_type_284,
    local: *const zx_type_42,
};

pub const zx_type_411 = struct {
    conditions: []const u32,
    fallback: u32,
    metadata: *const zx_type_236,
    results: []const u32,
    subject: ?u32,
    table: *const zx_type_34,
};

pub const zx_type_412 = struct {
    entries: *const zx_type_295,
    name: []const u8,
    value: u32,
};

pub const zx_type_413 = struct {
    entries: *const zx_type_295,
    span: *const zx_type_46,
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_414 = struct {
    entries: *const zx_type_295,
    state: *const zx_type_188,
};

pub const zx_type_415 = struct {
    evaluation: []const u32,
    indices: []const u32,
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    values: []const u32,
};

pub const zx_type_416 = struct {
    entries: *const zx_type_295,
    evaluation: []const u32,
    hint: ?u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_417 = struct {
    entries: *const zx_type_295,
    evaluation: []const u32,
    state: *const zx_type_188,
};

pub const zx_type_418 = struct {
    fields: []const ?u32,
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    tasks: []const u32,
};

pub const zx_type_419 = struct {
    functions: *const zx_type_267,
    operand: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_420 = struct {
    metadata: *const zx_type_236,
    operand: u32,
    operator: zx_type_26,
    table: *const zx_type_34,
};

pub const zx_type_421 = struct {
    negative: bool,
    operand: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_422 = struct {
    name: *const zx_type_86,
    span: *const zx_type_46,
    state: *const zx_type_188,
    target: u32,
};

pub const zx_type_423 = struct {
    index: u32,
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    target: u32,
};

pub const zx_type_424 = struct {
    index: u32,
    index_span: *const zx_type_46,
    span: *const zx_type_46,
    state: *const zx_type_188,
    target: u32,
};

pub const zx_type_425 = struct {
    span: *const zx_type_46,
    state: *const zx_type_188,
    target: u32,
};

pub const zx_type_426 = struct {
    cancellation: bool,
    operand: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_427 = struct {
    local: *const zx_type_42,
    name: *const zx_type_86,
    scope_start: u64,
    scopes: *const zx_type_294,
    value: u32,
};

pub const zx_type_428 = struct {
    diagnostic: *const zx_type_58,
    local: *const zx_type_42,
    scopes: *const zx_type_294,
    symbol: u32,
};

pub const zx_type_429 = struct {
    err: u32,
    facts: *const zx_type_36,
    result: u32,
};

pub const zx_type_430 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_34,
    facts: *const zx_type_36,
    result: ?u32,
    value: u64,
};

pub const zx_type_431 = struct {
    local: *const zx_type_42,
    name: *const zx_type_86,
    scopes: *const zx_type_294,
};

pub const zx_type_432 = struct {
    local: *const zx_type_42,
    scopes: *const zx_type_294,
    value: u32,
};

pub const zx_type_433 = struct {
    diagnostic: *const zx_type_58,
    local: *const zx_type_42,
    scopes: *const zx_type_294,
    value: u32,
};

pub const zx_type_434 = struct {
    scopes: *const zx_type_294,
    source: *const zx_type_272,
    state: *const zx_type_188,
    statement: u64,
    value: u32,
};

pub const zx_type_435 = struct {
    scopes: *const zx_type_294,
    state: *const zx_type_188,
};

pub const zx_type_436 = struct {
    scopes: *const zx_type_294,
    value: u32,
};

pub const zx_type_437 = struct {
    local: *const zx_type_42,
    scopes: *const zx_type_294,
    span: *const zx_type_46,
    value: u32,
};

pub const zx_type_438 = struct {
    diagnostic: *const zx_type_58,
    local: *const zx_type_42,
    scopes: *const zx_type_294,
};

pub const zx_type_439 = struct {
    count: u64,
    head: u64,
    items: []const *const zx_type_70,
};

pub const zx_type_440 = struct {
    block: u64,
    local: *const zx_type_42,
    scopes: *const zx_type_294,
    state_symbol: u32,
    tree: *const zx_type_164,
};

pub const zx_type_441 = struct {
    expressions: *const zx_type_34,
    left: u64,
    right: u64,
};

pub const zx_type_442 = struct {
    previous: []const u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_443 = struct {
    read_value: bool,
    state: *const zx_type_188,
    state_symbol: u32,
    target: u32,
};

pub const zx_type_445 = struct {
    diagnostic: *const zx_type_58,
    frames: []const *const zx_type_286,
};

pub const zx_type_446 = struct {
    read_value: bool,
    scopes: *const zx_type_294,
    state: *const zx_type_188,
    state_symbol: u32,
    target: u32,
};

pub const zx_type_447 = struct {
    places: []const *const zx_type_287,
    scopes: *const zx_type_294,
    state: *const zx_type_188,
};

pub const zx_type_448 = struct {
    parent: u32,
    selected: u32,
    state: *const zx_type_188,
    tuple: bool,
    value: u32,
};

pub const zx_type_449 = struct {
    places: []const *const zx_type_287,
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_450 = struct {
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    value: []const u8,
};

pub const zx_type_451 = struct {
    source: []const u8,
    template: bool,
};

pub const zx_type_452 = struct {
    source: []const u8,
    span: *const zx_type_46,
    state: *const zx_type_188,
    template: bool,
};

pub const zx_type_453 = struct {
    name: []const u8,
    ownership: zx_type_11,
    span: *const zx_type_46,
    state: *const zx_type_188,
    type_id: u32,
};

pub const zx_type_454 = struct {
    state: *const zx_type_188,
    symbol: u32,
};

pub const zx_type_455 = struct {
    bindings: *const zx_type_281,
    source: u32,
    state: *const zx_type_188,
};

pub const zx_type_456 = struct {
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    value: bool,
};

pub const zx_type_457 = struct {
    span: *const zx_type_46,
    state: *const zx_type_188,
    value: bool,
};

pub const zx_type_458 = struct {
    metadata: *const zx_type_236,
    negative: bool,
    table: *const zx_type_34,
    value: u64,
};

pub const zx_type_459 = struct {
    span: *const zx_type_46,
    state: *const zx_type_188,
    value: u64,
};

pub const zx_type_460 = struct {
    initial: ?u32,
    kind: zx_type_25,
    result_type: u32,
    source: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_461 = struct {
    fields: *const zx_type_295,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_462 = struct {
    span: *const zx_type_46,
    state: *const zx_type_188,
    values: []const u32,
};

pub const zx_type_463 = struct {
    captures: []const u32,
    initial: ?u32,
    kind: zx_type_25,
    result: u32,
    source: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_464 = struct {
    initial: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_465 = struct {
    condition_parameter: u32,
    parameter: u32,
    state: *const zx_type_188,
};

pub const zx_type_466 = struct {
    kind: zx_type_25,
    parameter: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_467 = struct {
    callback: *const zx_type_280,
    kind: zx_type_25,
    parameter: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_468 = struct {
    bindings: *const zx_type_281,
    current: u32,
    index: u32,
    item: u32,
    previous: u32,
    source: u32,
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_469 = struct {
    span: *const zx_type_46,
    state: *const zx_type_188,
    target: u32,
    value: u32,
};

pub const zx_type_470 = struct {
    item: u32,
    kind: zx_type_25,
    previous: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_471 = struct {
    captures: bool,
    current: u32,
    index: u32,
    result: u32,
    source: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_472 = struct {
    borrows: []const bool,
    metadata: *const zx_type_236,
    result: u32,
    symbols: []const ?u32,
    table: *const zx_type_34,
    values: []const u32,
};

pub const zx_type_473 = struct {
    bindings: *const zx_type_281,
    current: u32,
    result: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_474 = struct {
    bindings: *const zx_type_281,
    body: u32,
    condition: u32,
    condition_parameter: u32,
    initial: u32,
    parameter: u32,
    result_type: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_475 = struct {
    captures: *const zx_type_41,
    frame: u32,
};

pub const zx_type_476 = struct {
    body: u32,
    frame: u32,
    kind: zx_type_25,
    parameters: []const u32,
    result_type: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_477 = struct {
    callback: *const zx_type_280,
    result_type: u32,
    state: *const zx_type_188,
};

pub const zx_type_478 = struct {
    captures: *const zx_type_41,
    frame: u32,
    source: u32,
    target: u32,
    value: u32,
};

pub const zx_type_479 = struct {
    captures: *const zx_type_41,
    frame: u32,
    source: u32,
};

pub const zx_type_480 = struct {
    frame: u32,
    source: u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_481 = struct {
    frame: u32,
    local: *const zx_type_42,
    name: []const u8,
};

pub const zx_type_482 = struct {
    name: *const zx_type_86,
    state: *const zx_type_188,
};

pub const zx_type_483 = struct {
    state: *const zx_type_188,
    symbol: ?u32,
};

pub const zx_type_484 = struct {
    expected: ?u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_485 = struct {
    metadata: *const zx_type_236,
    table: *const zx_type_34,
    value: f64,
};

pub const zx_type_486 = struct {
    digit: u64,
    limbs: []const u64,
};

pub const zx_type_487 = struct {
    limbs: []const u64,
    overflow: bool,
};

pub const zx_type_488 = struct {
    significant: u64,
    trailing: u64,
};

pub const zx_type_489 = struct {
    bytes: []const u8,
    precision: u64,
};

pub const zx_type_492 = struct {
    bytes: []const u8,
    negative: bool,
    single: bool,
};

pub const zx_type_493 = struct {
    message: []const u8,
    value: f64,
};

pub const zx_type_494 = struct {
    id: u32,
    negative: bool,
};

pub const zx_type_495 = struct {
    floating: bool,
    id: u32,
    integer: bool,
    signed: bool,
};

pub const zx_type_496 = struct {
    floating: f64,
    integer: u64,
    message: []const u8,
    target: *const zx_type_495,
};

pub const zx_type_497 = struct {
    expected: ?u32,
    floating: bool,
    negative: bool,
};

pub const zx_type_498 = struct {
    expected: ?u32,
    negative: bool,
    source: []const u8,
};

pub const zx_type_499 = struct {
    expected: ?u32,
    negative: bool,
    source: []const u8,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_500 = struct {
    node: u64,
    source: *const zx_type_272,
    state: *const zx_type_188,
};

pub const zx_type_501 = struct {
    slot: u32,
    state: *const zx_type_188,
};

pub const zx_type_502 = struct {
    name: []const u8,
    types: *const zx_type_114,
};

pub const zx_type_503 = struct {
    error_member: bool,
    name: *const zx_type_86,
    span: *const zx_type_46,
    state: *const zx_type_188,
    type_id: u32,
};

pub const zx_type_504 = struct {
    handled: bool,
    result: *const zx_type_242,
};

pub const zx_type_505 = struct {
    found: bool,
    state: *const zx_type_188,
};

pub const zx_type_506 = struct {
    imports: *const zx_type_268,
    name: []const u8,
    namespace: ?[]const u8,
};

pub const zx_type_507 = struct {
    found: bool,
    index: u64,
    known_namespace: bool,
};

pub const zx_type_508 = enum { Imported, Method, Loop, Parallel, Failed, };

pub const zx_type_509 = struct {
    index: u64,
    route: zx_type_508,
    state: *const zx_type_188,
};

pub const zx_type_510 = struct {
    imports: *const zx_type_268,
    name: *const zx_type_86,
    state: *const zx_type_188,
};

pub const zx_type_511 = struct {
    imports: *const zx_type_268,
    node: u64,
    source: *const zx_type_272,
    state: *const zx_type_188,
};

pub const zx_type_512 = struct {
    index: u64,
    work: *const zx_type_332,
};

pub const zx_type_513 = struct {
    condition: u64,
    diagnostic: *const zx_type_58,
    initial: u64,
    postcondition: bool,
    step: u64,
};

pub const zx_type_514 = struct {
    local: *const zx_type_42,
    scopes: *const zx_type_294,
    span: *const zx_type_46,
};

pub const zx_type_515 = struct {
    reference: u64,
    state: *const zx_type_188,
};

pub const zx_type_516 = struct {
    first: u64,
    table: *const zx_type_22,
};

pub const zx_type_517 = struct {
    id: u32,
    table: *const zx_type_22,
};

pub const zx_type_518 = struct {
    kind: zx_type_17,
    payload: u32,
    table: *const zx_type_22,
};

pub const zx_type_519 = struct {
    symbol: u32,
    table: *const zx_type_22,
    value: u32,
};

pub const zx_type_520 = struct {
    table: *const zx_type_22,
    value: ?u32,
};

pub const zx_type_521 = struct {
    ownership: []const zx_type_11,
    stores: []const *const zx_type_35,
};

pub const zx_type_522 = struct {
    body: ?u32,
    control: *const zx_type_22,
    expressions: *const zx_type_34,
    functions: *const zx_type_521,
    symbols: *const zx_type_16,
    type_only: bool,
    types: *const zx_type_51,
};

pub const zx_type_523 = struct {
    id: u64,
    types: *const zx_type_51,
};

pub const zx_type_524 = struct {
    expression: u64,
    expressions: *const zx_type_34,
    index: u64,
};

pub const zx_type_525 = struct {
    expression: u64,
    found: bool,
};

pub const zx_type_526 = struct {
    expression: u64,
    expressions: *const zx_type_34,
    locals: []const bool,
};

pub const zx_type_527 = struct {
    expression: u64,
    program: *const zx_type_522,
};

pub const zx_type_528 = struct {
    count: []const u64,
    first: []const u64,
    symbols: []const u64,
};

pub const zx_type_529 = enum { Copy, Borrowed, Owned, Loaned, Moved, };

pub const zx_type_530 = enum { Assign, Borrow, Freeze, };

pub const zx_type_531 = struct {
    children: []const u64,
    field_indices: []const u64,
    parents: []const u64,
    references: []const bool,
    siblings: []const u64,
    types: []const u32,
};

pub const zx_type_533 = struct {
    id: u64,
    layout: *const zx_type_531,
    operation: zx_type_530,
    states: []const zx_type_529,
    value: zx_type_529,
};

pub const zx_type_534 = struct {
    count: []const u64,
    first: []const u64,
    positions: []const u64,
};

pub const zx_type_535 = struct {
    cached: *const zx_type_534,
    heads: []const u64,
    next: []const u64,
    tree: *const zx_type_531,
};

pub const zx_type_536 = struct {
    cached: *const zx_type_534,
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    tree: *const zx_type_531,
    values: []const u64,
};

pub const zx_type_537 = enum { Heads, Symbols, Expressions, Evaluation, };

pub const zx_type_538 = struct {
    program: *const zx_type_522,
    references: []const bool,
};

pub const zx_type_539 = struct {
    capacity: u64,
    field: u64,
    parent: u64,
};

pub const zx_type_540 = struct {
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_541 = struct {
    field: u64,
    parent: u64,
};

pub const zx_type_542 = struct {
    found: bool,
    slot: u64,
    value: u64,
};

pub const zx_type_543 = struct {
    index: *const zx_type_540,
    key: *const zx_type_541,
};

pub const zx_type_544 = struct {
    expressions: *const zx_type_34,
    id: u64,
};

pub const zx_type_545 = struct {
    index: u32,
    target: u64,
};

pub const zx_type_546 = enum { Expression, AncestorStart, Ancestor, Root, Path, Ensure, Grow, Clear, Rehash, };

pub const zx_type_547 = struct {
    active: bool,
    ancestor: u64,
    bindings: []const u64,
    cached: *const zx_type_534,
    capacity: u64,
    child_expression: u64,
    children: []const u64,
    cursor: u64,
    direct: bool,
    expression: u64,
    field_indices: []const u64,
    heads: []const u64,
    key_fields: []const u64,
    key_parents: []const u64,
    next: []const u64,
    parent: u64,
    parents: []const u64,
    path: []const u64,
    path_index: u64,
    phase: zx_type_546,
    place_types: []const u32,
    program: *const zx_type_522,
    record: u64,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_548 = struct {
    first: u64,
    slots: []const u64,
};

pub const zx_type_549 = struct {
    program: *const zx_type_522,
    references: []const bool,
    roots: *const zx_type_535,
};

pub const zx_type_550 = struct {
    children: []const u64,
    count: []const u64,
    first: []const u64,
    shells: []const zx_type_529,
    states: []const zx_type_529,
    types: []const u32,
};

pub const zx_type_551 = struct {
    fact: u64,
    forest: *const zx_type_550,
};

pub const zx_type_552 = struct {
    fact: u64,
    forest: *const zx_type_550,
    index: u64,
    reference: bool,
};

pub const zx_type_553 = struct {
    index: u64,
    type_id: u32,
    types: *const zx_type_51,
};

pub const zx_type_554 = struct {
    left: zx_type_529,
    right: zx_type_529,
};

pub const zx_type_555 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_550,
    shell: zx_type_529,
    type_id: u32,
};

pub const zx_type_556 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    forest: *const zx_type_550,
    shell: zx_type_529,
    type_id: u32,
};

pub const zx_type_557 = struct {
    fact: u64,
    forest: *const zx_type_550,
    index: u64,
    references: []const bool,
    type_id: u32,
    types: *const zx_type_51,
    value: u64,
};

pub const zx_type_558 = struct {
    facts: []const u64,
    forest: *const zx_type_550,
    states: []const zx_type_529,
};

pub const zx_type_559 = struct {
    fact: u64,
    id: u64,
    layout: *const zx_type_531,
    references: []const bool,
    storage: *const zx_type_558,
    types: *const zx_type_51,
};

pub const zx_type_560 = struct {
    capacity: u64,
    left: u64,
    right: u64,
};

pub const zx_type_561 = enum { Join, Read, Borrow, Freeze, ReleaseAllLoans, ReleaseNewLoans, };

pub const zx_type_562 = struct {
    left: []const u64,
    right: []const u64,
    slots: []const u64,
    values: []const u64,
};

pub const zx_type_563 = struct {
    cache: *const zx_type_562,
    left: u64,
    right: u64,
};

pub const zx_type_564 = struct {
    cache: *const zx_type_562,
    left: u64,
    right: u64,
    value: u64,
};

pub const zx_type_565 = struct {
    count: u64,
    values: []const u64,
};

pub const zx_type_566 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: *const zx_type_550,
    references: []const bool,
    shell: zx_type_529,
    type_id: u32,
    types: *const zx_type_51,
};

pub const zx_type_567 = struct {
    action: zx_type_561,
    left: zx_type_529,
    right: zx_type_529,
};

pub const zx_type_568 = struct {
    action: zx_type_561,
    forest: *const zx_type_550,
    left: u64,
    references: []const bool,
    right: u64,
    types: *const zx_type_51,
};

pub const zx_type_569 = enum { States, Memo, Both, };

pub const zx_type_570 = enum { RestoreStates, MergeStates, ReleaseNewLoans, ReleaseAllLoans, RestoreMemo, };

pub const zx_type_571 = struct {
    facts: []const u64,
    memo: []const u64,
    memo_count: []const u64,
    memo_first: []const u64,
    state_count: []const u64,
    state_first: []const u64,
};

pub const zx_type_572 = struct {
    facts: []const u64,
    forest: *const zx_type_550,
    memo: []const u64,
    states: []const zx_type_529,
    trail: []const u64,
};

pub const zx_type_573 = struct {
    memory: *const zx_type_572,
    snapshots: *const zx_type_571,
};

pub const zx_type_574 = struct {
    fact: u64,
    id: u64,
    layout: *const zx_type_531,
    memory: *const zx_type_572,
    operation: zx_type_530,
    references: []const bool,
    types: *const zx_type_51,
};

pub const zx_type_575 = struct {
    layout: *const zx_type_536,
    program: *const zx_type_522,
    references: []const bool,
};

pub const zx_type_576 = enum { Block, Statement, Release, Value, Finish, Project, Captured, Copy, Borrowed, Constant, Result, Store, Destructure, Borrow, Aggregate, Sequence, SequenceResult, IndexTarget, IndexResult, BranchCondition, BranchYes, BranchNo, CallResult, BinaryLeft, BinaryRight, ConditionalCondition, ConditionalYes, ConditionalNo, UpdateResult, ScopeBinding, ScopeResult, ScopeFinish, TaskCapture, TaskFinish, ParallelBranch, ObjectEvaluation, ObjectCached, ObjectField, ObjectFieldResult, ObjectFinish, Invocation, InvocationResult, CollectionTarget, CollectionArgument, CollectionResult, CollectionFreeze, SwitchSubject, SwitchCase, SwitchResult, MatchSubject, MatchArm, MatchCondition, MatchResult, MatchFinish, IterationInitial, IterationRound, IterationAdvance, IterationCondition, IterationBody, IterationFinish, TransformTarget, TransformInitial, TransformParameter, TransformBody, TransformFinish, };

pub const zx_type_577 = struct {
    action: zx_type_576,
    index: u64,
    moving: bool,
    subject: u64,
};

pub const zx_type_579 = struct {
    actions: []const zx_type_576,
    indices: []const u64,
    moving: []const bool,
    subjects: []const u64,
};

pub const zx_type_580 = struct {
    complete: bool,
    expression: u64,
    failed: bool,
    output: zx_type_529,
    stores_owned: bool,
};

pub const zx_type_581 = struct {
    action: zx_type_570,
    frame: u64,
    layout: *const zx_type_531,
    memory: *const zx_type_572,
    references: []const bool,
    stack: *const zx_type_571,
    types: *const zx_type_51,
};

pub const zx_type_582 = struct {
    frame: u64,
    stack: *const zx_type_571,
};

pub const zx_type_583 = struct {
    capture: zx_type_569,
    memory: *const zx_type_572,
    stack: *const zx_type_571,
};

pub const zx_type_584 = struct {
    frame: *const zx_type_577,
    work: *const zx_type_579,
};

pub const zx_type_585 = struct {
    count: []const u64,
    first: []const u64,
};

pub const zx_type_586 = struct {
    boundaries: []const u64,
    count: []const u64,
    entries: []const u64,
    exits: []const u64,
    facts: []const u64,
    first: []const u64,
    heads: []const u64,
    outputs: []const u64,
    roots: []const u64,
    seen: []const bool,
};

pub const zx_type_587 = enum { Statements, Values, Callbacks, Branches, Calls, Collections, Objects, Scope, Tasks, Expression, Invalid, };

pub const zx_type_588 = struct {
    active: bool,
    builders: *const zx_type_585,
    complete: bool,
    domains: *const zx_type_528,
    expression: u64,
    failed: bool,
    layout: *const zx_type_536,
    loops: *const zx_type_586,
    memory: *const zx_type_572,
    program: *const zx_type_522,
    references: []const bool,
    returned: zx_type_529,
    returns: []const bool,
    snapshots: *const zx_type_571,
    stores_owned: bool,
    value: u64,
    values: []const u64,
    work: *const zx_type_579,
};

pub const zx_type_589 = struct {
    frame: u64,
    layout: *const zx_type_531,
    memory: *const zx_type_572,
    merge: bool,
    references: []const bool,
    stack: *const zx_type_571,
    types: *const zx_type_51,
};

pub const zx_type_590 = struct {
    index: u64,
    loops: *const zx_type_586,
    memory: *const zx_type_572,
    references: []const bool,
    types: *const zx_type_51,
    value: u64,
};

pub const zx_type_591 = struct {
    forest: *const zx_type_550,
    loops: *const zx_type_586,
};

pub const zx_type_592 = struct {
    condition: bool,
    expression: u64,
    index: u64,
    machine: *const zx_type_588,
    value: u64,
};

pub const zx_type_593 = struct {
    boundary: u64,
    memory: *const zx_type_572,
    snapshots: *const zx_type_571,
    work: *const zx_type_579,
};

pub const zx_type_594 = struct {
    changed: bool,
    forest: *const zx_type_550,
    loops: *const zx_type_586,
};

pub const zx_type_595 = struct {
    domains: *const zx_type_528,
    exiting: bool,
    expression: u64,
    index: u64,
    layout: *const zx_type_531,
    loops: *const zx_type_586,
    memory: *const zx_type_572,
    references: []const bool,
    snapshots: *const zx_type_571,
    types: *const zx_type_51,
};

pub const zx_type_596 = struct {
    domains: *const zx_type_528,
    entry: u64,
    expression: u64,
    layout: *const zx_type_531,
    loops: *const zx_type_586,
    memory: *const zx_type_572,
    program: *const zx_type_522,
    value: u64,
};

pub const zx_type_597 = enum { Next, Query, Descend, Expand, Enter, Done, };

pub const zx_type_598 = struct {
    active: bool,
    cursors: []const u64,
    expression: u64,
    expressions: *const zx_type_34,
    facts: []const u64,
    forest: *const zx_type_550,
    layout: *const zx_type_536,
    memo: []const u64,
    permanent: bool,
    phase: zx_type_597,
    position: u64,
    query: u64,
    references: []const bool,
    root: u64,
    states: []const zx_type_529,
    trail: []const u64,
    types: *const zx_type_51,
    work: []const u64,
};

pub const zx_type_599 = struct {
    expression: u64,
    expressions: *const zx_type_34,
    index: u64,
    permanent: bool,
};

pub const zx_type_600 = struct {
    expression: u64,
    expressions: *const zx_type_34,
    layout: *const zx_type_536,
    memory: *const zx_type_572,
    permanent: bool,
    references: []const bool,
    types: *const zx_type_51,
};

pub const zx_type_601 = struct {
    expression: u64,
    expressions: *const zx_type_34,
    layout: *const zx_type_536,
    memo: []const u64,
    trail: []const u64,
};

pub const zx_type_602 = struct {
    found: bool,
    position: u64,
    trail: []const u64,
};

pub const zx_type_603 = struct {
    current: zx_type_529,
    moving: bool,
    position: u64,
    symbols: *const zx_type_16,
    types: *const zx_type_51,
};

pub const zx_type_604 = struct {
    assign: bool,
    assigned: zx_type_529,
    failed: bool,
    value: zx_type_529,
};

pub const zx_type_605 = struct {
    builders: *const zx_type_585,
    count: u64,
    forest: *const zx_type_550,
};

pub const zx_type_606 = struct {
    builders: *const zx_type_585,
    forest: *const zx_type_550,
};

pub const zx_type_607 = enum { Operands, Containers, Control, };

pub const zx_type_608 = struct {
    container: bool,
    frame: *const zx_type_577,
    kind: zx_type_23,
    machine: *const zx_type_588,
    payload: u64,
};

pub const zx_type_609 = struct {
    builders: *const zx_type_585,
    forest: *const zx_type_550,
    type_id: u32,
};

pub const zx_type_610 = struct {
    builders: *const zx_type_585,
    fact: u64,
    forest: *const zx_type_550,
};

pub const zx_type_611 = struct {
    domains: *const zx_type_528,
    layout: *const zx_type_536,
    program: *const zx_type_522,
    references: []const bool,
    returns: []const bool,
    runtime: *const zx_type_573,
};

pub const zx_type_612 = struct {
    outcome: *const zx_type_580,
    state: *const zx_type_188,
};

pub const zx_type_613 = struct {
    ownership: zx_type_11,
    state: *const zx_type_188,
};

pub const zx_type_614 = struct {
    domains: *const zx_type_528,
    layout: *const zx_type_536,
    references: []const bool,
    returns: []const bool,
};

pub const zx_type_615 = struct {
    memory: *const zx_type_572,
    prepared: *const zx_type_614,
    snapshots: *const zx_type_571,
};

pub const zx_type_616 = struct {
    analysis: *const zx_type_189,
    linking: bool,
};

pub const zx_type_617 = struct {
    child_end: u64,
    field_end: u64,
    index: u64,
    name_end: u64,
    scalar_count: u64,
    table: *const zx_type_50,
    valid: bool,
};

pub const zx_type_618 = struct {
    after_underscore: bool,
    index: u64,
    kind: zx_type_192,
    name: []const u8,
    valid: bool,
};

pub const zx_type_619 = struct {
    ascending: bool,
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
};

pub const zx_type_620 = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    owner: u64,
    table: *const zx_type_50,
    valid: bool,
    values: []const u32,
};

pub const zx_type_621 = struct {
    count: u64,
    errors: bool,
    first: u64,
    index: u64,
    valid: bool,
    values: []const []const u8,
};

pub const zx_type_622 = struct {
    count: u64,
    first: u64,
    index: u64,
    member: []const u8,
    unique: bool,
    values: []const []const u8,
};

pub const zx_type_623 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_50,
    valid: bool,
};

pub const zx_type_624 = struct { *const zx_type_191, };

pub const zx_type_625 = struct { *const zx_type_191, bool, };

pub const zx_type_626 = struct { *const zx_type_191, bool, bool, };

pub const zx_type_627 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_628 = struct { []const u8, []const u8, };

pub const zx_type_629 = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    selected: u64,
    source: *const zx_type_102,
};

pub const zx_type_630 = struct { []const []const u8, []const []const u8, };

pub const zx_type_631 = struct {
    count: u64,
    index: u64,
    state: *const zx_type_108,
};

pub const zx_type_632 = struct { *const zx_type_108, };

pub const zx_type_633 = struct { *const zx_type_108, *const zx_type_108, };

pub const zx_type_634 = struct { *const zx_type_108, *const zx_type_108, *const zx_type_108, };

pub const zx_type_635 = struct { []const []const u8, void, };

pub const zx_type_636 = struct { []const u32, void, };

pub const zx_type_637 = struct { []const []const u8, ?[]const u8, };

pub const zx_type_639 = struct { []const *const zx_type_106, ?*const zx_type_106, };

pub const zx_type_640 = struct {
    equal: bool,
    index: u64,
    left: *const zx_type_211,
    right: *const zx_type_211,
};

pub const zx_type_641 = struct {
    candidate: *const zx_type_208,
    count: u64,
    found: bool,
    id: u32,
    index: u64,
    tables: *const zx_type_51,
};

pub const zx_type_642 = struct { []const u8, void, };

pub const zx_type_643 = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    limit: u64,
    right: []const u8,
};

pub const zx_type_644 = struct {
    building: bool,
    count: u64,
    names: []const []const u8,
    remaining: u64,
    root: u64,
    sifting: bool,
    types: []const u32,
};

pub const zx_type_645 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
};

pub const zx_type_646 = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: *const zx_type_51,
    target: zx_type_48,
};

pub const zx_type_647 = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: *const zx_type_51,
};

pub const zx_type_648 = struct { []const bool, void, };

pub const zx_type_649 = struct {
    children: []const u32,
    found: bool,
    index: u64,
    tables: *const zx_type_51,
};

pub const zx_type_650 = struct {
    count: u64,
    diagnostic: *const zx_type_58,
    enumeration: u64,
    index: u64,
    names: []const []const u8,
    source: *const zx_type_102,
};

pub const zx_type_651 = struct {
    cache: *const zx_type_104,
    found: bool,
    id: u32,
    index: u64,
    name: []const u8,
};

pub const zx_type_652 = struct { []const *const zx_type_106, void, };

pub const zx_type_653 = struct { []const u32, []const u32, };

pub const zx_type_654 = struct { *const zx_type_109, };

pub const zx_type_655 = struct { *const zx_type_109, *const zx_type_108, };

pub const zx_type_656 = struct { *const zx_type_109, *const zx_type_108, *const zx_type_108, };

pub const zx_type_657 = struct { *const zx_type_109, *const zx_type_108, *const zx_type_108, *const zx_type_108, };

pub const zx_type_658 = struct {
    count: u64,
    index: u64,
    types: []const u32,
    valid: bool,
};

pub const zx_type_659 = struct { *const zx_type_274, };

pub const zx_type_660 = struct { *const zx_type_274, bool, };

pub const zx_type_661 = struct { *const zx_type_274, bool, *const zx_type_109, };

pub const zx_type_662 = struct { *const zx_type_274, bool, *const zx_type_109, *const zx_type_110, };

pub const zx_type_663 = struct { *const zx_type_274, bool, *const zx_type_109, *const zx_type_110, *const zx_type_189, };

pub const zx_type_664 = struct { []const u64, void, };

pub const zx_type_665 = struct { []const zx_type_11, void, };

pub const zx_type_666 = struct { []const zx_type_23, void, };

pub const zx_type_667 = struct { *const zx_type_274, *const zx_type_189, };

pub const zx_type_668 = struct { *const zx_type_274, *const zx_type_189, *const zx_type_189, };

pub const zx_type_669 = struct {
    count: u64,
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
};

pub const zx_type_670 = struct {
    bytes: []const u8,
    index: u64,
    keyword: u64,
    start: bool,
    valid: bool,
};

pub const zx_type_671 = struct {
    index: u64,
    name: []const u8,
    names: []const []const u8,
    overlap: bool,
};

pub const zx_type_672 = struct {
    analysis: *const zx_type_189,
    index: u64,
    names: []const []const u8,
};

pub const zx_type_673 = struct {
    analysis: *const zx_type_189,
    index: u64,
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_674 = struct {
    found: bool,
    index: u64,
    symbol: u32,
    values: []const u32,
};

pub const zx_type_675 = struct {
    analysis: *const zx_type_189,
    bindings: []const []const u8,
    index: u64,
    names: []const []const u8,
};

pub const zx_type_676 = struct {
    bindings: []const []const u8,
    index: u64,
    name: []const u8,
    symbol: ?u32,
    symbols: []const u32,
};

pub const zx_type_677 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_34,
    index: u64,
    limit: u64,
    valid: bool,
};

pub const zx_type_678 = struct {
    index: u64,
    result: []const bool,
    source: []const ?u32,
};

pub const zx_type_679 = struct {
    concurrent: bool,
    functions: *const zx_type_277,
    index: u64,
    values: []const bool,
};

pub const zx_type_680 = struct {
    actual: u32,
    expected: u32,
    failed: bool,
    tables: *const zx_type_51,
    wrappers: []const u32,
};

pub const zx_type_681 = struct {
    index: u64,
    span: *const zx_type_46,
    table: *const zx_type_34,
    value: u32,
    wrappers: []const u32,
};

pub const zx_type_682 = struct {
    all: bool,
    bodies: []const u32,
    end: u64,
    index: u64,
    returns: []const bool,
};

pub const zx_type_683 = struct {
    block: u64,
    control: *const zx_type_22,
    returns: []const bool,
};

pub const zx_type_684 = struct { []const *const zx_type_338, void, };

pub const zx_type_685 = struct {
    contracts: *const zx_type_255,
    index: u64,
    state: *const zx_type_342,
};

pub const zx_type_686 = struct { []const *const zx_type_337, void, };

pub const zx_type_687 = struct {
    control: *const zx_type_22,
    first: u64,
    frames: []const *const zx_type_337,
    index: u64,
    source: u64,
};

pub const zx_type_688 = struct {
    capacity: u64,
    slots: []const u64,
};

pub const zx_type_689 = struct {
    index: u64,
    previous: []const u64,
    slots: []const u64,
};

pub const zx_type_690 = struct {
    position: u64,
    slots: []const u64,
};

pub const zx_type_691 = struct { []const u64, []const u64, };

pub const zx_type_692 = struct {
    key: u64,
    position: u64,
    slots: []const u64,
};

pub const zx_type_693 = struct {
    end: u64,
    index: u64,
    table: *const zx_type_34,
    values: []const u32,
};

pub const zx_type_694 = struct {
    end: u64,
    expressions: *const zx_type_34,
    index: u64,
    names: []const []const u8,
    tables: *const zx_type_51,
};

pub const zx_type_695 = struct { []const *const zx_type_338, []const *const zx_type_338, };

pub const zx_type_696 = struct {
    frames: []const *const zx_type_337,
    index: u64,
    source: u64,
    values: []const u32,
};

pub const zx_type_698 = struct { []const *const zx_type_337, ?*const zx_type_337, };

pub const zx_type_699 = struct {
    index: u64,
    names: []const []const u8,
    values: []const []const u8,
};

pub const zx_type_700 = struct { *const zx_type_343, };

pub const zx_type_701 = struct { *const zx_type_343, *const zx_type_342, };

pub const zx_type_702 = struct { *const zx_type_343, *const zx_type_342, *const zx_type_342, };

pub const zx_type_703 = struct { *const zx_type_343, *const zx_type_342, *const zx_type_342, ?[]const []const u8, };

pub const zx_type_704 = struct {
    captures: []const u32,
    concurrent: []const bool,
    index: u64,
    span: *const zx_type_46,
    state: *const zx_type_188,
    symbols: u64,
};

pub const zx_type_706 = struct { []const *const zx_type_310, ?*const zx_type_310, };

pub const zx_type_707 = struct { []const zx_type_27, void, };

pub const zx_type_708 = struct {
    comparable: bool,
    done: bool,
    id: u32,
    tables: *const zx_type_51,
};

pub const zx_type_709 = struct {
    facts: *const zx_type_36,
    index: u64,
    symbol: u32,
};

pub const zx_type_710 = struct {
    expressions: *const zx_type_34,
    state: *const zx_type_38,
};

pub const zx_type_711 = struct { []const u64, ?u64, };

pub const zx_type_713 = struct { []const bool, ?bool, };

pub const zx_type_714 = struct { []const zx_type_297, void, };

pub const zx_type_715 = struct { []const *const zx_type_300, []const *const zx_type_300, };

pub const zx_type_717 = struct { []const *const zx_type_300, ?*const zx_type_300, };

pub const zx_type_718 = struct {
    head: u64,
    items: []const *const zx_type_70,
    values: []const u64,
};

pub const zx_type_719 = struct { []const zx_type_24, void, };

pub const zx_type_721 = struct { []const *const zx_type_307, ?*const zx_type_307, };

pub const zx_type_722 = struct {
    done: bool,
    id: u32,
    tables: *const zx_type_51,
};

pub const zx_type_723 = struct {
    active: []const u32,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_724 = struct { []const ?u32, void, };

pub const zx_type_725 = struct {
    head: u64,
    ids: []const u64,
    tree: *const zx_type_150,
};

pub const zx_type_726 = struct {
    index: u64,
    order: []const u64,
    parameters: []const u32,
    source: *const zx_type_272,
    start: u64,
    state: *const zx_type_188,
    types: []const u32,
};

pub const zx_type_727 = struct { []const zx_type_11, []const zx_type_11, };

pub const zx_type_728 = struct { []const *const zx_type_283, []const *const zx_type_283, };

pub const zx_type_730 = struct { []const *const zx_type_306, ?*const zx_type_306, };

pub const zx_type_731 = struct { []const *const zx_type_283, void, };

pub const zx_type_732 = struct { []const *const zx_type_307, void, };

pub const zx_type_733 = struct {
    found: ?u32,
    index: u64,
    local: *const zx_type_42,
    name: []const u8,
};

pub const zx_type_734 = struct {
    done: bool,
    end: u64,
    matches: bool,
    node: u64,
    path: []const u8,
    source: *const zx_type_272,
};

pub const zx_type_735 = struct {
    end: u64,
    equal: bool,
    index: u64,
    path: []const u8,
    size: u64,
    source: []const u8,
    start: u64,
};

pub const zx_type_736 = struct {
    node: u64,
    tree: *const zx_type_150,
};

pub const zx_type_737 = struct {
    bindings: []const u32,
    index: u64,
    local: ?u32,
    names: []const []const u8,
    node: u64,
    source: *const zx_type_272,
    symbol: ?u32,
    unit: bool,
    units: []const []const u8,
};

pub const zx_type_738 = struct {
    imports: *const zx_type_268,
    index: u64,
    name: []const u8,
    namespace: ?[]const u8,
    result: ?u32,
};

pub const zx_type_739 = struct {
    index: u64,
    name: []const u8,
    owner: []const u8,
    stores: *const zx_type_35,
    type_id: ?u32,
};

pub const zx_type_740 = struct { []const *const zx_type_391, void, };

pub const zx_type_741 = struct {
    frames: []const *const zx_type_391,
    head: u64,
    tree: *const zx_type_150,
};

pub const zx_type_742 = struct {
    floating: bool,
    index: u64,
    separators: bool,
    source: []const u8,
};

pub const zx_type_743 = struct {
    floating: bool,
    index: u64,
    nodes: []const u64,
    signed: bool,
    source: *const zx_type_272,
};

pub const zx_type_744 = struct {
    fallback: u64,
    head: u64,
    source: *const zx_type_272,
    type_id: ?u32,
};

pub const zx_type_745 = struct {
    negative: bool,
    offset: u64,
    seen: bool,
    source: []const u8,
    started: bool,
    valid: bool,
    value: u64,
};

pub const zx_type_746 = struct {
    count: u64,
    first: u64,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_748 = struct { []const *const zx_type_391, ?*const zx_type_391, };

pub const zx_type_749 = struct { []const *const zx_type_301, []const *const zx_type_301, };

pub const zx_type_751 = struct { []const *const zx_type_301, ?*const zx_type_301, };

pub const zx_type_753 = struct { []const *const zx_type_305, ?*const zx_type_305, };

pub const zx_type_754 = struct { []const *const zx_type_305, []const *const zx_type_305, };

pub const zx_type_755 = struct { []const *const zx_type_285, []const *const zx_type_285, };

pub const zx_type_757 = struct { []const *const zx_type_285, ?*const zx_type_285, };

pub const zx_type_758 = struct { []const *const zx_type_307, []const *const zx_type_307, };

pub const zx_type_759 = struct { []const *const zx_type_302, []const *const zx_type_302, };

pub const zx_type_761 = struct { []const *const zx_type_302, ?*const zx_type_302, };

pub const zx_type_762 = struct {
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_763 = struct {
    count: u64,
    entries: *const zx_type_295,
    expressions: *const zx_type_34,
    first: u64,
    index: u64,
    names: []const []const u8,
    span: *const zx_type_46,
    types: []const u32,
    value: u32,
};

pub const zx_type_764 = struct {
    count: u64,
    entries: *const zx_type_295,
    evaluation: []const u32,
    first: u64,
    index: u64,
    names: []const []const u8,
    span: *const zx_type_46,
    state: *const zx_type_188,
    types: []const u32,
};

pub const zx_type_765 = struct {
    index: u64,
    output: []const u32,
    types: []const u32,
    values: []const u32,
};

pub const zx_type_766 = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    indices: []const u32,
    names: []const []const u8,
};

pub const zx_type_768 = struct { []const *const zx_type_304, ?*const zx_type_304, };

pub const zx_type_769 = struct { []const *const zx_type_304, []const *const zx_type_304, };

pub const zx_type_770 = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    indices: []const ?u32,
    names: []const []const u8,
};

pub const zx_type_771 = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    name: []const u8,
};

pub const zx_type_773 = struct { []const *const zx_type_311, ?*const zx_type_311, };

pub const zx_type_774 = struct { []const *const zx_type_311, []const *const zx_type_311, };

pub const zx_type_775 = struct { []const zx_type_26, void, };

pub const zx_type_776 = struct { []const *const zx_type_299, []const *const zx_type_299, };

pub const zx_type_778 = struct { []const *const zx_type_299, ?*const zx_type_299, };

pub const zx_type_779 = struct { []const u32, ?u32, };

pub const zx_type_780 = struct {
    head: u64,
    ids: []const u64,
    names: []const *const zx_type_159,
};

pub const zx_type_781 = struct {
    first: u64,
    index: u64,
    order: []const u64,
    saved: u32,
    scopes: *const zx_type_294,
    source: *const zx_type_272,
    start: u64,
    state: *const zx_type_188,
    symbols: []const ?u32,
    types: []const u32,
};

pub const zx_type_782 = struct { []const *const zx_type_292, []const *const zx_type_292, };

pub const zx_type_783 = struct {
    head: u64,
    items: []const *const zx_type_70,
    remaining: u64,
    statements: []const u64,
};

pub const zx_type_784 = struct { []const *const zx_type_292, void, };

pub const zx_type_785 = struct { []const *const zx_type_290, []const *const zx_type_290, };

pub const zx_type_787 = struct { []const *const zx_type_290, ?*const zx_type_290, };

pub const zx_type_788 = struct {
    expressions: *const zx_type_34,
    found: bool,
    index: u64,
    previous: []const u32,
    value: u64,
};

pub const zx_type_790 = struct { []const *const zx_type_291, ?*const zx_type_291, };

pub const zx_type_791 = struct { []const *const zx_type_291, []const *const zx_type_291, };

pub const zx_type_792 = struct {
    diagnostic: *const zx_type_58,
    done: bool,
    expressions: *const zx_type_34,
    frames: []const *const zx_type_286,
    read_value: bool,
    symbol: u32,
    tables: *const zx_type_51,
    target: u32,
};

pub const zx_type_793 = struct { []const *const zx_type_286, void, };

pub const zx_type_794 = struct {
    frames: []const *const zx_type_286,
    index: u64,
    places: []const *const zx_type_287,
    scopes: *const zx_type_294,
    state: *const zx_type_188,
};

pub const zx_type_795 = struct { []const *const zx_type_287, void, };

pub const zx_type_796 = struct { []const *const zx_type_287, []const *const zx_type_287, };

pub const zx_type_797 = struct {
    count: u64,
    expressions: *const zx_type_34,
    first: u64,
    index: u64,
    indices: []const u32,
    metadata: *const zx_type_236,
    parent: u32,
    selected: u64,
    table: *const zx_type_50,
    tuple: bool,
    value: u32,
    values: []const u32,
};

pub const zx_type_798 = struct {
    index: u64,
    places: []const *const zx_type_287,
    state: *const zx_type_188,
    value: u32,
};

pub const zx_type_799 = struct { []const *const zx_type_289, []const *const zx_type_289, };

pub const zx_type_801 = struct { []const *const zx_type_289, ?*const zx_type_289, };

pub const zx_type_803 = struct { []const *const zx_type_303, ?*const zx_type_303, };

pub const zx_type_804 = struct { []const *const zx_type_303, []const *const zx_type_303, };

pub const zx_type_805 = struct {
    index: u64,
    rewrite: bool,
    source: []const u8,
    template: bool,
};

pub const zx_type_806 = struct {
    bytes: []const u8,
    index: u64,
    source: []const u8,
    template: bool,
};

pub const zx_type_807 = struct {
    frame: *const zx_type_308,
    source: *const zx_type_272,
    span: *const zx_type_46,
    state: *const zx_type_188,
};

pub const zx_type_809 = struct { []const *const zx_type_308, ?*const zx_type_308, };

pub const zx_type_810 = struct { []const *const zx_type_308, []const *const zx_type_308, };

pub const zx_type_811 = struct {
    fields: []const u32,
    index: u64,
    types: []const u32,
    values: []const u32,
};

pub const zx_type_812 = struct {
    count: u64,
    fields: *const zx_type_295,
    first: u64,
    index: u64,
    indices: []const u32,
    names: []const []const u8,
    values: []const u32,
};

pub const zx_type_813 = struct {
    bindings: *const zx_type_281,
    context: u32,
    index: u64,
    span: *const zx_type_46,
    state: *const zx_type_188,
    targets: []const u32,
};

pub const zx_type_814 = struct {
    bindings: *const zx_type_281,
    index: u64,
    parameters: []const u32,
    reducing: bool,
    values: []const u32,
};

pub const zx_type_815 = struct { *const zx_type_467, };

pub const zx_type_816 = struct { *const zx_type_467, *const zx_type_468, };

pub const zx_type_817 = struct { *const zx_type_467, *const zx_type_468, *const zx_type_242, };

pub const zx_type_818 = struct { *const zx_type_467, *const zx_type_468, *const zx_type_242, *const zx_type_242, };

pub const zx_type_819 = struct { *const zx_type_467, *const zx_type_468, *const zx_type_242, *const zx_type_242, *const zx_type_242, };

pub const zx_type_820 = struct { *const zx_type_282, };

pub const zx_type_821 = struct { *const zx_type_282, *const zx_type_455, };

pub const zx_type_822 = struct { *const zx_type_282, *const zx_type_455, *const zx_type_242, };

pub const zx_type_823 = struct { *const zx_type_282, *const zx_type_455, *const zx_type_242, *const zx_type_242, };

pub const zx_type_824 = struct { *const zx_type_282, *const zx_type_455, *const zx_type_242, *const zx_type_242, *const zx_type_465, };

pub const zx_type_825 = struct { *const zx_type_282, *const zx_type_455, *const zx_type_242, *const zx_type_242, *const zx_type_465, *const zx_type_242, };

pub const zx_type_826 = struct { *const zx_type_282, *const zx_type_455, *const zx_type_242, *const zx_type_242, *const zx_type_465, *const zx_type_242, *const zx_type_242, };

pub const zx_type_827 = struct { *const zx_type_282, *const zx_type_455, *const zx_type_242, *const zx_type_242, *const zx_type_465, *const zx_type_242, *const zx_type_242, *const zx_type_242, };

pub const zx_type_828 = struct {
    bindings: *const zx_type_40,
    row: ?u32,
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
};

pub const zx_type_830 = struct { []const *const zx_type_283, ?*const zx_type_283, };

pub const zx_type_832 = struct { []const zx_type_297, ?zx_type_297, };

pub const zx_type_834 = struct { []const *const zx_type_298, ?*const zx_type_298, };

pub const zx_type_835 = struct { []const ?u32, []const ?u32, };

pub const zx_type_836 = struct {
    bindings: *const zx_type_40,
    found: ?u32,
    row: ?u32,
    source: u32,
};

pub const zx_type_837 = struct {
    floor: u64,
    found: ?u32,
    index: u64,
    local: *const zx_type_42,
    name: []const u8,
};

pub const zx_type_838 = struct {
    frame: ?u32,
    local: *const zx_type_42,
    name: []const u8,
    path: []const u32,
    symbol: ?u32,
};

pub const zx_type_839 = struct {
    index: u64,
    path: []const u32,
    span: *const zx_type_46,
    state: *const zx_type_188,
    symbol: u32,
};

pub const zx_type_840 = struct {
    found: bool,
    index: u64,
    local: *const zx_type_42,
    name: []const u8,
};

pub const zx_type_841 = struct { []const f64, void, };

pub const zx_type_842 = struct {
    bytes: []const u8,
    index: u64,
    source: []const u8,
};

pub const zx_type_843 = struct {
    carry: u64,
    index: u64,
    limbs: []const u64,
};

pub const zx_type_844 = struct {
    bits: u64,
    value: u64,
};

pub const zx_type_845 = struct {
    index: u64,
    limbs: []const u64,
};

pub const zx_type_846 = struct {
    count: u64,
    value: u64,
};

pub const zx_type_847 = struct {
    bytes: []const u8,
    index: u64,
    invalid: bool,
    limbs: []const u64,
};

pub const zx_type_848 = struct {
    handle: []const u8,
    handles: []const []const u8,
    index: u64,
};

pub const zx_type_849 = struct {
    active: []const u32,
    floor: u64,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_850 = struct {
    found: bool,
    imports: *const zx_type_268,
    index: u64,
    known_namespace: bool,
    name: []const u8,
    namespace: ?[]const u8,
};

pub const zx_type_851 = struct { []const *const zx_type_305, void, };

pub const zx_type_852 = struct {
    condition: ?u64,
    diagnostic: *const zx_type_58,
    fields: []const u64,
    index: u64,
    postcondition: bool,
    source: *const zx_type_272,
    step: ?u64,
};

pub const zx_type_853 = struct { []const *const zx_type_285, void, };

pub const zx_type_854 = struct {
    fields: []const *const zx_type_141,
    head: u64,
    ids: []const u64,
};

pub const zx_type_855 = struct { []const *const zx_type_311, void, };

pub const zx_type_856 = struct { []const *const zx_type_306, void, };

pub const zx_type_857 = struct {
    arms: []const u64,
    head: u64,
    tree: *const zx_type_150,
};

pub const zx_type_858 = struct { []const *const zx_type_302, void, };

pub const zx_type_859 = struct {
    fields: []const u64,
    head: u64,
    tree: *const zx_type_150,
};

pub const zx_type_860 = struct { []const *const zx_type_304, void, };

pub const zx_type_861 = struct {
    head: u64,
    items: []const u64,
    tree: *const zx_type_150,
};

pub const zx_type_862 = struct { []const *const zx_type_303, void, };

pub const zx_type_863 = struct {
    head: u64,
    parts: []const u64,
    tree: *const zx_type_150,
};

pub const zx_type_864 = struct { []const *const zx_type_308, void, };

pub const zx_type_865 = struct { []const *const zx_type_298, void, };

pub const zx_type_866 = struct { []const *const zx_type_310, void, };

pub const zx_type_867 = struct { []const *const zx_type_299, void, };

pub const zx_type_868 = struct { []const *const zx_type_300, void, };

pub const zx_type_869 = struct { []const *const zx_type_301, void, };

pub const zx_type_870 = struct { []const bool, []const bool, };

pub const zx_type_872 = struct { []const *const zx_type_292, ?*const zx_type_292, };

pub const zx_type_873 = struct { []const *const zx_type_289, void, };

pub const zx_type_874 = struct { []const *const zx_type_290, void, };

pub const zx_type_875 = struct {
    cases: []const *const zx_type_160,
    head: u64,
    ids: []const u64,
};

pub const zx_type_876 = struct { []const *const zx_type_291, void, };

pub const zx_type_877 = struct { *const zx_type_274, *const zx_type_275, };

pub const zx_type_878 = struct { *const zx_type_274, *const zx_type_275, *const zx_type_332, };

pub const zx_type_879 = struct { *const zx_type_274, *const zx_type_275, *const zx_type_332, *const zx_type_332, };

pub const zx_type_880 = struct { []const zx_type_17, void, };

pub const zx_type_881 = struct {
    index: u64,
    symbols: []const u32,
    table: *const zx_type_22,
    values: []const u32,
};

pub const zx_type_882 = struct { *const zx_type_189, };

pub const zx_type_883 = struct { *const zx_type_189, *const zx_type_189, };

pub const zx_type_884 = struct {
    target: *const zx_type_53,
    types: *const zx_type_51,
};

pub const zx_type_885 = struct {
    index: u64,
    references: []const bool,
    types: *const zx_type_51,
};

pub const zx_type_886 = struct {
    count: u64,
    expressions: *const zx_type_34,
    index: u64,
    kind: zx_type_23,
    locals: []const bool,
    payload: u64,
};

pub const zx_type_887 = struct {
    body: u64,
    condition: u64,
    count: u64,
    locals: []const bool,
    reachable: []const bool,
    symbols: u64,
};

pub const zx_type_888 = struct {
    expressions: *const zx_type_34,
    index: u64,
    locals: []const bool,
    reachable: []const bool,
    remaining: u64,
};

pub const zx_type_889 = struct {
    count: []const u64,
    first: []const u64,
    index: u64,
    program: *const zx_type_522,
    symbols: []const u64,
};

pub const zx_type_890 = struct {
    index: u64,
    locals: []const bool,
    symbols: []const u64,
};

pub const zx_type_891 = struct {
    active: bool,
    cached_count: []const u64,
    cached_first: []const u64,
    cached_positions: []const u64,
    children: []const u64,
    field_indices: []const u64,
    heads: []const u64,
    index: u64,
    item: u64,
    next: []const u64,
    parents: []const u64,
    phase: zx_type_537,
    place_types: []const u32,
    program: *const zx_type_522,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    tails: []const u64,
};

pub const zx_type_892 = struct {
    active: bool,
    found: bool,
    index: *const zx_type_540,
    key: *const zx_type_541,
    slot: u64,
    value: u64,
};

pub const zx_type_893 = struct { *const zx_type_522, };

pub const zx_type_894 = struct { *const zx_type_522, []const bool, };

pub const zx_type_895 = struct { *const zx_type_522, []const bool, []const bool, };

pub const zx_type_896 = struct { *const zx_type_522, []const bool, []const bool, *const zx_type_528, };

pub const zx_type_897 = struct { *const zx_type_522, []const bool, []const bool, *const zx_type_528, *const zx_type_535, };

pub const zx_type_898 = struct { *const zx_type_522, []const bool, []const bool, *const zx_type_528, *const zx_type_535, *const zx_type_536, };

pub const zx_type_899 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_550,
    index: u64,
    state: zx_type_529,
};

pub const zx_type_900 = struct { []const zx_type_529, void, };

pub const zx_type_901 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    index: u64,
    source: []const u64,
};

pub const zx_type_902 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    forest: *const zx_type_550,
    index: u64,
    references: []const bool,
    target: u64,
    type_id: u32,
    types: *const zx_type_51,
    value: u64,
};

pub const zx_type_903 = struct {
    active: bool,
    ascending: bool,
    fact: u64,
    facts: []const u64,
    forest: *const zx_type_550,
    id: u64,
    layout: *const zx_type_531,
    leaving: bool,
    references: []const bool,
    root: u64,
    states: []const zx_type_529,
    types: *const zx_type_51,
};

pub const zx_type_904 = struct {
    active: bool,
    cache: *const zx_type_562,
    found: bool,
    left: u64,
    right: u64,
    slot: u64,
    value: u64,
};

pub const zx_type_905 = struct {
    active: bool,
    cache: *const zx_type_562,
    capacity: u64,
    grow: bool,
    index: u64,
    left: u64,
    right: u64,
    value: u64,
};

pub const zx_type_906 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: *const zx_type_550,
    index: u64,
    references: []const bool,
    same: bool,
    type_id: u32,
    types: *const zx_type_51,
};

pub const zx_type_907 = struct {
    action: zx_type_561,
    cache: *const zx_type_562,
    children: []const u64,
    first: []const u64,
    forest: *const zx_type_550,
    indices: []const u64,
    left: []const u64,
    paired: bool,
    references: []const bool,
    right: []const u64,
    types: *const zx_type_51,
    value: u64,
};

pub const zx_type_908 = struct {
    expressions: u64,
    facts: []const u64,
    memo: []const u64,
    places: u64,
    states: []const zx_type_529,
};

pub const zx_type_909 = struct { *const zx_type_522, *const zx_type_614, };

pub const zx_type_910 = struct { *const zx_type_522, *const zx_type_614, *const zx_type_573, };

pub const zx_type_911 = struct {
    action: zx_type_570,
    count: u64,
    index: u64,
    layout: *const zx_type_531,
    memo_first: u64,
    memory: *const zx_type_572,
    references: []const bool,
    rewrite_action: zx_type_561,
    saved: *const zx_type_571,
    state_first: u64,
    types: *const zx_type_51,
};

pub const zx_type_913 = struct { []const zx_type_576, ?zx_type_576, };

pub const zx_type_914 = struct { []const zx_type_576, void, };

pub const zx_type_915 = struct {
    count: u64,
    first: u64,
    forest: *const zx_type_550,
    index: u64,
    merge: bool,
    parents: []const u64,
    references: []const bool,
    saved: []const u64,
    source: []const u64,
    types: *const zx_type_51,
};

pub const zx_type_916 = struct {
    activation: u64,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: *const zx_type_550,
    index: u64,
    loops: *const zx_type_586,
    references: []const bool,
    seen: bool,
    types: *const zx_type_51,
    value: u64,
};

pub const zx_type_917 = struct {
    activation: u64,
    changed: bool,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: *const zx_type_550,
    index: u64,
    loops: *const zx_type_586,
    references: []const bool,
    types: *const zx_type_51,
    value: u64,
};

pub const zx_type_918 = struct {
    count: u64,
    facts: []const u64,
    first: u64,
    index: u64,
    layout: *const zx_type_531,
    local_first: u64,
    locals: u64,
    memory: *const zx_type_572,
    references: []const bool,
    roots: []const u64,
    symbols: []const u64,
    types: *const zx_type_51,
};

pub const zx_type_919 = struct {
    count: u64,
    flags: []const bool,
    symbols: u64,
};

pub const zx_type_920 = struct {
    count: u64,
    first: u64,
    flags: []const bool,
    index: u64,
    symbols: []const u64,
};

pub const zx_type_921 = struct {
    flags: []const bool,
    index: u64,
    memo: []const u64,
    parents: []const u64,
};

pub const zx_type_922 = struct {
    id: u64,
    parents: []const u64,
};

pub const zx_type_923 = struct {
    facts: []const u64,
    flags: []const bool,
    index: u64,
    outputs: []const u64,
    roots: []const u64,
    source: []const u64,
};

pub const zx_type_924 = struct {
    found: bool,
    index: u64,
    slots: *const zx_type_35,
};

pub const zx_type_925 = struct {
    active: bool,
    ascending: bool,
    expression: u64,
    expressions: *const zx_type_34,
    found: bool,
    layout: *const zx_type_536,
    memo: []const u64,
    position: u64,
    trail: []const u64,
};

pub const zx_type_926 = struct {
    children: []const u64,
    count: u64,
    index: u64,
};

pub const zx_type_927 = struct { *const zx_type_522, *const zx_type_615, };

pub const zx_type_928 = struct { *const zx_type_522, *const zx_type_615, *const zx_type_580, };

pub const zx_type_929 = struct { *const zx_type_616, };

pub const zx_type_930 = struct { *const zx_type_616, *const zx_type_522, };

pub const zx_type_931 = struct { *const zx_type_616, *const zx_type_522, *const zx_type_580, };

pub const zx_type_932 = struct { *const zx_type_616, *const zx_type_522, *const zx_type_580, *const zx_type_613, };

pub const zx_type_933 = struct { *const zx_type_185, };

pub const zx_type_934 = struct { *const zx_type_185, *const zx_type_189, };

pub const zx_type_935 = struct { *const zx_type_185, *const zx_type_189, *const zx_type_189, };

pub const zx_type_936 = struct { *const zx_type_185, *const zx_type_189, *const zx_type_189, *const zx_type_189, };

pub const zx_type_937 = struct { *const zx_type_185, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, };

pub const zx_type_938 = struct { *const zx_type_185, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, };

pub const zx_type_939 = struct { *const zx_type_185, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, };

pub const zx_type_940 = struct { *const zx_type_185, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, };

pub const zx_type_941 = struct { *const zx_type_185, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, };

pub const zx_type_942 = struct { *const zx_type_185, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_189, *const zx_type_190, };

pub const value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
    zx_origin: ?*const zx_type_36 = null,
};

pub const value_zx_type_38_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    conditions: []const u64,
    facts: value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    truths: []const bool,
    zx_origin: ?*const zx_type_38 = null,
};

pub const value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    first: []const ?u32,
    floors: []const u64,
    last: []const ?u32,
    parents: []const ?u32,
    starts: []const u64,
    zx_origin: ?*const zx_type_39 = null,
};

pub const value_zx_type_40_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    next: []const ?u32,
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_40 = null,
};

pub const value_zx_type_41_386c6731c19530fd8432acc84ff31b97d6ba880a96c10f7bdfa1616ee45da0f0 = struct {
    bindings: value_zx_type_40_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    current: ?u32,
    frames: value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_41 = null,
};

pub const value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69 = struct {
    active: []const u32,
    allow_store: bool,
    captures: value_zx_type_41_386c6731c19530fd8432acc84ff31b97d6ba880a96c10f7bdfa1616ee45da0f0,
    control: *const zx_type_22,
    expression_bindings: []const u32,
    expression_units: []const []const u8,
    expressions: *const zx_type_34,
    lambda_depth: u64,
    output_type: u32,
    refinement: value_zx_type_38_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    scope_floor: u64,
    stores: *const zx_type_35,
    symbols: *const zx_type_16,
    zx_origin: ?*const zx_type_42 = null,
};

pub const value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    base: *const zx_type_50,
    delta: *const zx_type_50,
    zx_origin: ?*const zx_type_51 = null,
};

pub const value_zx_type_52_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_52 = null,
};

pub const value_zx_type_53_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_48,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_53 = null,
};

pub const value_zx_type_55_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    end: u64,
    last_byte: u8,
    phase: zx_type_54,
    separators_valid: bool,
    zx_origin: ?*const zx_type_55 = null,
};

pub const value_zx_type_56_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    diagnostic: []const u8,
    end: u64,
    zx_origin: ?*const zx_type_56 = null,
};

pub const value_zx_type_63_14f151be98723b44a65ef54272e86f37e634a51c57971b7cdbf77db5daef53fc = struct {
    ahead_one: u8,
    ahead_two: u8,
    braces: u64,
    comments: []const *const zx_type_46,
    depth: u64,
    diagnostic: *const zx_type_58,
    dollar: bool,
    frames: []const *const zx_type_59,
    keyword_state: u64,
    line_break: bool,
    mode: zx_type_57,
    number: value_zx_type_55_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    offset: u64,
    skip_until: u64,
    source_length: u64,
    start: u64,
    symbol: zx_type_45,
    tokens: []const *const zx_type_47,
    warmed: u8,
    zx_origin: ?*const zx_type_63 = null,
};

pub const value_zx_type_64_e1ffa7811185b0059f03a475523fa4c6e0b5b5a864f30612add6a83cb730f9cf = struct {
    after: u8,
    byte: u8,
    has_after: bool,
    has_next: bool,
    next: u8,
    state: value_zx_type_63_14f151be98723b44a65ef54272e86f37e634a51c57971b7cdbf77db5daef53fc,
    zx_origin: ?*const zx_type_64 = null,
};

pub const value_zx_type_71_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    fields: []const u64,
    heads: []const u64,
    items: []const u64,
    zx_origin: ?*const zx_type_71 = null,
};

pub const value_zx_type_75_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    fields: []const *const zx_type_69,
    items: []const *const zx_type_70,
    nodes: []const *const zx_type_68,
    zx_origin: ?*const zx_type_75 = null,
};

pub const value_zx_type_77_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    depth: u64,
    diagnostic: *const zx_type_58,
    index: u64,
    name: *const zx_type_46,
    phase: zx_type_67,
    result: u64,
    start: u64,
    token: *const zx_type_47,
    zx_origin: ?*const zx_type_77 = null,
};

pub const value_zx_type_79_3d4acdf86258039cbdbe5c274a8acd76d0c1d090dc7f46092a910e9027d72b99 = struct {
    control: value_zx_type_77_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    frames: []const *const zx_type_76,
    tree: value_zx_type_75_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_79 = null,
};

pub const value_zx_type_82_1f6cf931ff1653b987809c8802c1c5135603b2eaa9fca3d6a77de94ccab3545b = struct {
    count: u64,
    depth: u64,
    diagnostic: *const zx_type_58,
    enumeration: bool,
    first: u64,
    index: u64,
    last_end: u64,
    name: *const zx_type_46,
    opening: u64,
    opening_index: u64,
    phase: zx_type_80,
    start: u64,
    token: *const zx_type_47,
    type_diagnostic: bool,
    zx_origin: ?*const zx_type_82 = null,
};

pub const value_zx_type_84_d4c36911b9e29c07c9fb12b56567bd5ba9d6014af03c3a6e74374757c00d5bea = struct {
    control: value_zx_type_82_1f6cf931ff1653b987809c8802c1c5135603b2eaa9fca3d6a77de94ccab3545b,
    declarations: []const *const zx_type_81,
    members: []const *const zx_type_46,
    types: value_zx_type_79_3d4acdf86258039cbdbe5c274a8acd76d0c1d090dc7f46092a910e9027d72b99,
    zx_origin: ?*const zx_type_84 = null,
};

pub const value_zx_type_99_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    declarations: []const *const zx_type_91,
    enumerations: []const *const zx_type_92,
    fields: []const *const zx_type_89,
    items: []const *const zx_type_90,
    members: []const *const zx_type_86,
    nodes: []const *const zx_type_88,
    zx_origin: ?*const zx_type_99 = null,
};

pub const value_zx_type_100_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97 = struct {
    bytes: []const u8,
    declarations: []const *const zx_type_81,
    members: []const *const zx_type_46,
    order: value_zx_type_71_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_75_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_100 = null,
};

pub const value_zx_type_102_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203 = struct {
    indexed: value_zx_type_100_007a74d9171b1b2fd8d7ed27a75e0ea835b89f311cfa0ceaf84c8ad913bf2c97,
    native: ?value_zx_type_99_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_102 = null,
};

pub const value_zx_type_105_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441 = struct {
    aliases: *const zx_type_104,
    base: *const zx_type_50,
    native_interface: bool,
    resolved: *const zx_type_104,
    source: value_zx_type_102_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    visiting: []const []const u8,
    zx_origin: ?*const zx_type_105 = null,
};

pub const value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72 = struct {
    active: []const []const u8,
    cache: *const zx_type_104,
    context: value_zx_type_105_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441,
    delta: *const zx_type_50,
    diagnostic: *const zx_type_58,
    frames: []const *const zx_type_106,
    result: u32,
    scratch: value_zx_type_52_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_108 = null,
};

pub const value_zx_type_109_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2 = struct {
    cache: *const zx_type_104,
    context: value_zx_type_105_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441,
    delta: *const zx_type_50,
    initialize: bool,
    name: *const zx_type_86,
    named: bool,
    reference: *const zx_type_87,
    zx_origin: ?*const zx_type_109 = null,
};

pub const value_zx_type_110_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    cache: *const zx_type_104,
    delta: *const zx_type_50,
    diagnostic: *const zx_type_58,
    id: u32,
    zx_origin: ?*const zx_type_110 = null,
};

pub const value_zx_type_111_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_111 = null,
};

pub const value_zx_type_112_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
    zx_origin: ?*const zx_type_112 = null,
};

pub const value_zx_type_113_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53 = struct {
    base: value_zx_type_112_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    delta: value_zx_type_112_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_113 = null,
};

pub const value_zx_type_114_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7 = struct {
    cache: *const zx_type_104,
    context: value_zx_type_105_36b892e5f2f11c173439464b5fc0a3a4ef14284f3c56f887350134b71309c441,
    delta: *const zx_type_50,
    nominal_delta: value_zx_type_112_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_114 = null,
};

pub const value_zx_type_115_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3 = struct {
    diagnostic: *const zx_type_58,
    input_type: u32,
    output_type: u32,
    span: *const zx_type_46,
    types: value_zx_type_114_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_115 = null,
};

pub const value_zx_type_116_539d28689d73e2d7988f395928c455fd14b02556a112f989000e7ec15641f78b = struct {
    allow_store: bool,
    signature: value_zx_type_115_b6302c920e9a1665b1c96be12933cadd5d806dc437a87820bb4681cfe07875c3,
    stores: *const zx_type_35,
    zx_origin: ?*const zx_type_116 = null,
};

pub const value_zx_type_125_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    events: []const *const zx_type_121,
    lexed: *const zx_type_65,
    parts: []const *const zx_type_120,
    templates: []const *const zx_type_119,
    token_templates: []const u64,
    zx_origin: ?*const zx_type_125 = null,
};

pub const value_zx_type_128_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    interpolations: []const *const zx_type_126,
    lexed: *const zx_type_65,
    parts: []const *const zx_type_120,
    templates: []const *const zx_type_119,
    token_templates: []const u64,
    zx_origin: ?*const zx_type_128 = null,
};

pub const value_zx_type_134_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    after_identifier: bool,
    arrow: bool,
    hints: []const *const zx_type_132,
    parameter_start: bool,
    zx_origin: ?*const zx_type_134 = null,
};

pub const value_zx_type_136_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1 = struct {
    hints: []const *const zx_type_132,
    interpolation_hints: []const []const *const zx_type_132,
    lexical: value_zx_type_128_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_136 = null,
};

pub const value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    arms: []const *const zx_type_144,
    fields: []const *const zx_type_141,
    items: []const *const zx_type_70,
    nodes: []const *const zx_type_140,
    parameters: []const *const zx_type_142,
    parts: []const *const zx_type_143,
    zx_origin: ?*const zx_type_150 = null,
};

pub const value_zx_type_154_b14d81bd852082d928c7e97a3a48f317953fa9f765bc0c0407cdb3f926b69b5e = struct {
    control: *const zx_type_152,
    frames: []const *const zx_type_151,
    prepared: value_zx_type_136_d46d81b23fe7b76cbd993c184d69769a718bc4753e6ec9bd75f5f207d6851ed1,
    tree: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_79_3d4acdf86258039cbdbe5c274a8acd76d0c1d090dc7f46092a910e9027d72b99,
    zx_origin: ?*const zx_type_154 = null,
};

pub const value_zx_type_164_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    blocks: []const *const zx_type_119,
    cases: []const *const zx_type_160,
    items: []const *const zx_type_70,
    names: []const *const zx_type_159,
    statements: []const *const zx_type_158,
    zx_origin: ?*const zx_type_164 = null,
};

pub const value_zx_type_170_8479351ede6be59f4cda24c2c469bcb9266110074e57ce839eee441715fb7524 = struct {
    control: *const zx_type_166,
    expression: value_zx_type_154_b14d81bd852082d928c7e97a3a48f317953fa9f765bc0c0407cdb3f926b69b5e,
    frame: *const zx_type_165,
    frames: []const *const zx_type_165,
    suspended: []const *const zx_type_168,
    tree: value_zx_type_164_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_170 = null,
};

pub const value_zx_type_173_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    contract_start: u64,
    diagnostic: *const zx_type_58,
    ensures: bool,
    expression_diagnostic: bool,
    has_ensures: bool,
    has_store: bool,
    phase: zx_type_171,
    token: *const zx_type_47,
    zx_origin: ?*const zx_type_173 = null,
};

pub const value_zx_type_175_2b945e954668d79a1828a63af686318e734737f524f3484029ebbdb1c25be8f2 = struct {
    body: value_zx_type_164_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    contracts: []const *const zx_type_172,
    control: value_zx_type_173_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    expression: value_zx_type_154_b14d81bd852082d928c7e97a3a48f317953fa9f765bc0c0407cdb3f926b69b5e,
    zx_origin: ?*const zx_type_175 = null,
};

pub const value_zx_type_179_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d = struct {
    count: u64,
    diagnostic: *const zx_type_58,
    first: u64,
    index: u64,
    named: bool,
    opening: *const zx_type_46,
    path: *const zx_type_46,
    phase: zx_type_176,
    start: u64,
    token: *const zx_type_47,
    type_only: bool,
    zx_origin: ?*const zx_type_179 = null,
};

pub const value_zx_type_181_74ed739624cff66047721e4df18908cd0e813cc99bd4a24ae4f125763c8bb979 = struct {
    control: value_zx_type_179_e94c22d54df2577542e5f7da583caa35b601e7dc58d30f5a71ec9a9dd45d3f6d,
    imports: []const *const zx_type_178,
    names: []const *const zx_type_46,
    zx_origin: ?*const zx_type_181 = null,
};

pub const value_zx_type_183_3191ede17c96f03fe92fcee2a142bf07dadade62fc1258eb19ab63856e0a826a = struct {
    blocks: value_zx_type_164_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    body: ?u64,
    comments: []const *const zx_type_46,
    contracts: []const *const zx_type_172,
    declarations: []const *const zx_type_81,
    diagnostic: *const zx_type_58,
    expressions: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    function_start: u64,
    has_store: bool,
    import_names: []const *const zx_type_46,
    imports: []const *const zx_type_178,
    members: []const *const zx_type_46,
    tokens: []const *const zx_type_47,
    type_order: value_zx_type_71_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_75_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_183 = null,
};

pub const value_zx_type_184_d14aba735b0c187625e56713e243f7433aa1db3df3f6db783432ba1fe4c75e84 = struct {
    blocks: value_zx_type_164_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    comments: []const *const zx_type_46,
    diagnostic: *const zx_type_58,
    expressions: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    result: u64,
    tokens: []const *const zx_type_47,
    type_order: value_zx_type_71_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    types: value_zx_type_75_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    zx_origin: ?*const zx_type_184 = null,
};

pub const value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234 = struct {
    binding_names: []const []const u8,
    binding_types: []const u32,
    bytes: []const u8,
    expected: ?u32,
    linking: bool,
    maximum_type_count: u64,
    nonnull_bindings: []const []const u8,
    scalar_count: u64,
    syntax: value_zx_type_184_d14aba735b0c187625e56713e243f7433aa1db3df3f6db783432ba1fe4c75e84,
    type_base: *const zx_type_50,
    unit_bindings: []const []const u8,
    zx_origin: ?*const zx_type_185 = null,
};

pub const value_zx_type_186_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80 = struct {
    control: *const zx_type_22,
    expressions: *const zx_type_34,
    root: ?u32,
    stores: *const zx_type_35,
    symbols: *const zx_type_16,
    zx_origin: ?*const zx_type_186 = null,
};

pub const value_zx_type_187_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_34,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_16,
    zx_origin: ?*const zx_type_187 = null,
};

pub const value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed = struct {
    diagnostic: *const zx_type_58,
    input_type: u32,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    types: value_zx_type_114_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_188 = null,
};

pub const value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a = struct {
    binding_values: []const u32,
    input_value: u32,
    ownership: zx_type_11,
    root: ?u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_189 = null,
};

pub const value_zx_type_190_2473023bce8bf30edddad3d0973b2d3f36e9323c91cc1063d2e3c2123dd47f52 = struct {
    body: value_zx_type_186_5d40e1c8ed6129ef9e9ff2c507da077027e3d49603e02d62b08bf627af264d80,
    diagnostic: *const zx_type_58,
    input_type: u32,
    output_ownership: zx_type_11,
    output_type: u32,
    type_delta: *const zx_type_50,
    zx_origin: ?*const zx_type_190 = null,
};

pub const value_zx_type_191_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    maximum_count: u64,
    scalar_count: u64,
    table: *const zx_type_50,
    zx_origin: ?*const zx_type_191 = null,
};

pub const value_zx_type_193_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    kind: zx_type_192,
    name: []const u8,
    zx_origin: ?*const zx_type_193 = null,
};

pub const value_zx_type_194_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_194 = null,
};

pub const value_zx_type_195_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    table: *const zx_type_50,
    zx_origin: ?*const zx_type_195 = null,
};

pub const value_zx_type_196_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    errors: bool,
    first: u64,
    values: []const []const u8,
    zx_origin: ?*const zx_type_196 = null,
};

pub const value_zx_type_197_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_50,
    zx_origin: ?*const zx_type_197 = null,
};

pub const value_zx_type_198_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    scalar_count: u64,
    table: *const zx_type_50,
    zx_origin: ?*const zx_type_198 = null,
};

pub const value_zx_type_199_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    name: *const zx_type_86,
    operation: zx_type_103,
    reference: *const zx_type_87,
    zx_origin: ?*const zx_type_199 = null,
};

pub const value_zx_type_200_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_200 = null,
};

pub const value_zx_type_201_ce77ce34d8b07d2d8cf3d14edad6ab93dcb0763a67b7d556988b9d1c501ca5d6 = struct {
    code: []const u8,
    message: []const u8,
    name: *const zx_type_86,
    state: value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_201 = null,
};

pub const value_zx_type_203_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    source: []const u8,
    span: *const zx_type_46,
    zx_origin: ?*const zx_type_203 = null,
};

pub const value_zx_type_204_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    index: u64,
    source: value_zx_type_102_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_204 = null,
};

pub const value_zx_type_205_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b = struct {
    limit: u64,
    name: []const u8,
    source: value_zx_type_102_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_205 = null,
};

pub const value_zx_type_206_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    index: u64,
    zx_origin: ?*const zx_type_206 = null,
};

pub const value_zx_type_207_1f89c88e8344df3ff0e1ae6aeca43f8d4c75d21269ca1cbbd88f24f6f34f4e80 = struct {
    index: u64,
    state: value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_207 = null,
};

pub const value_zx_type_208_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_52_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_48,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_208 = null,
};

pub const value_zx_type_209_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_209 = null,
};

pub const value_zx_type_210_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    delta: *const zx_type_50,
    id: u32,
    zx_origin: ?*const zx_type_210 = null,
};

pub const value_zx_type_211_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d = struct {
    children: []const u32,
    count: u64,
    field_names: []const []const u8,
    field_types: []const u32,
    first: u32,
    kind: zx_type_48,
    label: []const u8,
    names: []const []const u8,
    offset: u64,
    second: u32,
    zx_origin: ?*const zx_type_211 = null,
};

pub const value_zx_type_212_6f975b180818098029dbaef75bb89bfea5e3cb89ee69a1d9370d1963760c4a33 = struct {
    left: value_zx_type_211_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    right: value_zx_type_211_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_212 = null,
};

pub const value_zx_type_213_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u64,
    table: *const zx_type_50,
    zx_origin: ?*const zx_type_213 = null,
};

pub const value_zx_type_214_2c4a87f781c651962259ae1ef67d878ae312a61c3d14b66307e5fd0a9c7f1e1e = struct {
    candidate: value_zx_type_208_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    id: u32,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_214 = null,
};

pub const value_zx_type_215_f9f434bc9d0869ee4fe93b8f2d75449d97ec21cc1ea12455f1df810be7821e22 = struct {
    candidate: value_zx_type_208_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_215 = null,
};

pub const value_zx_type_216_655f2c15f8b96113ed59dee46636710e0c7433f1f71d56fc2c400bda5a955e85 = struct {
    candidate: value_zx_type_208_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    delta: *const zx_type_50,
    zx_origin: ?*const zx_type_216 = null,
};

pub const value_zx_type_217_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    code: []const u8,
    message: []const u8,
    zx_origin: ?*const zx_type_217 = null,
};

pub const value_zx_type_218_655f2c15f8b96113ed59dee46636710e0c7433f1f71d56fc2c400bda5a955e85 = struct {
    candidate: value_zx_type_208_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    table: *const zx_type_50,
    zx_origin: ?*const zx_type_218 = null,
};

pub const value_zx_type_219_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    delta: *const zx_type_50,
    diagnostic: value_zx_type_217_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    id: u32,
    zx_origin: ?*const zx_type_219 = null,
};

pub const value_zx_type_220_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u32,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_220 = null,
};

pub const value_zx_type_221_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    flags: []const bool,
    index: u64,
    native_references: bool,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_221 = null,
};

pub const value_zx_type_222_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    id: u32,
    native_references: bool,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_222 = null,
};

pub const value_zx_type_224_5443cbe39f2296ef486982bb05040a6b5c31305900fd32c8ae6836a1865363f0 = struct {
    candidate: value_zx_type_208_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    state: value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_224 = null,
};

pub const value_zx_type_225_ed4584f19a29320f1f7bfa54b250c4883357e0d1a3a4696179ab103a34ffbd2b = struct {
    enumeration: u64,
    index: u64,
    source: value_zx_type_102_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_225 = null,
};

pub const value_zx_type_226_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    reference: *const zx_type_87,
    source: value_zx_type_102_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_226 = null,
};

pub const value_zx_type_227_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    cache: *const zx_type_104,
    name: []const u8,
    zx_origin: ?*const zx_type_227 = null,
};

pub const value_zx_type_228_1f89c88e8344df3ff0e1ae6aeca43f8d4c75d21269ca1cbbd88f24f6f34f4e80 = struct {
    frame: *const zx_type_106,
    state: value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_228 = null,
};

pub const value_zx_type_229_df36ed4970e5c22881b924bb7578a8314efe0f9cc458dde833d319f0ed756eb4 = struct {
    position: u64,
    source: value_zx_type_102_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_229 = null,
};

pub const value_zx_type_230_7051df2af347117a015c8f3f25e99dae54e378cf29db9dc02b9eaca5f9b82a03 = struct {
    analysis: value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a,
    binding_types: []const u32,
    expected: ?u32,
    zx_origin: ?*const zx_type_230 = null,
};

pub const value_zx_type_231_b7022e5f7e6d6017e6486dabb7679bffcfe40734ccee3cfd445f9f3f9dd5c4b7 = struct {
    candidate: value_zx_type_208_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_231 = null,
};

pub const value_zx_type_232_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    id: u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_232 = null,
};

pub const value_zx_type_233_01927fc72980f9f7e06f02c430cda24b1bfe582ea8131a0ec2f6be4c7b3ca6e4 = struct {
    analysis: value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a,
    types: []const u32,
    zx_origin: ?*const zx_type_233 = null,
};

pub const value_zx_type_234_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    name: []const u8,
    ownership: zx_type_11,
    span_end: u64,
    span_start: u64,
    table: *const zx_type_16,
    type_id: u32,
    zx_origin: ?*const zx_type_234 = null,
};

pub const value_zx_type_235_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    table: *const zx_type_16,
    zx_origin: ?*const zx_type_235 = null,
};

pub const value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    span_end: u64,
    span_start: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_236 = null,
};

pub const value_zx_type_237_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    table: *const zx_type_34,
    zx_origin: ?*const zx_type_237 = null,
};

pub const value_zx_type_240_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    kind: zx_type_23,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    payload: u32,
    table: *const zx_type_34,
    zx_origin: ?*const zx_type_240 = null,
};

pub const value_zx_type_241_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    kind: zx_type_238,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    value: u32,
    zx_origin: ?*const zx_type_241 = null,
};

pub const value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae = struct {
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_242 = null,
};

pub const value_zx_type_243_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol: u32,
    zx_origin: ?*const zx_type_243 = null,
};

pub const value_zx_type_244_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    byte: u8,
    state: u64,
    zx_origin: ?*const zx_type_244 = null,
};

pub const value_zx_type_245_b8f8133d0ed6cc1c9f544c82e720db020bea99055b67224fb5e28d88e5acfbc2 = struct {
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    span: *const zx_type_46,
    zx_origin: ?*const zx_type_245 = null,
};

pub const value_zx_type_246_01927fc72980f9f7e06f02c430cda24b1bfe582ea8131a0ec2f6be4c7b3ca6e4 = struct {
    analysis: value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a,
    names: []const []const u8,
    zx_origin: ?*const zx_type_246 = null,
};

pub const value_zx_type_247_8a0e8171bb34be7cea5536924946825257889020009cc44d8989d27b14418fbd = struct {
    index: u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    target: u32,
    tuple: bool,
    zx_origin: ?*const zx_type_247 = null,
};

pub const value_zx_type_248_c7282ba88a569f47ef80d0b07c5739723b36ca15c27d01bf49b07aee33b7f128 = struct {
    analysis: value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a,
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_248 = null,
};

pub const value_zx_type_249_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct {
    facts: value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    symbol: u32,
    zx_origin: ?*const zx_type_249 = null,
};

pub const value_zx_type_250_c7282ba88a569f47ef80d0b07c5739723b36ca15c27d01bf49b07aee33b7f128 = struct {
    analysis: value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a,
    bindings: []const []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_250 = null,
};

pub const value_zx_type_263_27f6baed02dfb16b8bbeaef695a80d4899de28e19dde605fcd26d176c6e70749 = struct {
    files: []const []const u8,
    input_types: []const u32,
    native_allocators: []const bool,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_inputs: []const ?[]const ?[]const u8,
    native_io: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    native_process: []const bool,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_11,
    zx_origin: ?*const zx_type_263 = null,
};

pub const value_zx_type_267_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731 = struct {
    contracts: []const *const zx_type_255,
    control: []const *const zx_type_22,
    expressions: []const *const zx_type_34,
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_fallible: []const bool,
    native_modules: []const ?u32,
    native_tuples: []const bool,
    output_types: []const u32,
    ownership: []const zx_type_11,
    roots: []const ?u32,
    stores: []const *const zx_type_35,
    zx_origin: ?*const zx_type_267 = null,
};

pub const value_zx_type_268_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    ids: []const u32,
    input_types: []const u32,
    names: []const []const u8,
    namespaces: []const ?[]const u8,
    output_types: []const u32,
    zx_origin: ?*const zx_type_268 = null,
};

pub const value_zx_type_269_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    type_ids: []const ?u32,
    type_names: []const ?[]const u8,
    writable: []const bool,
    zx_origin: ?*const zx_type_269 = null,
};

pub const value_zx_type_270_3a357295bc15378c8d9379bded45bab4c78ce157dc22ada26dc5eacb7e5e2528 = struct {
    aliases: *const zx_type_104,
    function_imports: value_zx_type_268_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    functions: value_zx_type_267_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    nominal_base: value_zx_type_112_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    nominal_origin: value_zx_type_111_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    shared: bool,
    store_bindings: value_zx_type_269_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    store_type_count: u64,
    type_base: *const zx_type_50,
    zx_origin: ?*const zx_type_270 = null,
};

pub const value_zx_type_271_ff841ee250355d3b0bf70949f910b61fd9fdebd46f5d0314015c912305a4d6d4 = struct {
    bytes: []const u8,
    context: value_zx_type_270_3a357295bc15378c8d9379bded45bab4c78ce157dc22ada26dc5eacb7e5e2528,
    file_name: []const u8,
    syntax: value_zx_type_183_3191ede17c96f03fe92fcee2a142bf07dadade62fc1258eb19ab63856e0a826a,
    zx_origin: ?*const zx_type_271 = null,
};

pub const value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f = struct {
    blocks: value_zx_type_164_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    bytes: []const u8,
    tree: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_272 = null,
};

pub const value_zx_type_273_d1d3079bb818786c6de7fe35a1b30dd3ac1d301e4180de5d8f3c6ef6b6a70962 = struct {
    expected: ?u32,
    node: u64,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_273 = null,
};

pub const value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d = struct {
    analysis: value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a,
    input: value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234,
    zx_origin: ?*const zx_type_274 = null,
};

pub const value_zx_type_275_a986431fc03b854e809a69648942c955b0d0576700ff151ca27f5ac1b466e8cc = struct {
    functions: value_zx_type_267_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    imports: value_zx_type_268_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    request: value_zx_type_273_d1d3079bb818786c6de7fe35a1b30dd3ac1d301e4180de5d8f3c6ef6b6a70962,
    zx_origin: ?*const zx_type_275 = null,
};

pub const value_zx_type_276_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_34,
    limit: u64,
    zx_origin: ?*const zx_type_276 = null,
};

pub const value_zx_type_277_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: []const *const zx_type_34,
    native_concurrent: []const bool,
    native_modules: []const ?u32,
    stores: []const *const zx_type_35,
    zx_origin: ?*const zx_type_277 = null,
};

pub const value_zx_type_278_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = struct {
    concurrent: bool,
    functions: value_zx_type_277_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_278 = null,
};

pub const value_zx_type_279_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_279 = null,
};

pub const value_zx_type_280_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    body: u32,
    captures: value_zx_type_279_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    parameters: []const u32,
    zx_origin: ?*const zx_type_280 = null,
};

pub const value_zx_type_281_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    borrows: []const bool,
    symbols: []const ?u32,
    values: []const u32,
    zx_origin: ?*const zx_type_281 = null,
};

pub const value_zx_type_282_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117 = struct {
    callback: value_zx_type_280_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    ignored: ?u32,
    initial: ?u32,
    kind: zx_type_25,
    result_type: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    zx_origin: ?*const zx_type_282 = null,
};

pub const value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct {
    bindings: value_zx_type_281_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    frames: []const *const zx_type_292,
    zx_origin: ?*const zx_type_294 = null,
};

pub const value_zx_type_309_37d199f1b50bfa5590430fb1ebc517221eb0ddef3e4e99045f9c200d682d2ab3 = struct {
    active: u64,
    captures: ?u32,
    depth: u64,
    facts: *const zx_type_37,
    floor: u64,
    zx_origin: ?*const zx_type_309 = null,
};

pub const value_zx_type_331_6652383135ce0d60d191e68b6c98178f0216e42ab6c6b6ba57bc43fe23362021 = struct {
    actions: []const zx_type_297,
    asynchronous: []const *const zx_type_310,
    binaries: []const *const zx_type_300,
    branches: []const *const zx_type_290,
    coercions: []const *const zx_type_298,
    conditionals: []const *const zx_type_301,
    imported: []const *const zx_type_305,
    indices: []const *const zx_type_299,
    iterations: []const *const zx_type_285,
    lists: []const *const zx_type_307,
    methods: []const *const zx_type_306,
    objects: []const *const zx_type_304,
    parallels: []const *const zx_type_311,
    selections: []const *const zx_type_302,
    sequences: []const *const zx_type_303,
    singles: []const u64,
    statements: []const u64,
    switches: []const *const zx_type_291,
    templates: []const *const zx_type_308,
    transforms: []const *const zx_type_283,
    updates: []const *const zx_type_289,
    zx_origin: ?*const zx_type_331 = null,
};

pub const value_zx_type_332_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519 = struct {
    boundary: value_zx_type_309_37d199f1b50bfa5590430fb1ebc517221eb0ddef3e4e99045f9c200d682d2ab3,
    concurrent: []const bool,
    expected: ?u32,
    frames: value_zx_type_331_6652383135ce0d60d191e68b6c98178f0216e42ab6c6b6ba57bc43fe23362021,
    functions: value_zx_type_267_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    imports: value_zx_type_268_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    node: u64,
    phase: zx_type_296,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_332 = null,
};

pub const value_zx_type_333_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    expected: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_333 = null,
};

pub const value_zx_type_334_cf7f91935142e682a287d5d100dd4ce0b0109b30ee54eeca5ee330715975db08 = struct {
    body: u32,
    captures: []const u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    zx_origin: ?*const zx_type_334 = null,
};

pub const value_zx_type_339_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b = struct {
    functions: value_zx_type_267_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_339 = null,
};

pub const value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290 = struct {
    called: *const zx_type_335,
    context: value_zx_type_339_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b,
    frames: []const *const zx_type_337,
    names: []const []const u8,
    sources: []const *const zx_type_338,
    unknown: bool,
    zx_origin: ?*const zx_type_342 = null,
};

pub const value_zx_type_343_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea = struct {
    context: value_zx_type_339_70078ad0c2b32a7a90e4d6295a3adfecc03a8eb207812a93c1a37be05e59198b,
    contracts: *const zx_type_255,
    control: *const zx_type_22,
    expression: u32,
    expressions: *const zx_type_34,
    program: bool,
    root: ?u32,
    stores: bool,
    zx_origin: ?*const zx_type_343 = null,
};

pub const value_zx_type_344_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    control: *const zx_type_22,
    returns: []const bool,
    selection: u64,
    zx_origin: ?*const zx_type_344 = null,
};

pub const value_zx_type_345_5821a6631fd0a2b5d5f68275f533e0b86f2430edbf1471339d13b94e742690d5 = struct {
    control: *const zx_type_22,
    expressions: *const zx_type_34,
    state: value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_345 = null,
};

pub const value_zx_type_346_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    source: u64,
    state: value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_346 = null,
};

pub const value_zx_type_347_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    contracts: *const zx_type_255,
    state: value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_347 = null,
};

pub const value_zx_type_348_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    frame: *const zx_type_337,
    state: value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_348 = null,
};

pub const value_zx_type_349_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    seen: *const zx_type_335,
    zx_origin: ?*const zx_type_349 = null,
};

pub const value_zx_type_350_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    fresh: bool,
    seen: *const zx_type_335,
    zx_origin: ?*const zx_type_350 = null,
};

pub const value_zx_type_351_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expressions: *const zx_type_34,
    index: u64,
    zx_origin: ?*const zx_type_351 = null,
};

pub const value_zx_type_352_9638323d174581190e16ab503293f71b5cdb03fa5c46773baeea6b9588a76bd1 = struct {
    names: []const []const u8,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    type_id: u32,
    zx_origin: ?*const zx_type_352 = null,
};

pub const value_zx_type_353_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    expressions: *const zx_type_34,
    index: u64,
    names: []const []const u8,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_353 = null,
};

pub const value_zx_type_354_1138918a732211e3b3c9493983794961097ca8c4cfab2b18f104ff2fd27f6750 = struct {
    index: u64,
    state: value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_354 = null,
};

pub const value_zx_type_355_61e72feecd2c7ea08919f23f45020799258e07ca40609f3ec3c2a2c121ab638d = struct {
    functions: value_zx_type_267_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_355 = null,
};

pub const value_zx_type_356_c10b56468fcdfc340efd837bc2bb5a1d1abf702877c05f5181a62bc3537de488 = struct {
    concurrent: []const bool,
    first: u64,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol_count: u64,
    zx_origin: ?*const zx_type_356 = null,
};

pub const value_zx_type_357_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    captures: []const u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_357 = null,
};

pub const value_zx_type_358_7e8ae8be50002306e9d0962406982db1fcca8341a5a0201e018f4d4519b03356 = struct {
    body: u32,
    concurrent: []const bool,
    first: u64,
    functions: value_zx_type_267_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol_count: u64,
    zx_origin: ?*const zx_type_358 = null,
};

pub const value_zx_type_359_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct {
    facts: value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    mark: *const zx_type_37,
    zx_origin: ?*const zx_type_359 = null,
};

pub const value_zx_type_360_8a0e8171bb34be7cea5536924946825257889020009cc44d8989d27b14418fbd = struct {
    left: u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    operator: zx_type_27,
    right: u32,
    table: *const zx_type_34,
    zx_origin: ?*const zx_type_360 = null,
};

pub const value_zx_type_361_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    comparison: bool,
    equality: bool,
    logical: bool,
    zx_origin: ?*const zx_type_361 = null,
};

pub const value_zx_type_362_758dce47268ce260391b79fcce19430100f29f81aa06dca556ac6c937c9b34ac = struct {
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    type_id: u32,
    zx_origin: ?*const zx_type_362 = null,
};

pub const value_zx_type_363_d3beea0968cbeae3a086396c9e5ffff3a98358d00a82ff4e47174659d0a5d370 = struct {
    left: u32,
    operator: zx_type_27,
    right: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_363 = null,
};

pub const value_zx_type_364_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    expressions: *const zx_type_34,
    facts: value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    payload: u64,
    truth: bool,
    zx_origin: ?*const zx_type_364 = null,
};

pub const value_zx_type_365_180c8db61327c5ec28c1dd7044b5cf087f6bf11c71b70daa8f83a901fbf86853 = struct {
    condition: u64,
    expressions: *const zx_type_34,
    state: value_zx_type_38_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    truth: bool,
    zx_origin: ?*const zx_type_365 = null,
};

pub const value_zx_type_366_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    left: u32,
    operator: zx_type_27,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_366 = null,
};

pub const value_zx_type_367_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    expected: u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_367 = null,
};

pub const value_zx_type_368_398405e4d778524902904773ea675b0aeac3ad17463e51a805f63f94da7e856a = struct {
    action: zx_type_297,
    work: value_zx_type_332_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519,
    zx_origin: ?*const zx_type_368 = null,
};

pub const value_zx_type_369_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    element: u32,
    list: u32,
    name: []const u8,
    zx_origin: ?*const zx_type_369 = null,
};

pub const value_zx_type_370_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    code: []const u8,
    hints: []const u32,
    kind: zx_type_24,
    message: []const u8,
    replacement: bool,
    zx_origin: ?*const zx_type_370 = null,
};

pub const value_zx_type_371_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    head: u64,
    items: []const *const zx_type_70,
    zx_origin: ?*const zx_type_371 = null,
};

pub const value_zx_type_372_4cc958f044815e7193e188aa8d2b374a7d7b5bdc35e292ff41875ed7f5ad06b2 = struct {
    arguments: []const u32,
    kind: zx_type_24,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    target: u32,
    zx_origin: ?*const zx_type_372 = null,
};

pub const value_zx_type_373_8a0e8171bb34be7cea5536924946825257889020009cc44d8989d27b14418fbd = struct {
    index: u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    target: u32,
    value: u32,
    zx_origin: ?*const zx_type_373 = null,
};

pub const value_zx_type_374_320140e206741eb6a6c49f977db0f2408310cbbb6bc0068879af58c7913c6479 = struct {
    kind: zx_type_24,
    replacement: bool,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    values: []const u32,
    zx_origin: ?*const zx_type_374 = null,
};

pub const value_zx_type_375_1d596865a15a49bb75fc16c90a7dd21003bff94dbdf67563e2b022d273d3f10d = struct {
    expected: ?u32,
    types: value_zx_type_114_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_375 = null,
};

pub const value_zx_type_376_946d687d0c4ea3809039d5317ed7d2aba883a417cff00079d9283aa71ce54d7c = struct {
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: *const zx_type_86,
    scope_start: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_376 = null,
};

pub const value_zx_type_377_6c42e587ea37fcf9cebd3363bae951bc8d27c8514466872e4d2dccf9f350e428 = struct {
    diagnostic: *const zx_type_58,
    id: u32,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    zx_origin: ?*const zx_type_377 = null,
};

pub const value_zx_type_378_8aa5028c1fa4881a2d1ecd5dd1891a11196fbe0a82cd5a6fb884bc582c9c12b3 = struct {
    frame: u32,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    zx_origin: ?*const zx_type_378 = null,
};

pub const value_zx_type_379_f03d027d90539c51366482b018ae66dc2f472151ba6834d7ee9d5e68f39bc19f = struct {
    node: u64,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    types: []const u32,
    zx_origin: ?*const zx_type_379 = null,
};

pub const value_zx_type_380_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    body: u64,
    frame: u32,
    parameters: []const u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_380 = null,
};

pub const value_zx_type_381_031052d85d43fe0b78cc9d16de0b727534577b1c00a37aff1c2ad91211744f4a = struct {
    expected: ?u32,
    kind: zx_type_25,
    second: ?u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    zx_origin: ?*const zx_type_381 = null,
};

pub const value_zx_type_382_5de783d1563b20987c6dd1466aa53bc335bc49cdf5213bb1c1cc310c808cd9fd = struct {
    body: ?u32,
    parameters: []const u32,
    result: u32,
    zx_origin: ?*const zx_type_382 = null,
};

pub const value_zx_type_383_398405e4d778524902904773ea675b0aeac3ad17463e51a805f63f94da7e856a = struct {
    name: []const u8,
    work: value_zx_type_332_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519,
    zx_origin: ?*const zx_type_383 = null,
};

pub const value_zx_type_384_8a0e8171bb34be7cea5536924946825257889020009cc44d8989d27b14418fbd = struct {
    condition: u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    no: u32,
    table: *const zx_type_34,
    yes: u32,
    zx_origin: ?*const zx_type_384 = null,
};

pub const value_zx_type_385_208aa70893ffd89deeb12476fa37935a6d473e7b89bb1e3e05e8d4835750280d = struct {
    facts: value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    symbol: u32,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    type_id: u32,
    zx_origin: ?*const zx_type_385 = null,
};

pub const value_zx_type_386_66dd4c90d45184bc766e20e49e9a6da896057c0f8267927eca5c31ac05ae261e = struct {
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    zx_origin: ?*const zx_type_386 = null,
};

pub const value_zx_type_387_63d147828f65d3607200b5ba26d827f7ceddb4bcc75a4c77c08a3e4e2680fe3d = struct {
    node: u64,
    path: []const u8,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_387 = null,
};

pub const value_zx_type_388_a5e97b5d148979078fb526bf8b0a3f2e3879dc81aae4d331b8d02ba4a40dbdbf = struct {
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    node: u64,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_388 = null,
};

pub const value_zx_type_389_b697f8130174a859aa6986a4ae35912f4dbf2e3d0251d6c8876d483068ea65bd = struct {
    symbol: ?u32,
    unit: bool,
    zx_origin: ?*const zx_type_389 = null,
};

pub const value_zx_type_392_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a = struct {
    imports: value_zx_type_268_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_392 = null,
};

pub const value_zx_type_394_d6f05b6a7468cda4e0cb0471293b5bc9c924753364f601fd75acaf11c9c13f34 = struct {
    context: value_zx_type_392_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a,
    frames: []const *const zx_type_391,
    result: ?u32,
    zx_origin: ?*const zx_type_394 = null,
};

pub const value_zx_type_395_c4fdb933f579107fe690837d45be4bfbc2ab7010fb3d9757ce268ea44cbe7a71 = struct {
    callee: u64,
    context: value_zx_type_392_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a,
    zx_origin: ?*const zx_type_395 = null,
};

pub const value_zx_type_396_e8147ecb68420dc730dce1b61adbbf549a04cf8791e4c2684653218e80bf9ade = struct {
    context: value_zx_type_392_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a,
    node: u64,
    zx_origin: ?*const zx_type_396 = null,
};

pub const value_zx_type_397_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct {
    handled: bool,
    type_id: ?u32,
    zx_origin: ?*const zx_type_397 = null,
};

pub const value_zx_type_398_a4e28b9aa9bec82279c7697dfd19ce9bb7344a5a9111c1bc7390c1d7bb70d5e6 = struct {
    node: u64,
    work: value_zx_type_394_d6f05b6a7468cda4e0cb0471293b5bc9c924753364f601fd75acaf11c9c13f34,
    zx_origin: ?*const zx_type_398 = null,
};

pub const value_zx_type_399_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    floating: bool,
    separators: bool,
    zx_origin: ?*const zx_type_399 = null,
};

pub const value_zx_type_400_63d147828f65d3607200b5ba26d827f7ceddb4bcc75a4c77c08a3e4e2680fe3d = struct {
    left: u64,
    right: u64,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_400 = null,
};

pub const value_zx_type_401_d1334bc45f95292594200d1d386af54ad2694049d5073c61166233cf0c59cca5 = struct {
    node: u64,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_401 = null,
};

pub const value_zx_type_402_857eb865ac7e63d23c084d39c9d182e776e834af701d182a80c35ea041ec42c4 = struct {
    context: value_zx_type_392_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a,
    frame: *const zx_type_391,
    type_id: u32,
    zx_origin: ?*const zx_type_402 = null,
};

pub const value_zx_type_403_d483752daf6f2499abf5821d84984c199ae0e80e071318f70d6eaad6c9a6f411 = struct {
    context: value_zx_type_392_47545a5d094c245700a0c365a3bd0406ed90df3c9ed16bcfd53cc682d4f5373a,
    expected: ?u32,
    node: u64,
    zx_origin: ?*const zx_type_403 = null,
};

pub const value_zx_type_404_4cc958f044815e7193e188aa8d2b374a7d7b5bdc35e292ff41875ed7f5ad06b2 = struct {
    argument: u32,
    function_id: u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    stores: []const u32,
    table: *const zx_type_34,
    zx_origin: ?*const zx_type_404 = null,
};

pub const value_zx_type_405_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    optional: bool,
    table: *const zx_type_34,
    zx_origin: ?*const zx_type_405 = null,
};

pub const value_zx_type_406_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    kind: zx_type_239,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    values: []const u32,
    zx_origin: ?*const zx_type_406 = null,
};

pub const value_zx_type_407_fd7a6dc827118410c36e21cce8ddad7179973d8786aa21dfc2a8c2f51f48f835 = struct {
    body: u32,
    condition: u32,
    condition_parameter: u32,
    initial: u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    parameter: u32,
    postcondition: bool,
    table: *const zx_type_34,
    zx_origin: ?*const zx_type_407 = null,
};

pub const value_zx_type_408_6d8b876cf043ee5d5e88ca2f8429bbfe364811df5a12532f9673eae08f9ea7be = struct {
    node: u64,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    type_id: u32,
    updating: bool,
    zx_origin: ?*const zx_type_408 = null,
};

pub const value_zx_type_409_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    body: u64,
    context: *const zx_type_284,
    parameter: u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_409 = null,
};

pub const value_zx_type_410_8aa5028c1fa4881a2d1ecd5dd1891a11196fbe0a82cd5a6fb884bc582c9c12b3 = struct {
    context: *const zx_type_284,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    zx_origin: ?*const zx_type_410 = null,
};

pub const value_zx_type_411_cf2c185f503109ab892b84b39da09b633a610070b4dacaa8d4793767c39471d5 = struct {
    conditions: []const u32,
    fallback: u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    results: []const u32,
    subject: ?u32,
    table: *const zx_type_34,
    zx_origin: ?*const zx_type_411 = null,
};

pub const value_zx_type_412_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    entries: *const zx_type_295,
    name: []const u8,
    value: u32,
    zx_origin: ?*const zx_type_412 = null,
};

pub const value_zx_type_413_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    entries: *const zx_type_295,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_413 = null,
};

pub const value_zx_type_414_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    entries: *const zx_type_295,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_414 = null,
};

pub const value_zx_type_415_4cc958f044815e7193e188aa8d2b374a7d7b5bdc35e292ff41875ed7f5ad06b2 = struct {
    evaluation: []const u32,
    indices: []const u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    values: []const u32,
    zx_origin: ?*const zx_type_415 = null,
};

pub const value_zx_type_416_f61a34c050d4f456cdc1f1b11a4488c1a69373c43cb0a50164ff3b85629ae16c = struct {
    entries: *const zx_type_295,
    evaluation: []const u32,
    hint: ?u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_416 = null,
};

pub const value_zx_type_417_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    entries: *const zx_type_295,
    evaluation: []const u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_417 = null,
};

pub const value_zx_type_418_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    fields: []const ?u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    tasks: []const u32,
    zx_origin: ?*const zx_type_418 = null,
};

pub const value_zx_type_419_de45a800d67dbd5a954a7ea2592b79ae8578b35193363bc4e40f5e0050e78b60 = struct {
    functions: value_zx_type_267_c56807e0f0cdb5406e79a37c212d9a7e2faba626a0ecfdd2d4efd8e29d522731,
    operand: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_419 = null,
};

pub const value_zx_type_420_514b8247d8ac45dc9a48b26ab84281962bbd77a9d5481b83c41f75eb0f777c3e = struct {
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    operand: u32,
    operator: zx_type_26,
    table: *const zx_type_34,
    zx_origin: ?*const zx_type_420 = null,
};

pub const value_zx_type_421_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    negative: bool,
    operand: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_421 = null,
};

pub const value_zx_type_422_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    name: *const zx_type_86,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    zx_origin: ?*const zx_type_422 = null,
};

pub const value_zx_type_423_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    index: u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    target: u32,
    zx_origin: ?*const zx_type_423 = null,
};

pub const value_zx_type_424_c10b56468fcdfc340efd837bc2bb5a1d1abf702877c05f5181a62bc3537de488 = struct {
    index: u32,
    index_span: *const zx_type_46,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    zx_origin: ?*const zx_type_424 = null,
};

pub const value_zx_type_425_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    zx_origin: ?*const zx_type_425 = null,
};

pub const value_zx_type_426_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    cancellation: bool,
    operand: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_426 = null,
};

pub const value_zx_type_427_8c1d402feed71d5be501dd118718c8941180b5b47dbfeceb6cb3fb71882a9add = struct {
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: *const zx_type_86,
    scope_start: u64,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    value: u32,
    zx_origin: ?*const zx_type_427 = null,
};

pub const value_zx_type_428_071bfa4a6872a664aae79520a5231728ab2c1ead6d3e44b0c51bf20b4067b027 = struct {
    diagnostic: *const zx_type_58,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    symbol: u32,
    zx_origin: ?*const zx_type_428 = null,
};

pub const value_zx_type_429_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    err: u32,
    facts: value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: u32,
    zx_origin: ?*const zx_type_429 = null,
};

pub const value_zx_type_430_073d891ba45095e5915c165198921d39ae001c11a900ba5941237395e3848750 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_34,
    facts: value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: ?u32,
    value: u64,
    zx_origin: ?*const zx_type_430 = null,
};

pub const value_zx_type_431_c5dd19f4e7f36f068d5a7a3ffb0d98e2195433b7ead24ca3660081c76dc44acf = struct {
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: *const zx_type_86,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    zx_origin: ?*const zx_type_431 = null,
};

pub const value_zx_type_432_b7b2ab1b57db04a2d9173a45213e4ebf3682ff85da6e9f0f4545139fbb3fa85b = struct {
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    value: u32,
    zx_origin: ?*const zx_type_432 = null,
};

pub const value_zx_type_433_071bfa4a6872a664aae79520a5231728ab2c1ead6d3e44b0c51bf20b4067b027 = struct {
    diagnostic: *const zx_type_58,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    value: u32,
    zx_origin: ?*const zx_type_433 = null,
};

pub const value_zx_type_434_e5a82e07a2f8fa078df5034296876c7e922c6afafdc6dc91c02ffcd9117e463d = struct {
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    statement: u64,
    value: u32,
    zx_origin: ?*const zx_type_434 = null,
};

pub const value_zx_type_435_c558d374130410987b090947fa981755686fb618962601d0de6c2613a44c4785 = struct {
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_435 = null,
};

pub const value_zx_type_436_1a6760d00bf1c9003cbcfb5abdde768513d5a3da8c714d4e24fc2174f9a67d14 = struct {
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    value: u32,
    zx_origin: ?*const zx_type_436 = null,
};

pub const value_zx_type_437_ef418fd216c53fd927fb13f77762d8888382f3c1957ef5c6ba04865917651a2d = struct {
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    span: *const zx_type_46,
    value: u32,
    zx_origin: ?*const zx_type_437 = null,
};

pub const value_zx_type_438_70368df1a566c9de055a94a3e9adf4361ddab8e71140bdb84b7925d6f0a19d05 = struct {
    diagnostic: *const zx_type_58,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    zx_origin: ?*const zx_type_438 = null,
};

pub const value_zx_type_439_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    head: u64,
    items: []const *const zx_type_70,
    zx_origin: ?*const zx_type_439 = null,
};

pub const value_zx_type_440_7b8b63d14d9fdc158cc85548dfa2416c1d843e86616a3cc0633f7b8ca55231de = struct {
    block: u64,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    state_symbol: u32,
    tree: value_zx_type_164_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_440 = null,
};

pub const value_zx_type_441_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expressions: *const zx_type_34,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_441 = null,
};

pub const value_zx_type_442_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    previous: []const u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_442 = null,
};

pub const value_zx_type_443_ed2ab87d2bb47c97942d4ee504ffba775c1edbfbfa8ebf1e4e97e5cf49214553 = struct {
    read_value: bool,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    state_symbol: u32,
    target: u32,
    zx_origin: ?*const zx_type_443 = null,
};

pub const value_zx_type_445_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    diagnostic: *const zx_type_58,
    frames: []const *const zx_type_286,
    zx_origin: ?*const zx_type_445 = null,
};

pub const value_zx_type_446_29b8bb2c9220c4b8f09be5148fdae78d6fe459dc123072bc4d45410b5a846b96 = struct {
    read_value: bool,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    state_symbol: u32,
    target: u32,
    zx_origin: ?*const zx_type_446 = null,
};

pub const value_zx_type_447_67fdbd174b3a8e88ef9b945e32fb70a796e4af2ede9a634500cb0b7c6b54ad6a = struct {
    places: []const *const zx_type_287,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_447 = null,
};

pub const value_zx_type_448_8f0278930ba6adb4eb4098f36d8f2cdeec2915ef557ad5c3bd4f7b2c6c11f572 = struct {
    parent: u32,
    selected: u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    tuple: bool,
    value: u32,
    zx_origin: ?*const zx_type_448 = null,
};

pub const value_zx_type_449_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    places: []const *const zx_type_287,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_449 = null,
};

pub const value_zx_type_450_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    value: []const u8,
    zx_origin: ?*const zx_type_450 = null,
};

pub const value_zx_type_451_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    source: []const u8,
    template: bool,
    zx_origin: ?*const zx_type_451 = null,
};

pub const value_zx_type_452_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    source: []const u8,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    template: bool,
    zx_origin: ?*const zx_type_452 = null,
};

pub const value_zx_type_453_c10b56468fcdfc340efd837bc2bb5a1d1abf702877c05f5181a62bc3537de488 = struct {
    name: []const u8,
    ownership: zx_type_11,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    type_id: u32,
    zx_origin: ?*const zx_type_453 = null,
};

pub const value_zx_type_454_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae = struct {
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol: u32,
    zx_origin: ?*const zx_type_454 = null,
};

pub const value_zx_type_455_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e = struct {
    bindings: value_zx_type_281_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    source: u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_455 = null,
};

pub const value_zx_type_456_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    value: bool,
    zx_origin: ?*const zx_type_456 = null,
};

pub const value_zx_type_457_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: bool,
    zx_origin: ?*const zx_type_457 = null,
};

pub const value_zx_type_458_514b8247d8ac45dc9a48b26ab84281962bbd77a9d5481b83c41f75eb0f777c3e = struct {
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    negative: bool,
    table: *const zx_type_34,
    value: u64,
    zx_origin: ?*const zx_type_458 = null,
};

pub const value_zx_type_459_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u64,
    zx_origin: ?*const zx_type_459 = null,
};

pub const value_zx_type_460_8115a2d724b597ff41263498f187c33ab1f087573c7d9a86c7ce96ceb5c8795f = struct {
    initial: ?u32,
    kind: zx_type_25,
    result_type: u32,
    source: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_460 = null,
};

pub const value_zx_type_461_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    fields: *const zx_type_295,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_461 = null,
};

pub const value_zx_type_462_d4b5a97c0c455b86538e915308a1e66a6324646e5615638d4a8cb50134e354c4 = struct {
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    values: []const u32,
    zx_origin: ?*const zx_type_462 = null,
};

pub const value_zx_type_463_7da9860be73e1d08e73da929e35fdaf7b5e10e03f0836665c51e514d78561a02 = struct {
    captures: []const u32,
    initial: ?u32,
    kind: zx_type_25,
    result: u32,
    source: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_463 = null,
};

pub const value_zx_type_464_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    initial: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_464 = null,
};

pub const value_zx_type_465_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    condition_parameter: u32,
    parameter: u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_465 = null,
};

pub const value_zx_type_466_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    kind: zx_type_25,
    parameter: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_466 = null,
};

pub const value_zx_type_467_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be = struct {
    callback: value_zx_type_280_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    kind: zx_type_25,
    parameter: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_467 = null,
};

pub const value_zx_type_468_a77e4162e607846786e14298a59c2e743a9752ef2fe6c98ae39887af0965c62c = struct {
    bindings: value_zx_type_281_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    current: u32,
    index: u32,
    item: u32,
    previous: u32,
    source: u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_468 = null,
};

pub const value_zx_type_469_ed2ab87d2bb47c97942d4ee504ffba775c1edbfbfa8ebf1e4e97e5cf49214553 = struct {
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    target: u32,
    value: u32,
    zx_origin: ?*const zx_type_469 = null,
};

pub const value_zx_type_470_6bd979ddc38e9089ff343580aac7bbd290f506083ba1a522db596260b01dd22c = struct {
    item: u32,
    kind: zx_type_25,
    previous: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_470 = null,
};

pub const value_zx_type_471_5cbbc1e9c27f413358ca0364e5d2761d90343019c7ebd851830bd8b4023d818f = struct {
    captures: bool,
    current: u32,
    index: u32,
    result: u32,
    source: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_471 = null,
};

pub const value_zx_type_472_e71f3c44de88c731e7dbd31a1c034dc4e45cf9665e42d098bb8ba1b5ab878432 = struct {
    borrows: []const bool,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    result: u32,
    symbols: []const ?u32,
    table: *const zx_type_34,
    values: []const u32,
    zx_origin: ?*const zx_type_472 = null,
};

pub const value_zx_type_473_6d20ea482b833343b6028f7ee62eab338d8b454ae1dc5d197ef5c4b0547d062a = struct {
    bindings: value_zx_type_281_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    current: u32,
    result: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_473 = null,
};

pub const value_zx_type_474_02fc6614916cf53341130ecc0059ef28f684d013009cec2774f9ca5992c86c75 = struct {
    bindings: value_zx_type_281_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    body: u32,
    condition: u32,
    condition_parameter: u32,
    initial: u32,
    parameter: u32,
    result_type: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_474 = null,
};

pub const value_zx_type_475_96d93c32fedaebeb2e4335c6d4d02fbd166df43f1d9b9d167683516e6395793b = struct {
    captures: value_zx_type_41_386c6731c19530fd8432acc84ff31b97d6ba880a96c10f7bdfa1616ee45da0f0,
    frame: u32,
    zx_origin: ?*const zx_type_475 = null,
};

pub const value_zx_type_476_5cbbc1e9c27f413358ca0364e5d2761d90343019c7ebd851830bd8b4023d818f = struct {
    body: u32,
    frame: u32,
    kind: zx_type_25,
    parameters: []const u32,
    result_type: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_476 = null,
};

pub const value_zx_type_477_428e5f177681a4ece7b981df4c9b9917c0d51dd97564d93b590ba699d90f2b09 = struct {
    callback: value_zx_type_280_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    result_type: u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_477 = null,
};

pub const value_zx_type_478_8cc4942feb3b1fbbdb34610cb34c8018caeefae663b336ddcaf49c9715307c10 = struct {
    captures: value_zx_type_41_386c6731c19530fd8432acc84ff31b97d6ba880a96c10f7bdfa1616ee45da0f0,
    frame: u32,
    source: u32,
    target: u32,
    value: u32,
    zx_origin: ?*const zx_type_478 = null,
};

pub const value_zx_type_479_6393b1ac4c4256c8e70334e24894634855403fe8966d04dc252b47af11666264 = struct {
    captures: value_zx_type_41_386c6731c19530fd8432acc84ff31b97d6ba880a96c10f7bdfa1616ee45da0f0,
    frame: u32,
    source: u32,
    zx_origin: ?*const zx_type_479 = null,
};

pub const value_zx_type_480_20ed35077270de2cfdcf92021bffc324c14e6be839605ac8935376376d9b2b9e = struct {
    frame: u32,
    source: u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_480 = null,
};

pub const value_zx_type_481_2bcfb17f8b5ada61753c7081b6d0a8994c8d4f122d1680941f810eb98e83ddca = struct {
    frame: u32,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    zx_origin: ?*const zx_type_481 = null,
};

pub const value_zx_type_482_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    name: *const zx_type_86,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_482 = null,
};

pub const value_zx_type_483_74ffaeb805922b745ff90f54cea71a77e4a1cff9fb0b01f504a23a5a4c263f8a = struct {
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol: ?u32,
    zx_origin: ?*const zx_type_483 = null,
};

pub const value_zx_type_484_cc2662a39a44280a9cc0900a7644cc7e5d856b6b16e6eed126424914cce8abd9 = struct {
    expected: ?u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_484 = null,
};

pub const value_zx_type_485_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    table: *const zx_type_34,
    value: f64,
    zx_origin: ?*const zx_type_485 = null,
};

pub const value_zx_type_486_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    digit: u64,
    limbs: []const u64,
    zx_origin: ?*const zx_type_486 = null,
};

pub const value_zx_type_487_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    limbs: []const u64,
    overflow: bool,
    zx_origin: ?*const zx_type_487 = null,
};

pub const value_zx_type_488_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    significant: u64,
    trailing: u64,
    zx_origin: ?*const zx_type_488 = null,
};

pub const value_zx_type_489_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    bytes: []const u8,
    precision: u64,
    zx_origin: ?*const zx_type_489 = null,
};

pub const value_zx_type_492_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    bytes: []const u8,
    negative: bool,
    single: bool,
    zx_origin: ?*const zx_type_492 = null,
};

pub const value_zx_type_493_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    message: []const u8,
    value: f64,
    zx_origin: ?*const zx_type_493 = null,
};

pub const value_zx_type_494_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    negative: bool,
    zx_origin: ?*const zx_type_494 = null,
};

pub const value_zx_type_495_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    floating: bool,
    id: u32,
    integer: bool,
    signed: bool,
    zx_origin: ?*const zx_type_495 = null,
};

pub const value_zx_type_496_402fa3ee9dab64c0be5141e52e0d49aef3ff722a43fc6ee1347ed09435774922 = struct {
    floating: f64,
    integer: u64,
    message: []const u8,
    target: value_zx_type_495_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_496 = null,
};

pub const value_zx_type_497_5de783d1563b20987c6dd1466aa53bc335bc49cdf5213bb1c1cc310c808cd9fd = struct {
    expected: ?u32,
    floating: bool,
    negative: bool,
    zx_origin: ?*const zx_type_497 = null,
};

pub const value_zx_type_498_5de783d1563b20987c6dd1466aa53bc335bc49cdf5213bb1c1cc310c808cd9fd = struct {
    expected: ?u32,
    negative: bool,
    source: []const u8,
    zx_origin: ?*const zx_type_498 = null,
};

pub const value_zx_type_499_ebd7909577121487cee25f683f0a438ae6c5ac0acdf76a3ad6d079c94f8e07d5 = struct {
    expected: ?u32,
    negative: bool,
    source: []const u8,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_499 = null,
};

pub const value_zx_type_500_4a95a80a22abf19024e87679087d49375865ea3a9a1d6f11df28c643cd2bf19f = struct {
    node: u64,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_500 = null,
};

pub const value_zx_type_501_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    slot: u32,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_501 = null,
};

pub const value_zx_type_502_c4687b451029bc752a34492032f763837140be11707ee5c293df7514277d4b06 = struct {
    name: []const u8,
    types: value_zx_type_114_6463e807311dd1d90047d5f57bcc4c385f2ec895c526c3dd9afd2ba11a5069e7,
    zx_origin: ?*const zx_type_502 = null,
};

pub const value_zx_type_503_c10b56468fcdfc340efd837bc2bb5a1d1abf702877c05f5181a62bc3537de488 = struct {
    error_member: bool,
    name: *const zx_type_86,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    type_id: u32,
    zx_origin: ?*const zx_type_503 = null,
};

pub const value_zx_type_504_4fa39ae4b3818fe82b441b9ff0fab0ef61fac8155f5719f07b7c9207c0d82355 = struct {
    handled: bool,
    result: value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae,
    zx_origin: ?*const zx_type_504 = null,
};

pub const value_zx_type_505_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    found: bool,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_505 = null,
};

pub const value_zx_type_506_d6e75a67ef3ff977d850655cf9d97725e7186d6275235af73e7042cd0fa75ba2 = struct {
    imports: value_zx_type_268_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    name: []const u8,
    namespace: ?[]const u8,
    zx_origin: ?*const zx_type_506 = null,
};

pub const value_zx_type_507_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    index: u64,
    known_namespace: bool,
    zx_origin: ?*const zx_type_507 = null,
};

pub const value_zx_type_509_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1 = struct {
    index: u64,
    route: zx_type_508,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_509 = null,
};

pub const value_zx_type_510_2c9e656b34818e8ea4d644375dcec12913bfb4a556cf3342b7be1fc9100ea365 = struct {
    imports: value_zx_type_268_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    name: *const zx_type_86,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_510 = null,
};

pub const value_zx_type_511_48a506a01538af1e5c678d6cbd5b59ad6af05a7cddb3962430a08d42a64a6e94 = struct {
    imports: value_zx_type_268_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    node: u64,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_511 = null,
};

pub const value_zx_type_512_398405e4d778524902904773ea675b0aeac3ad17463e51a805f63f94da7e856a = struct {
    index: u64,
    work: value_zx_type_332_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519,
    zx_origin: ?*const zx_type_512 = null,
};

pub const value_zx_type_513_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    condition: u64,
    diagnostic: *const zx_type_58,
    initial: u64,
    postcondition: bool,
    step: u64,
    zx_origin: ?*const zx_type_513 = null,
};

pub const value_zx_type_514_b7b2ab1b57db04a2d9173a45213e4ebf3682ff85da6e9f0f4545139fbb3fa85b = struct {
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    span: *const zx_type_46,
    zx_origin: ?*const zx_type_514 = null,
};

pub const value_zx_type_515_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    reference: u64,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_515 = null,
};

pub const value_zx_type_516_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    first: u64,
    table: *const zx_type_22,
    zx_origin: ?*const zx_type_516 = null,
};

pub const value_zx_type_517_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    table: *const zx_type_22,
    zx_origin: ?*const zx_type_517 = null,
};

pub const value_zx_type_518_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    kind: zx_type_17,
    payload: u32,
    table: *const zx_type_22,
    zx_origin: ?*const zx_type_518 = null,
};

pub const value_zx_type_519_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    symbol: u32,
    table: *const zx_type_22,
    value: u32,
    zx_origin: ?*const zx_type_519 = null,
};

pub const value_zx_type_520_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct {
    table: *const zx_type_22,
    value: ?u32,
    zx_origin: ?*const zx_type_520 = null,
};

pub const value_zx_type_521_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    ownership: []const zx_type_11,
    stores: []const *const zx_type_35,
    zx_origin: ?*const zx_type_521 = null,
};

pub const value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695 = struct {
    body: ?u32,
    control: *const zx_type_22,
    expressions: *const zx_type_34,
    functions: value_zx_type_521_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    symbols: *const zx_type_16,
    type_only: bool,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_522 = null,
};

pub const value_zx_type_523_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec = struct {
    id: u64,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_523 = null,
};

pub const value_zx_type_524_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expression: u64,
    expressions: *const zx_type_34,
    index: u64,
    zx_origin: ?*const zx_type_524 = null,
};

pub const value_zx_type_525_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expression: u64,
    found: bool,
    zx_origin: ?*const zx_type_525 = null,
};

pub const value_zx_type_526_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expression: u64,
    expressions: *const zx_type_34,
    locals: []const bool,
    zx_origin: ?*const zx_type_526 = null,
};

pub const value_zx_type_527_e05028d9f2b1d7792bfed137694ab8e6051e740db09be899cd5c3c4ff8b94544 = struct {
    expression: u64,
    program: value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    zx_origin: ?*const zx_type_527 = null,
};

pub const value_zx_type_528_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u64,
    first: []const u64,
    symbols: []const u64,
    zx_origin: ?*const zx_type_528 = null,
};

pub const value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u64,
    field_indices: []const u64,
    parents: []const u64,
    references: []const bool,
    siblings: []const u64,
    types: []const u32,
    zx_origin: ?*const zx_type_531 = null,
};

pub const value_zx_type_533_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d = struct {
    id: u64,
    layout: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    operation: zx_type_530,
    states: []const zx_type_529,
    value: zx_type_529,
    zx_origin: ?*const zx_type_533 = null,
};

pub const value_zx_type_534_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u64,
    first: []const u64,
    positions: []const u64,
    zx_origin: ?*const zx_type_534 = null,
};

pub const value_zx_type_535_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937 = struct {
    cached: value_zx_type_534_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    heads: []const u64,
    next: []const u64,
    tree: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_535 = null,
};

pub const value_zx_type_536_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d = struct {
    cached: value_zx_type_534_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    tree: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    values: []const u64,
    zx_origin: ?*const zx_type_536 = null,
};

pub const value_zx_type_538_767b69074202a272a12100b84e23109da965767802298cfb5e4fed280635514e = struct {
    program: value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    zx_origin: ?*const zx_type_538 = null,
};

pub const value_zx_type_539_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capacity: u64,
    field: u64,
    parent: u64,
    zx_origin: ?*const zx_type_539 = null,
};

pub const value_zx_type_540_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    fields: []const u64,
    parents: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_540 = null,
};

pub const value_zx_type_541_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    field: u64,
    parent: u64,
    zx_origin: ?*const zx_type_541 = null,
};

pub const value_zx_type_542_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_542 = null,
};

pub const value_zx_type_543_0093e0155d66cb511a94de9e5d1d5b400f76ae0078e86bc776bc6b8934ee5924 = struct {
    index: value_zx_type_540_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    key: value_zx_type_541_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_543 = null,
};

pub const value_zx_type_544_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    expressions: *const zx_type_34,
    id: u64,
    zx_origin: ?*const zx_type_544 = null,
};

pub const value_zx_type_545_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u32,
    target: u64,
    zx_origin: ?*const zx_type_545 = null,
};

pub const value_zx_type_547_66dcc527b00a87c3c2a5109b4a3924ac4c4d43c09f84caa10ed23e5ea63930cf = struct {
    active: bool,
    ancestor: u64,
    bindings: []const u64,
    cached: value_zx_type_534_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    capacity: u64,
    child_expression: u64,
    children: []const u64,
    cursor: u64,
    direct: bool,
    expression: u64,
    field_indices: []const u64,
    heads: []const u64,
    key_fields: []const u64,
    key_parents: []const u64,
    next: []const u64,
    parent: u64,
    parents: []const u64,
    path: []const u64,
    path_index: u64,
    phase: zx_type_546,
    place_types: []const u32,
    program: value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    record: u64,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_547 = null,
};

pub const value_zx_type_548_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    first: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_548 = null,
};

pub const value_zx_type_549_08ae4a5c88157bebdfb632c2939fd9a2fdb6e48e4cc60655b08697fb2d0015fb = struct {
    program: value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    roots: value_zx_type_535_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937,
    zx_origin: ?*const zx_type_549 = null,
};

pub const value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u64,
    count: []const u64,
    first: []const u64,
    shells: []const zx_type_529,
    states: []const zx_type_529,
    types: []const u32,
    zx_origin: ?*const zx_type_550 = null,
};

pub const value_zx_type_551_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    fact: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_551 = null,
};

pub const value_zx_type_552_461a038225996c015433bf0a5fb2c9e6a36f43e598f85eccd7a2eee1e984e893 = struct {
    fact: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    reference: bool,
    zx_origin: ?*const zx_type_552 = null,
};

pub const value_zx_type_553_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    index: u64,
    type_id: u32,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_553 = null,
};

pub const value_zx_type_554_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    left: zx_type_529,
    right: zx_type_529,
    zx_origin: ?*const zx_type_554 = null,
};

pub const value_zx_type_555_df87d4e4c94482fd017e977a114eba826861ac6af356c343aea16855cac7c373 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    shell: zx_type_529,
    type_id: u32,
    zx_origin: ?*const zx_type_555 = null,
};

pub const value_zx_type_556_b1b23fbb7680b8cb1b3dadbfa986aa274ef1483cb6efee44a47ca580481a8e23 = struct {
    children: []const u64,
    count: u64,
    first: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    shell: zx_type_529,
    type_id: u32,
    zx_origin: ?*const zx_type_556 = null,
};

pub const value_zx_type_557_48e6facbc67e19905cc5d1979cc7988969acfd6e4bae54b78cb7684de3ebbbab = struct {
    fact: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    type_id: u32,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_557 = null,
};

pub const value_zx_type_558_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0 = struct {
    facts: []const u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    states: []const zx_type_529,
    zx_origin: ?*const zx_type_558 = null,
};

pub const value_zx_type_559_c7b60c00d717dc61a2a9736408d32321057c2522adc791850c9eae52b70181a8 = struct {
    fact: u64,
    id: u64,
    layout: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    references: []const bool,
    storage: value_zx_type_558_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_559 = null,
};

pub const value_zx_type_560_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capacity: u64,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_560 = null,
};

pub const value_zx_type_562_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    left: []const u64,
    right: []const u64,
    slots: []const u64,
    values: []const u64,
    zx_origin: ?*const zx_type_562 = null,
};

pub const value_zx_type_563_9e473f196db28165f17fa02012d877e38b20b2fdd7fbf0bd932a3b8513569fa0 = struct {
    cache: value_zx_type_562_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_563 = null,
};

pub const value_zx_type_564_03d90fa68e4e68b677112113e76ce3e9fb7563db5d750228bd60f891663f8e20 = struct {
    cache: value_zx_type_562_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    left: u64,
    right: u64,
    value: u64,
    zx_origin: ?*const zx_type_564 = null,
};

pub const value_zx_type_565_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const u64,
    zx_origin: ?*const zx_type_565 = null,
};

pub const value_zx_type_566_0e14e5cdabbe38cb1c79f91fab9c5efb4effe8af60678a6b3d272d5ab52e2387 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    references: []const bool,
    shell: zx_type_529,
    type_id: u32,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_566 = null,
};

pub const value_zx_type_567_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    action: zx_type_561,
    left: zx_type_529,
    right: zx_type_529,
    zx_origin: ?*const zx_type_567 = null,
};

pub const value_zx_type_568_ec908cc2db7bcb55b295ba38c99a7117d8d48d2fedde568fd60bfa6cb2ebc669 = struct {
    action: zx_type_561,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    left: u64,
    references: []const bool,
    right: u64,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_568 = null,
};

pub const value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    facts: []const u64,
    memo: []const u64,
    memo_count: []const u64,
    memo_first: []const u64,
    state_count: []const u64,
    state_first: []const u64,
    zx_origin: ?*const zx_type_571 = null,
};

pub const value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d = struct {
    facts: []const u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memo: []const u64,
    states: []const zx_type_529,
    trail: []const u64,
    zx_origin: ?*const zx_type_572 = null,
};

pub const value_zx_type_573_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf = struct {
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    snapshots: value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_573 = null,
};

pub const value_zx_type_574_c2b2345f31a3ca9410ec1d01298fd1e422f335f176ffd7a4e0451d112beced1a = struct {
    fact: u64,
    id: u64,
    layout: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    operation: zx_type_530,
    references: []const bool,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_574 = null,
};

pub const value_zx_type_575_a0405b3f3da574378c4599f54a1cf52b9531f3ff33aefbd053cbddcca68d591c = struct {
    layout: value_zx_type_536_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    program: value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    zx_origin: ?*const zx_type_575 = null,
};

pub const value_zx_type_577_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    action: zx_type_576,
    index: u64,
    moving: bool,
    subject: u64,
    zx_origin: ?*const zx_type_577 = null,
};

pub const value_zx_type_579_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    actions: []const zx_type_576,
    indices: []const u64,
    moving: []const bool,
    subjects: []const u64,
    zx_origin: ?*const zx_type_579 = null,
};

pub const value_zx_type_580_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    complete: bool,
    expression: u64,
    failed: bool,
    output: zx_type_529,
    stores_owned: bool,
    zx_origin: ?*const zx_type_580 = null,
};

pub const value_zx_type_581_9ca4da4ade6ce39392bcd565b92026186825f5515fba0d69864aa5bdd2c0c8c0 = struct {
    action: zx_type_570,
    frame: u64,
    layout: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    stack: value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_581 = null,
};

pub const value_zx_type_582_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    frame: u64,
    stack: value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_582 = null,
};

pub const value_zx_type_583_38e16b7ca832d5cab2cdd1573bdea3003d7c88255f2146bd1c658c5474aa0153 = struct {
    capture: zx_type_569,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    stack: value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_583 = null,
};

pub const value_zx_type_584_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53 = struct {
    frame: value_zx_type_577_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    work: value_zx_type_579_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_584 = null,
};

pub const value_zx_type_585_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: []const u64,
    first: []const u64,
    zx_origin: ?*const zx_type_585 = null,
};

pub const value_zx_type_586_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d = struct {
    boundaries: []const u64,
    count: []const u64,
    entries: []const u64,
    exits: []const u64,
    facts: []const u64,
    first: []const u64,
    heads: []const u64,
    outputs: []const u64,
    roots: []const u64,
    seen: []const bool,
    zx_origin: ?*const zx_type_586 = null,
};

pub const value_zx_type_588_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3 = struct {
    active: bool,
    builders: value_zx_type_585_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    complete: bool,
    domains: value_zx_type_528_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    expression: u64,
    failed: bool,
    layout: value_zx_type_536_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    loops: value_zx_type_586_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    program: value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    returned: zx_type_529,
    returns: []const bool,
    snapshots: value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    stores_owned: bool,
    value: u64,
    values: []const u64,
    work: value_zx_type_579_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_588 = null,
};

pub const value_zx_type_589_a338d1ab71f88877331d772f98bd14da65b1786b2be70c874f8b7e12b86f2f1f = struct {
    frame: u64,
    layout: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    merge: bool,
    references: []const bool,
    stack: value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_589 = null,
};

pub const value_zx_type_590_c24243ffcb91606794657c93d9112ec4c334bd9de6c46889f83dc67ca369b0a0 = struct {
    index: u64,
    loops: value_zx_type_586_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_590 = null,
};

pub const value_zx_type_591_e0ee3b7694a94ee6184c97b78a601ea953f2ec41d003a59e2d2c20bd608416ca = struct {
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_586_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_591 = null,
};

pub const value_zx_type_592_3d04dd43b3d06a3225ea47bfd43abc7af1e40baf278abd1b107975826d4f1dbb = struct {
    condition: bool,
    expression: u64,
    index: u64,
    machine: value_zx_type_588_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3,
    value: u64,
    zx_origin: ?*const zx_type_592 = null,
};

pub const value_zx_type_593_240efbbbf7810640b6fc01ce36bdc99bfbeb5720a9917ff0491c9572a913a019 = struct {
    boundary: u64,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    snapshots: value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    work: value_zx_type_579_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_593 = null,
};

pub const value_zx_type_594_4d3f012ce1af010aa08025827bda50d8f143763669bc2e4b561dcc5658f0bb6a = struct {
    changed: bool,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_586_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_594 = null,
};

pub const value_zx_type_595_9ea6e119697e5089b2d71b0128c4d91826c989da87b1481dc0d5f340ecdd8edd = struct {
    domains: value_zx_type_528_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    exiting: bool,
    expression: u64,
    index: u64,
    layout: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_586_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    snapshots: value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_595 = null,
};

pub const value_zx_type_596_889643ab829a1c5bfcc90b79c286ed0a794313db5ea714f0972ac74b5720a859 = struct {
    domains: value_zx_type_528_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    entry: u64,
    expression: u64,
    layout: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    loops: value_zx_type_586_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    program: value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    value: u64,
    zx_origin: ?*const zx_type_596 = null,
};

pub const value_zx_type_598_4158841c74e882000927bc9fb2cfef48d50f106f07c7898967375498c5ede5cb = struct {
    active: bool,
    cursors: []const u64,
    expression: u64,
    expressions: *const zx_type_34,
    facts: []const u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    layout: value_zx_type_536_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    permanent: bool,
    phase: zx_type_597,
    position: u64,
    query: u64,
    references: []const bool,
    root: u64,
    states: []const zx_type_529,
    trail: []const u64,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    work: []const u64,
    zx_origin: ?*const zx_type_598 = null,
};

pub const value_zx_type_599_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expression: u64,
    expressions: *const zx_type_34,
    index: u64,
    permanent: bool,
    zx_origin: ?*const zx_type_599 = null,
};

pub const value_zx_type_600_0d6d611f2caeee490761bbb5ea443b6881e3d712a7de202a9d02b0df984686e1 = struct {
    expression: u64,
    expressions: *const zx_type_34,
    layout: value_zx_type_536_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    permanent: bool,
    references: []const bool,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_600 = null,
};

pub const value_zx_type_601_ba054a92466517afadfa71eb48b1a69236032a9b3b84f6ef89ed7b3a38acc13a = struct {
    expression: u64,
    expressions: *const zx_type_34,
    layout: value_zx_type_536_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_601 = null,
};

pub const value_zx_type_602_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    position: u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_602 = null,
};

pub const value_zx_type_603_7498e4f806a7d6cb548387280423a75175fc5b80ec06eb4213ab0655a938538d = struct {
    current: zx_type_529,
    moving: bool,
    position: u64,
    symbols: *const zx_type_16,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_603 = null,
};

pub const value_zx_type_604_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    assign: bool,
    assigned: zx_type_529,
    failed: bool,
    value: zx_type_529,
    zx_origin: ?*const zx_type_604 = null,
};

pub const value_zx_type_605_548d03a1c937aa175a4ae6dc65848134fd43039f0f2deb8397102cde1a357280 = struct {
    builders: value_zx_type_585_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    count: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_605 = null,
};

pub const value_zx_type_606_9b2f070bd0a5a2314312b35bc5cd00be816db0248310d896c611be777eb24dfc = struct {
    builders: value_zx_type_585_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_606 = null,
};

pub const value_zx_type_608_3d9243068d042715091b3bc26eced84b2276542fa4ce6ed7c77bd25c76818046 = struct {
    container: bool,
    frame: value_zx_type_577_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    kind: zx_type_23,
    machine: value_zx_type_588_a5d842a973b78d300676629b346155805bd2b3a8732ea16e977ca646f5d671d3,
    payload: u64,
    zx_origin: ?*const zx_type_608 = null,
};

pub const value_zx_type_609_190073c195a96e0748b52805b1cbcc6366d97081df0f6eda8af2362d81577f30 = struct {
    builders: value_zx_type_585_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    type_id: u32,
    zx_origin: ?*const zx_type_609 = null,
};

pub const value_zx_type_610_548d03a1c937aa175a4ae6dc65848134fd43039f0f2deb8397102cde1a357280 = struct {
    builders: value_zx_type_585_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    fact: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_610 = null,
};

pub const value_zx_type_611_9c68fc8229a3cb9544086ee9d74623a5845e02f8d7b0c7e22830b51be4e668ef = struct {
    domains: value_zx_type_528_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    layout: value_zx_type_536_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    program: value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    references: []const bool,
    returns: []const bool,
    runtime: value_zx_type_573_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf,
    zx_origin: ?*const zx_type_611 = null,
};

pub const value_zx_type_612_1ea31d9a4373a8a2d6567244ece57ae6415a5b0cf74a64103f4b2767cf8e0a88 = struct {
    outcome: value_zx_type_580_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_612 = null,
};

pub const value_zx_type_613_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b = struct {
    ownership: zx_type_11,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_613 = null,
};

pub const value_zx_type_614_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a = struct {
    domains: value_zx_type_528_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    layout: value_zx_type_536_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    references: []const bool,
    returns: []const bool,
    zx_origin: ?*const zx_type_614 = null,
};

pub const value_zx_type_615_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134 = struct {
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    prepared: value_zx_type_614_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a,
    snapshots: value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_615 = null,
};

pub const value_zx_type_616_01927fc72980f9f7e06f02c430cda24b1bfe582ea8131a0ec2f6be4c7b3ca6e4 = struct {
    analysis: value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a,
    linking: bool,
    zx_origin: ?*const zx_type_616 = null,
};

pub const value_zx_type_617_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    child_end: u64,
    field_end: u64,
    index: u64,
    name_end: u64,
    scalar_count: u64,
    table: *const zx_type_50,
    valid: bool,
    zx_origin: ?*const zx_type_617 = null,
};

pub const value_zx_type_618_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    after_underscore: bool,
    index: u64,
    kind: zx_type_192,
    name: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_618 = null,
};

pub const value_zx_type_619_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    ascending: bool,
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_619 = null,
};

pub const value_zx_type_620_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    count: u64,
    first: u64,
    index: u64,
    object: bool,
    owner: u64,
    table: *const zx_type_50,
    valid: bool,
    values: []const u32,
    zx_origin: ?*const zx_type_620 = null,
};

pub const value_zx_type_621_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    errors: bool,
    first: u64,
    index: u64,
    valid: bool,
    values: []const []const u8,
    zx_origin: ?*const zx_type_621 = null,
};

pub const value_zx_type_622_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    first: u64,
    index: u64,
    member: []const u8,
    unique: bool,
    values: []const []const u8,
    zx_origin: ?*const zx_type_622 = null,
};

pub const value_zx_type_623_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    scalar_count: u64,
    table: *const zx_type_50,
    valid: bool,
    zx_origin: ?*const zx_type_623 = null,
};

pub const value_zx_type_624_49129128bed2eab4847d5108d0ed3c4d32810f9cdd95b1d04dcc61383544ee70 = struct { value_zx_type_191_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_624, };

pub const value_zx_type_625_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct { value_zx_type_191_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, bool, ?*const zx_type_625, };

pub const value_zx_type_626_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct { value_zx_type_191_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, bool, bool, ?*const zx_type_626, };

pub const value_zx_type_627_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_627 = null,
};

pub const value_zx_type_628_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, []const u8, ?*const zx_type_628, };

pub const value_zx_type_629_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = struct {
    found: bool,
    index: u64,
    limit: u64,
    name: []const u8,
    selected: u64,
    source: value_zx_type_102_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_629 = null,
};

pub const value_zx_type_630_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, []const []const u8, ?*const zx_type_630, };

pub const value_zx_type_631_c112291784b95a088b8165381f6507d0f20b29ff9da2fb78d0ffff47dfc8012c = struct {
    count: u64,
    index: u64,
    state: value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72,
    zx_origin: ?*const zx_type_631 = null,
};

pub const value_zx_type_632_069a7ea61cfb445517edf055c511f09555d98c65d5dabbbf56f319da889b646f = struct { value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_632, };

pub const value_zx_type_633_997a00fdf8ac3d8f5d11296afb04111770aaaddeb73f1727104ad7827dfb64b9 = struct { value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_633, };

pub const value_zx_type_634_07d29144135453d3b73bd99c103d4e9e7f95f2b78fa387faa9e763801bc07ebe = struct { value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_634, };

pub const value_zx_type_635_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const []const u8, void, ?*const zx_type_635, };

pub const value_zx_type_636_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, void, ?*const zx_type_636, };

pub const value_zx_type_637_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const []const u8, ?[]const u8, ?*const zx_type_637, };

pub const value_zx_type_639_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_106, ?*const zx_type_106, ?*const zx_type_639, };

pub const value_zx_type_640_713639bf2340277cb2fc17b55239d7eafff49067cfedc85ab5bd099cd1d4078d = struct {
    equal: bool,
    index: u64,
    left: value_zx_type_211_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    right: value_zx_type_211_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_640 = null,
};

pub const value_zx_type_641_0e70c693f6adee041b71153b65d39c537ba5de74cae3bc9eba48950bd94db775 = struct {
    candidate: value_zx_type_208_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    count: u64,
    found: bool,
    id: u32,
    index: u64,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_641 = null,
};

pub const value_zx_type_642_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u8, void, ?*const zx_type_642, };

pub const value_zx_type_643_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    equal: bool,
    index: u64,
    left: []const u8,
    limit: u64,
    right: []const u8,
    zx_origin: ?*const zx_type_643 = null,
};

pub const value_zx_type_644_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    building: bool,
    count: u64,
    names: []const []const u8,
    remaining: u64,
    root: u64,
    sifting: bool,
    types: []const u32,
    zx_origin: ?*const zx_type_644 = null,
};

pub const value_zx_type_645_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    children: []const u32,
    count: u64,
    flags: []const bool,
    found: bool,
    index: u64,
    offset: u64,
    zx_origin: ?*const zx_type_645 = null,
};

pub const value_zx_type_646_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = struct {
    found: bool,
    index: u64,
    limit: u64,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    target: zx_type_48,
    zx_origin: ?*const zx_type_646 = null,
};

pub const value_zx_type_647_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = struct {
    first: u64,
    flags: []const bool,
    index: u64,
    limit: u64,
    native_references: bool,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_647 = null,
};

pub const value_zx_type_648_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, void, ?*const zx_type_648, };

pub const value_zx_type_649_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    children: []const u32,
    found: bool,
    index: u64,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_649 = null,
};

pub const value_zx_type_650_9dd59f2959a59a5b95ef2d1498743f145e1457d8d6e8fd683304458ba711744c = struct {
    count: u64,
    diagnostic: *const zx_type_58,
    enumeration: u64,
    index: u64,
    names: []const []const u8,
    source: value_zx_type_102_7af6b5f1e2644fc2b2bd880e55cba7a0a5ce74c0b718c6e34e43fb3761bb5203,
    zx_origin: ?*const zx_type_650 = null,
};

pub const value_zx_type_651_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    cache: *const zx_type_104,
    found: bool,
    id: u32,
    index: u64,
    name: []const u8,
    zx_origin: ?*const zx_type_651 = null,
};

pub const value_zx_type_652_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_106, void, ?*const zx_type_652, };

pub const value_zx_type_653_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u32, []const u32, ?*const zx_type_653, };

pub const value_zx_type_654_90fe70fa5d2d4c69af4dc354ff484cde4f742eadfc88af37b0709510fab97410 = struct { value_zx_type_109_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, ?*const zx_type_654, };

pub const value_zx_type_655_1b7a94226e1adb4685c1fa613f3f77c323dc421ecdbae8cfe9089c85d51102d0 = struct { value_zx_type_109_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_655, };

pub const value_zx_type_656_bfc1740ffee8c8ed5a138d86c027163d38443f5478ce225817f6bca9761197af = struct { value_zx_type_109_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_656, };

pub const value_zx_type_657_f9b0821e8e8c23d3efb7e66c63da1fdac46b8458b9acbca9413e99ea98017969 = struct { value_zx_type_109_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, value_zx_type_108_3f7a67a1c7cb7aa54a937ccb4fe485d6ec45ccbb0002dff6696dd3ebe4fc5c72, ?*const zx_type_657, };

pub const value_zx_type_658_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    index: u64,
    types: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_658 = null,
};

pub const value_zx_type_659_976c79e1cc082a66795a3ecc0aec9b751a9c90bedb2c061aee5b5ea60a59a99e = struct { value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d, ?*const zx_type_659, };

pub const value_zx_type_660_d8bc35bad78fb8d50b22d97305a0747eb960eaf2c54964821af979ca1afcf037 = struct { value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d, bool, ?*const zx_type_660, };

pub const value_zx_type_661_ecce1ccc355490bd9273e17e62d9774cb7f8ccc0642e34ae854a8f6e10fcf9a5 = struct { value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d, bool, value_zx_type_109_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, ?*const zx_type_661, };

pub const value_zx_type_662_7840d0bb895cc54b038f5f72c62d95d004e00878f0dae9817498140e3abc2778 = struct { value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d, bool, value_zx_type_109_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_110_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, ?*const zx_type_662, };

pub const value_zx_type_663_d706ff764ff1489ae43cda065f8c09cd152f3489217031f3b22275e20eae05fc = struct { value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d, bool, value_zx_type_109_cab9a91d7f90b0dcc4eb0e2b29ca1238a06423dfa333e5001aa2e3a706effbf2, value_zx_type_110_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_663, };

pub const value_zx_type_664_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, void, ?*const zx_type_664, };

pub const value_zx_type_665_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_11, void, ?*const zx_type_665, };

pub const value_zx_type_666_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_23, void, ?*const zx_type_666, };

pub const value_zx_type_667_884cec86bf32ea32a6c6a4cf3ce292c30f8a5dbb0d5b0093a43986fa983718ca = struct { value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_667, };

pub const value_zx_type_668_7a9e4276667a3d1bd9ae3bec39c67f81784bb189b8d03bc227d92cb4bb01f26a = struct { value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_668, };

pub const value_zx_type_669_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    equal: bool,
    index: u64,
    left: []const u8,
    right: []const u8,
    zx_origin: ?*const zx_type_669 = null,
};

pub const value_zx_type_670_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    bytes: []const u8,
    index: u64,
    keyword: u64,
    start: bool,
    valid: bool,
    zx_origin: ?*const zx_type_670 = null,
};

pub const value_zx_type_671_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    name: []const u8,
    names: []const []const u8,
    overlap: bool,
    zx_origin: ?*const zx_type_671 = null,
};

pub const value_zx_type_672_c7282ba88a569f47ef80d0b07c5739723b36ca15c27d01bf49b07aee33b7f128 = struct {
    analysis: value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a,
    index: u64,
    names: []const []const u8,
    zx_origin: ?*const zx_type_672 = null,
};

pub const value_zx_type_673_1815f92861d8d20202d639557ac42b96536702715874c18e1abde8f1343a2d37 = struct {
    analysis: value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a,
    index: u64,
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_673 = null,
};

pub const value_zx_type_674_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    found: bool,
    index: u64,
    symbol: u32,
    values: []const u32,
    zx_origin: ?*const zx_type_674 = null,
};

pub const value_zx_type_675_1815f92861d8d20202d639557ac42b96536702715874c18e1abde8f1343a2d37 = struct {
    analysis: value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a,
    bindings: []const []const u8,
    index: u64,
    names: []const []const u8,
    zx_origin: ?*const zx_type_675 = null,
};

pub const value_zx_type_676_ce17709e63320e28149f834ac1d9457cf73694d5188ef6a71f19299f16d9b17f = struct {
    bindings: []const []const u8,
    index: u64,
    name: []const u8,
    symbol: ?u32,
    symbols: []const u32,
    zx_origin: ?*const zx_type_676 = null,
};

pub const value_zx_type_677_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_34,
    index: u64,
    limit: u64,
    valid: bool,
    zx_origin: ?*const zx_type_677 = null,
};

pub const value_zx_type_678_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    result: []const bool,
    source: []const ?u32,
    zx_origin: ?*const zx_type_678 = null,
};

pub const value_zx_type_679_3a2d3372119d766901b9e73d1d1a1cb69e32e364aec8da316dab97f3e55fcf11 = struct {
    concurrent: bool,
    functions: value_zx_type_277_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    index: u64,
    values: []const bool,
    zx_origin: ?*const zx_type_679 = null,
};

pub const value_zx_type_680_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = struct {
    actual: u32,
    expected: u32,
    failed: bool,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    wrappers: []const u32,
    zx_origin: ?*const zx_type_680 = null,
};

pub const value_zx_type_681_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    index: u64,
    span: *const zx_type_46,
    table: *const zx_type_34,
    value: u32,
    wrappers: []const u32,
    zx_origin: ?*const zx_type_681 = null,
};

pub const value_zx_type_682_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    all: bool,
    bodies: []const u32,
    end: u64,
    index: u64,
    returns: []const bool,
    zx_origin: ?*const zx_type_682 = null,
};

pub const value_zx_type_683_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    block: u64,
    control: *const zx_type_22,
    returns: []const bool,
    zx_origin: ?*const zx_type_683 = null,
};

pub const value_zx_type_684_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_338, void, ?*const zx_type_684, };

pub const value_zx_type_685_5821a6631fd0a2b5d5f68275f533e0b86f2430edbf1471339d13b94e742690d5 = struct {
    contracts: *const zx_type_255,
    index: u64,
    state: value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290,
    zx_origin: ?*const zx_type_685 = null,
};

pub const value_zx_type_686_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_337, void, ?*const zx_type_686, };

pub const value_zx_type_687_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    control: *const zx_type_22,
    first: u64,
    frames: []const *const zx_type_337,
    index: u64,
    source: u64,
    zx_origin: ?*const zx_type_687 = null,
};

pub const value_zx_type_688_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    capacity: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_688 = null,
};

pub const value_zx_type_689_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    previous: []const u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_689 = null,
};

pub const value_zx_type_690_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    position: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_690 = null,
};

pub const value_zx_type_691_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const u64, []const u64, ?*const zx_type_691, };

pub const value_zx_type_692_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    key: u64,
    position: u64,
    slots: []const u64,
    zx_origin: ?*const zx_type_692 = null,
};

pub const value_zx_type_693_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    end: u64,
    index: u64,
    table: *const zx_type_34,
    values: []const u32,
    zx_origin: ?*const zx_type_693 = null,
};

pub const value_zx_type_694_7498e4f806a7d6cb548387280423a75175fc5b80ec06eb4213ab0655a938538d = struct {
    end: u64,
    expressions: *const zx_type_34,
    index: u64,
    names: []const []const u8,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_694 = null,
};

pub const value_zx_type_695_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_338, []const *const zx_type_338, ?*const zx_type_695, };

pub const value_zx_type_696_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    frames: []const *const zx_type_337,
    index: u64,
    source: u64,
    values: []const u32,
    zx_origin: ?*const zx_type_696 = null,
};

pub const value_zx_type_698_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_337, ?*const zx_type_337, ?*const zx_type_698, };

pub const value_zx_type_699_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    names: []const []const u8,
    values: []const []const u8,
    zx_origin: ?*const zx_type_699 = null,
};

pub const value_zx_type_700_b06e51454feef7fdf7d9b33c62cb112de772e5d9de51777f095ab91e73b9d4a4 = struct { value_zx_type_343_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, ?*const zx_type_700, };

pub const value_zx_type_701_559c4a2367a0e05791ca87aafe7d7cdb8a8bef28a8e16e6f7fcc6220ff365f00 = struct { value_zx_type_343_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?*const zx_type_701, };

pub const value_zx_type_702_7e470e8ae35bc1ae71064e0d2c7f58ebb3ee66a2637521f4043452e64e35c605 = struct { value_zx_type_343_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?*const zx_type_702, };

pub const value_zx_type_703_6327aad74f053b917836b19aec6a569c09585fbbc9966097f141db1ae3eef3e6 = struct { value_zx_type_343_6c4357fea66f7abc6a945ec5f61f389bc787a6938c6a47f0eb1f32956839b4ea, value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, value_zx_type_342_11b6ea320d2c37bfb52acccffdfbbe4e2115076edf45261f3be4006ea3ef9290, ?[]const []const u8, ?*const zx_type_703, };

pub const value_zx_type_704_6bd979ddc38e9089ff343580aac7bbd290f506083ba1a522db596260b01dd22c = struct {
    captures: []const u32,
    concurrent: []const bool,
    index: u64,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbols: u64,
    zx_origin: ?*const zx_type_704 = null,
};

pub const value_zx_type_706_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_310, ?*const zx_type_310, ?*const zx_type_706, };

pub const value_zx_type_707_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_27, void, ?*const zx_type_707, };

pub const value_zx_type_708_45bed241fe4e2523b208ec60e7bff7103d776329866b5ac3be4ba8d2df1b6363 = struct {
    comparable: bool,
    done: bool,
    id: u32,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_708 = null,
};

pub const value_zx_type_709_aee76122a8aa68efe04b2c02a68c8e3c08413ae0f993bee8758d75935e4a54be = struct {
    facts: value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    symbol: u32,
    zx_origin: ?*const zx_type_709 = null,
};

pub const value_zx_type_710_4373da08621bcbc23abd1852eb2d5ba558f05027208e827b7568eb84bcb01181 = struct {
    expressions: *const zx_type_34,
    state: value_zx_type_38_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f,
    zx_origin: ?*const zx_type_710 = null,
};

pub const value_zx_type_711_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u64, ?u64, ?*const zx_type_711, };

pub const value_zx_type_713_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const bool, ?bool, ?*const zx_type_713, };

pub const value_zx_type_714_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_297, void, ?*const zx_type_714, };

pub const value_zx_type_715_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_300, []const *const zx_type_300, ?*const zx_type_715, };

pub const value_zx_type_717_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_300, ?*const zx_type_300, ?*const zx_type_717, };

pub const value_zx_type_718_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    head: u64,
    items: []const *const zx_type_70,
    values: []const u64,
    zx_origin: ?*const zx_type_718 = null,
};

pub const value_zx_type_719_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_24, void, ?*const zx_type_719, };

pub const value_zx_type_721_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_307, ?*const zx_type_307, ?*const zx_type_721, };

pub const value_zx_type_722_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    done: bool,
    id: u32,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_722 = null,
};

pub const value_zx_type_723_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    active: []const u32,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_723 = null,
};

pub const value_zx_type_724_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?u32, void, ?*const zx_type_724, };

pub const value_zx_type_725_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    head: u64,
    ids: []const u64,
    tree: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_725 = null,
};

pub const value_zx_type_726_0baf43f3d33ac4f0e304448bc488db6ef2f4f56bdeadfb1e3c6d28d21146b517 = struct {
    index: u64,
    order: []const u64,
    parameters: []const u32,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    start: u64,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    types: []const u32,
    zx_origin: ?*const zx_type_726 = null,
};

pub const value_zx_type_727_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_11, []const zx_type_11, ?*const zx_type_727, };

pub const value_zx_type_728_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_283, []const *const zx_type_283, ?*const zx_type_728, };

pub const value_zx_type_730_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_306, ?*const zx_type_306, ?*const zx_type_730, };

pub const value_zx_type_731_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_283, void, ?*const zx_type_731, };

pub const value_zx_type_732_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_307, void, ?*const zx_type_732, };

pub const value_zx_type_733_bdda99bcf93d154ace4e82689f18514c6aef827e9905b839439fdb204788378d = struct {
    found: ?u32,
    index: u64,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    zx_origin: ?*const zx_type_733 = null,
};

pub const value_zx_type_734_e2199116c4df1fbf6b79ada1c538756c5bb7ce66c8becb7428e7b0269042524f = struct {
    done: bool,
    end: u64,
    matches: bool,
    node: u64,
    path: []const u8,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_734 = null,
};

pub const value_zx_type_735_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    end: u64,
    equal: bool,
    index: u64,
    path: []const u8,
    size: u64,
    source: []const u8,
    start: u64,
    zx_origin: ?*const zx_type_735 = null,
};

pub const value_zx_type_736_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    node: u64,
    tree: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_736 = null,
};

pub const value_zx_type_737_98162e3b291b362b1be268664dcae441df176033bcb3f4ad0cc295c0f8f21860 = struct {
    bindings: []const u32,
    index: u64,
    local: ?u32,
    names: []const []const u8,
    node: u64,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    symbol: ?u32,
    unit: bool,
    units: []const []const u8,
    zx_origin: ?*const zx_type_737 = null,
};

pub const value_zx_type_738_bdf11028d7edf63a86b591ebd231881ed231979a6ab2be7bd107b8f8b578b5cf = struct {
    imports: value_zx_type_268_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    index: u64,
    name: []const u8,
    namespace: ?[]const u8,
    result: ?u32,
    zx_origin: ?*const zx_type_738 = null,
};

pub const value_zx_type_739_4465fc637d9223ac98ffb2dcac0bb3ae1a3507c97bbbb5f308bde59bd8c0db24 = struct {
    index: u64,
    name: []const u8,
    owner: []const u8,
    stores: *const zx_type_35,
    type_id: ?u32,
    zx_origin: ?*const zx_type_739 = null,
};

pub const value_zx_type_740_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_391, void, ?*const zx_type_740, };

pub const value_zx_type_741_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    frames: []const *const zx_type_391,
    head: u64,
    tree: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_741 = null,
};

pub const value_zx_type_742_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    floating: bool,
    index: u64,
    separators: bool,
    source: []const u8,
    zx_origin: ?*const zx_type_742 = null,
};

pub const value_zx_type_743_7c66a3cb5e44aab8edd226d8256d0daabeaa161477f0b38f3d49c352a8750ddd = struct {
    floating: bool,
    index: u64,
    nodes: []const u64,
    signed: bool,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    zx_origin: ?*const zx_type_743 = null,
};

pub const value_zx_type_744_31a5bb298f65bcca8355220f42cbed1d9c8fb3cc0856538ed6740f52bea20b41 = struct {
    fallback: u64,
    head: u64,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    type_id: ?u32,
    zx_origin: ?*const zx_type_744 = null,
};

pub const value_zx_type_745_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    negative: bool,
    offset: u64,
    seen: bool,
    source: []const u8,
    started: bool,
    valid: bool,
    value: u64,
    zx_origin: ?*const zx_type_745 = null,
};

pub const value_zx_type_746_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    first: u64,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_746 = null,
};

pub const value_zx_type_748_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_391, ?*const zx_type_391, ?*const zx_type_748, };

pub const value_zx_type_749_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_301, []const *const zx_type_301, ?*const zx_type_749, };

pub const value_zx_type_751_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_301, ?*const zx_type_301, ?*const zx_type_751, };

pub const value_zx_type_753_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_305, ?*const zx_type_305, ?*const zx_type_753, };

pub const value_zx_type_754_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_305, []const *const zx_type_305, ?*const zx_type_754, };

pub const value_zx_type_755_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_285, []const *const zx_type_285, ?*const zx_type_755, };

pub const value_zx_type_757_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_285, ?*const zx_type_285, ?*const zx_type_757, };

pub const value_zx_type_758_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_307, []const *const zx_type_307, ?*const zx_type_758, };

pub const value_zx_type_759_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_302, []const *const zx_type_302, ?*const zx_type_759, };

pub const value_zx_type_761_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_302, ?*const zx_type_302, ?*const zx_type_761, };

pub const value_zx_type_762_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_762 = null,
};

pub const value_zx_type_763_36e32a7d36ecb8b71dbe7e25a4158128c7836c2521d5fee40349f25f49cdbf83 = struct {
    count: u64,
    entries: *const zx_type_295,
    expressions: *const zx_type_34,
    first: u64,
    index: u64,
    names: []const []const u8,
    span: *const zx_type_46,
    types: []const u32,
    value: u32,
    zx_origin: ?*const zx_type_763 = null,
};

pub const value_zx_type_764_58ef347c61db31ca5ea618c4e523002df95e3d2676181d87628d3eee1f05edef = struct {
    count: u64,
    entries: *const zx_type_295,
    evaluation: []const u32,
    first: u64,
    index: u64,
    names: []const []const u8,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    types: []const u32,
    zx_origin: ?*const zx_type_764 = null,
};

pub const value_zx_type_765_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    output: []const u32,
    types: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_765 = null,
};

pub const value_zx_type_766_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    indices: []const u32,
    names: []const []const u8,
    zx_origin: ?*const zx_type_766 = null,
};

pub const value_zx_type_768_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_304, ?*const zx_type_304, ?*const zx_type_768, };

pub const value_zx_type_769_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_304, []const *const zx_type_304, ?*const zx_type_769, };

pub const value_zx_type_770_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    indices: []const ?u32,
    names: []const []const u8,
    zx_origin: ?*const zx_type_770 = null,
};

pub const value_zx_type_771_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    fields: []const []const u8,
    first: u64,
    index: u64,
    name: []const u8,
    zx_origin: ?*const zx_type_771 = null,
};

pub const value_zx_type_773_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_311, ?*const zx_type_311, ?*const zx_type_773, };

pub const value_zx_type_774_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_311, []const *const zx_type_311, ?*const zx_type_774, };

pub const value_zx_type_775_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_26, void, ?*const zx_type_775, };

pub const value_zx_type_776_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_299, []const *const zx_type_299, ?*const zx_type_776, };

pub const value_zx_type_778_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_299, ?*const zx_type_299, ?*const zx_type_778, };

pub const value_zx_type_779_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u32, ?u32, ?*const zx_type_779, };

pub const value_zx_type_780_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    head: u64,
    ids: []const u64,
    names: []const *const zx_type_159,
    zx_origin: ?*const zx_type_780 = null,
};

pub const value_zx_type_781_3cf4ab3384f85d536427bbf94775a364291e2e976d07b6ba4ce3a0bde60c9a23 = struct {
    first: u64,
    index: u64,
    order: []const u64,
    saved: u32,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    start: u64,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbols: []const ?u32,
    types: []const u32,
    zx_origin: ?*const zx_type_781 = null,
};

pub const value_zx_type_782_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_292, []const *const zx_type_292, ?*const zx_type_782, };

pub const value_zx_type_783_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    head: u64,
    items: []const *const zx_type_70,
    remaining: u64,
    statements: []const u64,
    zx_origin: ?*const zx_type_783 = null,
};

pub const value_zx_type_784_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_292, void, ?*const zx_type_784, };

pub const value_zx_type_785_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_290, []const *const zx_type_290, ?*const zx_type_785, };

pub const value_zx_type_787_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_290, ?*const zx_type_290, ?*const zx_type_787, };

pub const value_zx_type_788_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_34,
    found: bool,
    index: u64,
    previous: []const u32,
    value: u64,
    zx_origin: ?*const zx_type_788 = null,
};

pub const value_zx_type_790_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_291, ?*const zx_type_291, ?*const zx_type_790, };

pub const value_zx_type_791_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_291, []const *const zx_type_291, ?*const zx_type_791, };

pub const value_zx_type_792_9be0cbf8f65799eaec939714507e681c309c047ed5caa6a25e1f3fcb9bb77bbd = struct {
    diagnostic: *const zx_type_58,
    done: bool,
    expressions: *const zx_type_34,
    frames: []const *const zx_type_286,
    read_value: bool,
    symbol: u32,
    tables: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    target: u32,
    zx_origin: ?*const zx_type_792 = null,
};

pub const value_zx_type_793_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_286, void, ?*const zx_type_793, };

pub const value_zx_type_794_e959e660250ea2c38eebc15197975dc40fca3c1eaea3e75064cc2976d3108df9 = struct {
    frames: []const *const zx_type_286,
    index: u64,
    places: []const *const zx_type_287,
    scopes: value_zx_type_294_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_794 = null,
};

pub const value_zx_type_795_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_287, void, ?*const zx_type_795, };

pub const value_zx_type_796_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_287, []const *const zx_type_287, ?*const zx_type_796, };

pub const value_zx_type_797_f5e52abeececd02ffdc4c45617da5eb5314fc9768ade4904d8fbfd910922c82e = struct {
    count: u64,
    expressions: *const zx_type_34,
    first: u64,
    index: u64,
    indices: []const u32,
    metadata: value_zx_type_236_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    parent: u32,
    selected: u64,
    table: *const zx_type_50,
    tuple: bool,
    value: u32,
    values: []const u32,
    zx_origin: ?*const zx_type_797 = null,
};

pub const value_zx_type_798_38c23013d1af4d622634024dfde4192752164d6c244c3422d12297fb090cb522 = struct {
    index: u64,
    places: []const *const zx_type_287,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    value: u32,
    zx_origin: ?*const zx_type_798 = null,
};

pub const value_zx_type_799_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_289, []const *const zx_type_289, ?*const zx_type_799, };

pub const value_zx_type_801_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_289, ?*const zx_type_289, ?*const zx_type_801, };

pub const value_zx_type_803_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_303, ?*const zx_type_303, ?*const zx_type_803, };

pub const value_zx_type_804_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_303, []const *const zx_type_303, ?*const zx_type_804, };

pub const value_zx_type_805_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    rewrite: bool,
    source: []const u8,
    template: bool,
    zx_origin: ?*const zx_type_805 = null,
};

pub const value_zx_type_806_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    bytes: []const u8,
    index: u64,
    source: []const u8,
    template: bool,
    zx_origin: ?*const zx_type_806 = null,
};

pub const value_zx_type_807_6b377024a652d6223d88a2d381b58933d303496773134218a4819ded26bc33a9 = struct {
    frame: *const zx_type_308,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    zx_origin: ?*const zx_type_807 = null,
};

pub const value_zx_type_809_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_308, ?*const zx_type_308, ?*const zx_type_809, };

pub const value_zx_type_810_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_308, []const *const zx_type_308, ?*const zx_type_810, };

pub const value_zx_type_811_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    fields: []const u32,
    index: u64,
    types: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_811 = null,
};

pub const value_zx_type_812_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    count: u64,
    fields: *const zx_type_295,
    first: u64,
    index: u64,
    indices: []const u32,
    names: []const []const u8,
    values: []const u32,
    zx_origin: ?*const zx_type_812 = null,
};

pub const value_zx_type_813_62eb0bd048c00d4bd5a9d380474a21cd2439b8e1eb81b546c8adfcdd2e7fd525 = struct {
    bindings: value_zx_type_281_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    context: u32,
    index: u64,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    targets: []const u32,
    zx_origin: ?*const zx_type_813 = null,
};

pub const value_zx_type_814_5e11fd03bacccdbb2280a648f039ef89d25acbb81946e58c24b4fff298b40cb5 = struct {
    bindings: value_zx_type_281_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    parameters: []const u32,
    reducing: bool,
    values: []const u32,
    zx_origin: ?*const zx_type_814 = null,
};

pub const value_zx_type_815_bb3d08a9d210071122fcf4b6334aeb326db723ac4738083846e7f76296942d8a = struct { value_zx_type_467_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be, ?*const zx_type_815, };

pub const value_zx_type_816_c20f7901727429a64bd5c9a3511d6c2afaa12810bba72af2a34e0317a130a091 = struct { value_zx_type_467_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be, value_zx_type_468_a77e4162e607846786e14298a59c2e743a9752ef2fe6c98ae39887af0965c62c, ?*const zx_type_816, };

pub const value_zx_type_817_3e2f95de7047baf1a7fa6ace8e72579debf51c3a0e346b407c7139908cae79b8 = struct { value_zx_type_467_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be, value_zx_type_468_a77e4162e607846786e14298a59c2e743a9752ef2fe6c98ae39887af0965c62c, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_817, };

pub const value_zx_type_818_ef800787bf4272e120a2a808feeb5a6d3b9861c7dc2b3c28627e9017fd650685 = struct { value_zx_type_467_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be, value_zx_type_468_a77e4162e607846786e14298a59c2e743a9752ef2fe6c98ae39887af0965c62c, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_818, };

pub const value_zx_type_819_bd633bfbf84777411fdc6c682c43927d5ca69f87e6e589e58867dce54bfb004c = struct { value_zx_type_467_bf1f1af20121cb4fceaaaeea658681d86853da36c7ca715172145007219829be, value_zx_type_468_a77e4162e607846786e14298a59c2e743a9752ef2fe6c98ae39887af0965c62c, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_819, };

pub const value_zx_type_820_fff74499e9dffad0184af283e05aa9c7369e1426eec866594e10632235337c41 = struct { value_zx_type_282_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, ?*const zx_type_820, };

pub const value_zx_type_821_8d9346352232c8e7c3ef88d5b43378ffdbb71107b32f9096d7c0b082216517ff = struct { value_zx_type_282_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_455_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, ?*const zx_type_821, };

pub const value_zx_type_822_92dd839f9e33c2416dbb94d1e8619a26990e165c6afdfe4682d05d1961a7e6ea = struct { value_zx_type_282_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_455_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_822, };

pub const value_zx_type_823_66506a907204c4d67000ee625e975f8ff9e10b7672db030701121810df7bec97 = struct { value_zx_type_282_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_455_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_823, };

pub const value_zx_type_824_8ff59d43ad8ec447fb0ed9c0728a847046e3011573ebe272ddf4f35368b95d20 = struct { value_zx_type_282_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_455_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_465_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, ?*const zx_type_824, };

pub const value_zx_type_825_f5dd8cd85f0ebeab84f9d3e3b086ee2a6d9567bb743407e1884a2103dd7e1311 = struct { value_zx_type_282_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_455_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_465_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_825, };

pub const value_zx_type_826_4491fd18fcb5fea3e4da1fc84cb0adbe65f680ef96f50af43c2e5549dca2ef74 = struct { value_zx_type_282_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_455_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_465_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_826, };

pub const value_zx_type_827_4fc54855ed54e369b5f2add3c52ac7e9efc1a4b5843d0300e08ed38d43255c78 = struct { value_zx_type_282_98a64fed87f15c7438a766f93f282646ec4440b3842133a48fcb4cd1f76c4117, value_zx_type_455_f2fa0bf45ea2ac794ce6cdb4e7e9eda16a2e861ddcdd8bd94aedbb564d70267e, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_465_c8fe6c2bd7602ac6827573534225759f93526fb1281dbe728ff91e6f36de6bf1, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, value_zx_type_242_61fc95d0dd0b464dbb2880d24d1b72f20356b8405b14debf34b50eed9ebb37ae, ?*const zx_type_827, };

pub const value_zx_type_828_d7317231acbaea954b8aa77221704d1f17ed961b3ebe42150f79e53d34997a08 = struct {
    bindings: value_zx_type_40_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    row: ?u32,
    sources: []const u32,
    targets: []const u32,
    values: []const u32,
    zx_origin: ?*const zx_type_828 = null,
};

pub const value_zx_type_830_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_283, ?*const zx_type_283, ?*const zx_type_830, };

pub const value_zx_type_832_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const zx_type_297, ?zx_type_297, ?*const zx_type_832, };

pub const value_zx_type_834_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_298, ?*const zx_type_298, ?*const zx_type_834, };

pub const value_zx_type_835_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const ?u32, []const ?u32, ?*const zx_type_835, };

pub const value_zx_type_836_963ce4ff9ea7f93f347b5e6ba3bb449b7465b6c311531cab8541fc7b96cf273f = struct {
    bindings: value_zx_type_40_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    found: ?u32,
    row: ?u32,
    source: u32,
    zx_origin: ?*const zx_type_836 = null,
};

pub const value_zx_type_837_86a7b3113d22c4f5c71c881410c90c0e7cd5e9a4faebfbc40f2c395532e20d52 = struct {
    floor: u64,
    found: ?u32,
    index: u64,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    zx_origin: ?*const zx_type_837 = null,
};

pub const value_zx_type_838_bcd4d35e777eb2934f239c98ebc1f91b1dd4109c366ae594abc6d3c6c946efd0 = struct {
    frame: ?u32,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    path: []const u32,
    symbol: ?u32,
    zx_origin: ?*const zx_type_838 = null,
};

pub const value_zx_type_839_c10b56468fcdfc340efd837bc2bb5a1d1abf702877c05f5181a62bc3537de488 = struct {
    index: u64,
    path: []const u32,
    span: *const zx_type_46,
    state: value_zx_type_188_44cd18561c68b6b0e1ec40ba63dfb3ca26872bc5aec435ab71f92d827c1358ed,
    symbol: u32,
    zx_origin: ?*const zx_type_839 = null,
};

pub const value_zx_type_840_3691146d03d1eaa2c0c3b46f9fab32112bcab6edf4654c6245fcc77a52e03758 = struct {
    found: bool,
    index: u64,
    local: value_zx_type_42_b0b7d504168b01da16120c14ab595de0ad68ebeebf419c67792ba58e50819d69,
    name: []const u8,
    zx_origin: ?*const zx_type_840 = null,
};

pub const value_zx_type_841_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const f64, void, ?*const zx_type_841, };

pub const value_zx_type_842_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    bytes: []const u8,
    index: u64,
    source: []const u8,
    zx_origin: ?*const zx_type_842 = null,
};

pub const value_zx_type_843_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    carry: u64,
    index: u64,
    limbs: []const u64,
    zx_origin: ?*const zx_type_843 = null,
};

pub const value_zx_type_844_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    bits: u64,
    value: u64,
    zx_origin: ?*const zx_type_844 = null,
};

pub const value_zx_type_845_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    index: u64,
    limbs: []const u64,
    zx_origin: ?*const zx_type_845 = null,
};

pub const value_zx_type_846_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    value: u64,
    zx_origin: ?*const zx_type_846 = null,
};

pub const value_zx_type_847_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    bytes: []const u8,
    index: u64,
    invalid: bool,
    limbs: []const u64,
    zx_origin: ?*const zx_type_847 = null,
};

pub const value_zx_type_848_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    handle: []const u8,
    handles: []const []const u8,
    index: u64,
    zx_origin: ?*const zx_type_848 = null,
};

pub const value_zx_type_849_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    active: []const u32,
    floor: u64,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_849 = null,
};

pub const value_zx_type_850_6c35bd65687b543bd880afd6526cdd3358740165380c62eed517e4ec12458ab1 = struct {
    found: bool,
    imports: value_zx_type_268_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    index: u64,
    known_namespace: bool,
    name: []const u8,
    namespace: ?[]const u8,
    zx_origin: ?*const zx_type_850 = null,
};

pub const value_zx_type_851_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_305, void, ?*const zx_type_851, };

pub const value_zx_type_852_aa6c764a8238ceeee1b28212d5066b2c415c3d6a543dc2594694476b133f3b0d = struct {
    condition: ?u64,
    diagnostic: *const zx_type_58,
    fields: []const u64,
    index: u64,
    postcondition: bool,
    source: value_zx_type_272_38b3e596b781fdb4c3c5c5a4638e380024434bfc0553ff3fb6357e4096b9e88f,
    step: ?u64,
    zx_origin: ?*const zx_type_852 = null,
};

pub const value_zx_type_853_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_285, void, ?*const zx_type_853, };

pub const value_zx_type_854_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    fields: []const *const zx_type_141,
    head: u64,
    ids: []const u64,
    zx_origin: ?*const zx_type_854 = null,
};

pub const value_zx_type_855_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_311, void, ?*const zx_type_855, };

pub const value_zx_type_856_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_306, void, ?*const zx_type_856, };

pub const value_zx_type_857_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    arms: []const u64,
    head: u64,
    tree: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_857 = null,
};

pub const value_zx_type_858_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_302, void, ?*const zx_type_858, };

pub const value_zx_type_859_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    fields: []const u64,
    head: u64,
    tree: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_859 = null,
};

pub const value_zx_type_860_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_304, void, ?*const zx_type_860, };

pub const value_zx_type_861_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    head: u64,
    items: []const u64,
    tree: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_861 = null,
};

pub const value_zx_type_862_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_303, void, ?*const zx_type_862, };

pub const value_zx_type_863_e31035308a5386ac6027517d84ca7992d1d22dc27407e4e23f1c47cf8666bd31 = struct {
    head: u64,
    parts: []const u64,
    tree: value_zx_type_150_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_863 = null,
};

pub const value_zx_type_864_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_308, void, ?*const zx_type_864, };

pub const value_zx_type_865_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_298, void, ?*const zx_type_865, };

pub const value_zx_type_866_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_310, void, ?*const zx_type_866, };

pub const value_zx_type_867_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_299, void, ?*const zx_type_867, };

pub const value_zx_type_868_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_300, void, ?*const zx_type_868, };

pub const value_zx_type_869_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_301, void, ?*const zx_type_869, };

pub const value_zx_type_870_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, []const bool, ?*const zx_type_870, };

pub const value_zx_type_872_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const *const zx_type_292, ?*const zx_type_292, ?*const zx_type_872, };

pub const value_zx_type_873_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_289, void, ?*const zx_type_873, };

pub const value_zx_type_874_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_290, void, ?*const zx_type_874, };

pub const value_zx_type_875_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    cases: []const *const zx_type_160,
    head: u64,
    ids: []const u64,
    zx_origin: ?*const zx_type_875 = null,
};

pub const value_zx_type_876_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const *const zx_type_291, void, ?*const zx_type_876, };

pub const value_zx_type_877_07e08e47533e04c042048a66563793f6d464f80f91d9b72aa35dca0b16989b3c = struct { value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d, value_zx_type_275_a986431fc03b854e809a69648942c955b0d0576700ff151ca27f5ac1b466e8cc, ?*const zx_type_877, };

pub const value_zx_type_878_f9f8c02752d5b62af73bc780b29a6f2c84e95397aa566770251dc935250508dd = struct { value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d, value_zx_type_275_a986431fc03b854e809a69648942c955b0d0576700ff151ca27f5ac1b466e8cc, value_zx_type_332_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519, ?*const zx_type_878, };

pub const value_zx_type_879_9c0e830bb90e032220267345e7238198abd71a4a62d1a4638a14cab6b8fbbadd = struct { value_zx_type_274_bd0de58692630d578f2a1679973ecebd148e76e536e7d0f25bcf74b73b061f2d, value_zx_type_275_a986431fc03b854e809a69648942c955b0d0576700ff151ca27f5ac1b466e8cc, value_zx_type_332_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519, value_zx_type_332_fbc37b65d8f62de495e73076f7adf82047f7dc807b0f41f77bd0907aaa929519, ?*const zx_type_879, };

pub const value_zx_type_880_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_17, void, ?*const zx_type_880, };

pub const value_zx_type_881_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    index: u64,
    symbols: []const u32,
    table: *const zx_type_22,
    values: []const u32,
    zx_origin: ?*const zx_type_881 = null,
};

pub const value_zx_type_882_5b036322b280386762a74654d61ae2888c86dbcb531b75813552b39105b44420 = struct { value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_882, };

pub const value_zx_type_883_6bcad2b47933c7316be5c07b1005715a46eb96dc90ee0f9100841687a251f9ad = struct { value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_883, };

pub const value_zx_type_884_4854cde39e36b19a70d421960f863c814d73da5cf3181d8fbe8174fcb46ecdcd = struct {
    target: value_zx_type_53_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_884 = null,
};

pub const value_zx_type_885_152936f5b3ece57cfa1afaff5c987671dc1de239be81c121450e61f890947569 = struct {
    index: u64,
    references: []const bool,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_885 = null,
};

pub const value_zx_type_886_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    expressions: *const zx_type_34,
    index: u64,
    kind: zx_type_23,
    locals: []const bool,
    payload: u64,
    zx_origin: ?*const zx_type_886 = null,
};

pub const value_zx_type_887_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    body: u64,
    condition: u64,
    count: u64,
    locals: []const bool,
    reachable: []const bool,
    symbols: u64,
    zx_origin: ?*const zx_type_887 = null,
};

pub const value_zx_type_888_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: *const zx_type_34,
    index: u64,
    locals: []const bool,
    reachable: []const bool,
    remaining: u64,
    zx_origin: ?*const zx_type_888 = null,
};

pub const value_zx_type_889_d42088e18bb5c05cf1e3a3d9851c1dd08d41eae9e1223a6150bd284f2dc08b77 = struct {
    count: []const u64,
    first: []const u64,
    index: u64,
    program: value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    symbols: []const u64,
    zx_origin: ?*const zx_type_889 = null,
};

pub const value_zx_type_890_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    locals: []const bool,
    symbols: []const u64,
    zx_origin: ?*const zx_type_890 = null,
};

pub const value_zx_type_891_4c9a900895778ef8a8b8af9807bd68428ea35c59b77acdf07c33728d1d771352 = struct {
    active: bool,
    cached_count: []const u64,
    cached_first: []const u64,
    cached_positions: []const u64,
    children: []const u64,
    field_indices: []const u64,
    heads: []const u64,
    index: u64,
    item: u64,
    next: []const u64,
    parents: []const u64,
    phase: zx_type_537,
    place_types: []const u32,
    program: value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695,
    reference_flags: []const bool,
    references: []const bool,
    siblings: []const u64,
    tails: []const u64,
    zx_origin: ?*const zx_type_891 = null,
};

pub const value_zx_type_892_1b2191a44235c6e6b65e1ae9ab1c3d223553737681d5d92d9e9cae41a381d262 = struct {
    active: bool,
    found: bool,
    index: value_zx_type_540_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    key: value_zx_type_541_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_892 = null,
};

pub const value_zx_type_893_2a73385728db51fa9518b55ca4dd797e91049a447a89c6c5efe9d790e5c08e2e = struct { value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, ?*const zx_type_893, };

pub const value_zx_type_894_767b69074202a272a12100b84e23109da965767802298cfb5e4fed280635514e = struct { value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, ?*const zx_type_894, };

pub const value_zx_type_895_46b777fb29a6ec83f56ee22ad77d1bbbd13caf8e6a27064012c94c0eb1544938 = struct { value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, ?*const zx_type_895, };

pub const value_zx_type_896_18fcb2898d1d7204e87db706f073fcf51d79752c11063fe602073e375e06acd1 = struct { value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_528_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_896, };

pub const value_zx_type_897_2cde30861016700fbcc37ec0e53f358a870f83b3d9276e54dca5abfa42381dbf = struct { value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_528_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_535_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937, ?*const zx_type_897, };

pub const value_zx_type_898_fc9d1607bfc29c393e85973469418c6449deb36cf03f440f10859d1b0e6cf2c1 = struct { value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, []const bool, []const bool, value_zx_type_528_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, value_zx_type_535_ca3027ce0db6d42ba9ab8339b85fc5fc8a630734ee7a847cd6ee8a6c73f64937, value_zx_type_536_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d, ?*const zx_type_898, };

pub const value_zx_type_899_df87d4e4c94482fd017e977a114eba826861ac6af356c343aea16855cac7c373 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    state: zx_type_529,
    zx_origin: ?*const zx_type_899 = null,
};

pub const value_zx_type_900_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_529, void, ?*const zx_type_900, };

pub const value_zx_type_901_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    children: []const u64,
    count: u64,
    first: u64,
    index: u64,
    source: []const u64,
    zx_origin: ?*const zx_type_901 = null,
};

pub const value_zx_type_902_03ceda26995807c2aa6530d3178a20e89911f37af4bad09be3c9b210bc3682ce = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    target: u64,
    type_id: u32,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_902 = null,
};

pub const value_zx_type_903_20d7d99279e33ed98c39ff3a89f60b0602618a66dfe76434242c1e24534deee7 = struct {
    active: bool,
    ascending: bool,
    fact: u64,
    facts: []const u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    id: u64,
    layout: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    leaving: bool,
    references: []const bool,
    root: u64,
    states: []const zx_type_529,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_903 = null,
};

pub const value_zx_type_904_b96c48974ce17ef2b8be551c68efc904286af193386b87a21ad68406a5672c15 = struct {
    active: bool,
    cache: value_zx_type_562_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    found: bool,
    left: u64,
    right: u64,
    slot: u64,
    value: u64,
    zx_origin: ?*const zx_type_904 = null,
};

pub const value_zx_type_905_4b4ea4009453ea5e4d3d79e2158cdc223b3d2c1404741f1be6d92e28595818e4 = struct {
    active: bool,
    cache: value_zx_type_562_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    capacity: u64,
    grow: bool,
    index: u64,
    left: u64,
    right: u64,
    value: u64,
    zx_origin: ?*const zx_type_905 = null,
};

pub const value_zx_type_906_fddf701302546dc5c12ecdb7d8719eb57b5e534ac713eb9744231ee909d8dc70 = struct {
    children: []const u64,
    count: u64,
    fact: u64,
    first: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    references: []const bool,
    same: bool,
    type_id: u32,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_906 = null,
};

pub const value_zx_type_907_b3760cb020967af5517f45e8ca01d64dcc589438ca8342340b78221ceef17d6a = struct {
    action: zx_type_561,
    cache: value_zx_type_562_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    children: []const u64,
    first: []const u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    indices: []const u64,
    left: []const u64,
    paired: bool,
    references: []const bool,
    right: []const u64,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_907 = null,
};

pub const value_zx_type_908_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    expressions: u64,
    facts: []const u64,
    memo: []const u64,
    places: u64,
    states: []const zx_type_529,
    zx_origin: ?*const zx_type_908 = null,
};

pub const value_zx_type_909_84331d6a4a43806456ffa46c6afa1bd16dcd6bebddd17f96d6eddd9ac3c6fff1 = struct { value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_614_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a, ?*const zx_type_909, };

pub const value_zx_type_910_56d3a3384af94c4c5beea8da80c665c922686500c24f911e92fe4db704c5a3bf = struct { value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_614_9959815e5ae6c7870ec97a8fdf3ed12a0c7bf34b29c357590c9c92a6eaf7bf7a, value_zx_type_573_cc081934d258ff48f42c09545687cf0482e8c3007254b4930be20103ed103fdf, ?*const zx_type_910, };

pub const value_zx_type_911_797fedc00020e01168f99323a87b071e9e1bdebae23b4195463f8ae8c1241ef7 = struct {
    action: zx_type_570,
    count: u64,
    index: u64,
    layout: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    memo_first: u64,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    rewrite_action: zx_type_561,
    saved: value_zx_type_571_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    state_first: u64,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_911 = null,
};

pub const value_zx_type_913_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const zx_type_576, ?zx_type_576, ?*const zx_type_913, };

pub const value_zx_type_914_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const zx_type_576, void, ?*const zx_type_914, };

pub const value_zx_type_915_463372a636e1a2c93bbb2070e2204f09a436eef0f006e94b3d11fa862ef159e2 = struct {
    count: u64,
    first: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    merge: bool,
    parents: []const u64,
    references: []const bool,
    saved: []const u64,
    source: []const u64,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_915 = null,
};

pub const value_zx_type_916_2b3f0033db751cf78256c30d401a1a8639ee63997cf1909aeaff24112d21a8c6 = struct {
    activation: u64,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    loops: value_zx_type_586_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    references: []const bool,
    seen: bool,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_916 = null,
};

pub const value_zx_type_917_57c8216039667f25f8124cd801f82d6db9b8e64f4e9aa500df6f0cbf67657227 = struct {
    activation: u64,
    changed: bool,
    count: u64,
    facts: []const u64,
    first: u64,
    forest: value_zx_type_550_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    loops: value_zx_type_586_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    references: []const bool,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    value: u64,
    zx_origin: ?*const zx_type_917 = null,
};

pub const value_zx_type_918_87c1c976ed99693bb0b79319ced55961e2f09cd998a5c93ecc538e2ca8eb719e = struct {
    count: u64,
    facts: []const u64,
    first: u64,
    index: u64,
    layout: value_zx_type_531_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    local_first: u64,
    locals: u64,
    memory: value_zx_type_572_9e60a83da2934812a9544e6e6d5a28bdec5ff1dad2916521e06d6b7369a0ec2d,
    references: []const bool,
    roots: []const u64,
    symbols: []const u64,
    types: value_zx_type_51_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    zx_origin: ?*const zx_type_918 = null,
};

pub const value_zx_type_919_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    flags: []const bool,
    symbols: u64,
    zx_origin: ?*const zx_type_919 = null,
};

pub const value_zx_type_920_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    first: u64,
    flags: []const bool,
    index: u64,
    symbols: []const u64,
    zx_origin: ?*const zx_type_920 = null,
};

pub const value_zx_type_921_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    flags: []const bool,
    index: u64,
    memo: []const u64,
    parents: []const u64,
    zx_origin: ?*const zx_type_921 = null,
};

pub const value_zx_type_922_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u64,
    parents: []const u64,
    zx_origin: ?*const zx_type_922 = null,
};

pub const value_zx_type_923_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    facts: []const u64,
    flags: []const bool,
    index: u64,
    outputs: []const u64,
    roots: []const u64,
    source: []const u64,
    zx_origin: ?*const zx_type_923 = null,
};

pub const value_zx_type_924_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    found: bool,
    index: u64,
    slots: *const zx_type_35,
    zx_origin: ?*const zx_type_924 = null,
};

pub const value_zx_type_925_45c9de4479c865238cef7a36dce7217ac4de64b83f4320ae5b044d7e2faff701 = struct {
    active: bool,
    ascending: bool,
    expression: u64,
    expressions: *const zx_type_34,
    found: bool,
    layout: value_zx_type_536_32e2949509cb40a52063f069209596bb6717fb6fe825f14a951b546cf8bc366d,
    memo: []const u64,
    position: u64,
    trail: []const u64,
    zx_origin: ?*const zx_type_925 = null,
};

pub const value_zx_type_926_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    children: []const u64,
    count: u64,
    index: u64,
    zx_origin: ?*const zx_type_926 = null,
};

pub const value_zx_type_927_39e74984115c929e88eabd575698c342998222fa7ee1c2957f496eb4bea9c312 = struct { value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_615_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134, ?*const zx_type_927, };

pub const value_zx_type_928_3ef121c2969f416beec22224e6006647d628ebbbd818e782fec8feea9c3aa01c = struct { value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_615_c3889be5aff8db49232c275de4102909235123747f9ac8ea09f881b38cb5f134, value_zx_type_580_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_928, };

pub const value_zx_type_929_ba9e1700dfc166edcda60abb91e23d2d790cb2e9c86a2b6303924249829cb607 = struct { value_zx_type_616_01927fc72980f9f7e06f02c430cda24b1bfe582ea8131a0ec2f6be4c7b3ca6e4, ?*const zx_type_929, };

pub const value_zx_type_930_5db2664a1cf0e28679b65fcdbb67bc80c32535971f547c803e444fa6eebf5e6d = struct { value_zx_type_616_01927fc72980f9f7e06f02c430cda24b1bfe582ea8131a0ec2f6be4c7b3ca6e4, value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, ?*const zx_type_930, };

pub const value_zx_type_931_404c9fb433dcc5016a50e9385b71cf1ee82410866a03c60832a48ed92a911b25 = struct { value_zx_type_616_01927fc72980f9f7e06f02c430cda24b1bfe582ea8131a0ec2f6be4c7b3ca6e4, value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_580_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, ?*const zx_type_931, };

pub const value_zx_type_932_9d9af749b373f29491d7ba654e4ce4f813f067d9e9d379099db7f378bd57eeaf = struct { value_zx_type_616_01927fc72980f9f7e06f02c430cda24b1bfe582ea8131a0ec2f6be4c7b3ca6e4, value_zx_type_522_13d3204733b822b38df09f2b99b1253872c37bb07348389d67b1b79e19284695, value_zx_type_580_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, value_zx_type_613_e62b71435b6fa6b25036c5b47e62be7c9229f7704c315733b67b8d1fc43c1d7b, ?*const zx_type_932, };

pub const value_zx_type_933_a4f261019b29429d0cbd4470d3003fdc3e83a840206c71e918e2d7143e58a95c = struct { value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234, ?*const zx_type_933, };

pub const value_zx_type_934_16754ee01793f374faa41ae08f9735fb869b8024290b65286b5e3c2f74b8f5e3 = struct { value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_934, };

pub const value_zx_type_935_3b56ea7a4480803bf1ebed93b5632e754d4d90d196841c10585fe0ff91470ca1 = struct { value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_935, };

pub const value_zx_type_936_4a4d5b359ddb915abaab3d240b7f7c8074ff85af853b95e8582b243168d4f21b = struct { value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_936, };

pub const value_zx_type_937_1d94bbb56b26a3d58072ce099175d2418edeece4ddacc6c78b8b7aec6b67c88a = struct { value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_937, };

pub const value_zx_type_938_07c443e9894fe80e20688b589b63e33b44f5e181b9406c9b2e33c1342b533a23 = struct { value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_938, };

pub const value_zx_type_939_78def5dc030456ae8e5c21187af4e7729009887dade6122428f1fba73409102a = struct { value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_939, };

pub const value_zx_type_940_e0819f3b69adf7be9a20d4ef85c2da353e4c4527a7b322d088f01d1f19eac74b = struct { value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_940, };

pub const value_zx_type_941_054395fa4048de15e82337829c90d4c0f1c1e911e2cd2e2ed703b2f88fcdcea3 = struct { value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, ?*const zx_type_941, };

pub const value_zx_type_942_cd8bd391b219c811ee9f62de4e3ad2b292228b5a9120526fa543d5ae67486f8f = struct { value_zx_type_185_4109c9401386930286dd1c3927c58db65eb5b7e74893760e73afe2a253d67234, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_189_a71c7972c779a6a822147c3dd33553d3a2b50e52996abf0a02a60da45b3d122a, value_zx_type_190_2473023bce8bf30edddad3d0973b2d3f36e9323c91cc1063d2e3c2123dd47f52, ?*const zx_type_942, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
    pub const @"std:encoding" = struct {
        pub const encodeBase64 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeBase64 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const encodeHex = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeHex = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const encodeUtf8 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const decodeUtf8 = struct {
            pub const Input = []const u8;
            pub const Output = []const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = []const u8;
        };
        pub const sliceBytes = struct {
            pub const Input = *const zx_type_202;
            pub const Output = []const u8;
            pub const InputValue = zx_type_202;
            pub const OutputValue = []const u8;
        };
    };
    pub const @"zig:floats" = struct {
        pub const narrow = struct {
            pub const Input = f64;
            pub const Output = f32;
            pub const InputValue = f64;
            pub const OutputValue = f32;
        };
        pub const widen = struct {
            pub const Input = f32;
            pub const Output = f64;
            pub const InputValue = f32;
            pub const OutputValue = f64;
        };
        pub const isFinite = struct {
            pub const Input = f64;
            pub const Output = bool;
            pub const InputValue = f64;
            pub const OutputValue = bool;
        };
        pub const parse32 = struct {
            pub const Input = []const u8;
            pub const Output = ?f32;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f32;
        };
        pub const parse64 = struct {
            pub const Input = []const u8;
            pub const Output = ?f64;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f64;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
    pub const @"std:encoding" = struct {
    };
    pub const @"zig:floats" = struct {
    };
};

