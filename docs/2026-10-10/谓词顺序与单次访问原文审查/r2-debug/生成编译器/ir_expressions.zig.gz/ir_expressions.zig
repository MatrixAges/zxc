const std = @import("std");

const zx_native_0 = @import("integers");

const zx_native_1 = @import("floats");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .scalar, };

const zx_shape_13 = .{ .kind = .scalar, };

const zx_shape_14 = .{ .kind = .scalar, };

const zx_shape_15 = .{ .kind = .scalar, };

const zx_shape_16 = .{ .kind = .scalar, };

const zx_shape_17 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_18 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_19 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .children = zx_shape_18, .field_names = zx_shape_19, .field_types = zx_shape_18, .first = zx_shape_18, .kinds = zx_shape_17, .labels = zx_shape_19, .names = zx_shape_19, .second = zx_shape_18, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .base = zx_shape_20, .delta = zx_shape_20, }, };

const zx_shape_22 = .{ .kind = .object, .fields = .{ .names = zx_shape_19, .types = zx_shape_18, }, };

const zx_shape_23 = .{ .kind = .object, .fields = .{ .delta = zx_shape_1, .first = zx_shape_4, .kind = zx_shape_16, .label = zx_shape_10, .second = zx_shape_4, }, };

const zx_shape_24 = .{ .kind = .list, .child = zx_shape_11, };

const zx_shape_25 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_26 = .{ .kind = .list, .child = zx_shape_9, };

const zx_shape_27 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_28 = .{ .kind = .optional, .child = zx_shape_4, };

const zx_shape_29 = .{ .kind = .list, .child = zx_shape_28, };

const zx_shape_30 = .{ .kind = .list, .child = zx_shape_12, };

const zx_shape_31 = .{ .kind = .list, .child = zx_shape_13, };

const zx_shape_32 = .{ .kind = .list, .child = zx_shape_14, };

const zx_shape_33 = .{ .kind = .list, .child = zx_shape_15, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .awaits = zx_shape_18, .binary_left = zx_shape_18, .binary_operators = zx_shape_33, .binary_right = zx_shape_18, .booleans = zx_shape_27, .call_arguments = zx_shape_18, .call_functions = zx_shape_18, .call_store_count = zx_shape_18, .call_store_first = zx_shape_18, .call_stores = zx_shape_18, .cancellations = zx_shape_18, .captures = zx_shape_18, .collection_arguments = zx_shape_18, .collection_count = zx_shape_18, .collection_first = zx_shape_18, .collection_kinds = zx_shape_30, .collection_targets = zx_shape_18, .conditional_conditions = zx_shape_18, .conditional_no = zx_shape_18, .conditional_yes = zx_shape_18, .enumerations = zx_shape_18, .errors = zx_shape_18, .floats = zx_shape_26, .index_targets = zx_shape_18, .index_values = zx_shape_18, .integers = zx_shape_25, .iteration_bodies = zx_shape_18, .iteration_condition_parameters = zx_shape_18, .iteration_conditions = zx_shape_18, .iteration_initials = zx_shape_18, .iteration_parameters = zx_shape_18, .iteration_postconditions = zx_shape_27, .kinds = zx_shape_24, .lengths = zx_shape_18, .match_conditions = zx_shape_18, .match_count = zx_shape_18, .match_fallbacks = zx_shape_18, .match_first = zx_shape_18, .match_results = zx_shape_18, .match_subjects = zx_shape_29, .negative_integers = zx_shape_25, .object_count = zx_shape_18, .object_evaluation_count = zx_shape_18, .object_evaluation_first = zx_shape_18, .object_evaluation_values = zx_shape_18, .object_field_indices = zx_shape_18, .object_field_values = zx_shape_18, .object_first = zx_shape_18, .optional_values = zx_shape_18, .parallel_count = zx_shape_18, .parallel_fields = zx_shape_29, .parallel_first = zx_shape_18, .parallel_tasks = zx_shape_18, .payloads = zx_shape_18, .projection_indices = zx_shape_18, .projection_targets = zx_shape_18, .references = zx_shape_18, .scope_borrows = zx_shape_27, .scope_count = zx_shape_18, .scope_first = zx_shape_18, .scope_results = zx_shape_18, .scope_symbols = zx_shape_29, .scope_values = zx_shape_18, .sequence_count = zx_shape_18, .sequence_first = zx_shape_18, .sequence_items = zx_shape_18, .some = zx_shape_18, .span_end = zx_shape_25, .span_start = zx_shape_25, .stores = zx_shape_18, .strings = zx_shape_19, .task_bodies = zx_shape_18, .task_capture_count = zx_shape_18, .task_capture_first = zx_shape_18, .task_captures = zx_shape_18, .transform_bodies = zx_shape_18, .transform_count = zx_shape_18, .transform_first = zx_shape_18, .transform_initials = zx_shape_29, .transform_kinds = zx_shape_31, .transform_parameters = zx_shape_18, .transform_targets = zx_shape_18, .types = zx_shape_18, .unary_operands = zx_shape_18, .unary_operators = zx_shape_32, .update_indices = zx_shape_18, .update_targets = zx_shape_18, .update_values = zx_shape_18, }, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_34, .id = zx_shape_4, .index = zx_shape_5, .type_id = zx_shape_4, }, };

const zx_shape_36 = .{ .kind = .object, .fields = .{ .handles = zx_shape_19, .paths = zx_shape_19, .readable = zx_shape_27, .types = zx_shape_18, .writable = zx_shape_27, }, };

const zx_shape_37 = .{ .kind = .scalar, };

const zx_shape_38 = .{ .kind = .list, .child = zx_shape_37, };

const zx_shape_39 = .{ .kind = .object, .fields = .{ .names = zx_shape_19, .ownership = zx_shape_38, .span_end = zx_shape_25, .span_start = zx_shape_25, .types = zx_shape_18, }, };

const zx_shape_40 = .{ .kind = .list, .child = zx_shape_36, };

const zx_shape_41 = .{ .kind = .object, .fields = .{ .input_types = zx_shape_18, .output_types = zx_shape_18, .stores = zx_shape_40, }, };

const zx_shape_42 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_34, .functions = zx_shape_41, .index = zx_shape_5, .orchestration = zx_shape_1, .stores = zx_shape_36, .symbols = zx_shape_39, .table = zx_shape_20, }, };

const zx_shape_43 = .{ .kind = .object, .fields = .{ .context = zx_shape_42, .kind = zx_shape_11, .payload = zx_shape_5, .target = zx_shape_16, .type_id = zx_shape_4, }, };

const zx_shape_44 = .{ .kind = .scalar, };

const zx_shape_45 = .{ .kind = .optional, .child = zx_shape_8, };

const zx_shape_46 = .{ .kind = .optional, .child = zx_shape_9, };

const zx_shape_47 = .{ .kind = .object, .fields = .{ .available = zx_shape_36, .count = zx_shape_5, .first = zx_shape_5, .orchestration = zx_shape_1, .required = zx_shape_36, .slots = zx_shape_18, }, };

const zx_shape_48 = .{ .kind = .object, .fields = .{ .table = zx_shape_20, .type_id = zx_shape_4, }, };

const zx_shape_49 = .{ .kind = .object, .fields = .{ .available = zx_shape_36, .count = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .required = zx_shape_36, .slots = zx_shape_18, .valid = zx_shape_1, }, };

const zx_shape_50 = .{ .kind = .object, .fields = .{ .first = zx_shape_5, .found = zx_shape_1, .id = zx_shape_4, .index = zx_shape_5, .limit = zx_shape_5, .slots = zx_shape_18, }, };

const zx_shape_51 = .{ .kind = .object, .fields = .{ .condition_type = zx_shape_4, .context = zx_shape_42, .count = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .result_type = zx_shape_4, .valid = zx_shape_1, }, };

const zx_shape_52 = .{ .kind = .object, .fields = .{ .context = zx_shape_42, .count = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_53 = .{ .kind = .object, .fields = .{ .context = zx_shape_42, .count = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .type_first = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_54 = .{ .kind = .object, .fields = .{ .field = zx_shape_5, .first = zx_shape_5, .found = zx_shape_1, .index = zx_shape_5, .indices = zx_shape_18, .limit = zx_shape_5, }, };

const zx_shape_55 = .{ .kind = .object, .fields = .{ .context = zx_shape_42, .count = zx_shape_5, .element = zx_shape_4, .first = zx_shape_5, .index = zx_shape_5, .operation = zx_shape_12, .source = zx_shape_4, .valid = zx_shape_1, }, };

const zx_shape_56 = .{ .kind = .object, .fields = .{ .check = zx_shape_43, .count = zx_shape_5, .fields = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_57 = .{ .kind = .object, .fields = .{ .field = zx_shape_28, .fields = zx_shape_29, .first = zx_shape_5, .found = zx_shape_1, .index = zx_shape_5, .limit = zx_shape_5, .task = zx_shape_4, .tasks = zx_shape_18, }, };

const zx_shape_58 = .{ .kind = .object, .fields = .{ .check = zx_shape_43, .count = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_59 = .{ .kind = .object, .fields = .{ .captures = zx_shape_18, .first = zx_shape_5, .found = zx_shape_1, .index = zx_shape_5, .limit = zx_shape_5, .symbol = zx_shape_4, }, };

const zx_shape_60 = .{ .kind = .object, .fields = .{ .context = zx_shape_42, .context_type = zx_shape_4, .count = zx_shape_5, .element = zx_shape_4, .first = zx_shape_5, .index = zx_shape_5, .operation = zx_shape_13, .valid = zx_shape_1, }, };

const zx_shape_61 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_42, }, };

const zx_shape_62 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_42, .@"1" = zx_shape_1, }, };

pub const input_shape = zx_shape_42;

pub const output_shape = zx_shape_1;

pub const Input = *const (zx_abi).zx_type_42;

pub const Output = bool;

fn function_0(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: u8) error{ }!u64 {
    const native_result = (zx_native_0).widenByte(in);

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: f64) error{ }!f32 {
    const native_result = (zx_native_1).narrow(in);

    _ = allocator;

    return native_result;
}

fn function_4(allocator: ((std).mem).Allocator, in: f32) error{ }!f64 {
    const native_result = (zx_native_1).widen(in);

    _ = allocator;

    return native_result;
}

fn function_5(allocator: ((std).mem).Allocator, in: f64) error{ }!bool {
    const native_result = (zx_native_1).isFinite(in);

    _ = allocator;

    return native_result;
}

fn function_6(allocator: ((std).mem).Allocator, in: []const u8) error{ }!?f32 {
    const native_result = (zx_native_1).parse32(in);

    _ = allocator;

    return native_result;
}

fn function_7(allocator: ((std).mem).Allocator, in: []const u8) error{ }!?f64 {
    const native_result = (zx_native_1).parse64(in);

    _ = allocator;

    return native_result;
}

fn function_8(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_16 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_2: {
        const operand_1 = in;

        break :block_2 (if ((operand_1 == @as(u8, 0))) @as((zx_abi).zx_type_16, .Scalar) else (if ((operand_1 == @as(u8, 1))) @as((zx_abi).zx_type_16, .Object) else (if ((operand_1 == @as(u8, 2))) @as((zx_abi).zx_type_16, .Optional) else (if ((operand_1 == @as(u8, 3))) @as((zx_abi).zx_type_16, .List) else (if ((operand_1 == @as(u8, 4))) @as((zx_abi).zx_type_16, .Tuple) else (if ((operand_1 == @as(u8, 5))) @as((zx_abi).zx_type_16, .ErrorSet) else (if ((operand_1 == @as(u8, 6))) @as((zx_abi).zx_type_16, .Task) else (if ((operand_1 == @as(u8, 7))) @as((zx_abi).zx_type_16, .Enumeration) else @as((zx_abi).zx_type_16, .NativeReference)))))))));
    };
}

fn function_9(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_16 {
    @setRuntimeSafety(true);

    return (try function_8(allocator, in));
}

fn function_10(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_35) error{ IndexOutOfBounds, }!bool {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_0(allocator, (in).id));

    return ((value_1 < (in).index) and (block_3: {
        const operand_1 = ((in).expressions).types;
        const operand_2 = value_1;

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    } == (in).type_id));
}

fn function_11(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;
    const value_3: (zx_abi).zx_type_20 = (((&value_1)).table).*;

    if (((in).kind == @as((zx_abi).zx_type_11, .Some))) {
        return (((in).target == @as((zx_abi).zx_type_16, .Optional)) and block_62: {
            const operand_51 = (&value_2);
            const operand_52 = ((&value_1)).index;
            const operand_56 = block_55: {
                const operand_53 = ((&value_2)).some;
                const operand_54 = (in).payload;

                if ((operand_54 >= (operand_53).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_55 (operand_53)[@intCast(operand_54)];
            };
            const operand_60 = block_59: {
                const operand_57 = ((&value_3)).first;
                const operand_58 = (try function_0(allocator, (in).type_id));

                if ((operand_58 >= (operand_57).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_59 (operand_57)[@intCast(operand_58)];
            };
            const operand_61 = (zx_abi).zx_type_35{ .expressions = operand_51, .index = operand_52, .id = operand_56, .type_id = operand_60, };

            break :block_62 (try function_10(allocator, (&operand_61)));
        });
    }

    const value_4: u32 = block_50: {
        const operand_37 = (in).kind;

        break :block_50 (if ((operand_37 == @as((zx_abi).zx_type_11, .OptionalValue))) block_49: {
            const operand_47 = ((&value_2)).optional_values;
            const operand_48 = (in).payload;

            if ((operand_48 >= (operand_47).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_49 (operand_47)[@intCast(operand_48)];
        } else (if ((operand_37 == @as((zx_abi).zx_type_11, .Length))) block_46: {
            const operand_44 = ((&value_2)).lengths;
            const operand_45 = (in).payload;

            if ((operand_45 >= (operand_44).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_46 (operand_44)[@intCast(operand_45)];
        } else (if ((operand_37 == @as((zx_abi).zx_type_11, .Index))) block_43: {
            const operand_41 = ((&value_2)).index_targets;
            const operand_42 = (in).payload;

            if ((operand_42 >= (operand_41).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_43 (operand_41)[@intCast(operand_42)];
        } else block_40: {
            const operand_38 = ((&value_2)).projection_targets;
            const operand_39 = (in).payload;

            if ((operand_39 >= (operand_38).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_40 (operand_38)[@intCast(operand_39)];
        })));
    };
    const value_5: u64 = (try function_0(allocator, value_4));

    if ((value_5 >= ((&value_1)).index)) {
        return false;
    }

    const value_6: u32 = block_36: {
        const operand_34 = ((&value_2)).types;
        const operand_35 = value_5;

        if ((operand_35 >= (operand_34).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_36 (operand_34)[@intCast(operand_35)];
    };
    const value_7: u64 = (try function_0(allocator, value_6));
    const value_8: (zx_abi).zx_type_16 = (try function_9(allocator, block_33: {
        const operand_31 = ((&value_3)).kinds;
        const operand_32 = value_7;

        if ((operand_32 >= (operand_31).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_33 (operand_31)[@intCast(operand_32)];
    }));

    if (((in).kind == @as((zx_abi).zx_type_11, .OptionalValue))) {
        return ((value_8 == @as((zx_abi).zx_type_16, .Optional)) and (block_30: {
            const operand_28 = ((&value_3)).first;
            const operand_29 = value_7;

            if ((operand_29 >= (operand_28).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_30 (operand_28)[@intCast(operand_29)];
        } == (in).type_id));
    }

    if (((in).kind == @as((zx_abi).zx_type_11, .Length))) {
        return (((in).type_id == @as(u32, 5)) and ((value_8 == @as((zx_abi).zx_type_16, .List)) or (value_6 == @as(u32, 10))));
    }

    if (((in).kind == @as((zx_abi).zx_type_11, .Index))) {
        return (block_24: {
            const operand_16 = (&value_2);
            const operand_17 = ((&value_1)).index;
            const operand_21 = block_20: {
                const operand_18 = ((&value_2)).index_values;
                const operand_19 = (in).payload;

                if ((operand_19 >= (operand_18).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_20 (operand_18)[@intCast(operand_19)];
            };
            const operand_22 = @as(u32, 5);
            const operand_23 = (zx_abi).zx_type_35{ .expressions = operand_16, .index = operand_17, .id = operand_21, .type_id = operand_22, };

            break :block_24 (try function_10(allocator, (&operand_23)));
        } and (if ((value_6 == @as(u32, 10))) ((in).type_id == @as(u32, 2)) else ((value_8 == @as((zx_abi).zx_type_16, .List)) and (block_27: {
            const operand_25 = ((&value_3)).first;
            const operand_26 = value_7;

            if ((operand_26 >= (operand_25).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_27 (operand_25)[@intCast(operand_26)];
        } == (in).type_id))));
    }

    const value_9: u64 = (try function_0(allocator, block_15: {
        const operand_13 = ((&value_2)).projection_indices;
        const operand_14 = (in).payload;

        if ((operand_14 >= (operand_13).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_15 (operand_13)[@intCast(operand_14)];
    }));
    const value_10: u64 = (try function_0(allocator, block_12: {
        const operand_10 = ((&value_3)).first;
        const operand_11 = value_7;

        if ((operand_11 >= (operand_10).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_12 (operand_10)[@intCast(operand_11)];
    }));

    if ((value_9 >= (try function_0(allocator, block_9: {
        const operand_7 = ((&value_3)).second;
        const operand_8 = value_7;

        if ((operand_8 >= (operand_7).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_9 (operand_7)[@intCast(operand_8)];
    })))) {
        return false;
    }

    return (if (((in).kind == @as((zx_abi).zx_type_11, .Field))) ((value_8 == @as((zx_abi).zx_type_16, .Object)) and (block_3: {
        const operand_1 = ((&value_3)).field_types;
        const operand_2 = (value_10 + value_9);

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    } == (in).type_id)) else ((value_8 == @as((zx_abi).zx_type_16, .Tuple)) and (block_6: {
        const operand_4 = ((&value_3)).children;
        const operand_5 = (value_10 + value_9);

        if ((operand_5 >= (operand_4).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_6 (operand_4)[@intCast(operand_5)];
    } == (in).type_id)));
}

fn function_12(allocator: ((std).mem).Allocator, in: u32) error{ }!(zx_abi).zx_type_44 {
    @setRuntimeSafety(true);

    _ = allocator;

    if (((in >= @as(u32, 2)) and (in <= @as(u32, 5)))) {
        return @as((zx_abi).zx_type_44, .Integer);
    }

    if (((in == @as(u32, 6)) or (in == @as(u32, 7)))) {
        return @as((zx_abi).zx_type_44, .Signed);
    }

    return (if (((in == @as(u32, 8)) or (in == @as(u32, 9)))) @as((zx_abi).zx_type_44, .Float) else @as((zx_abi).zx_type_44, .Other));
}

fn function_13(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_34 = (((in).context).expressions).*;

    if ((((in).kind == @as((zx_abi).zx_type_11, .Integer)) or ((in).kind == @as((zx_abi).zx_type_11, .NegativeInteger)))) {
        const value_2: (zx_abi).zx_type_44 = (try function_12(allocator, (in).type_id));
        const value_3: bool = ((in).kind == @as((zx_abi).zx_type_11, .NegativeInteger));

        if ((((value_2 != @as((zx_abi).zx_type_44, .Integer)) and (value_2 != @as((zx_abi).zx_type_44, .Signed))) or (value_3 and (value_2 != @as((zx_abi).zx_type_44, .Signed))))) {
            return false;
        }

        const value_4: u64 = block_40: {
            const operand_39 = (in).type_id;

            break :block_40 (if ((operand_39 == @as(u32, 2))) @as(u64, 255) else (if ((operand_39 == @as(u32, 3))) @as(u64, 65535) else (if ((operand_39 == @as(u32, 4))) @as(u64, 4294967295) else (if ((operand_39 == @as(u32, 5))) @as(u64, 18446744073709551615) else (if ((operand_39 == @as(u32, 6))) (if (value_3) @as(u64, 2147483648) else @as(u64, 2147483647)) else (if (value_3) @as(u64, 9223372036854775808) else @as(u64, 9223372036854775807)))))));
        };
        const value_5: u64 = (if (value_3) block_35: {
            const operand_33 = ((&value_1)).negative_integers;
            const operand_34 = (in).payload;

            if ((operand_34 >= (operand_33).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_35 (operand_33)[@intCast(operand_34)];
        } else block_38: {
            const operand_36 = ((&value_1)).integers;
            const operand_37 = (in).payload;

            if ((operand_37 >= (operand_36).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_38 (operand_36)[@intCast(operand_37)];
        });

        return (value_5 <= value_4);
    }

    if (((in).kind == @as((zx_abi).zx_type_11, .Float))) {
        const value_6: f64 = block_32: {
            const operand_30 = ((&value_1)).floats;
            const operand_31 = (in).payload;

            if ((operand_31 >= (operand_30).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_32 (operand_30)[@intCast(operand_31)];
        };

        return ((((try function_12(allocator, (in).type_id)) == @as((zx_abi).zx_type_44, .Float)) and (try function_5(allocator, value_6))) and (((in).type_id != @as(u32, 8)) or ((try function_4(allocator, (try function_3(allocator, value_6)))) == value_6)));
    }

    if (((in).kind == @as((zx_abi).zx_type_11, .StoreGet))) {
        const value_7: u64 = (try function_0(allocator, block_29: {
            const operand_27 = ((&value_1)).stores;
            const operand_28 = (in).payload;

            if ((operand_28 >= (operand_27).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_29 (operand_27)[@intCast(operand_28)];
        }));

        return (((value_7 < @as(u64, ((((in).context).stores).paths).len)) and block_23: {
            const operand_21 = (((in).context).stores).readable;
            const operand_22 = value_7;

            if ((operand_22 >= (operand_21).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_23 (operand_21)[@intCast(operand_22)];
        }) and (block_26: {
            const operand_24 = (((in).context).stores).types;
            const operand_25 = value_7;

            if ((operand_25 >= (operand_24).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_26 (operand_24)[@intCast(operand_25)];
        } == (in).type_id));
    }

    if (((in).kind == @as((zx_abi).zx_type_11, .Reference))) {
        const value_8: u64 = (try function_0(allocator, block_20: {
            const operand_18 = ((&value_1)).references;
            const operand_19 = (in).payload;

            if ((operand_19 >= (operand_18).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_20 (operand_18)[@intCast(operand_19)];
        }));

        return ((value_8 < @as(u64, ((((in).context).symbols).names).len)) and (block_17: {
            const operand_15 = (((in).context).symbols).types;
            const operand_16 = value_8;

            if ((operand_16 >= (operand_15).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_17 (operand_15)[@intCast(operand_16)];
        } == (in).type_id));
    }

    return block_14: {
        const operand_1 = (in).kind;

        break :block_14 (if ((operand_1 == @as((zx_abi).zx_type_11, .String))) ((in).type_id == @as(u32, 10)) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Boolean))) ((in).type_id == @as(u32, 1)) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Unit))) ((in).type_id == @as(u32, 0)) else (if ((operand_1 == @as((zx_abi).zx_type_11, .None))) ((in).target == @as((zx_abi).zx_type_16, .Optional)) else (if ((operand_1 == @as((zx_abi).zx_type_11, .EnumValue))) (((in).target == @as((zx_abi).zx_type_16, .Enumeration)) and (block_10: {
            const operand_8 = ((&value_1)).enumerations;
            const operand_9 = (in).payload;

            if ((operand_9 >= (operand_8).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_10 (operand_8)[@intCast(operand_9)];
        } < block_13: {
            const operand_11 = (((in).context).table).second;
            const operand_12 = (try function_0(allocator, (in).type_id));

            if ((operand_12 >= (operand_11).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_13 (operand_11)[@intCast(operand_12)];
        })) else (if ((operand_1 == @as((zx_abi).zx_type_11, .ErrorValue))) (((in).target == @as((zx_abi).zx_type_16, .ErrorSet)) and (block_4: {
            const operand_2 = ((&value_1)).errors;
            const operand_3 = (in).payload;

            if ((operand_3 >= (operand_2).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_4 (operand_2)[@intCast(operand_3)];
        } < block_7: {
            const operand_5 = (((in).context).table).second;
            const operand_6 = (try function_0(allocator, (in).type_id));

            if ((operand_6 >= (operand_5).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_7 (operand_5)[@intCast(operand_6)];
        })) else false))))));
    };
}

fn function_14(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_36) error{ }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: u64 = @as(u64, ((in).paths).len);

    return (((((value_1 <= @as(u64, 4294967295)) and (@as(u64, ((in).types).len) == value_1)) and (@as(u64, ((in).handles).len) == value_1)) and (@as(u64, ((in).readable).len) == value_1)) and (@as(u64, ((in).writable).len) == value_1));
}

fn function_15(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_47) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if (((((((!(try function_14(allocator, (in).available))) or (!(try function_14(allocator, (in).required)))) or ((in).first > @as(u64, ((in).slots).len))) or ((in).count > (@as(u64, ((in).slots).len) - (in).first))) or ((in).count != @as(u64, (((in).required).paths).len))) or (((in).count != @as(u64, 0)) and (!(in).orchestration)))) {
        return false;
    }

    return block_74: {
        const operand_10 = block_9: {
            const operand_2 = (in).available;
            const operand_3 = (in).required;
            const operand_4 = (in).slots;
            const operand_5 = (in).first;
            const operand_6 = (in).count;
            const operand_7 = @as(u64, 0);
            const operand_8 = true;

            break :block_9 (zx_abi).zx_type_49{ .available = operand_2, .required = operand_3, .slots = operand_4, .first = operand_5, .count = operand_6, .index = operand_7, .valid = operand_8, };
        };

        var state_1: (zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .available = (operand_10).available, .count = (operand_10).count, .first = (operand_10).first, .index = (operand_10).index, .required = (operand_10).required, .slots = (operand_10).slots, .valid = (operand_10).valid, .zx_origin = (&operand_10), };

        while (((state_1).valid and ((state_1).index < (state_1).count))) {
            state_1 = block_73: {
                const value_3: u32 = block_72: {
                    const operand_70 = (state_1).slots;
                    const operand_71 = ((state_1).first + (state_1).index);

                    if ((operand_71 >= (operand_70).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_72 (operand_70)[@intCast(operand_71)];
                };
                const value_4: u64 = (try function_0(allocator, block_69: {
                    break :block_69 value_3;
                }));
                const value_13: (zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if ((block_13: {
                    break :block_13 value_4;
                } >= @as(u64, (((state_1).available).paths).len))) block_15: {
                    const value_5: (zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_14: {
                        break :block_14 @as((zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .available = (state_1).available, .count = (state_1).count, .first = (state_1).first, .index = (state_1).index, .required = (state_1).required, .slots = (state_1).slots, .valid = false, });
                    };

                    break :block_15 value_5;
                } else block_68: {
                    const value_11: (zx_abi).value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_67: {
                        const operand_57 = block_56: {
                            const operand_49 = (state_1).slots;
                            const operand_50 = (state_1).first;
                            const operand_51 = (state_1).index;
                            const operand_52 = @as(u64, 0);
                            const operand_53 = block_54: {
                                break :block_54 value_3;
                            };
                            const operand_55 = false;

                            break :block_56 @as((zx_abi).value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .slots = operand_49, .first = operand_50, .limit = operand_51, .index = operand_52, .id = operand_53, .found = operand_55, });
                        };

                        var state_48: (zx_abi).value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = operand_57;

                        var state_changed_58 = false;

                        while ((((state_48).index < (state_48).limit) and (!(state_48).found))) {
                            state_48 = block_65: {
                                const value_8: (zx_abi).value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_64: {
                                    break :block_64 @as((zx_abi).value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .first = (state_48).first, .found = (block_63: {
                                        const operand_61 = (state_48).slots;
                                        const operand_62 = ((state_48).first + (state_48).index);

                                        if ((operand_62 >= (operand_61).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_63 (operand_61)[@intCast(operand_62)];
                                    } == (state_48).id), .id = (state_48).id, .index = (state_48).index, .limit = (state_48).limit, .slots = (state_48).slots, });
                                };
                                const value_9: u64 = (value_8).index;
                                const value_10: (zx_abi).value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_60: {
                                    break :block_60 @as((zx_abi).value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .first = (value_8).first, .found = (value_8).found, .id = (value_8).id, .index = (block_59: {
                                        break :block_59 value_9;
                                    } + @as(u64, 1)), .limit = (value_8).limit, .slots = (value_8).slots, });
                                };

                                break :block_65 value_10;
                            };

                            state_changed_58 = true;
                        }

                        break :block_67 (if (state_changed_58) state_48 else operand_57);
                    };
                    const value_12: (zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_47: {
                        break :block_47 @as((zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .available = (state_1).available, .count = (state_1).count, .first = (state_1).first, .index = (state_1).index, .required = (state_1).required, .slots = (state_1).slots, .valid = (((((!(value_11).found) and (block_19: {
                            const operand_17 = ((state_1).available).types;
                            const operand_18 = block_16: {
                                break :block_16 value_4;
                            };

                            if ((operand_18 >= (operand_17).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_19 (operand_17)[@intCast(operand_18)];
                        } == block_22: {
                            const operand_20 = ((state_1).required).types;
                            const operand_21 = (state_1).index;

                            if ((operand_21 >= (operand_20).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_22 (operand_20)[@intCast(operand_21)];
                        })) and block_32: {
                            const operand_30 = block_26: {
                                const operand_24 = ((state_1).available).paths;
                                const operand_25 = block_23: {
                                    break :block_23 value_4;
                                };

                                if ((operand_25 >= (operand_24).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_26 (operand_24)[@intCast(operand_25)];
                            };
                            const operand_31 = block_29: {
                                const operand_27 = ((state_1).required).paths;
                                const operand_28 = (state_1).index;

                                if ((operand_28 >= (operand_27).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_29 (operand_27)[@intCast(operand_28)];
                            };

                            break :block_32 ((std).mem).eql(u8, operand_30, operand_31);
                        }) and ((!block_35: {
                            const operand_33 = ((state_1).required).readable;
                            const operand_34 = (state_1).index;

                            if ((operand_34 >= (operand_33).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_35 (operand_33)[@intCast(operand_34)];
                        }) or block_39: {
                            const operand_37 = ((state_1).available).readable;
                            const operand_38 = block_36: {
                                break :block_36 value_4;
                            };

                            if ((operand_38 >= (operand_37).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_39 (operand_37)[@intCast(operand_38)];
                        })) and ((!block_42: {
                            const operand_40 = ((state_1).required).writable;
                            const operand_41 = (state_1).index;

                            if ((operand_41 >= (operand_40).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_42 (operand_40)[@intCast(operand_41)];
                        }) or block_46: {
                            const operand_44 = ((state_1).available).writable;
                            const operand_45 = block_43: {
                                break :block_43 value_4;
                            };

                            if ((operand_45 >= (operand_44).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_46 (operand_44)[@intCast(operand_45)];
                        })), });
                    };

                    break :block_68 value_12;
                });
                const value_14: u64 = (value_13).index;
                const value_15: (zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_12: {
                    break :block_12 @as((zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, (zx_abi).value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .available = (value_13).available, .count = (value_13).count, .first = (value_13).first, .index = (block_11: {
                        break :block_11 value_14;
                    } + @as(u64, 1)), .required = (value_13).required, .slots = (value_13).slots, .valid = (value_13).valid, });
                };

                break :block_73 value_15;
            };
        }

        break :block_74 (state_1).valid;
    };
}

fn function_16(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;
    const value_3: u64 = (try function_0(allocator, block_35: {
        const operand_33 = ((&value_2)).call_functions;
        const operand_34 = (in).payload;

        if ((operand_34 >= (operand_33).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_35 (operand_33)[@intCast(operand_34)];
    }));

    return ((((value_3 < @as(u64, ((((&value_1)).functions).input_types).len)) and ((in).type_id == block_3: {
        const operand_1 = (((&value_1)).functions).output_types;
        const operand_2 = value_3;

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    })) and block_15: {
        const operand_4 = (&value_2);
        const operand_5 = ((&value_1)).index;
        const operand_9 = block_8: {
            const operand_6 = ((&value_2)).call_arguments;
            const operand_7 = (in).payload;

            if ((operand_7 >= (operand_6).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_8 (operand_6)[@intCast(operand_7)];
        };
        const operand_13 = block_12: {
            const operand_10 = (((&value_1)).functions).input_types;
            const operand_11 = value_3;

            if ((operand_11 >= (operand_10).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_12 (operand_10)[@intCast(operand_11)];
        };
        const operand_14 = (zx_abi).zx_type_35{ .expressions = operand_4, .index = operand_5, .id = operand_9, .type_id = operand_13, };

        break :block_15 (try function_10(allocator, (&operand_14)));
    }) and block_32: {
        const operand_16 = ((&value_1)).stores;
        const operand_20 = block_19: {
            const operand_17 = (((&value_1)).functions).stores;
            const operand_18 = value_3;

            if ((operand_18 >= (operand_17).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_19 (operand_17)[@intCast(operand_18)];
        };
        const operand_21 = ((&value_2)).call_stores;
        const operand_25 = (try function_0(allocator, block_24: {
            const operand_22 = ((&value_2)).call_store_first;
            const operand_23 = (in).payload;

            if ((operand_23 >= (operand_22).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_24 (operand_22)[@intCast(operand_23)];
        }));
        const operand_29 = (try function_0(allocator, block_28: {
            const operand_26 = ((&value_2)).call_store_count;
            const operand_27 = (in).payload;

            if ((operand_27 >= (operand_26).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_28 (operand_26)[@intCast(operand_27)];
        }));
        const operand_30 = ((&value_1)).orchestration;
        const operand_31 = (zx_abi).zx_type_47{ .available = operand_16, .required = operand_20, .slots = operand_21, .first = operand_25, .count = operand_29, .orchestration = operand_30, };

        break :block_32 (try function_15(allocator, (&operand_31)));
    });
}

fn function_17(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;

    if (((in).kind == @as((zx_abi).zx_type_11, .Conditional))) {
        return ((block_88: {
            const operand_80 = (&value_2);
            const operand_81 = ((&value_1)).index;
            const operand_85 = block_84: {
                const operand_82 = ((&value_2)).conditional_conditions;
                const operand_83 = (in).payload;

                if ((operand_83 >= (operand_82).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_84 (operand_82)[@intCast(operand_83)];
            };
            const operand_86 = @as(u32, 1);
            const operand_87 = (zx_abi).zx_type_35{ .expressions = operand_80, .index = operand_81, .id = operand_85, .type_id = operand_86, };

            break :block_88 (try function_10(allocator, (&operand_87)));
        } and block_97: {
            const operand_89 = (&value_2);
            const operand_90 = ((&value_1)).index;
            const operand_94 = block_93: {
                const operand_91 = ((&value_2)).conditional_yes;
                const operand_92 = (in).payload;

                if ((operand_92 >= (operand_91).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_93 (operand_91)[@intCast(operand_92)];
            };
            const operand_95 = (in).type_id;
            const operand_96 = (zx_abi).zx_type_35{ .expressions = operand_89, .index = operand_90, .id = operand_94, .type_id = operand_95, };

            break :block_97 (try function_10(allocator, (&operand_96)));
        }) and block_106: {
            const operand_98 = (&value_2);
            const operand_99 = ((&value_1)).index;
            const operand_103 = block_102: {
                const operand_100 = ((&value_2)).conditional_no;
                const operand_101 = (in).payload;

                if ((operand_101 >= (operand_100).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_102 (operand_100)[@intCast(operand_101)];
            };
            const operand_104 = (in).type_id;
            const operand_105 = (zx_abi).zx_type_35{ .expressions = operand_98, .index = operand_99, .id = operand_103, .type_id = operand_104, };

            break :block_106 (try function_10(allocator, (&operand_105)));
        });
    }

    const value_3: ?u32 = block_79: {
        const operand_77 = ((&value_2)).match_subjects;
        const operand_78 = (in).payload;

        if ((operand_78 >= (operand_77).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_79 (operand_77)[@intCast(operand_78)];
    };

    if (((value_3 != null) and ((try function_0(allocator, value_3.?)) >= ((&value_1)).index))) {
        return false;
    }

    const value_4: u32 = (if ((value_3 == null)) @as(u32, 1) else block_76: {
        const operand_74 = ((&value_2)).types;
        const operand_75 = (try function_0(allocator, value_3.?));

        if ((operand_75 >= (operand_74).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_76 (operand_74)[@intCast(operand_75)];
    });
    const value_5: (zx_abi).zx_type_16 = (try function_9(allocator, block_73: {
        const operand_71 = (((&value_1)).table).kinds;
        const operand_72 = (try function_0(allocator, value_4));

        if ((operand_72 >= (operand_71).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_73 (operand_71)[@intCast(operand_72)];
    }));

    if (((value_3 != null) and ((((value_5 != @as((zx_abi).zx_type_16, .Scalar)) and (value_5 != @as((zx_abi).zx_type_16, .Enumeration))) and (value_5 != @as((zx_abi).zx_type_16, .ErrorSet))) or (value_4 == @as(u32, 0))))) {
        return false;
    }

    const value_13: (zx_abi).zx_type_51 = block_70: {
        const operand_25 = block_24: {
            const operand_11 = (&value_1);
            const operand_12 = value_4;
            const operand_13 = (in).type_id;
            const operand_14 = (try function_0(allocator, block_17: {
                const operand_15 = ((&value_2)).match_first;
                const operand_16 = (in).payload;

                if ((operand_16 >= (operand_15).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_17 (operand_15)[@intCast(operand_16)];
            }));
            const operand_18 = (try function_0(allocator, block_21: {
                const operand_19 = ((&value_2)).match_count;
                const operand_20 = (in).payload;

                if ((operand_20 >= (operand_19).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_21 (operand_19)[@intCast(operand_20)];
            }));
            const operand_22 = @as(u64, 0);
            const operand_23 = true;

            break :block_24 (zx_abi).zx_type_51{ .context = operand_11, .condition_type = operand_12, .result_type = operand_13, .first = operand_14, .count = operand_18, .index = operand_22, .valid = operand_23, };
        };

        var state_10: (zx_abi).value_zx_type_51_698b14c9054a42c897970dde7b67171e5e5a2bdf21605a4242a54005cf5cded9 = (zx_abi).value_zx_type_51_698b14c9054a42c897970dde7b67171e5e5a2bdf21605a4242a54005cf5cded9{ .condition_type = (operand_25).condition_type, .context = (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159{ .expressions = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (((operand_25).context).expressions).awaits, .binary_left = (((operand_25).context).expressions).binary_left, .binary_operators = (((operand_25).context).expressions).binary_operators, .binary_right = (((operand_25).context).expressions).binary_right, .booleans = (((operand_25).context).expressions).booleans, .call_arguments = (((operand_25).context).expressions).call_arguments, .call_functions = (((operand_25).context).expressions).call_functions, .call_store_count = (((operand_25).context).expressions).call_store_count, .call_store_first = (((operand_25).context).expressions).call_store_first, .call_stores = (((operand_25).context).expressions).call_stores, .cancellations = (((operand_25).context).expressions).cancellations, .captures = (((operand_25).context).expressions).captures, .collection_arguments = (((operand_25).context).expressions).collection_arguments, .collection_count = (((operand_25).context).expressions).collection_count, .collection_first = (((operand_25).context).expressions).collection_first, .collection_kinds = (((operand_25).context).expressions).collection_kinds, .collection_targets = (((operand_25).context).expressions).collection_targets, .conditional_conditions = (((operand_25).context).expressions).conditional_conditions, .conditional_no = (((operand_25).context).expressions).conditional_no, .conditional_yes = (((operand_25).context).expressions).conditional_yes, .enumerations = (((operand_25).context).expressions).enumerations, .errors = (((operand_25).context).expressions).errors, .floats = (((operand_25).context).expressions).floats, .index_targets = (((operand_25).context).expressions).index_targets, .index_values = (((operand_25).context).expressions).index_values, .integers = (((operand_25).context).expressions).integers, .iteration_bodies = (((operand_25).context).expressions).iteration_bodies, .iteration_condition_parameters = (((operand_25).context).expressions).iteration_condition_parameters, .iteration_conditions = (((operand_25).context).expressions).iteration_conditions, .iteration_initials = (((operand_25).context).expressions).iteration_initials, .iteration_parameters = (((operand_25).context).expressions).iteration_parameters, .iteration_postconditions = (((operand_25).context).expressions).iteration_postconditions, .kinds = (((operand_25).context).expressions).kinds, .lengths = (((operand_25).context).expressions).lengths, .match_conditions = (((operand_25).context).expressions).match_conditions, .match_count = (((operand_25).context).expressions).match_count, .match_fallbacks = (((operand_25).context).expressions).match_fallbacks, .match_first = (((operand_25).context).expressions).match_first, .match_results = (((operand_25).context).expressions).match_results, .match_subjects = (((operand_25).context).expressions).match_subjects, .negative_integers = (((operand_25).context).expressions).negative_integers, .object_count = (((operand_25).context).expressions).object_count, .object_evaluation_count = (((operand_25).context).expressions).object_evaluation_count, .object_evaluation_first = (((operand_25).context).expressions).object_evaluation_first, .object_evaluation_values = (((operand_25).context).expressions).object_evaluation_values, .object_field_indices = (((operand_25).context).expressions).object_field_indices, .object_field_values = (((operand_25).context).expressions).object_field_values, .object_first = (((operand_25).context).expressions).object_first, .optional_values = (((operand_25).context).expressions).optional_values, .parallel_count = (((operand_25).context).expressions).parallel_count, .parallel_fields = (((operand_25).context).expressions).parallel_fields, .parallel_first = (((operand_25).context).expressions).parallel_first, .parallel_tasks = (((operand_25).context).expressions).parallel_tasks, .payloads = (((operand_25).context).expressions).payloads, .projection_indices = (((operand_25).context).expressions).projection_indices, .projection_targets = (((operand_25).context).expressions).projection_targets, .references = (((operand_25).context).expressions).references, .scope_borrows = (((operand_25).context).expressions).scope_borrows, .scope_count = (((operand_25).context).expressions).scope_count, .scope_first = (((operand_25).context).expressions).scope_first, .scope_results = (((operand_25).context).expressions).scope_results, .scope_symbols = (((operand_25).context).expressions).scope_symbols, .scope_values = (((operand_25).context).expressions).scope_values, .sequence_count = (((operand_25).context).expressions).sequence_count, .sequence_first = (((operand_25).context).expressions).sequence_first, .sequence_items = (((operand_25).context).expressions).sequence_items, .some = (((operand_25).context).expressions).some, .span_end = (((operand_25).context).expressions).span_end, .span_start = (((operand_25).context).expressions).span_start, .stores = (((operand_25).context).expressions).stores, .strings = (((operand_25).context).expressions).strings, .task_bodies = (((operand_25).context).expressions).task_bodies, .task_capture_count = (((operand_25).context).expressions).task_capture_count, .task_capture_first = (((operand_25).context).expressions).task_capture_first, .task_captures = (((operand_25).context).expressions).task_captures, .transform_bodies = (((operand_25).context).expressions).transform_bodies, .transform_count = (((operand_25).context).expressions).transform_count, .transform_first = (((operand_25).context).expressions).transform_first, .transform_initials = (((operand_25).context).expressions).transform_initials, .transform_kinds = (((operand_25).context).expressions).transform_kinds, .transform_parameters = (((operand_25).context).expressions).transform_parameters, .transform_targets = (((operand_25).context).expressions).transform_targets, .types = (((operand_25).context).expressions).types, .unary_operands = (((operand_25).context).expressions).unary_operands, .unary_operators = (((operand_25).context).expressions).unary_operators, .update_indices = (((operand_25).context).expressions).update_indices, .update_targets = (((operand_25).context).expressions).update_targets, .update_values = (((operand_25).context).expressions).update_values, .zx_origin = ((operand_25).context).expressions, }, .functions = (zx_abi).value_zx_type_41_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .input_types = (((operand_25).context).functions).input_types, .output_types = (((operand_25).context).functions).output_types, .stores = (((operand_25).context).functions).stores, .zx_origin = ((operand_25).context).functions, }, .index = ((operand_25).context).index, .orchestration = ((operand_25).context).orchestration, .stores = ((operand_25).context).stores, .symbols = (zx_abi).value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((operand_25).context).symbols).names, .ownership = (((operand_25).context).symbols).ownership, .span_end = (((operand_25).context).symbols).span_end, .span_start = (((operand_25).context).symbols).span_start, .types = (((operand_25).context).symbols).types, .zx_origin = ((operand_25).context).symbols, }, .table = (zx_abi).value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_25).context).table).children, .field_names = (((operand_25).context).table).field_names, .field_types = (((operand_25).context).table).field_types, .first = (((operand_25).context).table).first, .kinds = (((operand_25).context).table).kinds, .labels = (((operand_25).context).table).labels, .names = (((operand_25).context).table).names, .second = (((operand_25).context).table).second, .zx_origin = ((operand_25).context).table, }, .zx_origin = (operand_25).context, }, .count = (operand_25).count, .first = (operand_25).first, .index = (operand_25).index, .result_type = (operand_25).result_type, .valid = (operand_25).valid, .zx_origin = (&operand_25), };

        while (((state_10).valid and ((state_10).index < (state_10).count))) {
            state_10 = block_57: {
                const value_8: (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159 = (state_10).context;
                const value_9: u64 = ((state_10).first + (state_10).index);
                const value_10: (zx_abi).value_zx_type_51_698b14c9054a42c897970dde7b67171e5e5a2bdf21605a4242a54005cf5cded9 = block_56: {
                    break :block_56 @as((zx_abi).value_zx_type_51_698b14c9054a42c897970dde7b67171e5e5a2bdf21605a4242a54005cf5cded9, (zx_abi).value_zx_type_51_698b14c9054a42c897970dde7b67171e5e5a2bdf21605a4242a54005cf5cded9{ .condition_type = (state_10).condition_type, .context = (state_10).context, .count = (state_10).count, .first = (state_10).first, .index = (state_10).index, .result_type = (state_10).result_type, .valid = (block_41: {
                        const operand_28 = (value_8).expressions;

                        var state_borrow_29: (zx_abi).zx_type_34 = undefined;

                        state_borrow_29 = (zx_abi).zx_type_34{ .awaits = (operand_28).awaits, .binary_left = (operand_28).binary_left, .binary_operators = (operand_28).binary_operators, .binary_right = (operand_28).binary_right, .booleans = (operand_28).booleans, .call_arguments = (operand_28).call_arguments, .call_functions = (operand_28).call_functions, .call_store_count = (operand_28).call_store_count, .call_store_first = (operand_28).call_store_first, .call_stores = (operand_28).call_stores, .cancellations = (operand_28).cancellations, .captures = (operand_28).captures, .collection_arguments = (operand_28).collection_arguments, .collection_count = (operand_28).collection_count, .collection_first = (operand_28).collection_first, .collection_kinds = (operand_28).collection_kinds, .collection_targets = (operand_28).collection_targets, .conditional_conditions = (operand_28).conditional_conditions, .conditional_no = (operand_28).conditional_no, .conditional_yes = (operand_28).conditional_yes, .enumerations = (operand_28).enumerations, .errors = (operand_28).errors, .floats = (operand_28).floats, .index_targets = (operand_28).index_targets, .index_values = (operand_28).index_values, .integers = (operand_28).integers, .iteration_bodies = (operand_28).iteration_bodies, .iteration_condition_parameters = (operand_28).iteration_condition_parameters, .iteration_conditions = (operand_28).iteration_conditions, .iteration_initials = (operand_28).iteration_initials, .iteration_parameters = (operand_28).iteration_parameters, .iteration_postconditions = (operand_28).iteration_postconditions, .kinds = (operand_28).kinds, .lengths = (operand_28).lengths, .match_conditions = (operand_28).match_conditions, .match_count = (operand_28).match_count, .match_fallbacks = (operand_28).match_fallbacks, .match_first = (operand_28).match_first, .match_results = (operand_28).match_results, .match_subjects = (operand_28).match_subjects, .negative_integers = (operand_28).negative_integers, .object_count = (operand_28).object_count, .object_evaluation_count = (operand_28).object_evaluation_count, .object_evaluation_first = (operand_28).object_evaluation_first, .object_evaluation_values = (operand_28).object_evaluation_values, .object_field_indices = (operand_28).object_field_indices, .object_field_values = (operand_28).object_field_values, .object_first = (operand_28).object_first, .optional_values = (operand_28).optional_values, .parallel_count = (operand_28).parallel_count, .parallel_fields = (operand_28).parallel_fields, .parallel_first = (operand_28).parallel_first, .parallel_tasks = (operand_28).parallel_tasks, .payloads = (operand_28).payloads, .projection_indices = (operand_28).projection_indices, .projection_targets = (operand_28).projection_targets, .references = (operand_28).references, .scope_borrows = (operand_28).scope_borrows, .scope_count = (operand_28).scope_count, .scope_first = (operand_28).scope_first, .scope_results = (operand_28).scope_results, .scope_symbols = (operand_28).scope_symbols, .scope_values = (operand_28).scope_values, .sequence_count = (operand_28).sequence_count, .sequence_first = (operand_28).sequence_first, .sequence_items = (operand_28).sequence_items, .some = (operand_28).some, .span_end = (operand_28).span_end, .span_start = (operand_28).span_start, .stores = (operand_28).stores, .strings = (operand_28).strings, .task_bodies = (operand_28).task_bodies, .task_capture_count = (operand_28).task_capture_count, .task_capture_first = (operand_28).task_capture_first, .task_captures = (operand_28).task_captures, .transform_bodies = (operand_28).transform_bodies, .transform_count = (operand_28).transform_count, .transform_first = (operand_28).transform_first, .transform_initials = (operand_28).transform_initials, .transform_kinds = (operand_28).transform_kinds, .transform_parameters = (operand_28).transform_parameters, .transform_targets = (operand_28).transform_targets, .types = (operand_28).types, .unary_operands = (operand_28).unary_operands, .unary_operators = (operand_28).unary_operators, .update_indices = (operand_28).update_indices, .update_targets = (operand_28).update_targets, .update_values = (operand_28).update_values, };

                        const operand_30 = ((operand_28).zx_origin orelse (&state_borrow_29));
                        const operand_31 = (value_8).index;
                        const operand_36 = block_35: {
                            const operand_33 = ((value_8).expressions).match_conditions;
                            const operand_34 = block_32: {
                                break :block_32 value_9;
                            };

                            if ((operand_34 >= (operand_33).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_35 (operand_33)[@intCast(operand_34)];
                        };
                        const operand_37 = (state_10).condition_type;
                        const operand_38 = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (operand_30).awaits, .binary_left = (operand_30).binary_left, .binary_operators = (operand_30).binary_operators, .binary_right = (operand_30).binary_right, .booleans = (operand_30).booleans, .call_arguments = (operand_30).call_arguments, .call_functions = (operand_30).call_functions, .call_store_count = (operand_30).call_store_count, .call_store_first = (operand_30).call_store_first, .call_stores = (operand_30).call_stores, .cancellations = (operand_30).cancellations, .captures = (operand_30).captures, .collection_arguments = (operand_30).collection_arguments, .collection_count = (operand_30).collection_count, .collection_first = (operand_30).collection_first, .collection_kinds = (operand_30).collection_kinds, .collection_targets = (operand_30).collection_targets, .conditional_conditions = (operand_30).conditional_conditions, .conditional_no = (operand_30).conditional_no, .conditional_yes = (operand_30).conditional_yes, .enumerations = (operand_30).enumerations, .errors = (operand_30).errors, .floats = (operand_30).floats, .index_targets = (operand_30).index_targets, .index_values = (operand_30).index_values, .integers = (operand_30).integers, .iteration_bodies = (operand_30).iteration_bodies, .iteration_condition_parameters = (operand_30).iteration_condition_parameters, .iteration_conditions = (operand_30).iteration_conditions, .iteration_initials = (operand_30).iteration_initials, .iteration_parameters = (operand_30).iteration_parameters, .iteration_postconditions = (operand_30).iteration_postconditions, .kinds = (operand_30).kinds, .lengths = (operand_30).lengths, .match_conditions = (operand_30).match_conditions, .match_count = (operand_30).match_count, .match_fallbacks = (operand_30).match_fallbacks, .match_first = (operand_30).match_first, .match_results = (operand_30).match_results, .match_subjects = (operand_30).match_subjects, .negative_integers = (operand_30).negative_integers, .object_count = (operand_30).object_count, .object_evaluation_count = (operand_30).object_evaluation_count, .object_evaluation_first = (operand_30).object_evaluation_first, .object_evaluation_values = (operand_30).object_evaluation_values, .object_field_indices = (operand_30).object_field_indices, .object_field_values = (operand_30).object_field_values, .object_first = (operand_30).object_first, .optional_values = (operand_30).optional_values, .parallel_count = (operand_30).parallel_count, .parallel_fields = (operand_30).parallel_fields, .parallel_first = (operand_30).parallel_first, .parallel_tasks = (operand_30).parallel_tasks, .payloads = (operand_30).payloads, .projection_indices = (operand_30).projection_indices, .projection_targets = (operand_30).projection_targets, .references = (operand_30).references, .scope_borrows = (operand_30).scope_borrows, .scope_count = (operand_30).scope_count, .scope_first = (operand_30).scope_first, .scope_results = (operand_30).scope_results, .scope_symbols = (operand_30).scope_symbols, .scope_values = (operand_30).scope_values, .sequence_count = (operand_30).sequence_count, .sequence_first = (operand_30).sequence_first, .sequence_items = (operand_30).sequence_items, .some = (operand_30).some, .span_end = (operand_30).span_end, .span_start = (operand_30).span_start, .stores = (operand_30).stores, .strings = (operand_30).strings, .task_bodies = (operand_30).task_bodies, .task_capture_count = (operand_30).task_capture_count, .task_capture_first = (operand_30).task_capture_first, .task_captures = (operand_30).task_captures, .transform_bodies = (operand_30).transform_bodies, .transform_count = (operand_30).transform_count, .transform_first = (operand_30).transform_first, .transform_initials = (operand_30).transform_initials, .transform_kinds = (operand_30).transform_kinds, .transform_parameters = (operand_30).transform_parameters, .transform_targets = (operand_30).transform_targets, .types = (operand_30).types, .unary_operands = (operand_30).unary_operands, .unary_operators = (operand_30).unary_operators, .update_indices = (operand_30).update_indices, .update_targets = (operand_30).update_targets, .update_values = (operand_30).update_values, .zx_origin = operand_30, };

                        var state_borrow_39: (zx_abi).zx_type_34 = undefined;

                        state_borrow_39 = (zx_abi).zx_type_34{ .awaits = (operand_38).awaits, .binary_left = (operand_38).binary_left, .binary_operators = (operand_38).binary_operators, .binary_right = (operand_38).binary_right, .booleans = (operand_38).booleans, .call_arguments = (operand_38).call_arguments, .call_functions = (operand_38).call_functions, .call_store_count = (operand_38).call_store_count, .call_store_first = (operand_38).call_store_first, .call_stores = (operand_38).call_stores, .cancellations = (operand_38).cancellations, .captures = (operand_38).captures, .collection_arguments = (operand_38).collection_arguments, .collection_count = (operand_38).collection_count, .collection_first = (operand_38).collection_first, .collection_kinds = (operand_38).collection_kinds, .collection_targets = (operand_38).collection_targets, .conditional_conditions = (operand_38).conditional_conditions, .conditional_no = (operand_38).conditional_no, .conditional_yes = (operand_38).conditional_yes, .enumerations = (operand_38).enumerations, .errors = (operand_38).errors, .floats = (operand_38).floats, .index_targets = (operand_38).index_targets, .index_values = (operand_38).index_values, .integers = (operand_38).integers, .iteration_bodies = (operand_38).iteration_bodies, .iteration_condition_parameters = (operand_38).iteration_condition_parameters, .iteration_conditions = (operand_38).iteration_conditions, .iteration_initials = (operand_38).iteration_initials, .iteration_parameters = (operand_38).iteration_parameters, .iteration_postconditions = (operand_38).iteration_postconditions, .kinds = (operand_38).kinds, .lengths = (operand_38).lengths, .match_conditions = (operand_38).match_conditions, .match_count = (operand_38).match_count, .match_fallbacks = (operand_38).match_fallbacks, .match_first = (operand_38).match_first, .match_results = (operand_38).match_results, .match_subjects = (operand_38).match_subjects, .negative_integers = (operand_38).negative_integers, .object_count = (operand_38).object_count, .object_evaluation_count = (operand_38).object_evaluation_count, .object_evaluation_first = (operand_38).object_evaluation_first, .object_evaluation_values = (operand_38).object_evaluation_values, .object_field_indices = (operand_38).object_field_indices, .object_field_values = (operand_38).object_field_values, .object_first = (operand_38).object_first, .optional_values = (operand_38).optional_values, .parallel_count = (operand_38).parallel_count, .parallel_fields = (operand_38).parallel_fields, .parallel_first = (operand_38).parallel_first, .parallel_tasks = (operand_38).parallel_tasks, .payloads = (operand_38).payloads, .projection_indices = (operand_38).projection_indices, .projection_targets = (operand_38).projection_targets, .references = (operand_38).references, .scope_borrows = (operand_38).scope_borrows, .scope_count = (operand_38).scope_count, .scope_first = (operand_38).scope_first, .scope_results = (operand_38).scope_results, .scope_symbols = (operand_38).scope_symbols, .scope_values = (operand_38).scope_values, .sequence_count = (operand_38).sequence_count, .sequence_first = (operand_38).sequence_first, .sequence_items = (operand_38).sequence_items, .some = (operand_38).some, .span_end = (operand_38).span_end, .span_start = (operand_38).span_start, .stores = (operand_38).stores, .strings = (operand_38).strings, .task_bodies = (operand_38).task_bodies, .task_capture_count = (operand_38).task_capture_count, .task_capture_first = (operand_38).task_capture_first, .task_captures = (operand_38).task_captures, .transform_bodies = (operand_38).transform_bodies, .transform_count = (operand_38).transform_count, .transform_first = (operand_38).transform_first, .transform_initials = (operand_38).transform_initials, .transform_kinds = (operand_38).transform_kinds, .transform_parameters = (operand_38).transform_parameters, .transform_targets = (operand_38).transform_targets, .types = (operand_38).types, .unary_operands = (operand_38).unary_operands, .unary_operators = (operand_38).unary_operators, .update_indices = (operand_38).update_indices, .update_targets = (operand_38).update_targets, .update_values = (operand_38).update_values, };

                        const operand_40 = (zx_abi).zx_type_35{ .expressions = ((operand_38).zx_origin orelse (&state_borrow_39)), .index = operand_31, .id = operand_36, .type_id = operand_37, };

                        break :block_41 (try function_10(allocator, (&operand_40)));
                    } and block_55: {
                        const operand_42 = (value_8).expressions;

                        var state_borrow_43: (zx_abi).zx_type_34 = undefined;

                        state_borrow_43 = (zx_abi).zx_type_34{ .awaits = (operand_42).awaits, .binary_left = (operand_42).binary_left, .binary_operators = (operand_42).binary_operators, .binary_right = (operand_42).binary_right, .booleans = (operand_42).booleans, .call_arguments = (operand_42).call_arguments, .call_functions = (operand_42).call_functions, .call_store_count = (operand_42).call_store_count, .call_store_first = (operand_42).call_store_first, .call_stores = (operand_42).call_stores, .cancellations = (operand_42).cancellations, .captures = (operand_42).captures, .collection_arguments = (operand_42).collection_arguments, .collection_count = (operand_42).collection_count, .collection_first = (operand_42).collection_first, .collection_kinds = (operand_42).collection_kinds, .collection_targets = (operand_42).collection_targets, .conditional_conditions = (operand_42).conditional_conditions, .conditional_no = (operand_42).conditional_no, .conditional_yes = (operand_42).conditional_yes, .enumerations = (operand_42).enumerations, .errors = (operand_42).errors, .floats = (operand_42).floats, .index_targets = (operand_42).index_targets, .index_values = (operand_42).index_values, .integers = (operand_42).integers, .iteration_bodies = (operand_42).iteration_bodies, .iteration_condition_parameters = (operand_42).iteration_condition_parameters, .iteration_conditions = (operand_42).iteration_conditions, .iteration_initials = (operand_42).iteration_initials, .iteration_parameters = (operand_42).iteration_parameters, .iteration_postconditions = (operand_42).iteration_postconditions, .kinds = (operand_42).kinds, .lengths = (operand_42).lengths, .match_conditions = (operand_42).match_conditions, .match_count = (operand_42).match_count, .match_fallbacks = (operand_42).match_fallbacks, .match_first = (operand_42).match_first, .match_results = (operand_42).match_results, .match_subjects = (operand_42).match_subjects, .negative_integers = (operand_42).negative_integers, .object_count = (operand_42).object_count, .object_evaluation_count = (operand_42).object_evaluation_count, .object_evaluation_first = (operand_42).object_evaluation_first, .object_evaluation_values = (operand_42).object_evaluation_values, .object_field_indices = (operand_42).object_field_indices, .object_field_values = (operand_42).object_field_values, .object_first = (operand_42).object_first, .optional_values = (operand_42).optional_values, .parallel_count = (operand_42).parallel_count, .parallel_fields = (operand_42).parallel_fields, .parallel_first = (operand_42).parallel_first, .parallel_tasks = (operand_42).parallel_tasks, .payloads = (operand_42).payloads, .projection_indices = (operand_42).projection_indices, .projection_targets = (operand_42).projection_targets, .references = (operand_42).references, .scope_borrows = (operand_42).scope_borrows, .scope_count = (operand_42).scope_count, .scope_first = (operand_42).scope_first, .scope_results = (operand_42).scope_results, .scope_symbols = (operand_42).scope_symbols, .scope_values = (operand_42).scope_values, .sequence_count = (operand_42).sequence_count, .sequence_first = (operand_42).sequence_first, .sequence_items = (operand_42).sequence_items, .some = (operand_42).some, .span_end = (operand_42).span_end, .span_start = (operand_42).span_start, .stores = (operand_42).stores, .strings = (operand_42).strings, .task_bodies = (operand_42).task_bodies, .task_capture_count = (operand_42).task_capture_count, .task_capture_first = (operand_42).task_capture_first, .task_captures = (operand_42).task_captures, .transform_bodies = (operand_42).transform_bodies, .transform_count = (operand_42).transform_count, .transform_first = (operand_42).transform_first, .transform_initials = (operand_42).transform_initials, .transform_kinds = (operand_42).transform_kinds, .transform_parameters = (operand_42).transform_parameters, .transform_targets = (operand_42).transform_targets, .types = (operand_42).types, .unary_operands = (operand_42).unary_operands, .unary_operators = (operand_42).unary_operators, .update_indices = (operand_42).update_indices, .update_targets = (operand_42).update_targets, .update_values = (operand_42).update_values, };

                        const operand_44 = ((operand_42).zx_origin orelse (&state_borrow_43));
                        const operand_45 = (value_8).index;
                        const operand_50 = block_49: {
                            const operand_47 = ((value_8).expressions).match_results;
                            const operand_48 = block_46: {
                                break :block_46 value_9;
                            };

                            if ((operand_48 >= (operand_47).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_49 (operand_47)[@intCast(operand_48)];
                        };
                        const operand_51 = (state_10).result_type;
                        const operand_52 = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (operand_44).awaits, .binary_left = (operand_44).binary_left, .binary_operators = (operand_44).binary_operators, .binary_right = (operand_44).binary_right, .booleans = (operand_44).booleans, .call_arguments = (operand_44).call_arguments, .call_functions = (operand_44).call_functions, .call_store_count = (operand_44).call_store_count, .call_store_first = (operand_44).call_store_first, .call_stores = (operand_44).call_stores, .cancellations = (operand_44).cancellations, .captures = (operand_44).captures, .collection_arguments = (operand_44).collection_arguments, .collection_count = (operand_44).collection_count, .collection_first = (operand_44).collection_first, .collection_kinds = (operand_44).collection_kinds, .collection_targets = (operand_44).collection_targets, .conditional_conditions = (operand_44).conditional_conditions, .conditional_no = (operand_44).conditional_no, .conditional_yes = (operand_44).conditional_yes, .enumerations = (operand_44).enumerations, .errors = (operand_44).errors, .floats = (operand_44).floats, .index_targets = (operand_44).index_targets, .index_values = (operand_44).index_values, .integers = (operand_44).integers, .iteration_bodies = (operand_44).iteration_bodies, .iteration_condition_parameters = (operand_44).iteration_condition_parameters, .iteration_conditions = (operand_44).iteration_conditions, .iteration_initials = (operand_44).iteration_initials, .iteration_parameters = (operand_44).iteration_parameters, .iteration_postconditions = (operand_44).iteration_postconditions, .kinds = (operand_44).kinds, .lengths = (operand_44).lengths, .match_conditions = (operand_44).match_conditions, .match_count = (operand_44).match_count, .match_fallbacks = (operand_44).match_fallbacks, .match_first = (operand_44).match_first, .match_results = (operand_44).match_results, .match_subjects = (operand_44).match_subjects, .negative_integers = (operand_44).negative_integers, .object_count = (operand_44).object_count, .object_evaluation_count = (operand_44).object_evaluation_count, .object_evaluation_first = (operand_44).object_evaluation_first, .object_evaluation_values = (operand_44).object_evaluation_values, .object_field_indices = (operand_44).object_field_indices, .object_field_values = (operand_44).object_field_values, .object_first = (operand_44).object_first, .optional_values = (operand_44).optional_values, .parallel_count = (operand_44).parallel_count, .parallel_fields = (operand_44).parallel_fields, .parallel_first = (operand_44).parallel_first, .parallel_tasks = (operand_44).parallel_tasks, .payloads = (operand_44).payloads, .projection_indices = (operand_44).projection_indices, .projection_targets = (operand_44).projection_targets, .references = (operand_44).references, .scope_borrows = (operand_44).scope_borrows, .scope_count = (operand_44).scope_count, .scope_first = (operand_44).scope_first, .scope_results = (operand_44).scope_results, .scope_symbols = (operand_44).scope_symbols, .scope_values = (operand_44).scope_values, .sequence_count = (operand_44).sequence_count, .sequence_first = (operand_44).sequence_first, .sequence_items = (operand_44).sequence_items, .some = (operand_44).some, .span_end = (operand_44).span_end, .span_start = (operand_44).span_start, .stores = (operand_44).stores, .strings = (operand_44).strings, .task_bodies = (operand_44).task_bodies, .task_capture_count = (operand_44).task_capture_count, .task_capture_first = (operand_44).task_capture_first, .task_captures = (operand_44).task_captures, .transform_bodies = (operand_44).transform_bodies, .transform_count = (operand_44).transform_count, .transform_first = (operand_44).transform_first, .transform_initials = (operand_44).transform_initials, .transform_kinds = (operand_44).transform_kinds, .transform_parameters = (operand_44).transform_parameters, .transform_targets = (operand_44).transform_targets, .types = (operand_44).types, .unary_operands = (operand_44).unary_operands, .unary_operators = (operand_44).unary_operators, .update_indices = (operand_44).update_indices, .update_targets = (operand_44).update_targets, .update_values = (operand_44).update_values, .zx_origin = operand_44, };

                        var state_borrow_53: (zx_abi).zx_type_34 = undefined;

                        state_borrow_53 = (zx_abi).zx_type_34{ .awaits = (operand_52).awaits, .binary_left = (operand_52).binary_left, .binary_operators = (operand_52).binary_operators, .binary_right = (operand_52).binary_right, .booleans = (operand_52).booleans, .call_arguments = (operand_52).call_arguments, .call_functions = (operand_52).call_functions, .call_store_count = (operand_52).call_store_count, .call_store_first = (operand_52).call_store_first, .call_stores = (operand_52).call_stores, .cancellations = (operand_52).cancellations, .captures = (operand_52).captures, .collection_arguments = (operand_52).collection_arguments, .collection_count = (operand_52).collection_count, .collection_first = (operand_52).collection_first, .collection_kinds = (operand_52).collection_kinds, .collection_targets = (operand_52).collection_targets, .conditional_conditions = (operand_52).conditional_conditions, .conditional_no = (operand_52).conditional_no, .conditional_yes = (operand_52).conditional_yes, .enumerations = (operand_52).enumerations, .errors = (operand_52).errors, .floats = (operand_52).floats, .index_targets = (operand_52).index_targets, .index_values = (operand_52).index_values, .integers = (operand_52).integers, .iteration_bodies = (operand_52).iteration_bodies, .iteration_condition_parameters = (operand_52).iteration_condition_parameters, .iteration_conditions = (operand_52).iteration_conditions, .iteration_initials = (operand_52).iteration_initials, .iteration_parameters = (operand_52).iteration_parameters, .iteration_postconditions = (operand_52).iteration_postconditions, .kinds = (operand_52).kinds, .lengths = (operand_52).lengths, .match_conditions = (operand_52).match_conditions, .match_count = (operand_52).match_count, .match_fallbacks = (operand_52).match_fallbacks, .match_first = (operand_52).match_first, .match_results = (operand_52).match_results, .match_subjects = (operand_52).match_subjects, .negative_integers = (operand_52).negative_integers, .object_count = (operand_52).object_count, .object_evaluation_count = (operand_52).object_evaluation_count, .object_evaluation_first = (operand_52).object_evaluation_first, .object_evaluation_values = (operand_52).object_evaluation_values, .object_field_indices = (operand_52).object_field_indices, .object_field_values = (operand_52).object_field_values, .object_first = (operand_52).object_first, .optional_values = (operand_52).optional_values, .parallel_count = (operand_52).parallel_count, .parallel_fields = (operand_52).parallel_fields, .parallel_first = (operand_52).parallel_first, .parallel_tasks = (operand_52).parallel_tasks, .payloads = (operand_52).payloads, .projection_indices = (operand_52).projection_indices, .projection_targets = (operand_52).projection_targets, .references = (operand_52).references, .scope_borrows = (operand_52).scope_borrows, .scope_count = (operand_52).scope_count, .scope_first = (operand_52).scope_first, .scope_results = (operand_52).scope_results, .scope_symbols = (operand_52).scope_symbols, .scope_values = (operand_52).scope_values, .sequence_count = (operand_52).sequence_count, .sequence_first = (operand_52).sequence_first, .sequence_items = (operand_52).sequence_items, .some = (operand_52).some, .span_end = (operand_52).span_end, .span_start = (operand_52).span_start, .stores = (operand_52).stores, .strings = (operand_52).strings, .task_bodies = (operand_52).task_bodies, .task_capture_count = (operand_52).task_capture_count, .task_capture_first = (operand_52).task_capture_first, .task_captures = (operand_52).task_captures, .transform_bodies = (operand_52).transform_bodies, .transform_count = (operand_52).transform_count, .transform_first = (operand_52).transform_first, .transform_initials = (operand_52).transform_initials, .transform_kinds = (operand_52).transform_kinds, .transform_parameters = (operand_52).transform_parameters, .transform_targets = (operand_52).transform_targets, .types = (operand_52).types, .unary_operands = (operand_52).unary_operands, .unary_operators = (operand_52).unary_operators, .update_indices = (operand_52).update_indices, .update_targets = (operand_52).update_targets, .update_values = (operand_52).update_values, };

                        const operand_54 = (zx_abi).zx_type_35{ .expressions = ((operand_52).zx_origin orelse (&state_borrow_53)), .index = operand_45, .id = operand_50, .type_id = operand_51, };

                        break :block_55 (try function_10(allocator, (&operand_54)));
                    }), });
                };
                const value_11: u64 = (value_10).index;
                const value_12: (zx_abi).value_zx_type_51_698b14c9054a42c897970dde7b67171e5e5a2bdf21605a4242a54005cf5cded9 = block_27: {
                    break :block_27 @as((zx_abi).value_zx_type_51_698b14c9054a42c897970dde7b67171e5e5a2bdf21605a4242a54005cf5cded9, (zx_abi).value_zx_type_51_698b14c9054a42c897970dde7b67171e5e5a2bdf21605a4242a54005cf5cded9{ .condition_type = (value_10).condition_type, .context = (value_10).context, .count = (value_10).count, .first = (value_10).first, .index = (block_26: {
                        break :block_26 value_11;
                    } + @as(u64, 1)), .result_type = (value_10).result_type, .valid = (value_10).valid, });
                };

                break :block_57 value_12;
            };
        }

        break :block_70 block_69: {
            break :block_69 (if (((state_10).zx_origin != null)) ((state_10).zx_origin.?).* else block_68: {
                break :block_68 (zx_abi).zx_type_51{ .condition_type = (state_10).condition_type, .context = (if ((((state_10).context).zx_origin != null)) ((state_10).context).zx_origin.? else block_67: {
                    const operand_66 = (try (allocator).create((zx_abi).zx_type_42));

                    (operand_66).* = (zx_abi).zx_type_42{ .expressions = (if (((((state_10).context).expressions).zx_origin != null)) (((state_10).context).expressions).zx_origin.? else block_59: {
                        const operand_58 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_58).* = (zx_abi).zx_type_34{ .awaits = (((state_10).context).expressions).awaits, .binary_left = (((state_10).context).expressions).binary_left, .binary_operators = (((state_10).context).expressions).binary_operators, .binary_right = (((state_10).context).expressions).binary_right, .booleans = (((state_10).context).expressions).booleans, .call_arguments = (((state_10).context).expressions).call_arguments, .call_functions = (((state_10).context).expressions).call_functions, .call_store_count = (((state_10).context).expressions).call_store_count, .call_store_first = (((state_10).context).expressions).call_store_first, .call_stores = (((state_10).context).expressions).call_stores, .cancellations = (((state_10).context).expressions).cancellations, .captures = (((state_10).context).expressions).captures, .collection_arguments = (((state_10).context).expressions).collection_arguments, .collection_count = (((state_10).context).expressions).collection_count, .collection_first = (((state_10).context).expressions).collection_first, .collection_kinds = (((state_10).context).expressions).collection_kinds, .collection_targets = (((state_10).context).expressions).collection_targets, .conditional_conditions = (((state_10).context).expressions).conditional_conditions, .conditional_no = (((state_10).context).expressions).conditional_no, .conditional_yes = (((state_10).context).expressions).conditional_yes, .enumerations = (((state_10).context).expressions).enumerations, .errors = (((state_10).context).expressions).errors, .floats = (((state_10).context).expressions).floats, .index_targets = (((state_10).context).expressions).index_targets, .index_values = (((state_10).context).expressions).index_values, .integers = (((state_10).context).expressions).integers, .iteration_bodies = (((state_10).context).expressions).iteration_bodies, .iteration_condition_parameters = (((state_10).context).expressions).iteration_condition_parameters, .iteration_conditions = (((state_10).context).expressions).iteration_conditions, .iteration_initials = (((state_10).context).expressions).iteration_initials, .iteration_parameters = (((state_10).context).expressions).iteration_parameters, .iteration_postconditions = (((state_10).context).expressions).iteration_postconditions, .kinds = (((state_10).context).expressions).kinds, .lengths = (((state_10).context).expressions).lengths, .match_conditions = (((state_10).context).expressions).match_conditions, .match_count = (((state_10).context).expressions).match_count, .match_fallbacks = (((state_10).context).expressions).match_fallbacks, .match_first = (((state_10).context).expressions).match_first, .match_results = (((state_10).context).expressions).match_results, .match_subjects = (((state_10).context).expressions).match_subjects, .negative_integers = (((state_10).context).expressions).negative_integers, .object_count = (((state_10).context).expressions).object_count, .object_evaluation_count = (((state_10).context).expressions).object_evaluation_count, .object_evaluation_first = (((state_10).context).expressions).object_evaluation_first, .object_evaluation_values = (((state_10).context).expressions).object_evaluation_values, .object_field_indices = (((state_10).context).expressions).object_field_indices, .object_field_values = (((state_10).context).expressions).object_field_values, .object_first = (((state_10).context).expressions).object_first, .optional_values = (((state_10).context).expressions).optional_values, .parallel_count = (((state_10).context).expressions).parallel_count, .parallel_fields = (((state_10).context).expressions).parallel_fields, .parallel_first = (((state_10).context).expressions).parallel_first, .parallel_tasks = (((state_10).context).expressions).parallel_tasks, .payloads = (((state_10).context).expressions).payloads, .projection_indices = (((state_10).context).expressions).projection_indices, .projection_targets = (((state_10).context).expressions).projection_targets, .references = (((state_10).context).expressions).references, .scope_borrows = (((state_10).context).expressions).scope_borrows, .scope_count = (((state_10).context).expressions).scope_count, .scope_first = (((state_10).context).expressions).scope_first, .scope_results = (((state_10).context).expressions).scope_results, .scope_symbols = (((state_10).context).expressions).scope_symbols, .scope_values = (((state_10).context).expressions).scope_values, .sequence_count = (((state_10).context).expressions).sequence_count, .sequence_first = (((state_10).context).expressions).sequence_first, .sequence_items = (((state_10).context).expressions).sequence_items, .some = (((state_10).context).expressions).some, .span_end = (((state_10).context).expressions).span_end, .span_start = (((state_10).context).expressions).span_start, .stores = (((state_10).context).expressions).stores, .strings = (((state_10).context).expressions).strings, .task_bodies = (((state_10).context).expressions).task_bodies, .task_capture_count = (((state_10).context).expressions).task_capture_count, .task_capture_first = (((state_10).context).expressions).task_capture_first, .task_captures = (((state_10).context).expressions).task_captures, .transform_bodies = (((state_10).context).expressions).transform_bodies, .transform_count = (((state_10).context).expressions).transform_count, .transform_first = (((state_10).context).expressions).transform_first, .transform_initials = (((state_10).context).expressions).transform_initials, .transform_kinds = (((state_10).context).expressions).transform_kinds, .transform_parameters = (((state_10).context).expressions).transform_parameters, .transform_targets = (((state_10).context).expressions).transform_targets, .types = (((state_10).context).expressions).types, .unary_operands = (((state_10).context).expressions).unary_operands, .unary_operators = (((state_10).context).expressions).unary_operators, .update_indices = (((state_10).context).expressions).update_indices, .update_targets = (((state_10).context).expressions).update_targets, .update_values = (((state_10).context).expressions).update_values, };

                        break :block_59 @as(*const (zx_abi).zx_type_34, operand_58);
                    }), .functions = (if (((((state_10).context).functions).zx_origin != null)) (((state_10).context).functions).zx_origin.? else block_61: {
                        const operand_60 = (try (allocator).create((zx_abi).zx_type_41));

                        (operand_60).* = (zx_abi).zx_type_41{ .input_types = (((state_10).context).functions).input_types, .output_types = (((state_10).context).functions).output_types, .stores = (((state_10).context).functions).stores, };

                        break :block_61 @as(*const (zx_abi).zx_type_41, operand_60);
                    }), .index = ((state_10).context).index, .orchestration = ((state_10).context).orchestration, .stores = ((state_10).context).stores, .symbols = (if (((((state_10).context).symbols).zx_origin != null)) (((state_10).context).symbols).zx_origin.? else block_63: {
                        const operand_62 = (try (allocator).create((zx_abi).zx_type_39));

                        (operand_62).* = (zx_abi).zx_type_39{ .names = (((state_10).context).symbols).names, .ownership = (((state_10).context).symbols).ownership, .span_end = (((state_10).context).symbols).span_end, .span_start = (((state_10).context).symbols).span_start, .types = (((state_10).context).symbols).types, };

                        break :block_63 @as(*const (zx_abi).zx_type_39, operand_62);
                    }), .table = (if (((((state_10).context).table).zx_origin != null)) (((state_10).context).table).zx_origin.? else block_65: {
                        const operand_64 = (try (allocator).create((zx_abi).zx_type_20));

                        (operand_64).* = (zx_abi).zx_type_20{ .children = (((state_10).context).table).children, .field_names = (((state_10).context).table).field_names, .field_types = (((state_10).context).table).field_types, .first = (((state_10).context).table).first, .kinds = (((state_10).context).table).kinds, .labels = (((state_10).context).table).labels, .names = (((state_10).context).table).names, .second = (((state_10).context).table).second, };

                        break :block_65 @as(*const (zx_abi).zx_type_20, operand_64);
                    }), };

                    break :block_67 @as(*const (zx_abi).zx_type_42, operand_66);
                }), .count = (state_10).count, .first = (state_10).first, .index = (state_10).index, .result_type = (state_10).result_type, .valid = (state_10).valid, };
            });
        };
    };

    return (((&value_13)).valid and block_9: {
        const operand_1 = (&value_2);
        const operand_2 = ((&value_1)).index;
        const operand_6 = block_5: {
            const operand_3 = ((&value_2)).match_fallbacks;
            const operand_4 = (in).payload;

            if ((operand_4 >= (operand_3).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_5 (operand_3)[@intCast(operand_4)];
        };
        const operand_7 = (in).type_id;
        const operand_8 = (zx_abi).zx_type_35{ .expressions = operand_1, .index = operand_2, .id = operand_6, .type_id = operand_7, };

        break :block_9 (try function_10(allocator, (&operand_8)));
    });
}

fn function_18(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;

    if (((in).kind == @as((zx_abi).zx_type_11, .ListUpdate))) {
        return (((((in).target == @as((zx_abi).zx_type_16, .List)) and block_48: {
            const operand_40 = (&value_2);
            const operand_41 = ((&value_1)).index;
            const operand_45 = block_44: {
                const operand_42 = ((&value_2)).update_targets;
                const operand_43 = (in).payload;

                if ((operand_43 >= (operand_42).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_44 (operand_42)[@intCast(operand_43)];
            };
            const operand_46 = (in).type_id;
            const operand_47 = (zx_abi).zx_type_35{ .expressions = operand_40, .index = operand_41, .id = operand_45, .type_id = operand_46, };

            break :block_48 (try function_10(allocator, (&operand_47)));
        }) and block_57: {
            const operand_49 = (&value_2);
            const operand_50 = ((&value_1)).index;
            const operand_54 = block_53: {
                const operand_51 = ((&value_2)).update_indices;
                const operand_52 = (in).payload;

                if ((operand_52 >= (operand_51).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_53 (operand_51)[@intCast(operand_52)];
            };
            const operand_55 = @as(u32, 5);
            const operand_56 = (zx_abi).zx_type_35{ .expressions = operand_49, .index = operand_50, .id = operand_54, .type_id = operand_55, };

            break :block_57 (try function_10(allocator, (&operand_56)));
        }) and block_69: {
            const operand_58 = (&value_2);
            const operand_59 = ((&value_1)).index;
            const operand_63 = block_62: {
                const operand_60 = ((&value_2)).update_values;
                const operand_61 = (in).payload;

                if ((operand_61 >= (operand_60).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_62 (operand_60)[@intCast(operand_61)];
            };
            const operand_67 = block_66: {
                const operand_64 = (((&value_1)).table).first;
                const operand_65 = (try function_0(allocator, (in).type_id));

                if ((operand_65 >= (operand_64).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_66 (operand_64)[@intCast(operand_65)];
            };
            const operand_68 = (zx_abi).zx_type_35{ .expressions = operand_58, .index = operand_59, .id = operand_63, .type_id = operand_67, };

            break :block_69 (try function_10(allocator, (&operand_68)));
        });
    }

    const value_3: u64 = (try function_0(allocator, block_39: {
        const operand_37 = ((&value_2)).iteration_parameters;
        const operand_38 = (in).payload;

        if ((operand_38 >= (operand_37).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_39 (operand_37)[@intCast(operand_38)];
    }));
    const value_4: u64 = (try function_0(allocator, block_36: {
        const operand_34 = ((&value_2)).iteration_condition_parameters;
        const operand_35 = (in).payload;

        if ((operand_35 >= (operand_34).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_36 (operand_34)[@intCast(operand_35)];
    }));

    return ((((((((((in).type_id != @as(u32, 0)) and block_9: {
        const operand_1 = (&value_2);
        const operand_2 = ((&value_1)).index;
        const operand_6 = block_5: {
            const operand_3 = ((&value_2)).iteration_initials;
            const operand_4 = (in).payload;

            if ((operand_4 >= (operand_3).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_5 (operand_3)[@intCast(operand_4)];
        };
        const operand_7 = (in).type_id;
        const operand_8 = (zx_abi).zx_type_35{ .expressions = operand_1, .index = operand_2, .id = operand_6, .type_id = operand_7, };

        break :block_9 (try function_10(allocator, (&operand_8)));
    }) and block_18: {
        const operand_10 = (&value_2);
        const operand_11 = ((&value_1)).index;
        const operand_15 = block_14: {
            const operand_12 = ((&value_2)).iteration_bodies;
            const operand_13 = (in).payload;

            if ((operand_13 >= (operand_12).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_14 (operand_12)[@intCast(operand_13)];
        };
        const operand_16 = (in).type_id;
        const operand_17 = (zx_abi).zx_type_35{ .expressions = operand_10, .index = operand_11, .id = operand_15, .type_id = operand_16, };

        break :block_18 (try function_10(allocator, (&operand_17)));
    }) and block_27: {
        const operand_19 = (&value_2);
        const operand_20 = ((&value_1)).index;
        const operand_24 = block_23: {
            const operand_21 = ((&value_2)).iteration_conditions;
            const operand_22 = (in).payload;

            if ((operand_22 >= (operand_21).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_23 (operand_21)[@intCast(operand_22)];
        };
        const operand_25 = @as(u32, 1);
        const operand_26 = (zx_abi).zx_type_35{ .expressions = operand_19, .index = operand_20, .id = operand_24, .type_id = operand_25, };

        break :block_27 (try function_10(allocator, (&operand_26)));
    }) and (value_3 != value_4)) and (value_3 < @as(u64, ((((&value_1)).symbols).types).len))) and (value_4 < @as(u64, ((((&value_1)).symbols).types).len))) and (block_30: {
        const operand_28 = (((&value_1)).symbols).types;
        const operand_29 = value_3;

        if ((operand_29 >= (operand_28).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_30 (operand_28)[@intCast(operand_29)];
    } == (in).type_id)) and (block_33: {
        const operand_31 = (((&value_1)).symbols).types;
        const operand_32 = value_4;

        if ((operand_32 >= (operand_31).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_33 (operand_31)[@intCast(operand_32)];
    } == (in).type_id));
}

fn function_19(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;
    const value_3: u64 = (try function_0(allocator, block_114: {
        const operand_112 = ((&value_2)).object_count;
        const operand_113 = (in).payload;

        if ((operand_113 >= (operand_112).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_114 (operand_112)[@intCast(operand_113)];
    }));
    const value_4: u64 = (try function_0(allocator, (in).type_id));

    if ((((in).target != @as((zx_abi).zx_type_16, .Object)) or ((try function_0(allocator, block_111: {
        const operand_109 = (((&value_1)).table).second;
        const operand_110 = value_4;

        if ((operand_110 >= (operand_109).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_111 (operand_109)[@intCast(operand_110)];
    })) != value_3))) {
        return false;
    }

    const value_12: (zx_abi).zx_type_52 = block_108: {
        const operand_80 = block_79: {
            const operand_68 = (&value_1);
            const operand_69 = (try function_0(allocator, block_72: {
                const operand_70 = ((&value_2)).object_evaluation_first;
                const operand_71 = (in).payload;

                if ((operand_71 >= (operand_70).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_72 (operand_70)[@intCast(operand_71)];
            }));
            const operand_73 = (try function_0(allocator, block_76: {
                const operand_74 = ((&value_2)).object_evaluation_count;
                const operand_75 = (in).payload;

                if ((operand_75 >= (operand_74).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_76 (operand_74)[@intCast(operand_75)];
            }));
            const operand_77 = @as(u64, 0);
            const operand_78 = true;

            break :block_79 (zx_abi).zx_type_52{ .context = operand_68, .first = operand_69, .count = operand_73, .index = operand_77, .valid = operand_78, };
        };

        var state_67: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159{ .expressions = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (((operand_80).context).expressions).awaits, .binary_left = (((operand_80).context).expressions).binary_left, .binary_operators = (((operand_80).context).expressions).binary_operators, .binary_right = (((operand_80).context).expressions).binary_right, .booleans = (((operand_80).context).expressions).booleans, .call_arguments = (((operand_80).context).expressions).call_arguments, .call_functions = (((operand_80).context).expressions).call_functions, .call_store_count = (((operand_80).context).expressions).call_store_count, .call_store_first = (((operand_80).context).expressions).call_store_first, .call_stores = (((operand_80).context).expressions).call_stores, .cancellations = (((operand_80).context).expressions).cancellations, .captures = (((operand_80).context).expressions).captures, .collection_arguments = (((operand_80).context).expressions).collection_arguments, .collection_count = (((operand_80).context).expressions).collection_count, .collection_first = (((operand_80).context).expressions).collection_first, .collection_kinds = (((operand_80).context).expressions).collection_kinds, .collection_targets = (((operand_80).context).expressions).collection_targets, .conditional_conditions = (((operand_80).context).expressions).conditional_conditions, .conditional_no = (((operand_80).context).expressions).conditional_no, .conditional_yes = (((operand_80).context).expressions).conditional_yes, .enumerations = (((operand_80).context).expressions).enumerations, .errors = (((operand_80).context).expressions).errors, .floats = (((operand_80).context).expressions).floats, .index_targets = (((operand_80).context).expressions).index_targets, .index_values = (((operand_80).context).expressions).index_values, .integers = (((operand_80).context).expressions).integers, .iteration_bodies = (((operand_80).context).expressions).iteration_bodies, .iteration_condition_parameters = (((operand_80).context).expressions).iteration_condition_parameters, .iteration_conditions = (((operand_80).context).expressions).iteration_conditions, .iteration_initials = (((operand_80).context).expressions).iteration_initials, .iteration_parameters = (((operand_80).context).expressions).iteration_parameters, .iteration_postconditions = (((operand_80).context).expressions).iteration_postconditions, .kinds = (((operand_80).context).expressions).kinds, .lengths = (((operand_80).context).expressions).lengths, .match_conditions = (((operand_80).context).expressions).match_conditions, .match_count = (((operand_80).context).expressions).match_count, .match_fallbacks = (((operand_80).context).expressions).match_fallbacks, .match_first = (((operand_80).context).expressions).match_first, .match_results = (((operand_80).context).expressions).match_results, .match_subjects = (((operand_80).context).expressions).match_subjects, .negative_integers = (((operand_80).context).expressions).negative_integers, .object_count = (((operand_80).context).expressions).object_count, .object_evaluation_count = (((operand_80).context).expressions).object_evaluation_count, .object_evaluation_first = (((operand_80).context).expressions).object_evaluation_first, .object_evaluation_values = (((operand_80).context).expressions).object_evaluation_values, .object_field_indices = (((operand_80).context).expressions).object_field_indices, .object_field_values = (((operand_80).context).expressions).object_field_values, .object_first = (((operand_80).context).expressions).object_first, .optional_values = (((operand_80).context).expressions).optional_values, .parallel_count = (((operand_80).context).expressions).parallel_count, .parallel_fields = (((operand_80).context).expressions).parallel_fields, .parallel_first = (((operand_80).context).expressions).parallel_first, .parallel_tasks = (((operand_80).context).expressions).parallel_tasks, .payloads = (((operand_80).context).expressions).payloads, .projection_indices = (((operand_80).context).expressions).projection_indices, .projection_targets = (((operand_80).context).expressions).projection_targets, .references = (((operand_80).context).expressions).references, .scope_borrows = (((operand_80).context).expressions).scope_borrows, .scope_count = (((operand_80).context).expressions).scope_count, .scope_first = (((operand_80).context).expressions).scope_first, .scope_results = (((operand_80).context).expressions).scope_results, .scope_symbols = (((operand_80).context).expressions).scope_symbols, .scope_values = (((operand_80).context).expressions).scope_values, .sequence_count = (((operand_80).context).expressions).sequence_count, .sequence_first = (((operand_80).context).expressions).sequence_first, .sequence_items = (((operand_80).context).expressions).sequence_items, .some = (((operand_80).context).expressions).some, .span_end = (((operand_80).context).expressions).span_end, .span_start = (((operand_80).context).expressions).span_start, .stores = (((operand_80).context).expressions).stores, .strings = (((operand_80).context).expressions).strings, .task_bodies = (((operand_80).context).expressions).task_bodies, .task_capture_count = (((operand_80).context).expressions).task_capture_count, .task_capture_first = (((operand_80).context).expressions).task_capture_first, .task_captures = (((operand_80).context).expressions).task_captures, .transform_bodies = (((operand_80).context).expressions).transform_bodies, .transform_count = (((operand_80).context).expressions).transform_count, .transform_first = (((operand_80).context).expressions).transform_first, .transform_initials = (((operand_80).context).expressions).transform_initials, .transform_kinds = (((operand_80).context).expressions).transform_kinds, .transform_parameters = (((operand_80).context).expressions).transform_parameters, .transform_targets = (((operand_80).context).expressions).transform_targets, .types = (((operand_80).context).expressions).types, .unary_operands = (((operand_80).context).expressions).unary_operands, .unary_operators = (((operand_80).context).expressions).unary_operators, .update_indices = (((operand_80).context).expressions).update_indices, .update_targets = (((operand_80).context).expressions).update_targets, .update_values = (((operand_80).context).expressions).update_values, .zx_origin = ((operand_80).context).expressions, }, .functions = (zx_abi).value_zx_type_41_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .input_types = (((operand_80).context).functions).input_types, .output_types = (((operand_80).context).functions).output_types, .stores = (((operand_80).context).functions).stores, .zx_origin = ((operand_80).context).functions, }, .index = ((operand_80).context).index, .orchestration = ((operand_80).context).orchestration, .stores = ((operand_80).context).stores, .symbols = (zx_abi).value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((operand_80).context).symbols).names, .ownership = (((operand_80).context).symbols).ownership, .span_end = (((operand_80).context).symbols).span_end, .span_start = (((operand_80).context).symbols).span_start, .types = (((operand_80).context).symbols).types, .zx_origin = ((operand_80).context).symbols, }, .table = (zx_abi).value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_80).context).table).children, .field_names = (((operand_80).context).table).field_names, .field_types = (((operand_80).context).table).field_types, .first = (((operand_80).context).table).first, .kinds = (((operand_80).context).table).kinds, .labels = (((operand_80).context).table).labels, .names = (((operand_80).context).table).names, .second = (((operand_80).context).table).second, .zx_origin = ((operand_80).context).table, }, .zx_origin = (operand_80).context, }, .count = (operand_80).count, .first = (operand_80).first, .index = (operand_80).index, .valid = (operand_80).valid, .zx_origin = (&operand_80), };

        while (((state_67).valid and ((state_67).index < (state_67).count))) {
            state_67 = block_95: {
                const value_7: (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159 = (state_67).context;
                const value_8: u64 = (try function_0(allocator, block_94: {
                    const operand_92 = ((value_7).expressions).object_evaluation_values;
                    const operand_93 = ((state_67).first + (state_67).index);

                    if ((operand_93 >= (operand_92).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_94 (operand_92)[@intCast(operand_93)];
                }));
                const value_9: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = block_91: {
                    break :block_91 @as((zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c, (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (state_67).context, .count = (state_67).count, .first = (state_67).first, .index = (state_67).index, .valid = ((block_83: {
                        break :block_83 value_8;
                    } < (value_7).index) and ((try function_9(allocator, block_90: {
                        const operand_88 = ((value_7).table).kinds;
                        const operand_89 = (try function_0(allocator, block_87: {
                            const operand_85 = ((value_7).expressions).types;
                            const operand_86 = block_84: {
                                break :block_84 value_8;
                            };

                            if ((operand_86 >= (operand_85).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_87 (operand_85)[@intCast(operand_86)];
                        }));

                        if ((operand_89 >= (operand_88).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_90 (operand_88)[@intCast(operand_89)];
                    })) != @as((zx_abi).zx_type_16, .Task))), });
                };
                const value_10: u64 = (value_9).index;
                const value_11: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = block_82: {
                    break :block_82 @as((zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c, (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (value_9).context, .count = (value_9).count, .first = (value_9).first, .index = (block_81: {
                        break :block_81 value_10;
                    } + @as(u64, 1)), .valid = (value_9).valid, });
                };

                break :block_95 value_11;
            };
        }

        break :block_108 block_107: {
            break :block_107 (if (((state_67).zx_origin != null)) ((state_67).zx_origin.?).* else block_106: {
                break :block_106 (zx_abi).zx_type_52{ .context = (if ((((state_67).context).zx_origin != null)) ((state_67).context).zx_origin.? else block_105: {
                    const operand_104 = (try (allocator).create((zx_abi).zx_type_42));

                    (operand_104).* = (zx_abi).zx_type_42{ .expressions = (if (((((state_67).context).expressions).zx_origin != null)) (((state_67).context).expressions).zx_origin.? else block_97: {
                        const operand_96 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_96).* = (zx_abi).zx_type_34{ .awaits = (((state_67).context).expressions).awaits, .binary_left = (((state_67).context).expressions).binary_left, .binary_operators = (((state_67).context).expressions).binary_operators, .binary_right = (((state_67).context).expressions).binary_right, .booleans = (((state_67).context).expressions).booleans, .call_arguments = (((state_67).context).expressions).call_arguments, .call_functions = (((state_67).context).expressions).call_functions, .call_store_count = (((state_67).context).expressions).call_store_count, .call_store_first = (((state_67).context).expressions).call_store_first, .call_stores = (((state_67).context).expressions).call_stores, .cancellations = (((state_67).context).expressions).cancellations, .captures = (((state_67).context).expressions).captures, .collection_arguments = (((state_67).context).expressions).collection_arguments, .collection_count = (((state_67).context).expressions).collection_count, .collection_first = (((state_67).context).expressions).collection_first, .collection_kinds = (((state_67).context).expressions).collection_kinds, .collection_targets = (((state_67).context).expressions).collection_targets, .conditional_conditions = (((state_67).context).expressions).conditional_conditions, .conditional_no = (((state_67).context).expressions).conditional_no, .conditional_yes = (((state_67).context).expressions).conditional_yes, .enumerations = (((state_67).context).expressions).enumerations, .errors = (((state_67).context).expressions).errors, .floats = (((state_67).context).expressions).floats, .index_targets = (((state_67).context).expressions).index_targets, .index_values = (((state_67).context).expressions).index_values, .integers = (((state_67).context).expressions).integers, .iteration_bodies = (((state_67).context).expressions).iteration_bodies, .iteration_condition_parameters = (((state_67).context).expressions).iteration_condition_parameters, .iteration_conditions = (((state_67).context).expressions).iteration_conditions, .iteration_initials = (((state_67).context).expressions).iteration_initials, .iteration_parameters = (((state_67).context).expressions).iteration_parameters, .iteration_postconditions = (((state_67).context).expressions).iteration_postconditions, .kinds = (((state_67).context).expressions).kinds, .lengths = (((state_67).context).expressions).lengths, .match_conditions = (((state_67).context).expressions).match_conditions, .match_count = (((state_67).context).expressions).match_count, .match_fallbacks = (((state_67).context).expressions).match_fallbacks, .match_first = (((state_67).context).expressions).match_first, .match_results = (((state_67).context).expressions).match_results, .match_subjects = (((state_67).context).expressions).match_subjects, .negative_integers = (((state_67).context).expressions).negative_integers, .object_count = (((state_67).context).expressions).object_count, .object_evaluation_count = (((state_67).context).expressions).object_evaluation_count, .object_evaluation_first = (((state_67).context).expressions).object_evaluation_first, .object_evaluation_values = (((state_67).context).expressions).object_evaluation_values, .object_field_indices = (((state_67).context).expressions).object_field_indices, .object_field_values = (((state_67).context).expressions).object_field_values, .object_first = (((state_67).context).expressions).object_first, .optional_values = (((state_67).context).expressions).optional_values, .parallel_count = (((state_67).context).expressions).parallel_count, .parallel_fields = (((state_67).context).expressions).parallel_fields, .parallel_first = (((state_67).context).expressions).parallel_first, .parallel_tasks = (((state_67).context).expressions).parallel_tasks, .payloads = (((state_67).context).expressions).payloads, .projection_indices = (((state_67).context).expressions).projection_indices, .projection_targets = (((state_67).context).expressions).projection_targets, .references = (((state_67).context).expressions).references, .scope_borrows = (((state_67).context).expressions).scope_borrows, .scope_count = (((state_67).context).expressions).scope_count, .scope_first = (((state_67).context).expressions).scope_first, .scope_results = (((state_67).context).expressions).scope_results, .scope_symbols = (((state_67).context).expressions).scope_symbols, .scope_values = (((state_67).context).expressions).scope_values, .sequence_count = (((state_67).context).expressions).sequence_count, .sequence_first = (((state_67).context).expressions).sequence_first, .sequence_items = (((state_67).context).expressions).sequence_items, .some = (((state_67).context).expressions).some, .span_end = (((state_67).context).expressions).span_end, .span_start = (((state_67).context).expressions).span_start, .stores = (((state_67).context).expressions).stores, .strings = (((state_67).context).expressions).strings, .task_bodies = (((state_67).context).expressions).task_bodies, .task_capture_count = (((state_67).context).expressions).task_capture_count, .task_capture_first = (((state_67).context).expressions).task_capture_first, .task_captures = (((state_67).context).expressions).task_captures, .transform_bodies = (((state_67).context).expressions).transform_bodies, .transform_count = (((state_67).context).expressions).transform_count, .transform_first = (((state_67).context).expressions).transform_first, .transform_initials = (((state_67).context).expressions).transform_initials, .transform_kinds = (((state_67).context).expressions).transform_kinds, .transform_parameters = (((state_67).context).expressions).transform_parameters, .transform_targets = (((state_67).context).expressions).transform_targets, .types = (((state_67).context).expressions).types, .unary_operands = (((state_67).context).expressions).unary_operands, .unary_operators = (((state_67).context).expressions).unary_operators, .update_indices = (((state_67).context).expressions).update_indices, .update_targets = (((state_67).context).expressions).update_targets, .update_values = (((state_67).context).expressions).update_values, };

                        break :block_97 @as(*const (zx_abi).zx_type_34, operand_96);
                    }), .functions = (if (((((state_67).context).functions).zx_origin != null)) (((state_67).context).functions).zx_origin.? else block_99: {
                        const operand_98 = (try (allocator).create((zx_abi).zx_type_41));

                        (operand_98).* = (zx_abi).zx_type_41{ .input_types = (((state_67).context).functions).input_types, .output_types = (((state_67).context).functions).output_types, .stores = (((state_67).context).functions).stores, };

                        break :block_99 @as(*const (zx_abi).zx_type_41, operand_98);
                    }), .index = ((state_67).context).index, .orchestration = ((state_67).context).orchestration, .stores = ((state_67).context).stores, .symbols = (if (((((state_67).context).symbols).zx_origin != null)) (((state_67).context).symbols).zx_origin.? else block_101: {
                        const operand_100 = (try (allocator).create((zx_abi).zx_type_39));

                        (operand_100).* = (zx_abi).zx_type_39{ .names = (((state_67).context).symbols).names, .ownership = (((state_67).context).symbols).ownership, .span_end = (((state_67).context).symbols).span_end, .span_start = (((state_67).context).symbols).span_start, .types = (((state_67).context).symbols).types, };

                        break :block_101 @as(*const (zx_abi).zx_type_39, operand_100);
                    }), .table = (if (((((state_67).context).table).zx_origin != null)) (((state_67).context).table).zx_origin.? else block_103: {
                        const operand_102 = (try (allocator).create((zx_abi).zx_type_20));

                        (operand_102).* = (zx_abi).zx_type_20{ .children = (((state_67).context).table).children, .field_names = (((state_67).context).table).field_names, .field_types = (((state_67).context).table).field_types, .first = (((state_67).context).table).first, .kinds = (((state_67).context).table).kinds, .labels = (((state_67).context).table).labels, .names = (((state_67).context).table).names, .second = (((state_67).context).table).second, };

                        break :block_103 @as(*const (zx_abi).zx_type_20, operand_102);
                    }), };

                    break :block_105 @as(*const (zx_abi).zx_type_42, operand_104);
                }), .count = (state_67).count, .first = (state_67).first, .index = (state_67).index, .valid = (state_67).valid, };
            });
        };
    };

    if ((!((&value_12)).valid)) {
        return false;
    }

    return block_66: {
        const operand_15 = block_14: {
            const operand_2 = (&value_1);
            const operand_3 = (try function_0(allocator, block_6: {
                const operand_4 = ((&value_2)).object_first;
                const operand_5 = (in).payload;

                if ((operand_5 >= (operand_4).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_6 (operand_4)[@intCast(operand_5)];
            }));
            const operand_7 = (try function_0(allocator, block_10: {
                const operand_8 = (((&value_1)).table).first;
                const operand_9 = value_4;

                if ((operand_9 >= (operand_8).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_10 (operand_8)[@intCast(operand_9)];
            }));
            const operand_11 = value_3;
            const operand_12 = @as(u64, 0);
            const operand_13 = true;

            break :block_14 (zx_abi).zx_type_53{ .context = operand_2, .first = operand_3, .type_first = operand_7, .count = operand_11, .index = operand_12, .valid = operand_13, };
        };

        var state_1: (zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335 = (zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335{ .context = (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159{ .expressions = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (((operand_15).context).expressions).awaits, .binary_left = (((operand_15).context).expressions).binary_left, .binary_operators = (((operand_15).context).expressions).binary_operators, .binary_right = (((operand_15).context).expressions).binary_right, .booleans = (((operand_15).context).expressions).booleans, .call_arguments = (((operand_15).context).expressions).call_arguments, .call_functions = (((operand_15).context).expressions).call_functions, .call_store_count = (((operand_15).context).expressions).call_store_count, .call_store_first = (((operand_15).context).expressions).call_store_first, .call_stores = (((operand_15).context).expressions).call_stores, .cancellations = (((operand_15).context).expressions).cancellations, .captures = (((operand_15).context).expressions).captures, .collection_arguments = (((operand_15).context).expressions).collection_arguments, .collection_count = (((operand_15).context).expressions).collection_count, .collection_first = (((operand_15).context).expressions).collection_first, .collection_kinds = (((operand_15).context).expressions).collection_kinds, .collection_targets = (((operand_15).context).expressions).collection_targets, .conditional_conditions = (((operand_15).context).expressions).conditional_conditions, .conditional_no = (((operand_15).context).expressions).conditional_no, .conditional_yes = (((operand_15).context).expressions).conditional_yes, .enumerations = (((operand_15).context).expressions).enumerations, .errors = (((operand_15).context).expressions).errors, .floats = (((operand_15).context).expressions).floats, .index_targets = (((operand_15).context).expressions).index_targets, .index_values = (((operand_15).context).expressions).index_values, .integers = (((operand_15).context).expressions).integers, .iteration_bodies = (((operand_15).context).expressions).iteration_bodies, .iteration_condition_parameters = (((operand_15).context).expressions).iteration_condition_parameters, .iteration_conditions = (((operand_15).context).expressions).iteration_conditions, .iteration_initials = (((operand_15).context).expressions).iteration_initials, .iteration_parameters = (((operand_15).context).expressions).iteration_parameters, .iteration_postconditions = (((operand_15).context).expressions).iteration_postconditions, .kinds = (((operand_15).context).expressions).kinds, .lengths = (((operand_15).context).expressions).lengths, .match_conditions = (((operand_15).context).expressions).match_conditions, .match_count = (((operand_15).context).expressions).match_count, .match_fallbacks = (((operand_15).context).expressions).match_fallbacks, .match_first = (((operand_15).context).expressions).match_first, .match_results = (((operand_15).context).expressions).match_results, .match_subjects = (((operand_15).context).expressions).match_subjects, .negative_integers = (((operand_15).context).expressions).negative_integers, .object_count = (((operand_15).context).expressions).object_count, .object_evaluation_count = (((operand_15).context).expressions).object_evaluation_count, .object_evaluation_first = (((operand_15).context).expressions).object_evaluation_first, .object_evaluation_values = (((operand_15).context).expressions).object_evaluation_values, .object_field_indices = (((operand_15).context).expressions).object_field_indices, .object_field_values = (((operand_15).context).expressions).object_field_values, .object_first = (((operand_15).context).expressions).object_first, .optional_values = (((operand_15).context).expressions).optional_values, .parallel_count = (((operand_15).context).expressions).parallel_count, .parallel_fields = (((operand_15).context).expressions).parallel_fields, .parallel_first = (((operand_15).context).expressions).parallel_first, .parallel_tasks = (((operand_15).context).expressions).parallel_tasks, .payloads = (((operand_15).context).expressions).payloads, .projection_indices = (((operand_15).context).expressions).projection_indices, .projection_targets = (((operand_15).context).expressions).projection_targets, .references = (((operand_15).context).expressions).references, .scope_borrows = (((operand_15).context).expressions).scope_borrows, .scope_count = (((operand_15).context).expressions).scope_count, .scope_first = (((operand_15).context).expressions).scope_first, .scope_results = (((operand_15).context).expressions).scope_results, .scope_symbols = (((operand_15).context).expressions).scope_symbols, .scope_values = (((operand_15).context).expressions).scope_values, .sequence_count = (((operand_15).context).expressions).sequence_count, .sequence_first = (((operand_15).context).expressions).sequence_first, .sequence_items = (((operand_15).context).expressions).sequence_items, .some = (((operand_15).context).expressions).some, .span_end = (((operand_15).context).expressions).span_end, .span_start = (((operand_15).context).expressions).span_start, .stores = (((operand_15).context).expressions).stores, .strings = (((operand_15).context).expressions).strings, .task_bodies = (((operand_15).context).expressions).task_bodies, .task_capture_count = (((operand_15).context).expressions).task_capture_count, .task_capture_first = (((operand_15).context).expressions).task_capture_first, .task_captures = (((operand_15).context).expressions).task_captures, .transform_bodies = (((operand_15).context).expressions).transform_bodies, .transform_count = (((operand_15).context).expressions).transform_count, .transform_first = (((operand_15).context).expressions).transform_first, .transform_initials = (((operand_15).context).expressions).transform_initials, .transform_kinds = (((operand_15).context).expressions).transform_kinds, .transform_parameters = (((operand_15).context).expressions).transform_parameters, .transform_targets = (((operand_15).context).expressions).transform_targets, .types = (((operand_15).context).expressions).types, .unary_operands = (((operand_15).context).expressions).unary_operands, .unary_operators = (((operand_15).context).expressions).unary_operators, .update_indices = (((operand_15).context).expressions).update_indices, .update_targets = (((operand_15).context).expressions).update_targets, .update_values = (((operand_15).context).expressions).update_values, .zx_origin = ((operand_15).context).expressions, }, .functions = (zx_abi).value_zx_type_41_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .input_types = (((operand_15).context).functions).input_types, .output_types = (((operand_15).context).functions).output_types, .stores = (((operand_15).context).functions).stores, .zx_origin = ((operand_15).context).functions, }, .index = ((operand_15).context).index, .orchestration = ((operand_15).context).orchestration, .stores = ((operand_15).context).stores, .symbols = (zx_abi).value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((operand_15).context).symbols).names, .ownership = (((operand_15).context).symbols).ownership, .span_end = (((operand_15).context).symbols).span_end, .span_start = (((operand_15).context).symbols).span_start, .types = (((operand_15).context).symbols).types, .zx_origin = ((operand_15).context).symbols, }, .table = (zx_abi).value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_15).context).table).children, .field_names = (((operand_15).context).table).field_names, .field_types = (((operand_15).context).table).field_types, .first = (((operand_15).context).table).first, .kinds = (((operand_15).context).table).kinds, .labels = (((operand_15).context).table).labels, .names = (((operand_15).context).table).names, .second = (((operand_15).context).table).second, .zx_origin = ((operand_15).context).table, }, .zx_origin = (operand_15).context, }, .count = (operand_15).count, .first = (operand_15).first, .index = (operand_15).index, .type_first = (operand_15).type_first, .valid = (operand_15).valid, .zx_origin = (&operand_15), };

        while (((state_1).valid and ((state_1).index < (state_1).count))) {
            state_1 = block_65: {
                const value_15: (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159 = (state_1).context;
                const value_16: u64 = ((state_1).first + (state_1).index);
                const value_17: u64 = (try function_0(allocator, block_64: {
                    const operand_62 = ((value_15).expressions).object_field_indices;
                    const operand_63 = block_61: {
                        break :block_61 value_16;
                    };

                    if ((operand_63 >= (operand_62).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_64 (operand_62)[@intCast(operand_63)];
                }));
                const value_26: (zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335 = (if (((block_18: {
                    break :block_18 value_17;
                } >= (state_1).count) or (!block_36: {
                    const operand_19 = (value_15).expressions;

                    var state_borrow_20: (zx_abi).zx_type_34 = undefined;

                    state_borrow_20 = (zx_abi).zx_type_34{ .awaits = (operand_19).awaits, .binary_left = (operand_19).binary_left, .binary_operators = (operand_19).binary_operators, .binary_right = (operand_19).binary_right, .booleans = (operand_19).booleans, .call_arguments = (operand_19).call_arguments, .call_functions = (operand_19).call_functions, .call_store_count = (operand_19).call_store_count, .call_store_first = (operand_19).call_store_first, .call_stores = (operand_19).call_stores, .cancellations = (operand_19).cancellations, .captures = (operand_19).captures, .collection_arguments = (operand_19).collection_arguments, .collection_count = (operand_19).collection_count, .collection_first = (operand_19).collection_first, .collection_kinds = (operand_19).collection_kinds, .collection_targets = (operand_19).collection_targets, .conditional_conditions = (operand_19).conditional_conditions, .conditional_no = (operand_19).conditional_no, .conditional_yes = (operand_19).conditional_yes, .enumerations = (operand_19).enumerations, .errors = (operand_19).errors, .floats = (operand_19).floats, .index_targets = (operand_19).index_targets, .index_values = (operand_19).index_values, .integers = (operand_19).integers, .iteration_bodies = (operand_19).iteration_bodies, .iteration_condition_parameters = (operand_19).iteration_condition_parameters, .iteration_conditions = (operand_19).iteration_conditions, .iteration_initials = (operand_19).iteration_initials, .iteration_parameters = (operand_19).iteration_parameters, .iteration_postconditions = (operand_19).iteration_postconditions, .kinds = (operand_19).kinds, .lengths = (operand_19).lengths, .match_conditions = (operand_19).match_conditions, .match_count = (operand_19).match_count, .match_fallbacks = (operand_19).match_fallbacks, .match_first = (operand_19).match_first, .match_results = (operand_19).match_results, .match_subjects = (operand_19).match_subjects, .negative_integers = (operand_19).negative_integers, .object_count = (operand_19).object_count, .object_evaluation_count = (operand_19).object_evaluation_count, .object_evaluation_first = (operand_19).object_evaluation_first, .object_evaluation_values = (operand_19).object_evaluation_values, .object_field_indices = (operand_19).object_field_indices, .object_field_values = (operand_19).object_field_values, .object_first = (operand_19).object_first, .optional_values = (operand_19).optional_values, .parallel_count = (operand_19).parallel_count, .parallel_fields = (operand_19).parallel_fields, .parallel_first = (operand_19).parallel_first, .parallel_tasks = (operand_19).parallel_tasks, .payloads = (operand_19).payloads, .projection_indices = (operand_19).projection_indices, .projection_targets = (operand_19).projection_targets, .references = (operand_19).references, .scope_borrows = (operand_19).scope_borrows, .scope_count = (operand_19).scope_count, .scope_first = (operand_19).scope_first, .scope_results = (operand_19).scope_results, .scope_symbols = (operand_19).scope_symbols, .scope_values = (operand_19).scope_values, .sequence_count = (operand_19).sequence_count, .sequence_first = (operand_19).sequence_first, .sequence_items = (operand_19).sequence_items, .some = (operand_19).some, .span_end = (operand_19).span_end, .span_start = (operand_19).span_start, .stores = (operand_19).stores, .strings = (operand_19).strings, .task_bodies = (operand_19).task_bodies, .task_capture_count = (operand_19).task_capture_count, .task_capture_first = (operand_19).task_capture_first, .task_captures = (operand_19).task_captures, .transform_bodies = (operand_19).transform_bodies, .transform_count = (operand_19).transform_count, .transform_first = (operand_19).transform_first, .transform_initials = (operand_19).transform_initials, .transform_kinds = (operand_19).transform_kinds, .transform_parameters = (operand_19).transform_parameters, .transform_targets = (operand_19).transform_targets, .types = (operand_19).types, .unary_operands = (operand_19).unary_operands, .unary_operators = (operand_19).unary_operators, .update_indices = (operand_19).update_indices, .update_targets = (operand_19).update_targets, .update_values = (operand_19).update_values, };

                    const operand_21 = ((operand_19).zx_origin orelse (&state_borrow_20));
                    const operand_22 = (value_15).index;
                    const operand_27 = block_26: {
                        const operand_24 = ((value_15).expressions).object_field_values;
                        const operand_25 = block_23: {
                            break :block_23 value_16;
                        };

                        if ((operand_25 >= (operand_24).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_26 (operand_24)[@intCast(operand_25)];
                    };
                    const operand_32 = block_31: {
                        const operand_29 = ((value_15).table).field_types;
                        const operand_30 = ((state_1).type_first + block_28: {
                            break :block_28 value_17;
                        });

                        if ((operand_30 >= (operand_29).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_31 (operand_29)[@intCast(operand_30)];
                    };
                    const operand_33 = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (operand_21).awaits, .binary_left = (operand_21).binary_left, .binary_operators = (operand_21).binary_operators, .binary_right = (operand_21).binary_right, .booleans = (operand_21).booleans, .call_arguments = (operand_21).call_arguments, .call_functions = (operand_21).call_functions, .call_store_count = (operand_21).call_store_count, .call_store_first = (operand_21).call_store_first, .call_stores = (operand_21).call_stores, .cancellations = (operand_21).cancellations, .captures = (operand_21).captures, .collection_arguments = (operand_21).collection_arguments, .collection_count = (operand_21).collection_count, .collection_first = (operand_21).collection_first, .collection_kinds = (operand_21).collection_kinds, .collection_targets = (operand_21).collection_targets, .conditional_conditions = (operand_21).conditional_conditions, .conditional_no = (operand_21).conditional_no, .conditional_yes = (operand_21).conditional_yes, .enumerations = (operand_21).enumerations, .errors = (operand_21).errors, .floats = (operand_21).floats, .index_targets = (operand_21).index_targets, .index_values = (operand_21).index_values, .integers = (operand_21).integers, .iteration_bodies = (operand_21).iteration_bodies, .iteration_condition_parameters = (operand_21).iteration_condition_parameters, .iteration_conditions = (operand_21).iteration_conditions, .iteration_initials = (operand_21).iteration_initials, .iteration_parameters = (operand_21).iteration_parameters, .iteration_postconditions = (operand_21).iteration_postconditions, .kinds = (operand_21).kinds, .lengths = (operand_21).lengths, .match_conditions = (operand_21).match_conditions, .match_count = (operand_21).match_count, .match_fallbacks = (operand_21).match_fallbacks, .match_first = (operand_21).match_first, .match_results = (operand_21).match_results, .match_subjects = (operand_21).match_subjects, .negative_integers = (operand_21).negative_integers, .object_count = (operand_21).object_count, .object_evaluation_count = (operand_21).object_evaluation_count, .object_evaluation_first = (operand_21).object_evaluation_first, .object_evaluation_values = (operand_21).object_evaluation_values, .object_field_indices = (operand_21).object_field_indices, .object_field_values = (operand_21).object_field_values, .object_first = (operand_21).object_first, .optional_values = (operand_21).optional_values, .parallel_count = (operand_21).parallel_count, .parallel_fields = (operand_21).parallel_fields, .parallel_first = (operand_21).parallel_first, .parallel_tasks = (operand_21).parallel_tasks, .payloads = (operand_21).payloads, .projection_indices = (operand_21).projection_indices, .projection_targets = (operand_21).projection_targets, .references = (operand_21).references, .scope_borrows = (operand_21).scope_borrows, .scope_count = (operand_21).scope_count, .scope_first = (operand_21).scope_first, .scope_results = (operand_21).scope_results, .scope_symbols = (operand_21).scope_symbols, .scope_values = (operand_21).scope_values, .sequence_count = (operand_21).sequence_count, .sequence_first = (operand_21).sequence_first, .sequence_items = (operand_21).sequence_items, .some = (operand_21).some, .span_end = (operand_21).span_end, .span_start = (operand_21).span_start, .stores = (operand_21).stores, .strings = (operand_21).strings, .task_bodies = (operand_21).task_bodies, .task_capture_count = (operand_21).task_capture_count, .task_capture_first = (operand_21).task_capture_first, .task_captures = (operand_21).task_captures, .transform_bodies = (operand_21).transform_bodies, .transform_count = (operand_21).transform_count, .transform_first = (operand_21).transform_first, .transform_initials = (operand_21).transform_initials, .transform_kinds = (operand_21).transform_kinds, .transform_parameters = (operand_21).transform_parameters, .transform_targets = (operand_21).transform_targets, .types = (operand_21).types, .unary_operands = (operand_21).unary_operands, .unary_operators = (operand_21).unary_operators, .update_indices = (operand_21).update_indices, .update_targets = (operand_21).update_targets, .update_values = (operand_21).update_values, .zx_origin = operand_21, };

                    var state_borrow_34: (zx_abi).zx_type_34 = undefined;

                    state_borrow_34 = (zx_abi).zx_type_34{ .awaits = (operand_33).awaits, .binary_left = (operand_33).binary_left, .binary_operators = (operand_33).binary_operators, .binary_right = (operand_33).binary_right, .booleans = (operand_33).booleans, .call_arguments = (operand_33).call_arguments, .call_functions = (operand_33).call_functions, .call_store_count = (operand_33).call_store_count, .call_store_first = (operand_33).call_store_first, .call_stores = (operand_33).call_stores, .cancellations = (operand_33).cancellations, .captures = (operand_33).captures, .collection_arguments = (operand_33).collection_arguments, .collection_count = (operand_33).collection_count, .collection_first = (operand_33).collection_first, .collection_kinds = (operand_33).collection_kinds, .collection_targets = (operand_33).collection_targets, .conditional_conditions = (operand_33).conditional_conditions, .conditional_no = (operand_33).conditional_no, .conditional_yes = (operand_33).conditional_yes, .enumerations = (operand_33).enumerations, .errors = (operand_33).errors, .floats = (operand_33).floats, .index_targets = (operand_33).index_targets, .index_values = (operand_33).index_values, .integers = (operand_33).integers, .iteration_bodies = (operand_33).iteration_bodies, .iteration_condition_parameters = (operand_33).iteration_condition_parameters, .iteration_conditions = (operand_33).iteration_conditions, .iteration_initials = (operand_33).iteration_initials, .iteration_parameters = (operand_33).iteration_parameters, .iteration_postconditions = (operand_33).iteration_postconditions, .kinds = (operand_33).kinds, .lengths = (operand_33).lengths, .match_conditions = (operand_33).match_conditions, .match_count = (operand_33).match_count, .match_fallbacks = (operand_33).match_fallbacks, .match_first = (operand_33).match_first, .match_results = (operand_33).match_results, .match_subjects = (operand_33).match_subjects, .negative_integers = (operand_33).negative_integers, .object_count = (operand_33).object_count, .object_evaluation_count = (operand_33).object_evaluation_count, .object_evaluation_first = (operand_33).object_evaluation_first, .object_evaluation_values = (operand_33).object_evaluation_values, .object_field_indices = (operand_33).object_field_indices, .object_field_values = (operand_33).object_field_values, .object_first = (operand_33).object_first, .optional_values = (operand_33).optional_values, .parallel_count = (operand_33).parallel_count, .parallel_fields = (operand_33).parallel_fields, .parallel_first = (operand_33).parallel_first, .parallel_tasks = (operand_33).parallel_tasks, .payloads = (operand_33).payloads, .projection_indices = (operand_33).projection_indices, .projection_targets = (operand_33).projection_targets, .references = (operand_33).references, .scope_borrows = (operand_33).scope_borrows, .scope_count = (operand_33).scope_count, .scope_first = (operand_33).scope_first, .scope_results = (operand_33).scope_results, .scope_symbols = (operand_33).scope_symbols, .scope_values = (operand_33).scope_values, .sequence_count = (operand_33).sequence_count, .sequence_first = (operand_33).sequence_first, .sequence_items = (operand_33).sequence_items, .some = (operand_33).some, .span_end = (operand_33).span_end, .span_start = (operand_33).span_start, .stores = (operand_33).stores, .strings = (operand_33).strings, .task_bodies = (operand_33).task_bodies, .task_capture_count = (operand_33).task_capture_count, .task_capture_first = (operand_33).task_capture_first, .task_captures = (operand_33).task_captures, .transform_bodies = (operand_33).transform_bodies, .transform_count = (operand_33).transform_count, .transform_first = (operand_33).transform_first, .transform_initials = (operand_33).transform_initials, .transform_kinds = (operand_33).transform_kinds, .transform_parameters = (operand_33).transform_parameters, .transform_targets = (operand_33).transform_targets, .types = (operand_33).types, .unary_operands = (operand_33).unary_operands, .unary_operators = (operand_33).unary_operators, .update_indices = (operand_33).update_indices, .update_targets = (operand_33).update_targets, .update_values = (operand_33).update_values, };

                    const operand_35 = (zx_abi).zx_type_35{ .expressions = ((operand_33).zx_origin orelse (&state_borrow_34)), .index = operand_22, .id = operand_27, .type_id = operand_32, };

                    break :block_36 (try function_10(allocator, (&operand_35)));
                }))) block_38: {
                    const value_18: (zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335 = block_37: {
                        break :block_37 @as((zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335, (zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335{ .context = (state_1).context, .count = (state_1).count, .first = (state_1).first, .index = (state_1).index, .type_first = (state_1).type_first, .valid = false, });
                    };

                    break :block_38 value_18;
                } else block_60: {
                    const value_24: (zx_abi).value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_59: {
                        const operand_49 = block_48: {
                            const operand_41 = ((value_15).expressions).object_field_indices;
                            const operand_42 = (state_1).first;
                            const operand_43 = (state_1).index;
                            const operand_44 = block_45: {
                                break :block_45 value_17;
                            };
                            const operand_46 = @as(u64, 0);
                            const operand_47 = false;

                            break :block_48 @as((zx_abi).value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .indices = operand_41, .first = operand_42, .limit = operand_43, .field = operand_44, .index = operand_46, .found = operand_47, });
                        };

                        var state_40: (zx_abi).value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = operand_49;

                        var state_changed_50 = false;

                        while (((!(state_40).found) and ((state_40).index < (state_40).limit))) {
                            state_40 = block_57: {
                                const value_21: (zx_abi).value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_56: {
                                    break :block_56 @as((zx_abi).value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .field = (state_40).field, .first = (state_40).first, .found = ((try function_0(allocator, block_55: {
                                        const operand_53 = (state_40).indices;
                                        const operand_54 = ((state_40).first + (state_40).index);

                                        if ((operand_54 >= (operand_53).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_55 (operand_53)[@intCast(operand_54)];
                                    })) == (state_40).field), .index = (state_40).index, .indices = (state_40).indices, .limit = (state_40).limit, });
                                };
                                const value_22: u64 = (value_21).index;
                                const value_23: (zx_abi).value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_52: {
                                    break :block_52 @as((zx_abi).value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .field = (value_21).field, .first = (value_21).first, .found = (value_21).found, .index = (block_51: {
                                        break :block_51 value_22;
                                    } + @as(u64, 1)), .indices = (value_21).indices, .limit = (value_21).limit, });
                                };

                                break :block_57 value_23;
                            };

                            state_changed_50 = true;
                        }

                        break :block_59 (if (state_changed_50) state_40 else operand_49);
                    };
                    const value_25: (zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335 = block_39: {
                        break :block_39 @as((zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335, (zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335{ .context = (state_1).context, .count = (state_1).count, .first = (state_1).first, .index = (state_1).index, .type_first = (state_1).type_first, .valid = (!(value_24).found), });
                    };

                    break :block_60 value_25;
                });
                const value_27: u64 = (value_26).index;
                const value_28: (zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335 = block_17: {
                    break :block_17 @as((zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335, (zx_abi).value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335{ .context = (value_26).context, .count = (value_26).count, .first = (value_26).first, .index = (block_16: {
                        break :block_16 value_27;
                    } + @as(u64, 1)), .type_first = (value_26).type_first, .valid = (value_26).valid, });
                };

                break :block_65 value_28;
            };
        }

        break :block_66 (state_1).valid;
    };
}

fn function_20(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;
    const value_3: (zx_abi).zx_type_20 = (((&value_1)).table).*;
    const value_4: u64 = (try function_0(allocator, block_87: {
        const operand_85 = ((&value_2)).collection_targets;
        const operand_86 = (in).payload;

        if ((operand_86 >= (operand_85).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_87 (operand_85)[@intCast(operand_86)];
    }));
    const value_5: u64 = (try function_0(allocator, (in).type_id));

    if ((((value_4 >= ((&value_1)).index) or ((in).target != @as((zx_abi).zx_type_16, .Tuple))) or (block_84: {
        const operand_82 = ((&value_3)).second;
        const operand_83 = value_5;

        if ((operand_83 >= (operand_82).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_84 (operand_82)[@intCast(operand_83)];
    } != @as(u32, 2)))) {
        return false;
    }

    const value_6: u32 = block_81: {
        const operand_79 = ((&value_2)).types;
        const operand_80 = value_4;

        if ((operand_80 >= (operand_79).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_81 (operand_79)[@intCast(operand_80)];
    };
    const value_7: u64 = (try function_0(allocator, value_6));
    const value_8: u64 = (try function_0(allocator, block_78: {
        const operand_76 = ((&value_3)).first;
        const operand_77 = value_5;

        if ((operand_77 >= (operand_76).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_78 (operand_76)[@intCast(operand_77)];
    }));

    if ((((try function_9(allocator, block_72: {
        const operand_70 = ((&value_3)).kinds;
        const operand_71 = value_7;

        if ((operand_71 >= (operand_70).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_72 (operand_70)[@intCast(operand_71)];
    })) != @as((zx_abi).zx_type_16, .List)) or (block_75: {
        const operand_73 = ((&value_3)).children;
        const operand_74 = value_8;

        if ((operand_74 >= (operand_73).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_75 (operand_73)[@intCast(operand_74)];
    } != value_6))) {
        return false;
    }

    const value_9: (zx_abi).zx_type_12 = block_69: {
        const operand_67 = ((&value_2)).collection_kinds;
        const operand_68 = (in).payload;

        if ((operand_68 >= (operand_67).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_69 (operand_67)[@intCast(operand_68)];
    };
    const value_10: u64 = (try function_0(allocator, block_66: {
        const operand_64 = ((&value_2)).collection_count;
        const operand_65 = (in).payload;

        if ((operand_65 >= (operand_64).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_66 (operand_64)[@intCast(operand_65)];
    }));
    const value_11: u64 = block_63: {
        const operand_62 = value_9;

        break :block_63 (if ((operand_62 == @as((zx_abi).zx_type_12, .Push))) @as(u64, 1) else (if ((operand_62 == @as((zx_abi).zx_type_12, .Concat))) @as(u64, 1) else (if ((operand_62 == @as((zx_abi).zx_type_12, .Splice))) @as(u64, 3) else @as(u64, 0))));
    };

    if ((value_10 != value_11)) {
        return false;
    }

    const value_12: u32 = block_61: {
        const operand_59 = ((&value_3)).first;
        const operand_60 = value_7;

        if ((operand_60 >= (operand_59).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_61 (operand_59)[@intCast(operand_60)];
    };
    const value_20: (zx_abi).zx_type_55 = block_58: {
        const operand_25 = block_24: {
            const operand_13 = (&value_1);
            const operand_14 = (try function_0(allocator, block_17: {
                const operand_15 = ((&value_2)).collection_first;
                const operand_16 = (in).payload;

                if ((operand_16 >= (operand_15).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_17 (operand_15)[@intCast(operand_16)];
            }));
            const operand_18 = value_10;
            const operand_19 = value_9;
            const operand_20 = value_12;
            const operand_21 = value_6;
            const operand_22 = @as(u64, 0);
            const operand_23 = true;

            break :block_24 (zx_abi).zx_type_55{ .context = operand_13, .first = operand_14, .count = operand_18, .operation = operand_19, .element = operand_20, .source = operand_21, .index = operand_22, .valid = operand_23, };
        };

        var state_12: (zx_abi).value_zx_type_55_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef = (zx_abi).value_zx_type_55_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef{ .context = (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159{ .expressions = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (((operand_25).context).expressions).awaits, .binary_left = (((operand_25).context).expressions).binary_left, .binary_operators = (((operand_25).context).expressions).binary_operators, .binary_right = (((operand_25).context).expressions).binary_right, .booleans = (((operand_25).context).expressions).booleans, .call_arguments = (((operand_25).context).expressions).call_arguments, .call_functions = (((operand_25).context).expressions).call_functions, .call_store_count = (((operand_25).context).expressions).call_store_count, .call_store_first = (((operand_25).context).expressions).call_store_first, .call_stores = (((operand_25).context).expressions).call_stores, .cancellations = (((operand_25).context).expressions).cancellations, .captures = (((operand_25).context).expressions).captures, .collection_arguments = (((operand_25).context).expressions).collection_arguments, .collection_count = (((operand_25).context).expressions).collection_count, .collection_first = (((operand_25).context).expressions).collection_first, .collection_kinds = (((operand_25).context).expressions).collection_kinds, .collection_targets = (((operand_25).context).expressions).collection_targets, .conditional_conditions = (((operand_25).context).expressions).conditional_conditions, .conditional_no = (((operand_25).context).expressions).conditional_no, .conditional_yes = (((operand_25).context).expressions).conditional_yes, .enumerations = (((operand_25).context).expressions).enumerations, .errors = (((operand_25).context).expressions).errors, .floats = (((operand_25).context).expressions).floats, .index_targets = (((operand_25).context).expressions).index_targets, .index_values = (((operand_25).context).expressions).index_values, .integers = (((operand_25).context).expressions).integers, .iteration_bodies = (((operand_25).context).expressions).iteration_bodies, .iteration_condition_parameters = (((operand_25).context).expressions).iteration_condition_parameters, .iteration_conditions = (((operand_25).context).expressions).iteration_conditions, .iteration_initials = (((operand_25).context).expressions).iteration_initials, .iteration_parameters = (((operand_25).context).expressions).iteration_parameters, .iteration_postconditions = (((operand_25).context).expressions).iteration_postconditions, .kinds = (((operand_25).context).expressions).kinds, .lengths = (((operand_25).context).expressions).lengths, .match_conditions = (((operand_25).context).expressions).match_conditions, .match_count = (((operand_25).context).expressions).match_count, .match_fallbacks = (((operand_25).context).expressions).match_fallbacks, .match_first = (((operand_25).context).expressions).match_first, .match_results = (((operand_25).context).expressions).match_results, .match_subjects = (((operand_25).context).expressions).match_subjects, .negative_integers = (((operand_25).context).expressions).negative_integers, .object_count = (((operand_25).context).expressions).object_count, .object_evaluation_count = (((operand_25).context).expressions).object_evaluation_count, .object_evaluation_first = (((operand_25).context).expressions).object_evaluation_first, .object_evaluation_values = (((operand_25).context).expressions).object_evaluation_values, .object_field_indices = (((operand_25).context).expressions).object_field_indices, .object_field_values = (((operand_25).context).expressions).object_field_values, .object_first = (((operand_25).context).expressions).object_first, .optional_values = (((operand_25).context).expressions).optional_values, .parallel_count = (((operand_25).context).expressions).parallel_count, .parallel_fields = (((operand_25).context).expressions).parallel_fields, .parallel_first = (((operand_25).context).expressions).parallel_first, .parallel_tasks = (((operand_25).context).expressions).parallel_tasks, .payloads = (((operand_25).context).expressions).payloads, .projection_indices = (((operand_25).context).expressions).projection_indices, .projection_targets = (((operand_25).context).expressions).projection_targets, .references = (((operand_25).context).expressions).references, .scope_borrows = (((operand_25).context).expressions).scope_borrows, .scope_count = (((operand_25).context).expressions).scope_count, .scope_first = (((operand_25).context).expressions).scope_first, .scope_results = (((operand_25).context).expressions).scope_results, .scope_symbols = (((operand_25).context).expressions).scope_symbols, .scope_values = (((operand_25).context).expressions).scope_values, .sequence_count = (((operand_25).context).expressions).sequence_count, .sequence_first = (((operand_25).context).expressions).sequence_first, .sequence_items = (((operand_25).context).expressions).sequence_items, .some = (((operand_25).context).expressions).some, .span_end = (((operand_25).context).expressions).span_end, .span_start = (((operand_25).context).expressions).span_start, .stores = (((operand_25).context).expressions).stores, .strings = (((operand_25).context).expressions).strings, .task_bodies = (((operand_25).context).expressions).task_bodies, .task_capture_count = (((operand_25).context).expressions).task_capture_count, .task_capture_first = (((operand_25).context).expressions).task_capture_first, .task_captures = (((operand_25).context).expressions).task_captures, .transform_bodies = (((operand_25).context).expressions).transform_bodies, .transform_count = (((operand_25).context).expressions).transform_count, .transform_first = (((operand_25).context).expressions).transform_first, .transform_initials = (((operand_25).context).expressions).transform_initials, .transform_kinds = (((operand_25).context).expressions).transform_kinds, .transform_parameters = (((operand_25).context).expressions).transform_parameters, .transform_targets = (((operand_25).context).expressions).transform_targets, .types = (((operand_25).context).expressions).types, .unary_operands = (((operand_25).context).expressions).unary_operands, .unary_operators = (((operand_25).context).expressions).unary_operators, .update_indices = (((operand_25).context).expressions).update_indices, .update_targets = (((operand_25).context).expressions).update_targets, .update_values = (((operand_25).context).expressions).update_values, .zx_origin = ((operand_25).context).expressions, }, .functions = (zx_abi).value_zx_type_41_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .input_types = (((operand_25).context).functions).input_types, .output_types = (((operand_25).context).functions).output_types, .stores = (((operand_25).context).functions).stores, .zx_origin = ((operand_25).context).functions, }, .index = ((operand_25).context).index, .orchestration = ((operand_25).context).orchestration, .stores = ((operand_25).context).stores, .symbols = (zx_abi).value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((operand_25).context).symbols).names, .ownership = (((operand_25).context).symbols).ownership, .span_end = (((operand_25).context).symbols).span_end, .span_start = (((operand_25).context).symbols).span_start, .types = (((operand_25).context).symbols).types, .zx_origin = ((operand_25).context).symbols, }, .table = (zx_abi).value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_25).context).table).children, .field_names = (((operand_25).context).table).field_names, .field_types = (((operand_25).context).table).field_types, .first = (((operand_25).context).table).first, .kinds = (((operand_25).context).table).kinds, .labels = (((operand_25).context).table).labels, .names = (((operand_25).context).table).names, .second = (((operand_25).context).table).second, .zx_origin = ((operand_25).context).table, }, .zx_origin = (operand_25).context, }, .count = (operand_25).count, .element = (operand_25).element, .first = (operand_25).first, .index = (operand_25).index, .operation = (operand_25).operation, .source = (operand_25).source, .valid = (operand_25).valid, .zx_origin = (&operand_25), };

        while (((state_12).valid and ((state_12).index < (state_12).count))) {
            state_12 = block_45: {
                const value_15: u32 = block_44: {
                    const operand_43 = (state_12).operation;

                    break :block_44 (if ((operand_43 == @as((zx_abi).zx_type_12, .Push))) (state_12).element else (if ((operand_43 == @as((zx_abi).zx_type_12, .Splice))) (if (((state_12).index < @as(u64, 2))) @as(u32, 5) else (state_12).source) else (state_12).source));
                };
                const value_16: (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159 = (state_12).context;
                const value_17: (zx_abi).value_zx_type_55_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef = block_42: {
                    break :block_42 @as((zx_abi).value_zx_type_55_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef, (zx_abi).value_zx_type_55_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef{ .context = (state_12).context, .count = (state_12).count, .element = (state_12).element, .first = (state_12).first, .index = (state_12).index, .operation = (state_12).operation, .source = (state_12).source, .valid = block_41: {
                        const operand_28 = (value_16).expressions;

                        var state_borrow_29: (zx_abi).zx_type_34 = undefined;

                        state_borrow_29 = (zx_abi).zx_type_34{ .awaits = (operand_28).awaits, .binary_left = (operand_28).binary_left, .binary_operators = (operand_28).binary_operators, .binary_right = (operand_28).binary_right, .booleans = (operand_28).booleans, .call_arguments = (operand_28).call_arguments, .call_functions = (operand_28).call_functions, .call_store_count = (operand_28).call_store_count, .call_store_first = (operand_28).call_store_first, .call_stores = (operand_28).call_stores, .cancellations = (operand_28).cancellations, .captures = (operand_28).captures, .collection_arguments = (operand_28).collection_arguments, .collection_count = (operand_28).collection_count, .collection_first = (operand_28).collection_first, .collection_kinds = (operand_28).collection_kinds, .collection_targets = (operand_28).collection_targets, .conditional_conditions = (operand_28).conditional_conditions, .conditional_no = (operand_28).conditional_no, .conditional_yes = (operand_28).conditional_yes, .enumerations = (operand_28).enumerations, .errors = (operand_28).errors, .floats = (operand_28).floats, .index_targets = (operand_28).index_targets, .index_values = (operand_28).index_values, .integers = (operand_28).integers, .iteration_bodies = (operand_28).iteration_bodies, .iteration_condition_parameters = (operand_28).iteration_condition_parameters, .iteration_conditions = (operand_28).iteration_conditions, .iteration_initials = (operand_28).iteration_initials, .iteration_parameters = (operand_28).iteration_parameters, .iteration_postconditions = (operand_28).iteration_postconditions, .kinds = (operand_28).kinds, .lengths = (operand_28).lengths, .match_conditions = (operand_28).match_conditions, .match_count = (operand_28).match_count, .match_fallbacks = (operand_28).match_fallbacks, .match_first = (operand_28).match_first, .match_results = (operand_28).match_results, .match_subjects = (operand_28).match_subjects, .negative_integers = (operand_28).negative_integers, .object_count = (operand_28).object_count, .object_evaluation_count = (operand_28).object_evaluation_count, .object_evaluation_first = (operand_28).object_evaluation_first, .object_evaluation_values = (operand_28).object_evaluation_values, .object_field_indices = (operand_28).object_field_indices, .object_field_values = (operand_28).object_field_values, .object_first = (operand_28).object_first, .optional_values = (operand_28).optional_values, .parallel_count = (operand_28).parallel_count, .parallel_fields = (operand_28).parallel_fields, .parallel_first = (operand_28).parallel_first, .parallel_tasks = (operand_28).parallel_tasks, .payloads = (operand_28).payloads, .projection_indices = (operand_28).projection_indices, .projection_targets = (operand_28).projection_targets, .references = (operand_28).references, .scope_borrows = (operand_28).scope_borrows, .scope_count = (operand_28).scope_count, .scope_first = (operand_28).scope_first, .scope_results = (operand_28).scope_results, .scope_symbols = (operand_28).scope_symbols, .scope_values = (operand_28).scope_values, .sequence_count = (operand_28).sequence_count, .sequence_first = (operand_28).sequence_first, .sequence_items = (operand_28).sequence_items, .some = (operand_28).some, .span_end = (operand_28).span_end, .span_start = (operand_28).span_start, .stores = (operand_28).stores, .strings = (operand_28).strings, .task_bodies = (operand_28).task_bodies, .task_capture_count = (operand_28).task_capture_count, .task_capture_first = (operand_28).task_capture_first, .task_captures = (operand_28).task_captures, .transform_bodies = (operand_28).transform_bodies, .transform_count = (operand_28).transform_count, .transform_first = (operand_28).transform_first, .transform_initials = (operand_28).transform_initials, .transform_kinds = (operand_28).transform_kinds, .transform_parameters = (operand_28).transform_parameters, .transform_targets = (operand_28).transform_targets, .types = (operand_28).types, .unary_operands = (operand_28).unary_operands, .unary_operators = (operand_28).unary_operators, .update_indices = (operand_28).update_indices, .update_targets = (operand_28).update_targets, .update_values = (operand_28).update_values, };

                        const operand_30 = ((operand_28).zx_origin orelse (&state_borrow_29));
                        const operand_31 = (value_16).index;
                        const operand_35 = block_34: {
                            const operand_32 = ((value_16).expressions).collection_arguments;
                            const operand_33 = ((state_12).first + (state_12).index);

                            if ((operand_33 >= (operand_32).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_34 (operand_32)[@intCast(operand_33)];
                        };
                        const operand_37 = block_36: {
                            break :block_36 value_15;
                        };
                        const operand_38 = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (operand_30).awaits, .binary_left = (operand_30).binary_left, .binary_operators = (operand_30).binary_operators, .binary_right = (operand_30).binary_right, .booleans = (operand_30).booleans, .call_arguments = (operand_30).call_arguments, .call_functions = (operand_30).call_functions, .call_store_count = (operand_30).call_store_count, .call_store_first = (operand_30).call_store_first, .call_stores = (operand_30).call_stores, .cancellations = (operand_30).cancellations, .captures = (operand_30).captures, .collection_arguments = (operand_30).collection_arguments, .collection_count = (operand_30).collection_count, .collection_first = (operand_30).collection_first, .collection_kinds = (operand_30).collection_kinds, .collection_targets = (operand_30).collection_targets, .conditional_conditions = (operand_30).conditional_conditions, .conditional_no = (operand_30).conditional_no, .conditional_yes = (operand_30).conditional_yes, .enumerations = (operand_30).enumerations, .errors = (operand_30).errors, .floats = (operand_30).floats, .index_targets = (operand_30).index_targets, .index_values = (operand_30).index_values, .integers = (operand_30).integers, .iteration_bodies = (operand_30).iteration_bodies, .iteration_condition_parameters = (operand_30).iteration_condition_parameters, .iteration_conditions = (operand_30).iteration_conditions, .iteration_initials = (operand_30).iteration_initials, .iteration_parameters = (operand_30).iteration_parameters, .iteration_postconditions = (operand_30).iteration_postconditions, .kinds = (operand_30).kinds, .lengths = (operand_30).lengths, .match_conditions = (operand_30).match_conditions, .match_count = (operand_30).match_count, .match_fallbacks = (operand_30).match_fallbacks, .match_first = (operand_30).match_first, .match_results = (operand_30).match_results, .match_subjects = (operand_30).match_subjects, .negative_integers = (operand_30).negative_integers, .object_count = (operand_30).object_count, .object_evaluation_count = (operand_30).object_evaluation_count, .object_evaluation_first = (operand_30).object_evaluation_first, .object_evaluation_values = (operand_30).object_evaluation_values, .object_field_indices = (operand_30).object_field_indices, .object_field_values = (operand_30).object_field_values, .object_first = (operand_30).object_first, .optional_values = (operand_30).optional_values, .parallel_count = (operand_30).parallel_count, .parallel_fields = (operand_30).parallel_fields, .parallel_first = (operand_30).parallel_first, .parallel_tasks = (operand_30).parallel_tasks, .payloads = (operand_30).payloads, .projection_indices = (operand_30).projection_indices, .projection_targets = (operand_30).projection_targets, .references = (operand_30).references, .scope_borrows = (operand_30).scope_borrows, .scope_count = (operand_30).scope_count, .scope_first = (operand_30).scope_first, .scope_results = (operand_30).scope_results, .scope_symbols = (operand_30).scope_symbols, .scope_values = (operand_30).scope_values, .sequence_count = (operand_30).sequence_count, .sequence_first = (operand_30).sequence_first, .sequence_items = (operand_30).sequence_items, .some = (operand_30).some, .span_end = (operand_30).span_end, .span_start = (operand_30).span_start, .stores = (operand_30).stores, .strings = (operand_30).strings, .task_bodies = (operand_30).task_bodies, .task_capture_count = (operand_30).task_capture_count, .task_capture_first = (operand_30).task_capture_first, .task_captures = (operand_30).task_captures, .transform_bodies = (operand_30).transform_bodies, .transform_count = (operand_30).transform_count, .transform_first = (operand_30).transform_first, .transform_initials = (operand_30).transform_initials, .transform_kinds = (operand_30).transform_kinds, .transform_parameters = (operand_30).transform_parameters, .transform_targets = (operand_30).transform_targets, .types = (operand_30).types, .unary_operands = (operand_30).unary_operands, .unary_operators = (operand_30).unary_operators, .update_indices = (operand_30).update_indices, .update_targets = (operand_30).update_targets, .update_values = (operand_30).update_values, .zx_origin = operand_30, };

                        var state_borrow_39: (zx_abi).zx_type_34 = undefined;

                        state_borrow_39 = (zx_abi).zx_type_34{ .awaits = (operand_38).awaits, .binary_left = (operand_38).binary_left, .binary_operators = (operand_38).binary_operators, .binary_right = (operand_38).binary_right, .booleans = (operand_38).booleans, .call_arguments = (operand_38).call_arguments, .call_functions = (operand_38).call_functions, .call_store_count = (operand_38).call_store_count, .call_store_first = (operand_38).call_store_first, .call_stores = (operand_38).call_stores, .cancellations = (operand_38).cancellations, .captures = (operand_38).captures, .collection_arguments = (operand_38).collection_arguments, .collection_count = (operand_38).collection_count, .collection_first = (operand_38).collection_first, .collection_kinds = (operand_38).collection_kinds, .collection_targets = (operand_38).collection_targets, .conditional_conditions = (operand_38).conditional_conditions, .conditional_no = (operand_38).conditional_no, .conditional_yes = (operand_38).conditional_yes, .enumerations = (operand_38).enumerations, .errors = (operand_38).errors, .floats = (operand_38).floats, .index_targets = (operand_38).index_targets, .index_values = (operand_38).index_values, .integers = (operand_38).integers, .iteration_bodies = (operand_38).iteration_bodies, .iteration_condition_parameters = (operand_38).iteration_condition_parameters, .iteration_conditions = (operand_38).iteration_conditions, .iteration_initials = (operand_38).iteration_initials, .iteration_parameters = (operand_38).iteration_parameters, .iteration_postconditions = (operand_38).iteration_postconditions, .kinds = (operand_38).kinds, .lengths = (operand_38).lengths, .match_conditions = (operand_38).match_conditions, .match_count = (operand_38).match_count, .match_fallbacks = (operand_38).match_fallbacks, .match_first = (operand_38).match_first, .match_results = (operand_38).match_results, .match_subjects = (operand_38).match_subjects, .negative_integers = (operand_38).negative_integers, .object_count = (operand_38).object_count, .object_evaluation_count = (operand_38).object_evaluation_count, .object_evaluation_first = (operand_38).object_evaluation_first, .object_evaluation_values = (operand_38).object_evaluation_values, .object_field_indices = (operand_38).object_field_indices, .object_field_values = (operand_38).object_field_values, .object_first = (operand_38).object_first, .optional_values = (operand_38).optional_values, .parallel_count = (operand_38).parallel_count, .parallel_fields = (operand_38).parallel_fields, .parallel_first = (operand_38).parallel_first, .parallel_tasks = (operand_38).parallel_tasks, .payloads = (operand_38).payloads, .projection_indices = (operand_38).projection_indices, .projection_targets = (operand_38).projection_targets, .references = (operand_38).references, .scope_borrows = (operand_38).scope_borrows, .scope_count = (operand_38).scope_count, .scope_first = (operand_38).scope_first, .scope_results = (operand_38).scope_results, .scope_symbols = (operand_38).scope_symbols, .scope_values = (operand_38).scope_values, .sequence_count = (operand_38).sequence_count, .sequence_first = (operand_38).sequence_first, .sequence_items = (operand_38).sequence_items, .some = (operand_38).some, .span_end = (operand_38).span_end, .span_start = (operand_38).span_start, .stores = (operand_38).stores, .strings = (operand_38).strings, .task_bodies = (operand_38).task_bodies, .task_capture_count = (operand_38).task_capture_count, .task_capture_first = (operand_38).task_capture_first, .task_captures = (operand_38).task_captures, .transform_bodies = (operand_38).transform_bodies, .transform_count = (operand_38).transform_count, .transform_first = (operand_38).transform_first, .transform_initials = (operand_38).transform_initials, .transform_kinds = (operand_38).transform_kinds, .transform_parameters = (operand_38).transform_parameters, .transform_targets = (operand_38).transform_targets, .types = (operand_38).types, .unary_operands = (operand_38).unary_operands, .unary_operators = (operand_38).unary_operators, .update_indices = (operand_38).update_indices, .update_targets = (operand_38).update_targets, .update_values = (operand_38).update_values, };

                        const operand_40 = (zx_abi).zx_type_35{ .expressions = ((operand_38).zx_origin orelse (&state_borrow_39)), .index = operand_31, .id = operand_35, .type_id = operand_37, };

                        break :block_41 (try function_10(allocator, (&operand_40)));
                    }, });
                };
                const value_18: u64 = (value_17).index;
                const value_19: (zx_abi).value_zx_type_55_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef = block_27: {
                    break :block_27 @as((zx_abi).value_zx_type_55_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef, (zx_abi).value_zx_type_55_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef{ .context = (value_17).context, .count = (value_17).count, .element = (value_17).element, .first = (value_17).first, .index = (block_26: {
                        break :block_26 value_18;
                    } + @as(u64, 1)), .operation = (value_17).operation, .source = (value_17).source, .valid = (value_17).valid, });
                };

                break :block_45 value_19;
            };
        }

        break :block_58 block_57: {
            break :block_57 (if (((state_12).zx_origin != null)) ((state_12).zx_origin.?).* else block_56: {
                break :block_56 (zx_abi).zx_type_55{ .context = (if ((((state_12).context).zx_origin != null)) ((state_12).context).zx_origin.? else block_55: {
                    const operand_54 = (try (allocator).create((zx_abi).zx_type_42));

                    (operand_54).* = (zx_abi).zx_type_42{ .expressions = (if (((((state_12).context).expressions).zx_origin != null)) (((state_12).context).expressions).zx_origin.? else block_47: {
                        const operand_46 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_46).* = (zx_abi).zx_type_34{ .awaits = (((state_12).context).expressions).awaits, .binary_left = (((state_12).context).expressions).binary_left, .binary_operators = (((state_12).context).expressions).binary_operators, .binary_right = (((state_12).context).expressions).binary_right, .booleans = (((state_12).context).expressions).booleans, .call_arguments = (((state_12).context).expressions).call_arguments, .call_functions = (((state_12).context).expressions).call_functions, .call_store_count = (((state_12).context).expressions).call_store_count, .call_store_first = (((state_12).context).expressions).call_store_first, .call_stores = (((state_12).context).expressions).call_stores, .cancellations = (((state_12).context).expressions).cancellations, .captures = (((state_12).context).expressions).captures, .collection_arguments = (((state_12).context).expressions).collection_arguments, .collection_count = (((state_12).context).expressions).collection_count, .collection_first = (((state_12).context).expressions).collection_first, .collection_kinds = (((state_12).context).expressions).collection_kinds, .collection_targets = (((state_12).context).expressions).collection_targets, .conditional_conditions = (((state_12).context).expressions).conditional_conditions, .conditional_no = (((state_12).context).expressions).conditional_no, .conditional_yes = (((state_12).context).expressions).conditional_yes, .enumerations = (((state_12).context).expressions).enumerations, .errors = (((state_12).context).expressions).errors, .floats = (((state_12).context).expressions).floats, .index_targets = (((state_12).context).expressions).index_targets, .index_values = (((state_12).context).expressions).index_values, .integers = (((state_12).context).expressions).integers, .iteration_bodies = (((state_12).context).expressions).iteration_bodies, .iteration_condition_parameters = (((state_12).context).expressions).iteration_condition_parameters, .iteration_conditions = (((state_12).context).expressions).iteration_conditions, .iteration_initials = (((state_12).context).expressions).iteration_initials, .iteration_parameters = (((state_12).context).expressions).iteration_parameters, .iteration_postconditions = (((state_12).context).expressions).iteration_postconditions, .kinds = (((state_12).context).expressions).kinds, .lengths = (((state_12).context).expressions).lengths, .match_conditions = (((state_12).context).expressions).match_conditions, .match_count = (((state_12).context).expressions).match_count, .match_fallbacks = (((state_12).context).expressions).match_fallbacks, .match_first = (((state_12).context).expressions).match_first, .match_results = (((state_12).context).expressions).match_results, .match_subjects = (((state_12).context).expressions).match_subjects, .negative_integers = (((state_12).context).expressions).negative_integers, .object_count = (((state_12).context).expressions).object_count, .object_evaluation_count = (((state_12).context).expressions).object_evaluation_count, .object_evaluation_first = (((state_12).context).expressions).object_evaluation_first, .object_evaluation_values = (((state_12).context).expressions).object_evaluation_values, .object_field_indices = (((state_12).context).expressions).object_field_indices, .object_field_values = (((state_12).context).expressions).object_field_values, .object_first = (((state_12).context).expressions).object_first, .optional_values = (((state_12).context).expressions).optional_values, .parallel_count = (((state_12).context).expressions).parallel_count, .parallel_fields = (((state_12).context).expressions).parallel_fields, .parallel_first = (((state_12).context).expressions).parallel_first, .parallel_tasks = (((state_12).context).expressions).parallel_tasks, .payloads = (((state_12).context).expressions).payloads, .projection_indices = (((state_12).context).expressions).projection_indices, .projection_targets = (((state_12).context).expressions).projection_targets, .references = (((state_12).context).expressions).references, .scope_borrows = (((state_12).context).expressions).scope_borrows, .scope_count = (((state_12).context).expressions).scope_count, .scope_first = (((state_12).context).expressions).scope_first, .scope_results = (((state_12).context).expressions).scope_results, .scope_symbols = (((state_12).context).expressions).scope_symbols, .scope_values = (((state_12).context).expressions).scope_values, .sequence_count = (((state_12).context).expressions).sequence_count, .sequence_first = (((state_12).context).expressions).sequence_first, .sequence_items = (((state_12).context).expressions).sequence_items, .some = (((state_12).context).expressions).some, .span_end = (((state_12).context).expressions).span_end, .span_start = (((state_12).context).expressions).span_start, .stores = (((state_12).context).expressions).stores, .strings = (((state_12).context).expressions).strings, .task_bodies = (((state_12).context).expressions).task_bodies, .task_capture_count = (((state_12).context).expressions).task_capture_count, .task_capture_first = (((state_12).context).expressions).task_capture_first, .task_captures = (((state_12).context).expressions).task_captures, .transform_bodies = (((state_12).context).expressions).transform_bodies, .transform_count = (((state_12).context).expressions).transform_count, .transform_first = (((state_12).context).expressions).transform_first, .transform_initials = (((state_12).context).expressions).transform_initials, .transform_kinds = (((state_12).context).expressions).transform_kinds, .transform_parameters = (((state_12).context).expressions).transform_parameters, .transform_targets = (((state_12).context).expressions).transform_targets, .types = (((state_12).context).expressions).types, .unary_operands = (((state_12).context).expressions).unary_operands, .unary_operators = (((state_12).context).expressions).unary_operators, .update_indices = (((state_12).context).expressions).update_indices, .update_targets = (((state_12).context).expressions).update_targets, .update_values = (((state_12).context).expressions).update_values, };

                        break :block_47 @as(*const (zx_abi).zx_type_34, operand_46);
                    }), .functions = (if (((((state_12).context).functions).zx_origin != null)) (((state_12).context).functions).zx_origin.? else block_49: {
                        const operand_48 = (try (allocator).create((zx_abi).zx_type_41));

                        (operand_48).* = (zx_abi).zx_type_41{ .input_types = (((state_12).context).functions).input_types, .output_types = (((state_12).context).functions).output_types, .stores = (((state_12).context).functions).stores, };

                        break :block_49 @as(*const (zx_abi).zx_type_41, operand_48);
                    }), .index = ((state_12).context).index, .orchestration = ((state_12).context).orchestration, .stores = ((state_12).context).stores, .symbols = (if (((((state_12).context).symbols).zx_origin != null)) (((state_12).context).symbols).zx_origin.? else block_51: {
                        const operand_50 = (try (allocator).create((zx_abi).zx_type_39));

                        (operand_50).* = (zx_abi).zx_type_39{ .names = (((state_12).context).symbols).names, .ownership = (((state_12).context).symbols).ownership, .span_end = (((state_12).context).symbols).span_end, .span_start = (((state_12).context).symbols).span_start, .types = (((state_12).context).symbols).types, };

                        break :block_51 @as(*const (zx_abi).zx_type_39, operand_50);
                    }), .table = (if (((((state_12).context).table).zx_origin != null)) (((state_12).context).table).zx_origin.? else block_53: {
                        const operand_52 = (try (allocator).create((zx_abi).zx_type_20));

                        (operand_52).* = (zx_abi).zx_type_20{ .children = (((state_12).context).table).children, .field_names = (((state_12).context).table).field_names, .field_types = (((state_12).context).table).field_types, .first = (((state_12).context).table).first, .kinds = (((state_12).context).table).kinds, .labels = (((state_12).context).table).labels, .names = (((state_12).context).table).names, .second = (((state_12).context).table).second, };

                        break :block_53 @as(*const (zx_abi).zx_type_20, operand_52);
                    }), };

                    break :block_55 @as(*const (zx_abi).zx_type_42, operand_54);
                }), .count = (state_12).count, .element = (state_12).element, .first = (state_12).first, .index = (state_12).index, .operation = (state_12).operation, .source = (state_12).source, .valid = (state_12).valid, };
            });
        };
    };

    if ((!((&value_20)).valid)) {
        return false;
    }

    const value_21: u32 = block_11: {
        const operand_9 = ((&value_3)).children;
        const operand_10 = (value_8 + @as(u64, 1));

        if ((operand_10 >= (operand_9).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_11 (operand_9)[@intCast(operand_10)];
    };

    return block_8: {
        const operand_1 = value_9;

        break :block_8 (if ((operand_1 == @as((zx_abi).zx_type_12, .Pop))) (((try function_9(allocator, block_4: {
            const operand_2 = ((&value_3)).kinds;
            const operand_3 = (try function_0(allocator, value_21));

            if ((operand_3 >= (operand_2).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_4 (operand_2)[@intCast(operand_3)];
        })) == @as((zx_abi).zx_type_16, .Optional)) and (block_7: {
            const operand_5 = ((&value_3)).first;
            const operand_6 = (try function_0(allocator, value_21));

            if ((operand_6 >= (operand_5).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_7 (operand_5)[@intCast(operand_6)];
        } == value_12)) else (if ((operand_1 == @as((zx_abi).zx_type_12, .Splice))) (value_21 == value_6) else (if ((operand_1 == @as((zx_abi).zx_type_12, .Sort))) ((value_21 == @as(u32, 0)) and (((try function_12(allocator, value_12)) != @as((zx_abi).zx_type_44, .Other)) or (value_12 == @as(u32, 10)))) else (value_21 == @as(u32, 0)))));
    };
}

fn function_21(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_48) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_4: (zx_abi).zx_type_48 = block_21: {
        const operand_8 = block_7: {
            const operand_5 = (in).table;
            const operand_6 = (in).type_id;

            break :block_7 (zx_abi).zx_type_48{ .table = operand_5, .type_id = operand_6, };
        };

        var state_4: (zx_abi).value_zx_type_48_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922 = (zx_abi).value_zx_type_48_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922{ .table = (zx_abi).value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_8).table).children, .field_names = ((operand_8).table).field_names, .field_types = ((operand_8).table).field_types, .first = ((operand_8).table).first, .kinds = ((operand_8).table).kinds, .labels = ((operand_8).table).labels, .names = ((operand_8).table).names, .second = ((operand_8).table).second, .zx_origin = (operand_8).table, }, .type_id = (operand_8).type_id, .zx_origin = (&operand_8), };

        while (((try function_9(allocator, block_11: {
            const operand_9 = ((state_4).table).kinds;
            const operand_10 = (try function_0(allocator, (state_4).type_id));

            if ((operand_10 >= (operand_9).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_11 (operand_9)[@intCast(operand_10)];
        })) == @as((zx_abi).zx_type_16, .Optional))) {
            state_4 = block_16: {
                const value_3: (zx_abi).value_zx_type_48_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922 = block_15: {
                    break :block_15 @as((zx_abi).value_zx_type_48_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922, (zx_abi).value_zx_type_48_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922{ .table = (state_4).table, .type_id = block_14: {
                        const operand_12 = ((state_4).table).first;
                        const operand_13 = (try function_0(allocator, (state_4).type_id));

                        if ((operand_13 >= (operand_12).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_14 (operand_12)[@intCast(operand_13)];
                    }, });
                };

                break :block_16 value_3;
            };
        }

        break :block_21 block_20: {
            break :block_20 (if (((state_4).zx_origin != null)) ((state_4).zx_origin.?).* else block_19: {
                break :block_19 (zx_abi).zx_type_48{ .table = (if ((((state_4).table).zx_origin != null)) ((state_4).table).zx_origin.? else block_18: {
                    const operand_17 = (try (allocator).create((zx_abi).zx_type_20));

                    (operand_17).* = (zx_abi).zx_type_20{ .children = ((state_4).table).children, .field_names = ((state_4).table).field_names, .field_types = ((state_4).table).field_types, .first = ((state_4).table).first, .kinds = ((state_4).table).kinds, .labels = ((state_4).table).labels, .names = ((state_4).table).names, .second = ((state_4).table).second, };

                    break :block_18 @as(*const (zx_abi).zx_type_20, operand_17);
                }), .type_id = (state_4).type_id, };
            });
        };
    };
    const value_5: (zx_abi).zx_type_16 = (try function_9(allocator, block_3: {
        const operand_1 = ((in).table).kinds;
        const operand_2 = (try function_0(allocator, ((&value_4)).type_id));

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    }));

    return ((((value_5 == @as((zx_abi).zx_type_16, .Scalar)) and (((&value_4)).type_id != @as(u32, 0))) or (value_5 == @as((zx_abi).zx_type_16, .Enumeration))) or (value_5 == @as((zx_abi).zx_type_16, .ErrorSet)));
}

fn function_22(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;

    if (((in).kind == @as((zx_abi).zx_type_11, .Unary))) {
        const value_3: (zx_abi).zx_type_44 = (try function_12(allocator, (in).type_id));

        return (block_42: {
            const operand_34 = (&value_2);
            const operand_35 = ((&value_1)).index;
            const operand_39 = block_38: {
                const operand_36 = ((&value_2)).unary_operands;
                const operand_37 = (in).payload;

                if ((operand_37 >= (operand_36).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_38 (operand_36)[@intCast(operand_37)];
            };
            const operand_40 = (in).type_id;
            const operand_41 = (zx_abi).zx_type_35{ .expressions = operand_34, .index = operand_35, .id = operand_39, .type_id = operand_40, };

            break :block_42 (try function_10(allocator, (&operand_41)));
        } and (if ((block_45: {
            const operand_43 = ((&value_2)).unary_operators;
            const operand_44 = (in).payload;

            if ((operand_44 >= (operand_43).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_45 (operand_43)[@intCast(operand_44)];
        } == @as((zx_abi).zx_type_14, .Not))) ((in).type_id == @as(u32, 1)) else ((value_3 == @as((zx_abi).zx_type_44, .Signed)) or (value_3 == @as((zx_abi).zx_type_44, .Float)))));
    }

    const value_4: u64 = (try function_0(allocator, block_33: {
        const operand_31 = ((&value_2)).binary_left;
        const operand_32 = (in).payload;

        if ((operand_32 >= (operand_31).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_33 (operand_31)[@intCast(operand_32)];
    }));
    const value_5: u64 = (try function_0(allocator, block_30: {
        const operand_28 = ((&value_2)).binary_right;
        const operand_29 = (in).payload;

        if ((operand_29 >= (operand_28).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_30 (operand_28)[@intCast(operand_29)];
    }));

    if (((value_4 >= ((&value_1)).index) or (value_5 >= ((&value_1)).index))) {
        return false;
    }

    const value_6: u32 = block_27: {
        const operand_25 = ((&value_2)).types;
        const operand_26 = value_4;

        if ((operand_26 >= (operand_25).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_27 (operand_25)[@intCast(operand_26)];
    };
    const value_7: u32 = block_24: {
        const operand_22 = ((&value_2)).types;
        const operand_23 = value_5;

        if ((operand_23 >= (operand_22).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_24 (operand_22)[@intCast(operand_23)];
    };
    const value_8: (zx_abi).zx_type_16 = (try function_9(allocator, block_21: {
        const operand_19 = (((&value_1)).table).kinds;
        const operand_20 = (try function_0(allocator, value_6));

        if ((operand_20 >= (operand_19).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_21 (operand_19)[@intCast(operand_20)];
    }));
    const value_9: (zx_abi).zx_type_15 = block_18: {
        const operand_16 = ((&value_2)).binary_operators;
        const operand_17 = (in).payload;

        if ((operand_17 >= (operand_16).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_18 (operand_16)[@intCast(operand_17)];
    };

    if ((value_9 == @as((zx_abi).zx_type_15, .Coalesce))) {
        return (((value_8 == @as((zx_abi).zx_type_16, .Optional)) and (block_15: {
            const operand_13 = (((&value_1)).table).first;
            const operand_14 = (try function_0(allocator, value_6));

            if ((operand_14 >= (operand_13).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_15 (operand_13)[@intCast(operand_14)];
        } == value_7)) and ((in).type_id == value_7));
    }

    if ((value_6 != value_7)) {
        return false;
    }

    const value_10: bool = ((value_9 == @as((zx_abi).zx_type_15, .Equal)) or (value_9 == @as((zx_abi).zx_type_15, .NotEqual)));

    if (((((value_10 and (value_8 == @as((zx_abi).zx_type_16, .Optional))) and (!block_6: {
        const operand_3 = ((&value_1)).table;
        const operand_4 = value_6;
        const operand_5 = (zx_abi).zx_type_48{ .table = operand_3, .type_id = operand_4, };

        break :block_6 (try function_21(allocator, (&operand_5)));
    })) and (block_9: {
        const operand_7 = ((&value_2)).kinds;
        const operand_8 = value_4;

        if ((operand_8 >= (operand_7).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_9 (operand_7)[@intCast(operand_8)];
    } != @as((zx_abi).zx_type_11, .None))) and (block_12: {
        const operand_10 = ((&value_2)).kinds;
        const operand_11 = value_5;

        if ((operand_11 >= (operand_10).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_12 (operand_10)[@intCast(operand_11)];
    } != @as((zx_abi).zx_type_11, .None)))) {
        return false;
    }

    const value_11: bool = ((try function_12(allocator, value_6)) != @as((zx_abi).zx_type_44, .Other));

    if (value_10) {
        return ((((((value_11 or (value_6 == @as(u32, 1))) or (value_6 == @as(u32, 10))) or (value_8 == @as((zx_abi).zx_type_16, .Enumeration))) or (value_8 == @as((zx_abi).zx_type_16, .ErrorSet))) or (value_8 == @as((zx_abi).zx_type_16, .Optional))) and ((in).type_id == @as(u32, 1)));
    }

    return block_2: {
        const operand_1 = value_9;

        break :block_2 (if ((operand_1 == @as((zx_abi).zx_type_15, .LogicalAnd))) ((value_6 == @as(u32, 1)) and ((in).type_id == @as(u32, 1))) else (if ((operand_1 == @as((zx_abi).zx_type_15, .LogicalOr))) ((value_6 == @as(u32, 1)) and ((in).type_id == @as(u32, 1))) else (if ((operand_1 == @as((zx_abi).zx_type_15, .Less))) (value_11 and ((in).type_id == @as(u32, 1))) else (if ((operand_1 == @as((zx_abi).zx_type_15, .LessEqual))) (value_11 and ((in).type_id == @as(u32, 1))) else (if ((operand_1 == @as((zx_abi).zx_type_15, .Greater))) (value_11 and ((in).type_id == @as(u32, 1))) else (if ((operand_1 == @as((zx_abi).zx_type_15, .GreaterEqual))) (value_11 and ((in).type_id == @as(u32, 1))) else (value_11 and ((in).type_id == value_6))))))));
    };
}

fn function_23(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if ((((in).target != @as((zx_abi).zx_type_16, .Object)) and ((in).type_id != @as(u32, 0)))) {
        return false;
    }

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;
    const value_33: (zx_abi).zx_type_56 = block_122: {
        const operand_18 = block_17: {
            const operand_5 = in;
            const operand_6 = (try function_0(allocator, block_9: {
                const operand_7 = ((&value_2)).parallel_first;
                const operand_8 = (in).payload;

                if ((operand_8 >= (operand_7).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_9 (operand_7)[@intCast(operand_8)];
            }));
            const operand_10 = (try function_0(allocator, block_13: {
                const operand_11 = ((&value_2)).parallel_count;
                const operand_12 = (in).payload;

                if ((operand_12 >= (operand_11).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_13 (operand_11)[@intCast(operand_12)];
            }));
            const operand_14 = @as(u64, 0);
            const operand_15 = @as(u64, 0);
            const operand_16 = true;

            break :block_17 (zx_abi).zx_type_56{ .check = operand_5, .first = operand_6, .count = operand_10, .index = operand_14, .fields = operand_15, .valid = operand_16, };
        };

        var state_4: (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945 = (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945{ .check = (zx_abi).value_zx_type_43_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159{ .expressions = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = ((((operand_18).check).context).expressions).awaits, .binary_left = ((((operand_18).check).context).expressions).binary_left, .binary_operators = ((((operand_18).check).context).expressions).binary_operators, .binary_right = ((((operand_18).check).context).expressions).binary_right, .booleans = ((((operand_18).check).context).expressions).booleans, .call_arguments = ((((operand_18).check).context).expressions).call_arguments, .call_functions = ((((operand_18).check).context).expressions).call_functions, .call_store_count = ((((operand_18).check).context).expressions).call_store_count, .call_store_first = ((((operand_18).check).context).expressions).call_store_first, .call_stores = ((((operand_18).check).context).expressions).call_stores, .cancellations = ((((operand_18).check).context).expressions).cancellations, .captures = ((((operand_18).check).context).expressions).captures, .collection_arguments = ((((operand_18).check).context).expressions).collection_arguments, .collection_count = ((((operand_18).check).context).expressions).collection_count, .collection_first = ((((operand_18).check).context).expressions).collection_first, .collection_kinds = ((((operand_18).check).context).expressions).collection_kinds, .collection_targets = ((((operand_18).check).context).expressions).collection_targets, .conditional_conditions = ((((operand_18).check).context).expressions).conditional_conditions, .conditional_no = ((((operand_18).check).context).expressions).conditional_no, .conditional_yes = ((((operand_18).check).context).expressions).conditional_yes, .enumerations = ((((operand_18).check).context).expressions).enumerations, .errors = ((((operand_18).check).context).expressions).errors, .floats = ((((operand_18).check).context).expressions).floats, .index_targets = ((((operand_18).check).context).expressions).index_targets, .index_values = ((((operand_18).check).context).expressions).index_values, .integers = ((((operand_18).check).context).expressions).integers, .iteration_bodies = ((((operand_18).check).context).expressions).iteration_bodies, .iteration_condition_parameters = ((((operand_18).check).context).expressions).iteration_condition_parameters, .iteration_conditions = ((((operand_18).check).context).expressions).iteration_conditions, .iteration_initials = ((((operand_18).check).context).expressions).iteration_initials, .iteration_parameters = ((((operand_18).check).context).expressions).iteration_parameters, .iteration_postconditions = ((((operand_18).check).context).expressions).iteration_postconditions, .kinds = ((((operand_18).check).context).expressions).kinds, .lengths = ((((operand_18).check).context).expressions).lengths, .match_conditions = ((((operand_18).check).context).expressions).match_conditions, .match_count = ((((operand_18).check).context).expressions).match_count, .match_fallbacks = ((((operand_18).check).context).expressions).match_fallbacks, .match_first = ((((operand_18).check).context).expressions).match_first, .match_results = ((((operand_18).check).context).expressions).match_results, .match_subjects = ((((operand_18).check).context).expressions).match_subjects, .negative_integers = ((((operand_18).check).context).expressions).negative_integers, .object_count = ((((operand_18).check).context).expressions).object_count, .object_evaluation_count = ((((operand_18).check).context).expressions).object_evaluation_count, .object_evaluation_first = ((((operand_18).check).context).expressions).object_evaluation_first, .object_evaluation_values = ((((operand_18).check).context).expressions).object_evaluation_values, .object_field_indices = ((((operand_18).check).context).expressions).object_field_indices, .object_field_values = ((((operand_18).check).context).expressions).object_field_values, .object_first = ((((operand_18).check).context).expressions).object_first, .optional_values = ((((operand_18).check).context).expressions).optional_values, .parallel_count = ((((operand_18).check).context).expressions).parallel_count, .parallel_fields = ((((operand_18).check).context).expressions).parallel_fields, .parallel_first = ((((operand_18).check).context).expressions).parallel_first, .parallel_tasks = ((((operand_18).check).context).expressions).parallel_tasks, .payloads = ((((operand_18).check).context).expressions).payloads, .projection_indices = ((((operand_18).check).context).expressions).projection_indices, .projection_targets = ((((operand_18).check).context).expressions).projection_targets, .references = ((((operand_18).check).context).expressions).references, .scope_borrows = ((((operand_18).check).context).expressions).scope_borrows, .scope_count = ((((operand_18).check).context).expressions).scope_count, .scope_first = ((((operand_18).check).context).expressions).scope_first, .scope_results = ((((operand_18).check).context).expressions).scope_results, .scope_symbols = ((((operand_18).check).context).expressions).scope_symbols, .scope_values = ((((operand_18).check).context).expressions).scope_values, .sequence_count = ((((operand_18).check).context).expressions).sequence_count, .sequence_first = ((((operand_18).check).context).expressions).sequence_first, .sequence_items = ((((operand_18).check).context).expressions).sequence_items, .some = ((((operand_18).check).context).expressions).some, .span_end = ((((operand_18).check).context).expressions).span_end, .span_start = ((((operand_18).check).context).expressions).span_start, .stores = ((((operand_18).check).context).expressions).stores, .strings = ((((operand_18).check).context).expressions).strings, .task_bodies = ((((operand_18).check).context).expressions).task_bodies, .task_capture_count = ((((operand_18).check).context).expressions).task_capture_count, .task_capture_first = ((((operand_18).check).context).expressions).task_capture_first, .task_captures = ((((operand_18).check).context).expressions).task_captures, .transform_bodies = ((((operand_18).check).context).expressions).transform_bodies, .transform_count = ((((operand_18).check).context).expressions).transform_count, .transform_first = ((((operand_18).check).context).expressions).transform_first, .transform_initials = ((((operand_18).check).context).expressions).transform_initials, .transform_kinds = ((((operand_18).check).context).expressions).transform_kinds, .transform_parameters = ((((operand_18).check).context).expressions).transform_parameters, .transform_targets = ((((operand_18).check).context).expressions).transform_targets, .types = ((((operand_18).check).context).expressions).types, .unary_operands = ((((operand_18).check).context).expressions).unary_operands, .unary_operators = ((((operand_18).check).context).expressions).unary_operators, .update_indices = ((((operand_18).check).context).expressions).update_indices, .update_targets = ((((operand_18).check).context).expressions).update_targets, .update_values = ((((operand_18).check).context).expressions).update_values, .zx_origin = (((operand_18).check).context).expressions, }, .functions = (zx_abi).value_zx_type_41_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .input_types = ((((operand_18).check).context).functions).input_types, .output_types = ((((operand_18).check).context).functions).output_types, .stores = ((((operand_18).check).context).functions).stores, .zx_origin = (((operand_18).check).context).functions, }, .index = (((operand_18).check).context).index, .orchestration = (((operand_18).check).context).orchestration, .stores = (((operand_18).check).context).stores, .symbols = (zx_abi).value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_18).check).context).symbols).names, .ownership = ((((operand_18).check).context).symbols).ownership, .span_end = ((((operand_18).check).context).symbols).span_end, .span_start = ((((operand_18).check).context).symbols).span_start, .types = ((((operand_18).check).context).symbols).types, .zx_origin = (((operand_18).check).context).symbols, }, .table = (zx_abi).value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((((operand_18).check).context).table).children, .field_names = ((((operand_18).check).context).table).field_names, .field_types = ((((operand_18).check).context).table).field_types, .first = ((((operand_18).check).context).table).first, .kinds = ((((operand_18).check).context).table).kinds, .labels = ((((operand_18).check).context).table).labels, .names = ((((operand_18).check).context).table).names, .second = ((((operand_18).check).context).table).second, .zx_origin = (((operand_18).check).context).table, }, .zx_origin = ((operand_18).check).context, }, .kind = ((operand_18).check).kind, .payload = ((operand_18).check).payload, .target = ((operand_18).check).target, .type_id = ((operand_18).check).type_id, .zx_origin = (operand_18).check, }, .count = (operand_18).count, .fields = (operand_18).fields, .first = (operand_18).first, .index = (operand_18).index, .valid = (operand_18).valid, .zx_origin = (&operand_18), };

        while (((state_4).valid and ((state_4).index < (state_4).count))) {
            state_4 = block_107: {
                const value_5: (zx_abi).value_zx_type_43_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = (state_4).check;
                const value_6: (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159 = (value_5).context;
                const value_7: (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788 = (value_6).expressions;
                const value_8: (zx_abi).value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = (value_6).table;
                const value_9: u64 = ((state_4).first + (state_4).index);
                const value_10: u32 = block_106: {
                    const operand_104 = (value_7).parallel_tasks;
                    const operand_105 = block_103: {
                        break :block_103 value_9;
                    };

                    if ((operand_105 >= (operand_104).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_106 (operand_104)[@intCast(operand_105)];
                };
                const value_11: u64 = (try function_0(allocator, block_102: {
                    break :block_102 value_10;
                }));
                const value_30: (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945 = (if ((((block_21: {
                    break :block_21 value_11;
                } >= (value_6).index) or (block_25: {
                    const operand_23 = (value_7).kinds;
                    const operand_24 = block_22: {
                        break :block_22 value_11;
                    };

                    if ((operand_24 >= (operand_23).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_25 (operand_23)[@intCast(operand_24)];
                } != @as((zx_abi).zx_type_11, .Task))) or ((try function_9(allocator, block_32: {
                    const operand_30 = (value_8).kinds;
                    const operand_31 = (try function_0(allocator, block_29: {
                        const operand_27 = (value_7).types;
                        const operand_28 = block_26: {
                            break :block_26 value_11;
                        };

                        if ((operand_28 >= (operand_27).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_29 (operand_27)[@intCast(operand_28)];
                    }));

                    if ((operand_31 >= (operand_30).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_32 (operand_30)[@intCast(operand_31)];
                })) != @as((zx_abi).zx_type_16, .Task)))) block_34: {
                    const value_12: (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945 = block_33: {
                        break :block_33 @as((zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945, (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945{ .check = (state_4).check, .count = (state_4).count, .fields = (state_4).fields, .first = (state_4).first, .index = (state_4).index, .valid = false, });
                    };

                    break :block_34 value_12;
                } else block_101: {
                    const value_13: u32 = block_100: {
                        const operand_98 = (value_8).first;
                        const operand_99 = (try function_0(allocator, block_97: {
                            const operand_95 = (value_7).types;
                            const operand_96 = block_94: {
                                break :block_94 value_11;
                            };

                            if ((operand_96 >= (operand_95).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_97 (operand_95)[@intCast(operand_96)];
                        }));

                        if ((operand_99 >= (operand_98).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_100 (operand_98)[@intCast(operand_99)];
                    };
                    const value_14: ?u32 = block_93: {
                        const operand_91 = (value_7).parallel_fields;
                        const operand_92 = block_90: {
                            break :block_90 value_9;
                        };

                        if ((operand_92 >= (operand_91).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_93 (operand_91)[@intCast(operand_92)];
                    };
                    const value_15: u64 = (try function_0(allocator, (value_5).type_id));
                    const value_21: (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945 = (if ((block_67: {
                        break :block_67 value_14;
                    } != null)) block_86: {
                        const value_16: u64 = (try function_0(allocator, block_85: {
                            break :block_85 value_14;
                        }.?));
                        const value_17: (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945 = block_84: {
                            break :block_84 @as((zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945, (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945{ .check = (state_4).check, .count = (state_4).count, .fields = (state_4).fields, .first = (state_4).first, .index = (state_4).index, .valid = ((((value_5).target == @as((zx_abi).zx_type_16, .Object)) and (block_70: {
                                break :block_70 value_16;
                            } < (try function_0(allocator, block_74: {
                                const operand_72 = (value_8).second;
                                const operand_73 = block_71: {
                                    break :block_71 value_15;
                                };

                                if ((operand_73 >= (operand_72).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_74 (operand_72)[@intCast(operand_73)];
                            })))) and (block_82: {
                                const operand_80 = (value_8).field_types;
                                const operand_81 = ((try function_0(allocator, block_78: {
                                    const operand_76 = (value_8).first;
                                    const operand_77 = block_75: {
                                        break :block_75 value_15;
                                    };

                                    if ((operand_77 >= (operand_76).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_78 (operand_76)[@intCast(operand_77)];
                                })) + block_79: {
                                    break :block_79 value_16;
                                });

                                if ((operand_81 >= (operand_80).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_82 (operand_80)[@intCast(operand_81)];
                            } == block_83: {
                                break :block_83 value_13;
                            })), });
                        };
                        const value_18: u64 = (value_17).fields;
                        const value_19: (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945 = block_69: {
                            break :block_69 @as((zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945, (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945{ .check = (value_17).check, .count = (value_17).count, .fields = (block_68: {
                                break :block_68 value_18;
                            } + @as(u64, 1)), .first = (value_17).first, .index = (value_17).index, .valid = (value_17).valid, });
                        };

                        break :block_86 value_19;
                    } else block_89: {
                        const value_20: (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945 = block_88: {
                            break :block_88 @as((zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945, (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945{ .check = (state_4).check, .count = (state_4).count, .fields = (state_4).fields, .first = (state_4).first, .index = (state_4).index, .valid = (block_87: {
                                break :block_87 value_13;
                            } == @as(u32, 0)), });
                        };

                        break :block_89 value_20;
                    });
                    const value_28: (zx_abi).value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077 = block_66: {
                        const operand_48 = block_47: {
                            const operand_37 = (value_7).parallel_tasks;
                            const operand_38 = (value_7).parallel_fields;
                            const operand_39 = (value_21).first;
                            const operand_40 = (value_21).index;
                            const operand_41 = block_42: {
                                break :block_42 value_10;
                            };
                            const operand_43 = block_44: {
                                break :block_44 value_14;
                            };
                            const operand_45 = @as(u64, 0);
                            const operand_46 = false;

                            break :block_47 @as((zx_abi).value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077, (zx_abi).value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077{ .tasks = operand_37, .fields = operand_38, .first = operand_39, .limit = operand_40, .task = operand_41, .field = operand_43, .index = operand_45, .found = operand_46, });
                        };

                        var state_36: (zx_abi).value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077 = operand_48;

                        var state_changed_49 = false;

                        while (((!(state_36).found) and ((state_36).index < (state_36).limit))) {
                            state_36 = block_64: {
                                const value_24: u64 = ((state_36).first + (state_36).index);
                                const value_25: (zx_abi).value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077 = block_63: {
                                    break :block_63 @as((zx_abi).value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077, (zx_abi).value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077{ .field = (state_36).field, .fields = (state_36).fields, .first = (state_36).first, .found = ((block_55: {
                                        const operand_53 = (state_36).tasks;
                                        const operand_54 = block_52: {
                                            break :block_52 value_24;
                                        };

                                        if ((operand_54 >= (operand_53).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_55 (operand_53)[@intCast(operand_54)];
                                    } == (state_36).task) or (((state_36).field != null) and block_62: {
                                        const operand_60 = block_59: {
                                            const operand_57 = (state_36).fields;
                                            const operand_58 = block_56: {
                                                break :block_56 value_24;
                                            };

                                            if ((operand_58 >= (operand_57).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            break :block_59 (operand_57)[@intCast(operand_58)];
                                        };
                                        const operand_61 = (state_36).field;

                                        break :block_62 (if (((operand_60 == null) or (operand_61 == null))) ((operand_60 == null) and (operand_61 == null)) else (operand_60.? == operand_61.?));
                                    })), .index = (state_36).index, .limit = (state_36).limit, .task = (state_36).task, .tasks = (state_36).tasks, });
                                };
                                const value_26: u64 = (value_25).index;
                                const value_27: (zx_abi).value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077 = block_51: {
                                    break :block_51 @as((zx_abi).value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077, (zx_abi).value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077{ .field = (value_25).field, .fields = (value_25).fields, .first = (value_25).first, .found = (value_25).found, .index = (block_50: {
                                        break :block_50 value_26;
                                    } + @as(u64, 1)), .limit = (value_25).limit, .task = (value_25).task, .tasks = (value_25).tasks, });
                                };

                                break :block_64 value_27;
                            };

                            state_changed_49 = true;
                        }

                        break :block_66 (if (state_changed_49) state_36 else operand_48);
                    };
                    const value_29: (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945 = block_35: {
                        break :block_35 @as((zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945, (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945{ .check = (value_21).check, .count = (value_21).count, .fields = (value_21).fields, .first = (value_21).first, .index = (value_21).index, .valid = ((value_21).valid and (!(value_28).found)), });
                    };

                    break :block_101 value_29;
                });
                const value_31: u64 = (value_30).index;
                const value_32: (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945 = block_20: {
                    break :block_20 @as((zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945, (zx_abi).value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945{ .check = (value_30).check, .count = (value_30).count, .fields = (value_30).fields, .first = (value_30).first, .index = (block_19: {
                        break :block_19 value_31;
                    } + @as(u64, 1)), .valid = (value_30).valid, });
                };

                break :block_107 value_32;
            };
        }

        break :block_122 block_121: {
            break :block_121 (if (((state_4).zx_origin != null)) ((state_4).zx_origin.?).* else block_120: {
                break :block_120 (zx_abi).zx_type_56{ .check = (if ((((state_4).check).zx_origin != null)) ((state_4).check).zx_origin.? else block_119: {
                    const operand_118 = (try (allocator).create((zx_abi).zx_type_43));

                    (operand_118).* = (zx_abi).zx_type_43{ .context = (if (((((state_4).check).context).zx_origin != null)) (((state_4).check).context).zx_origin.? else block_117: {
                        const operand_116 = (try (allocator).create((zx_abi).zx_type_42));

                        (operand_116).* = (zx_abi).zx_type_42{ .expressions = (if ((((((state_4).check).context).expressions).zx_origin != null)) ((((state_4).check).context).expressions).zx_origin.? else block_109: {
                            const operand_108 = (try (allocator).create((zx_abi).zx_type_34));

                            (operand_108).* = (zx_abi).zx_type_34{ .awaits = ((((state_4).check).context).expressions).awaits, .binary_left = ((((state_4).check).context).expressions).binary_left, .binary_operators = ((((state_4).check).context).expressions).binary_operators, .binary_right = ((((state_4).check).context).expressions).binary_right, .booleans = ((((state_4).check).context).expressions).booleans, .call_arguments = ((((state_4).check).context).expressions).call_arguments, .call_functions = ((((state_4).check).context).expressions).call_functions, .call_store_count = ((((state_4).check).context).expressions).call_store_count, .call_store_first = ((((state_4).check).context).expressions).call_store_first, .call_stores = ((((state_4).check).context).expressions).call_stores, .cancellations = ((((state_4).check).context).expressions).cancellations, .captures = ((((state_4).check).context).expressions).captures, .collection_arguments = ((((state_4).check).context).expressions).collection_arguments, .collection_count = ((((state_4).check).context).expressions).collection_count, .collection_first = ((((state_4).check).context).expressions).collection_first, .collection_kinds = ((((state_4).check).context).expressions).collection_kinds, .collection_targets = ((((state_4).check).context).expressions).collection_targets, .conditional_conditions = ((((state_4).check).context).expressions).conditional_conditions, .conditional_no = ((((state_4).check).context).expressions).conditional_no, .conditional_yes = ((((state_4).check).context).expressions).conditional_yes, .enumerations = ((((state_4).check).context).expressions).enumerations, .errors = ((((state_4).check).context).expressions).errors, .floats = ((((state_4).check).context).expressions).floats, .index_targets = ((((state_4).check).context).expressions).index_targets, .index_values = ((((state_4).check).context).expressions).index_values, .integers = ((((state_4).check).context).expressions).integers, .iteration_bodies = ((((state_4).check).context).expressions).iteration_bodies, .iteration_condition_parameters = ((((state_4).check).context).expressions).iteration_condition_parameters, .iteration_conditions = ((((state_4).check).context).expressions).iteration_conditions, .iteration_initials = ((((state_4).check).context).expressions).iteration_initials, .iteration_parameters = ((((state_4).check).context).expressions).iteration_parameters, .iteration_postconditions = ((((state_4).check).context).expressions).iteration_postconditions, .kinds = ((((state_4).check).context).expressions).kinds, .lengths = ((((state_4).check).context).expressions).lengths, .match_conditions = ((((state_4).check).context).expressions).match_conditions, .match_count = ((((state_4).check).context).expressions).match_count, .match_fallbacks = ((((state_4).check).context).expressions).match_fallbacks, .match_first = ((((state_4).check).context).expressions).match_first, .match_results = ((((state_4).check).context).expressions).match_results, .match_subjects = ((((state_4).check).context).expressions).match_subjects, .negative_integers = ((((state_4).check).context).expressions).negative_integers, .object_count = ((((state_4).check).context).expressions).object_count, .object_evaluation_count = ((((state_4).check).context).expressions).object_evaluation_count, .object_evaluation_first = ((((state_4).check).context).expressions).object_evaluation_first, .object_evaluation_values = ((((state_4).check).context).expressions).object_evaluation_values, .object_field_indices = ((((state_4).check).context).expressions).object_field_indices, .object_field_values = ((((state_4).check).context).expressions).object_field_values, .object_first = ((((state_4).check).context).expressions).object_first, .optional_values = ((((state_4).check).context).expressions).optional_values, .parallel_count = ((((state_4).check).context).expressions).parallel_count, .parallel_fields = ((((state_4).check).context).expressions).parallel_fields, .parallel_first = ((((state_4).check).context).expressions).parallel_first, .parallel_tasks = ((((state_4).check).context).expressions).parallel_tasks, .payloads = ((((state_4).check).context).expressions).payloads, .projection_indices = ((((state_4).check).context).expressions).projection_indices, .projection_targets = ((((state_4).check).context).expressions).projection_targets, .references = ((((state_4).check).context).expressions).references, .scope_borrows = ((((state_4).check).context).expressions).scope_borrows, .scope_count = ((((state_4).check).context).expressions).scope_count, .scope_first = ((((state_4).check).context).expressions).scope_first, .scope_results = ((((state_4).check).context).expressions).scope_results, .scope_symbols = ((((state_4).check).context).expressions).scope_symbols, .scope_values = ((((state_4).check).context).expressions).scope_values, .sequence_count = ((((state_4).check).context).expressions).sequence_count, .sequence_first = ((((state_4).check).context).expressions).sequence_first, .sequence_items = ((((state_4).check).context).expressions).sequence_items, .some = ((((state_4).check).context).expressions).some, .span_end = ((((state_4).check).context).expressions).span_end, .span_start = ((((state_4).check).context).expressions).span_start, .stores = ((((state_4).check).context).expressions).stores, .strings = ((((state_4).check).context).expressions).strings, .task_bodies = ((((state_4).check).context).expressions).task_bodies, .task_capture_count = ((((state_4).check).context).expressions).task_capture_count, .task_capture_first = ((((state_4).check).context).expressions).task_capture_first, .task_captures = ((((state_4).check).context).expressions).task_captures, .transform_bodies = ((((state_4).check).context).expressions).transform_bodies, .transform_count = ((((state_4).check).context).expressions).transform_count, .transform_first = ((((state_4).check).context).expressions).transform_first, .transform_initials = ((((state_4).check).context).expressions).transform_initials, .transform_kinds = ((((state_4).check).context).expressions).transform_kinds, .transform_parameters = ((((state_4).check).context).expressions).transform_parameters, .transform_targets = ((((state_4).check).context).expressions).transform_targets, .types = ((((state_4).check).context).expressions).types, .unary_operands = ((((state_4).check).context).expressions).unary_operands, .unary_operators = ((((state_4).check).context).expressions).unary_operators, .update_indices = ((((state_4).check).context).expressions).update_indices, .update_targets = ((((state_4).check).context).expressions).update_targets, .update_values = ((((state_4).check).context).expressions).update_values, };

                            break :block_109 @as(*const (zx_abi).zx_type_34, operand_108);
                        }), .functions = (if ((((((state_4).check).context).functions).zx_origin != null)) ((((state_4).check).context).functions).zx_origin.? else block_111: {
                            const operand_110 = (try (allocator).create((zx_abi).zx_type_41));

                            (operand_110).* = (zx_abi).zx_type_41{ .input_types = ((((state_4).check).context).functions).input_types, .output_types = ((((state_4).check).context).functions).output_types, .stores = ((((state_4).check).context).functions).stores, };

                            break :block_111 @as(*const (zx_abi).zx_type_41, operand_110);
                        }), .index = (((state_4).check).context).index, .orchestration = (((state_4).check).context).orchestration, .stores = (((state_4).check).context).stores, .symbols = (if ((((((state_4).check).context).symbols).zx_origin != null)) ((((state_4).check).context).symbols).zx_origin.? else block_113: {
                            const operand_112 = (try (allocator).create((zx_abi).zx_type_39));

                            (operand_112).* = (zx_abi).zx_type_39{ .names = ((((state_4).check).context).symbols).names, .ownership = ((((state_4).check).context).symbols).ownership, .span_end = ((((state_4).check).context).symbols).span_end, .span_start = ((((state_4).check).context).symbols).span_start, .types = ((((state_4).check).context).symbols).types, };

                            break :block_113 @as(*const (zx_abi).zx_type_39, operand_112);
                        }), .table = (if ((((((state_4).check).context).table).zx_origin != null)) ((((state_4).check).context).table).zx_origin.? else block_115: {
                            const operand_114 = (try (allocator).create((zx_abi).zx_type_20));

                            (operand_114).* = (zx_abi).zx_type_20{ .children = ((((state_4).check).context).table).children, .field_names = ((((state_4).check).context).table).field_names, .field_types = ((((state_4).check).context).table).field_types, .first = ((((state_4).check).context).table).first, .kinds = ((((state_4).check).context).table).kinds, .labels = ((((state_4).check).context).table).labels, .names = ((((state_4).check).context).table).names, .second = ((((state_4).check).context).table).second, };

                            break :block_115 @as(*const (zx_abi).zx_type_20, operand_114);
                        }), };

                        break :block_117 @as(*const (zx_abi).zx_type_42, operand_116);
                    }), .kind = ((state_4).check).kind, .payload = ((state_4).check).payload, .target = ((state_4).check).target, .type_id = ((state_4).check).type_id, };

                    break :block_119 @as(*const (zx_abi).zx_type_43, operand_118);
                }), .count = (state_4).count, .fields = (state_4).fields, .first = (state_4).first, .index = (state_4).index, .valid = (state_4).valid, };
            });
        };
    };
    const value_34: u64 = (if (((in).target == @as((zx_abi).zx_type_16, .Object))) (try function_0(allocator, block_3: {
        const operand_1 = (((&value_1)).table).second;
        const operand_2 = (try function_0(allocator, (in).type_id));

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    })) else @as(u64, 0));

    return (((&value_33)).valid and (((&value_33)).fields == value_34));
}

fn function_24(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;
    const value_17: (zx_abi).zx_type_52 = block_88: {
        const operand_23 = block_22: {
            const operand_11 = (&value_1);
            const operand_12 = (try function_0(allocator, block_15: {
                const operand_13 = ((&value_2)).scope_first;
                const operand_14 = (in).payload;

                if ((operand_14 >= (operand_13).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_15 (operand_13)[@intCast(operand_14)];
            }));
            const operand_16 = (try function_0(allocator, block_19: {
                const operand_17 = ((&value_2)).scope_count;
                const operand_18 = (in).payload;

                if ((operand_18 >= (operand_17).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_19 (operand_17)[@intCast(operand_18)];
            }));
            const operand_20 = @as(u64, 0);
            const operand_21 = true;

            break :block_22 (zx_abi).zx_type_52{ .context = operand_11, .first = operand_12, .count = operand_16, .index = operand_20, .valid = operand_21, };
        };

        var state_10: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159{ .expressions = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (((operand_23).context).expressions).awaits, .binary_left = (((operand_23).context).expressions).binary_left, .binary_operators = (((operand_23).context).expressions).binary_operators, .binary_right = (((operand_23).context).expressions).binary_right, .booleans = (((operand_23).context).expressions).booleans, .call_arguments = (((operand_23).context).expressions).call_arguments, .call_functions = (((operand_23).context).expressions).call_functions, .call_store_count = (((operand_23).context).expressions).call_store_count, .call_store_first = (((operand_23).context).expressions).call_store_first, .call_stores = (((operand_23).context).expressions).call_stores, .cancellations = (((operand_23).context).expressions).cancellations, .captures = (((operand_23).context).expressions).captures, .collection_arguments = (((operand_23).context).expressions).collection_arguments, .collection_count = (((operand_23).context).expressions).collection_count, .collection_first = (((operand_23).context).expressions).collection_first, .collection_kinds = (((operand_23).context).expressions).collection_kinds, .collection_targets = (((operand_23).context).expressions).collection_targets, .conditional_conditions = (((operand_23).context).expressions).conditional_conditions, .conditional_no = (((operand_23).context).expressions).conditional_no, .conditional_yes = (((operand_23).context).expressions).conditional_yes, .enumerations = (((operand_23).context).expressions).enumerations, .errors = (((operand_23).context).expressions).errors, .floats = (((operand_23).context).expressions).floats, .index_targets = (((operand_23).context).expressions).index_targets, .index_values = (((operand_23).context).expressions).index_values, .integers = (((operand_23).context).expressions).integers, .iteration_bodies = (((operand_23).context).expressions).iteration_bodies, .iteration_condition_parameters = (((operand_23).context).expressions).iteration_condition_parameters, .iteration_conditions = (((operand_23).context).expressions).iteration_conditions, .iteration_initials = (((operand_23).context).expressions).iteration_initials, .iteration_parameters = (((operand_23).context).expressions).iteration_parameters, .iteration_postconditions = (((operand_23).context).expressions).iteration_postconditions, .kinds = (((operand_23).context).expressions).kinds, .lengths = (((operand_23).context).expressions).lengths, .match_conditions = (((operand_23).context).expressions).match_conditions, .match_count = (((operand_23).context).expressions).match_count, .match_fallbacks = (((operand_23).context).expressions).match_fallbacks, .match_first = (((operand_23).context).expressions).match_first, .match_results = (((operand_23).context).expressions).match_results, .match_subjects = (((operand_23).context).expressions).match_subjects, .negative_integers = (((operand_23).context).expressions).negative_integers, .object_count = (((operand_23).context).expressions).object_count, .object_evaluation_count = (((operand_23).context).expressions).object_evaluation_count, .object_evaluation_first = (((operand_23).context).expressions).object_evaluation_first, .object_evaluation_values = (((operand_23).context).expressions).object_evaluation_values, .object_field_indices = (((operand_23).context).expressions).object_field_indices, .object_field_values = (((operand_23).context).expressions).object_field_values, .object_first = (((operand_23).context).expressions).object_first, .optional_values = (((operand_23).context).expressions).optional_values, .parallel_count = (((operand_23).context).expressions).parallel_count, .parallel_fields = (((operand_23).context).expressions).parallel_fields, .parallel_first = (((operand_23).context).expressions).parallel_first, .parallel_tasks = (((operand_23).context).expressions).parallel_tasks, .payloads = (((operand_23).context).expressions).payloads, .projection_indices = (((operand_23).context).expressions).projection_indices, .projection_targets = (((operand_23).context).expressions).projection_targets, .references = (((operand_23).context).expressions).references, .scope_borrows = (((operand_23).context).expressions).scope_borrows, .scope_count = (((operand_23).context).expressions).scope_count, .scope_first = (((operand_23).context).expressions).scope_first, .scope_results = (((operand_23).context).expressions).scope_results, .scope_symbols = (((operand_23).context).expressions).scope_symbols, .scope_values = (((operand_23).context).expressions).scope_values, .sequence_count = (((operand_23).context).expressions).sequence_count, .sequence_first = (((operand_23).context).expressions).sequence_first, .sequence_items = (((operand_23).context).expressions).sequence_items, .some = (((operand_23).context).expressions).some, .span_end = (((operand_23).context).expressions).span_end, .span_start = (((operand_23).context).expressions).span_start, .stores = (((operand_23).context).expressions).stores, .strings = (((operand_23).context).expressions).strings, .task_bodies = (((operand_23).context).expressions).task_bodies, .task_capture_count = (((operand_23).context).expressions).task_capture_count, .task_capture_first = (((operand_23).context).expressions).task_capture_first, .task_captures = (((operand_23).context).expressions).task_captures, .transform_bodies = (((operand_23).context).expressions).transform_bodies, .transform_count = (((operand_23).context).expressions).transform_count, .transform_first = (((operand_23).context).expressions).transform_first, .transform_initials = (((operand_23).context).expressions).transform_initials, .transform_kinds = (((operand_23).context).expressions).transform_kinds, .transform_parameters = (((operand_23).context).expressions).transform_parameters, .transform_targets = (((operand_23).context).expressions).transform_targets, .types = (((operand_23).context).expressions).types, .unary_operands = (((operand_23).context).expressions).unary_operands, .unary_operators = (((operand_23).context).expressions).unary_operators, .update_indices = (((operand_23).context).expressions).update_indices, .update_targets = (((operand_23).context).expressions).update_targets, .update_values = (((operand_23).context).expressions).update_values, .zx_origin = ((operand_23).context).expressions, }, .functions = (zx_abi).value_zx_type_41_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .input_types = (((operand_23).context).functions).input_types, .output_types = (((operand_23).context).functions).output_types, .stores = (((operand_23).context).functions).stores, .zx_origin = ((operand_23).context).functions, }, .index = ((operand_23).context).index, .orchestration = ((operand_23).context).orchestration, .stores = ((operand_23).context).stores, .symbols = (zx_abi).value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((operand_23).context).symbols).names, .ownership = (((operand_23).context).symbols).ownership, .span_end = (((operand_23).context).symbols).span_end, .span_start = (((operand_23).context).symbols).span_start, .types = (((operand_23).context).symbols).types, .zx_origin = ((operand_23).context).symbols, }, .table = (zx_abi).value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_23).context).table).children, .field_names = (((operand_23).context).table).field_names, .field_types = (((operand_23).context).table).field_types, .first = (((operand_23).context).table).first, .kinds = (((operand_23).context).table).kinds, .labels = (((operand_23).context).table).labels, .names = (((operand_23).context).table).names, .second = (((operand_23).context).table).second, .zx_origin = ((operand_23).context).table, }, .zx_origin = (operand_23).context, }, .count = (operand_23).count, .first = (operand_23).first, .index = (operand_23).index, .valid = (operand_23).valid, .zx_origin = (&operand_23), };

        while (((state_10).valid and ((state_10).index < (state_10).count))) {
            state_10 = block_75: {
                const value_5: (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159 = (state_10).context;
                const value_6: u64 = ((state_10).first + (state_10).index);
                const value_7: u32 = block_74: {
                    const operand_72 = ((value_5).expressions).scope_values;
                    const operand_73 = block_71: {
                        break :block_71 value_6;
                    };

                    if ((operand_73 >= (operand_72).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_74 (operand_72)[@intCast(operand_73)];
                };
                const value_8: ?u32 = block_70: {
                    const operand_68 = ((value_5).expressions).scope_symbols;
                    const operand_69 = block_67: {
                        break :block_67 value_6;
                    };

                    if ((operand_69 >= (operand_68).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_70 (operand_68)[@intCast(operand_69)];
                };
                const value_14: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = (if (((try function_0(allocator, block_26: {
                    break :block_26 value_7;
                })) >= (value_5).index)) block_28: {
                    const value_9: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = block_27: {
                        break :block_27 @as((zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c, (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (state_10).context, .count = (state_10).count, .first = (state_10).first, .index = (state_10).index, .valid = false, });
                    };

                    break :block_28 value_9;
                } else block_66: {
                    const value_13: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = (if ((block_29: {
                        break :block_29 value_8;
                    } != null)) block_48: {
                        const value_10: u64 = (try function_0(allocator, block_47: {
                            break :block_47 value_8;
                        }.?));
                        const value_11: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = block_46: {
                            break :block_46 @as((zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c, (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (state_10).context, .count = (state_10).count, .first = (state_10).first, .index = (state_10).index, .valid = ((block_30: {
                                break :block_30 value_10;
                            } < @as(u64, (((value_5).symbols).types).len)) and block_45: {
                                const operand_31 = (value_5).expressions;

                                var state_borrow_32: (zx_abi).zx_type_34 = undefined;

                                state_borrow_32 = (zx_abi).zx_type_34{ .awaits = (operand_31).awaits, .binary_left = (operand_31).binary_left, .binary_operators = (operand_31).binary_operators, .binary_right = (operand_31).binary_right, .booleans = (operand_31).booleans, .call_arguments = (operand_31).call_arguments, .call_functions = (operand_31).call_functions, .call_store_count = (operand_31).call_store_count, .call_store_first = (operand_31).call_store_first, .call_stores = (operand_31).call_stores, .cancellations = (operand_31).cancellations, .captures = (operand_31).captures, .collection_arguments = (operand_31).collection_arguments, .collection_count = (operand_31).collection_count, .collection_first = (operand_31).collection_first, .collection_kinds = (operand_31).collection_kinds, .collection_targets = (operand_31).collection_targets, .conditional_conditions = (operand_31).conditional_conditions, .conditional_no = (operand_31).conditional_no, .conditional_yes = (operand_31).conditional_yes, .enumerations = (operand_31).enumerations, .errors = (operand_31).errors, .floats = (operand_31).floats, .index_targets = (operand_31).index_targets, .index_values = (operand_31).index_values, .integers = (operand_31).integers, .iteration_bodies = (operand_31).iteration_bodies, .iteration_condition_parameters = (operand_31).iteration_condition_parameters, .iteration_conditions = (operand_31).iteration_conditions, .iteration_initials = (operand_31).iteration_initials, .iteration_parameters = (operand_31).iteration_parameters, .iteration_postconditions = (operand_31).iteration_postconditions, .kinds = (operand_31).kinds, .lengths = (operand_31).lengths, .match_conditions = (operand_31).match_conditions, .match_count = (operand_31).match_count, .match_fallbacks = (operand_31).match_fallbacks, .match_first = (operand_31).match_first, .match_results = (operand_31).match_results, .match_subjects = (operand_31).match_subjects, .negative_integers = (operand_31).negative_integers, .object_count = (operand_31).object_count, .object_evaluation_count = (operand_31).object_evaluation_count, .object_evaluation_first = (operand_31).object_evaluation_first, .object_evaluation_values = (operand_31).object_evaluation_values, .object_field_indices = (operand_31).object_field_indices, .object_field_values = (operand_31).object_field_values, .object_first = (operand_31).object_first, .optional_values = (operand_31).optional_values, .parallel_count = (operand_31).parallel_count, .parallel_fields = (operand_31).parallel_fields, .parallel_first = (operand_31).parallel_first, .parallel_tasks = (operand_31).parallel_tasks, .payloads = (operand_31).payloads, .projection_indices = (operand_31).projection_indices, .projection_targets = (operand_31).projection_targets, .references = (operand_31).references, .scope_borrows = (operand_31).scope_borrows, .scope_count = (operand_31).scope_count, .scope_first = (operand_31).scope_first, .scope_results = (operand_31).scope_results, .scope_symbols = (operand_31).scope_symbols, .scope_values = (operand_31).scope_values, .sequence_count = (operand_31).sequence_count, .sequence_first = (operand_31).sequence_first, .sequence_items = (operand_31).sequence_items, .some = (operand_31).some, .span_end = (operand_31).span_end, .span_start = (operand_31).span_start, .stores = (operand_31).stores, .strings = (operand_31).strings, .task_bodies = (operand_31).task_bodies, .task_capture_count = (operand_31).task_capture_count, .task_capture_first = (operand_31).task_capture_first, .task_captures = (operand_31).task_captures, .transform_bodies = (operand_31).transform_bodies, .transform_count = (operand_31).transform_count, .transform_first = (operand_31).transform_first, .transform_initials = (operand_31).transform_initials, .transform_kinds = (operand_31).transform_kinds, .transform_parameters = (operand_31).transform_parameters, .transform_targets = (operand_31).transform_targets, .types = (operand_31).types, .unary_operands = (operand_31).unary_operands, .unary_operators = (operand_31).unary_operators, .update_indices = (operand_31).update_indices, .update_targets = (operand_31).update_targets, .update_values = (operand_31).update_values, };

                                const operand_33 = ((operand_31).zx_origin orelse (&state_borrow_32));
                                const operand_34 = (value_5).index;
                                const operand_36 = block_35: {
                                    break :block_35 value_7;
                                };
                                const operand_41 = block_40: {
                                    const operand_38 = ((value_5).symbols).types;
                                    const operand_39 = block_37: {
                                        break :block_37 value_10;
                                    };

                                    if ((operand_39 >= (operand_38).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_40 (operand_38)[@intCast(operand_39)];
                                };
                                const operand_42 = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (operand_33).awaits, .binary_left = (operand_33).binary_left, .binary_operators = (operand_33).binary_operators, .binary_right = (operand_33).binary_right, .booleans = (operand_33).booleans, .call_arguments = (operand_33).call_arguments, .call_functions = (operand_33).call_functions, .call_store_count = (operand_33).call_store_count, .call_store_first = (operand_33).call_store_first, .call_stores = (operand_33).call_stores, .cancellations = (operand_33).cancellations, .captures = (operand_33).captures, .collection_arguments = (operand_33).collection_arguments, .collection_count = (operand_33).collection_count, .collection_first = (operand_33).collection_first, .collection_kinds = (operand_33).collection_kinds, .collection_targets = (operand_33).collection_targets, .conditional_conditions = (operand_33).conditional_conditions, .conditional_no = (operand_33).conditional_no, .conditional_yes = (operand_33).conditional_yes, .enumerations = (operand_33).enumerations, .errors = (operand_33).errors, .floats = (operand_33).floats, .index_targets = (operand_33).index_targets, .index_values = (operand_33).index_values, .integers = (operand_33).integers, .iteration_bodies = (operand_33).iteration_bodies, .iteration_condition_parameters = (operand_33).iteration_condition_parameters, .iteration_conditions = (operand_33).iteration_conditions, .iteration_initials = (operand_33).iteration_initials, .iteration_parameters = (operand_33).iteration_parameters, .iteration_postconditions = (operand_33).iteration_postconditions, .kinds = (operand_33).kinds, .lengths = (operand_33).lengths, .match_conditions = (operand_33).match_conditions, .match_count = (operand_33).match_count, .match_fallbacks = (operand_33).match_fallbacks, .match_first = (operand_33).match_first, .match_results = (operand_33).match_results, .match_subjects = (operand_33).match_subjects, .negative_integers = (operand_33).negative_integers, .object_count = (operand_33).object_count, .object_evaluation_count = (operand_33).object_evaluation_count, .object_evaluation_first = (operand_33).object_evaluation_first, .object_evaluation_values = (operand_33).object_evaluation_values, .object_field_indices = (operand_33).object_field_indices, .object_field_values = (operand_33).object_field_values, .object_first = (operand_33).object_first, .optional_values = (operand_33).optional_values, .parallel_count = (operand_33).parallel_count, .parallel_fields = (operand_33).parallel_fields, .parallel_first = (operand_33).parallel_first, .parallel_tasks = (operand_33).parallel_tasks, .payloads = (operand_33).payloads, .projection_indices = (operand_33).projection_indices, .projection_targets = (operand_33).projection_targets, .references = (operand_33).references, .scope_borrows = (operand_33).scope_borrows, .scope_count = (operand_33).scope_count, .scope_first = (operand_33).scope_first, .scope_results = (operand_33).scope_results, .scope_symbols = (operand_33).scope_symbols, .scope_values = (operand_33).scope_values, .sequence_count = (operand_33).sequence_count, .sequence_first = (operand_33).sequence_first, .sequence_items = (operand_33).sequence_items, .some = (operand_33).some, .span_end = (operand_33).span_end, .span_start = (operand_33).span_start, .stores = (operand_33).stores, .strings = (operand_33).strings, .task_bodies = (operand_33).task_bodies, .task_capture_count = (operand_33).task_capture_count, .task_capture_first = (operand_33).task_capture_first, .task_captures = (operand_33).task_captures, .transform_bodies = (operand_33).transform_bodies, .transform_count = (operand_33).transform_count, .transform_first = (operand_33).transform_first, .transform_initials = (operand_33).transform_initials, .transform_kinds = (operand_33).transform_kinds, .transform_parameters = (operand_33).transform_parameters, .transform_targets = (operand_33).transform_targets, .types = (operand_33).types, .unary_operands = (operand_33).unary_operands, .unary_operators = (operand_33).unary_operators, .update_indices = (operand_33).update_indices, .update_targets = (operand_33).update_targets, .update_values = (operand_33).update_values, .zx_origin = operand_33, };

                                var state_borrow_43: (zx_abi).zx_type_34 = undefined;

                                state_borrow_43 = (zx_abi).zx_type_34{ .awaits = (operand_42).awaits, .binary_left = (operand_42).binary_left, .binary_operators = (operand_42).binary_operators, .binary_right = (operand_42).binary_right, .booleans = (operand_42).booleans, .call_arguments = (operand_42).call_arguments, .call_functions = (operand_42).call_functions, .call_store_count = (operand_42).call_store_count, .call_store_first = (operand_42).call_store_first, .call_stores = (operand_42).call_stores, .cancellations = (operand_42).cancellations, .captures = (operand_42).captures, .collection_arguments = (operand_42).collection_arguments, .collection_count = (operand_42).collection_count, .collection_first = (operand_42).collection_first, .collection_kinds = (operand_42).collection_kinds, .collection_targets = (operand_42).collection_targets, .conditional_conditions = (operand_42).conditional_conditions, .conditional_no = (operand_42).conditional_no, .conditional_yes = (operand_42).conditional_yes, .enumerations = (operand_42).enumerations, .errors = (operand_42).errors, .floats = (operand_42).floats, .index_targets = (operand_42).index_targets, .index_values = (operand_42).index_values, .integers = (operand_42).integers, .iteration_bodies = (operand_42).iteration_bodies, .iteration_condition_parameters = (operand_42).iteration_condition_parameters, .iteration_conditions = (operand_42).iteration_conditions, .iteration_initials = (operand_42).iteration_initials, .iteration_parameters = (operand_42).iteration_parameters, .iteration_postconditions = (operand_42).iteration_postconditions, .kinds = (operand_42).kinds, .lengths = (operand_42).lengths, .match_conditions = (operand_42).match_conditions, .match_count = (operand_42).match_count, .match_fallbacks = (operand_42).match_fallbacks, .match_first = (operand_42).match_first, .match_results = (operand_42).match_results, .match_subjects = (operand_42).match_subjects, .negative_integers = (operand_42).negative_integers, .object_count = (operand_42).object_count, .object_evaluation_count = (operand_42).object_evaluation_count, .object_evaluation_first = (operand_42).object_evaluation_first, .object_evaluation_values = (operand_42).object_evaluation_values, .object_field_indices = (operand_42).object_field_indices, .object_field_values = (operand_42).object_field_values, .object_first = (operand_42).object_first, .optional_values = (operand_42).optional_values, .parallel_count = (operand_42).parallel_count, .parallel_fields = (operand_42).parallel_fields, .parallel_first = (operand_42).parallel_first, .parallel_tasks = (operand_42).parallel_tasks, .payloads = (operand_42).payloads, .projection_indices = (operand_42).projection_indices, .projection_targets = (operand_42).projection_targets, .references = (operand_42).references, .scope_borrows = (operand_42).scope_borrows, .scope_count = (operand_42).scope_count, .scope_first = (operand_42).scope_first, .scope_results = (operand_42).scope_results, .scope_symbols = (operand_42).scope_symbols, .scope_values = (operand_42).scope_values, .sequence_count = (operand_42).sequence_count, .sequence_first = (operand_42).sequence_first, .sequence_items = (operand_42).sequence_items, .some = (operand_42).some, .span_end = (operand_42).span_end, .span_start = (operand_42).span_start, .stores = (operand_42).stores, .strings = (operand_42).strings, .task_bodies = (operand_42).task_bodies, .task_capture_count = (operand_42).task_capture_count, .task_capture_first = (operand_42).task_capture_first, .task_captures = (operand_42).task_captures, .transform_bodies = (operand_42).transform_bodies, .transform_count = (operand_42).transform_count, .transform_first = (operand_42).transform_first, .transform_initials = (operand_42).transform_initials, .transform_kinds = (operand_42).transform_kinds, .transform_parameters = (operand_42).transform_parameters, .transform_targets = (operand_42).transform_targets, .types = (operand_42).types, .unary_operands = (operand_42).unary_operands, .unary_operators = (operand_42).unary_operators, .update_indices = (operand_42).update_indices, .update_targets = (operand_42).update_targets, .update_values = (operand_42).update_values, };

                                const operand_44 = (zx_abi).zx_type_35{ .expressions = ((operand_42).zx_origin orelse (&state_borrow_43)), .index = operand_34, .id = operand_36, .type_id = operand_41, };

                                break :block_45 (try function_10(allocator, (&operand_44)));
                            }), });
                        };

                        break :block_48 value_11;
                    } else block_65: {
                        const value_12: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = block_64: {
                            break :block_64 @as((zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c, (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (state_10).context, .count = (state_10).count, .first = (state_10).first, .index = (state_10).index, .valid = (block_59: {
                                const operand_49 = (value_5).expressions;

                                var state_borrow_50: (zx_abi).zx_type_34 = undefined;

                                state_borrow_50 = (zx_abi).zx_type_34{ .awaits = (operand_49).awaits, .binary_left = (operand_49).binary_left, .binary_operators = (operand_49).binary_operators, .binary_right = (operand_49).binary_right, .booleans = (operand_49).booleans, .call_arguments = (operand_49).call_arguments, .call_functions = (operand_49).call_functions, .call_store_count = (operand_49).call_store_count, .call_store_first = (operand_49).call_store_first, .call_stores = (operand_49).call_stores, .cancellations = (operand_49).cancellations, .captures = (operand_49).captures, .collection_arguments = (operand_49).collection_arguments, .collection_count = (operand_49).collection_count, .collection_first = (operand_49).collection_first, .collection_kinds = (operand_49).collection_kinds, .collection_targets = (operand_49).collection_targets, .conditional_conditions = (operand_49).conditional_conditions, .conditional_no = (operand_49).conditional_no, .conditional_yes = (operand_49).conditional_yes, .enumerations = (operand_49).enumerations, .errors = (operand_49).errors, .floats = (operand_49).floats, .index_targets = (operand_49).index_targets, .index_values = (operand_49).index_values, .integers = (operand_49).integers, .iteration_bodies = (operand_49).iteration_bodies, .iteration_condition_parameters = (operand_49).iteration_condition_parameters, .iteration_conditions = (operand_49).iteration_conditions, .iteration_initials = (operand_49).iteration_initials, .iteration_parameters = (operand_49).iteration_parameters, .iteration_postconditions = (operand_49).iteration_postconditions, .kinds = (operand_49).kinds, .lengths = (operand_49).lengths, .match_conditions = (operand_49).match_conditions, .match_count = (operand_49).match_count, .match_fallbacks = (operand_49).match_fallbacks, .match_first = (operand_49).match_first, .match_results = (operand_49).match_results, .match_subjects = (operand_49).match_subjects, .negative_integers = (operand_49).negative_integers, .object_count = (operand_49).object_count, .object_evaluation_count = (operand_49).object_evaluation_count, .object_evaluation_first = (operand_49).object_evaluation_first, .object_evaluation_values = (operand_49).object_evaluation_values, .object_field_indices = (operand_49).object_field_indices, .object_field_values = (operand_49).object_field_values, .object_first = (operand_49).object_first, .optional_values = (operand_49).optional_values, .parallel_count = (operand_49).parallel_count, .parallel_fields = (operand_49).parallel_fields, .parallel_first = (operand_49).parallel_first, .parallel_tasks = (operand_49).parallel_tasks, .payloads = (operand_49).payloads, .projection_indices = (operand_49).projection_indices, .projection_targets = (operand_49).projection_targets, .references = (operand_49).references, .scope_borrows = (operand_49).scope_borrows, .scope_count = (operand_49).scope_count, .scope_first = (operand_49).scope_first, .scope_results = (operand_49).scope_results, .scope_symbols = (operand_49).scope_symbols, .scope_values = (operand_49).scope_values, .sequence_count = (operand_49).sequence_count, .sequence_first = (operand_49).sequence_first, .sequence_items = (operand_49).sequence_items, .some = (operand_49).some, .span_end = (operand_49).span_end, .span_start = (operand_49).span_start, .stores = (operand_49).stores, .strings = (operand_49).strings, .task_bodies = (operand_49).task_bodies, .task_capture_count = (operand_49).task_capture_count, .task_capture_first = (operand_49).task_capture_first, .task_captures = (operand_49).task_captures, .transform_bodies = (operand_49).transform_bodies, .transform_count = (operand_49).transform_count, .transform_first = (operand_49).transform_first, .transform_initials = (operand_49).transform_initials, .transform_kinds = (operand_49).transform_kinds, .transform_parameters = (operand_49).transform_parameters, .transform_targets = (operand_49).transform_targets, .types = (operand_49).types, .unary_operands = (operand_49).unary_operands, .unary_operators = (operand_49).unary_operators, .update_indices = (operand_49).update_indices, .update_targets = (operand_49).update_targets, .update_values = (operand_49).update_values, };

                                const operand_51 = ((operand_49).zx_origin orelse (&state_borrow_50));
                                const operand_52 = (value_5).index;
                                const operand_54 = block_53: {
                                    break :block_53 value_7;
                                };
                                const operand_55 = @as(u32, 0);
                                const operand_56 = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (operand_51).awaits, .binary_left = (operand_51).binary_left, .binary_operators = (operand_51).binary_operators, .binary_right = (operand_51).binary_right, .booleans = (operand_51).booleans, .call_arguments = (operand_51).call_arguments, .call_functions = (operand_51).call_functions, .call_store_count = (operand_51).call_store_count, .call_store_first = (operand_51).call_store_first, .call_stores = (operand_51).call_stores, .cancellations = (operand_51).cancellations, .captures = (operand_51).captures, .collection_arguments = (operand_51).collection_arguments, .collection_count = (operand_51).collection_count, .collection_first = (operand_51).collection_first, .collection_kinds = (operand_51).collection_kinds, .collection_targets = (operand_51).collection_targets, .conditional_conditions = (operand_51).conditional_conditions, .conditional_no = (operand_51).conditional_no, .conditional_yes = (operand_51).conditional_yes, .enumerations = (operand_51).enumerations, .errors = (operand_51).errors, .floats = (operand_51).floats, .index_targets = (operand_51).index_targets, .index_values = (operand_51).index_values, .integers = (operand_51).integers, .iteration_bodies = (operand_51).iteration_bodies, .iteration_condition_parameters = (operand_51).iteration_condition_parameters, .iteration_conditions = (operand_51).iteration_conditions, .iteration_initials = (operand_51).iteration_initials, .iteration_parameters = (operand_51).iteration_parameters, .iteration_postconditions = (operand_51).iteration_postconditions, .kinds = (operand_51).kinds, .lengths = (operand_51).lengths, .match_conditions = (operand_51).match_conditions, .match_count = (operand_51).match_count, .match_fallbacks = (operand_51).match_fallbacks, .match_first = (operand_51).match_first, .match_results = (operand_51).match_results, .match_subjects = (operand_51).match_subjects, .negative_integers = (operand_51).negative_integers, .object_count = (operand_51).object_count, .object_evaluation_count = (operand_51).object_evaluation_count, .object_evaluation_first = (operand_51).object_evaluation_first, .object_evaluation_values = (operand_51).object_evaluation_values, .object_field_indices = (operand_51).object_field_indices, .object_field_values = (operand_51).object_field_values, .object_first = (operand_51).object_first, .optional_values = (operand_51).optional_values, .parallel_count = (operand_51).parallel_count, .parallel_fields = (operand_51).parallel_fields, .parallel_first = (operand_51).parallel_first, .parallel_tasks = (operand_51).parallel_tasks, .payloads = (operand_51).payloads, .projection_indices = (operand_51).projection_indices, .projection_targets = (operand_51).projection_targets, .references = (operand_51).references, .scope_borrows = (operand_51).scope_borrows, .scope_count = (operand_51).scope_count, .scope_first = (operand_51).scope_first, .scope_results = (operand_51).scope_results, .scope_symbols = (operand_51).scope_symbols, .scope_values = (operand_51).scope_values, .sequence_count = (operand_51).sequence_count, .sequence_first = (operand_51).sequence_first, .sequence_items = (operand_51).sequence_items, .some = (operand_51).some, .span_end = (operand_51).span_end, .span_start = (operand_51).span_start, .stores = (operand_51).stores, .strings = (operand_51).strings, .task_bodies = (operand_51).task_bodies, .task_capture_count = (operand_51).task_capture_count, .task_capture_first = (operand_51).task_capture_first, .task_captures = (operand_51).task_captures, .transform_bodies = (operand_51).transform_bodies, .transform_count = (operand_51).transform_count, .transform_first = (operand_51).transform_first, .transform_initials = (operand_51).transform_initials, .transform_kinds = (operand_51).transform_kinds, .transform_parameters = (operand_51).transform_parameters, .transform_targets = (operand_51).transform_targets, .types = (operand_51).types, .unary_operands = (operand_51).unary_operands, .unary_operators = (operand_51).unary_operators, .update_indices = (operand_51).update_indices, .update_targets = (operand_51).update_targets, .update_values = (operand_51).update_values, .zx_origin = operand_51, };

                                var state_borrow_57: (zx_abi).zx_type_34 = undefined;

                                state_borrow_57 = (zx_abi).zx_type_34{ .awaits = (operand_56).awaits, .binary_left = (operand_56).binary_left, .binary_operators = (operand_56).binary_operators, .binary_right = (operand_56).binary_right, .booleans = (operand_56).booleans, .call_arguments = (operand_56).call_arguments, .call_functions = (operand_56).call_functions, .call_store_count = (operand_56).call_store_count, .call_store_first = (operand_56).call_store_first, .call_stores = (operand_56).call_stores, .cancellations = (operand_56).cancellations, .captures = (operand_56).captures, .collection_arguments = (operand_56).collection_arguments, .collection_count = (operand_56).collection_count, .collection_first = (operand_56).collection_first, .collection_kinds = (operand_56).collection_kinds, .collection_targets = (operand_56).collection_targets, .conditional_conditions = (operand_56).conditional_conditions, .conditional_no = (operand_56).conditional_no, .conditional_yes = (operand_56).conditional_yes, .enumerations = (operand_56).enumerations, .errors = (operand_56).errors, .floats = (operand_56).floats, .index_targets = (operand_56).index_targets, .index_values = (operand_56).index_values, .integers = (operand_56).integers, .iteration_bodies = (operand_56).iteration_bodies, .iteration_condition_parameters = (operand_56).iteration_condition_parameters, .iteration_conditions = (operand_56).iteration_conditions, .iteration_initials = (operand_56).iteration_initials, .iteration_parameters = (operand_56).iteration_parameters, .iteration_postconditions = (operand_56).iteration_postconditions, .kinds = (operand_56).kinds, .lengths = (operand_56).lengths, .match_conditions = (operand_56).match_conditions, .match_count = (operand_56).match_count, .match_fallbacks = (operand_56).match_fallbacks, .match_first = (operand_56).match_first, .match_results = (operand_56).match_results, .match_subjects = (operand_56).match_subjects, .negative_integers = (operand_56).negative_integers, .object_count = (operand_56).object_count, .object_evaluation_count = (operand_56).object_evaluation_count, .object_evaluation_first = (operand_56).object_evaluation_first, .object_evaluation_values = (operand_56).object_evaluation_values, .object_field_indices = (operand_56).object_field_indices, .object_field_values = (operand_56).object_field_values, .object_first = (operand_56).object_first, .optional_values = (operand_56).optional_values, .parallel_count = (operand_56).parallel_count, .parallel_fields = (operand_56).parallel_fields, .parallel_first = (operand_56).parallel_first, .parallel_tasks = (operand_56).parallel_tasks, .payloads = (operand_56).payloads, .projection_indices = (operand_56).projection_indices, .projection_targets = (operand_56).projection_targets, .references = (operand_56).references, .scope_borrows = (operand_56).scope_borrows, .scope_count = (operand_56).scope_count, .scope_first = (operand_56).scope_first, .scope_results = (operand_56).scope_results, .scope_symbols = (operand_56).scope_symbols, .scope_values = (operand_56).scope_values, .sequence_count = (operand_56).sequence_count, .sequence_first = (operand_56).sequence_first, .sequence_items = (operand_56).sequence_items, .some = (operand_56).some, .span_end = (operand_56).span_end, .span_start = (operand_56).span_start, .stores = (operand_56).stores, .strings = (operand_56).strings, .task_bodies = (operand_56).task_bodies, .task_capture_count = (operand_56).task_capture_count, .task_capture_first = (operand_56).task_capture_first, .task_captures = (operand_56).task_captures, .transform_bodies = (operand_56).transform_bodies, .transform_count = (operand_56).transform_count, .transform_first = (operand_56).transform_first, .transform_initials = (operand_56).transform_initials, .transform_kinds = (operand_56).transform_kinds, .transform_parameters = (operand_56).transform_parameters, .transform_targets = (operand_56).transform_targets, .types = (operand_56).types, .unary_operands = (operand_56).unary_operands, .unary_operators = (operand_56).unary_operators, .update_indices = (operand_56).update_indices, .update_targets = (operand_56).update_targets, .update_values = (operand_56).update_values, };

                                const operand_58 = (zx_abi).zx_type_35{ .expressions = ((operand_56).zx_origin orelse (&state_borrow_57)), .index = operand_52, .id = operand_54, .type_id = operand_55, };

                                break :block_59 (try function_10(allocator, (&operand_58)));
                            } or (block_63: {
                                const operand_61 = ((value_5).expressions).kinds;
                                const operand_62 = (try function_0(allocator, block_60: {
                                    break :block_60 value_7;
                                }));

                                if ((operand_62 >= (operand_61).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_63 (operand_61)[@intCast(operand_62)];
                            } == @as((zx_abi).zx_type_11, .Iteration))), });
                        };

                        break :block_65 value_12;
                    });

                    break :block_66 value_13;
                });
                const value_15: u64 = (value_14).index;
                const value_16: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = block_25: {
                    break :block_25 @as((zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c, (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (value_14).context, .count = (value_14).count, .first = (value_14).first, .index = (block_24: {
                        break :block_24 value_15;
                    } + @as(u64, 1)), .valid = (value_14).valid, });
                };

                break :block_75 value_16;
            };
        }

        break :block_88 block_87: {
            break :block_87 (if (((state_10).zx_origin != null)) ((state_10).zx_origin.?).* else block_86: {
                break :block_86 (zx_abi).zx_type_52{ .context = (if ((((state_10).context).zx_origin != null)) ((state_10).context).zx_origin.? else block_85: {
                    const operand_84 = (try (allocator).create((zx_abi).zx_type_42));

                    (operand_84).* = (zx_abi).zx_type_42{ .expressions = (if (((((state_10).context).expressions).zx_origin != null)) (((state_10).context).expressions).zx_origin.? else block_77: {
                        const operand_76 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_76).* = (zx_abi).zx_type_34{ .awaits = (((state_10).context).expressions).awaits, .binary_left = (((state_10).context).expressions).binary_left, .binary_operators = (((state_10).context).expressions).binary_operators, .binary_right = (((state_10).context).expressions).binary_right, .booleans = (((state_10).context).expressions).booleans, .call_arguments = (((state_10).context).expressions).call_arguments, .call_functions = (((state_10).context).expressions).call_functions, .call_store_count = (((state_10).context).expressions).call_store_count, .call_store_first = (((state_10).context).expressions).call_store_first, .call_stores = (((state_10).context).expressions).call_stores, .cancellations = (((state_10).context).expressions).cancellations, .captures = (((state_10).context).expressions).captures, .collection_arguments = (((state_10).context).expressions).collection_arguments, .collection_count = (((state_10).context).expressions).collection_count, .collection_first = (((state_10).context).expressions).collection_first, .collection_kinds = (((state_10).context).expressions).collection_kinds, .collection_targets = (((state_10).context).expressions).collection_targets, .conditional_conditions = (((state_10).context).expressions).conditional_conditions, .conditional_no = (((state_10).context).expressions).conditional_no, .conditional_yes = (((state_10).context).expressions).conditional_yes, .enumerations = (((state_10).context).expressions).enumerations, .errors = (((state_10).context).expressions).errors, .floats = (((state_10).context).expressions).floats, .index_targets = (((state_10).context).expressions).index_targets, .index_values = (((state_10).context).expressions).index_values, .integers = (((state_10).context).expressions).integers, .iteration_bodies = (((state_10).context).expressions).iteration_bodies, .iteration_condition_parameters = (((state_10).context).expressions).iteration_condition_parameters, .iteration_conditions = (((state_10).context).expressions).iteration_conditions, .iteration_initials = (((state_10).context).expressions).iteration_initials, .iteration_parameters = (((state_10).context).expressions).iteration_parameters, .iteration_postconditions = (((state_10).context).expressions).iteration_postconditions, .kinds = (((state_10).context).expressions).kinds, .lengths = (((state_10).context).expressions).lengths, .match_conditions = (((state_10).context).expressions).match_conditions, .match_count = (((state_10).context).expressions).match_count, .match_fallbacks = (((state_10).context).expressions).match_fallbacks, .match_first = (((state_10).context).expressions).match_first, .match_results = (((state_10).context).expressions).match_results, .match_subjects = (((state_10).context).expressions).match_subjects, .negative_integers = (((state_10).context).expressions).negative_integers, .object_count = (((state_10).context).expressions).object_count, .object_evaluation_count = (((state_10).context).expressions).object_evaluation_count, .object_evaluation_first = (((state_10).context).expressions).object_evaluation_first, .object_evaluation_values = (((state_10).context).expressions).object_evaluation_values, .object_field_indices = (((state_10).context).expressions).object_field_indices, .object_field_values = (((state_10).context).expressions).object_field_values, .object_first = (((state_10).context).expressions).object_first, .optional_values = (((state_10).context).expressions).optional_values, .parallel_count = (((state_10).context).expressions).parallel_count, .parallel_fields = (((state_10).context).expressions).parallel_fields, .parallel_first = (((state_10).context).expressions).parallel_first, .parallel_tasks = (((state_10).context).expressions).parallel_tasks, .payloads = (((state_10).context).expressions).payloads, .projection_indices = (((state_10).context).expressions).projection_indices, .projection_targets = (((state_10).context).expressions).projection_targets, .references = (((state_10).context).expressions).references, .scope_borrows = (((state_10).context).expressions).scope_borrows, .scope_count = (((state_10).context).expressions).scope_count, .scope_first = (((state_10).context).expressions).scope_first, .scope_results = (((state_10).context).expressions).scope_results, .scope_symbols = (((state_10).context).expressions).scope_symbols, .scope_values = (((state_10).context).expressions).scope_values, .sequence_count = (((state_10).context).expressions).sequence_count, .sequence_first = (((state_10).context).expressions).sequence_first, .sequence_items = (((state_10).context).expressions).sequence_items, .some = (((state_10).context).expressions).some, .span_end = (((state_10).context).expressions).span_end, .span_start = (((state_10).context).expressions).span_start, .stores = (((state_10).context).expressions).stores, .strings = (((state_10).context).expressions).strings, .task_bodies = (((state_10).context).expressions).task_bodies, .task_capture_count = (((state_10).context).expressions).task_capture_count, .task_capture_first = (((state_10).context).expressions).task_capture_first, .task_captures = (((state_10).context).expressions).task_captures, .transform_bodies = (((state_10).context).expressions).transform_bodies, .transform_count = (((state_10).context).expressions).transform_count, .transform_first = (((state_10).context).expressions).transform_first, .transform_initials = (((state_10).context).expressions).transform_initials, .transform_kinds = (((state_10).context).expressions).transform_kinds, .transform_parameters = (((state_10).context).expressions).transform_parameters, .transform_targets = (((state_10).context).expressions).transform_targets, .types = (((state_10).context).expressions).types, .unary_operands = (((state_10).context).expressions).unary_operands, .unary_operators = (((state_10).context).expressions).unary_operators, .update_indices = (((state_10).context).expressions).update_indices, .update_targets = (((state_10).context).expressions).update_targets, .update_values = (((state_10).context).expressions).update_values, };

                        break :block_77 @as(*const (zx_abi).zx_type_34, operand_76);
                    }), .functions = (if (((((state_10).context).functions).zx_origin != null)) (((state_10).context).functions).zx_origin.? else block_79: {
                        const operand_78 = (try (allocator).create((zx_abi).zx_type_41));

                        (operand_78).* = (zx_abi).zx_type_41{ .input_types = (((state_10).context).functions).input_types, .output_types = (((state_10).context).functions).output_types, .stores = (((state_10).context).functions).stores, };

                        break :block_79 @as(*const (zx_abi).zx_type_41, operand_78);
                    }), .index = ((state_10).context).index, .orchestration = ((state_10).context).orchestration, .stores = ((state_10).context).stores, .symbols = (if (((((state_10).context).symbols).zx_origin != null)) (((state_10).context).symbols).zx_origin.? else block_81: {
                        const operand_80 = (try (allocator).create((zx_abi).zx_type_39));

                        (operand_80).* = (zx_abi).zx_type_39{ .names = (((state_10).context).symbols).names, .ownership = (((state_10).context).symbols).ownership, .span_end = (((state_10).context).symbols).span_end, .span_start = (((state_10).context).symbols).span_start, .types = (((state_10).context).symbols).types, };

                        break :block_81 @as(*const (zx_abi).zx_type_39, operand_80);
                    }), .table = (if (((((state_10).context).table).zx_origin != null)) (((state_10).context).table).zx_origin.? else block_83: {
                        const operand_82 = (try (allocator).create((zx_abi).zx_type_20));

                        (operand_82).* = (zx_abi).zx_type_20{ .children = (((state_10).context).table).children, .field_names = (((state_10).context).table).field_names, .field_types = (((state_10).context).table).field_types, .first = (((state_10).context).table).first, .kinds = (((state_10).context).table).kinds, .labels = (((state_10).context).table).labels, .names = (((state_10).context).table).names, .second = (((state_10).context).table).second, };

                        break :block_83 @as(*const (zx_abi).zx_type_20, operand_82);
                    }), };

                    break :block_85 @as(*const (zx_abi).zx_type_42, operand_84);
                }), .count = (state_10).count, .first = (state_10).first, .index = (state_10).index, .valid = (state_10).valid, };
            });
        };
    };

    return (((&value_17)).valid and block_9: {
        const operand_1 = (&value_2);
        const operand_2 = ((&value_1)).index;
        const operand_6 = block_5: {
            const operand_3 = ((&value_2)).scope_results;
            const operand_4 = (in).payload;

            if ((operand_4 >= (operand_3).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_5 (operand_3)[@intCast(operand_4)];
        };
        const operand_7 = (in).type_id;
        const operand_8 = (zx_abi).zx_type_35{ .expressions = operand_1, .index = operand_2, .id = operand_6, .type_id = operand_7, };

        break :block_9 (try function_10(allocator, (&operand_8)));
    });
}

fn function_25(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_34 = (((in).context).expressions).*;
    const value_2: (zx_abi).zx_type_20 = (((in).context).table).*;
    const value_3: u64 = (try function_0(allocator, block_68: {
        const operand_66 = ((&value_1)).sequence_count;
        const operand_67 = (in).payload;

        if ((operand_67 >= (operand_66).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_68 (operand_66)[@intCast(operand_67)];
    }));

    if ((((in).kind == @as((zx_abi).zx_type_11, .List)) and ((in).target != @as((zx_abi).zx_type_16, .List)))) {
        return false;
    }

    if ((((in).kind == @as((zx_abi).zx_type_11, .Tuple)) and (((in).target != @as((zx_abi).zx_type_16, .Tuple)) or ((try function_0(allocator, block_65: {
        const operand_63 = ((&value_2)).second;
        const operand_64 = (try function_0(allocator, (in).type_id));

        if ((operand_64 >= (operand_63).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_65 (operand_63)[@intCast(operand_64)];
    })) != value_3)))) {
        return false;
    }

    if ((((in).kind == @as((zx_abi).zx_type_11, .Template)) and ((in).type_id != @as(u32, 10)))) {
        return false;
    }

    return block_62: {
        const state_type_2 = struct {
            awaits: []const u32,
            binary_left: []const u32,
            binary_operators: []const (zx_abi).zx_type_15,
            binary_right: []const u32,
            booleans: []const bool,
            call_arguments: []const u32,
            call_functions: []const u32,
            call_store_count: []const u32,
            call_store_first: []const u32,
            call_stores: []const u32,
            cancellations: []const u32,
            captures: []const u32,
            collection_arguments: []const u32,
            collection_count: []const u32,
            collection_first: []const u32,
            collection_kinds: []const (zx_abi).zx_type_12,
            collection_targets: []const u32,
            conditional_conditions: []const u32,
            conditional_no: []const u32,
            conditional_yes: []const u32,
            enumerations: []const u32,
            errors: []const u32,
            floats: []const f64,
            index_targets: []const u32,
            index_values: []const u32,
            integers: []const u64,
            iteration_bodies: []const u32,
            iteration_condition_parameters: []const u32,
            iteration_conditions: []const u32,
            iteration_initials: []const u32,
            iteration_parameters: []const u32,
            iteration_postconditions: []const bool,
            kinds: []const (zx_abi).zx_type_11,
            lengths: []const u32,
            match_conditions: []const u32,
            match_count: []const u32,
            match_fallbacks: []const u32,
            match_first: []const u32,
            match_results: []const u32,
            match_subjects: []const ?u32,
            negative_integers: []const u64,
            object_count: []const u32,
            object_evaluation_count: []const u32,
            object_evaluation_first: []const u32,
            object_evaluation_values: []const u32,
            object_field_indices: []const u32,
            object_field_values: []const u32,
            object_first: []const u32,
            optional_values: []const u32,
            parallel_count: []const u32,
            parallel_fields: []const ?u32,
            parallel_first: []const u32,
            parallel_tasks: []const u32,
            payloads: []const u32,
            projection_indices: []const u32,
            projection_targets: []const u32,
            references: []const u32,
            scope_borrows: []const bool,
            scope_count: []const u32,
            scope_first: []const u32,
            scope_results: []const u32,
            scope_symbols: []const ?u32,
            scope_values: []const u32,
            sequence_count: []const u32,
            sequence_first: []const u32,
            sequence_items: []const u32,
            some: []const u32,
            span_end: []const u64,
            span_start: []const u64,
            stores: []const u32,
            strings: []const []const u8,
            task_bodies: []const u32,
            task_capture_count: []const u32,
            task_capture_first: []const u32,
            task_captures: []const u32,
            transform_bodies: []const u32,
            transform_count: []const u32,
            transform_first: []const u32,
            transform_initials: []const ?u32,
            transform_kinds: []const (zx_abi).zx_type_13,
            transform_parameters: []const u32,
            transform_targets: []const u32,
            types: []const u32,
            unary_operands: []const u32,
            unary_operators: []const (zx_abi).zx_type_14,
            update_indices: []const u32,
            update_targets: []const u32,
            update_values: []const u32,
        };
        const state_type_3 = struct {
            input_types: []const u32,
            output_types: []const u32,
            stores: []const *const (zx_abi).zx_type_36,
        };
        const state_type_4 = struct {
            handles: []const []const u8,
            paths: []const []const u8,
            readable: []const bool,
            types: []const u32,
            writable: []const bool,
        };
        const state_type_5 = struct {
            names: []const []const u8,
            ownership: []const (zx_abi).zx_type_37,
            span_end: []const u64,
            span_start: []const u64,
            types: []const u32,
        };
        const state_type_6 = struct {
            children: []const u32,
            field_names: []const []const u8,
            field_types: []const u32,
            first: []const u32,
            kinds: []const u8,
            labels: []const []const u8,
            names: []const []const u8,
            second: []const u32,
        };
        const state_type_7 = struct {
            expressions: state_type_2,
            functions: state_type_3,
            index: u64,
            orchestration: bool,
            stores: state_type_4,
            symbols: state_type_5,
            table: state_type_6,
        };
        const state_type_8 = struct {
            context: state_type_7,
            kind: (zx_abi).zx_type_11,
            payload: u64,
            target: (zx_abi).zx_type_16,
            type_id: u32,
        };
        const state_type_9 = struct {
            check: state_type_8,
            count: u64,
            first: u64,
            index: u64,
            valid: bool,
        };
        const operand_25 = block_24: {
            const operand_12 = block_11: {
                const operand_10 = in;

                break :block_11 state_type_8{ .context = state_type_7{ .expressions = state_type_2{ .awaits = (((operand_10).context).expressions).awaits, .binary_left = (((operand_10).context).expressions).binary_left, .binary_operators = (((operand_10).context).expressions).binary_operators, .binary_right = (((operand_10).context).expressions).binary_right, .booleans = (((operand_10).context).expressions).booleans, .call_arguments = (((operand_10).context).expressions).call_arguments, .call_functions = (((operand_10).context).expressions).call_functions, .call_store_count = (((operand_10).context).expressions).call_store_count, .call_store_first = (((operand_10).context).expressions).call_store_first, .call_stores = (((operand_10).context).expressions).call_stores, .cancellations = (((operand_10).context).expressions).cancellations, .captures = (((operand_10).context).expressions).captures, .collection_arguments = (((operand_10).context).expressions).collection_arguments, .collection_count = (((operand_10).context).expressions).collection_count, .collection_first = (((operand_10).context).expressions).collection_first, .collection_kinds = (((operand_10).context).expressions).collection_kinds, .collection_targets = (((operand_10).context).expressions).collection_targets, .conditional_conditions = (((operand_10).context).expressions).conditional_conditions, .conditional_no = (((operand_10).context).expressions).conditional_no, .conditional_yes = (((operand_10).context).expressions).conditional_yes, .enumerations = (((operand_10).context).expressions).enumerations, .errors = (((operand_10).context).expressions).errors, .floats = (((operand_10).context).expressions).floats, .index_targets = (((operand_10).context).expressions).index_targets, .index_values = (((operand_10).context).expressions).index_values, .integers = (((operand_10).context).expressions).integers, .iteration_bodies = (((operand_10).context).expressions).iteration_bodies, .iteration_condition_parameters = (((operand_10).context).expressions).iteration_condition_parameters, .iteration_conditions = (((operand_10).context).expressions).iteration_conditions, .iteration_initials = (((operand_10).context).expressions).iteration_initials, .iteration_parameters = (((operand_10).context).expressions).iteration_parameters, .iteration_postconditions = (((operand_10).context).expressions).iteration_postconditions, .kinds = (((operand_10).context).expressions).kinds, .lengths = (((operand_10).context).expressions).lengths, .match_conditions = (((operand_10).context).expressions).match_conditions, .match_count = (((operand_10).context).expressions).match_count, .match_fallbacks = (((operand_10).context).expressions).match_fallbacks, .match_first = (((operand_10).context).expressions).match_first, .match_results = (((operand_10).context).expressions).match_results, .match_subjects = (((operand_10).context).expressions).match_subjects, .negative_integers = (((operand_10).context).expressions).negative_integers, .object_count = (((operand_10).context).expressions).object_count, .object_evaluation_count = (((operand_10).context).expressions).object_evaluation_count, .object_evaluation_first = (((operand_10).context).expressions).object_evaluation_first, .object_evaluation_values = (((operand_10).context).expressions).object_evaluation_values, .object_field_indices = (((operand_10).context).expressions).object_field_indices, .object_field_values = (((operand_10).context).expressions).object_field_values, .object_first = (((operand_10).context).expressions).object_first, .optional_values = (((operand_10).context).expressions).optional_values, .parallel_count = (((operand_10).context).expressions).parallel_count, .parallel_fields = (((operand_10).context).expressions).parallel_fields, .parallel_first = (((operand_10).context).expressions).parallel_first, .parallel_tasks = (((operand_10).context).expressions).parallel_tasks, .payloads = (((operand_10).context).expressions).payloads, .projection_indices = (((operand_10).context).expressions).projection_indices, .projection_targets = (((operand_10).context).expressions).projection_targets, .references = (((operand_10).context).expressions).references, .scope_borrows = (((operand_10).context).expressions).scope_borrows, .scope_count = (((operand_10).context).expressions).scope_count, .scope_first = (((operand_10).context).expressions).scope_first, .scope_results = (((operand_10).context).expressions).scope_results, .scope_symbols = (((operand_10).context).expressions).scope_symbols, .scope_values = (((operand_10).context).expressions).scope_values, .sequence_count = (((operand_10).context).expressions).sequence_count, .sequence_first = (((operand_10).context).expressions).sequence_first, .sequence_items = (((operand_10).context).expressions).sequence_items, .some = (((operand_10).context).expressions).some, .span_end = (((operand_10).context).expressions).span_end, .span_start = (((operand_10).context).expressions).span_start, .stores = (((operand_10).context).expressions).stores, .strings = (((operand_10).context).expressions).strings, .task_bodies = (((operand_10).context).expressions).task_bodies, .task_capture_count = (((operand_10).context).expressions).task_capture_count, .task_capture_first = (((operand_10).context).expressions).task_capture_first, .task_captures = (((operand_10).context).expressions).task_captures, .transform_bodies = (((operand_10).context).expressions).transform_bodies, .transform_count = (((operand_10).context).expressions).transform_count, .transform_first = (((operand_10).context).expressions).transform_first, .transform_initials = (((operand_10).context).expressions).transform_initials, .transform_kinds = (((operand_10).context).expressions).transform_kinds, .transform_parameters = (((operand_10).context).expressions).transform_parameters, .transform_targets = (((operand_10).context).expressions).transform_targets, .types = (((operand_10).context).expressions).types, .unary_operands = (((operand_10).context).expressions).unary_operands, .unary_operators = (((operand_10).context).expressions).unary_operators, .update_indices = (((operand_10).context).expressions).update_indices, .update_targets = (((operand_10).context).expressions).update_targets, .update_values = (((operand_10).context).expressions).update_values, }, .functions = state_type_3{ .input_types = (((operand_10).context).functions).input_types, .output_types = (((operand_10).context).functions).output_types, .stores = (((operand_10).context).functions).stores, }, .index = ((operand_10).context).index, .orchestration = ((operand_10).context).orchestration, .stores = state_type_4{ .handles = (((operand_10).context).stores).handles, .paths = (((operand_10).context).stores).paths, .readable = (((operand_10).context).stores).readable, .types = (((operand_10).context).stores).types, .writable = (((operand_10).context).stores).writable, }, .symbols = state_type_5{ .names = (((operand_10).context).symbols).names, .ownership = (((operand_10).context).symbols).ownership, .span_end = (((operand_10).context).symbols).span_end, .span_start = (((operand_10).context).symbols).span_start, .types = (((operand_10).context).symbols).types, }, .table = state_type_6{ .children = (((operand_10).context).table).children, .field_names = (((operand_10).context).table).field_names, .field_types = (((operand_10).context).table).field_types, .first = (((operand_10).context).table).first, .kinds = (((operand_10).context).table).kinds, .labels = (((operand_10).context).table).labels, .names = (((operand_10).context).table).names, .second = (((operand_10).context).table).second, }, }, .kind = (operand_10).kind, .payload = (operand_10).payload, .target = (operand_10).target, .type_id = (operand_10).type_id, };
            };
            const operand_20 = (try function_0(allocator, block_19: {
                const operand_17 = (block_14: {
                    const operand_13 = (&value_1);

                    break :block_14 state_type_2{ .awaits = (operand_13).awaits, .binary_left = (operand_13).binary_left, .binary_operators = (operand_13).binary_operators, .binary_right = (operand_13).binary_right, .booleans = (operand_13).booleans, .call_arguments = (operand_13).call_arguments, .call_functions = (operand_13).call_functions, .call_store_count = (operand_13).call_store_count, .call_store_first = (operand_13).call_store_first, .call_stores = (operand_13).call_stores, .cancellations = (operand_13).cancellations, .captures = (operand_13).captures, .collection_arguments = (operand_13).collection_arguments, .collection_count = (operand_13).collection_count, .collection_first = (operand_13).collection_first, .collection_kinds = (operand_13).collection_kinds, .collection_targets = (operand_13).collection_targets, .conditional_conditions = (operand_13).conditional_conditions, .conditional_no = (operand_13).conditional_no, .conditional_yes = (operand_13).conditional_yes, .enumerations = (operand_13).enumerations, .errors = (operand_13).errors, .floats = (operand_13).floats, .index_targets = (operand_13).index_targets, .index_values = (operand_13).index_values, .integers = (operand_13).integers, .iteration_bodies = (operand_13).iteration_bodies, .iteration_condition_parameters = (operand_13).iteration_condition_parameters, .iteration_conditions = (operand_13).iteration_conditions, .iteration_initials = (operand_13).iteration_initials, .iteration_parameters = (operand_13).iteration_parameters, .iteration_postconditions = (operand_13).iteration_postconditions, .kinds = (operand_13).kinds, .lengths = (operand_13).lengths, .match_conditions = (operand_13).match_conditions, .match_count = (operand_13).match_count, .match_fallbacks = (operand_13).match_fallbacks, .match_first = (operand_13).match_first, .match_results = (operand_13).match_results, .match_subjects = (operand_13).match_subjects, .negative_integers = (operand_13).negative_integers, .object_count = (operand_13).object_count, .object_evaluation_count = (operand_13).object_evaluation_count, .object_evaluation_first = (operand_13).object_evaluation_first, .object_evaluation_values = (operand_13).object_evaluation_values, .object_field_indices = (operand_13).object_field_indices, .object_field_values = (operand_13).object_field_values, .object_first = (operand_13).object_first, .optional_values = (operand_13).optional_values, .parallel_count = (operand_13).parallel_count, .parallel_fields = (operand_13).parallel_fields, .parallel_first = (operand_13).parallel_first, .parallel_tasks = (operand_13).parallel_tasks, .payloads = (operand_13).payloads, .projection_indices = (operand_13).projection_indices, .projection_targets = (operand_13).projection_targets, .references = (operand_13).references, .scope_borrows = (operand_13).scope_borrows, .scope_count = (operand_13).scope_count, .scope_first = (operand_13).scope_first, .scope_results = (operand_13).scope_results, .scope_symbols = (operand_13).scope_symbols, .scope_values = (operand_13).scope_values, .sequence_count = (operand_13).sequence_count, .sequence_first = (operand_13).sequence_first, .sequence_items = (operand_13).sequence_items, .some = (operand_13).some, .span_end = (operand_13).span_end, .span_start = (operand_13).span_start, .stores = (operand_13).stores, .strings = (operand_13).strings, .task_bodies = (operand_13).task_bodies, .task_capture_count = (operand_13).task_capture_count, .task_capture_first = (operand_13).task_capture_first, .task_captures = (operand_13).task_captures, .transform_bodies = (operand_13).transform_bodies, .transform_count = (operand_13).transform_count, .transform_first = (operand_13).transform_first, .transform_initials = (operand_13).transform_initials, .transform_kinds = (operand_13).transform_kinds, .transform_parameters = (operand_13).transform_parameters, .transform_targets = (operand_13).transform_targets, .types = (operand_13).types, .unary_operands = (operand_13).unary_operands, .unary_operators = (operand_13).unary_operators, .update_indices = (operand_13).update_indices, .update_targets = (operand_13).update_targets, .update_values = (operand_13).update_values, };
                }).sequence_first;
                const operand_18 = (block_16: {
                    const operand_15 = in;

                    break :block_16 state_type_8{ .context = state_type_7{ .expressions = state_type_2{ .awaits = (((operand_15).context).expressions).awaits, .binary_left = (((operand_15).context).expressions).binary_left, .binary_operators = (((operand_15).context).expressions).binary_operators, .binary_right = (((operand_15).context).expressions).binary_right, .booleans = (((operand_15).context).expressions).booleans, .call_arguments = (((operand_15).context).expressions).call_arguments, .call_functions = (((operand_15).context).expressions).call_functions, .call_store_count = (((operand_15).context).expressions).call_store_count, .call_store_first = (((operand_15).context).expressions).call_store_first, .call_stores = (((operand_15).context).expressions).call_stores, .cancellations = (((operand_15).context).expressions).cancellations, .captures = (((operand_15).context).expressions).captures, .collection_arguments = (((operand_15).context).expressions).collection_arguments, .collection_count = (((operand_15).context).expressions).collection_count, .collection_first = (((operand_15).context).expressions).collection_first, .collection_kinds = (((operand_15).context).expressions).collection_kinds, .collection_targets = (((operand_15).context).expressions).collection_targets, .conditional_conditions = (((operand_15).context).expressions).conditional_conditions, .conditional_no = (((operand_15).context).expressions).conditional_no, .conditional_yes = (((operand_15).context).expressions).conditional_yes, .enumerations = (((operand_15).context).expressions).enumerations, .errors = (((operand_15).context).expressions).errors, .floats = (((operand_15).context).expressions).floats, .index_targets = (((operand_15).context).expressions).index_targets, .index_values = (((operand_15).context).expressions).index_values, .integers = (((operand_15).context).expressions).integers, .iteration_bodies = (((operand_15).context).expressions).iteration_bodies, .iteration_condition_parameters = (((operand_15).context).expressions).iteration_condition_parameters, .iteration_conditions = (((operand_15).context).expressions).iteration_conditions, .iteration_initials = (((operand_15).context).expressions).iteration_initials, .iteration_parameters = (((operand_15).context).expressions).iteration_parameters, .iteration_postconditions = (((operand_15).context).expressions).iteration_postconditions, .kinds = (((operand_15).context).expressions).kinds, .lengths = (((operand_15).context).expressions).lengths, .match_conditions = (((operand_15).context).expressions).match_conditions, .match_count = (((operand_15).context).expressions).match_count, .match_fallbacks = (((operand_15).context).expressions).match_fallbacks, .match_first = (((operand_15).context).expressions).match_first, .match_results = (((operand_15).context).expressions).match_results, .match_subjects = (((operand_15).context).expressions).match_subjects, .negative_integers = (((operand_15).context).expressions).negative_integers, .object_count = (((operand_15).context).expressions).object_count, .object_evaluation_count = (((operand_15).context).expressions).object_evaluation_count, .object_evaluation_first = (((operand_15).context).expressions).object_evaluation_first, .object_evaluation_values = (((operand_15).context).expressions).object_evaluation_values, .object_field_indices = (((operand_15).context).expressions).object_field_indices, .object_field_values = (((operand_15).context).expressions).object_field_values, .object_first = (((operand_15).context).expressions).object_first, .optional_values = (((operand_15).context).expressions).optional_values, .parallel_count = (((operand_15).context).expressions).parallel_count, .parallel_fields = (((operand_15).context).expressions).parallel_fields, .parallel_first = (((operand_15).context).expressions).parallel_first, .parallel_tasks = (((operand_15).context).expressions).parallel_tasks, .payloads = (((operand_15).context).expressions).payloads, .projection_indices = (((operand_15).context).expressions).projection_indices, .projection_targets = (((operand_15).context).expressions).projection_targets, .references = (((operand_15).context).expressions).references, .scope_borrows = (((operand_15).context).expressions).scope_borrows, .scope_count = (((operand_15).context).expressions).scope_count, .scope_first = (((operand_15).context).expressions).scope_first, .scope_results = (((operand_15).context).expressions).scope_results, .scope_symbols = (((operand_15).context).expressions).scope_symbols, .scope_values = (((operand_15).context).expressions).scope_values, .sequence_count = (((operand_15).context).expressions).sequence_count, .sequence_first = (((operand_15).context).expressions).sequence_first, .sequence_items = (((operand_15).context).expressions).sequence_items, .some = (((operand_15).context).expressions).some, .span_end = (((operand_15).context).expressions).span_end, .span_start = (((operand_15).context).expressions).span_start, .stores = (((operand_15).context).expressions).stores, .strings = (((operand_15).context).expressions).strings, .task_bodies = (((operand_15).context).expressions).task_bodies, .task_capture_count = (((operand_15).context).expressions).task_capture_count, .task_capture_first = (((operand_15).context).expressions).task_capture_first, .task_captures = (((operand_15).context).expressions).task_captures, .transform_bodies = (((operand_15).context).expressions).transform_bodies, .transform_count = (((operand_15).context).expressions).transform_count, .transform_first = (((operand_15).context).expressions).transform_first, .transform_initials = (((operand_15).context).expressions).transform_initials, .transform_kinds = (((operand_15).context).expressions).transform_kinds, .transform_parameters = (((operand_15).context).expressions).transform_parameters, .transform_targets = (((operand_15).context).expressions).transform_targets, .types = (((operand_15).context).expressions).types, .unary_operands = (((operand_15).context).expressions).unary_operands, .unary_operators = (((operand_15).context).expressions).unary_operators, .update_indices = (((operand_15).context).expressions).update_indices, .update_targets = (((operand_15).context).expressions).update_targets, .update_values = (((operand_15).context).expressions).update_values, }, .functions = state_type_3{ .input_types = (((operand_15).context).functions).input_types, .output_types = (((operand_15).context).functions).output_types, .stores = (((operand_15).context).functions).stores, }, .index = ((operand_15).context).index, .orchestration = ((operand_15).context).orchestration, .stores = state_type_4{ .handles = (((operand_15).context).stores).handles, .paths = (((operand_15).context).stores).paths, .readable = (((operand_15).context).stores).readable, .types = (((operand_15).context).stores).types, .writable = (((operand_15).context).stores).writable, }, .symbols = state_type_5{ .names = (((operand_15).context).symbols).names, .ownership = (((operand_15).context).symbols).ownership, .span_end = (((operand_15).context).symbols).span_end, .span_start = (((operand_15).context).symbols).span_start, .types = (((operand_15).context).symbols).types, }, .table = state_type_6{ .children = (((operand_15).context).table).children, .field_names = (((operand_15).context).table).field_names, .field_types = (((operand_15).context).table).field_types, .first = (((operand_15).context).table).first, .kinds = (((operand_15).context).table).kinds, .labels = (((operand_15).context).table).labels, .names = (((operand_15).context).table).names, .second = (((operand_15).context).table).second, }, }, .kind = (operand_15).kind, .payload = (operand_15).payload, .target = (operand_15).target, .type_id = (operand_15).type_id, };
                }).payload;

                if ((operand_18 >= (operand_17).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_19 (operand_17)[@intCast(operand_18)];
            }));
            const operand_21 = value_3;
            const operand_22 = @as(u64, 0);
            const operand_23 = true;

            break :block_24 state_type_9{ .check = operand_12, .first = operand_20, .count = operand_21, .index = operand_22, .valid = operand_23, };
        };
        const state_type_39 = struct {
            expressions: state_type_2,
            id: u32,
            index: u64,
            type_id: u32,
        };

        var state_1: state_type_9 = operand_25;

        var state_changed_26 = false;

        while (((state_1).valid and ((state_1).index < (state_1).count))) {
            state_1 = block_61: {
                const value_6: state_type_8 = (state_1).check;
                const value_7: state_type_7 = (value_6).context;
                const value_8: state_type_6 = (value_7).table;
                const value_9: u32 = block_60: {
                    const operand_58 = ((value_7).expressions).sequence_items;
                    const operand_59 = ((state_1).first + (state_1).index);

                    if ((operand_59 >= (operand_58).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_60 (operand_58)[@intCast(operand_59)];
                };
                const value_10: u32 = block_57: {
                    const operand_55 = (value_8).first;
                    const operand_56 = (try function_0(allocator, (value_6).type_id));

                    if ((operand_56 >= (operand_55).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_57 (operand_55)[@intCast(operand_56)];
                };
                const value_18: state_type_9 = (if (((value_6).kind == @as((zx_abi).zx_type_11, .Template))) block_38: {
                    const value_11: u64 = (try function_0(allocator, value_9));
                    const value_15: state_type_9 = (if ((value_11 >= (value_7).index)) block_29: {
                        const value_12: state_type_9 = block_28: {
                            break :block_28 state_type_9{ .check = (state_1).check, .count = (state_1).count, .first = (state_1).first, .index = (state_1).index, .valid = false, };
                        };

                        break :block_29 value_12;
                    } else block_37: {
                        const value_13: u32 = block_36: {
                            const operand_34 = ((value_7).expressions).types;
                            const operand_35 = value_11;

                            if ((operand_35 >= (operand_34).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_36 (operand_34)[@intCast(operand_35)];
                        };
                        const value_14: state_type_9 = block_33: {
                            break :block_33 state_type_9{ .check = (state_1).check, .count = (state_1).count, .first = (state_1).first, .index = (state_1).index, .valid = ((value_13 != @as(u32, 0)) and ((try function_9(allocator, block_32: {
                                const operand_30 = (value_8).kinds;
                                const operand_31 = (try function_0(allocator, value_13));

                                if ((operand_31 >= (operand_30).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_32 (operand_30)[@intCast(operand_31)];
                            })) == @as((zx_abi).zx_type_16, .Scalar))), };
                        };

                        break :block_37 value_14;
                    });

                    break :block_38 value_15;
                } else block_54: {
                    const value_16: u32 = (if (((value_6).kind == @as((zx_abi).zx_type_11, .List))) value_10 else block_53: {
                        const operand_51 = (value_8).children;
                        const operand_52 = ((try function_0(allocator, value_10)) + (state_1).index);

                        if ((operand_52 >= (operand_51).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_53 (operand_51)[@intCast(operand_52)];
                    });
                    const value_17: state_type_9 = block_50: {
                        break :block_50 state_type_9{ .check = (state_1).check, .count = (state_1).count, .first = (state_1).first, .index = (state_1).index, .valid = block_49: {
                            const operand_45 = block_44: {
                                const operand_40 = (value_7).expressions;
                                const operand_41 = (value_7).index;
                                const operand_42 = value_9;
                                const operand_43 = value_16;

                                break :block_44 state_type_39{ .expressions = operand_40, .index = operand_41, .id = operand_42, .type_id = operand_43, };
                            };
                            const operand_46 = (zx_abi).zx_type_34{ .awaits = ((operand_45).expressions).awaits, .binary_left = ((operand_45).expressions).binary_left, .binary_operators = ((operand_45).expressions).binary_operators, .binary_right = ((operand_45).expressions).binary_right, .booleans = ((operand_45).expressions).booleans, .call_arguments = ((operand_45).expressions).call_arguments, .call_functions = ((operand_45).expressions).call_functions, .call_store_count = ((operand_45).expressions).call_store_count, .call_store_first = ((operand_45).expressions).call_store_first, .call_stores = ((operand_45).expressions).call_stores, .cancellations = ((operand_45).expressions).cancellations, .captures = ((operand_45).expressions).captures, .collection_arguments = ((operand_45).expressions).collection_arguments, .collection_count = ((operand_45).expressions).collection_count, .collection_first = ((operand_45).expressions).collection_first, .collection_kinds = ((operand_45).expressions).collection_kinds, .collection_targets = ((operand_45).expressions).collection_targets, .conditional_conditions = ((operand_45).expressions).conditional_conditions, .conditional_no = ((operand_45).expressions).conditional_no, .conditional_yes = ((operand_45).expressions).conditional_yes, .enumerations = ((operand_45).expressions).enumerations, .errors = ((operand_45).expressions).errors, .floats = ((operand_45).expressions).floats, .index_targets = ((operand_45).expressions).index_targets, .index_values = ((operand_45).expressions).index_values, .integers = ((operand_45).expressions).integers, .iteration_bodies = ((operand_45).expressions).iteration_bodies, .iteration_condition_parameters = ((operand_45).expressions).iteration_condition_parameters, .iteration_conditions = ((operand_45).expressions).iteration_conditions, .iteration_initials = ((operand_45).expressions).iteration_initials, .iteration_parameters = ((operand_45).expressions).iteration_parameters, .iteration_postconditions = ((operand_45).expressions).iteration_postconditions, .kinds = ((operand_45).expressions).kinds, .lengths = ((operand_45).expressions).lengths, .match_conditions = ((operand_45).expressions).match_conditions, .match_count = ((operand_45).expressions).match_count, .match_fallbacks = ((operand_45).expressions).match_fallbacks, .match_first = ((operand_45).expressions).match_first, .match_results = ((operand_45).expressions).match_results, .match_subjects = ((operand_45).expressions).match_subjects, .negative_integers = ((operand_45).expressions).negative_integers, .object_count = ((operand_45).expressions).object_count, .object_evaluation_count = ((operand_45).expressions).object_evaluation_count, .object_evaluation_first = ((operand_45).expressions).object_evaluation_first, .object_evaluation_values = ((operand_45).expressions).object_evaluation_values, .object_field_indices = ((operand_45).expressions).object_field_indices, .object_field_values = ((operand_45).expressions).object_field_values, .object_first = ((operand_45).expressions).object_first, .optional_values = ((operand_45).expressions).optional_values, .parallel_count = ((operand_45).expressions).parallel_count, .parallel_fields = ((operand_45).expressions).parallel_fields, .parallel_first = ((operand_45).expressions).parallel_first, .parallel_tasks = ((operand_45).expressions).parallel_tasks, .payloads = ((operand_45).expressions).payloads, .projection_indices = ((operand_45).expressions).projection_indices, .projection_targets = ((operand_45).expressions).projection_targets, .references = ((operand_45).expressions).references, .scope_borrows = ((operand_45).expressions).scope_borrows, .scope_count = ((operand_45).expressions).scope_count, .scope_first = ((operand_45).expressions).scope_first, .scope_results = ((operand_45).expressions).scope_results, .scope_symbols = ((operand_45).expressions).scope_symbols, .scope_values = ((operand_45).expressions).scope_values, .sequence_count = ((operand_45).expressions).sequence_count, .sequence_first = ((operand_45).expressions).sequence_first, .sequence_items = ((operand_45).expressions).sequence_items, .some = ((operand_45).expressions).some, .span_end = ((operand_45).expressions).span_end, .span_start = ((operand_45).expressions).span_start, .stores = ((operand_45).expressions).stores, .strings = ((operand_45).expressions).strings, .task_bodies = ((operand_45).expressions).task_bodies, .task_capture_count = ((operand_45).expressions).task_capture_count, .task_capture_first = ((operand_45).expressions).task_capture_first, .task_captures = ((operand_45).expressions).task_captures, .transform_bodies = ((operand_45).expressions).transform_bodies, .transform_count = ((operand_45).expressions).transform_count, .transform_first = ((operand_45).expressions).transform_first, .transform_initials = ((operand_45).expressions).transform_initials, .transform_kinds = ((operand_45).expressions).transform_kinds, .transform_parameters = ((operand_45).expressions).transform_parameters, .transform_targets = ((operand_45).expressions).transform_targets, .types = ((operand_45).expressions).types, .unary_operands = ((operand_45).expressions).unary_operands, .unary_operators = ((operand_45).expressions).unary_operators, .update_indices = ((operand_45).expressions).update_indices, .update_targets = ((operand_45).expressions).update_targets, .update_values = ((operand_45).expressions).update_values, };
                            const operand_47 = (zx_abi).zx_type_35{ .expressions = (&operand_46), .id = (operand_45).id, .index = (operand_45).index, .type_id = (operand_45).type_id, };
                            const operand_48 = (try function_10(allocator, (&operand_47)));

                            break :block_49 operand_48;
                        }, };
                    };

                    break :block_54 value_17;
                });
                const value_19: u64 = (value_18).index;
                const value_20: state_type_9 = block_27: {
                    break :block_27 state_type_9{ .check = (value_18).check, .count = (value_18).count, .first = (value_18).first, .index = (value_19 + @as(u64, 1)), .valid = (value_18).valid, };
                };

                break :block_61 value_20;
            };

            state_changed_26 = true;
        }

        break :block_62 (state_1).valid;
    };
}

fn function_26(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;
    const value_3: (zx_abi).zx_type_20 = (((&value_1)).table).*;

    if (((in).kind == @as((zx_abi).zx_type_11, .Task))) {
        if ((((in).target != @as((zx_abi).zx_type_16, .Task)) or (!block_122: {
            const operand_111 = (&value_2);
            const operand_112 = ((&value_1)).index;
            const operand_116 = block_115: {
                const operand_113 = ((&value_2)).task_bodies;
                const operand_114 = (in).payload;

                if ((operand_114 >= (operand_113).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_115 (operand_113)[@intCast(operand_114)];
            };
            const operand_120 = block_119: {
                const operand_117 = ((&value_3)).first;
                const operand_118 = (try function_0(allocator, (in).type_id));

                if ((operand_118 >= (operand_117).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_119 (operand_117)[@intCast(operand_118)];
            };
            const operand_121 = (zx_abi).zx_type_35{ .expressions = operand_111, .index = operand_112, .id = operand_116, .type_id = operand_120, };

            break :block_122 (try function_10(allocator, (&operand_121)));
        }))) {
            return false;
        }

        return block_110: {
            const operand_70 = block_69: {
                const operand_58 = (&value_1);
                const operand_59 = (try function_0(allocator, block_62: {
                    const operand_60 = ((&value_2)).task_capture_first;
                    const operand_61 = (in).payload;

                    if ((operand_61 >= (operand_60).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_62 (operand_60)[@intCast(operand_61)];
                }));
                const operand_63 = (try function_0(allocator, block_66: {
                    const operand_64 = ((&value_2)).task_capture_count;
                    const operand_65 = (in).payload;

                    if ((operand_65 >= (operand_64).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_66 (operand_64)[@intCast(operand_65)];
                }));
                const operand_67 = @as(u64, 0);
                const operand_68 = true;

                break :block_69 (zx_abi).zx_type_52{ .context = operand_58, .first = operand_59, .count = operand_63, .index = operand_67, .valid = operand_68, };
            };

            var state_57: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159{ .expressions = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (((operand_70).context).expressions).awaits, .binary_left = (((operand_70).context).expressions).binary_left, .binary_operators = (((operand_70).context).expressions).binary_operators, .binary_right = (((operand_70).context).expressions).binary_right, .booleans = (((operand_70).context).expressions).booleans, .call_arguments = (((operand_70).context).expressions).call_arguments, .call_functions = (((operand_70).context).expressions).call_functions, .call_store_count = (((operand_70).context).expressions).call_store_count, .call_store_first = (((operand_70).context).expressions).call_store_first, .call_stores = (((operand_70).context).expressions).call_stores, .cancellations = (((operand_70).context).expressions).cancellations, .captures = (((operand_70).context).expressions).captures, .collection_arguments = (((operand_70).context).expressions).collection_arguments, .collection_count = (((operand_70).context).expressions).collection_count, .collection_first = (((operand_70).context).expressions).collection_first, .collection_kinds = (((operand_70).context).expressions).collection_kinds, .collection_targets = (((operand_70).context).expressions).collection_targets, .conditional_conditions = (((operand_70).context).expressions).conditional_conditions, .conditional_no = (((operand_70).context).expressions).conditional_no, .conditional_yes = (((operand_70).context).expressions).conditional_yes, .enumerations = (((operand_70).context).expressions).enumerations, .errors = (((operand_70).context).expressions).errors, .floats = (((operand_70).context).expressions).floats, .index_targets = (((operand_70).context).expressions).index_targets, .index_values = (((operand_70).context).expressions).index_values, .integers = (((operand_70).context).expressions).integers, .iteration_bodies = (((operand_70).context).expressions).iteration_bodies, .iteration_condition_parameters = (((operand_70).context).expressions).iteration_condition_parameters, .iteration_conditions = (((operand_70).context).expressions).iteration_conditions, .iteration_initials = (((operand_70).context).expressions).iteration_initials, .iteration_parameters = (((operand_70).context).expressions).iteration_parameters, .iteration_postconditions = (((operand_70).context).expressions).iteration_postconditions, .kinds = (((operand_70).context).expressions).kinds, .lengths = (((operand_70).context).expressions).lengths, .match_conditions = (((operand_70).context).expressions).match_conditions, .match_count = (((operand_70).context).expressions).match_count, .match_fallbacks = (((operand_70).context).expressions).match_fallbacks, .match_first = (((operand_70).context).expressions).match_first, .match_results = (((operand_70).context).expressions).match_results, .match_subjects = (((operand_70).context).expressions).match_subjects, .negative_integers = (((operand_70).context).expressions).negative_integers, .object_count = (((operand_70).context).expressions).object_count, .object_evaluation_count = (((operand_70).context).expressions).object_evaluation_count, .object_evaluation_first = (((operand_70).context).expressions).object_evaluation_first, .object_evaluation_values = (((operand_70).context).expressions).object_evaluation_values, .object_field_indices = (((operand_70).context).expressions).object_field_indices, .object_field_values = (((operand_70).context).expressions).object_field_values, .object_first = (((operand_70).context).expressions).object_first, .optional_values = (((operand_70).context).expressions).optional_values, .parallel_count = (((operand_70).context).expressions).parallel_count, .parallel_fields = (((operand_70).context).expressions).parallel_fields, .parallel_first = (((operand_70).context).expressions).parallel_first, .parallel_tasks = (((operand_70).context).expressions).parallel_tasks, .payloads = (((operand_70).context).expressions).payloads, .projection_indices = (((operand_70).context).expressions).projection_indices, .projection_targets = (((operand_70).context).expressions).projection_targets, .references = (((operand_70).context).expressions).references, .scope_borrows = (((operand_70).context).expressions).scope_borrows, .scope_count = (((operand_70).context).expressions).scope_count, .scope_first = (((operand_70).context).expressions).scope_first, .scope_results = (((operand_70).context).expressions).scope_results, .scope_symbols = (((operand_70).context).expressions).scope_symbols, .scope_values = (((operand_70).context).expressions).scope_values, .sequence_count = (((operand_70).context).expressions).sequence_count, .sequence_first = (((operand_70).context).expressions).sequence_first, .sequence_items = (((operand_70).context).expressions).sequence_items, .some = (((operand_70).context).expressions).some, .span_end = (((operand_70).context).expressions).span_end, .span_start = (((operand_70).context).expressions).span_start, .stores = (((operand_70).context).expressions).stores, .strings = (((operand_70).context).expressions).strings, .task_bodies = (((operand_70).context).expressions).task_bodies, .task_capture_count = (((operand_70).context).expressions).task_capture_count, .task_capture_first = (((operand_70).context).expressions).task_capture_first, .task_captures = (((operand_70).context).expressions).task_captures, .transform_bodies = (((operand_70).context).expressions).transform_bodies, .transform_count = (((operand_70).context).expressions).transform_count, .transform_first = (((operand_70).context).expressions).transform_first, .transform_initials = (((operand_70).context).expressions).transform_initials, .transform_kinds = (((operand_70).context).expressions).transform_kinds, .transform_parameters = (((operand_70).context).expressions).transform_parameters, .transform_targets = (((operand_70).context).expressions).transform_targets, .types = (((operand_70).context).expressions).types, .unary_operands = (((operand_70).context).expressions).unary_operands, .unary_operators = (((operand_70).context).expressions).unary_operators, .update_indices = (((operand_70).context).expressions).update_indices, .update_targets = (((operand_70).context).expressions).update_targets, .update_values = (((operand_70).context).expressions).update_values, .zx_origin = ((operand_70).context).expressions, }, .functions = (zx_abi).value_zx_type_41_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .input_types = (((operand_70).context).functions).input_types, .output_types = (((operand_70).context).functions).output_types, .stores = (((operand_70).context).functions).stores, .zx_origin = ((operand_70).context).functions, }, .index = ((operand_70).context).index, .orchestration = ((operand_70).context).orchestration, .stores = ((operand_70).context).stores, .symbols = (zx_abi).value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((operand_70).context).symbols).names, .ownership = (((operand_70).context).symbols).ownership, .span_end = (((operand_70).context).symbols).span_end, .span_start = (((operand_70).context).symbols).span_start, .types = (((operand_70).context).symbols).types, .zx_origin = ((operand_70).context).symbols, }, .table = (zx_abi).value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_70).context).table).children, .field_names = (((operand_70).context).table).field_names, .field_types = (((operand_70).context).table).field_types, .first = (((operand_70).context).table).first, .kinds = (((operand_70).context).table).kinds, .labels = (((operand_70).context).table).labels, .names = (((operand_70).context).table).names, .second = (((operand_70).context).table).second, .zx_origin = ((operand_70).context).table, }, .zx_origin = (operand_70).context, }, .count = (operand_70).count, .first = (operand_70).first, .index = (operand_70).index, .valid = (operand_70).valid, .zx_origin = (&operand_70), };

            while (((state_57).valid and ((state_57).index < (state_57).count))) {
                state_57 = block_109: {
                    const value_6: (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159 = (state_57).context;
                    const value_7: u32 = block_108: {
                        const operand_106 = ((value_6).expressions).task_captures;
                        const operand_107 = ((state_57).first + (state_57).index);

                        if ((operand_107 >= (operand_106).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_108 (operand_106)[@intCast(operand_107)];
                    };
                    const value_8: u64 = (try function_0(allocator, block_105: {
                        break :block_105 value_7;
                    }));
                    const value_17: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = (if (((block_73: {
                        break :block_73 value_8;
                    } >= @as(u64, (((value_6).symbols).types).len)) or ((try function_9(allocator, block_80: {
                        const operand_78 = ((value_6).table).kinds;
                        const operand_79 = (try function_0(allocator, block_77: {
                            const operand_75 = ((value_6).symbols).types;
                            const operand_76 = block_74: {
                                break :block_74 value_8;
                            };

                            if ((operand_76 >= (operand_75).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_77 (operand_75)[@intCast(operand_76)];
                        }));

                        if ((operand_79 >= (operand_78).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_80 (operand_78)[@intCast(operand_79)];
                    })) == @as((zx_abi).zx_type_16, .Task)))) block_82: {
                        const value_9: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = block_81: {
                            break :block_81 @as((zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c, (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (state_57).context, .count = (state_57).count, .first = (state_57).first, .index = (state_57).index, .valid = false, });
                        };

                        break :block_82 value_9;
                    } else block_104: {
                        const value_15: (zx_abi).value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_103: {
                            const operand_93 = block_92: {
                                const operand_85 = ((value_6).expressions).task_captures;
                                const operand_86 = (state_57).first;
                                const operand_87 = (state_57).index;
                                const operand_88 = block_89: {
                                    break :block_89 value_7;
                                };
                                const operand_90 = @as(u64, 0);
                                const operand_91 = false;

                                break :block_92 @as((zx_abi).value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .captures = operand_85, .first = operand_86, .limit = operand_87, .symbol = operand_88, .index = operand_90, .found = operand_91, });
                            };

                            var state_84: (zx_abi).value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = operand_93;

                            var state_changed_94 = false;

                            while (((!(state_84).found) and ((state_84).index < (state_84).limit))) {
                                state_84 = block_101: {
                                    const value_12: (zx_abi).value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_100: {
                                        break :block_100 @as((zx_abi).value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .captures = (state_84).captures, .first = (state_84).first, .found = (block_99: {
                                            const operand_97 = (state_84).captures;
                                            const operand_98 = ((state_84).first + (state_84).index);

                                            if ((operand_98 >= (operand_97).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            break :block_99 (operand_97)[@intCast(operand_98)];
                                        } == (state_84).symbol), .index = (state_84).index, .limit = (state_84).limit, .symbol = (state_84).symbol, });
                                    };
                                    const value_13: u64 = (value_12).index;
                                    const value_14: (zx_abi).value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_96: {
                                        break :block_96 @as((zx_abi).value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .captures = (value_12).captures, .first = (value_12).first, .found = (value_12).found, .index = (block_95: {
                                            break :block_95 value_13;
                                        } + @as(u64, 1)), .limit = (value_12).limit, .symbol = (value_12).symbol, });
                                    };

                                    break :block_101 value_14;
                                };

                                state_changed_94 = true;
                            }

                            break :block_103 (if (state_changed_94) state_84 else operand_93);
                        };
                        const value_16: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = block_83: {
                            break :block_83 @as((zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c, (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (state_57).context, .count = (state_57).count, .first = (state_57).first, .index = (state_57).index, .valid = (!(value_15).found), });
                        };

                        break :block_104 value_16;
                    });
                    const value_18: u64 = (value_17).index;
                    const value_19: (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = block_72: {
                        break :block_72 @as((zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c, (zx_abi).value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c{ .context = (value_17).context, .count = (value_17).count, .first = (value_17).first, .index = (block_71: {
                            break :block_71 value_18;
                        } + @as(u64, 1)), .valid = (value_17).valid, });
                    };

                    break :block_109 value_19;
                };
            }

            break :block_110 (state_57).valid;
        };
    }

    const value_21: u32 = block_56: {
        const operand_46 = (in).kind;

        break :block_56 (if ((operand_46 == @as((zx_abi).zx_type_11, .AwaitTask))) block_55: {
            const operand_53 = ((&value_2)).awaits;
            const operand_54 = (in).payload;

            if ((operand_54 >= (operand_53).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_55 (operand_53)[@intCast(operand_54)];
        } else (if ((operand_46 == @as((zx_abi).zx_type_11, .CancelTask))) block_52: {
            const operand_50 = ((&value_2)).cancellations;
            const operand_51 = (in).payload;

            if ((operand_51 >= (operand_50).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_52 (operand_50)[@intCast(operand_51)];
        } else block_49: {
            const operand_47 = ((&value_2)).captures;
            const operand_48 = (in).payload;

            if ((operand_48 >= (operand_47).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_49 (operand_47)[@intCast(operand_48)];
        }));
    };
    const value_22: u64 = (try function_0(allocator, value_21));

    if ((value_22 >= ((&value_1)).index)) {
        return false;
    }

    const value_23: u32 = block_45: {
        const operand_43 = ((&value_2)).types;
        const operand_44 = value_22;

        if ((operand_44 >= (operand_43).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_45 (operand_43)[@intCast(operand_44)];
    };
    const value_24: u64 = (try function_0(allocator, value_23));

    if (((in).kind == @as((zx_abi).zx_type_11, .AwaitTask))) {
        return (((try function_9(allocator, block_39: {
            const operand_37 = ((&value_3)).kinds;
            const operand_38 = value_24;

            if ((operand_38 >= (operand_37).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_39 (operand_37)[@intCast(operand_38)];
        })) == @as((zx_abi).zx_type_16, .Task)) and (block_42: {
            const operand_40 = ((&value_3)).first;
            const operand_41 = value_24;

            if ((operand_41 >= (operand_40).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_42 (operand_40)[@intCast(operand_41)];
        } == (in).type_id));
    }

    if (((in).kind == @as((zx_abi).zx_type_11, .CancelTask))) {
        return (((in).type_id == @as(u32, 0)) and ((try function_9(allocator, block_36: {
            const operand_34 = ((&value_3)).kinds;
            const operand_35 = value_24;

            if ((operand_35 >= (operand_34).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_36 (operand_34)[@intCast(operand_35)];
        })) == @as((zx_abi).zx_type_16, .Task)));
    }

    const value_25: u64 = (try function_0(allocator, (in).type_id));

    if ((((in).target != @as((zx_abi).zx_type_16, .Tuple)) or (block_33: {
        const operand_31 = ((&value_3)).second;
        const operand_32 = value_25;

        if ((operand_32 >= (operand_31).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_33 (operand_31)[@intCast(operand_32)];
    } != @as(u32, 2)))) {
        return false;
    }

    const value_26: u64 = (try function_0(allocator, block_30: {
        const operand_28 = ((&value_3)).first;
        const operand_29 = value_25;

        if ((operand_29 >= (operand_28).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_30 (operand_28)[@intCast(operand_29)];
    }));
    const value_27: u64 = (try function_0(allocator, block_27: {
        const operand_25 = ((&value_3)).children;
        const operand_26 = value_26;

        if ((operand_26 >= (operand_25).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_27 (operand_25)[@intCast(operand_26)];
    }));
    const value_28: u32 = block_24: {
        const operand_22 = ((&value_3)).children;
        const operand_23 = (value_26 + @as(u64, 1));

        if ((operand_23 >= (operand_22).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_24 (operand_22)[@intCast(operand_23)];
    };

    if ((((try function_9(allocator, block_15: {
        const operand_13 = ((&value_3)).kinds;
        const operand_14 = value_27;

        if ((operand_14 >= (operand_13).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_15 (operand_13)[@intCast(operand_14)];
    })) != @as((zx_abi).zx_type_16, .Optional)) or ((try function_9(allocator, block_21: {
        const operand_19 = ((&value_3)).kinds;
        const operand_20 = (try function_0(allocator, block_18: {
            const operand_16 = ((&value_3)).first;
            const operand_17 = value_27;

            if ((operand_17 >= (operand_16).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_18 (operand_16)[@intCast(operand_17)];
        }));

        if ((operand_20 >= (operand_19).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_21 (operand_19)[@intCast(operand_20)];
    })) != @as((zx_abi).zx_type_16, .ErrorSet)))) {
        return false;
    }

    return (if ((value_23 == @as(u32, 0))) (value_28 == @as(u32, 0)) else (((try function_9(allocator, block_3: {
        const operand_1 = ((&value_3)).kinds;
        const operand_2 = (try function_0(allocator, value_28));

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    })) == @as((zx_abi).zx_type_16, .Optional)) and block_12: {
        const operand_4 = (&value_2);
        const operand_5 = ((&value_1)).index;
        const operand_6 = value_21;
        const operand_10 = block_9: {
            const operand_7 = ((&value_3)).first;
            const operand_8 = (try function_0(allocator, value_28));

            if ((operand_8 >= (operand_7).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_9 (operand_7)[@intCast(operand_8)];
        };
        const operand_11 = (zx_abi).zx_type_35{ .expressions = operand_4, .index = operand_5, .id = operand_6, .type_id = operand_10, };

        break :block_12 (try function_10(allocator, (&operand_11)));
    }));
}

fn function_27(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_42 = ((in).context).*;
    const value_2: (zx_abi).zx_type_34 = (((&value_1)).expressions).*;
    const value_3: (zx_abi).zx_type_20 = (((&value_1)).table).*;
    const value_4: u64 = (try function_0(allocator, block_109: {
        const operand_107 = ((&value_2)).transform_targets;
        const operand_108 = (in).payload;

        if ((operand_108 >= (operand_107).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_109 (operand_107)[@intCast(operand_108)];
    }));
    const value_5: u32 = block_106: {
        const operand_104 = ((&value_2)).transform_bodies;
        const operand_105 = (in).payload;

        if ((operand_105 >= (operand_104).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_106 (operand_104)[@intCast(operand_105)];
    };

    if (((value_4 >= ((&value_1)).index) or ((try function_0(allocator, value_5)) >= ((&value_1)).index))) {
        return false;
    }

    const value_6: u32 = block_103: {
        const operand_101 = ((&value_2)).types;
        const operand_102 = value_4;

        if ((operand_102 >= (operand_101).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_103 (operand_101)[@intCast(operand_102)];
    };
    const value_7: u64 = (try function_0(allocator, value_6));
    const value_8: (zx_abi).zx_type_13 = block_100: {
        const operand_98 = ((&value_2)).transform_kinds;
        const operand_99 = (in).payload;

        if ((operand_99 >= (operand_98).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_100 (operand_98)[@intCast(operand_99)];
    };
    const value_9: u64 = (try function_0(allocator, block_97: {
        const operand_95 = ((&value_2)).transform_count;
        const operand_96 = (in).payload;

        if ((operand_96 >= (operand_95).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_97 (operand_95)[@intCast(operand_96)];
    }));
    const value_10: ?u32 = block_94: {
        const operand_92 = ((&value_2)).transform_initials;
        const operand_93 = (in).payload;

        if ((operand_93 >= (operand_92).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_94 (operand_92)[@intCast(operand_93)];
    };

    if (((value_10 != null) and ((try function_0(allocator, value_10.?)) >= ((&value_1)).index))) {
        return false;
    }

    if ((((value_10 != null) and (value_8 != @as((zx_abi).zx_type_13, .Reduce))) and ((try function_9(allocator, block_91: {
        const operand_89 = ((&value_3)).kinds;
        const operand_90 = (try function_0(allocator, block_88: {
            const operand_86 = ((&value_2)).types;
            const operand_87 = (try function_0(allocator, value_10.?));

            if ((operand_87 >= (operand_86).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_88 (operand_86)[@intCast(operand_87)];
        }));

        if ((operand_90 >= (operand_89).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_91 (operand_89)[@intCast(operand_90)];
    })) == @as((zx_abi).zx_type_16, .Task)))) {
        return false;
    }

    if (((value_8 == @as((zx_abi).zx_type_13, .Reduce)) and (value_10 == null))) {
        return false;
    }

    if ((((try function_9(allocator, block_85: {
        const operand_83 = ((&value_3)).kinds;
        const operand_84 = value_7;

        if ((operand_84 >= (operand_83).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_85 (operand_83)[@intCast(operand_84)];
    })) != @as((zx_abi).zx_type_16, .List)) or (value_9 != (if ((value_10 != null)) @as(u64, 2) else @as(u64, 1))))) {
        return false;
    }

    const value_19: (zx_abi).zx_type_60 = block_82: {
        const operand_55 = block_54: {
            const operand_37 = (&value_1);
            const operand_38 = (try function_0(allocator, block_41: {
                const operand_39 = ((&value_2)).transform_first;
                const operand_40 = (in).payload;

                if ((operand_40 >= (operand_39).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_41 (operand_39)[@intCast(operand_40)];
            }));
            const operand_42 = value_9;
            const operand_43 = value_8;
            const operand_44 = (if ((value_10 != null)) block_47: {
                const operand_45 = ((&value_2)).types;
                const operand_46 = (try function_0(allocator, value_10.?));

                if ((operand_46 >= (operand_45).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_47 (operand_45)[@intCast(operand_46)];
            } else @as(u32, 0));
            const operand_48 = block_51: {
                const operand_49 = ((&value_3)).first;
                const operand_50 = value_7;

                if ((operand_50 >= (operand_49).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_51 (operand_49)[@intCast(operand_50)];
            };
            const operand_52 = @as(u64, 0);
            const operand_53 = true;

            break :block_54 (zx_abi).zx_type_60{ .context = operand_37, .first = operand_38, .count = operand_42, .operation = operand_43, .context_type = operand_44, .element = operand_48, .index = operand_52, .valid = operand_53, };
        };

        var state_36: (zx_abi).value_zx_type_60_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef = (zx_abi).value_zx_type_60_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef{ .context = (zx_abi).value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159{ .expressions = (zx_abi).value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (((operand_55).context).expressions).awaits, .binary_left = (((operand_55).context).expressions).binary_left, .binary_operators = (((operand_55).context).expressions).binary_operators, .binary_right = (((operand_55).context).expressions).binary_right, .booleans = (((operand_55).context).expressions).booleans, .call_arguments = (((operand_55).context).expressions).call_arguments, .call_functions = (((operand_55).context).expressions).call_functions, .call_store_count = (((operand_55).context).expressions).call_store_count, .call_store_first = (((operand_55).context).expressions).call_store_first, .call_stores = (((operand_55).context).expressions).call_stores, .cancellations = (((operand_55).context).expressions).cancellations, .captures = (((operand_55).context).expressions).captures, .collection_arguments = (((operand_55).context).expressions).collection_arguments, .collection_count = (((operand_55).context).expressions).collection_count, .collection_first = (((operand_55).context).expressions).collection_first, .collection_kinds = (((operand_55).context).expressions).collection_kinds, .collection_targets = (((operand_55).context).expressions).collection_targets, .conditional_conditions = (((operand_55).context).expressions).conditional_conditions, .conditional_no = (((operand_55).context).expressions).conditional_no, .conditional_yes = (((operand_55).context).expressions).conditional_yes, .enumerations = (((operand_55).context).expressions).enumerations, .errors = (((operand_55).context).expressions).errors, .floats = (((operand_55).context).expressions).floats, .index_targets = (((operand_55).context).expressions).index_targets, .index_values = (((operand_55).context).expressions).index_values, .integers = (((operand_55).context).expressions).integers, .iteration_bodies = (((operand_55).context).expressions).iteration_bodies, .iteration_condition_parameters = (((operand_55).context).expressions).iteration_condition_parameters, .iteration_conditions = (((operand_55).context).expressions).iteration_conditions, .iteration_initials = (((operand_55).context).expressions).iteration_initials, .iteration_parameters = (((operand_55).context).expressions).iteration_parameters, .iteration_postconditions = (((operand_55).context).expressions).iteration_postconditions, .kinds = (((operand_55).context).expressions).kinds, .lengths = (((operand_55).context).expressions).lengths, .match_conditions = (((operand_55).context).expressions).match_conditions, .match_count = (((operand_55).context).expressions).match_count, .match_fallbacks = (((operand_55).context).expressions).match_fallbacks, .match_first = (((operand_55).context).expressions).match_first, .match_results = (((operand_55).context).expressions).match_results, .match_subjects = (((operand_55).context).expressions).match_subjects, .negative_integers = (((operand_55).context).expressions).negative_integers, .object_count = (((operand_55).context).expressions).object_count, .object_evaluation_count = (((operand_55).context).expressions).object_evaluation_count, .object_evaluation_first = (((operand_55).context).expressions).object_evaluation_first, .object_evaluation_values = (((operand_55).context).expressions).object_evaluation_values, .object_field_indices = (((operand_55).context).expressions).object_field_indices, .object_field_values = (((operand_55).context).expressions).object_field_values, .object_first = (((operand_55).context).expressions).object_first, .optional_values = (((operand_55).context).expressions).optional_values, .parallel_count = (((operand_55).context).expressions).parallel_count, .parallel_fields = (((operand_55).context).expressions).parallel_fields, .parallel_first = (((operand_55).context).expressions).parallel_first, .parallel_tasks = (((operand_55).context).expressions).parallel_tasks, .payloads = (((operand_55).context).expressions).payloads, .projection_indices = (((operand_55).context).expressions).projection_indices, .projection_targets = (((operand_55).context).expressions).projection_targets, .references = (((operand_55).context).expressions).references, .scope_borrows = (((operand_55).context).expressions).scope_borrows, .scope_count = (((operand_55).context).expressions).scope_count, .scope_first = (((operand_55).context).expressions).scope_first, .scope_results = (((operand_55).context).expressions).scope_results, .scope_symbols = (((operand_55).context).expressions).scope_symbols, .scope_values = (((operand_55).context).expressions).scope_values, .sequence_count = (((operand_55).context).expressions).sequence_count, .sequence_first = (((operand_55).context).expressions).sequence_first, .sequence_items = (((operand_55).context).expressions).sequence_items, .some = (((operand_55).context).expressions).some, .span_end = (((operand_55).context).expressions).span_end, .span_start = (((operand_55).context).expressions).span_start, .stores = (((operand_55).context).expressions).stores, .strings = (((operand_55).context).expressions).strings, .task_bodies = (((operand_55).context).expressions).task_bodies, .task_capture_count = (((operand_55).context).expressions).task_capture_count, .task_capture_first = (((operand_55).context).expressions).task_capture_first, .task_captures = (((operand_55).context).expressions).task_captures, .transform_bodies = (((operand_55).context).expressions).transform_bodies, .transform_count = (((operand_55).context).expressions).transform_count, .transform_first = (((operand_55).context).expressions).transform_first, .transform_initials = (((operand_55).context).expressions).transform_initials, .transform_kinds = (((operand_55).context).expressions).transform_kinds, .transform_parameters = (((operand_55).context).expressions).transform_parameters, .transform_targets = (((operand_55).context).expressions).transform_targets, .types = (((operand_55).context).expressions).types, .unary_operands = (((operand_55).context).expressions).unary_operands, .unary_operators = (((operand_55).context).expressions).unary_operators, .update_indices = (((operand_55).context).expressions).update_indices, .update_targets = (((operand_55).context).expressions).update_targets, .update_values = (((operand_55).context).expressions).update_values, .zx_origin = ((operand_55).context).expressions, }, .functions = (zx_abi).value_zx_type_41_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .input_types = (((operand_55).context).functions).input_types, .output_types = (((operand_55).context).functions).output_types, .stores = (((operand_55).context).functions).stores, .zx_origin = ((operand_55).context).functions, }, .index = ((operand_55).context).index, .orchestration = ((operand_55).context).orchestration, .stores = ((operand_55).context).stores, .symbols = (zx_abi).value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((operand_55).context).symbols).names, .ownership = (((operand_55).context).symbols).ownership, .span_end = (((operand_55).context).symbols).span_end, .span_start = (((operand_55).context).symbols).span_start, .types = (((operand_55).context).symbols).types, .zx_origin = ((operand_55).context).symbols, }, .table = (zx_abi).value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_55).context).table).children, .field_names = (((operand_55).context).table).field_names, .field_types = (((operand_55).context).table).field_types, .first = (((operand_55).context).table).first, .kinds = (((operand_55).context).table).kinds, .labels = (((operand_55).context).table).labels, .names = (((operand_55).context).table).names, .second = (((operand_55).context).table).second, .zx_origin = ((operand_55).context).table, }, .zx_origin = (operand_55).context, }, .context_type = (operand_55).context_type, .count = (operand_55).count, .element = (operand_55).element, .first = (operand_55).first, .index = (operand_55).index, .operation = (operand_55).operation, .valid = (operand_55).valid, .zx_origin = (&operand_55), };

        while (((state_36).valid and ((state_36).index < (state_36).count))) {
            state_36 = block_69: {
                const value_13: u64 = (try function_0(allocator, block_68: {
                    const operand_66 = (((state_36).context).expressions).transform_parameters;
                    const operand_67 = ((state_36).first + (state_36).index);

                    if ((operand_67 >= (operand_66).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_68 (operand_66)[@intCast(operand_67)];
                }));
                const value_14: u64 = (if (((state_36).operation == @as((zx_abi).zx_type_13, .Reduce))) @as(u64, 0) else @as(u64, 1));
                const value_15: u32 = (if (((state_36).index == block_65: {
                    break :block_65 value_14;
                })) (state_36).context_type else (state_36).element);
                const value_16: (zx_abi).value_zx_type_60_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef = block_64: {
                    break :block_64 @as((zx_abi).value_zx_type_60_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef, (zx_abi).value_zx_type_60_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef{ .context = (state_36).context, .context_type = (state_36).context_type, .count = (state_36).count, .element = (state_36).element, .first = (state_36).first, .index = (state_36).index, .operation = (state_36).operation, .valid = ((block_58: {
                        break :block_58 value_13;
                    } < @as(u64, ((((state_36).context).symbols).types).len)) and (block_62: {
                        const operand_60 = (((state_36).context).symbols).types;
                        const operand_61 = block_59: {
                            break :block_59 value_13;
                        };

                        if ((operand_61 >= (operand_60).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_62 (operand_60)[@intCast(operand_61)];
                    } == block_63: {
                        break :block_63 value_15;
                    })), });
                };
                const value_17: u64 = (value_16).index;
                const value_18: (zx_abi).value_zx_type_60_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef = block_57: {
                    break :block_57 @as((zx_abi).value_zx_type_60_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef, (zx_abi).value_zx_type_60_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef{ .context = (value_16).context, .context_type = (value_16).context_type, .count = (value_16).count, .element = (value_16).element, .first = (value_16).first, .index = (block_56: {
                        break :block_56 value_17;
                    } + @as(u64, 1)), .operation = (value_16).operation, .valid = (value_16).valid, });
                };

                break :block_69 value_18;
            };
        }

        break :block_82 block_81: {
            break :block_81 (if (((state_36).zx_origin != null)) ((state_36).zx_origin.?).* else block_80: {
                break :block_80 (zx_abi).zx_type_60{ .context = (if ((((state_36).context).zx_origin != null)) ((state_36).context).zx_origin.? else block_79: {
                    const operand_78 = (try (allocator).create((zx_abi).zx_type_42));

                    (operand_78).* = (zx_abi).zx_type_42{ .expressions = (if (((((state_36).context).expressions).zx_origin != null)) (((state_36).context).expressions).zx_origin.? else block_71: {
                        const operand_70 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_70).* = (zx_abi).zx_type_34{ .awaits = (((state_36).context).expressions).awaits, .binary_left = (((state_36).context).expressions).binary_left, .binary_operators = (((state_36).context).expressions).binary_operators, .binary_right = (((state_36).context).expressions).binary_right, .booleans = (((state_36).context).expressions).booleans, .call_arguments = (((state_36).context).expressions).call_arguments, .call_functions = (((state_36).context).expressions).call_functions, .call_store_count = (((state_36).context).expressions).call_store_count, .call_store_first = (((state_36).context).expressions).call_store_first, .call_stores = (((state_36).context).expressions).call_stores, .cancellations = (((state_36).context).expressions).cancellations, .captures = (((state_36).context).expressions).captures, .collection_arguments = (((state_36).context).expressions).collection_arguments, .collection_count = (((state_36).context).expressions).collection_count, .collection_first = (((state_36).context).expressions).collection_first, .collection_kinds = (((state_36).context).expressions).collection_kinds, .collection_targets = (((state_36).context).expressions).collection_targets, .conditional_conditions = (((state_36).context).expressions).conditional_conditions, .conditional_no = (((state_36).context).expressions).conditional_no, .conditional_yes = (((state_36).context).expressions).conditional_yes, .enumerations = (((state_36).context).expressions).enumerations, .errors = (((state_36).context).expressions).errors, .floats = (((state_36).context).expressions).floats, .index_targets = (((state_36).context).expressions).index_targets, .index_values = (((state_36).context).expressions).index_values, .integers = (((state_36).context).expressions).integers, .iteration_bodies = (((state_36).context).expressions).iteration_bodies, .iteration_condition_parameters = (((state_36).context).expressions).iteration_condition_parameters, .iteration_conditions = (((state_36).context).expressions).iteration_conditions, .iteration_initials = (((state_36).context).expressions).iteration_initials, .iteration_parameters = (((state_36).context).expressions).iteration_parameters, .iteration_postconditions = (((state_36).context).expressions).iteration_postconditions, .kinds = (((state_36).context).expressions).kinds, .lengths = (((state_36).context).expressions).lengths, .match_conditions = (((state_36).context).expressions).match_conditions, .match_count = (((state_36).context).expressions).match_count, .match_fallbacks = (((state_36).context).expressions).match_fallbacks, .match_first = (((state_36).context).expressions).match_first, .match_results = (((state_36).context).expressions).match_results, .match_subjects = (((state_36).context).expressions).match_subjects, .negative_integers = (((state_36).context).expressions).negative_integers, .object_count = (((state_36).context).expressions).object_count, .object_evaluation_count = (((state_36).context).expressions).object_evaluation_count, .object_evaluation_first = (((state_36).context).expressions).object_evaluation_first, .object_evaluation_values = (((state_36).context).expressions).object_evaluation_values, .object_field_indices = (((state_36).context).expressions).object_field_indices, .object_field_values = (((state_36).context).expressions).object_field_values, .object_first = (((state_36).context).expressions).object_first, .optional_values = (((state_36).context).expressions).optional_values, .parallel_count = (((state_36).context).expressions).parallel_count, .parallel_fields = (((state_36).context).expressions).parallel_fields, .parallel_first = (((state_36).context).expressions).parallel_first, .parallel_tasks = (((state_36).context).expressions).parallel_tasks, .payloads = (((state_36).context).expressions).payloads, .projection_indices = (((state_36).context).expressions).projection_indices, .projection_targets = (((state_36).context).expressions).projection_targets, .references = (((state_36).context).expressions).references, .scope_borrows = (((state_36).context).expressions).scope_borrows, .scope_count = (((state_36).context).expressions).scope_count, .scope_first = (((state_36).context).expressions).scope_first, .scope_results = (((state_36).context).expressions).scope_results, .scope_symbols = (((state_36).context).expressions).scope_symbols, .scope_values = (((state_36).context).expressions).scope_values, .sequence_count = (((state_36).context).expressions).sequence_count, .sequence_first = (((state_36).context).expressions).sequence_first, .sequence_items = (((state_36).context).expressions).sequence_items, .some = (((state_36).context).expressions).some, .span_end = (((state_36).context).expressions).span_end, .span_start = (((state_36).context).expressions).span_start, .stores = (((state_36).context).expressions).stores, .strings = (((state_36).context).expressions).strings, .task_bodies = (((state_36).context).expressions).task_bodies, .task_capture_count = (((state_36).context).expressions).task_capture_count, .task_capture_first = (((state_36).context).expressions).task_capture_first, .task_captures = (((state_36).context).expressions).task_captures, .transform_bodies = (((state_36).context).expressions).transform_bodies, .transform_count = (((state_36).context).expressions).transform_count, .transform_first = (((state_36).context).expressions).transform_first, .transform_initials = (((state_36).context).expressions).transform_initials, .transform_kinds = (((state_36).context).expressions).transform_kinds, .transform_parameters = (((state_36).context).expressions).transform_parameters, .transform_targets = (((state_36).context).expressions).transform_targets, .types = (((state_36).context).expressions).types, .unary_operands = (((state_36).context).expressions).unary_operands, .unary_operators = (((state_36).context).expressions).unary_operators, .update_indices = (((state_36).context).expressions).update_indices, .update_targets = (((state_36).context).expressions).update_targets, .update_values = (((state_36).context).expressions).update_values, };

                        break :block_71 @as(*const (zx_abi).zx_type_34, operand_70);
                    }), .functions = (if (((((state_36).context).functions).zx_origin != null)) (((state_36).context).functions).zx_origin.? else block_73: {
                        const operand_72 = (try (allocator).create((zx_abi).zx_type_41));

                        (operand_72).* = (zx_abi).zx_type_41{ .input_types = (((state_36).context).functions).input_types, .output_types = (((state_36).context).functions).output_types, .stores = (((state_36).context).functions).stores, };

                        break :block_73 @as(*const (zx_abi).zx_type_41, operand_72);
                    }), .index = ((state_36).context).index, .orchestration = ((state_36).context).orchestration, .stores = ((state_36).context).stores, .symbols = (if (((((state_36).context).symbols).zx_origin != null)) (((state_36).context).symbols).zx_origin.? else block_75: {
                        const operand_74 = (try (allocator).create((zx_abi).zx_type_39));

                        (operand_74).* = (zx_abi).zx_type_39{ .names = (((state_36).context).symbols).names, .ownership = (((state_36).context).symbols).ownership, .span_end = (((state_36).context).symbols).span_end, .span_start = (((state_36).context).symbols).span_start, .types = (((state_36).context).symbols).types, };

                        break :block_75 @as(*const (zx_abi).zx_type_39, operand_74);
                    }), .table = (if (((((state_36).context).table).zx_origin != null)) (((state_36).context).table).zx_origin.? else block_77: {
                        const operand_76 = (try (allocator).create((zx_abi).zx_type_20));

                        (operand_76).* = (zx_abi).zx_type_20{ .children = (((state_36).context).table).children, .field_names = (((state_36).context).table).field_names, .field_types = (((state_36).context).table).field_types, .first = (((state_36).context).table).first, .kinds = (((state_36).context).table).kinds, .labels = (((state_36).context).table).labels, .names = (((state_36).context).table).names, .second = (((state_36).context).table).second, };

                        break :block_77 @as(*const (zx_abi).zx_type_20, operand_76);
                    }), };

                    break :block_79 @as(*const (zx_abi).zx_type_42, operand_78);
                }), .context_type = (state_36).context_type, .count = (state_36).count, .element = (state_36).element, .first = (state_36).first, .index = (state_36).index, .operation = (state_36).operation, .valid = (state_36).valid, };
            });
        };
    };

    if ((!((&value_19)).valid)) {
        return false;
    }

    return block_35: {
        const operand_1 = value_8;

        break :block_35 (if ((operand_1 == @as((zx_abi).zx_type_13, .Map))) (((in).target == @as((zx_abi).zx_type_16, .List)) and block_34: {
            const operand_26 = (&value_2);
            const operand_27 = ((&value_1)).index;
            const operand_28 = value_5;
            const operand_32 = block_31: {
                const operand_29 = ((&value_3)).first;
                const operand_30 = (try function_0(allocator, (in).type_id));

                if ((operand_30 >= (operand_29).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_31 (operand_29)[@intCast(operand_30)];
            };
            const operand_33 = (zx_abi).zx_type_35{ .expressions = operand_26, .index = operand_27, .id = operand_28, .type_id = operand_32, };

            break :block_34 (try function_10(allocator, (&operand_33)));
        }) else (if ((operand_1 == @as((zx_abi).zx_type_13, .Filter))) (((in).type_id == value_6) and block_25: {
            const operand_20 = (&value_2);
            const operand_21 = ((&value_1)).index;
            const operand_22 = value_5;
            const operand_23 = @as(u32, 1);
            const operand_24 = (zx_abi).zx_type_35{ .expressions = operand_20, .index = operand_21, .id = operand_22, .type_id = operand_23, };

            break :block_25 (try function_10(allocator, (&operand_24)));
        }) else (if ((operand_1 == @as((zx_abi).zx_type_13, .Reduce))) (((value_10 != null) and block_13: {
            const operand_8 = (&value_2);
            const operand_9 = ((&value_1)).index;
            const operand_10 = value_10.?;
            const operand_11 = (in).type_id;
            const operand_12 = (zx_abi).zx_type_35{ .expressions = operand_8, .index = operand_9, .id = operand_10, .type_id = operand_11, };

            break :block_13 (try function_10(allocator, (&operand_12)));
        }) and block_19: {
            const operand_14 = (&value_2);
            const operand_15 = ((&value_1)).index;
            const operand_16 = value_5;
            const operand_17 = (in).type_id;
            const operand_18 = (zx_abi).zx_type_35{ .expressions = operand_14, .index = operand_15, .id = operand_16, .type_id = operand_17, };

            break :block_19 (try function_10(allocator, (&operand_18)));
        }) else (((in).type_id == @as(u32, 1)) and block_7: {
            const operand_2 = (&value_2);
            const operand_3 = ((&value_1)).index;
            const operand_4 = value_5;
            const operand_5 = @as(u32, 1);
            const operand_6 = (zx_abi).zx_type_35{ .expressions = operand_2, .index = operand_3, .id = operand_4, .type_id = operand_5, };

            break :block_7 (try function_10(allocator, (&operand_6)));
        }))));
    };
}

fn function_28(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_42) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if (((in).index >= @as(u64, (((in).expressions).types).len))) {
        return false;
    }

    const value_1: u32 = block_20: {
        const operand_18 = ((in).expressions).types;
        const operand_19 = (in).index;

        if ((operand_19 >= (operand_18).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_20 (operand_18)[@intCast(operand_19)];
    };

    if (((try function_0(allocator, value_1)) >= @as(u64, (((in).table).kinds).len))) {
        return false;
    }

    const value_2: (zx_abi).zx_type_16 = (try function_9(allocator, block_17: {
        const operand_15 = ((in).table).kinds;
        const operand_16 = (try function_0(allocator, value_1));

        if ((operand_16 >= (operand_15).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_17 (operand_15)[@intCast(operand_16)];
    }));
    const value_3: (zx_abi).zx_type_11 = block_14: {
        const operand_12 = ((in).expressions).kinds;
        const operand_13 = (in).index;

        if ((operand_13 >= (operand_12).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_14 (operand_12)[@intCast(operand_13)];
    };

    if ((((value_2 == @as((zx_abi).zx_type_16, .Task)) and (value_3 != @as((zx_abi).zx_type_11, .Task))) and (value_3 != @as((zx_abi).zx_type_11, .Reference)))) {
        return false;
    }

    const value_4: (zx_abi).zx_type_43 = block_11: {
        const operand_3 = in;
        const operand_4 = value_1;
        const operand_5 = value_2;
        const operand_6 = value_3;
        const operand_7 = (try function_0(allocator, block_10: {
            const operand_8 = ((in).expressions).payloads;
            const operand_9 = (in).index;

            if ((operand_9 >= (operand_8).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_10 (operand_8)[@intCast(operand_9)];
        }));

        break :block_11 (zx_abi).zx_type_43{ .context = operand_3, .type_id = operand_4, .target = operand_5, .kind = operand_6, .payload = operand_7, };
    };

    return block_2: {
        const operand_1 = value_3;

        break :block_2 (if ((operand_1 == @as((zx_abi).zx_type_11, .Some))) (try function_11(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .OptionalValue))) (try function_11(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Field))) (try function_11(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .TupleField))) (try function_11(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Index))) (try function_11(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Length))) (try function_11(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Task))) (try function_26(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .AwaitTask))) (try function_26(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .CancelTask))) (try function_26(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Capture))) (try function_26(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Parallel))) (try function_23(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .List))) (try function_25(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Tuple))) (try function_25(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Template))) (try function_25(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Object))) (try function_19(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Unary))) (try function_22(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Binary))) (try function_22(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Conditional))) (try function_17(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Match))) (try function_17(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Call))) (try function_16(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Transform))) (try function_27(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Iteration))) (try function_18(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .ListUpdate))) (try function_18(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .Scope))) (try function_24(allocator, (&value_4))) else (if ((operand_1 == @as((zx_abi).zx_type_11, .ListOperation))) (try function_20(allocator, (&value_4))) else (try function_13(allocator, (&value_4))))))))))))))))))))))))))));
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_42) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = (try function_28(allocator, in));

    return value_1;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_42) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: bool = (try function_28(allocator, in));

    return value_1;
}

