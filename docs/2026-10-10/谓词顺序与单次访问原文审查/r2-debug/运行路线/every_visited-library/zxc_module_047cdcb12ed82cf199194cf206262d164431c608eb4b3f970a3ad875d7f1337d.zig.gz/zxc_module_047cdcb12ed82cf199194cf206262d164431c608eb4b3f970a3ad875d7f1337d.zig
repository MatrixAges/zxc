const std = @import("std");

const zx_abi = @import("zxc_abi");

pub fn call(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_29e983954018f5dbae2f2b502992cb534b81928d5ac5d5d98c5278a95f8d0629) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    return block_22: {
        const value_4: []const i64 = (try (@import("zxc_module_596a952d9c1cf71e5895d72c9087c8fbee84dd7771078fb2055892e0250a8842")).call(allocator, (in).items));

        _ = (try (@import("zxc_module_9ed43fc1add206b8f20937b26a69d143c33f6bae49d4ae6a9a841484e74703ab")).call(allocator, {}));

        break :block_22 block_21: {
            const operand_6 = block_5: {
                const operand_2 = value_4;
                const operand_3 = @as(u64, 0);
                const operand_4 = true;

                break :block_5 (zx_abi).zx_type_6f29b97f56d4db3bd751242185c40590ad842b5ab153a6fcca934f711870a621{ .index = operand_3, .result = operand_4, .source = operand_2, };
            };

            var state_1: (zx_abi).zx_type_6f29b97f56d4db3bd751242185c40590ad842b5ab153a6fcca934f711870a621 = operand_6;

            while (((((&state_1)).index < @as(u64, (((&state_1)).source).len)) and ((&state_1)).result)) {
                state_1 = block_20: {
                    const value_7: i64 = block_19: {
                        const operand_17 = ((&state_1)).source;
                        const operand_18 = ((&state_1)).index;

                        if ((operand_18 >= (operand_17).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_19 (operand_17)[@intCast(operand_18)];
                    };
                    const value_1: i64 = value_7;
                    const value_2: u64 = ((&state_1)).index;
                    const value_3: []const i64 = ((&state_1)).source;
                    const value_8: bool = (try (@import("zxc_module_0cf8054b54b15895b231725d26bdf734e3ffcb997c8cfd7e561e067bb9353833")).call(allocator, block_16: {
                        const operand_11 = value_1;
                        const operand_12 = value_2;
                        const operand_13 = value_3;

                        break :block_16 block_15: {
                            const operand_14 = (try (allocator).create((zx_abi).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054));

                            (operand_14).* = @as((zx_abi).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054, (zx_abi).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054{ .item = operand_11, .index = operand_12, .source = operand_13, });

                            break :block_15 @as(*const (zx_abi).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054, operand_14);
                        };
                    }));

                    break :block_20 block_10: {
                        const operand_7 = ((&state_1)).source;
                        const operand_8 = (((&state_1)).index + @as(u64, 1));
                        const operand_9 = value_8;

                        break :block_10 (zx_abi).zx_type_6f29b97f56d4db3bd751242185c40590ad842b5ab153a6fcca934f711870a621{ .index = operand_8, .result = operand_9, .source = operand_7, };
                    };
                };
            }

            break :block_21 (state_1).result;
        };
    };
}

