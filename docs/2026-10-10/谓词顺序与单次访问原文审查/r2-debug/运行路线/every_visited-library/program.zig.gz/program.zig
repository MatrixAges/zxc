const std = @import("std");

const zx_abi = @import("zxc_abi");

pub const Input = *const (zx_abi).zx_type_29e983954018f5dbae2f2b502992cb534b81928d5ac5d5d98c5278a95f8d0629;

pub const Output = bool;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_7, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .item = zx_shape_7, .source = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .items = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_1, .source = zx_shape_11, }, };

pub const input_shape = zx_shape_13;

pub const output_shape = zx_shape_1;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_29e983954018f5dbae2f2b502992cb534b81928d5ac5d5d98c5278a95f8d0629) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();

    return (try (@import("zxc_module_047cdcb12ed82cf199194cf206262d164431c608eb4b3f970a3ad875d7f1337d")).call(allocator, in));
}

