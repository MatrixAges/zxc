const std = @import("std");

const zx_abi = @import("zxc_abi");

pub const Input = *const (zx_abi).zx_type_29e983954018f5dbae2f2b502992cb534b81928d5ac5d5d98c5278a95f8d0629;

pub const Output = bool;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_7, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .item = zx_shape_7, .source = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .items = zx_shape_11, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .result = zx_shape_1, .source = zx_shape_11, }, };

pub const input_shape = zx_shape_13;

pub const output_shape = zx_shape_1;

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_29e983954018f5dbae2f2b502992cb534b81928d5ac5d5d98c5278a95f8d0629) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();

    return block_22: {
        const value_4: []const i64 = (try (@import("zxc_module_f375141af5fd2808029eb479aa3c5fe5e052cfe106264f6a2a4307cdd0069069")).call(allocator, (in).items));

        break :block_22 block_21: {
            const operand_6 = block_5: {
                const operand_2 = value_4;
                const operand_3 = @as(u64, 0);
                const operand_4 = false;

                break :block_5 (zx_abi).zx_type_6f29b97f56d4db3bd751242185c40590ad842b5ab153a6fcca934f711870a621{ .index = operand_3, .result = operand_4, .source = operand_2, };
            };

            var state_1: (zx_abi).zx_type_6f29b97f56d4db3bd751242185c40590ad842b5ab153a6fcca934f711870a621 = operand_6;

            while (((((&state_1)).index < @as(u64, (((&state_1)).source).len)) and (!((&state_1)).result))) {
                state_1 = block_20: {
                    const value_7: i64 = block_19: {
                        const operand_17 = ((&state_1)).source;
                        const operand_18 = ((&state_1)).index;

                        if ((operand_18 >= (operand_17).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_19 (operand_17)[@intCast(operand_18)];
                    };
                    const value_1: i64 = value_7;
                    const value_2: u64 = ((&state_1)).index;
                    const value_3: []const i64 = ((&state_1)).source;
                    const value_8: bool = (try (@import("zxc_module_49c76b273d2ed7e815e61aaa71e4644f3565aee79de36b120bdf0b824dc5c601")).call(allocator, block_16: {
                        const operand_11 = value_1;
                        const operand_12 = value_2;
                        const operand_13 = value_3;

                        break :block_16 block_15: {
                            const operand_14 = (try (allocator).create((zx_abi).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054));

                            (operand_14).* = @as((zx_abi).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054, (zx_abi).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054{ .item = operand_11, .index = operand_12, .source = operand_13, });

                            break :block_15 @as(*const (zx_abi).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054, operand_14);
                        };
                    }));

                    break :block_20 block_10: {
                        const operand_7 = ((&state_1)).source;
                        const operand_8 = (((&state_1)).index + @as(u64, 1));
                        const operand_9 = value_8;

                        break :block_10 (zx_abi).zx_type_6f29b97f56d4db3bd751242185c40590ad842b5ab153a6fcca934f711870a621{ .index = operand_8, .result = operand_9, .source = operand_7, };
                    };
                };
            }

            break :block_21 (state_1).result;
        };
    };
}

