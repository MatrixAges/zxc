const std = @import("std");

const zx_abi = @import("zxc_abi");

const zx_native = @import("library_native_548342be9273bad8c4760e8d54cb1f8c7458a71351c177953725e1b8a55cdc8b");

pub fn call(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054) error{ }!bool {
    const native_result = (zx_native).visit(in);

    _ = allocator;

    return native_result;
}

