pub const method: enum { map, filter, every, some } = .some;
