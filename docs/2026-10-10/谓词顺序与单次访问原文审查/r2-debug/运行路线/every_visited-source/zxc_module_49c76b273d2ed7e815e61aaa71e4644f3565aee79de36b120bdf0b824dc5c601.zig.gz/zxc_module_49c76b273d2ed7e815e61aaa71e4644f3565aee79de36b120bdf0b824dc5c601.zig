const std = @import("std");

const zx_abi = @import("zxc_abi");

const zx_native = @import("host");

pub fn call(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_55e4e85410968e1de74bac15e77b76c6010e9a63b00ae8bbb22514bf9b6c5054) error{ }!bool {
    const native_result = (zx_native).visit(in);

    _ = allocator;

    return native_result;
}

