const std = @import("std");

const zx_abi = @import("zxc_abi");

const zx_native = @import("host");

pub fn call(allocator: ((std).mem).Allocator, in: void) error{ }!void {
    _ = in;

    const native_result = (zx_native).context();

    _ = allocator;

    return native_result;
}

