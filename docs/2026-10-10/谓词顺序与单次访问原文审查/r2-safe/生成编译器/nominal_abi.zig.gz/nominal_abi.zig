pub const zx_type_11 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_15 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_16 = struct {
    base: *const zx_type_15,
    delta: *const zx_type_15,
};

pub const zx_type_17 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_18 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    second: u32,
};

pub const zx_type_19 = struct {
    children: []const u32,
    fields: *const zx_type_17,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_20 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_21 = struct {
    delta: *const zx_type_15,
    id: u32,
};

pub const zx_type_22 = struct {
    children: []const u32,
    count: u64,
    field_names: []const []const u8,
    field_types: []const u32,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    names: []const []const u8,
    offset: u64,
    second: u32,
};

pub const zx_type_23 = struct {
    left: *const zx_type_22,
    right: *const zx_type_22,
};

pub const zx_type_24 = struct {
    index: u64,
    table: *const zx_type_15,
};

pub const zx_type_25 = struct {
    candidate: *const zx_type_19,
    id: u32,
    tables: *const zx_type_16,
};

pub const zx_type_26 = struct {
    id: u32,
    tables: *const zx_type_16,
};

pub const zx_type_27 = enum { Missing, Found, Conflict, };

pub const zx_type_28 = struct {
    id: u32,
    status: zx_type_27,
};

pub const zx_type_29 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
};

pub const zx_type_30 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
};

pub const zx_type_31 = struct {
    base: *const zx_type_30,
    delta: *const zx_type_30,
};

pub const zx_type_32 = struct {
    candidate: *const zx_type_19,
    origin: *const zx_type_29,
    origins: *const zx_type_31,
    tables: *const zx_type_16,
};

pub const zx_type_33 = struct {
    equal: bool,
    index: u64,
    left: *const zx_type_22,
    right: *const zx_type_22,
};

pub const zx_type_34 = struct {
    candidate: *const zx_type_19,
    count: u64,
    id: u32,
    index: u64,
    origin: *const zx_type_29,
    origins: *const zx_type_31,
    status: zx_type_27,
    tables: *const zx_type_16,
};

pub const zx_type_35 = struct { *const zx_type_32, };

pub const zx_type_36 = struct { *const zx_type_32, *const zx_type_28, };

pub const zx_type_37 = struct { *const zx_type_32, *const zx_type_28, u64, };

pub const value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
    zx_origin: ?*const zx_type_15 = null,
};

pub const value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9 = struct {
    base: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    delta: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_18 = null,
};

pub const value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_21_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922 = struct {
    delta: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    id: u32,
    zx_origin: ?*const zx_type_21 = null,
};

pub const value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d = struct {
    children: []const u32,
    count: u64,
    field_names: []const []const u8,
    field_types: []const u32,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    names: []const []const u8,
    offset: u64,
    second: u32,
    zx_origin: ?*const zx_type_22 = null,
};

pub const value_zx_type_23_6f975b180818098029dbaef75bb89bfea5e3cb89ee69a1d9370d1963760c4a33 = struct {
    left: value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    right: value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_23 = null,
};

pub const value_zx_type_24_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77 = struct {
    index: u64,
    table: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_24 = null,
};

pub const value_zx_type_25_0034dce8c9365af25a54326f547e187efea37df5125c62a42d8291d0d5df0ebf = struct {
    candidate: value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    id: u32,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    zx_origin: ?*const zx_type_25 = null,
};

pub const value_zx_type_26_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d = struct {
    id: u32,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    zx_origin: ?*const zx_type_26 = null,
};

pub const value_zx_type_28_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    id: u32,
    status: zx_type_27,
    zx_origin: ?*const zx_type_28 = null,
};

pub const value_zx_type_29_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    kind: u8,
    member: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_29 = null,
};

pub const value_zx_type_30_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    ids: []const u32,
    kinds: []const u8,
    members: []const []const u8,
    owners: []const []const u8,
    zx_origin: ?*const zx_type_30 = null,
};

pub const value_zx_type_31_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53 = struct {
    base: value_zx_type_30_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    delta: value_zx_type_30_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_31 = null,
};

pub const value_zx_type_32_bd208de60d840cfc787ebffb6ff5afe0f3ea76a39636b572313b962e7b4577de = struct {
    candidate: value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    origin: value_zx_type_29_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_31_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    zx_origin: ?*const zx_type_32 = null,
};

pub const value_zx_type_33_713639bf2340277cb2fc17b55239d7eafff49067cfedc85ab5bd099cd1d4078d = struct {
    equal: bool,
    index: u64,
    left: value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    right: value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d,
    zx_origin: ?*const zx_type_33 = null,
};

pub const value_zx_type_34_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01 = struct {
    candidate: value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384,
    count: u64,
    id: u32,
    index: u64,
    origin: value_zx_type_29_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    origins: value_zx_type_31_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53,
    status: zx_type_27,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    zx_origin: ?*const zx_type_34 = null,
};

pub const value_zx_type_35_124aae66a63ebe315b481482164e9d4de034a3f222611f4fc8219b7863b3570d = struct { value_zx_type_32_bd208de60d840cfc787ebffb6ff5afe0f3ea76a39636b572313b962e7b4577de, ?*const zx_type_35, };

pub const value_zx_type_36_5cc8934297f0b67ca34c0b80af07908e232652ab99eaba3eadbc3cc233a85ea0 = struct { value_zx_type_32_bd208de60d840cfc787ebffb6ff5afe0f3ea76a39636b572313b962e7b4577de, value_zx_type_28_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, ?*const zx_type_36, };

pub const value_zx_type_37_2c7aae1ca593fc92025c3afab8e2f75ee02659c73d5a4bb7b30775baa9982563 = struct { value_zx_type_32_bd208de60d840cfc787ebffb6ff5afe0f3ea76a39636b572313b962e7b4577de, value_zx_type_28_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, u64, ?*const zx_type_37, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
};

