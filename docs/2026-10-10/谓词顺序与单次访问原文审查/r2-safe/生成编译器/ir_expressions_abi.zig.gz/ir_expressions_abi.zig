pub const zx_type_11 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_12 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_13 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_14 = enum { Negate, Not, };

pub const zx_type_15 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_16 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_20 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_21 = struct {
    base: *const zx_type_20,
    delta: *const zx_type_20,
};

pub const zx_type_22 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_23 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_16,
    label: []const u8,
    second: u32,
};

pub const zx_type_34 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_15,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_12,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_11,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_13,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_14,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_35 = struct {
    expressions: *const zx_type_34,
    id: u32,
    index: u64,
    type_id: u32,
};

pub const zx_type_36 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_37 = enum { Copy, Borrowed, Owned, };

pub const zx_type_39 = struct {
    names: []const []const u8,
    ownership: []const zx_type_37,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_41 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_36,
};

pub const zx_type_42 = struct {
    expressions: *const zx_type_34,
    functions: *const zx_type_41,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_36,
    symbols: *const zx_type_39,
    table: *const zx_type_20,
};

pub const zx_type_43 = struct {
    context: *const zx_type_42,
    kind: zx_type_11,
    payload: u64,
    target: zx_type_16,
    type_id: u32,
};

pub const zx_type_44 = enum { Other, Integer, Signed, Float, };

pub const zx_type_47 = struct {
    available: *const zx_type_36,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_36,
    slots: []const u32,
};

pub const zx_type_48 = struct {
    table: *const zx_type_20,
    type_id: u32,
};

pub const zx_type_49 = struct {
    available: *const zx_type_36,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_36,
    slots: []const u32,
    valid: bool,
};

pub const zx_type_50 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
};

pub const zx_type_51 = struct {
    condition_type: u32,
    context: *const zx_type_42,
    count: u64,
    first: u64,
    index: u64,
    result_type: u32,
    valid: bool,
};

pub const zx_type_52 = struct {
    context: *const zx_type_42,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_53 = struct {
    context: *const zx_type_42,
    count: u64,
    first: u64,
    index: u64,
    type_first: u64,
    valid: bool,
};

pub const zx_type_54 = struct {
    field: u64,
    first: u64,
    found: bool,
    index: u64,
    indices: []const u32,
    limit: u64,
};

pub const zx_type_55 = struct {
    context: *const zx_type_42,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_12,
    source: u32,
    valid: bool,
};

pub const zx_type_56 = struct {
    check: *const zx_type_43,
    count: u64,
    fields: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_57 = struct {
    field: ?u32,
    fields: []const ?u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    task: u32,
    tasks: []const u32,
};

pub const zx_type_58 = struct {
    check: *const zx_type_43,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_59 = struct {
    captures: []const u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    symbol: u32,
};

pub const zx_type_60 = struct {
    context: *const zx_type_42,
    context_type: u32,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_13,
    valid: bool,
};

pub const zx_type_61 = struct { *const zx_type_42, };

pub const zx_type_62 = struct { *const zx_type_42, bool, };

pub const value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_21_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9 = struct {
    base: value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    delta: value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_21 = null,
};

pub const value_zx_type_22_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_22 = null,
};

pub const value_zx_type_23_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_16,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_23 = null,
};

pub const value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_15,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_12,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_11,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_13,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_14,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
    zx_origin: ?*const zx_type_34 = null,
};

pub const value_zx_type_35_3d2a5be7ce7775f1628fb2017abf3abebedfe2e849558b1bdb504dc8989a3de9 = struct {
    expressions: value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788,
    id: u32,
    index: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_35 = null,
};

pub const value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    names: []const []const u8,
    ownership: []const zx_type_37,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
    zx_origin: ?*const zx_type_39 = null,
};

pub const value_zx_type_41_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_36,
    zx_origin: ?*const zx_type_41 = null,
};

pub const value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159 = struct {
    expressions: value_zx_type_34_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788,
    functions: value_zx_type_41_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_36,
    symbols: value_zx_type_39_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    table: value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_42 = null,
};

pub const value_zx_type_43_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = struct {
    context: value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159,
    kind: zx_type_11,
    payload: u64,
    target: zx_type_16,
    type_id: u32,
    zx_origin: ?*const zx_type_43 = null,
};

pub const value_zx_type_47_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    available: *const zx_type_36,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_36,
    slots: []const u32,
    zx_origin: ?*const zx_type_47 = null,
};

pub const value_zx_type_48_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922 = struct {
    table: value_zx_type_20_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    type_id: u32,
    zx_origin: ?*const zx_type_48 = null,
};

pub const value_zx_type_49_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    available: *const zx_type_36,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_36,
    slots: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_49 = null,
};

pub const value_zx_type_50_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
    zx_origin: ?*const zx_type_50 = null,
};

pub const value_zx_type_51_698b14c9054a42c897970dde7b67171e5e5a2bdf21605a4242a54005cf5cded9 = struct {
    condition_type: u32,
    context: value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159,
    count: u64,
    first: u64,
    index: u64,
    result_type: u32,
    valid: bool,
    zx_origin: ?*const zx_type_51 = null,
};

pub const value_zx_type_52_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c = struct {
    context: value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_52 = null,
};

pub const value_zx_type_53_8402a8d3b1664ff6b26614bcc1d310ab21dbfdc810cd0b4413c12a1a25b30335 = struct {
    context: value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159,
    count: u64,
    first: u64,
    index: u64,
    type_first: u64,
    valid: bool,
    zx_origin: ?*const zx_type_53 = null,
};

pub const value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    field: u64,
    first: u64,
    found: bool,
    index: u64,
    indices: []const u32,
    limit: u64,
    zx_origin: ?*const zx_type_54 = null,
};

pub const value_zx_type_55_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef = struct {
    context: value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_12,
    source: u32,
    valid: bool,
    zx_origin: ?*const zx_type_55 = null,
};

pub const value_zx_type_56_656c505fac39176473babfe9fa871c7e8504d23f50b61469fe21981782f14945 = struct {
    check: value_zx_type_43_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c,
    count: u64,
    fields: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_56 = null,
};

pub const value_zx_type_57_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077 = struct {
    field: ?u32,
    fields: []const ?u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    task: u32,
    tasks: []const u32,
    zx_origin: ?*const zx_type_57 = null,
};

pub const value_zx_type_58_6d1bc69b25779a10d9f1afe2a3709f07a05011a28d7ce09864d1cc9ef38c5e75 = struct {
    check: value_zx_type_43_7fee0949e8a940385627fded35bce8e3d0215a1e5c79db5e73e8e29e0159621c,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_58 = null,
};

pub const value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    captures: []const u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    symbol: u32,
    zx_origin: ?*const zx_type_59 = null,
};

pub const value_zx_type_60_451a175e795fff6bd4328ecde23588c7bf1e0ad977f3a2b59fca5b8b3ca050ef = struct {
    context: value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159,
    context_type: u32,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_13,
    valid: bool,
    zx_origin: ?*const zx_type_60 = null,
};

pub const value_zx_type_61_de0822f98df61dbb7b794c617f08b3235af92eb099f30710c1ec59286db51b73 = struct { value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159, ?*const zx_type_61, };

pub const value_zx_type_62_68865df9abc82868dc88b5f114299951aef77e92279349cc67417eb2fd574cdf = struct { value_zx_type_42_7bebc26c2653d873b89d5d84de9094dc066e40dcc5a0d23761283fd5f52ca159, bool, ?*const zx_type_62, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
    pub const @"zig:floats" = struct {
        pub const narrow = struct {
            pub const Input = f64;
            pub const Output = f32;
            pub const InputValue = f64;
            pub const OutputValue = f32;
        };
        pub const widen = struct {
            pub const Input = f32;
            pub const Output = f64;
            pub const InputValue = f32;
            pub const OutputValue = f64;
        };
        pub const isFinite = struct {
            pub const Input = f64;
            pub const Output = bool;
            pub const InputValue = f64;
            pub const OutputValue = bool;
        };
        pub const parse32 = struct {
            pub const Input = []const u8;
            pub const Output = ?f32;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f32;
        };
        pub const parse64 = struct {
            pub const Input = []const u8;
            pub const Output = ?f64;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f64;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
    pub const @"zig:floats" = struct {
    };
};

