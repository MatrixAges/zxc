const std = @import("std");

const zx_native_0 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .object, .fields = .{ .kind = zx_shape_2, .member = zx_shape_10, .owner = zx_shape_10, }, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_14 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .ids = zx_shape_12, .kinds = zx_shape_13, .members = zx_shape_14, .owners = zx_shape_14, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .base = zx_shape_15, .delta = zx_shape_15, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .names = zx_shape_14, .origins = zx_shape_15, }, };

const zx_shape_18 = .{ .kind = .scalar, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .children = zx_shape_12, .field_names = zx_shape_14, .field_types = zx_shape_12, .first = zx_shape_12, .kinds = zx_shape_13, .labels = zx_shape_14, .names = zx_shape_14, .second = zx_shape_12, }, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .base = zx_shape_19, .delta = zx_shape_19, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .names = zx_shape_14, .types = zx_shape_12, }, };

const zx_shape_22 = .{ .kind = .object, .fields = .{ .delta = zx_shape_1, .first = zx_shape_4, .kind = zx_shape_18, .label = zx_shape_10, .second = zx_shape_4, }, };

const zx_shape_23 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .names = zx_shape_14, .origins = zx_shape_15, .table = zx_shape_19, }, };

const zx_shape_24 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .names = zx_shape_14, .origins = zx_shape_15, }, };

const zx_shape_25 = .{ .kind = .object, .fields = .{ .names = zx_shape_14, .origins = zx_shape_15, .table = zx_shape_19, }, };

const zx_shape_26 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .index = zx_shape_5, .origins = zx_shape_15, .valid = zx_shape_1, }, };

const zx_shape_27 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .names = zx_shape_14, .origins = zx_shape_15, .previous = zx_shape_5, .unique = zx_shape_1, }, };

const zx_shape_28 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .index = zx_shape_5, .names = zx_shape_14, .origins = zx_shape_15, .table = zx_shape_19, .valid = zx_shape_1, }, };

const zx_shape_29 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_25, }, };

const zx_shape_30 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_25, .@"1" = zx_shape_1, }, };

const zx_shape_31 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_25, .@"1" = zx_shape_1, .@"2" = zx_shape_1, }, };

pub const input_shape = zx_shape_25;

pub const output_shape = zx_shape_1;

pub const Input = *const (zx_abi).zx_type_25;

pub const Output = bool;

fn function_0(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: u8) error{ }!u64 {
    const native_result = (zx_native_0).widenByte(in);

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_17) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: u64 = @as(u64, (((in).origins).ids).len);

    if (((((@as(u64, (((in).origins).kinds).len) != value_1) or (@as(u64, (((in).origins).owners).len) != value_1)) or (@as(u64, (((in).origins).members).len) != value_1)) or (@as(u64, ((in).names).len) != value_1))) {
        return false;
    }

    return block_26: {
        const state_type_2 = struct {
            ids: []const u32,
            kinds: []const u8,
            members: []const []const u8,
            owners: []const []const u8,
        };
        const state_type_3 = struct {
            count: u64,
            index: u64,
            origins: state_type_2,
            valid: bool,
        };
        const state_type_5 = struct {
            names: []const []const u8,
            origins: state_type_2,
        };
        const operand_12 = block_11: {
            const operand_7 = (block_6: {
                const operand_4 = in;

                break :block_6 state_type_5{ .names = (operand_4).names, .origins = state_type_2{ .ids = ((operand_4).origins).ids, .kinds = ((operand_4).origins).kinds, .members = ((operand_4).origins).members, .owners = ((operand_4).origins).owners, }, };
            }).origins;
            const operand_8 = value_1;
            const operand_9 = @as(u64, 0);
            const operand_10 = true;

            break :block_11 state_type_3{ .origins = operand_7, .count = operand_8, .index = operand_9, .valid = operand_10, };
        };

        var state_1: state_type_3 = operand_12;

        var state_changed_13 = false;

        while (((state_1).valid and ((state_1).index < (state_1).count))) {
            state_1 = block_25: {
                const value_4: u8 = block_24: {
                    const operand_22 = ((state_1).origins).kinds;
                    const operand_23 = (state_1).index;

                    if ((operand_23 >= (operand_22).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_24 (operand_22)[@intCast(operand_23)];
                };
                const value_5: state_type_3 = block_21: {
                    break :block_21 state_type_3{ .count = (state_1).count, .index = (state_1).index, .origins = (state_1).origins, .valid = ((value_4 <= @as(u8, 2)) and ((value_4 == @as(u8, 2)) or block_20: {
                        const operand_18 = block_17: {
                            const operand_15 = ((state_1).origins).members;
                            const operand_16 = (state_1).index;

                            if ((operand_16 >= (operand_15).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_17 (operand_15)[@intCast(operand_16)];
                        };
                        const operand_19 = @as([]const u8, "");

                        break :block_20 ((std).mem).eql(u8, operand_18, operand_19);
                    })), };
                };
                const value_6: u64 = (value_5).index;
                const value_7: state_type_3 = block_14: {
                    break :block_14 state_type_3{ .count = (value_5).count, .index = (value_6 + @as(u64, 1)), .origins = (value_5).origins, .valid = (value_5).valid, };
                };

                break :block_25 value_7;
            };

            state_changed_13 = true;
        }

        break :block_26 (state_1).valid;
    };
}

fn function_4(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_18 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_2: {
        const operand_1 = in;

        break :block_2 (if ((operand_1 == @as(u8, 0))) @as((zx_abi).zx_type_18, .Scalar) else (if ((operand_1 == @as(u8, 1))) @as((zx_abi).zx_type_18, .Object) else (if ((operand_1 == @as(u8, 2))) @as((zx_abi).zx_type_18, .Optional) else (if ((operand_1 == @as(u8, 3))) @as((zx_abi).zx_type_18, .List) else (if ((operand_1 == @as(u8, 4))) @as((zx_abi).zx_type_18, .Tuple) else (if ((operand_1 == @as(u8, 5))) @as((zx_abi).zx_type_18, .ErrorSet) else (if ((operand_1 == @as(u8, 6))) @as((zx_abi).zx_type_18, .Task) else (if ((operand_1 == @as(u8, 7))) @as((zx_abi).zx_type_18, .Enumeration) else @as((zx_abi).zx_type_18, .NativeReference)))))))));
    };
}

fn function_5(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_18 {
    @setRuntimeSafety(true);

    return (try function_4(allocator, in));
}

fn function_6(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_23) error{ IndexOutOfBounds, }!bool {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_0(allocator, block_18: {
        const operand_16 = ((in).origins).ids;
        const operand_17 = (in).index;

        if ((operand_17 >= (operand_16).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_18 (operand_16)[@intCast(operand_17)];
    }));

    if ((value_1 >= @as(u64, (((in).table).kinds).len))) {
        return false;
    }

    const value_2: (zx_abi).zx_type_18 = (try function_5(allocator, block_15: {
        const operand_13 = ((in).table).kinds;
        const operand_14 = value_1;

        if ((operand_14 >= (operand_13).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_15 (operand_13)[@intCast(operand_14)];
    }));

    if ((((value_2 != @as((zx_abi).zx_type_18, .Enumeration)) and (value_2 != @as((zx_abi).zx_type_18, .NativeReference))) or ((value_2 == @as((zx_abi).zx_type_18, .NativeReference)) and (block_12: {
        const operand_10 = ((in).origins).kinds;
        const operand_11 = (in).index;

        if ((operand_11 >= (operand_10).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_12 (operand_10)[@intCast(operand_11)];
    } != @as(u8, 1))))) {
        return false;
    }

    return block_9: {
        const operand_7 = block_3: {
            const operand_1 = ((in).table).labels;
            const operand_2 = value_1;

            if ((operand_2 >= (operand_1).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_3 (operand_1)[@intCast(operand_2)];
        };
        const operand_8 = block_6: {
            const operand_4 = (in).names;
            const operand_5 = (in).index;

            if ((operand_5 >= (operand_4).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_6 (operand_4)[@intCast(operand_5)];
        };

        break :block_9 ((std).mem).eql(u8, operand_7, operand_8);
    };
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_24) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_61: {
        const state_type_2 = struct {
            ids: []const u32,
            kinds: []const u8,
            members: []const []const u8,
            owners: []const []const u8,
        };
        const state_type_3 = struct {
            index: u64,
            names: []const []const u8,
            origins: state_type_2,
            previous: u64,
            unique: bool,
        };
        const state_type_5 = struct {
            index: u64,
            names: []const []const u8,
            origins: state_type_2,
        };
        const operand_17 = block_16: {
            const operand_7 = (block_6: {
                const operand_4 = in;

                break :block_6 state_type_5{ .index = (operand_4).index, .names = (operand_4).names, .origins = state_type_2{ .ids = ((operand_4).origins).ids, .kinds = ((operand_4).origins).kinds, .members = ((operand_4).origins).members, .owners = ((operand_4).origins).owners, }, };
            }).origins;
            const operand_10 = (block_9: {
                const operand_8 = in;

                break :block_9 state_type_5{ .index = (operand_8).index, .names = (operand_8).names, .origins = state_type_2{ .ids = ((operand_8).origins).ids, .kinds = ((operand_8).origins).kinds, .members = ((operand_8).origins).members, .owners = ((operand_8).origins).owners, }, };
            }).names;
            const operand_13 = (block_12: {
                const operand_11 = in;

                break :block_12 state_type_5{ .index = (operand_11).index, .names = (operand_11).names, .origins = state_type_2{ .ids = ((operand_11).origins).ids, .kinds = ((operand_11).origins).kinds, .members = ((operand_11).origins).members, .owners = ((operand_11).origins).owners, }, };
            }).index;
            const operand_14 = @as(u64, 0);
            const operand_15 = true;

            break :block_16 state_type_3{ .origins = operand_7, .names = operand_10, .index = operand_13, .previous = operand_14, .unique = operand_15, };
        };

        var state_1: state_type_3 = operand_17;

        var state_changed_18 = false;

        while (((state_1).unique and ((state_1).previous < (state_1).index))) {
            state_1 = block_60: {
                const value_3: u64 = (state_1).previous;
                const value_4: u64 = (state_1).index;
                const value_5: bool = (block_56: {
                    const operand_54 = ((state_1).origins).ids;
                    const operand_55 = value_3;

                    if ((operand_55 >= (operand_54).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_56 (operand_54)[@intCast(operand_55)];
                } == block_59: {
                    const operand_57 = ((state_1).origins).ids;
                    const operand_58 = value_4;

                    if ((operand_58 >= (operand_57).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_59 (operand_57)[@intCast(operand_58)];
                });
                const value_6: bool = (((block_32: {
                    const operand_30 = ((state_1).origins).kinds;
                    const operand_31 = value_3;

                    if ((operand_31 >= (operand_30).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_32 (operand_30)[@intCast(operand_31)];
                } == block_35: {
                    const operand_33 = ((state_1).origins).kinds;
                    const operand_34 = value_4;

                    if ((operand_34 >= (operand_33).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_35 (operand_33)[@intCast(operand_34)];
                }) and block_44: {
                    const operand_42 = block_38: {
                        const operand_36 = ((state_1).origins).owners;
                        const operand_37 = value_3;

                        if ((operand_37 >= (operand_36).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_38 (operand_36)[@intCast(operand_37)];
                    };
                    const operand_43 = block_41: {
                        const operand_39 = ((state_1).origins).owners;
                        const operand_40 = value_4;

                        if ((operand_40 >= (operand_39).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_41 (operand_39)[@intCast(operand_40)];
                    };

                    break :block_44 ((std).mem).eql(u8, operand_42, operand_43);
                }) and block_53: {
                    const operand_51 = block_47: {
                        const operand_45 = ((state_1).origins).members;
                        const operand_46 = value_3;

                        if ((operand_46 >= (operand_45).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_47 (operand_45)[@intCast(operand_46)];
                    };
                    const operand_52 = block_50: {
                        const operand_48 = ((state_1).origins).members;
                        const operand_49 = value_4;

                        if ((operand_49 >= (operand_48).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_50 (operand_48)[@intCast(operand_49)];
                    };

                    break :block_53 ((std).mem).eql(u8, operand_51, operand_52);
                });
                const value_7: state_type_3 = block_29: {
                    break :block_29 state_type_3{ .index = (state_1).index, .names = (state_1).names, .origins = (state_1).origins, .previous = (state_1).previous, .unique = ((!value_5) and (!(value_6 and block_28: {
                        const operand_26 = block_22: {
                            const operand_20 = (state_1).names;
                            const operand_21 = value_3;

                            if ((operand_21 >= (operand_20).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_22 (operand_20)[@intCast(operand_21)];
                        };
                        const operand_27 = block_25: {
                            const operand_23 = (state_1).names;
                            const operand_24 = value_4;

                            if ((operand_24 >= (operand_23).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_25 (operand_23)[@intCast(operand_24)];
                        };

                        break :block_28 ((std).mem).eql(u8, operand_26, operand_27);
                    }))), };
                };
                const value_8: u64 = (value_7).previous;
                const value_9: state_type_3 = block_19: {
                    break :block_19 state_type_3{ .index = (value_7).index, .names = (value_7).names, .origins = (value_7).origins, .previous = (value_8 + @as(u64, 1)), .unique = (value_7).unique, };
                };

                break :block_60 value_9;
            };

            state_changed_18 = true;
        }

        break :block_61 (state_1).unique;
    };
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_23) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    return ((try function_6(allocator, in)) and block_5: {
        const operand_1 = (in).origins;
        const operand_2 = (in).names;
        const operand_3 = (in).index;
        const operand_4 = (zx_abi).zx_type_24{ .origins = operand_1, .names = operand_2, .index = operand_3, };

        break :block_5 (try function_7(allocator, (&operand_4)));
    });
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_25) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: u64 = @as(u64, (((in).origins).ids).len);

    return block_36: {
        const state_type_2 = struct {
            ids: []const u32,
            kinds: []const u8,
            members: []const []const u8,
            owners: []const []const u8,
        };
        const state_type_3 = struct {
            children: []const u32,
            field_names: []const []const u8,
            field_types: []const u32,
            first: []const u32,
            kinds: []const u8,
            labels: []const []const u8,
            names: []const []const u8,
            second: []const u32,
        };
        const state_type_4 = struct {
            count: u64,
            index: u64,
            names: []const []const u8,
            origins: state_type_2,
            table: state_type_3,
            valid: bool,
        };
        const state_type_6 = struct {
            names: []const []const u8,
            origins: state_type_2,
            table: state_type_3,
        };
        const operand_19 = block_18: {
            const operand_8 = (block_7: {
                const operand_5 = in;

                break :block_7 state_type_6{ .names = (operand_5).names, .origins = state_type_2{ .ids = ((operand_5).origins).ids, .kinds = ((operand_5).origins).kinds, .members = ((operand_5).origins).members, .owners = ((operand_5).origins).owners, }, .table = state_type_3{ .children = ((operand_5).table).children, .field_names = ((operand_5).table).field_names, .field_types = ((operand_5).table).field_types, .first = ((operand_5).table).first, .kinds = ((operand_5).table).kinds, .labels = ((operand_5).table).labels, .names = ((operand_5).table).names, .second = ((operand_5).table).second, }, };
            }).table;
            const operand_11 = (block_10: {
                const operand_9 = in;

                break :block_10 state_type_6{ .names = (operand_9).names, .origins = state_type_2{ .ids = ((operand_9).origins).ids, .kinds = ((operand_9).origins).kinds, .members = ((operand_9).origins).members, .owners = ((operand_9).origins).owners, }, .table = state_type_3{ .children = ((operand_9).table).children, .field_names = ((operand_9).table).field_names, .field_types = ((operand_9).table).field_types, .first = ((operand_9).table).first, .kinds = ((operand_9).table).kinds, .labels = ((operand_9).table).labels, .names = ((operand_9).table).names, .second = ((operand_9).table).second, }, };
            }).origins;
            const operand_14 = (block_13: {
                const operand_12 = in;

                break :block_13 state_type_6{ .names = (operand_12).names, .origins = state_type_2{ .ids = ((operand_12).origins).ids, .kinds = ((operand_12).origins).kinds, .members = ((operand_12).origins).members, .owners = ((operand_12).origins).owners, }, .table = state_type_3{ .children = ((operand_12).table).children, .field_names = ((operand_12).table).field_names, .field_types = ((operand_12).table).field_types, .first = ((operand_12).table).first, .kinds = ((operand_12).table).kinds, .labels = ((operand_12).table).labels, .names = ((operand_12).table).names, .second = ((operand_12).table).second, }, };
            }).names;
            const operand_15 = @as(u64, 0);
            const operand_16 = value_1;
            const operand_17 = true;

            break :block_18 state_type_4{ .table = operand_8, .origins = operand_11, .names = operand_14, .index = operand_15, .count = operand_16, .valid = operand_17, };
        };
        const state_type_22 = struct {
            index: u64,
            names: []const []const u8,
            origins: state_type_2,
            table: state_type_3,
        };

        var state_1: state_type_4 = operand_19;

        var state_changed_20 = false;

        while (((state_1).valid and ((state_1).index < (state_1).count))) {
            state_1 = block_35: {
                const value_4: state_type_4 = block_34: {
                    break :block_34 state_type_4{ .count = (state_1).count, .index = (state_1).index, .names = (state_1).names, .origins = (state_1).origins, .table = (state_1).table, .valid = block_33: {
                        const operand_28 = block_27: {
                            const operand_23 = (state_1).table;
                            const operand_24 = (state_1).origins;
                            const operand_25 = (state_1).names;
                            const operand_26 = (state_1).index;

                            break :block_27 state_type_22{ .table = operand_23, .origins = operand_24, .names = operand_25, .index = operand_26, };
                        };
                        const operand_29 = (zx_abi).zx_type_15{ .ids = ((operand_28).origins).ids, .kinds = ((operand_28).origins).kinds, .members = ((operand_28).origins).members, .owners = ((operand_28).origins).owners, };
                        const operand_30 = (zx_abi).zx_type_19{ .children = ((operand_28).table).children, .field_names = ((operand_28).table).field_names, .field_types = ((operand_28).table).field_types, .first = ((operand_28).table).first, .kinds = ((operand_28).table).kinds, .labels = ((operand_28).table).labels, .names = ((operand_28).table).names, .second = ((operand_28).table).second, };
                        const operand_31 = (zx_abi).zx_type_23{ .index = (operand_28).index, .names = (operand_28).names, .origins = (&operand_29), .table = (&operand_30), };
                        const operand_32 = (try function_8(allocator, (&operand_31)));

                        break :block_33 operand_32;
                    }, };
                };
                const value_5: u64 = (value_4).index;
                const value_6: state_type_4 = block_21: {
                    break :block_21 state_type_4{ .count = (value_4).count, .index = (value_5 + @as(u64, 1)), .names = (value_4).names, .origins = (value_4).origins, .table = (value_4).table, .valid = (value_4).valid, };
                };

                break :block_35 value_6;
            };

            state_changed_20 = true;
        }

        break :block_36 (state_1).valid;
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_25) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = block_5: {
        const operand_2 = (in).origins;
        const operand_3 = (in).names;
        const operand_4 = (zx_abi).zx_type_17{ .origins = operand_2, .names = operand_3, };

        break :block_5 (try function_3(allocator, (&operand_4)));
    };
    const switch_1 = value_1;

    if ((switch_1 == true)) {
        const value_2: bool = (try function_9(allocator, in));

        return value_2;
    } else {
        return false;
    }
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_25) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: bool = block_10: {
        const operand_7 = (in).origins;
        const operand_8 = (in).names;
        const operand_9 = (zx_abi).zx_type_17{ .origins = operand_7, .names = operand_8, };

        break :block_10 (try function_3(allocator, (&operand_9)));
    };
    const switch_6 = value_1;

    if ((switch_6 == true)) {
        const value_2: bool = (try function_9(allocator, in));

        return value_2;
    } else {
        return false;
    }
}

