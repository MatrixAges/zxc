pub const zx_type_12 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
};

pub const zx_type_13 = enum { Copy, Borrowed, Owned, };

pub const zx_type_17 = struct {
    names: []const []const u8,
    ownership: []const zx_type_13,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_18 = struct {
    max_offset: u64,
    symbols: *const zx_type_17,
};

pub const zx_type_19 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_20 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_21 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_22 = enum { Negate, Not, };

pub const zx_type_23 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_33 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_23,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_20,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_19,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_21,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_22,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_34 = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_33,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
};

pub const zx_type_35 = struct {
    kind: zx_type_19,
    payload: u64,
    state: *const zx_type_34,
};

pub const zx_type_36 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
};

pub const zx_type_37 = struct {
    max_offset: u64,
    table: *const zx_type_33,
};

pub const zx_type_38 = enum { Requires, Ensures, };

pub const zx_type_42 = struct {
    expressions: []const *const zx_type_33,
    kinds: []const zx_type_38,
    predicates: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    symbols: []const *const zx_type_17,
};

pub const zx_type_43 = struct {
    contracts: *const zx_type_42,
    max_offset: u64,
};

pub const zx_type_44 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_46 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_47 = struct {
    base: *const zx_type_46,
    delta: *const zx_type_46,
};

pub const zx_type_48 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_49 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_44,
    label: []const u8,
    second: u32,
};

pub const zx_type_50 = struct {
    expressions: *const zx_type_33,
    id: u32,
    index: u64,
    type_id: u32,
};

pub const zx_type_51 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_53 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_51,
};

pub const zx_type_54 = struct {
    expressions: *const zx_type_33,
    functions: *const zx_type_53,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_51,
    symbols: *const zx_type_17,
    table: *const zx_type_46,
};

pub const zx_type_55 = struct {
    context: *const zx_type_54,
    kind: zx_type_19,
    payload: u64,
    target: zx_type_44,
    type_id: u32,
};

pub const zx_type_56 = enum { Other, Integer, Signed, Float, };

pub const zx_type_59 = struct {
    available: *const zx_type_51,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_51,
    slots: []const u32,
};

pub const zx_type_60 = struct {
    table: *const zx_type_46,
    type_id: u32,
};

pub const zx_type_61 = struct {
    contracts: *const zx_type_42,
    input_type: u32,
    max_offset: u64,
    output_type: u32,
    table: *const zx_type_46,
};

pub const zx_type_62 = struct {
    index: u64,
    program: *const zx_type_61,
};

pub const zx_type_63 = struct {
    index: u64,
    input: *const zx_type_12,
    valid: bool,
};

pub const zx_type_64 = struct {
    index: u64,
    input: *const zx_type_36,
    next: u64,
    valid: bool,
};

pub const zx_type_65 = struct {
    contracts: *const zx_type_42,
    index: u64,
    max_offset: u64,
    valid: bool,
};

pub const zx_type_66 = struct { *const zx_type_43, };

pub const zx_type_67 = struct { *const zx_type_43, bool, };

pub const zx_type_68 = struct {
    available: *const zx_type_51,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_51,
    slots: []const u32,
    valid: bool,
};

pub const zx_type_69 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
};

pub const zx_type_70 = struct {
    condition_type: u32,
    context: *const zx_type_54,
    count: u64,
    first: u64,
    index: u64,
    result_type: u32,
    valid: bool,
};

pub const zx_type_71 = struct {
    context: *const zx_type_54,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_72 = struct {
    context: *const zx_type_54,
    count: u64,
    first: u64,
    index: u64,
    type_first: u64,
    valid: bool,
};

pub const zx_type_73 = struct {
    field: u64,
    first: u64,
    found: bool,
    index: u64,
    indices: []const u32,
    limit: u64,
};

pub const zx_type_74 = struct {
    context: *const zx_type_54,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_20,
    source: u32,
    valid: bool,
};

pub const zx_type_75 = struct {
    check: *const zx_type_55,
    count: u64,
    fields: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_76 = struct {
    field: ?u32,
    fields: []const ?u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    task: u32,
    tasks: []const u32,
};

pub const zx_type_77 = struct {
    check: *const zx_type_55,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_78 = struct {
    captures: []const u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    symbol: u32,
};

pub const zx_type_79 = struct {
    context: *const zx_type_54,
    context_type: u32,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_21,
    valid: bool,
};

pub const zx_type_80 = struct {
    expressions: *const zx_type_33,
    functions: *const zx_type_53,
    index: u64,
    stores: *const zx_type_51,
    symbols: *const zx_type_17,
    table: *const zx_type_46,
    valid: bool,
};

pub const zx_type_81 = struct {
    has_ensures: bool,
    index: u64,
    program: *const zx_type_61,
    valid: bool,
};

pub const zx_type_82 = struct { *const zx_type_61, };

pub const zx_type_83 = struct { *const zx_type_61, bool, };

pub const zx_type_84 = struct { *const zx_type_61, bool, bool, };

pub const value_zx_type_12_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
    zx_origin: ?*const zx_type_12 = null,
};

pub const value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    max_offset: u64,
    symbols: *const zx_type_17,
    zx_origin: ?*const zx_type_18 = null,
};

pub const value_zx_type_34_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_33,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
    zx_origin: ?*const zx_type_34 = null,
};

pub const value_zx_type_35_65cf7d6fbad1c16266bae803c08ca5f9cfd0a43ae4a2b544cd579935fe760b39 = struct {
    kind: zx_type_19,
    payload: u64,
    state: value_zx_type_34_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a,
    zx_origin: ?*const zx_type_35 = null,
};

pub const value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
    zx_origin: ?*const zx_type_36 = null,
};

pub const value_zx_type_37_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    max_offset: u64,
    table: *const zx_type_33,
    zx_origin: ?*const zx_type_37 = null,
};

pub const value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    expressions: []const *const zx_type_33,
    kinds: []const zx_type_38,
    predicates: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    symbols: []const *const zx_type_17,
    zx_origin: ?*const zx_type_42 = null,
};

pub const value_zx_type_43_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct {
    contracts: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    max_offset: u64,
    zx_origin: ?*const zx_type_43 = null,
};

pub const value_zx_type_46_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
    zx_origin: ?*const zx_type_46 = null,
};

pub const value_zx_type_47_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9 = struct {
    base: value_zx_type_46_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    delta: value_zx_type_46_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_47 = null,
};

pub const value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_48 = null,
};

pub const value_zx_type_49_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_44,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_49 = null,
};

pub const value_zx_type_50_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: *const zx_type_33,
    id: u32,
    index: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_50 = null,
};

pub const value_zx_type_53_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_51,
    zx_origin: ?*const zx_type_53 = null,
};

pub const value_zx_type_54_d1fac45b3a74f4f5d453aa4b6ef60ac72ecb75810d0999ba0c1f536f00ead295 = struct {
    expressions: *const zx_type_33,
    functions: value_zx_type_53_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_51,
    symbols: *const zx_type_17,
    table: value_zx_type_46_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_54 = null,
};

pub const value_zx_type_55_68ef09498ec80ff262036f855dded72f202a8ddfab3b0f2dd63c1269dc168e1e = struct {
    context: value_zx_type_54_d1fac45b3a74f4f5d453aa4b6ef60ac72ecb75810d0999ba0c1f536f00ead295,
    kind: zx_type_19,
    payload: u64,
    target: zx_type_44,
    type_id: u32,
    zx_origin: ?*const zx_type_55 = null,
};

pub const value_zx_type_59_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    available: *const zx_type_51,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_51,
    slots: []const u32,
    zx_origin: ?*const zx_type_59 = null,
};

pub const value_zx_type_60_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922 = struct {
    table: value_zx_type_46_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    type_id: u32,
    zx_origin: ?*const zx_type_60 = null,
};

pub const value_zx_type_61_2f6d4721cf5713792246a6e07351b6f746a72bd3d6235d04175b75fea3e01e26 = struct {
    contracts: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    input_type: u32,
    max_offset: u64,
    output_type: u32,
    table: value_zx_type_46_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_61 = null,
};

pub const value_zx_type_62_9009aca571f4a4069d5117a490a834ede328fca363fb224d7b0e38f538fbd702 = struct {
    index: u64,
    program: value_zx_type_61_2f6d4721cf5713792246a6e07351b6f746a72bd3d6235d04175b75fea3e01e26,
    zx_origin: ?*const zx_type_62 = null,
};

pub const value_zx_type_63_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    index: u64,
    input: value_zx_type_12_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    valid: bool,
    zx_origin: ?*const zx_type_63 = null,
};

pub const value_zx_type_64_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    index: u64,
    input: value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    next: u64,
    valid: bool,
    zx_origin: ?*const zx_type_64 = null,
};

pub const value_zx_type_65_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8 = struct {
    contracts: value_zx_type_42_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    max_offset: u64,
    valid: bool,
    zx_origin: ?*const zx_type_65 = null,
};

pub const value_zx_type_66_4bb438ff01f237569bb9646dc2578b71e2a1e16fa8fe9e4b0b9d926ac5640cd1 = struct { value_zx_type_43_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, ?*const zx_type_66, };

pub const value_zx_type_67_80fa3f09fde2ea8660c1d43e969ee3d68c4cda0e85a50de87ab5f1fb43c5c390 = struct { value_zx_type_43_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, ?*const zx_type_67, };

pub const value_zx_type_68_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    available: *const zx_type_51,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_51,
    slots: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_68 = null,
};

pub const value_zx_type_69_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
    zx_origin: ?*const zx_type_69 = null,
};

pub const value_zx_type_70_0638b4aaa28fb6b90ce74fa4a5db51cd065366b585c384b635164794c3e9b7d7 = struct {
    condition_type: u32,
    context: value_zx_type_54_d1fac45b3a74f4f5d453aa4b6ef60ac72ecb75810d0999ba0c1f536f00ead295,
    count: u64,
    first: u64,
    index: u64,
    result_type: u32,
    valid: bool,
    zx_origin: ?*const zx_type_70 = null,
};

pub const value_zx_type_71_68ef09498ec80ff262036f855dded72f202a8ddfab3b0f2dd63c1269dc168e1e = struct {
    context: value_zx_type_54_d1fac45b3a74f4f5d453aa4b6ef60ac72ecb75810d0999ba0c1f536f00ead295,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_71 = null,
};

pub const value_zx_type_72_b8f86938ac6e66b0bee19cf07ee4e74655469a7f3fc55afb517521fa2fc136b2 = struct {
    context: value_zx_type_54_d1fac45b3a74f4f5d453aa4b6ef60ac72ecb75810d0999ba0c1f536f00ead295,
    count: u64,
    first: u64,
    index: u64,
    type_first: u64,
    valid: bool,
    zx_origin: ?*const zx_type_72 = null,
};

pub const value_zx_type_73_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    field: u64,
    first: u64,
    found: bool,
    index: u64,
    indices: []const u32,
    limit: u64,
    zx_origin: ?*const zx_type_73 = null,
};

pub const value_zx_type_74_27712909723ae69bfaed810a0a7f8ec6c9c53151329c0385b00e854044bc6afb = struct {
    context: value_zx_type_54_d1fac45b3a74f4f5d453aa4b6ef60ac72ecb75810d0999ba0c1f536f00ead295,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_20,
    source: u32,
    valid: bool,
    zx_origin: ?*const zx_type_74 = null,
};

pub const value_zx_type_75_5fbe538a4505a4a42e2076debd697df0f2493bc825e4d7ff3af07c2c6330d930 = struct {
    check: value_zx_type_55_68ef09498ec80ff262036f855dded72f202a8ddfab3b0f2dd63c1269dc168e1e,
    count: u64,
    fields: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_75 = null,
};

pub const value_zx_type_76_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077 = struct {
    field: ?u32,
    fields: []const ?u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    task: u32,
    tasks: []const u32,
    zx_origin: ?*const zx_type_76 = null,
};

pub const value_zx_type_77_d81c7ad893aedbe19547f5ef1e0152457ca5ff0cd243ebb8b7e47500e3c58dbf = struct {
    check: value_zx_type_55_68ef09498ec80ff262036f855dded72f202a8ddfab3b0f2dd63c1269dc168e1e,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_77 = null,
};

pub const value_zx_type_78_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    captures: []const u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    symbol: u32,
    zx_origin: ?*const zx_type_78 = null,
};

pub const value_zx_type_79_27712909723ae69bfaed810a0a7f8ec6c9c53151329c0385b00e854044bc6afb = struct {
    context: value_zx_type_54_d1fac45b3a74f4f5d453aa4b6ef60ac72ecb75810d0999ba0c1f536f00ead295,
    context_type: u32,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_21,
    valid: bool,
    zx_origin: ?*const zx_type_79 = null,
};

pub const value_zx_type_80_8cec82586ae6e3f5b32f033ac68de4a2d3e7ce3f4dba0d2c0c93d6e4ae0f2880 = struct {
    expressions: *const zx_type_33,
    functions: value_zx_type_53_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    stores: *const zx_type_51,
    symbols: *const zx_type_17,
    table: value_zx_type_46_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    valid: bool,
    zx_origin: ?*const zx_type_80 = null,
};

pub const value_zx_type_81_f0066aaf8c04c752f588689496866b9ea11c3b89c19460455449d405465d35b3 = struct {
    has_ensures: bool,
    index: u64,
    program: value_zx_type_61_2f6d4721cf5713792246a6e07351b6f746a72bd3d6235d04175b75fea3e01e26,
    valid: bool,
    zx_origin: ?*const zx_type_81 = null,
};

pub const value_zx_type_82_89ac96f0de1c61b4159b171aaa9cc9ead275eb22da9def54374c89a036c0ec83 = struct { value_zx_type_61_2f6d4721cf5713792246a6e07351b6f746a72bd3d6235d04175b75fea3e01e26, ?*const zx_type_82, };

pub const value_zx_type_83_31d32acc6d75612c77037d7ef6886a9ea68147e97b335d93dd08ba033cd2b331 = struct { value_zx_type_61_2f6d4721cf5713792246a6e07351b6f746a72bd3d6235d04175b75fea3e01e26, bool, ?*const zx_type_83, };

pub const value_zx_type_84_73e7eaae24b743bcf96add6d7edfc1284da219b23aab7ab8e7e8308c1c5d5eb6 = struct { value_zx_type_61_2f6d4721cf5713792246a6e07351b6f746a72bd3d6235d04175b75fea3e01e26, bool, bool, ?*const zx_type_84, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
    pub const @"zig:floats" = struct {
        pub const narrow = struct {
            pub const Input = f64;
            pub const Output = f32;
            pub const InputValue = f64;
            pub const OutputValue = f32;
        };
        pub const widen = struct {
            pub const Input = f32;
            pub const Output = f64;
            pub const InputValue = f32;
            pub const OutputValue = f64;
        };
        pub const isFinite = struct {
            pub const Input = f64;
            pub const Output = bool;
            pub const InputValue = f64;
            pub const OutputValue = bool;
        };
        pub const parse32 = struct {
            pub const Input = []const u8;
            pub const Output = ?f32;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f32;
        };
        pub const parse64 = struct {
            pub const Input = []const u8;
            pub const Output = ?f64;
            pub const InputValue = []const u8;
            pub const OutputValue = ?f64;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
    pub const @"zig:floats" = struct {
    };
};

