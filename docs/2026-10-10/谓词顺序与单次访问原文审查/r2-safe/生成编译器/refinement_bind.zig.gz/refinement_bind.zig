const std = @import("std");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .scalar, };

const zx_shape_13 = .{ .kind = .scalar, };

const zx_shape_14 = .{ .kind = .scalar, };

const zx_shape_15 = .{ .kind = .scalar, };

const zx_shape_16 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .capture_errors = zx_shape_16, .capture_results = zx_shape_16, .nonnull = zx_shape_16, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .captures = zx_shape_5, .nonnull = zx_shape_5, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .err = zx_shape_4, .facts = zx_shape_17, .result = zx_shape_4, }, };

const zx_shape_20 = .{ .kind = .list, .child = zx_shape_11, };

const zx_shape_21 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_22 = .{ .kind = .list, .child = zx_shape_9, };

const zx_shape_23 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_24 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_25 = .{ .kind = .optional, .child = zx_shape_4, };

const zx_shape_26 = .{ .kind = .list, .child = zx_shape_25, };

const zx_shape_27 = .{ .kind = .list, .child = zx_shape_12, };

const zx_shape_28 = .{ .kind = .list, .child = zx_shape_13, };

const zx_shape_29 = .{ .kind = .list, .child = zx_shape_14, };

const zx_shape_30 = .{ .kind = .list, .child = zx_shape_15, };

const zx_shape_31 = .{ .kind = .object, .fields = .{ .awaits = zx_shape_16, .binary_left = zx_shape_16, .binary_operators = zx_shape_30, .binary_right = zx_shape_16, .booleans = zx_shape_24, .call_arguments = zx_shape_16, .call_functions = zx_shape_16, .call_store_count = zx_shape_16, .call_store_first = zx_shape_16, .call_stores = zx_shape_16, .cancellations = zx_shape_16, .captures = zx_shape_16, .collection_arguments = zx_shape_16, .collection_count = zx_shape_16, .collection_first = zx_shape_16, .collection_kinds = zx_shape_27, .collection_targets = zx_shape_16, .conditional_conditions = zx_shape_16, .conditional_no = zx_shape_16, .conditional_yes = zx_shape_16, .enumerations = zx_shape_16, .errors = zx_shape_16, .floats = zx_shape_22, .index_targets = zx_shape_16, .index_values = zx_shape_16, .integers = zx_shape_21, .iteration_bodies = zx_shape_16, .iteration_condition_parameters = zx_shape_16, .iteration_conditions = zx_shape_16, .iteration_initials = zx_shape_16, .iteration_parameters = zx_shape_16, .iteration_postconditions = zx_shape_24, .kinds = zx_shape_20, .lengths = zx_shape_16, .match_conditions = zx_shape_16, .match_count = zx_shape_16, .match_fallbacks = zx_shape_16, .match_first = zx_shape_16, .match_results = zx_shape_16, .match_subjects = zx_shape_26, .negative_integers = zx_shape_21, .object_count = zx_shape_16, .object_evaluation_count = zx_shape_16, .object_evaluation_first = zx_shape_16, .object_evaluation_values = zx_shape_16, .object_field_indices = zx_shape_16, .object_field_values = zx_shape_16, .object_first = zx_shape_16, .optional_values = zx_shape_16, .parallel_count = zx_shape_16, .parallel_fields = zx_shape_26, .parallel_first = zx_shape_16, .parallel_tasks = zx_shape_16, .payloads = zx_shape_16, .projection_indices = zx_shape_16, .projection_targets = zx_shape_16, .references = zx_shape_16, .scope_borrows = zx_shape_24, .scope_count = zx_shape_16, .scope_first = zx_shape_16, .scope_results = zx_shape_16, .scope_symbols = zx_shape_26, .scope_values = zx_shape_16, .sequence_count = zx_shape_16, .sequence_first = zx_shape_16, .sequence_items = zx_shape_16, .some = zx_shape_16, .span_end = zx_shape_21, .span_start = zx_shape_21, .stores = zx_shape_16, .strings = zx_shape_23, .task_bodies = zx_shape_16, .task_capture_count = zx_shape_16, .task_capture_first = zx_shape_16, .task_captures = zx_shape_16, .transform_bodies = zx_shape_16, .transform_count = zx_shape_16, .transform_first = zx_shape_16, .transform_initials = zx_shape_26, .transform_kinds = zx_shape_28, .transform_parameters = zx_shape_16, .transform_targets = zx_shape_16, .types = zx_shape_16, .unary_operands = zx_shape_16, .unary_operators = zx_shape_29, .update_indices = zx_shape_16, .update_targets = zx_shape_16, .update_values = zx_shape_16, }, };

const zx_shape_32 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .err = zx_shape_25, .expressions = zx_shape_31, .facts = zx_shape_17, .result = zx_shape_25, .value = zx_shape_5, }, };

const zx_shape_33 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_16, .@"1" = zx_shape_0, }, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_32, }, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_32, .@"1" = zx_shape_17, }, };

pub const input_shape = zx_shape_32;

pub const output_shape = zx_shape_17;

pub const Input = *const (zx_abi).zx_type_32;

pub const Output = *const (zx_abi).zx_type_17;

fn function_0(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_19) error{ OutOfMemory, Overflow, }!*const (zx_abi).zx_type_17 {
    @setRuntimeSafety(true);

    return block_14: {
        const operand_1 = ((in).facts).nonnull;
        const operand_2 = (block_6: {
            const operand_3 = ((in).facts).capture_errors;
            const operand_4 = (in).err;
            const operand_5 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_3).len, 1))));

            @memcpy((operand_5)[0..(operand_3).len], operand_3);

            (operand_5)[(operand_3).len] = operand_4;

            break :block_6 @as((zx_abi).zx_type_33, .{ operand_5, {}, });
        }).@"0";
        const operand_7 = (block_11: {
            const operand_8 = ((in).facts).capture_results;
            const operand_9 = (in).result;
            const operand_10 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_8).len, 1))));

            @memcpy((operand_10)[0..(operand_8).len], operand_8);

            (operand_10)[(operand_8).len] = operand_9;

            break :block_11 @as((zx_abi).zx_type_33, .{ operand_10, {}, });
        }).@"0";

        break :block_14 block_13: {
            const operand_12 = (try (allocator).create((zx_abi).zx_type_17));

            (operand_12).* = @as((zx_abi).zx_type_17, (zx_abi).zx_type_17{ .nonnull = operand_1, .capture_errors = operand_2, .capture_results = operand_7, });

            break :block_13 @as(*const (zx_abi).zx_type_17, operand_12);
        };
    };
}

fn function_0_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_19_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f) error{ OutOfMemory, Overflow, }!(zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 {
    @setRuntimeSafety(true);

    return block_26: {
        const operand_15 = ((in).facts).nonnull;
        const operand_16 = (block_20: {
            const operand_17 = ((in).facts).capture_errors;
            const operand_18 = (in).err;
            const operand_19 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_17).len, 1))));

            @memcpy((operand_19)[0..(operand_17).len], operand_17);

            (operand_19)[(operand_17).len] = operand_18;

            break :block_20 @as((zx_abi).value_zx_type_33_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_19, {}, null, });
        }).@"0";
        const operand_21 = (block_25: {
            const operand_22 = ((in).facts).capture_results;
            const operand_23 = (in).result;
            const operand_24 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_22).len, 1))));

            @memcpy((operand_24)[0..(operand_22).len], operand_22);

            (operand_24)[(operand_22).len] = operand_23;

            break :block_25 @as((zx_abi).value_zx_type_33_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_24, {}, null, });
        }).@"0";

        break :block_26 @as((zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nonnull = operand_15, .capture_errors = operand_16, .capture_results = operand_21, });
    };
}

fn function_0_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_19_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!(zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 {
    @setRuntimeSafety(true);

    return block_44: {
        const operand_27 = ((in).facts).nonnull;
        const operand_28 = @as([]const u32, (if (((buffers).lane_0 != null)) block_31: {
            const operand_29 = ((in).facts).capture_errors;
            const operand_30 = (in).err;

            _ = (try ((std).math).add(usize, (operand_29).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_29));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_29).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_30));

            break :block_31 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_35: {
            const operand_32 = ((in).facts).capture_errors;
            const operand_33 = (in).err;
            const operand_34 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_32).len, 1))));

            @memcpy((operand_34)[0..(operand_32).len], operand_32);

            (operand_34)[(operand_32).len] = operand_33;

            break :block_35 @as((zx_abi).value_zx_type_33_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_34, {}, null, });
        }).@"0"));
        const operand_36 = @as([]const u32, (if (((buffers).lane_1 != null)) block_39: {
            const operand_37 = ((in).facts).capture_results;
            const operand_38 = (in).result;

            _ = (try ((std).math).add(usize, (operand_37).len, 1));

            if ((!(((buffers).lane_1.?).started).*)) {
                (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_37));

                (((buffers).lane_1.?).started).* = true;
            } else {
                (((((buffers).lane_1.?).buffer).*).items).len = (operand_37).len;
            }

            (try ((((buffers).lane_1.?).buffer).*).append(allocator, operand_38));

            break :block_39 ((((buffers).lane_1.?).buffer).*).items;
        } else (block_43: {
            const operand_40 = ((in).facts).capture_results;
            const operand_41 = (in).result;
            const operand_42 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_40).len, 1))));

            @memcpy((operand_42)[0..(operand_40).len], operand_40);

            (operand_42)[(operand_40).len] = operand_41;

            break :block_43 @as((zx_abi).value_zx_type_33_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_42, {}, null, });
        }).@"0"));

        break :block_44 @as((zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .nonnull = operand_27, .capture_errors = operand_28, .capture_results = operand_36, });
    };
}

fn function_0_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_19, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const (zx_abi).zx_type_17 {
    @setRuntimeSafety(true);

    return block_64: {
        const operand_45 = ((in).facts).nonnull;
        const operand_46 = @as([]const u32, (if (((buffers).lane_0 != null)) block_49: {
            const operand_47 = ((in).facts).capture_errors;
            const operand_48 = (in).err;

            _ = (try ((std).math).add(usize, (operand_47).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_47));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_47).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_48));

            break :block_49 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_53: {
            const operand_50 = ((in).facts).capture_errors;
            const operand_51 = (in).err;
            const operand_52 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_50).len, 1))));

            @memcpy((operand_52)[0..(operand_50).len], operand_50);

            (operand_52)[(operand_50).len] = operand_51;

            break :block_53 @as((zx_abi).zx_type_33, .{ operand_52, {}, });
        }).@"0"));
        const operand_54 = @as([]const u32, (if (((buffers).lane_1 != null)) block_57: {
            const operand_55 = ((in).facts).capture_results;
            const operand_56 = (in).result;

            _ = (try ((std).math).add(usize, (operand_55).len, 1));

            if ((!(((buffers).lane_1.?).started).*)) {
                (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_55));

                (((buffers).lane_1.?).started).* = true;
            } else {
                (((((buffers).lane_1.?).buffer).*).items).len = (operand_55).len;
            }

            (try ((((buffers).lane_1.?).buffer).*).append(allocator, operand_56));

            break :block_57 ((((buffers).lane_1.?).buffer).*).items;
        } else (block_61: {
            const operand_58 = ((in).facts).capture_results;
            const operand_59 = (in).result;
            const operand_60 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_58).len, 1))));

            @memcpy((operand_60)[0..(operand_58).len], operand_58);

            (operand_60)[(operand_58).len] = operand_59;

            break :block_61 @as((zx_abi).zx_type_33, .{ operand_60, {}, });
        }).@"0"));

        break :block_64 block_63: {
            const operand_62 = (try (allocator).create((zx_abi).zx_type_17));

            (operand_62).* = @as((zx_abi).zx_type_17, (zx_abi).zx_type_17{ .nonnull = operand_45, .capture_errors = operand_46, .capture_results = operand_54, });

            break :block_63 @as(*const (zx_abi).zx_type_17, operand_62);
        };
    };
}

fn function_1(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_32) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_17 {
    @setRuntimeSafety(true);

    const value_1: ?u32 = (in).err;
    const value_2: ?u32 = (in).result;

    if (((((block_3: {
        const operand_1 = ((in).expressions).kinds;
        const operand_2 = (in).value;

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    } == @as((zx_abi).zx_type_11, .Capture)) and ((in).count == @as(u64, 2))) and (value_1 != null)) and (value_2 != null))) {
        return block_14: {
            const operand_10 = block_9: {
                const operand_4 = (in).facts;
                const operand_5 = value_1.?;
                const operand_6 = value_2.?;

                break :block_9 block_8: {
                    const operand_7 = (try (allocator).create((zx_abi).zx_type_19));

                    (operand_7).* = @as((zx_abi).zx_type_19, (zx_abi).zx_type_19{ .facts = operand_4, .err = operand_5, .result = operand_6, });

                    break :block_8 @as(*const (zx_abi).zx_type_19, operand_7);
                };
            };
            const operand_11 = (try function_0_value(allocator, (zx_abi).value_zx_type_19_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f{ .err = (operand_10).err, .facts = (zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .capture_errors = ((operand_10).facts).capture_errors, .capture_results = ((operand_10).facts).capture_results, .nonnull = ((operand_10).facts).nonnull, .zx_origin = (operand_10).facts, }, .result = (operand_10).result, .zx_origin = operand_10, }));

            break :block_14 (if (((operand_11).zx_origin != null)) (operand_11).zx_origin.? else block_13: {
                const operand_12 = (try (allocator).create((zx_abi).zx_type_17));

                (operand_12).* = (zx_abi).zx_type_17{ .capture_errors = (operand_11).capture_errors, .capture_results = (operand_11).capture_results, .nonnull = (operand_11).nonnull, };

                break :block_13 @as(*const (zx_abi).zx_type_17, operand_12);
            });
        };
    }

    return (in).facts;
}

fn function_1_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_32_8ec0d6c8cd037da98e2aea5b29ac9f207f0bcde67b8c7979e6ec00c4b87b66a9) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 {
    @setRuntimeSafety(true);

    const value_1: ?u32 = (in).err;
    const value_2: ?u32 = (in).result;

    if (((((block_17: {
        const operand_15 = ((in).expressions).kinds;
        const operand_16 = (in).value;

        if ((operand_16 >= (operand_15).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_17 (operand_15)[@intCast(operand_16)];
    } == @as((zx_abi).zx_type_11, .Capture)) and ((in).count == @as(u64, 2))) and (block_18: {
        break :block_18 value_1;
    } != null)) and (block_19: {
        break :block_19 value_2;
    } != null))) {
        return block_26: {
            break :block_26 (try function_0_value(allocator, block_25: {
                const operand_20 = (in).facts;
                const operand_21 = block_22: {
                    break :block_22 value_1;
                }.?;
                const operand_23 = block_24: {
                    break :block_24 value_2;
                }.?;

                break :block_25 @as((zx_abi).value_zx_type_19_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f, (zx_abi).value_zx_type_19_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f{ .facts = operand_20, .err = operand_21, .result = operand_23, });
            }));
        };
    }

    return (in).facts;
}

fn function_1_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_32_8ec0d6c8cd037da98e2aea5b29ac9f207f0bcde67b8c7979e6ec00c4b87b66a9, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 {
    @setRuntimeSafety(true);

    const value_1: ?u32 = (in).err;
    const value_2: ?u32 = (in).result;

    if (((((block_29: {
        const operand_27 = ((in).expressions).kinds;
        const operand_28 = (in).value;

        if ((operand_28 >= (operand_27).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_29 (operand_27)[@intCast(operand_28)];
    } == @as((zx_abi).zx_type_11, .Capture)) and ((in).count == @as(u64, 2))) and (block_30: {
        break :block_30 value_1;
    } != null)) and (block_31: {
        break :block_31 value_2;
    } != null))) {
        return @as((zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, block_38: {
            break :block_38 (try function_0_buffered(allocator, block_37: {
                const operand_32 = (in).facts;
                const operand_33 = block_34: {
                    break :block_34 value_1;
                }.?;
                const operand_35 = block_36: {
                    break :block_36 value_2;
                }.?;

                break :block_37 @as((zx_abi).value_zx_type_19_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f, (zx_abi).value_zx_type_19_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f{ .facts = operand_32, .err = operand_33, .result = operand_35, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
        });
    }

    return (in).facts;
}

fn function_1_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_32, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_17 {
    @setRuntimeSafety(true);

    const value_1: ?u32 = (in).err;
    const value_2: ?u32 = (in).result;

    if (((((block_41: {
        const operand_39 = ((in).expressions).kinds;
        const operand_40 = (in).value;

        if ((operand_40 >= (operand_39).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_41 (operand_39)[@intCast(operand_40)];
    } == @as((zx_abi).zx_type_11, .Capture)) and ((in).count == @as(u64, 2))) and (value_1 != null)) and (value_2 != null))) {
        return (try function_0_buffered_pointer(allocator, block_47: {
            const operand_42 = (in).facts;
            const operand_43 = value_1.?;
            const operand_44 = value_2.?;

            break :block_47 block_46: {
                const operand_45 = (try (allocator).create((zx_abi).zx_type_19));

                (operand_45).* = @as((zx_abi).zx_type_19, (zx_abi).zx_type_19{ .facts = operand_42, .err = operand_43, .result = operand_44, });

                break :block_46 @as(*const (zx_abi).zx_type_19, operand_45);
            };
        }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    }

    return (in).facts;
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_32) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_17 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: *const (zx_abi).zx_type_17 = block_5: {
        const operand_1 = in;
        const operand_2 = (try function_1_value(allocator, (zx_abi).value_zx_type_32_8ec0d6c8cd037da98e2aea5b29ac9f207f0bcde67b8c7979e6ec00c4b87b66a9{ .count = (operand_1).count, .err = (operand_1).err, .expressions = (zx_abi).value_zx_type_31_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = ((operand_1).expressions).awaits, .binary_left = ((operand_1).expressions).binary_left, .binary_operators = ((operand_1).expressions).binary_operators, .binary_right = ((operand_1).expressions).binary_right, .booleans = ((operand_1).expressions).booleans, .call_arguments = ((operand_1).expressions).call_arguments, .call_functions = ((operand_1).expressions).call_functions, .call_store_count = ((operand_1).expressions).call_store_count, .call_store_first = ((operand_1).expressions).call_store_first, .call_stores = ((operand_1).expressions).call_stores, .cancellations = ((operand_1).expressions).cancellations, .captures = ((operand_1).expressions).captures, .collection_arguments = ((operand_1).expressions).collection_arguments, .collection_count = ((operand_1).expressions).collection_count, .collection_first = ((operand_1).expressions).collection_first, .collection_kinds = ((operand_1).expressions).collection_kinds, .collection_targets = ((operand_1).expressions).collection_targets, .conditional_conditions = ((operand_1).expressions).conditional_conditions, .conditional_no = ((operand_1).expressions).conditional_no, .conditional_yes = ((operand_1).expressions).conditional_yes, .enumerations = ((operand_1).expressions).enumerations, .errors = ((operand_1).expressions).errors, .floats = ((operand_1).expressions).floats, .index_targets = ((operand_1).expressions).index_targets, .index_values = ((operand_1).expressions).index_values, .integers = ((operand_1).expressions).integers, .iteration_bodies = ((operand_1).expressions).iteration_bodies, .iteration_condition_parameters = ((operand_1).expressions).iteration_condition_parameters, .iteration_conditions = ((operand_1).expressions).iteration_conditions, .iteration_initials = ((operand_1).expressions).iteration_initials, .iteration_parameters = ((operand_1).expressions).iteration_parameters, .iteration_postconditions = ((operand_1).expressions).iteration_postconditions, .kinds = ((operand_1).expressions).kinds, .lengths = ((operand_1).expressions).lengths, .match_conditions = ((operand_1).expressions).match_conditions, .match_count = ((operand_1).expressions).match_count, .match_fallbacks = ((operand_1).expressions).match_fallbacks, .match_first = ((operand_1).expressions).match_first, .match_results = ((operand_1).expressions).match_results, .match_subjects = ((operand_1).expressions).match_subjects, .negative_integers = ((operand_1).expressions).negative_integers, .object_count = ((operand_1).expressions).object_count, .object_evaluation_count = ((operand_1).expressions).object_evaluation_count, .object_evaluation_first = ((operand_1).expressions).object_evaluation_first, .object_evaluation_values = ((operand_1).expressions).object_evaluation_values, .object_field_indices = ((operand_1).expressions).object_field_indices, .object_field_values = ((operand_1).expressions).object_field_values, .object_first = ((operand_1).expressions).object_first, .optional_values = ((operand_1).expressions).optional_values, .parallel_count = ((operand_1).expressions).parallel_count, .parallel_fields = ((operand_1).expressions).parallel_fields, .parallel_first = ((operand_1).expressions).parallel_first, .parallel_tasks = ((operand_1).expressions).parallel_tasks, .payloads = ((operand_1).expressions).payloads, .projection_indices = ((operand_1).expressions).projection_indices, .projection_targets = ((operand_1).expressions).projection_targets, .references = ((operand_1).expressions).references, .scope_borrows = ((operand_1).expressions).scope_borrows, .scope_count = ((operand_1).expressions).scope_count, .scope_first = ((operand_1).expressions).scope_first, .scope_results = ((operand_1).expressions).scope_results, .scope_symbols = ((operand_1).expressions).scope_symbols, .scope_values = ((operand_1).expressions).scope_values, .sequence_count = ((operand_1).expressions).sequence_count, .sequence_first = ((operand_1).expressions).sequence_first, .sequence_items = ((operand_1).expressions).sequence_items, .some = ((operand_1).expressions).some, .span_end = ((operand_1).expressions).span_end, .span_start = ((operand_1).expressions).span_start, .stores = ((operand_1).expressions).stores, .strings = ((operand_1).expressions).strings, .task_bodies = ((operand_1).expressions).task_bodies, .task_capture_count = ((operand_1).expressions).task_capture_count, .task_capture_first = ((operand_1).expressions).task_capture_first, .task_captures = ((operand_1).expressions).task_captures, .transform_bodies = ((operand_1).expressions).transform_bodies, .transform_count = ((operand_1).expressions).transform_count, .transform_first = ((operand_1).expressions).transform_first, .transform_initials = ((operand_1).expressions).transform_initials, .transform_kinds = ((operand_1).expressions).transform_kinds, .transform_parameters = ((operand_1).expressions).transform_parameters, .transform_targets = ((operand_1).expressions).transform_targets, .types = ((operand_1).expressions).types, .unary_operands = ((operand_1).expressions).unary_operands, .unary_operators = ((operand_1).expressions).unary_operators, .update_indices = ((operand_1).expressions).update_indices, .update_targets = ((operand_1).expressions).update_targets, .update_values = ((operand_1).expressions).update_values, .zx_origin = (operand_1).expressions, }, .facts = (zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .capture_errors = ((operand_1).facts).capture_errors, .capture_results = ((operand_1).facts).capture_results, .nonnull = ((operand_1).facts).nonnull, .zx_origin = (operand_1).facts, }, .result = (operand_1).result, .value = (operand_1).value, .zx_origin = operand_1, }));

        break :block_5 (if (((operand_2).zx_origin != null)) (operand_2).zx_origin.? else block_4: {
            const operand_3 = (try (allocator).create((zx_abi).zx_type_17));

            (operand_3).* = (zx_abi).zx_type_17{ .capture_errors = (operand_2).capture_errors, .capture_results = (operand_2).capture_results, .nonnull = (operand_2).nonnull, };

            break :block_4 @as(*const (zx_abi).zx_type_17, operand_3);
        });
    };

    return value_1;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_32_8ec0d6c8cd037da98e2aea5b29ac9f207f0bcde67b8c7979e6ec00c4b87b66a9) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_6: {
        break :block_6 (try function_1_value(allocator, in));
    };

    return value_1;
}

pub fn executeBuffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_32_8ec0d6c8cd037da98e2aea5b29ac9f207f0bcde67b8c7979e6ec00c4b87b66a9, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = @as((zx_abi).value_zx_type_17_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, block_7: {
        break :block_7 (try function_1_buffered(allocator, in, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), }));
    });

    return value_1;
}

pub const buffer_lanes = .{ .{ .slot = "lane_0", .input = .{ "facts", "capture_errors", }, .output = .{ "capture_errors", }, }, .{ .slot = "lane_1", .input = .{ "facts", "capture_results", }, .output = .{ "capture_results", }, }, .{ .slot = "lane_2", .input = .{ "facts", "nonnull", }, .output = .{ "nonnull", }, }, };

