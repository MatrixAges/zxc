const std = @import("std");

const zx_native_0 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_14 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .field_names = zx_shape_14, .field_types = zx_shape_13, .first = zx_shape_13, .kinds = zx_shape_12, .labels = zx_shape_14, .names = zx_shape_14, .second = zx_shape_13, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .base = zx_shape_15, .delta = zx_shape_15, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .names = zx_shape_14, .types = zx_shape_13, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .delta = zx_shape_1, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .second = zx_shape_4, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .count = zx_shape_5, .field_names = zx_shape_14, .field_types = zx_shape_13, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .names = zx_shape_14, .offset = zx_shape_5, .second = zx_shape_4, }, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .left = zx_shape_19, .right = zx_shape_19, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .table = zx_shape_15, }, };

const zx_shape_22 = .{ .kind = .object, .fields = .{ .first = zx_shape_5, .source = zx_shape_15, .target = zx_shape_15, }, };

const zx_shape_23 = .{ .kind = .object, .fields = .{ .first = zx_shape_5, .mapping = zx_shape_13, }, };

const zx_shape_24 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .fields = zx_shape_17, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .names = zx_shape_14, .second = zx_shape_4, }, };

const zx_shape_25 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .id = zx_shape_4, }, };

const zx_shape_26 = .{ .kind = .object, .fields = .{ .delta = zx_shape_15, .id = zx_shape_4, }, };

const zx_shape_27 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_24, .delta = zx_shape_15, }, };

const zx_shape_28 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .references = zx_shape_13, .source = zx_shape_15, }, };

const zx_shape_29 = .{ .kind = .scalar, };

const zx_shape_30 = .{ .kind = .object, .fields = .{ .id = zx_shape_4, .status = zx_shape_29, }, };

const zx_shape_31 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_24, .id = zx_shape_4, .tables = zx_shape_16, }, };

const zx_shape_32 = .{ .kind = .object, .fields = .{ .id = zx_shape_4, .tables = zx_shape_16, }, };

const zx_shape_33 = .{ .kind = .object, .fields = .{ .kind = zx_shape_2, .member = zx_shape_10, .owner = zx_shape_10, }, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .ids = zx_shape_13, .kinds = zx_shape_12, .members = zx_shape_14, .owners = zx_shape_14, }, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .base = zx_shape_34, .delta = zx_shape_34, }, };

const zx_shape_36 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_24, .origin = zx_shape_33, .origins = zx_shape_35, .tables = zx_shape_16, }, };

const zx_shape_37 = .{ .kind = .object, .fields = .{ .bindings = zx_shape_34, .id = zx_shape_4, .origin = zx_shape_33, }, };

const zx_shape_38 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .mapping = zx_shape_13, .references = zx_shape_13, .source = zx_shape_15, }, };

const zx_shape_39 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_24, .tables = zx_shape_16, }, };

const zx_shape_40 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_41 = .{ .kind = .object, .fields = .{ .base = zx_shape_15, .base_origins = zx_shape_34, .first = zx_shape_5, .origin_indices = zx_shape_40, .origins = zx_shape_34, .source = zx_shape_15, }, };

const zx_shape_42 = .{ .kind = .object, .fields = .{ .delta = zx_shape_15, .mapping = zx_shape_13, .origins = zx_shape_34, .references = zx_shape_13, .status = zx_shape_5, }, };

const zx_shape_43 = .{ .kind = .object, .fields = .{ .request = zx_shape_41, .state = zx_shape_42, }, };

const zx_shape_44 = .{ .kind = .object, .fields = .{ .equal = zx_shape_1, .index = zx_shape_5, .left = zx_shape_19, .right = zx_shape_19, }, };

const zx_shape_45 = .{ .kind = .object, .fields = .{ .first = zx_shape_5, .index = zx_shape_5, .source = zx_shape_15, .target = zx_shape_15, .valid = zx_shape_1, }, };

const zx_shape_46 = .{ .kind = .object, .fields = .{ .first = zx_shape_5, .index = zx_shape_5, .mapping = zx_shape_13, }, };

const zx_shape_47 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_12, .@"1" = zx_shape_0, }, };

const zx_shape_48 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_13, .@"1" = zx_shape_0, }, };

const zx_shape_49 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_14, .@"1" = zx_shape_0, }, };

const zx_shape_50 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_14, .@"1" = zx_shape_14, }, };

const zx_shape_51 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_24, .count = zx_shape_5, .id = zx_shape_4, .index = zx_shape_5, .origin = zx_shape_33, .origins = zx_shape_35, .status = zx_shape_29, .tables = zx_shape_16, }, };

const zx_shape_52 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_13, .@"1" = zx_shape_13, }, };

const zx_shape_53 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .mapping = zx_shape_13, .references = zx_shape_13, .values = zx_shape_13, }, };

const zx_shape_54 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_24, .count = zx_shape_5, .found = zx_shape_1, .id = zx_shape_4, .index = zx_shape_5, .tables = zx_shape_16, }, };

const zx_shape_55 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .request = zx_shape_41, .state = zx_shape_42, }, };

const zx_shape_56 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_43, }, };

const zx_shape_57 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_43, .@"1" = zx_shape_1, }, };

const zx_shape_58 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_43, .@"1" = zx_shape_1, .@"2" = zx_shape_13, }, };

const zx_shape_59 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_43, .@"1" = zx_shape_1, .@"2" = zx_shape_13, .@"3" = zx_shape_42, }, };

pub const input_shape = zx_shape_43;

pub const output_shape = zx_shape_42;

pub const Input = *const (zx_abi).zx_type_43;

pub const Output = *const (zx_abi).zx_type_42;

fn function_0(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: u8) error{ }!u64 {
    const native_result = (zx_native_0).widenByte(in);

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_20) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: (zx_abi).zx_type_19 = ((in).left).*;
    const value_2: (zx_abi).zx_type_19 = ((in).right).*;

    if ((((&value_1)).kind != ((&value_2)).kind)) {
        return false;
    }

    if ((((((&value_1)).kind == @as((zx_abi).zx_type_11, .Scalar)) or (((&value_1)).kind == @as((zx_abi).zx_type_11, .Optional))) or (((&value_1)).kind == @as((zx_abi).zx_type_11, .List)))) {
        return (((&value_1)).first == ((&value_2)).first);
    }

    if ((((&value_1)).kind == @as((zx_abi).zx_type_11, .Task))) {
        return ((((&value_1)).first == ((&value_2)).first) and (((&value_1)).second == ((&value_2)).second));
    }

    if ((((&value_1)).kind == @as((zx_abi).zx_type_11, .NativeReference))) {
        return block_56: {
            const operand_54 = ((&value_1)).label;
            const operand_55 = ((&value_2)).label;

            break :block_56 ((std).mem).eql(u8, operand_54, operand_55);
        };
    }

    if (((((&value_1)).kind == @as((zx_abi).zx_type_11, .Enumeration)) and (!block_53: {
        const operand_51 = ((&value_1)).label;
        const operand_52 = ((&value_2)).label;

        break :block_53 ((std).mem).eql(u8, operand_51, operand_52);
    }))) {
        return false;
    }

    if ((((&value_1)).count != ((&value_2)).count)) {
        return false;
    }

    return block_50: {
        const state_type_2 = struct {
            children: []const u32,
            count: u64,
            field_names: []const []const u8,
            field_types: []const u32,
            first: u32,
            kind: (zx_abi).zx_type_11,
            label: []const u8,
            names: []const []const u8,
            offset: u64,
            second: u32,
        };
        const state_type_3 = struct {
            equal: bool,
            index: u64,
            left: state_type_2,
            right: state_type_2,
        };
        const operand_13 = block_12: {
            const operand_6 = block_5: {
                const operand_4 = (&value_1);

                break :block_5 state_type_2{ .children = (operand_4).children, .count = (operand_4).count, .field_names = (operand_4).field_names, .field_types = (operand_4).field_types, .first = (operand_4).first, .kind = (operand_4).kind, .label = (operand_4).label, .names = (operand_4).names, .offset = (operand_4).offset, .second = (operand_4).second, };
            };
            const operand_9 = block_8: {
                const operand_7 = (&value_2);

                break :block_8 state_type_2{ .children = (operand_7).children, .count = (operand_7).count, .field_names = (operand_7).field_names, .field_types = (operand_7).field_types, .first = (operand_7).first, .kind = (operand_7).kind, .label = (operand_7).label, .names = (operand_7).names, .offset = (operand_7).offset, .second = (operand_7).second, };
            };
            const operand_10 = @as(u64, 0);
            const operand_11 = true;

            break :block_12 state_type_3{ .left = operand_6, .right = operand_9, .index = operand_10, .equal = operand_11, };
        };

        var state_1: state_type_3 = operand_13;

        var state_changed_14 = false;

        while (((state_1).equal and ((state_1).index < ((state_1).left).count))) {
            state_1 = block_49: {
                const value_5: u64 = (((state_1).left).offset + (state_1).index);
                const value_6: u64 = (((state_1).right).offset + (state_1).index);
                const value_7: bool = block_48: {
                    const operand_17 = ((state_1).left).kind;

                    break :block_48 (if ((operand_17 == @as((zx_abi).zx_type_11, .Object))) (block_41: {
                        const operand_39 = block_35: {
                            const operand_33 = ((state_1).left).field_names;
                            const operand_34 = value_5;

                            if ((operand_34 >= (operand_33).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_35 (operand_33)[@intCast(operand_34)];
                        };
                        const operand_40 = block_38: {
                            const operand_36 = ((state_1).right).field_names;
                            const operand_37 = value_6;

                            if ((operand_37 >= (operand_36).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_38 (operand_36)[@intCast(operand_37)];
                        };

                        break :block_41 ((std).mem).eql(u8, operand_39, operand_40);
                    } and (block_44: {
                        const operand_42 = ((state_1).left).field_types;
                        const operand_43 = value_5;

                        if ((operand_43 >= (operand_42).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_44 (operand_42)[@intCast(operand_43)];
                    } == block_47: {
                        const operand_45 = ((state_1).right).field_types;
                        const operand_46 = value_6;

                        if ((operand_46 >= (operand_45).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_47 (operand_45)[@intCast(operand_46)];
                    })) else (if ((operand_17 == @as((zx_abi).zx_type_11, .Tuple))) (block_29: {
                        const operand_27 = ((state_1).left).children;
                        const operand_28 = value_5;

                        if ((operand_28 >= (operand_27).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_29 (operand_27)[@intCast(operand_28)];
                    } == block_32: {
                        const operand_30 = ((state_1).right).children;
                        const operand_31 = value_6;

                        if ((operand_31 >= (operand_30).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_32 (operand_30)[@intCast(operand_31)];
                    }) else block_26: {
                        const operand_24 = block_20: {
                            const operand_18 = ((state_1).left).names;
                            const operand_19 = value_5;

                            if ((operand_19 >= (operand_18).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_20 (operand_18)[@intCast(operand_19)];
                        };
                        const operand_25 = block_23: {
                            const operand_21 = ((state_1).right).names;
                            const operand_22 = value_6;

                            if ((operand_22 >= (operand_21).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_23 (operand_21)[@intCast(operand_22)];
                        };

                        break :block_26 ((std).mem).eql(u8, operand_24, operand_25);
                    }));
                };
                const value_8: state_type_3 = block_16: {
                    break :block_16 state_type_3{ .equal = value_7, .index = (state_1).index, .left = (state_1).left, .right = (state_1).right, };
                };
                const value_9: u64 = (value_8).index;
                const value_10: state_type_3 = block_15: {
                    break :block_15 state_type_3{ .equal = (value_8).equal, .index = (value_9 + @as(u64, 1)), .left = (value_8).left, .right = (value_8).right, };
                };

                break :block_49 value_10;
            };

            state_changed_14 = true;
        }

        break :block_50 (state_1).equal;
    };
}

fn function_4(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_11 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_2: {
        const operand_1 = in;

        break :block_2 (if ((operand_1 == @as(u8, 0))) @as((zx_abi).zx_type_11, .Scalar) else (if ((operand_1 == @as(u8, 1))) @as((zx_abi).zx_type_11, .Object) else (if ((operand_1 == @as(u8, 2))) @as((zx_abi).zx_type_11, .Optional) else (if ((operand_1 == @as(u8, 3))) @as((zx_abi).zx_type_11, .List) else (if ((operand_1 == @as(u8, 4))) @as((zx_abi).zx_type_11, .Tuple) else (if ((operand_1 == @as(u8, 5))) @as((zx_abi).zx_type_11, .ErrorSet) else (if ((operand_1 == @as(u8, 6))) @as((zx_abi).zx_type_11, .Task) else (if ((operand_1 == @as(u8, 7))) @as((zx_abi).zx_type_11, .Enumeration) else @as((zx_abi).zx_type_11, .NativeReference)))))))));
    };
}

fn function_5(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_11 {
    @setRuntimeSafety(true);

    return (try function_4(allocator, in));
}

fn function_6(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_21) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_19 {
    @setRuntimeSafety(true);

    return block_31: {
        const operand_1 = (try function_5(allocator, block_4: {
            const operand_2 = ((in).table).kinds;
            const operand_3 = (in).index;

            if ((operand_3 >= (operand_2).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_4 (operand_2)[@intCast(operand_3)];
        }));
        const operand_5 = block_8: {
            const operand_6 = ((in).table).first;
            const operand_7 = (in).index;

            if ((operand_7 >= (operand_6).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_8 (operand_6)[@intCast(operand_7)];
        };
        const operand_9 = block_12: {
            const operand_10 = ((in).table).second;
            const operand_11 = (in).index;

            if ((operand_11 >= (operand_10).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_12 (operand_10)[@intCast(operand_11)];
        };
        const operand_13 = block_16: {
            const operand_14 = ((in).table).labels;
            const operand_15 = (in).index;

            if ((operand_15 >= (operand_14).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_16 (operand_14)[@intCast(operand_15)];
        };
        const operand_17 = (try function_0(allocator, block_20: {
            const operand_18 = ((in).table).first;
            const operand_19 = (in).index;

            if ((operand_19 >= (operand_18).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_20 (operand_18)[@intCast(operand_19)];
        }));
        const operand_21 = (try function_0(allocator, block_24: {
            const operand_22 = ((in).table).second;
            const operand_23 = (in).index;

            if ((operand_23 >= (operand_22).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_24 (operand_22)[@intCast(operand_23)];
        }));
        const operand_25 = ((in).table).children;
        const operand_26 = ((in).table).field_names;
        const operand_27 = ((in).table).field_types;
        const operand_28 = ((in).table).names;

        break :block_31 block_30: {
            const operand_29 = (try (allocator).create((zx_abi).zx_type_19));

            (operand_29).* = @as((zx_abi).zx_type_19, (zx_abi).zx_type_19{ .kind = operand_1, .first = operand_5, .second = operand_9, .label = operand_13, .offset = operand_17, .count = operand_21, .children = operand_25, .field_names = operand_26, .field_types = operand_27, .names = operand_28, });

            break :block_30 @as(*const (zx_abi).zx_type_19, operand_29);
        };
    };
}

fn function_6_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_21_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    return block_60: {
        const operand_32 = (try function_5(allocator, block_35: {
            const operand_33 = ((in).table).kinds;
            const operand_34 = (in).index;

            if ((operand_34 >= (operand_33).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_35 (operand_33)[@intCast(operand_34)];
        }));
        const operand_36 = block_39: {
            const operand_37 = ((in).table).first;
            const operand_38 = (in).index;

            if ((operand_38 >= (operand_37).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_39 (operand_37)[@intCast(operand_38)];
        };
        const operand_40 = block_43: {
            const operand_41 = ((in).table).second;
            const operand_42 = (in).index;

            if ((operand_42 >= (operand_41).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_43 (operand_41)[@intCast(operand_42)];
        };
        const operand_44 = block_47: {
            const operand_45 = ((in).table).labels;
            const operand_46 = (in).index;

            if ((operand_46 >= (operand_45).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_47 (operand_45)[@intCast(operand_46)];
        };
        const operand_48 = (try function_0(allocator, block_51: {
            const operand_49 = ((in).table).first;
            const operand_50 = (in).index;

            if ((operand_50 >= (operand_49).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_51 (operand_49)[@intCast(operand_50)];
        }));
        const operand_52 = (try function_0(allocator, block_55: {
            const operand_53 = ((in).table).second;
            const operand_54 = (in).index;

            if ((operand_54 >= (operand_53).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_55 (operand_53)[@intCast(operand_54)];
        }));
        const operand_56 = ((in).table).children;
        const operand_57 = ((in).table).field_names;
        const operand_58 = ((in).table).field_types;
        const operand_59 = ((in).table).names;

        break :block_60 @as((zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_32, .first = operand_36, .second = operand_40, .label = operand_44, .offset = operand_48, .count = operand_52, .children = operand_56, .field_names = operand_57, .field_types = operand_58, .names = operand_59, });
    };
}

fn function_6_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_21_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    _ = buffers;

    return block_89: {
        const operand_61 = (try function_5(allocator, block_64: {
            const operand_62 = ((in).table).kinds;
            const operand_63 = (in).index;

            if ((operand_63 >= (operand_62).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_64 (operand_62)[@intCast(operand_63)];
        }));
        const operand_65 = block_68: {
            const operand_66 = ((in).table).first;
            const operand_67 = (in).index;

            if ((operand_67 >= (operand_66).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_68 (operand_66)[@intCast(operand_67)];
        };
        const operand_69 = block_72: {
            const operand_70 = ((in).table).second;
            const operand_71 = (in).index;

            if ((operand_71 >= (operand_70).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_72 (operand_70)[@intCast(operand_71)];
        };
        const operand_73 = block_76: {
            const operand_74 = ((in).table).labels;
            const operand_75 = (in).index;

            if ((operand_75 >= (operand_74).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_76 (operand_74)[@intCast(operand_75)];
        };
        const operand_77 = (try function_0(allocator, block_80: {
            const operand_78 = ((in).table).first;
            const operand_79 = (in).index;

            if ((operand_79 >= (operand_78).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_80 (operand_78)[@intCast(operand_79)];
        }));
        const operand_81 = (try function_0(allocator, block_84: {
            const operand_82 = ((in).table).second;
            const operand_83 = (in).index;

            if ((operand_83 >= (operand_82).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_84 (operand_82)[@intCast(operand_83)];
        }));
        const operand_85 = ((in).table).children;
        const operand_86 = ((in).table).field_names;
        const operand_87 = ((in).table).field_types;
        const operand_88 = ((in).table).names;

        break :block_89 @as((zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_61, .first = operand_65, .second = operand_69, .label = operand_73, .offset = operand_77, .count = operand_81, .children = operand_85, .field_names = operand_86, .field_types = operand_87, .names = operand_88, });
    };
}

fn function_6_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_21, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_19 {
    @setRuntimeSafety(true);

    _ = buffers;

    return block_120: {
        const operand_90 = (try function_5(allocator, block_93: {
            const operand_91 = ((in).table).kinds;
            const operand_92 = (in).index;

            if ((operand_92 >= (operand_91).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_93 (operand_91)[@intCast(operand_92)];
        }));
        const operand_94 = block_97: {
            const operand_95 = ((in).table).first;
            const operand_96 = (in).index;

            if ((operand_96 >= (operand_95).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_97 (operand_95)[@intCast(operand_96)];
        };
        const operand_98 = block_101: {
            const operand_99 = ((in).table).second;
            const operand_100 = (in).index;

            if ((operand_100 >= (operand_99).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_101 (operand_99)[@intCast(operand_100)];
        };
        const operand_102 = block_105: {
            const operand_103 = ((in).table).labels;
            const operand_104 = (in).index;

            if ((operand_104 >= (operand_103).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_105 (operand_103)[@intCast(operand_104)];
        };
        const operand_106 = (try function_0(allocator, block_109: {
            const operand_107 = ((in).table).first;
            const operand_108 = (in).index;

            if ((operand_108 >= (operand_107).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_109 (operand_107)[@intCast(operand_108)];
        }));
        const operand_110 = (try function_0(allocator, block_113: {
            const operand_111 = ((in).table).second;
            const operand_112 = (in).index;

            if ((operand_112 >= (operand_111).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_113 (operand_111)[@intCast(operand_112)];
        }));
        const operand_114 = ((in).table).children;
        const operand_115 = ((in).table).field_names;
        const operand_116 = ((in).table).field_types;
        const operand_117 = ((in).table).names;

        break :block_120 block_119: {
            const operand_118 = (try (allocator).create((zx_abi).zx_type_19));

            (operand_118).* = @as((zx_abi).zx_type_19, (zx_abi).zx_type_19{ .kind = operand_90, .first = operand_94, .second = operand_98, .label = operand_102, .offset = operand_106, .count = operand_110, .children = operand_114, .field_names = operand_115, .field_types = operand_116, .names = operand_117, });

            break :block_119 @as(*const (zx_abi).zx_type_19, operand_118);
        };
    };
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_22) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    return block_58: {
        const state_type_2 = struct {
            children: []const u32,
            field_names: []const []const u8,
            field_types: []const u32,
            first: []const u32,
            kinds: []const u8,
            labels: []const []const u8,
            names: []const []const u8,
            second: []const u32,
        };
        const state_type_3 = struct {
            first: u64,
            index: u64,
            source: state_type_2,
            target: state_type_2,
            valid: bool,
        };
        const state_type_5 = struct {
            first: u64,
            source: state_type_2,
            target: state_type_2,
        };
        const operand_17 = block_16: {
            const operand_7 = (block_6: {
                const operand_4 = in;

                break :block_6 state_type_5{ .first = (operand_4).first, .source = state_type_2{ .children = ((operand_4).source).children, .field_names = ((operand_4).source).field_names, .field_types = ((operand_4).source).field_types, .first = ((operand_4).source).first, .kinds = ((operand_4).source).kinds, .labels = ((operand_4).source).labels, .names = ((operand_4).source).names, .second = ((operand_4).source).second, }, .target = state_type_2{ .children = ((operand_4).target).children, .field_names = ((operand_4).target).field_names, .field_types = ((operand_4).target).field_types, .first = ((operand_4).target).first, .kinds = ((operand_4).target).kinds, .labels = ((operand_4).target).labels, .names = ((operand_4).target).names, .second = ((operand_4).target).second, }, };
            }).source;
            const operand_10 = (block_9: {
                const operand_8 = in;

                break :block_9 state_type_5{ .first = (operand_8).first, .source = state_type_2{ .children = ((operand_8).source).children, .field_names = ((operand_8).source).field_names, .field_types = ((operand_8).source).field_types, .first = ((operand_8).source).first, .kinds = ((operand_8).source).kinds, .labels = ((operand_8).source).labels, .names = ((operand_8).source).names, .second = ((operand_8).source).second, }, .target = state_type_2{ .children = ((operand_8).target).children, .field_names = ((operand_8).target).field_names, .field_types = ((operand_8).target).field_types, .first = ((operand_8).target).first, .kinds = ((operand_8).target).kinds, .labels = ((operand_8).target).labels, .names = ((operand_8).target).names, .second = ((operand_8).target).second, }, };
            }).target;
            const operand_13 = (block_12: {
                const operand_11 = in;

                break :block_12 state_type_5{ .first = (operand_11).first, .source = state_type_2{ .children = ((operand_11).source).children, .field_names = ((operand_11).source).field_names, .field_types = ((operand_11).source).field_types, .first = ((operand_11).source).first, .kinds = ((operand_11).source).kinds, .labels = ((operand_11).source).labels, .names = ((operand_11).source).names, .second = ((operand_11).source).second, }, .target = state_type_2{ .children = ((operand_11).target).children, .field_names = ((operand_11).target).field_names, .field_types = ((operand_11).target).field_types, .first = ((operand_11).target).first, .kinds = ((operand_11).target).kinds, .labels = ((operand_11).target).labels, .names = ((operand_11).target).names, .second = ((operand_11).target).second, }, };
            }).first;
            const operand_14 = @as(u64, 0);
            const operand_15 = true;

            break :block_16 state_type_3{ .source = operand_7, .target = operand_10, .first = operand_13, .index = operand_14, .valid = operand_15, };
        };
        const state_type_21 = struct {
            children: []const u32,
            count: u64,
            field_names: []const []const u8,
            field_types: []const u32,
            first: u32,
            kind: (zx_abi).zx_type_11,
            label: []const u8,
            names: []const []const u8,
            offset: u64,
            second: u32,
        };
        const state_type_22 = struct {
            left: state_type_21,
            right: state_type_21,
        };
        const state_type_23 = struct {
            index: u64,
            table: state_type_2,
        };

        var state_1: state_type_3 = operand_17;

        var state_changed_18 = false;

        while (((state_1).valid and ((state_1).index < (state_1).first))) {
            state_1 = block_57: {
                const value_3: bool = block_56: {
                    const operand_51 = block_50: {
                        const operand_36 = block_35: {
                            const operand_27 = block_26: {
                                const operand_24 = (state_1).source;
                                const operand_25 = (state_1).index;

                                break :block_26 state_type_23{ .table = operand_24, .index = operand_25, };
                            };
                            const operand_28 = (zx_abi).zx_type_15{ .children = ((operand_27).table).children, .field_names = ((operand_27).table).field_names, .field_types = ((operand_27).table).field_types, .first = ((operand_27).table).first, .kinds = ((operand_27).table).kinds, .labels = ((operand_27).table).labels, .names = ((operand_27).table).names, .second = ((operand_27).table).second, };
                            const operand_29 = (zx_abi).zx_type_21{ .index = (operand_27).index, .table = (&operand_28), };
                            const operand_34 = block_33: {
                                const operand_30 = (&operand_29);
                                const operand_31 = (try function_6_value(allocator, (zx_abi).value_zx_type_21_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77{ .index = (operand_30).index, .table = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_30).table).children, .field_names = ((operand_30).table).field_names, .field_types = ((operand_30).table).field_types, .first = ((operand_30).table).first, .kinds = ((operand_30).table).kinds, .labels = ((operand_30).table).labels, .names = ((operand_30).table).names, .second = ((operand_30).table).second, .zx_origin = (operand_30).table, }, .zx_origin = operand_30, }));

                                break :block_33 (if (((operand_31).zx_origin != null)) ((operand_31).zx_origin.?).* else block_32: {
                                    break :block_32 (zx_abi).zx_type_19{ .children = (operand_31).children, .count = (operand_31).count, .field_names = (operand_31).field_names, .field_types = (operand_31).field_types, .first = (operand_31).first, .kind = (operand_31).kind, .label = (operand_31).label, .names = (operand_31).names, .offset = (operand_31).offset, .second = (operand_31).second, };
                                });
                            };

                            break :block_35 state_type_21{ .children = (operand_34).children, .count = (operand_34).count, .field_names = (operand_34).field_names, .field_types = (operand_34).field_types, .first = (operand_34).first, .kind = (operand_34).kind, .label = (operand_34).label, .names = (operand_34).names, .offset = (operand_34).offset, .second = (operand_34).second, };
                        };
                        const operand_49 = block_48: {
                            const operand_40 = block_39: {
                                const operand_37 = (state_1).target;
                                const operand_38 = (state_1).index;

                                break :block_39 state_type_23{ .table = operand_37, .index = operand_38, };
                            };
                            const operand_41 = (zx_abi).zx_type_15{ .children = ((operand_40).table).children, .field_names = ((operand_40).table).field_names, .field_types = ((operand_40).table).field_types, .first = ((operand_40).table).first, .kinds = ((operand_40).table).kinds, .labels = ((operand_40).table).labels, .names = ((operand_40).table).names, .second = ((operand_40).table).second, };
                            const operand_42 = (zx_abi).zx_type_21{ .index = (operand_40).index, .table = (&operand_41), };
                            const operand_47 = block_46: {
                                const operand_43 = (&operand_42);
                                const operand_44 = (try function_6_value(allocator, (zx_abi).value_zx_type_21_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77{ .index = (operand_43).index, .table = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_43).table).children, .field_names = ((operand_43).table).field_names, .field_types = ((operand_43).table).field_types, .first = ((operand_43).table).first, .kinds = ((operand_43).table).kinds, .labels = ((operand_43).table).labels, .names = ((operand_43).table).names, .second = ((operand_43).table).second, .zx_origin = (operand_43).table, }, .zx_origin = operand_43, }));

                                break :block_46 (if (((operand_44).zx_origin != null)) ((operand_44).zx_origin.?).* else block_45: {
                                    break :block_45 (zx_abi).zx_type_19{ .children = (operand_44).children, .count = (operand_44).count, .field_names = (operand_44).field_names, .field_types = (operand_44).field_types, .first = (operand_44).first, .kind = (operand_44).kind, .label = (operand_44).label, .names = (operand_44).names, .offset = (operand_44).offset, .second = (operand_44).second, };
                                });
                            };

                            break :block_48 state_type_21{ .children = (operand_47).children, .count = (operand_47).count, .field_names = (operand_47).field_names, .field_types = (operand_47).field_types, .first = (operand_47).first, .kind = (operand_47).kind, .label = (operand_47).label, .names = (operand_47).names, .offset = (operand_47).offset, .second = (operand_47).second, };
                        };

                        break :block_50 state_type_22{ .left = operand_36, .right = operand_49, };
                    };
                    const operand_52 = (zx_abi).zx_type_19{ .children = ((operand_51).left).children, .count = ((operand_51).left).count, .field_names = ((operand_51).left).field_names, .field_types = ((operand_51).left).field_types, .first = ((operand_51).left).first, .kind = ((operand_51).left).kind, .label = ((operand_51).left).label, .names = ((operand_51).left).names, .offset = ((operand_51).left).offset, .second = ((operand_51).left).second, };
                    const operand_53 = (zx_abi).zx_type_19{ .children = ((operand_51).right).children, .count = ((operand_51).right).count, .field_names = ((operand_51).right).field_names, .field_types = ((operand_51).right).field_types, .first = ((operand_51).right).first, .kind = ((operand_51).right).kind, .label = ((operand_51).right).label, .names = ((operand_51).right).names, .offset = ((operand_51).right).offset, .second = ((operand_51).right).second, };
                    const operand_54 = (zx_abi).zx_type_20{ .left = (&operand_52), .right = (&operand_53), };
                    const operand_55 = (try function_3(allocator, (&operand_54)));

                    break :block_56 operand_55;
                };
                const value_4: state_type_3 = block_20: {
                    break :block_20 state_type_3{ .first = (state_1).first, .index = (state_1).index, .source = (state_1).source, .target = (state_1).target, .valid = value_3, };
                };
                const value_5: u64 = (value_4).index;
                const value_6: state_type_3 = block_19: {
                    break :block_19 state_type_3{ .first = (value_4).first, .index = (value_5 + @as(u64, 1)), .source = (value_4).source, .target = (value_4).target, .valid = (value_4).valid, };
                };

                break :block_57 value_6;
            };

            state_changed_18 = true;
        }

        break :block_58 (state_1).valid;
    };
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_23) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }![]const u32 {
    @setRuntimeSafety(true);

    return (block_20: {
        const operand_6 = block_5: {
            const operand_2 = (in).mapping;
            const operand_3 = (in).first;
            const operand_4 = @as(u64, 0);

            break :block_5 (zx_abi).zx_type_46{ .mapping = operand_2, .first = operand_3, .index = operand_4, };
        };

        var state_items_7: []u32 = undefined;

        var state_items_started_8 = false;

        var state_1: (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (operand_6).first, .index = (operand_6).index, .mapping = (operand_6).mapping, .zx_origin = (&operand_6), };

        while (((state_1).index < (state_1).first)) {
            state_1 = block_17: {
                const value_3: (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_16: {
                    break :block_16 @as((zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (state_1).first, .index = (state_1).index, .mapping = block_15: {
                        const operand_11 = (state_1).mapping;
                        const operand_12 = (state_1).index;

                        if ((operand_12 >= (operand_11).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_13 = (try function_2(allocator, (state_1).index));

                        break :block_15 block_14: {
                            if ((!state_items_started_8)) {
                                state_items_7 = (try (allocator).dupe(u32, operand_11));

                                state_items_started_8 = true;
                            }

                            (state_items_7)[@intCast(operand_12)] = operand_13;

                            break :block_14 state_items_7;
                        };
                    }, });
                };
                const value_4: u64 = (value_3).index;
                const value_5: (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_10: {
                    break :block_10 @as((zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (value_3).first, .index = (block_9: {
                        break :block_9 value_4;
                    } + @as(u64, 1)), .mapping = (value_3).mapping, });
                };

                break :block_17 value_5;
            };
        }

        break :block_20 block_19: {
            break :block_19 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_18: {
                break :block_18 (zx_abi).zx_type_46{ .first = (state_1).first, .index = (state_1).index, .mapping = (state_1).mapping, };
            });
        };
    }).mapping;
}

fn function_8_buffered(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_23, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }![]const u32 {
    @setRuntimeSafety(true);

    return (block_42: {
        const operand_26 = block_25: {
            const operand_22 = (in).mapping;
            const operand_23 = (in).first;
            const operand_24 = @as(u64, 0);

            break :block_25 (zx_abi).zx_type_46{ .mapping = operand_22, .first = operand_23, .index = operand_24, };
        };

        var state_capacity_27: (std).ArrayList(u32) = .empty;

        var state_capacity_started_28 = false;

        defer (state_capacity_27).deinit(allocator);

        var state_21: (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (operand_26).first, .index = (operand_26).index, .mapping = (operand_26).mapping, .zx_origin = (&operand_26), };

        while (((state_21).index < (state_21).first)) {
            state_21 = block_38: {
                const value_3: (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_37: {
                    break :block_37 @as((zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (state_21).first, .index = (state_21).index, .mapping = block_36: {
                        const operand_31 = (state_21).mapping;
                        const operand_32 = (state_21).index;

                        if ((operand_32 >= (operand_31).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_33 = (try function_2(allocator, (state_21).index));

                        break :block_36 @as([]const u32, (if (((buffers).lane_0 != null)) block_34: {
                            if ((!(((buffers).lane_0.?).started).*)) {
                                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_31));

                                (((buffers).lane_0.?).started).* = true;
                            } else {
                                (((((buffers).lane_0.?).buffer).*).items).len = (operand_31).len;
                            }

                            (((((buffers).lane_0.?).buffer).*).items)[@intCast(operand_32)] = operand_33;

                            break :block_34 ((((buffers).lane_0.?).buffer).*).items;
                        } else block_35: {
                            if ((!state_capacity_started_28)) {
                                (try (state_capacity_27).appendSlice(allocator, operand_31));

                                state_capacity_started_28 = true;
                            } else {
                                ((state_capacity_27).items).len = (operand_31).len;
                            }

                            ((state_capacity_27).items)[@intCast(operand_32)] = operand_33;

                            break :block_35 (state_capacity_27).items;
                        }));
                    }, });
                };
                const value_4: u64 = (value_3).index;
                const value_5: (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_30: {
                    break :block_30 @as((zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (value_3).first, .index = (block_29: {
                        break :block_29 value_4;
                    } + @as(u64, 1)), .mapping = (value_3).mapping, });
                };

                break :block_38 value_5;
            };
        }

        var state_owned_39: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_39);

        if (state_capacity_started_28) {
            ((state_capacity_27).items).len = ((state_21).mapping).len;

            state_owned_39 = (try (state_capacity_27).toOwnedSlice(allocator));
        }

        if (state_capacity_started_28) {
            state_21 = (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (state_21).first, .index = (state_21).index, .mapping = state_owned_39, };
        }

        break :block_42 block_41: {
            break :block_41 (if (((state_21).zx_origin != null)) ((state_21).zx_origin.?).* else block_40: {
                break :block_40 (zx_abi).zx_type_46{ .first = (state_21).first, .index = (state_21).index, .mapping = (state_21).mapping, };
            });
        };
    }).mapping;
}

fn function_8_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_23, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }![]const u32 {
    @setRuntimeSafety(true);

    return (block_64: {
        const operand_48 = block_47: {
            const operand_44 = (in).mapping;
            const operand_45 = (in).first;
            const operand_46 = @as(u64, 0);

            break :block_47 (zx_abi).zx_type_46{ .mapping = operand_44, .first = operand_45, .index = operand_46, };
        };

        var state_capacity_49: (std).ArrayList(u32) = .empty;

        var state_capacity_started_50 = false;

        defer (state_capacity_49).deinit(allocator);

        var state_43: (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (operand_48).first, .index = (operand_48).index, .mapping = (operand_48).mapping, .zx_origin = (&operand_48), };

        while (((state_43).index < (state_43).first)) {
            state_43 = block_60: {
                const value_3: (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_59: {
                    break :block_59 @as((zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (state_43).first, .index = (state_43).index, .mapping = block_58: {
                        const operand_53 = (state_43).mapping;
                        const operand_54 = (state_43).index;

                        if ((operand_54 >= (operand_53).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_55 = (try function_2(allocator, (state_43).index));

                        break :block_58 @as([]const u32, (if (((buffers).lane_0 != null)) block_56: {
                            if ((!(((buffers).lane_0.?).started).*)) {
                                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_53));

                                (((buffers).lane_0.?).started).* = true;
                            } else {
                                (((((buffers).lane_0.?).buffer).*).items).len = (operand_53).len;
                            }

                            (((((buffers).lane_0.?).buffer).*).items)[@intCast(operand_54)] = operand_55;

                            break :block_56 ((((buffers).lane_0.?).buffer).*).items;
                        } else block_57: {
                            if ((!state_capacity_started_50)) {
                                (try (state_capacity_49).appendSlice(allocator, operand_53));

                                state_capacity_started_50 = true;
                            } else {
                                ((state_capacity_49).items).len = (operand_53).len;
                            }

                            ((state_capacity_49).items)[@intCast(operand_54)] = operand_55;

                            break :block_57 (state_capacity_49).items;
                        }));
                    }, });
                };
                const value_4: u64 = (value_3).index;
                const value_5: (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_52: {
                    break :block_52 @as((zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (value_3).first, .index = (block_51: {
                        break :block_51 value_4;
                    } + @as(u64, 1)), .mapping = (value_3).mapping, });
                };

                break :block_60 value_5;
            };
        }

        var state_owned_61: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_61);

        if (state_capacity_started_50) {
            ((state_capacity_49).items).len = ((state_43).mapping).len;

            state_owned_61 = (try (state_capacity_49).toOwnedSlice(allocator));
        }

        if (state_capacity_started_50) {
            state_43 = (zx_abi).value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .first = (state_43).first, .index = (state_43).index, .mapping = state_owned_61, };
        }

        break :block_64 block_63: {
            break :block_63 (if (((state_43).zx_origin != null)) ((state_43).zx_origin.?).* else block_62: {
                break :block_62 (zx_abi).zx_type_46{ .first = (state_43).first, .index = (state_43).index, .mapping = (state_43).mapping, };
            });
        };
    }).mapping;
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_27) error{ IntegerOverflow, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_15 {
    @setRuntimeSafety(true);

    const value_1: u8 = block_49: {
        const operand_48 = ((in).candidate).kind;

        break :block_49 (if ((operand_48 == @as((zx_abi).zx_type_11, .Scalar))) @as(u8, 0) else (if ((operand_48 == @as((zx_abi).zx_type_11, .Object))) @as(u8, 1) else (if ((operand_48 == @as((zx_abi).zx_type_11, .Optional))) @as(u8, 2) else (if ((operand_48 == @as((zx_abi).zx_type_11, .List))) @as(u8, 3) else (if ((operand_48 == @as((zx_abi).zx_type_11, .Tuple))) @as(u8, 4) else (if ((operand_48 == @as((zx_abi).zx_type_11, .ErrorSet))) @as(u8, 5) else (if ((operand_48 == @as((zx_abi).zx_type_11, .Task))) @as(u8, 6) else (if ((operand_48 == @as((zx_abi).zx_type_11, .Enumeration))) @as(u8, 7) else @as(u8, 8)))))))));
    };
    const value_2: bool = ((((in).candidate).kind == @as((zx_abi).zx_type_11, .ErrorSet)) or (((in).candidate).kind == @as((zx_abi).zx_type_11, .Enumeration)));
    const value_3: u32 = block_47: {
        const operand_46 = ((in).candidate).kind;

        break :block_47 (if ((operand_46 == @as((zx_abi).zx_type_11, .Object))) (try function_2(allocator, @as(u64, (((in).delta).field_types).len))) else (if ((operand_46 == @as((zx_abi).zx_type_11, .Tuple))) (try function_2(allocator, @as(u64, (((in).delta).children).len))) else (if ((operand_46 == @as((zx_abi).zx_type_11, .ErrorSet))) (try function_2(allocator, @as(u64, (((in).delta).names).len))) else (if ((operand_46 == @as((zx_abi).zx_type_11, .Enumeration))) (try function_2(allocator, @as(u64, (((in).delta).names).len))) else ((in).candidate).first))));
    };
    const value_4: u32 = block_45: {
        const operand_44 = ((in).candidate).kind;

        break :block_45 (if ((operand_44 == @as((zx_abi).zx_type_11, .Object))) (try function_2(allocator, @as(u64, ((((in).candidate).fields).names).len))) else (if ((operand_44 == @as((zx_abi).zx_type_11, .Tuple))) (try function_2(allocator, @as(u64, (((in).candidate).children).len))) else (if ((operand_44 == @as((zx_abi).zx_type_11, .ErrorSet))) (try function_2(allocator, @as(u64, (((in).candidate).names).len))) else (if ((operand_44 == @as((zx_abi).zx_type_11, .Enumeration))) (try function_2(allocator, @as(u64, (((in).candidate).names).len))) else ((in).candidate).second))));
    };

    return block_43: {
        const operand_1 = (block_5: {
            const operand_2 = ((in).delta).kinds;
            const operand_3 = value_1;
            const operand_4 = (try (allocator).alloc(u8, (try ((std).math).add(usize, (operand_2).len, 1))));

            @memcpy((operand_4)[0..(operand_2).len], operand_2);

            (operand_4)[(operand_2).len] = operand_3;

            break :block_5 @as((zx_abi).zx_type_47, .{ operand_4, {}, });
        }).@"0";
        const operand_6 = (block_10: {
            const operand_7 = ((in).delta).first;
            const operand_8 = value_3;
            const operand_9 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_7).len, 1))));

            @memcpy((operand_9)[0..(operand_7).len], operand_7);

            (operand_9)[(operand_7).len] = operand_8;

            break :block_10 @as((zx_abi).zx_type_48, .{ operand_9, {}, });
        }).@"0";
        const operand_11 = (block_15: {
            const operand_12 = ((in).delta).second;
            const operand_13 = value_4;
            const operand_14 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_12).len, 1))));

            @memcpy((operand_14)[0..(operand_12).len], operand_12);

            (operand_14)[(operand_12).len] = operand_13;

            break :block_15 @as((zx_abi).zx_type_48, .{ operand_14, {}, });
        }).@"0";
        const operand_16 = (block_20: {
            const operand_17 = ((in).delta).labels;
            const operand_18 = ((in).candidate).label;
            const operand_19 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_17).len, 1))));

            @memcpy((operand_19)[0..(operand_17).len], operand_17);

            (operand_19)[(operand_17).len] = operand_18;

            break :block_20 @as((zx_abi).zx_type_49, .{ operand_19, {}, });
        }).@"0";
        const operand_21 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Tuple))) (block_25: {
            const operand_22 = ((in).delta).children;
            const operand_23 = ((in).candidate).children;
            const operand_24 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_22).len, (operand_23).len))));

            @memcpy((operand_24)[0..(operand_22).len], operand_22);

            @memcpy((operand_24)[(operand_22).len..], operand_23);

            break :block_25 @as((zx_abi).zx_type_48, .{ operand_24, {}, });
        }).@"0" else ((in).delta).children);
        const operand_26 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Object))) (block_30: {
            const operand_27 = ((in).delta).field_types;
            const operand_28 = (((in).candidate).fields).types;
            const operand_29 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_27).len, (operand_28).len))));

            @memcpy((operand_29)[0..(operand_27).len], operand_27);

            @memcpy((operand_29)[(operand_27).len..], operand_28);

            break :block_30 @as((zx_abi).zx_type_48, .{ operand_29, {}, });
        }).@"0" else ((in).delta).field_types);
        const operand_31 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Object))) (block_35: {
            const operand_32 = ((in).delta).field_names;
            const operand_33 = (((in).candidate).fields).names;
            const operand_34 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_32).len, (operand_33).len))));

            @memcpy((operand_34)[0..(operand_32).len], operand_32);

            @memcpy((operand_34)[(operand_32).len..], operand_33);

            break :block_35 @as((zx_abi).zx_type_49, .{ operand_34, {}, });
        }).@"0" else ((in).delta).field_names);
        const operand_36 = (if (value_2) (block_40: {
            const operand_37 = ((in).delta).names;
            const operand_38 = ((in).candidate).names;
            const operand_39 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_37).len, (operand_38).len))));

            @memcpy((operand_39)[0..(operand_37).len], operand_37);

            @memcpy((operand_39)[(operand_37).len..], operand_38);

            break :block_40 @as((zx_abi).zx_type_49, .{ operand_39, {}, });
        }).@"0" else ((in).delta).names);

        break :block_43 block_42: {
            const operand_41 = (try (allocator).create((zx_abi).zx_type_15));

            (operand_41).* = @as((zx_abi).zx_type_15, (zx_abi).zx_type_15{ .kinds = operand_1, .first = operand_6, .second = operand_11, .labels = operand_16, .children = operand_21, .field_types = operand_26, .field_names = operand_31, .names = operand_36, });

            break :block_42 @as(*const (zx_abi).zx_type_15, operand_41);
        };
    };
}

fn function_9_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_27_eb83b36bd9eb840e506cc8c01a38c13a9cdff0b6a9636a9eecf085d3c539269b) error{ IntegerOverflow, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b {
    @setRuntimeSafety(true);

    const value_1: u8 = block_100: {
        const operand_99 = ((in).candidate).kind;

        break :block_100 (if ((operand_99 == @as((zx_abi).zx_type_11, .Scalar))) @as(u8, 0) else (if ((operand_99 == @as((zx_abi).zx_type_11, .Object))) @as(u8, 1) else (if ((operand_99 == @as((zx_abi).zx_type_11, .Optional))) @as(u8, 2) else (if ((operand_99 == @as((zx_abi).zx_type_11, .List))) @as(u8, 3) else (if ((operand_99 == @as((zx_abi).zx_type_11, .Tuple))) @as(u8, 4) else (if ((operand_99 == @as((zx_abi).zx_type_11, .ErrorSet))) @as(u8, 5) else (if ((operand_99 == @as((zx_abi).zx_type_11, .Task))) @as(u8, 6) else (if ((operand_99 == @as((zx_abi).zx_type_11, .Enumeration))) @as(u8, 7) else @as(u8, 8)))))))));
    };
    const value_2: bool = ((((in).candidate).kind == @as((zx_abi).zx_type_11, .ErrorSet)) or (((in).candidate).kind == @as((zx_abi).zx_type_11, .Enumeration)));
    const value_3: u32 = block_98: {
        const operand_97 = ((in).candidate).kind;

        break :block_98 (if ((operand_97 == @as((zx_abi).zx_type_11, .Object))) (try function_2(allocator, @as(u64, (((in).delta).field_types).len))) else (if ((operand_97 == @as((zx_abi).zx_type_11, .Tuple))) (try function_2(allocator, @as(u64, (((in).delta).children).len))) else (if ((operand_97 == @as((zx_abi).zx_type_11, .ErrorSet))) (try function_2(allocator, @as(u64, (((in).delta).names).len))) else (if ((operand_97 == @as((zx_abi).zx_type_11, .Enumeration))) (try function_2(allocator, @as(u64, (((in).delta).names).len))) else ((in).candidate).first))));
    };
    const value_4: u32 = block_96: {
        const operand_95 = ((in).candidate).kind;

        break :block_96 (if ((operand_95 == @as((zx_abi).zx_type_11, .Object))) (try function_2(allocator, @as(u64, ((((in).candidate).fields).names).len))) else (if ((operand_95 == @as((zx_abi).zx_type_11, .Tuple))) (try function_2(allocator, @as(u64, (((in).candidate).children).len))) else (if ((operand_95 == @as((zx_abi).zx_type_11, .ErrorSet))) (try function_2(allocator, @as(u64, (((in).candidate).names).len))) else (if ((operand_95 == @as((zx_abi).zx_type_11, .Enumeration))) (try function_2(allocator, @as(u64, (((in).candidate).names).len))) else ((in).candidate).second))));
    };

    return block_94: {
        const operand_50 = (block_55: {
            const operand_51 = ((in).delta).kinds;
            const operand_53 = block_52: {
                break :block_52 value_1;
            };
            const operand_54 = (try (allocator).alloc(u8, (try ((std).math).add(usize, (operand_51).len, 1))));

            @memcpy((operand_54)[0..(operand_51).len], operand_51);

            (operand_54)[(operand_51).len] = operand_53;

            break :block_55 @as((zx_abi).value_zx_type_47_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_54, {}, null, });
        }).@"0";
        const operand_56 = (block_61: {
            const operand_57 = ((in).delta).first;
            const operand_59 = block_58: {
                break :block_58 value_3;
            };
            const operand_60 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_57).len, 1))));

            @memcpy((operand_60)[0..(operand_57).len], operand_57);

            (operand_60)[(operand_57).len] = operand_59;

            break :block_61 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_60, {}, null, });
        }).@"0";
        const operand_62 = (block_67: {
            const operand_63 = ((in).delta).second;
            const operand_65 = block_64: {
                break :block_64 value_4;
            };
            const operand_66 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_63).len, 1))));

            @memcpy((operand_66)[0..(operand_63).len], operand_63);

            (operand_66)[(operand_63).len] = operand_65;

            break :block_67 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_66, {}, null, });
        }).@"0";
        const operand_68 = (block_72: {
            const operand_69 = ((in).delta).labels;
            const operand_70 = ((in).candidate).label;
            const operand_71 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_69).len, 1))));

            @memcpy((operand_71)[0..(operand_69).len], operand_69);

            (operand_71)[(operand_69).len] = operand_70;

            break :block_72 @as((zx_abi).value_zx_type_49_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_71, {}, null, });
        }).@"0";
        const operand_73 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Tuple))) (block_77: {
            const operand_74 = ((in).delta).children;
            const operand_75 = ((in).candidate).children;
            const operand_76 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_74).len, (operand_75).len))));

            @memcpy((operand_76)[0..(operand_74).len], operand_74);

            @memcpy((operand_76)[(operand_74).len..], operand_75);

            break :block_77 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_76, {}, null, });
        }).@"0" else ((in).delta).children);
        const operand_78 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Object))) (block_82: {
            const operand_79 = ((in).delta).field_types;
            const operand_80 = (((in).candidate).fields).types;
            const operand_81 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_79).len, (operand_80).len))));

            @memcpy((operand_81)[0..(operand_79).len], operand_79);

            @memcpy((operand_81)[(operand_79).len..], operand_80);

            break :block_82 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_81, {}, null, });
        }).@"0" else ((in).delta).field_types);
        const operand_83 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Object))) (block_87: {
            const operand_84 = ((in).delta).field_names;
            const operand_85 = (((in).candidate).fields).names;
            const operand_86 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_84).len, (operand_85).len))));

            @memcpy((operand_86)[0..(operand_84).len], operand_84);

            @memcpy((operand_86)[(operand_84).len..], operand_85);

            break :block_87 @as((zx_abi).value_zx_type_49_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_86, {}, null, });
        }).@"0" else ((in).delta).field_names);
        const operand_88 = (if (block_89: {
            break :block_89 value_2;
        }) (block_93: {
            const operand_90 = ((in).delta).names;
            const operand_91 = ((in).candidate).names;
            const operand_92 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_90).len, (operand_91).len))));

            @memcpy((operand_92)[0..(operand_90).len], operand_90);

            @memcpy((operand_92)[(operand_90).len..], operand_91);

            break :block_93 @as((zx_abi).value_zx_type_49_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_92, {}, null, });
        }).@"0" else ((in).delta).names);

        break :block_94 @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .kinds = operand_50, .first = operand_56, .second = operand_62, .labels = operand_68, .children = operand_73, .field_types = operand_78, .field_names = operand_83, .names = operand_88, });
    };
}

fn function_9_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_27_eb83b36bd9eb840e506cc8c01a38c13a9cdff0b6a9636a9eecf085d3c539269b, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u8),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IntegerOverflow, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b {
    @setRuntimeSafety(true);

    const value_1: u8 = block_178: {
        const operand_177 = ((in).candidate).kind;

        break :block_178 (if ((operand_177 == @as((zx_abi).zx_type_11, .Scalar))) @as(u8, 0) else (if ((operand_177 == @as((zx_abi).zx_type_11, .Object))) @as(u8, 1) else (if ((operand_177 == @as((zx_abi).zx_type_11, .Optional))) @as(u8, 2) else (if ((operand_177 == @as((zx_abi).zx_type_11, .List))) @as(u8, 3) else (if ((operand_177 == @as((zx_abi).zx_type_11, .Tuple))) @as(u8, 4) else (if ((operand_177 == @as((zx_abi).zx_type_11, .ErrorSet))) @as(u8, 5) else (if ((operand_177 == @as((zx_abi).zx_type_11, .Task))) @as(u8, 6) else (if ((operand_177 == @as((zx_abi).zx_type_11, .Enumeration))) @as(u8, 7) else @as(u8, 8)))))))));
    };
    const value_2: bool = ((((in).candidate).kind == @as((zx_abi).zx_type_11, .ErrorSet)) or (((in).candidate).kind == @as((zx_abi).zx_type_11, .Enumeration)));
    const value_3: u32 = block_176: {
        const operand_175 = ((in).candidate).kind;

        break :block_176 (if ((operand_175 == @as((zx_abi).zx_type_11, .Object))) (try function_2(allocator, @as(u64, (((in).delta).field_types).len))) else (if ((operand_175 == @as((zx_abi).zx_type_11, .Tuple))) (try function_2(allocator, @as(u64, (((in).delta).children).len))) else (if ((operand_175 == @as((zx_abi).zx_type_11, .ErrorSet))) (try function_2(allocator, @as(u64, (((in).delta).names).len))) else (if ((operand_175 == @as((zx_abi).zx_type_11, .Enumeration))) (try function_2(allocator, @as(u64, (((in).delta).names).len))) else ((in).candidate).first))));
    };
    const value_4: u32 = block_174: {
        const operand_173 = ((in).candidate).kind;

        break :block_174 (if ((operand_173 == @as((zx_abi).zx_type_11, .Object))) (try function_2(allocator, @as(u64, ((((in).candidate).fields).names).len))) else (if ((operand_173 == @as((zx_abi).zx_type_11, .Tuple))) (try function_2(allocator, @as(u64, (((in).candidate).children).len))) else (if ((operand_173 == @as((zx_abi).zx_type_11, .ErrorSet))) (try function_2(allocator, @as(u64, (((in).candidate).names).len))) else (if ((operand_173 == @as((zx_abi).zx_type_11, .Enumeration))) (try function_2(allocator, @as(u64, (((in).candidate).names).len))) else ((in).candidate).second))));
    };

    return block_172: {
        const operand_101 = @as([]const u8, (if (((buffers).lane_4 != null)) block_105: {
            const operand_102 = ((in).delta).kinds;
            const operand_104 = block_103: {
                break :block_103 value_1;
            };

            _ = (try ((std).math).add(usize, (operand_102).len, 1));

            if ((!(((buffers).lane_4.?).started).*)) {
                (try ((((buffers).lane_4.?).buffer).*).appendSlice(allocator, operand_102));

                (((buffers).lane_4.?).started).* = true;
            } else {
                (((((buffers).lane_4.?).buffer).*).items).len = (operand_102).len;
            }

            (try ((((buffers).lane_4.?).buffer).*).append(allocator, operand_104));

            break :block_105 ((((buffers).lane_4.?).buffer).*).items;
        } else (block_110: {
            const operand_106 = ((in).delta).kinds;
            const operand_108 = block_107: {
                break :block_107 value_1;
            };
            const operand_109 = (try (allocator).alloc(u8, (try ((std).math).add(usize, (operand_106).len, 1))));

            @memcpy((operand_109)[0..(operand_106).len], operand_106);

            (operand_109)[(operand_106).len] = operand_108;

            break :block_110 @as((zx_abi).value_zx_type_47_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_109, {}, null, });
        }).@"0"));
        const operand_111 = @as([]const u32, (if (((buffers).lane_3 != null)) block_115: {
            const operand_112 = ((in).delta).first;
            const operand_114 = block_113: {
                break :block_113 value_3;
            };

            _ = (try ((std).math).add(usize, (operand_112).len, 1));

            if ((!(((buffers).lane_3.?).started).*)) {
                (try ((((buffers).lane_3.?).buffer).*).appendSlice(allocator, operand_112));

                (((buffers).lane_3.?).started).* = true;
            } else {
                (((((buffers).lane_3.?).buffer).*).items).len = (operand_112).len;
            }

            (try ((((buffers).lane_3.?).buffer).*).append(allocator, operand_114));

            break :block_115 ((((buffers).lane_3.?).buffer).*).items;
        } else (block_120: {
            const operand_116 = ((in).delta).first;
            const operand_118 = block_117: {
                break :block_117 value_3;
            };
            const operand_119 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_116).len, 1))));

            @memcpy((operand_119)[0..(operand_116).len], operand_116);

            (operand_119)[(operand_116).len] = operand_118;

            break :block_120 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_119, {}, null, });
        }).@"0"));
        const operand_121 = @as([]const u32, (if (((buffers).lane_7 != null)) block_125: {
            const operand_122 = ((in).delta).second;
            const operand_124 = block_123: {
                break :block_123 value_4;
            };

            _ = (try ((std).math).add(usize, (operand_122).len, 1));

            if ((!(((buffers).lane_7.?).started).*)) {
                (try ((((buffers).lane_7.?).buffer).*).appendSlice(allocator, operand_122));

                (((buffers).lane_7.?).started).* = true;
            } else {
                (((((buffers).lane_7.?).buffer).*).items).len = (operand_122).len;
            }

            (try ((((buffers).lane_7.?).buffer).*).append(allocator, operand_124));

            break :block_125 ((((buffers).lane_7.?).buffer).*).items;
        } else (block_130: {
            const operand_126 = ((in).delta).second;
            const operand_128 = block_127: {
                break :block_127 value_4;
            };
            const operand_129 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_126).len, 1))));

            @memcpy((operand_129)[0..(operand_126).len], operand_126);

            (operand_129)[(operand_126).len] = operand_128;

            break :block_130 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_129, {}, null, });
        }).@"0"));
        const operand_131 = @as([]const []const u8, (if (((buffers).lane_5 != null)) block_134: {
            const operand_132 = ((in).delta).labels;
            const operand_133 = ((in).candidate).label;

            _ = (try ((std).math).add(usize, (operand_132).len, 1));

            if ((!(((buffers).lane_5.?).started).*)) {
                (try ((((buffers).lane_5.?).buffer).*).appendSlice(allocator, operand_132));

                (((buffers).lane_5.?).started).* = true;
            } else {
                (((((buffers).lane_5.?).buffer).*).items).len = (operand_132).len;
            }

            (try ((((buffers).lane_5.?).buffer).*).append(allocator, operand_133));

            break :block_134 ((((buffers).lane_5.?).buffer).*).items;
        } else (block_138: {
            const operand_135 = ((in).delta).labels;
            const operand_136 = ((in).candidate).label;
            const operand_137 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_135).len, 1))));

            @memcpy((operand_137)[0..(operand_135).len], operand_135);

            (operand_137)[(operand_135).len] = operand_136;

            break :block_138 @as((zx_abi).value_zx_type_49_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_137, {}, null, });
        }).@"0"));
        const operand_139 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Tuple))) @as([]const u32, (if (((buffers).lane_0 != null)) block_142: {
            const operand_140 = ((in).delta).children;
            const operand_141 = ((in).candidate).children;

            _ = (try ((std).math).add(usize, (operand_140).len, (operand_141).len));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_140));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_140).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_141));

            break :block_142 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_146: {
            const operand_143 = ((in).delta).children;
            const operand_144 = ((in).candidate).children;
            const operand_145 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_143).len, (operand_144).len))));

            @memcpy((operand_145)[0..(operand_143).len], operand_143);

            @memcpy((operand_145)[(operand_143).len..], operand_144);

            break :block_146 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_145, {}, null, });
        }).@"0")) else ((in).delta).children);
        const operand_147 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Object))) @as([]const u32, (if (((buffers).lane_2 != null)) block_150: {
            const operand_148 = ((in).delta).field_types;
            const operand_149 = (((in).candidate).fields).types;

            _ = (try ((std).math).add(usize, (operand_148).len, (operand_149).len));

            if ((!(((buffers).lane_2.?).started).*)) {
                (try ((((buffers).lane_2.?).buffer).*).appendSlice(allocator, operand_148));

                (((buffers).lane_2.?).started).* = true;
            } else {
                (((((buffers).lane_2.?).buffer).*).items).len = (operand_148).len;
            }

            (try ((((buffers).lane_2.?).buffer).*).appendSlice(allocator, operand_149));

            break :block_150 ((((buffers).lane_2.?).buffer).*).items;
        } else (block_154: {
            const operand_151 = ((in).delta).field_types;
            const operand_152 = (((in).candidate).fields).types;
            const operand_153 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_151).len, (operand_152).len))));

            @memcpy((operand_153)[0..(operand_151).len], operand_151);

            @memcpy((operand_153)[(operand_151).len..], operand_152);

            break :block_154 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_153, {}, null, });
        }).@"0")) else ((in).delta).field_types);
        const operand_155 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Object))) @as([]const []const u8, (if (((buffers).lane_1 != null)) block_158: {
            const operand_156 = ((in).delta).field_names;
            const operand_157 = (((in).candidate).fields).names;

            _ = (try ((std).math).add(usize, (operand_156).len, (operand_157).len));

            if ((!(((buffers).lane_1.?).started).*)) {
                (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_156));

                (((buffers).lane_1.?).started).* = true;
            } else {
                (((((buffers).lane_1.?).buffer).*).items).len = (operand_156).len;
            }

            (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_157));

            break :block_158 ((((buffers).lane_1.?).buffer).*).items;
        } else (block_162: {
            const operand_159 = ((in).delta).field_names;
            const operand_160 = (((in).candidate).fields).names;
            const operand_161 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_159).len, (operand_160).len))));

            @memcpy((operand_161)[0..(operand_159).len], operand_159);

            @memcpy((operand_161)[(operand_159).len..], operand_160);

            break :block_162 @as((zx_abi).value_zx_type_49_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_161, {}, null, });
        }).@"0")) else ((in).delta).field_names);
        const operand_163 = (if (block_164: {
            break :block_164 value_2;
        }) @as([]const []const u8, (if (((buffers).lane_6 != null)) block_167: {
            const operand_165 = ((in).delta).names;
            const operand_166 = ((in).candidate).names;

            _ = (try ((std).math).add(usize, (operand_165).len, (operand_166).len));

            if ((!(((buffers).lane_6.?).started).*)) {
                (try ((((buffers).lane_6.?).buffer).*).appendSlice(allocator, operand_165));

                (((buffers).lane_6.?).started).* = true;
            } else {
                (((((buffers).lane_6.?).buffer).*).items).len = (operand_165).len;
            }

            (try ((((buffers).lane_6.?).buffer).*).appendSlice(allocator, operand_166));

            break :block_167 ((((buffers).lane_6.?).buffer).*).items;
        } else (block_171: {
            const operand_168 = ((in).delta).names;
            const operand_169 = ((in).candidate).names;
            const operand_170 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_168).len, (operand_169).len))));

            @memcpy((operand_170)[0..(operand_168).len], operand_168);

            @memcpy((operand_170)[(operand_168).len..], operand_169);

            break :block_171 @as((zx_abi).value_zx_type_49_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_170, {}, null, });
        }).@"0")) else ((in).delta).names);

        break :block_172 @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .kinds = operand_101, .first = operand_111, .second = operand_121, .labels = operand_131, .children = operand_139, .field_types = operand_147, .field_names = operand_155, .names = operand_163, });
    };
}

fn function_9_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_27, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u8),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IntegerOverflow, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_15 {
    @setRuntimeSafety(true);

    const value_1: u8 = block_251: {
        const operand_250 = ((in).candidate).kind;

        break :block_251 (if ((operand_250 == @as((zx_abi).zx_type_11, .Scalar))) @as(u8, 0) else (if ((operand_250 == @as((zx_abi).zx_type_11, .Object))) @as(u8, 1) else (if ((operand_250 == @as((zx_abi).zx_type_11, .Optional))) @as(u8, 2) else (if ((operand_250 == @as((zx_abi).zx_type_11, .List))) @as(u8, 3) else (if ((operand_250 == @as((zx_abi).zx_type_11, .Tuple))) @as(u8, 4) else (if ((operand_250 == @as((zx_abi).zx_type_11, .ErrorSet))) @as(u8, 5) else (if ((operand_250 == @as((zx_abi).zx_type_11, .Task))) @as(u8, 6) else (if ((operand_250 == @as((zx_abi).zx_type_11, .Enumeration))) @as(u8, 7) else @as(u8, 8)))))))));
    };
    const value_2: bool = ((((in).candidate).kind == @as((zx_abi).zx_type_11, .ErrorSet)) or (((in).candidate).kind == @as((zx_abi).zx_type_11, .Enumeration)));
    const value_3: u32 = block_249: {
        const operand_248 = ((in).candidate).kind;

        break :block_249 (if ((operand_248 == @as((zx_abi).zx_type_11, .Object))) (try function_2(allocator, @as(u64, (((in).delta).field_types).len))) else (if ((operand_248 == @as((zx_abi).zx_type_11, .Tuple))) (try function_2(allocator, @as(u64, (((in).delta).children).len))) else (if ((operand_248 == @as((zx_abi).zx_type_11, .ErrorSet))) (try function_2(allocator, @as(u64, (((in).delta).names).len))) else (if ((operand_248 == @as((zx_abi).zx_type_11, .Enumeration))) (try function_2(allocator, @as(u64, (((in).delta).names).len))) else ((in).candidate).first))));
    };
    const value_4: u32 = block_247: {
        const operand_246 = ((in).candidate).kind;

        break :block_247 (if ((operand_246 == @as((zx_abi).zx_type_11, .Object))) (try function_2(allocator, @as(u64, ((((in).candidate).fields).names).len))) else (if ((operand_246 == @as((zx_abi).zx_type_11, .Tuple))) (try function_2(allocator, @as(u64, (((in).candidate).children).len))) else (if ((operand_246 == @as((zx_abi).zx_type_11, .ErrorSet))) (try function_2(allocator, @as(u64, (((in).candidate).names).len))) else (if ((operand_246 == @as((zx_abi).zx_type_11, .Enumeration))) (try function_2(allocator, @as(u64, (((in).candidate).names).len))) else ((in).candidate).second))));
    };

    return block_245: {
        const operand_179 = @as([]const u8, (if (((buffers).lane_4 != null)) block_182: {
            const operand_180 = ((in).delta).kinds;
            const operand_181 = value_1;

            _ = (try ((std).math).add(usize, (operand_180).len, 1));

            if ((!(((buffers).lane_4.?).started).*)) {
                (try ((((buffers).lane_4.?).buffer).*).appendSlice(allocator, operand_180));

                (((buffers).lane_4.?).started).* = true;
            } else {
                (((((buffers).lane_4.?).buffer).*).items).len = (operand_180).len;
            }

            (try ((((buffers).lane_4.?).buffer).*).append(allocator, operand_181));

            break :block_182 ((((buffers).lane_4.?).buffer).*).items;
        } else (block_186: {
            const operand_183 = ((in).delta).kinds;
            const operand_184 = value_1;
            const operand_185 = (try (allocator).alloc(u8, (try ((std).math).add(usize, (operand_183).len, 1))));

            @memcpy((operand_185)[0..(operand_183).len], operand_183);

            (operand_185)[(operand_183).len] = operand_184;

            break :block_186 @as((zx_abi).zx_type_47, .{ operand_185, {}, });
        }).@"0"));
        const operand_187 = @as([]const u32, (if (((buffers).lane_3 != null)) block_190: {
            const operand_188 = ((in).delta).first;
            const operand_189 = value_3;

            _ = (try ((std).math).add(usize, (operand_188).len, 1));

            if ((!(((buffers).lane_3.?).started).*)) {
                (try ((((buffers).lane_3.?).buffer).*).appendSlice(allocator, operand_188));

                (((buffers).lane_3.?).started).* = true;
            } else {
                (((((buffers).lane_3.?).buffer).*).items).len = (operand_188).len;
            }

            (try ((((buffers).lane_3.?).buffer).*).append(allocator, operand_189));

            break :block_190 ((((buffers).lane_3.?).buffer).*).items;
        } else (block_194: {
            const operand_191 = ((in).delta).first;
            const operand_192 = value_3;
            const operand_193 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_191).len, 1))));

            @memcpy((operand_193)[0..(operand_191).len], operand_191);

            (operand_193)[(operand_191).len] = operand_192;

            break :block_194 @as((zx_abi).zx_type_48, .{ operand_193, {}, });
        }).@"0"));
        const operand_195 = @as([]const u32, (if (((buffers).lane_7 != null)) block_198: {
            const operand_196 = ((in).delta).second;
            const operand_197 = value_4;

            _ = (try ((std).math).add(usize, (operand_196).len, 1));

            if ((!(((buffers).lane_7.?).started).*)) {
                (try ((((buffers).lane_7.?).buffer).*).appendSlice(allocator, operand_196));

                (((buffers).lane_7.?).started).* = true;
            } else {
                (((((buffers).lane_7.?).buffer).*).items).len = (operand_196).len;
            }

            (try ((((buffers).lane_7.?).buffer).*).append(allocator, operand_197));

            break :block_198 ((((buffers).lane_7.?).buffer).*).items;
        } else (block_202: {
            const operand_199 = ((in).delta).second;
            const operand_200 = value_4;
            const operand_201 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_199).len, 1))));

            @memcpy((operand_201)[0..(operand_199).len], operand_199);

            (operand_201)[(operand_199).len] = operand_200;

            break :block_202 @as((zx_abi).zx_type_48, .{ operand_201, {}, });
        }).@"0"));
        const operand_203 = @as([]const []const u8, (if (((buffers).lane_5 != null)) block_206: {
            const operand_204 = ((in).delta).labels;
            const operand_205 = ((in).candidate).label;

            _ = (try ((std).math).add(usize, (operand_204).len, 1));

            if ((!(((buffers).lane_5.?).started).*)) {
                (try ((((buffers).lane_5.?).buffer).*).appendSlice(allocator, operand_204));

                (((buffers).lane_5.?).started).* = true;
            } else {
                (((((buffers).lane_5.?).buffer).*).items).len = (operand_204).len;
            }

            (try ((((buffers).lane_5.?).buffer).*).append(allocator, operand_205));

            break :block_206 ((((buffers).lane_5.?).buffer).*).items;
        } else (block_210: {
            const operand_207 = ((in).delta).labels;
            const operand_208 = ((in).candidate).label;
            const operand_209 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_207).len, 1))));

            @memcpy((operand_209)[0..(operand_207).len], operand_207);

            (operand_209)[(operand_207).len] = operand_208;

            break :block_210 @as((zx_abi).zx_type_49, .{ operand_209, {}, });
        }).@"0"));
        const operand_211 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Tuple))) @as([]const u32, (if (((buffers).lane_0 != null)) block_214: {
            const operand_212 = ((in).delta).children;
            const operand_213 = ((in).candidate).children;

            _ = (try ((std).math).add(usize, (operand_212).len, (operand_213).len));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_212));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_212).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_213));

            break :block_214 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_218: {
            const operand_215 = ((in).delta).children;
            const operand_216 = ((in).candidate).children;
            const operand_217 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_215).len, (operand_216).len))));

            @memcpy((operand_217)[0..(operand_215).len], operand_215);

            @memcpy((operand_217)[(operand_215).len..], operand_216);

            break :block_218 @as((zx_abi).zx_type_48, .{ operand_217, {}, });
        }).@"0")) else ((in).delta).children);
        const operand_219 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Object))) @as([]const u32, (if (((buffers).lane_2 != null)) block_222: {
            const operand_220 = ((in).delta).field_types;
            const operand_221 = (((in).candidate).fields).types;

            _ = (try ((std).math).add(usize, (operand_220).len, (operand_221).len));

            if ((!(((buffers).lane_2.?).started).*)) {
                (try ((((buffers).lane_2.?).buffer).*).appendSlice(allocator, operand_220));

                (((buffers).lane_2.?).started).* = true;
            } else {
                (((((buffers).lane_2.?).buffer).*).items).len = (operand_220).len;
            }

            (try ((((buffers).lane_2.?).buffer).*).appendSlice(allocator, operand_221));

            break :block_222 ((((buffers).lane_2.?).buffer).*).items;
        } else (block_226: {
            const operand_223 = ((in).delta).field_types;
            const operand_224 = (((in).candidate).fields).types;
            const operand_225 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_223).len, (operand_224).len))));

            @memcpy((operand_225)[0..(operand_223).len], operand_223);

            @memcpy((operand_225)[(operand_223).len..], operand_224);

            break :block_226 @as((zx_abi).zx_type_48, .{ operand_225, {}, });
        }).@"0")) else ((in).delta).field_types);
        const operand_227 = (if ((((in).candidate).kind == @as((zx_abi).zx_type_11, .Object))) @as([]const []const u8, (if (((buffers).lane_1 != null)) block_230: {
            const operand_228 = ((in).delta).field_names;
            const operand_229 = (((in).candidate).fields).names;

            _ = (try ((std).math).add(usize, (operand_228).len, (operand_229).len));

            if ((!(((buffers).lane_1.?).started).*)) {
                (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_228));

                (((buffers).lane_1.?).started).* = true;
            } else {
                (((((buffers).lane_1.?).buffer).*).items).len = (operand_228).len;
            }

            (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_229));

            break :block_230 ((((buffers).lane_1.?).buffer).*).items;
        } else (block_234: {
            const operand_231 = ((in).delta).field_names;
            const operand_232 = (((in).candidate).fields).names;
            const operand_233 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_231).len, (operand_232).len))));

            @memcpy((operand_233)[0..(operand_231).len], operand_231);

            @memcpy((operand_233)[(operand_231).len..], operand_232);

            break :block_234 @as((zx_abi).zx_type_49, .{ operand_233, {}, });
        }).@"0")) else ((in).delta).field_names);
        const operand_235 = (if (value_2) @as([]const []const u8, (if (((buffers).lane_6 != null)) block_238: {
            const operand_236 = ((in).delta).names;
            const operand_237 = ((in).candidate).names;

            _ = (try ((std).math).add(usize, (operand_236).len, (operand_237).len));

            if ((!(((buffers).lane_6.?).started).*)) {
                (try ((((buffers).lane_6.?).buffer).*).appendSlice(allocator, operand_236));

                (((buffers).lane_6.?).started).* = true;
            } else {
                (((((buffers).lane_6.?).buffer).*).items).len = (operand_236).len;
            }

            (try ((((buffers).lane_6.?).buffer).*).appendSlice(allocator, operand_237));

            break :block_238 ((((buffers).lane_6.?).buffer).*).items;
        } else (block_242: {
            const operand_239 = ((in).delta).names;
            const operand_240 = ((in).candidate).names;
            const operand_241 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_239).len, (operand_240).len))));

            @memcpy((operand_241)[0..(operand_239).len], operand_239);

            @memcpy((operand_241)[(operand_239).len..], operand_240);

            break :block_242 @as((zx_abi).zx_type_49, .{ operand_241, {}, });
        }).@"0")) else ((in).delta).names);

        break :block_245 block_244: {
            const operand_243 = (try (allocator).create((zx_abi).zx_type_15));

            (operand_243).* = @as((zx_abi).zx_type_15, (zx_abi).zx_type_15{ .kinds = operand_179, .first = operand_187, .second = operand_195, .labels = operand_203, .children = operand_211, .field_types = operand_219, .field_names = operand_227, .names = operand_235, });

            break :block_244 @as(*const (zx_abi).zx_type_15, operand_243);
        };
    };
}

fn function_10(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_28) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_24 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_11 = (try function_5(allocator, block_56: {
        const operand_54 = ((in).source).kinds;
        const operand_55 = (in).index;

        if ((operand_55 >= (operand_54).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_56 (operand_54)[@intCast(operand_55)];
    }));
    const value_2: bool = (((value_1 == @as((zx_abi).zx_type_11, .Optional)) or (value_1 == @as((zx_abi).zx_type_11, .List))) or (value_1 == @as((zx_abi).zx_type_11, .Task)));
    const value_3: u64 = (try function_0(allocator, block_53: {
        const operand_51 = ((in).source).first;
        const operand_52 = (in).index;

        if ((operand_52 >= (operand_51).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_53 (operand_51)[@intCast(operand_52)];
    }));
    const value_4: u64 = (try function_0(allocator, block_50: {
        const operand_48 = ((in).source).second;
        const operand_49 = (in).index;

        if ((operand_49 >= (operand_48).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_50 (operand_48)[@intCast(operand_49)];
    }));

    return block_47: {
        const operand_1 = value_1;
        const operand_2 = (if (value_2) block_5: {
            const operand_3 = (in).references;
            const operand_4 = @as(u64, 0);

            if ((operand_4 >= (operand_3).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_5 (operand_3)[@intCast(operand_4)];
        } else block_8: {
            const operand_6 = ((in).source).first;
            const operand_7 = (in).index;

            if ((operand_7 >= (operand_6).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_8 (operand_6)[@intCast(operand_7)];
        });
        const operand_9 = (if ((value_1 == @as((zx_abi).zx_type_11, .Task))) block_12: {
            const operand_10 = (in).references;
            const operand_11 = @as(u64, 1);

            if ((operand_11 >= (operand_10).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_12 (operand_10)[@intCast(operand_11)];
        } else @as(u32, 0));
        const operand_13 = block_16: {
            const operand_14 = ((in).source).labels;
            const operand_15 = (in).index;

            if ((operand_15 >= (operand_14).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_16 (operand_14)[@intCast(operand_15)];
        };
        const operand_17 = (if ((value_1 == @as((zx_abi).zx_type_11, .Tuple))) (in).references else block_18: {
            break :block_18 (try (allocator).dupe(u32, (&[_]u32{})));
        });
        const operand_19 = block_34: {
            const operand_20 = (if ((value_1 == @as((zx_abi).zx_type_11, .Object))) block_28: {
                const operand_21 = ((in).source).field_names;
                const operand_22 = value_3;
                const operand_23 = value_4;
                const operand_25 = block_24: {
                    break :block_24 (try (allocator).dupe([]const u8, (&[_][]const u8{})));
                };

                if (((operand_22 > (operand_21).len) or (operand_23 > ((operand_21).len - operand_22)))) {
                    return error.IndexOutOfBounds;
                }

                const operand_26 = @as(usize, @intCast(operand_22));
                const operand_27 = @as(usize, @intCast(operand_23));

                _ = (try ((std).math).add(usize, ((operand_21).len - operand_27), (operand_25).len));

                break :block_28 (operand_21)[operand_26..(operand_26 + operand_27)];
            } else block_29: {
                break :block_29 (try (allocator).dupe([]const u8, (&[_][]const u8{})));
            });
            const operand_30 = (if ((value_1 == @as((zx_abi).zx_type_11, .Object))) (in).references else block_31: {
                break :block_31 (try (allocator).dupe(u32, (&[_]u32{})));
            });

            break :block_34 block_33: {
                const operand_32 = (try (allocator).create((zx_abi).zx_type_17));

                (operand_32).* = @as((zx_abi).zx_type_17, (zx_abi).zx_type_17{ .names = operand_20, .types = operand_30, });

                break :block_33 @as(*const (zx_abi).zx_type_17, operand_32);
            };
        };
        const operand_35 = (if (((value_1 == @as((zx_abi).zx_type_11, .Enumeration)) or (value_1 == @as((zx_abi).zx_type_11, .ErrorSet)))) block_43: {
            const operand_36 = ((in).source).names;
            const operand_37 = value_3;
            const operand_38 = value_4;
            const operand_40 = block_39: {
                break :block_39 (try (allocator).dupe([]const u8, (&[_][]const u8{})));
            };

            if (((operand_37 > (operand_36).len) or (operand_38 > ((operand_36).len - operand_37)))) {
                return error.IndexOutOfBounds;
            }

            const operand_41 = @as(usize, @intCast(operand_37));
            const operand_42 = @as(usize, @intCast(operand_38));

            _ = (try ((std).math).add(usize, ((operand_36).len - operand_42), (operand_40).len));

            break :block_43 (operand_36)[operand_41..(operand_41 + operand_42)];
        } else block_44: {
            break :block_44 (try (allocator).dupe([]const u8, (&[_][]const u8{})));
        });

        break :block_47 block_46: {
            const operand_45 = (try (allocator).create((zx_abi).zx_type_24));

            (operand_45).* = @as((zx_abi).zx_type_24, (zx_abi).zx_type_24{ .kind = operand_1, .first = operand_2, .second = operand_9, .label = operand_13, .children = operand_17, .fields = operand_19, .names = operand_35, });

            break :block_46 @as(*const (zx_abi).zx_type_24, operand_45);
        };
    };
}

fn function_10_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_28_bc0beef4baed6cbec65527f285ce2af317364f06c28bd549a5782c80f0e63a13) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_11 = (try function_5(allocator, block_123: {
        const operand_121 = ((in).source).kinds;
        const operand_122 = (in).index;

        if ((operand_122 >= (operand_121).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_123 (operand_121)[@intCast(operand_122)];
    }));
    const value_2: bool = (((block_118: {
        break :block_118 value_1;
    } == @as((zx_abi).zx_type_11, .Optional)) or (block_119: {
        break :block_119 value_1;
    } == @as((zx_abi).zx_type_11, .List))) or (block_120: {
        break :block_120 value_1;
    } == @as((zx_abi).zx_type_11, .Task)));
    const value_3: u64 = (try function_0(allocator, block_117: {
        const operand_115 = ((in).source).first;
        const operand_116 = (in).index;

        if ((operand_116 >= (operand_115).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_117 (operand_115)[@intCast(operand_116)];
    }));
    const value_4: u64 = (try function_0(allocator, block_114: {
        const operand_112 = ((in).source).second;
        const operand_113 = (in).index;

        if ((operand_113 >= (operand_112).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_114 (operand_112)[@intCast(operand_113)];
    }));

    return block_111: {
        const operand_57 = block_58: {
            break :block_58 value_1;
        };
        const operand_59 = (if (block_60: {
            break :block_60 value_2;
        }) block_63: {
            const operand_61 = (in).references;
            const operand_62 = @as(u64, 0);

            if ((operand_62 >= (operand_61).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_63 (operand_61)[@intCast(operand_62)];
        } else block_66: {
            const operand_64 = ((in).source).first;
            const operand_65 = (in).index;

            if ((operand_65 >= (operand_64).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_66 (operand_64)[@intCast(operand_65)];
        });
        const operand_67 = (if ((block_68: {
            break :block_68 value_1;
        } == @as((zx_abi).zx_type_11, .Task))) block_71: {
            const operand_69 = (in).references;
            const operand_70 = @as(u64, 1);

            if ((operand_70 >= (operand_69).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_71 (operand_69)[@intCast(operand_70)];
        } else @as(u32, 0));
        const operand_72 = block_75: {
            const operand_73 = ((in).source).labels;
            const operand_74 = (in).index;

            if ((operand_74 >= (operand_73).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_75 (operand_73)[@intCast(operand_74)];
        };
        const operand_76 = (if ((block_77: {
            break :block_77 value_1;
        } == @as((zx_abi).zx_type_11, .Tuple))) (in).references else block_78: {
            break :block_78 (try (allocator).dupe(u32, (&[_]u32{})));
        });
        const operand_79 = block_96: {
            const operand_80 = (if ((block_81: {
                break :block_81 value_1;
            } == @as((zx_abi).zx_type_11, .Object))) block_91: {
                const operand_82 = ((in).source).field_names;
                const operand_84 = block_83: {
                    break :block_83 value_3;
                };
                const operand_86 = block_85: {
                    break :block_85 value_4;
                };
                const operand_88 = block_87: {
                    break :block_87 (try (allocator).dupe([]const u8, (&[_][]const u8{})));
                };

                if (((operand_84 > (operand_82).len) or (operand_86 > ((operand_82).len - operand_84)))) {
                    return error.IndexOutOfBounds;
                }

                const operand_89 = @as(usize, @intCast(operand_84));
                const operand_90 = @as(usize, @intCast(operand_86));

                _ = (try ((std).math).add(usize, ((operand_82).len - operand_90), (operand_88).len));

                break :block_91 (operand_82)[operand_89..(operand_89 + operand_90)];
            } else block_92: {
                break :block_92 (try (allocator).dupe([]const u8, (&[_][]const u8{})));
            });
            const operand_93 = (if ((block_94: {
                break :block_94 value_1;
            } == @as((zx_abi).zx_type_11, .Object))) (in).references else block_95: {
                break :block_95 (try (allocator).dupe(u32, (&[_]u32{})));
            });

            break :block_96 @as((zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = operand_80, .types = operand_93, });
        };
        const operand_97 = (if (((block_98: {
            break :block_98 value_1;
        } == @as((zx_abi).zx_type_11, .Enumeration)) or (block_99: {
            break :block_99 value_1;
        } == @as((zx_abi).zx_type_11, .ErrorSet)))) block_109: {
            const operand_100 = ((in).source).names;
            const operand_102 = block_101: {
                break :block_101 value_3;
            };
            const operand_104 = block_103: {
                break :block_103 value_4;
            };
            const operand_106 = block_105: {
                break :block_105 (try (allocator).dupe([]const u8, (&[_][]const u8{})));
            };

            if (((operand_102 > (operand_100).len) or (operand_104 > ((operand_100).len - operand_102)))) {
                return error.IndexOutOfBounds;
            }

            const operand_107 = @as(usize, @intCast(operand_102));
            const operand_108 = @as(usize, @intCast(operand_104));

            _ = (try ((std).math).add(usize, ((operand_100).len - operand_108), (operand_106).len));

            break :block_109 (operand_100)[operand_107..(operand_107 + operand_108)];
        } else block_110: {
            break :block_110 (try (allocator).dupe([]const u8, (&[_][]const u8{})));
        });

        break :block_111 @as((zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384, (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .kind = operand_57, .first = operand_59, .second = operand_67, .label = operand_72, .children = operand_76, .fields = operand_79, .names = operand_97, });
    };
}

fn function_11(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_30) error{ }!u64 {
    @setRuntimeSafety(true);

    return block_2: {
        const operand_1 = (in).status;

        break :block_2 (if ((operand_1 == @as((zx_abi).zx_type_29, .Missing))) @as(u64, 0) else (if ((operand_1 == @as((zx_abi).zx_type_29, .Conflict))) @as(u64, 1) else ((try function_0(allocator, (in).id)) + @as(u64, 2))));
    };
}

fn function_12(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_24) error{ OutOfMemory, }!*const (zx_abi).zx_type_19 {
    @setRuntimeSafety(true);

    const value_1: u64 = block_15: {
        const operand_14 = (in).kind;

        break :block_15 (if ((operand_14 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_14 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_13: {
        const operand_1 = (in).kind;
        const operand_2 = (in).first;
        const operand_3 = (in).second;
        const operand_4 = (in).label;
        const operand_5 = @as(u64, 0);
        const operand_6 = value_1;
        const operand_7 = (in).children;
        const operand_8 = ((in).fields).names;
        const operand_9 = ((in).fields).types;
        const operand_10 = (in).names;

        break :block_13 block_12: {
            const operand_11 = (try (allocator).create((zx_abi).zx_type_19));

            (operand_11).* = @as((zx_abi).zx_type_19, (zx_abi).zx_type_19{ .kind = operand_1, .first = operand_2, .second = operand_3, .label = operand_4, .offset = operand_5, .count = operand_6, .children = operand_7, .field_names = operand_8, .field_types = operand_9, .names = operand_10, });

            break :block_12 @as(*const (zx_abi).zx_type_19, operand_11);
        };
    };
}

fn function_12_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384) error{ OutOfMemory, }!(zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: u64 = block_29: {
        const operand_28 = (in).kind;

        break :block_29 (if ((operand_28 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_28 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_27: {
        const operand_16 = (in).kind;
        const operand_17 = (in).first;
        const operand_18 = (in).second;
        const operand_19 = (in).label;
        const operand_20 = @as(u64, 0);
        const operand_21 = block_22: {
            break :block_22 value_1;
        };
        const operand_23 = (in).children;
        const operand_24 = ((in).fields).names;
        const operand_25 = ((in).fields).types;
        const operand_26 = (in).names;

        break :block_27 @as((zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_16, .first = operand_17, .second = operand_18, .label = operand_19, .offset = operand_20, .count = operand_21, .children = operand_23, .field_names = operand_24, .field_types = operand_25, .names = operand_26, });
    };
}

fn function_12_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ OutOfMemory, }!(zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    _ = allocator;

    _ = buffers;

    const value_1: u64 = block_43: {
        const operand_42 = (in).kind;

        break :block_43 (if ((operand_42 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_42 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_41: {
        const operand_30 = (in).kind;
        const operand_31 = (in).first;
        const operand_32 = (in).second;
        const operand_33 = (in).label;
        const operand_34 = @as(u64, 0);
        const operand_35 = block_36: {
            break :block_36 value_1;
        };
        const operand_37 = (in).children;
        const operand_38 = ((in).fields).names;
        const operand_39 = ((in).fields).types;
        const operand_40 = (in).names;

        break :block_41 @as((zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_19_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_30, .first = operand_31, .second = operand_32, .label = operand_33, .offset = operand_34, .count = operand_35, .children = operand_37, .field_names = operand_38, .field_types = operand_39, .names = operand_40, });
    };
}

fn function_12_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_24, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ OutOfMemory, }!*const (zx_abi).zx_type_19 {
    @setRuntimeSafety(true);

    _ = buffers;

    const value_1: u64 = block_58: {
        const operand_57 = (in).kind;

        break :block_58 (if ((operand_57 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_57 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_56: {
        const operand_44 = (in).kind;
        const operand_45 = (in).first;
        const operand_46 = (in).second;
        const operand_47 = (in).label;
        const operand_48 = @as(u64, 0);
        const operand_49 = value_1;
        const operand_50 = (in).children;
        const operand_51 = ((in).fields).names;
        const operand_52 = ((in).fields).types;
        const operand_53 = (in).names;

        break :block_56 block_55: {
            const operand_54 = (try (allocator).create((zx_abi).zx_type_19));

            (operand_54).* = @as((zx_abi).zx_type_19, (zx_abi).zx_type_19{ .kind = operand_44, .first = operand_45, .second = operand_46, .label = operand_47, .offset = operand_48, .count = operand_49, .children = operand_50, .field_names = operand_51, .field_types = operand_52, .names = operand_53, });

            break :block_55 @as(*const (zx_abi).zx_type_19, operand_54);
        };
    };
}

fn function_13(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_31) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_0(allocator, (in).id));
    const value_2: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_3: bool = (value_1 >= value_2);
    const value_4: (zx_abi).zx_type_15 = (if (value_3) (((in).tables).delta).* else (((in).tables).base).*);
    const value_5: u64 = (if (value_3) (value_1 - value_2) else value_1);

    return block_13: {
        const operand_1 = (&value_4);
        const operand_2 = value_5;
        const operand_3 = (zx_abi).zx_type_21{ .table = operand_1, .index = operand_2, };
        const operand_4 = (&operand_3);
        const operand_5 = (try function_6_value(allocator, (zx_abi).value_zx_type_21_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77{ .index = (operand_4).index, .table = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_4).table).children, .field_names = ((operand_4).table).field_names, .field_types = ((operand_4).table).field_types, .first = ((operand_4).table).first, .kinds = ((operand_4).table).kinds, .labels = ((operand_4).table).labels, .names = ((operand_4).table).names, .second = ((operand_4).table).second, .zx_origin = (operand_4).table, }, .zx_origin = operand_4, }));

        var state_borrow_6: (zx_abi).zx_type_19 = undefined;

        state_borrow_6 = (zx_abi).zx_type_19{ .children = (operand_5).children, .count = (operand_5).count, .field_names = (operand_5).field_names, .field_types = (operand_5).field_types, .first = (operand_5).first, .kind = (operand_5).kind, .label = (operand_5).label, .names = (operand_5).names, .offset = (operand_5).offset, .second = (operand_5).second, };

        const operand_7 = ((operand_5).zx_origin orelse (&state_borrow_6));
        const operand_8 = (in).candidate;
        const operand_9 = (try function_12_value(allocator, (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_8).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_8).fields).names, .types = ((operand_8).fields).types, .zx_origin = (operand_8).fields, }, .first = (operand_8).first, .kind = (operand_8).kind, .label = (operand_8).label, .names = (operand_8).names, .second = (operand_8).second, .zx_origin = operand_8, }));

        var state_borrow_10: (zx_abi).zx_type_19 = undefined;

        state_borrow_10 = (zx_abi).zx_type_19{ .children = (operand_9).children, .count = (operand_9).count, .field_names = (operand_9).field_names, .field_types = (operand_9).field_types, .first = (operand_9).first, .kind = (operand_9).kind, .label = (operand_9).label, .names = (operand_9).names, .offset = (operand_9).offset, .second = (operand_9).second, };

        const operand_11 = ((operand_9).zx_origin orelse (&state_borrow_10));
        const operand_12 = (zx_abi).zx_type_20{ .left = operand_7, .right = operand_11, };

        break :block_13 (try function_3(allocator, (&operand_12)));
    };
}

fn function_14(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_32) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_18 {
    @setRuntimeSafety(true);

    const value_1: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_2: u64 = (try function_0(allocator, (in).id));
    const value_3: bool = (value_2 >= value_1);
    const value_4: *const (zx_abi).zx_type_15 = (if (value_3) ((in).tables).delta else ((in).tables).base);
    const value_5: u64 = (if (value_3) (value_2 - value_1) else value_2);

    return block_20: {
        const operand_1 = (try function_4(allocator, block_4: {
            const operand_2 = (value_4).kinds;
            const operand_3 = value_5;

            if ((operand_3 >= (operand_2).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_4 (operand_2)[@intCast(operand_3)];
        }));
        const operand_5 = block_8: {
            const operand_6 = (value_4).first;
            const operand_7 = value_5;

            if ((operand_7 >= (operand_6).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_8 (operand_6)[@intCast(operand_7)];
        };
        const operand_9 = block_12: {
            const operand_10 = (value_4).second;
            const operand_11 = value_5;

            if ((operand_11 >= (operand_10).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_12 (operand_10)[@intCast(operand_11)];
        };
        const operand_13 = block_16: {
            const operand_14 = (value_4).labels;
            const operand_15 = value_5;

            if ((operand_15 >= (operand_14).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_16 (operand_14)[@intCast(operand_15)];
        };
        const operand_17 = value_3;

        break :block_20 block_19: {
            const operand_18 = (try (allocator).create((zx_abi).zx_type_18));

            (operand_18).* = @as((zx_abi).zx_type_18, (zx_abi).zx_type_18{ .kind = operand_1, .first = operand_5, .second = operand_9, .label = operand_13, .delta = operand_17, });

            break :block_19 @as(*const (zx_abi).zx_type_18, operand_18);
        };
    };
}

fn function_14_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_32_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce {
    @setRuntimeSafety(true);

    const value_1: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_2: u64 = (try function_0(allocator, (in).id));
    const value_3: bool = (block_49: {
        break :block_49 value_2;
    } >= block_50: {
        break :block_50 value_1;
    });
    const value_4: (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = (if (block_48: {
        break :block_48 value_3;
    }) ((in).tables).delta else ((in).tables).base);
    const value_5: u64 = (if (block_44: {
        break :block_44 value_3;
    }) (block_45: {
        break :block_45 value_2;
    } - block_46: {
        break :block_46 value_1;
    }) else block_47: {
        break :block_47 value_2;
    });

    return block_43: {
        const operand_21 = (try function_4(allocator, block_25: {
            const operand_23 = (value_4).kinds;
            const operand_24 = block_22: {
                break :block_22 value_5;
            };

            if ((operand_24 >= (operand_23).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_25 (operand_23)[@intCast(operand_24)];
        }));
        const operand_26 = block_30: {
            const operand_28 = (value_4).first;
            const operand_29 = block_27: {
                break :block_27 value_5;
            };

            if ((operand_29 >= (operand_28).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_30 (operand_28)[@intCast(operand_29)];
        };
        const operand_31 = block_35: {
            const operand_33 = (value_4).second;
            const operand_34 = block_32: {
                break :block_32 value_5;
            };

            if ((operand_34 >= (operand_33).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_35 (operand_33)[@intCast(operand_34)];
        };
        const operand_36 = block_40: {
            const operand_38 = (value_4).labels;
            const operand_39 = block_37: {
                break :block_37 value_5;
            };

            if ((operand_39 >= (operand_38).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_40 (operand_38)[@intCast(operand_39)];
        };
        const operand_41 = block_42: {
            break :block_42 value_3;
        };

        break :block_43 @as((zx_abi).value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .kind = operand_21, .first = operand_26, .second = operand_31, .label = operand_36, .delta = operand_41, });
    };
}

fn function_15(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_32) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_18 {
    @setRuntimeSafety(true);

    return block_5: {
        const operand_1 = in;
        const operand_2 = (try function_14_value(allocator, (zx_abi).value_zx_type_32_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d{ .id = (operand_1).id, .tables = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).base).children, .field_names = (((operand_1).tables).base).field_names, .field_types = (((operand_1).tables).base).field_types, .first = (((operand_1).tables).base).first, .kinds = (((operand_1).tables).base).kinds, .labels = (((operand_1).tables).base).labels, .names = (((operand_1).tables).base).names, .second = (((operand_1).tables).base).second, .zx_origin = ((operand_1).tables).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).delta).children, .field_names = (((operand_1).tables).delta).field_names, .field_types = (((operand_1).tables).delta).field_types, .first = (((operand_1).tables).delta).first, .kinds = (((operand_1).tables).delta).kinds, .labels = (((operand_1).tables).delta).labels, .names = (((operand_1).tables).delta).names, .second = (((operand_1).tables).delta).second, .zx_origin = ((operand_1).tables).delta, }, .zx_origin = (operand_1).tables, }, .zx_origin = operand_1, }));

        break :block_5 (if (((operand_2).zx_origin != null)) (operand_2).zx_origin.? else block_4: {
            const operand_3 = (try (allocator).create((zx_abi).zx_type_18));

            (operand_3).* = (zx_abi).zx_type_18{ .delta = (operand_2).delta, .first = (operand_2).first, .kind = (operand_2).kind, .label = (operand_2).label, .second = (operand_2).second, };

            break :block_4 @as(*const (zx_abi).zx_type_18, operand_3);
        });
    };
}

fn function_15_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_32_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce {
    @setRuntimeSafety(true);

    return block_6: {
        break :block_6 (try function_14_value(allocator, in));
    };
}

fn function_16(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_36) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_30 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, ((((in).origins).base).ids).len) + @as(u64, ((((in).origins).delta).ids).len));
    const value_2: u32 = @as(u32, 0);

    return block_92: {
        const state_type_2 = struct {
            names: []const []const u8,
            types: []const u32,
        };
        const state_type_3 = struct {
            children: []const u32,
            fields: state_type_2,
            first: u32,
            kind: (zx_abi).zx_type_11,
            label: []const u8,
            names: []const []const u8,
            second: u32,
        };
        const state_type_4 = struct {
            kind: u8,
            member: []const u8,
            owner: []const u8,
        };
        const state_type_5 = struct {
            ids: []const u32,
            kinds: []const u8,
            members: []const []const u8,
            owners: []const []const u8,
        };
        const state_type_6 = struct {
            base: state_type_5,
            delta: state_type_5,
        };
        const state_type_7 = struct {
            children: []const u32,
            field_names: []const []const u8,
            field_types: []const u32,
            first: []const u32,
            kinds: []const u8,
            labels: []const []const u8,
            names: []const []const u8,
            second: []const u32,
        };
        const state_type_8 = struct {
            base: state_type_7,
            delta: state_type_7,
        };
        const state_type_9 = struct {
            candidate: state_type_3,
            count: u64,
            id: u32,
            index: u64,
            origin: state_type_4,
            origins: state_type_6,
            status: (zx_abi).zx_type_29,
            tables: state_type_8,
        };
        const state_type_11 = struct {
            candidate: state_type_3,
            origin: state_type_4,
            origins: state_type_6,
            tables: state_type_8,
        };
        const operand_28 = block_27: {
            const operand_13 = (block_12: {
                const operand_10 = in;

                break :block_12 state_type_11{ .candidate = state_type_3{ .children = ((operand_10).candidate).children, .fields = state_type_2{ .names = (((operand_10).candidate).fields).names, .types = (((operand_10).candidate).fields).types, }, .first = ((operand_10).candidate).first, .kind = ((operand_10).candidate).kind, .label = ((operand_10).candidate).label, .names = ((operand_10).candidate).names, .second = ((operand_10).candidate).second, }, .origin = state_type_4{ .kind = ((operand_10).origin).kind, .member = ((operand_10).origin).member, .owner = ((operand_10).origin).owner, }, .origins = state_type_6{ .base = state_type_5{ .ids = (((operand_10).origins).base).ids, .kinds = (((operand_10).origins).base).kinds, .members = (((operand_10).origins).base).members, .owners = (((operand_10).origins).base).owners, }, .delta = state_type_5{ .ids = (((operand_10).origins).delta).ids, .kinds = (((operand_10).origins).delta).kinds, .members = (((operand_10).origins).delta).members, .owners = (((operand_10).origins).delta).owners, }, }, .tables = state_type_8{ .base = state_type_7{ .children = (((operand_10).tables).base).children, .field_names = (((operand_10).tables).base).field_names, .field_types = (((operand_10).tables).base).field_types, .first = (((operand_10).tables).base).first, .kinds = (((operand_10).tables).base).kinds, .labels = (((operand_10).tables).base).labels, .names = (((operand_10).tables).base).names, .second = (((operand_10).tables).base).second, }, .delta = state_type_7{ .children = (((operand_10).tables).delta).children, .field_names = (((operand_10).tables).delta).field_names, .field_types = (((operand_10).tables).delta).field_types, .first = (((operand_10).tables).delta).first, .kinds = (((operand_10).tables).delta).kinds, .labels = (((operand_10).tables).delta).labels, .names = (((operand_10).tables).delta).names, .second = (((operand_10).tables).delta).second, }, }, };
            }).tables;
            const operand_16 = (block_15: {
                const operand_14 = in;

                break :block_15 state_type_11{ .candidate = state_type_3{ .children = ((operand_14).candidate).children, .fields = state_type_2{ .names = (((operand_14).candidate).fields).names, .types = (((operand_14).candidate).fields).types, }, .first = ((operand_14).candidate).first, .kind = ((operand_14).candidate).kind, .label = ((operand_14).candidate).label, .names = ((operand_14).candidate).names, .second = ((operand_14).candidate).second, }, .origin = state_type_4{ .kind = ((operand_14).origin).kind, .member = ((operand_14).origin).member, .owner = ((operand_14).origin).owner, }, .origins = state_type_6{ .base = state_type_5{ .ids = (((operand_14).origins).base).ids, .kinds = (((operand_14).origins).base).kinds, .members = (((operand_14).origins).base).members, .owners = (((operand_14).origins).base).owners, }, .delta = state_type_5{ .ids = (((operand_14).origins).delta).ids, .kinds = (((operand_14).origins).delta).kinds, .members = (((operand_14).origins).delta).members, .owners = (((operand_14).origins).delta).owners, }, }, .tables = state_type_8{ .base = state_type_7{ .children = (((operand_14).tables).base).children, .field_names = (((operand_14).tables).base).field_names, .field_types = (((operand_14).tables).base).field_types, .first = (((operand_14).tables).base).first, .kinds = (((operand_14).tables).base).kinds, .labels = (((operand_14).tables).base).labels, .names = (((operand_14).tables).base).names, .second = (((operand_14).tables).base).second, }, .delta = state_type_7{ .children = (((operand_14).tables).delta).children, .field_names = (((operand_14).tables).delta).field_names, .field_types = (((operand_14).tables).delta).field_types, .first = (((operand_14).tables).delta).first, .kinds = (((operand_14).tables).delta).kinds, .labels = (((operand_14).tables).delta).labels, .names = (((operand_14).tables).delta).names, .second = (((operand_14).tables).delta).second, }, }, };
            }).origins;
            const operand_19 = (block_18: {
                const operand_17 = in;

                break :block_18 state_type_11{ .candidate = state_type_3{ .children = ((operand_17).candidate).children, .fields = state_type_2{ .names = (((operand_17).candidate).fields).names, .types = (((operand_17).candidate).fields).types, }, .first = ((operand_17).candidate).first, .kind = ((operand_17).candidate).kind, .label = ((operand_17).candidate).label, .names = ((operand_17).candidate).names, .second = ((operand_17).candidate).second, }, .origin = state_type_4{ .kind = ((operand_17).origin).kind, .member = ((operand_17).origin).member, .owner = ((operand_17).origin).owner, }, .origins = state_type_6{ .base = state_type_5{ .ids = (((operand_17).origins).base).ids, .kinds = (((operand_17).origins).base).kinds, .members = (((operand_17).origins).base).members, .owners = (((operand_17).origins).base).owners, }, .delta = state_type_5{ .ids = (((operand_17).origins).delta).ids, .kinds = (((operand_17).origins).delta).kinds, .members = (((operand_17).origins).delta).members, .owners = (((operand_17).origins).delta).owners, }, }, .tables = state_type_8{ .base = state_type_7{ .children = (((operand_17).tables).base).children, .field_names = (((operand_17).tables).base).field_names, .field_types = (((operand_17).tables).base).field_types, .first = (((operand_17).tables).base).first, .kinds = (((operand_17).tables).base).kinds, .labels = (((operand_17).tables).base).labels, .names = (((operand_17).tables).base).names, .second = (((operand_17).tables).base).second, }, .delta = state_type_7{ .children = (((operand_17).tables).delta).children, .field_names = (((operand_17).tables).delta).field_names, .field_types = (((operand_17).tables).delta).field_types, .first = (((operand_17).tables).delta).first, .kinds = (((operand_17).tables).delta).kinds, .labels = (((operand_17).tables).delta).labels, .names = (((operand_17).tables).delta).names, .second = (((operand_17).tables).delta).second, }, }, };
            }).origin;
            const operand_22 = (block_21: {
                const operand_20 = in;

                break :block_21 state_type_11{ .candidate = state_type_3{ .children = ((operand_20).candidate).children, .fields = state_type_2{ .names = (((operand_20).candidate).fields).names, .types = (((operand_20).candidate).fields).types, }, .first = ((operand_20).candidate).first, .kind = ((operand_20).candidate).kind, .label = ((operand_20).candidate).label, .names = ((operand_20).candidate).names, .second = ((operand_20).candidate).second, }, .origin = state_type_4{ .kind = ((operand_20).origin).kind, .member = ((operand_20).origin).member, .owner = ((operand_20).origin).owner, }, .origins = state_type_6{ .base = state_type_5{ .ids = (((operand_20).origins).base).ids, .kinds = (((operand_20).origins).base).kinds, .members = (((operand_20).origins).base).members, .owners = (((operand_20).origins).base).owners, }, .delta = state_type_5{ .ids = (((operand_20).origins).delta).ids, .kinds = (((operand_20).origins).delta).kinds, .members = (((operand_20).origins).delta).members, .owners = (((operand_20).origins).delta).owners, }, }, .tables = state_type_8{ .base = state_type_7{ .children = (((operand_20).tables).base).children, .field_names = (((operand_20).tables).base).field_names, .field_types = (((operand_20).tables).base).field_types, .first = (((operand_20).tables).base).first, .kinds = (((operand_20).tables).base).kinds, .labels = (((operand_20).tables).base).labels, .names = (((operand_20).tables).base).names, .second = (((operand_20).tables).base).second, }, .delta = state_type_7{ .children = (((operand_20).tables).delta).children, .field_names = (((operand_20).tables).delta).field_names, .field_types = (((operand_20).tables).delta).field_types, .first = (((operand_20).tables).delta).first, .kinds = (((operand_20).tables).delta).kinds, .labels = (((operand_20).tables).delta).labels, .names = (((operand_20).tables).delta).names, .second = (((operand_20).tables).delta).second, }, }, };
            }).candidate;
            const operand_23 = value_1;
            const operand_24 = @as(u64, 0);
            const operand_25 = @as((zx_abi).zx_type_29, .Missing);
            const operand_26 = value_2;

            break :block_27 state_type_9{ .tables = operand_13, .origins = operand_16, .origin = operand_19, .candidate = operand_22, .count = operand_23, .index = operand_24, .status = operand_25, .id = operand_26, };
        };
        const state_type_35 = struct {
            candidate: state_type_3,
            id: u32,
            tables: state_type_8,
        };
        const state_type_49 = struct {
            id: u32,
            tables: state_type_8,
        };
        const state_type_63 = struct {
            delta: bool,
            first: u32,
            kind: (zx_abi).zx_type_11,
            label: []const u8,
            second: u32,
        };

        var state_1: state_type_9 = operand_28;

        var state_changed_29 = false;

        while ((((state_1).status == @as((zx_abi).zx_type_29, .Missing)) and ((state_1).index < (state_1).count))) {
            state_1 = block_86: {
                const value_5: u64 = @as(u64, ((((state_1).origins).base).ids).len);
                const value_6: bool = ((state_1).index >= value_5);
                const value_7: state_type_5 = (if (value_6) ((state_1).origins).delta else ((state_1).origins).base);
                const value_8: u64 = (if (value_6) ((state_1).index - value_5) else (state_1).index);
                const value_9: u32 = block_85: {
                    const operand_83 = (value_7).ids;
                    const operand_84 = value_8;

                    if ((operand_84 >= (operand_83).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_85 (operand_83)[@intCast(operand_84)];
                };
                const value_10: bool = (((block_70: {
                    const operand_68 = (value_7).kinds;
                    const operand_69 = value_8;

                    if ((operand_69 >= (operand_68).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_70 (operand_68)[@intCast(operand_69)];
                } == ((state_1).origin).kind) and block_76: {
                    const operand_74 = block_73: {
                        const operand_71 = (value_7).owners;
                        const operand_72 = value_8;

                        if ((operand_72 >= (operand_71).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_73 (operand_71)[@intCast(operand_72)];
                    };
                    const operand_75 = ((state_1).origin).owner;

                    break :block_76 ((std).mem).eql(u8, operand_74, operand_75);
                }) and block_82: {
                    const operand_80 = block_79: {
                        const operand_77 = (value_7).members;
                        const operand_78 = value_8;

                        if ((operand_78 >= (operand_77).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_79 (operand_77)[@intCast(operand_78)];
                    };
                    const operand_81 = ((state_1).origin).member;

                    break :block_82 ((std).mem).eql(u8, operand_80, operand_81);
                });
                const value_11: bool = (value_10 and block_67: {
                    const operand_65 = (block_64: {
                        const operand_53 = block_52: {
                            const operand_50 = (state_1).tables;
                            const operand_51 = value_9;

                            break :block_52 state_type_49{ .tables = operand_50, .id = operand_51, };
                        };
                        const operand_54 = (zx_abi).zx_type_15{ .children = (((operand_53).tables).base).children, .field_names = (((operand_53).tables).base).field_names, .field_types = (((operand_53).tables).base).field_types, .first = (((operand_53).tables).base).first, .kinds = (((operand_53).tables).base).kinds, .labels = (((operand_53).tables).base).labels, .names = (((operand_53).tables).base).names, .second = (((operand_53).tables).base).second, };
                        const operand_55 = (zx_abi).zx_type_15{ .children = (((operand_53).tables).delta).children, .field_names = (((operand_53).tables).delta).field_names, .field_types = (((operand_53).tables).delta).field_types, .first = (((operand_53).tables).delta).first, .kinds = (((operand_53).tables).delta).kinds, .labels = (((operand_53).tables).delta).labels, .names = (((operand_53).tables).delta).names, .second = (((operand_53).tables).delta).second, };
                        const operand_56 = (zx_abi).zx_type_16{ .base = (&operand_54), .delta = (&operand_55), };
                        const operand_57 = (zx_abi).zx_type_32{ .id = (operand_53).id, .tables = (&operand_56), };
                        const operand_62 = block_61: {
                            const operand_58 = (&operand_57);
                            const operand_59 = (try function_15_value(allocator, (zx_abi).value_zx_type_32_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d{ .id = (operand_58).id, .tables = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_58).tables).base).children, .field_names = (((operand_58).tables).base).field_names, .field_types = (((operand_58).tables).base).field_types, .first = (((operand_58).tables).base).first, .kinds = (((operand_58).tables).base).kinds, .labels = (((operand_58).tables).base).labels, .names = (((operand_58).tables).base).names, .second = (((operand_58).tables).base).second, .zx_origin = ((operand_58).tables).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_58).tables).delta).children, .field_names = (((operand_58).tables).delta).field_names, .field_types = (((operand_58).tables).delta).field_types, .first = (((operand_58).tables).delta).first, .kinds = (((operand_58).tables).delta).kinds, .labels = (((operand_58).tables).delta).labels, .names = (((operand_58).tables).delta).names, .second = (((operand_58).tables).delta).second, .zx_origin = ((operand_58).tables).delta, }, .zx_origin = (operand_58).tables, }, .zx_origin = operand_58, }));

                            break :block_61 (if (((operand_59).zx_origin != null)) ((operand_59).zx_origin.?).* else block_60: {
                                break :block_60 (zx_abi).zx_type_18{ .delta = (operand_59).delta, .first = (operand_59).first, .kind = (operand_59).kind, .label = (operand_59).label, .second = (operand_59).second, };
                            });
                        };

                        break :block_64 state_type_63{ .delta = (operand_62).delta, .first = (operand_62).first, .kind = (operand_62).kind, .label = (operand_62).label, .second = (operand_62).second, };
                    }).label;
                    const operand_66 = ((state_1).candidate).label;

                    break :block_67 ((std).mem).eql(u8, operand_65, operand_66);
                });
                const value_12: (zx_abi).zx_type_29 = (if ((!value_11)) @as((zx_abi).zx_type_29, .Missing) else (if (block_48: {
                    const operand_40 = block_39: {
                        const operand_36 = (state_1).tables;
                        const operand_37 = value_9;
                        const operand_38 = (state_1).candidate;

                        break :block_39 state_type_35{ .tables = operand_36, .id = operand_37, .candidate = operand_38, };
                    };
                    const operand_41 = (zx_abi).zx_type_17{ .names = (((operand_40).candidate).fields).names, .types = (((operand_40).candidate).fields).types, };
                    const operand_42 = (zx_abi).zx_type_24{ .children = ((operand_40).candidate).children, .fields = (&operand_41), .first = ((operand_40).candidate).first, .kind = ((operand_40).candidate).kind, .label = ((operand_40).candidate).label, .names = ((operand_40).candidate).names, .second = ((operand_40).candidate).second, };
                    const operand_43 = (zx_abi).zx_type_15{ .children = (((operand_40).tables).base).children, .field_names = (((operand_40).tables).base).field_names, .field_types = (((operand_40).tables).base).field_types, .first = (((operand_40).tables).base).first, .kinds = (((operand_40).tables).base).kinds, .labels = (((operand_40).tables).base).labels, .names = (((operand_40).tables).base).names, .second = (((operand_40).tables).base).second, };
                    const operand_44 = (zx_abi).zx_type_15{ .children = (((operand_40).tables).delta).children, .field_names = (((operand_40).tables).delta).field_names, .field_types = (((operand_40).tables).delta).field_types, .first = (((operand_40).tables).delta).first, .kinds = (((operand_40).tables).delta).kinds, .labels = (((operand_40).tables).delta).labels, .names = (((operand_40).tables).delta).names, .second = (((operand_40).tables).delta).second, };
                    const operand_45 = (zx_abi).zx_type_16{ .base = (&operand_43), .delta = (&operand_44), };
                    const operand_46 = (zx_abi).zx_type_31{ .candidate = (&operand_42), .id = (operand_40).id, .tables = (&operand_45), };
                    const operand_47 = (try function_13(allocator, (&operand_46)));

                    break :block_48 operand_47;
                }) @as((zx_abi).zx_type_29, .Found) else @as((zx_abi).zx_type_29, .Conflict)));
                const value_13: state_type_9 = block_34: {
                    const operand_30 = state_1;
                    const operand_31 = ((state_1).index + @as(u64, 1));
                    const operand_32 = value_12;
                    const operand_33 = (if (value_11) value_9 else (state_1).id);

                    break :block_34 state_type_9{ .candidate = (operand_30).candidate, .count = (operand_30).count, .id = operand_33, .index = operand_31, .origin = (operand_30).origin, .origins = (operand_30).origins, .status = operand_32, .tables = (operand_30).tables, };
                };

                break :block_86 value_13;
            };

            state_changed_29 = true;
        }

        break :block_92 block_91: {
            const operand_87 = (state_1).status;
            const operand_88 = (state_1).id;

            break :block_91 block_90: {
                const operand_89 = (try (allocator).create((zx_abi).zx_type_30));

                (operand_89).* = @as((zx_abi).zx_type_30, (zx_abi).zx_type_30{ .status = operand_87, .id = operand_88, });

                break :block_90 @as(*const (zx_abi).zx_type_30, operand_89);
            };
        };
    };
}

fn function_16_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_36_bd208de60d840cfc787ebffb6ff5afe0f3ea76a39636b572313b962e7b4577de) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_30_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    const value_1: u64 = (@as(u64, ((((in).origins).base).ids).len) + @as(u64, ((((in).origins).delta).ids).len));
    const value_2: u32 = @as(u32, 0);
    const value_14: (zx_abi).value_zx_type_51_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01 = block_177: {
        const operand_109 = block_108: {
            const operand_98 = (in).tables;
            const operand_99 = (in).origins;
            const operand_100 = (in).origin;
            const operand_101 = (in).candidate;
            const operand_102 = block_103: {
                break :block_103 value_1;
            };
            const operand_104 = @as(u64, 0);
            const operand_105 = @as((zx_abi).zx_type_29, .Missing);
            const operand_106 = block_107: {
                break :block_107 value_2;
            };

            break :block_108 @as((zx_abi).value_zx_type_51_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01, (zx_abi).value_zx_type_51_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01{ .tables = operand_98, .origins = operand_99, .origin = operand_100, .candidate = operand_101, .count = operand_102, .index = operand_104, .status = operand_105, .id = operand_106, });
        };

        var state_97: (zx_abi).value_zx_type_51_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01 = operand_109;

        var state_changed_110 = false;

        while ((((state_97).status == @as((zx_abi).zx_type_29, .Missing)) and ((state_97).index < (state_97).count))) {
            state_97 = block_175: {
                const value_5: u64 = @as(u64, ((((state_97).origins).base).ids).len);
                const value_6: bool = ((state_97).index >= block_174: {
                    break :block_174 value_5;
                });
                const value_7: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if (block_173: {
                    break :block_173 value_6;
                }) ((state_97).origins).delta else ((state_97).origins).base);
                const value_8: u64 = (if (block_171: {
                    break :block_171 value_6;
                }) ((state_97).index - block_172: {
                    break :block_172 value_5;
                }) else (state_97).index);
                const value_9: u32 = block_170: {
                    const operand_168 = (value_7).ids;
                    const operand_169 = block_167: {
                        break :block_167 value_8;
                    };

                    if ((operand_169 >= (operand_168).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_170 (operand_168)[@intCast(operand_169)];
                };
                const value_10: bool = (((block_152: {
                    const operand_150 = (value_7).kinds;
                    const operand_151 = block_149: {
                        break :block_149 value_8;
                    };

                    if ((operand_151 >= (operand_150).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_152 (operand_150)[@intCast(operand_151)];
                } == ((state_97).origin).kind) and block_159: {
                    const operand_157 = block_156: {
                        const operand_154 = (value_7).owners;
                        const operand_155 = block_153: {
                            break :block_153 value_8;
                        };

                        if ((operand_155 >= (operand_154).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_156 (operand_154)[@intCast(operand_155)];
                    };
                    const operand_158 = ((state_97).origin).owner;

                    break :block_159 ((std).mem).eql(u8, operand_157, operand_158);
                }) and block_166: {
                    const operand_164 = block_163: {
                        const operand_161 = (value_7).members;
                        const operand_162 = block_160: {
                            break :block_160 value_8;
                        };

                        if ((operand_162 >= (operand_161).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_163 (operand_161)[@intCast(operand_162)];
                    };
                    const operand_165 = ((state_97).origin).member;

                    break :block_166 ((std).mem).eql(u8, operand_164, operand_165);
                });
                const value_11: bool = (block_140: {
                    break :block_140 value_10;
                } and block_148: {
                    const operand_146 = (block_145: {
                        break :block_145 (try function_15_value(allocator, block_144: {
                            const operand_141 = (state_97).tables;
                            const operand_142 = block_143: {
                                break :block_143 value_9;
                            };

                            break :block_144 @as((zx_abi).value_zx_type_32_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d, (zx_abi).value_zx_type_32_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d{ .tables = operand_141, .id = operand_142, });
                        }));
                    }).label;
                    const operand_147 = ((state_97).candidate).label;

                    break :block_148 ((std).mem).eql(u8, operand_146, operand_147);
                });
                const value_12: (zx_abi).zx_type_29 = (if ((!block_139: {
                    break :block_139 value_11;
                })) @as((zx_abi).zx_type_29, .Missing) else (if (block_138: {
                    const operand_119 = (state_97).tables;

                    var state_borrow_120: (zx_abi).zx_type_15 = undefined;

                    state_borrow_120 = (zx_abi).zx_type_15{ .children = ((operand_119).base).children, .field_names = ((operand_119).base).field_names, .field_types = ((operand_119).base).field_types, .first = ((operand_119).base).first, .kinds = ((operand_119).base).kinds, .labels = ((operand_119).base).labels, .names = ((operand_119).base).names, .second = ((operand_119).base).second, };

                    var state_borrow_121: (zx_abi).zx_type_15 = undefined;

                    state_borrow_121 = (zx_abi).zx_type_15{ .children = ((operand_119).delta).children, .field_names = ((operand_119).delta).field_names, .field_types = ((operand_119).delta).field_types, .first = ((operand_119).delta).first, .kinds = ((operand_119).delta).kinds, .labels = ((operand_119).delta).labels, .names = ((operand_119).delta).names, .second = ((operand_119).delta).second, };

                    var state_borrow_122: (zx_abi).zx_type_16 = undefined;

                    state_borrow_122 = (zx_abi).zx_type_16{ .base = (((operand_119).base).zx_origin orelse (&state_borrow_120)), .delta = (((operand_119).delta).zx_origin orelse (&state_borrow_121)), };

                    const operand_123 = ((operand_119).zx_origin orelse (&state_borrow_122));
                    const operand_125 = block_124: {
                        break :block_124 value_9;
                    };
                    const operand_126 = (state_97).candidate;

                    var state_borrow_127: (zx_abi).zx_type_17 = undefined;

                    state_borrow_127 = (zx_abi).zx_type_17{ .names = ((operand_126).fields).names, .types = ((operand_126).fields).types, };

                    var state_borrow_128: (zx_abi).zx_type_24 = undefined;

                    state_borrow_128 = (zx_abi).zx_type_24{ .children = (operand_126).children, .fields = (((operand_126).fields).zx_origin orelse (&state_borrow_127)), .first = (operand_126).first, .kind = (operand_126).kind, .label = (operand_126).label, .names = (operand_126).names, .second = (operand_126).second, };

                    const operand_129 = ((operand_126).zx_origin orelse (&state_borrow_128));
                    const operand_130 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_123).base).children, .field_names = ((operand_123).base).field_names, .field_types = ((operand_123).base).field_types, .first = ((operand_123).base).first, .kinds = ((operand_123).base).kinds, .labels = ((operand_123).base).labels, .names = ((operand_123).base).names, .second = ((operand_123).base).second, .zx_origin = (operand_123).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_123).delta).children, .field_names = ((operand_123).delta).field_names, .field_types = ((operand_123).delta).field_types, .first = ((operand_123).delta).first, .kinds = ((operand_123).delta).kinds, .labels = ((operand_123).delta).labels, .names = ((operand_123).delta).names, .second = ((operand_123).delta).second, .zx_origin = (operand_123).delta, }, .zx_origin = operand_123, };

                    var state_borrow_131: (zx_abi).zx_type_15 = undefined;

                    state_borrow_131 = (zx_abi).zx_type_15{ .children = ((operand_130).base).children, .field_names = ((operand_130).base).field_names, .field_types = ((operand_130).base).field_types, .first = ((operand_130).base).first, .kinds = ((operand_130).base).kinds, .labels = ((operand_130).base).labels, .names = ((operand_130).base).names, .second = ((operand_130).base).second, };

                    var state_borrow_132: (zx_abi).zx_type_15 = undefined;

                    state_borrow_132 = (zx_abi).zx_type_15{ .children = ((operand_130).delta).children, .field_names = ((operand_130).delta).field_names, .field_types = ((operand_130).delta).field_types, .first = ((operand_130).delta).first, .kinds = ((operand_130).delta).kinds, .labels = ((operand_130).delta).labels, .names = ((operand_130).delta).names, .second = ((operand_130).delta).second, };

                    var state_borrow_133: (zx_abi).zx_type_16 = undefined;

                    state_borrow_133 = (zx_abi).zx_type_16{ .base = (((operand_130).base).zx_origin orelse (&state_borrow_131)), .delta = (((operand_130).delta).zx_origin orelse (&state_borrow_132)), };

                    const operand_134 = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_129).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_129).fields).names, .types = ((operand_129).fields).types, .zx_origin = (operand_129).fields, }, .first = (operand_129).first, .kind = (operand_129).kind, .label = (operand_129).label, .names = (operand_129).names, .second = (operand_129).second, .zx_origin = operand_129, };

                    var state_borrow_135: (zx_abi).zx_type_17 = undefined;

                    state_borrow_135 = (zx_abi).zx_type_17{ .names = ((operand_134).fields).names, .types = ((operand_134).fields).types, };

                    var state_borrow_136: (zx_abi).zx_type_24 = undefined;

                    state_borrow_136 = (zx_abi).zx_type_24{ .children = (operand_134).children, .fields = (((operand_134).fields).zx_origin orelse (&state_borrow_135)), .first = (operand_134).first, .kind = (operand_134).kind, .label = (operand_134).label, .names = (operand_134).names, .second = (operand_134).second, };

                    const operand_137 = (zx_abi).zx_type_31{ .tables = ((operand_130).zx_origin orelse (&state_borrow_133)), .id = operand_125, .candidate = ((operand_134).zx_origin orelse (&state_borrow_136)), };

                    break :block_138 (try function_13(allocator, (&operand_137)));
                }) @as((zx_abi).zx_type_29, .Found) else @as((zx_abi).zx_type_29, .Conflict)));
                const value_13: (zx_abi).value_zx_type_51_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01 = block_118: {
                    const operand_111 = state_97;
                    const operand_112 = ((state_97).index + @as(u64, 1));
                    const operand_113 = block_114: {
                        break :block_114 value_12;
                    };
                    const operand_115 = (if (block_116: {
                        break :block_116 value_11;
                    }) block_117: {
                        break :block_117 value_9;
                    } else (state_97).id);

                    break :block_118 @as((zx_abi).value_zx_type_51_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01, (zx_abi).value_zx_type_51_174d67dc7a4aa8de9bca59f2ddb4ce11e91b04c38dba011d725c6ada0ecf0f01{ .candidate = (operand_111).candidate, .count = (operand_111).count, .id = operand_115, .index = operand_112, .origin = (operand_111).origin, .origins = (operand_111).origins, .status = operand_113, .tables = (operand_111).tables, });
                };

                break :block_175 value_13;
            };

            state_changed_110 = true;
        }

        break :block_177 (if (state_changed_110) state_97 else operand_109);
    };

    return block_96: {
        const operand_94 = (value_14).status;
        const operand_95 = (value_14).id;

        break :block_96 @as((zx_abi).value_zx_type_30_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_30_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .status = operand_94, .id = operand_95, });
    };
}

fn function_17(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_36) error{ IndexOutOfBounds, OutOfMemory, }!u64 {
    @setRuntimeSafety(true);

    return block_4: {
        const operand_1 = in;
        const operand_2 = (try function_16_value(allocator, (zx_abi).value_zx_type_36_bd208de60d840cfc787ebffb6ff5afe0f3ea76a39636b572313b962e7b4577de{ .candidate = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = ((operand_1).candidate).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = (((operand_1).candidate).fields).names, .types = (((operand_1).candidate).fields).types, .zx_origin = ((operand_1).candidate).fields, }, .first = ((operand_1).candidate).first, .kind = ((operand_1).candidate).kind, .label = ((operand_1).candidate).label, .names = ((operand_1).candidate).names, .second = ((operand_1).candidate).second, .zx_origin = (operand_1).candidate, }, .origin = (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = ((operand_1).origin).kind, .member = ((operand_1).origin).member, .owner = ((operand_1).origin).owner, .zx_origin = (operand_1).origin, }, .origins = (zx_abi).value_zx_type_35_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53{ .base = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_1).origins).base).ids, .kinds = (((operand_1).origins).base).kinds, .members = (((operand_1).origins).base).members, .owners = (((operand_1).origins).base).owners, .zx_origin = ((operand_1).origins).base, }, .delta = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_1).origins).delta).ids, .kinds = (((operand_1).origins).delta).kinds, .members = (((operand_1).origins).delta).members, .owners = (((operand_1).origins).delta).owners, .zx_origin = ((operand_1).origins).delta, }, .zx_origin = (operand_1).origins, }, .tables = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).base).children, .field_names = (((operand_1).tables).base).field_names, .field_types = (((operand_1).tables).base).field_types, .first = (((operand_1).tables).base).first, .kinds = (((operand_1).tables).base).kinds, .labels = (((operand_1).tables).base).labels, .names = (((operand_1).tables).base).names, .second = (((operand_1).tables).base).second, .zx_origin = ((operand_1).tables).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).delta).children, .field_names = (((operand_1).tables).delta).field_names, .field_types = (((operand_1).tables).delta).field_types, .first = (((operand_1).tables).delta).first, .kinds = (((operand_1).tables).delta).kinds, .labels = (((operand_1).tables).delta).labels, .names = (((operand_1).tables).delta).names, .second = (((operand_1).tables).delta).second, .zx_origin = ((operand_1).tables).delta, }, .zx_origin = (operand_1).tables, }, .zx_origin = operand_1, }));

        var state_borrow_3: (zx_abi).zx_type_30 = undefined;

        state_borrow_3 = (zx_abi).zx_type_30{ .id = (operand_2).id, .status = (operand_2).status, };

        break :block_4 (try function_11(allocator, ((operand_2).zx_origin orelse (&state_borrow_3))));
    };
}

fn function_18(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_37) error{ OutOfMemory, Overflow, }!*const (zx_abi).zx_type_34 {
    @setRuntimeSafety(true);

    return block_23: {
        const operand_1 = (block_5: {
            const operand_2 = ((in).bindings).ids;
            const operand_3 = (in).id;
            const operand_4 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_2).len, 1))));

            @memcpy((operand_4)[0..(operand_2).len], operand_2);

            (operand_4)[(operand_2).len] = operand_3;

            break :block_5 @as((zx_abi).zx_type_48, .{ operand_4, {}, });
        }).@"0";
        const operand_6 = (block_10: {
            const operand_7 = ((in).bindings).kinds;
            const operand_8 = ((in).origin).kind;
            const operand_9 = (try (allocator).alloc(u8, (try ((std).math).add(usize, (operand_7).len, 1))));

            @memcpy((operand_9)[0..(operand_7).len], operand_7);

            (operand_9)[(operand_7).len] = operand_8;

            break :block_10 @as((zx_abi).zx_type_47, .{ operand_9, {}, });
        }).@"0";
        const operand_11 = (block_15: {
            const operand_12 = ((in).bindings).owners;
            const operand_13 = ((in).origin).owner;
            const operand_14 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_12).len, 1))));

            @memcpy((operand_14)[0..(operand_12).len], operand_12);

            (operand_14)[(operand_12).len] = operand_13;

            break :block_15 @as((zx_abi).zx_type_49, .{ operand_14, {}, });
        }).@"0";
        const operand_16 = (block_20: {
            const operand_17 = ((in).bindings).members;
            const operand_18 = ((in).origin).member;
            const operand_19 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_17).len, 1))));

            @memcpy((operand_19)[0..(operand_17).len], operand_17);

            (operand_19)[(operand_17).len] = operand_18;

            break :block_20 @as((zx_abi).zx_type_49, .{ operand_19, {}, });
        }).@"0";

        break :block_23 block_22: {
            const operand_21 = (try (allocator).create((zx_abi).zx_type_34));

            (operand_21).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .ids = operand_1, .kinds = operand_6, .owners = operand_11, .members = operand_16, });

            break :block_22 @as(*const (zx_abi).zx_type_34, operand_21);
        };
    };
}

fn function_18_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_37_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39) error{ OutOfMemory, Overflow, }!(zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    return block_44: {
        const operand_24 = (block_28: {
            const operand_25 = ((in).bindings).ids;
            const operand_26 = (in).id;
            const operand_27 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_25).len, 1))));

            @memcpy((operand_27)[0..(operand_25).len], operand_25);

            (operand_27)[(operand_25).len] = operand_26;

            break :block_28 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_27, {}, null, });
        }).@"0";
        const operand_29 = (block_33: {
            const operand_30 = ((in).bindings).kinds;
            const operand_31 = ((in).origin).kind;
            const operand_32 = (try (allocator).alloc(u8, (try ((std).math).add(usize, (operand_30).len, 1))));

            @memcpy((operand_32)[0..(operand_30).len], operand_30);

            (operand_32)[(operand_30).len] = operand_31;

            break :block_33 @as((zx_abi).value_zx_type_47_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_32, {}, null, });
        }).@"0";
        const operand_34 = (block_38: {
            const operand_35 = ((in).bindings).owners;
            const operand_36 = ((in).origin).owner;
            const operand_37 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_35).len, 1))));

            @memcpy((operand_37)[0..(operand_35).len], operand_35);

            (operand_37)[(operand_35).len] = operand_36;

            break :block_38 @as((zx_abi).value_zx_type_49_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_37, {}, null, });
        }).@"0";
        const operand_39 = (block_43: {
            const operand_40 = ((in).bindings).members;
            const operand_41 = ((in).origin).member;
            const operand_42 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_40).len, 1))));

            @memcpy((operand_42)[0..(operand_40).len], operand_40);

            (operand_42)[(operand_40).len] = operand_41;

            break :block_43 @as((zx_abi).value_zx_type_49_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_42, {}, null, });
        }).@"0";

        break :block_44 @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = operand_24, .kinds = operand_29, .owners = operand_34, .members = operand_39, });
    };
}

fn function_18_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_37_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!(zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    return block_77: {
        const operand_45 = @as([]const u32, (if (((buffers).lane_0 != null)) block_48: {
            const operand_46 = ((in).bindings).ids;
            const operand_47 = (in).id;

            _ = (try ((std).math).add(usize, (operand_46).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_46));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_46).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_47));

            break :block_48 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_52: {
            const operand_49 = ((in).bindings).ids;
            const operand_50 = (in).id;
            const operand_51 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_49).len, 1))));

            @memcpy((operand_51)[0..(operand_49).len], operand_49);

            (operand_51)[(operand_49).len] = operand_50;

            break :block_52 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_51, {}, null, });
        }).@"0"));
        const operand_53 = @as([]const u8, (if (((buffers).lane_1 != null)) block_56: {
            const operand_54 = ((in).bindings).kinds;
            const operand_55 = ((in).origin).kind;

            _ = (try ((std).math).add(usize, (operand_54).len, 1));

            if ((!(((buffers).lane_1.?).started).*)) {
                (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_54));

                (((buffers).lane_1.?).started).* = true;
            } else {
                (((((buffers).lane_1.?).buffer).*).items).len = (operand_54).len;
            }

            (try ((((buffers).lane_1.?).buffer).*).append(allocator, operand_55));

            break :block_56 ((((buffers).lane_1.?).buffer).*).items;
        } else (block_60: {
            const operand_57 = ((in).bindings).kinds;
            const operand_58 = ((in).origin).kind;
            const operand_59 = (try (allocator).alloc(u8, (try ((std).math).add(usize, (operand_57).len, 1))));

            @memcpy((operand_59)[0..(operand_57).len], operand_57);

            (operand_59)[(operand_57).len] = operand_58;

            break :block_60 @as((zx_abi).value_zx_type_47_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_59, {}, null, });
        }).@"0"));
        const operand_61 = @as([]const []const u8, (if (((buffers).lane_3 != null)) block_64: {
            const operand_62 = ((in).bindings).owners;
            const operand_63 = ((in).origin).owner;

            _ = (try ((std).math).add(usize, (operand_62).len, 1));

            if ((!(((buffers).lane_3.?).started).*)) {
                (try ((((buffers).lane_3.?).buffer).*).appendSlice(allocator, operand_62));

                (((buffers).lane_3.?).started).* = true;
            } else {
                (((((buffers).lane_3.?).buffer).*).items).len = (operand_62).len;
            }

            (try ((((buffers).lane_3.?).buffer).*).append(allocator, operand_63));

            break :block_64 ((((buffers).lane_3.?).buffer).*).items;
        } else (block_68: {
            const operand_65 = ((in).bindings).owners;
            const operand_66 = ((in).origin).owner;
            const operand_67 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_65).len, 1))));

            @memcpy((operand_67)[0..(operand_65).len], operand_65);

            (operand_67)[(operand_65).len] = operand_66;

            break :block_68 @as((zx_abi).value_zx_type_49_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_67, {}, null, });
        }).@"0"));
        const operand_69 = @as([]const []const u8, (if (((buffers).lane_2 != null)) block_72: {
            const operand_70 = ((in).bindings).members;
            const operand_71 = ((in).origin).member;

            _ = (try ((std).math).add(usize, (operand_70).len, 1));

            if ((!(((buffers).lane_2.?).started).*)) {
                (try ((((buffers).lane_2.?).buffer).*).appendSlice(allocator, operand_70));

                (((buffers).lane_2.?).started).* = true;
            } else {
                (((((buffers).lane_2.?).buffer).*).items).len = (operand_70).len;
            }

            (try ((((buffers).lane_2.?).buffer).*).append(allocator, operand_71));

            break :block_72 ((((buffers).lane_2.?).buffer).*).items;
        } else (block_76: {
            const operand_73 = ((in).bindings).members;
            const operand_74 = ((in).origin).member;
            const operand_75 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_73).len, 1))));

            @memcpy((operand_75)[0..(operand_73).len], operand_73);

            (operand_75)[(operand_73).len] = operand_74;

            break :block_76 @as((zx_abi).value_zx_type_49_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ operand_75, {}, null, });
        }).@"0"));

        break :block_77 @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = operand_45, .kinds = operand_53, .owners = operand_61, .members = operand_69, });
    };
}

fn function_18_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_37, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList(u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ OutOfMemory, Overflow, }!*const (zx_abi).zx_type_34 {
    @setRuntimeSafety(true);

    return block_112: {
        const operand_78 = @as([]const u32, (if (((buffers).lane_0 != null)) block_81: {
            const operand_79 = ((in).bindings).ids;
            const operand_80 = (in).id;

            _ = (try ((std).math).add(usize, (operand_79).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_79));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_79).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_80));

            break :block_81 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_85: {
            const operand_82 = ((in).bindings).ids;
            const operand_83 = (in).id;
            const operand_84 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_82).len, 1))));

            @memcpy((operand_84)[0..(operand_82).len], operand_82);

            (operand_84)[(operand_82).len] = operand_83;

            break :block_85 @as((zx_abi).zx_type_48, .{ operand_84, {}, });
        }).@"0"));
        const operand_86 = @as([]const u8, (if (((buffers).lane_1 != null)) block_89: {
            const operand_87 = ((in).bindings).kinds;
            const operand_88 = ((in).origin).kind;

            _ = (try ((std).math).add(usize, (operand_87).len, 1));

            if ((!(((buffers).lane_1.?).started).*)) {
                (try ((((buffers).lane_1.?).buffer).*).appendSlice(allocator, operand_87));

                (((buffers).lane_1.?).started).* = true;
            } else {
                (((((buffers).lane_1.?).buffer).*).items).len = (operand_87).len;
            }

            (try ((((buffers).lane_1.?).buffer).*).append(allocator, operand_88));

            break :block_89 ((((buffers).lane_1.?).buffer).*).items;
        } else (block_93: {
            const operand_90 = ((in).bindings).kinds;
            const operand_91 = ((in).origin).kind;
            const operand_92 = (try (allocator).alloc(u8, (try ((std).math).add(usize, (operand_90).len, 1))));

            @memcpy((operand_92)[0..(operand_90).len], operand_90);

            (operand_92)[(operand_90).len] = operand_91;

            break :block_93 @as((zx_abi).zx_type_47, .{ operand_92, {}, });
        }).@"0"));
        const operand_94 = @as([]const []const u8, (if (((buffers).lane_3 != null)) block_97: {
            const operand_95 = ((in).bindings).owners;
            const operand_96 = ((in).origin).owner;

            _ = (try ((std).math).add(usize, (operand_95).len, 1));

            if ((!(((buffers).lane_3.?).started).*)) {
                (try ((((buffers).lane_3.?).buffer).*).appendSlice(allocator, operand_95));

                (((buffers).lane_3.?).started).* = true;
            } else {
                (((((buffers).lane_3.?).buffer).*).items).len = (operand_95).len;
            }

            (try ((((buffers).lane_3.?).buffer).*).append(allocator, operand_96));

            break :block_97 ((((buffers).lane_3.?).buffer).*).items;
        } else (block_101: {
            const operand_98 = ((in).bindings).owners;
            const operand_99 = ((in).origin).owner;
            const operand_100 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_98).len, 1))));

            @memcpy((operand_100)[0..(operand_98).len], operand_98);

            (operand_100)[(operand_98).len] = operand_99;

            break :block_101 @as((zx_abi).zx_type_49, .{ operand_100, {}, });
        }).@"0"));
        const operand_102 = @as([]const []const u8, (if (((buffers).lane_2 != null)) block_105: {
            const operand_103 = ((in).bindings).members;
            const operand_104 = ((in).origin).member;

            _ = (try ((std).math).add(usize, (operand_103).len, 1));

            if ((!(((buffers).lane_2.?).started).*)) {
                (try ((((buffers).lane_2.?).buffer).*).appendSlice(allocator, operand_103));

                (((buffers).lane_2.?).started).* = true;
            } else {
                (((((buffers).lane_2.?).buffer).*).items).len = (operand_103).len;
            }

            (try ((((buffers).lane_2.?).buffer).*).append(allocator, operand_104));

            break :block_105 ((((buffers).lane_2.?).buffer).*).items;
        } else (block_109: {
            const operand_106 = ((in).bindings).members;
            const operand_107 = ((in).origin).member;
            const operand_108 = (try (allocator).alloc([]const u8, (try ((std).math).add(usize, (operand_106).len, 1))));

            @memcpy((operand_108)[0..(operand_106).len], operand_106);

            (operand_108)[(operand_106).len] = operand_107;

            break :block_109 @as((zx_abi).zx_type_49, .{ operand_108, {}, });
        }).@"0"));

        break :block_112 block_111: {
            const operand_110 = (try (allocator).create((zx_abi).zx_type_34));

            (operand_110).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .ids = operand_78, .kinds = operand_86, .owners = operand_94, .members = operand_102, });

            break :block_111 @as(*const (zx_abi).zx_type_34, operand_110);
        };
    };
}

fn function_19(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_38) error{ IndexOutOfBounds, OutOfMemory, Overflow, }![]const u32 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_11 = (try function_5(allocator, block_66: {
        const operand_64 = ((in).source).kinds;
        const operand_65 = (in).index;

        if ((operand_65 >= (operand_64).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_66 (operand_64)[@intCast(operand_65)];
    }));
    const value_2: []const u32 = block_63: {
        const operand_56 = (in).references;
        const operand_57 = @as(u64, 0);
        const operand_58 = @as(u64, 0);
        const operand_60 = block_59: {
            break :block_59 (try (allocator).dupe(u32, (&[_]u32{})));
        };

        if (((operand_57 > (operand_56).len) or (operand_58 > ((operand_56).len - operand_57)))) {
            return error.IndexOutOfBounds;
        }

        const operand_61 = @as(usize, @intCast(operand_57));
        const operand_62 = @as(usize, @intCast(operand_58));

        _ = (try ((std).math).add(usize, ((operand_56).len - operand_62), (operand_60).len));

        break :block_63 (operand_56)[operand_61..(operand_61 + operand_62)];
    };

    if ((((value_1 == @as((zx_abi).zx_type_11, .Optional)) or (value_1 == @as((zx_abi).zx_type_11, .List))) or (value_1 == @as((zx_abi).zx_type_11, .Task)))) {
        const value_3: u32 = block_55: {
            const operand_53 = (in).mapping;
            const operand_54 = (try function_0(allocator, block_52: {
                const operand_50 = ((in).source).first;
                const operand_51 = (in).index;

                if ((operand_51 >= (operand_50).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_52 (operand_50)[@intCast(operand_51)];
            }));

            if ((operand_54 >= (operand_53).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_55 (operand_53)[@intCast(operand_54)];
        };
        const value_4: []const u32 = (block_49: {
            const operand_46 = value_2;
            const operand_47 = value_3;
            const operand_48 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_46).len, 1))));

            @memcpy((operand_48)[0..(operand_46).len], operand_46);

            (operand_48)[(operand_46).len] = operand_47;

            break :block_49 @as((zx_abi).zx_type_48, .{ operand_48, {}, });
        }).@"0";

        return (if ((value_1 == @as((zx_abi).zx_type_11, .Task))) (block_45: {
            const operand_36 = value_4;
            const operand_43 = block_42: {
                const operand_40 = (in).mapping;
                const operand_41 = (try function_0(allocator, block_39: {
                    const operand_37 = ((in).source).second;
                    const operand_38 = (in).index;

                    if ((operand_38 >= (operand_37).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_39 (operand_37)[@intCast(operand_38)];
                }));

                if ((operand_41 >= (operand_40).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_42 (operand_40)[@intCast(operand_41)];
            };
            const operand_44 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_36).len, 1))));

            @memcpy((operand_44)[0..(operand_36).len], operand_36);

            (operand_44)[(operand_36).len] = operand_43;

            break :block_45 @as((zx_abi).zx_type_48, .{ operand_44, {}, });
        }).@"0" else value_4);
    }

    const value_5: bool = ((value_1 == @as((zx_abi).zx_type_11, .Tuple)) or (value_1 == @as((zx_abi).zx_type_11, .Object)));
    const value_6: []const u32 = (if ((value_1 == @as((zx_abi).zx_type_11, .Tuple))) ((in).source).children else ((in).source).field_types);
    const value_7: u64 = (if (value_5) (try function_0(allocator, block_35: {
        const operand_33 = ((in).source).second;
        const operand_34 = (in).index;

        if ((operand_34 >= (operand_33).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_35 (operand_33)[@intCast(operand_34)];
    })) else @as(u64, 0));
    const value_8: u64 = (try function_0(allocator, block_32: {
        const operand_30 = ((in).source).first;
        const operand_31 = (in).index;

        if ((operand_31 >= (operand_30).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_32 (operand_30)[@intCast(operand_31)];
    }));

    return (block_29: {
        const operand_9 = block_8: {
            const operand_2 = (in).mapping;
            const operand_3 = value_6;
            const operand_4 = value_8;
            const operand_5 = value_7;
            const operand_6 = @as(u64, 0);
            const operand_7 = value_2;

            break :block_8 (zx_abi).zx_type_53{ .mapping = operand_2, .values = operand_3, .first = operand_4, .count = operand_5, .index = operand_6, .references = operand_7, };
        };

        var state_capacity_10: (std).ArrayList(u32) = .empty;

        var state_capacity_started_11 = false;

        defer (state_capacity_10).deinit(allocator);

        var state_1: (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (operand_9).count, .first = (operand_9).first, .index = (operand_9).index, .mapping = (operand_9).mapping, .references = (operand_9).references, .values = (operand_9).values, .zx_origin = (&operand_9), };

        while (((state_1).index < (state_1).count)) {
            state_1 = block_25: {
                const value_11: u64 = (try function_0(allocator, block_24: {
                    const operand_22 = (state_1).values;
                    const operand_23 = ((state_1).first + (state_1).index);

                    if ((operand_23 >= (operand_22).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_24 (operand_22)[@intCast(operand_23)];
                }));
                const value_12: (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_21: {
                    break :block_21 @as((zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (state_1).count, .first = (state_1).first, .index = (state_1).index, .mapping = (state_1).mapping, .references = (block_20: {
                        const operand_14 = (state_1).references;
                        const operand_19 = block_18: {
                            const operand_16 = (state_1).mapping;
                            const operand_17 = block_15: {
                                break :block_15 value_11;
                            };

                            if ((operand_17 >= (operand_16).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_18 (operand_16)[@intCast(operand_17)];
                        };

                        _ = (try ((std).math).add(usize, (operand_14).len, 1));

                        if ((!state_capacity_started_11)) {
                            (try (state_capacity_10).appendSlice(allocator, operand_14));

                            state_capacity_started_11 = true;
                        } else {
                            ((state_capacity_10).items).len = (operand_14).len;
                        }

                        (try (state_capacity_10).append(allocator, operand_19));

                        break :block_20 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_10).items, {}, null, });
                    }).@"0", .values = (state_1).values, });
                };
                const value_13: u64 = (value_12).index;
                const value_14: (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_13: {
                    break :block_13 @as((zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (value_12).count, .first = (value_12).first, .index = (block_12: {
                        break :block_12 value_13;
                    } + @as(u64, 1)), .mapping = (value_12).mapping, .references = (value_12).references, .values = (value_12).values, });
                };

                break :block_25 value_14;
            };
        }

        var state_owned_26: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_26);

        if (state_capacity_started_11) {
            ((state_capacity_10).items).len = ((state_1).references).len;

            state_owned_26 = (try (state_capacity_10).toOwnedSlice(allocator));
        }

        if (state_capacity_started_11) {
            state_1 = (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (state_1).count, .first = (state_1).first, .index = (state_1).index, .mapping = (state_1).mapping, .references = state_owned_26, .values = (state_1).values, };
        }

        break :block_29 block_28: {
            break :block_28 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_27: {
                break :block_27 (zx_abi).zx_type_53{ .count = (state_1).count, .first = (state_1).first, .index = (state_1).index, .mapping = (state_1).mapping, .references = (state_1).references, .values = (state_1).values, };
            });
        };
    }).references;
}

fn function_19_buffered(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_38, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }![]const u32 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_11 = (try function_5(allocator, block_151: {
        const operand_149 = ((in).source).kinds;
        const operand_150 = (in).index;

        if ((operand_150 >= (operand_149).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_151 (operand_149)[@intCast(operand_150)];
    }));
    const value_2: []const u32 = block_148: {
        const operand_141 = (in).references;
        const operand_142 = @as(u64, 0);
        const operand_143 = @as(u64, 0);
        const operand_145 = block_144: {
            break :block_144 (try (allocator).dupe(u32, (&[_]u32{})));
        };

        if (((operand_142 > (operand_141).len) or (operand_143 > ((operand_141).len - operand_142)))) {
            return error.IndexOutOfBounds;
        }

        const operand_146 = @as(usize, @intCast(operand_142));
        const operand_147 = @as(usize, @intCast(operand_143));

        _ = (try ((std).math).add(usize, ((operand_141).len - operand_147), (operand_145).len));

        break :block_148 (operand_141)[operand_146..(operand_146 + operand_147)];
    };

    if ((((value_1 == @as((zx_abi).zx_type_11, .Optional)) or (value_1 == @as((zx_abi).zx_type_11, .List))) or (value_1 == @as((zx_abi).zx_type_11, .Task)))) {
        const value_3: u32 = block_140: {
            const operand_138 = (in).mapping;
            const operand_139 = (try function_0(allocator, block_137: {
                const operand_135 = ((in).source).first;
                const operand_136 = (in).index;

                if ((operand_136 >= (operand_135).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_137 (operand_135)[@intCast(operand_136)];
            }));

            if ((operand_139 >= (operand_138).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_140 (operand_138)[@intCast(operand_139)];
        };
        const value_4: []const u32 = @as([]const u32, (if (((buffers).lane_0 != null)) block_130: {
            const operand_128 = value_2;
            const operand_129 = value_3;

            _ = (try ((std).math).add(usize, (operand_128).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_128));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_128).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_129));

            break :block_130 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_134: {
            const operand_131 = value_2;
            const operand_132 = value_3;
            const operand_133 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_131).len, 1))));

            @memcpy((operand_133)[0..(operand_131).len], operand_131);

            (operand_133)[(operand_131).len] = operand_132;

            break :block_134 @as((zx_abi).zx_type_48, .{ operand_133, {}, });
        }).@"0"));

        return (if ((value_1 == @as((zx_abi).zx_type_11, .Task))) @as([]const u32, (if (((buffers).lane_0 != null)) block_117: {
            const operand_109 = value_4;
            const operand_116 = block_115: {
                const operand_113 = (in).mapping;
                const operand_114 = (try function_0(allocator, block_112: {
                    const operand_110 = ((in).source).second;
                    const operand_111 = (in).index;

                    if ((operand_111 >= (operand_110).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_112 (operand_110)[@intCast(operand_111)];
                }));

                if ((operand_114 >= (operand_113).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_115 (operand_113)[@intCast(operand_114)];
            };

            _ = (try ((std).math).add(usize, (operand_109).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_109));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_109).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_116));

            break :block_117 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_127: {
            const operand_118 = value_4;
            const operand_125 = block_124: {
                const operand_122 = (in).mapping;
                const operand_123 = (try function_0(allocator, block_121: {
                    const operand_119 = ((in).source).second;
                    const operand_120 = (in).index;

                    if ((operand_120 >= (operand_119).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_121 (operand_119)[@intCast(operand_120)];
                }));

                if ((operand_123 >= (operand_122).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_124 (operand_122)[@intCast(operand_123)];
            };
            const operand_126 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_118).len, 1))));

            @memcpy((operand_126)[0..(operand_118).len], operand_118);

            (operand_126)[(operand_118).len] = operand_125;

            break :block_127 @as((zx_abi).zx_type_48, .{ operand_126, {}, });
        }).@"0")) else value_4);
    }

    const value_5: bool = ((value_1 == @as((zx_abi).zx_type_11, .Tuple)) or (value_1 == @as((zx_abi).zx_type_11, .Object)));
    const value_6: []const u32 = (if ((value_1 == @as((zx_abi).zx_type_11, .Tuple))) ((in).source).children else ((in).source).field_types);
    const value_7: u64 = (if (value_5) (try function_0(allocator, block_108: {
        const operand_106 = ((in).source).second;
        const operand_107 = (in).index;

        if ((operand_107 >= (operand_106).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_108 (operand_106)[@intCast(operand_107)];
    })) else @as(u64, 0));
    const value_8: u64 = (try function_0(allocator, block_105: {
        const operand_103 = ((in).source).first;
        const operand_104 = (in).index;

        if ((operand_104 >= (operand_103).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_105 (operand_103)[@intCast(operand_104)];
    }));

    return (block_102: {
        const operand_75 = block_74: {
            const operand_68 = (in).mapping;
            const operand_69 = value_6;
            const operand_70 = value_8;
            const operand_71 = value_7;
            const operand_72 = @as(u64, 0);
            const operand_73 = value_2;

            break :block_74 (zx_abi).zx_type_53{ .mapping = operand_68, .values = operand_69, .first = operand_70, .count = operand_71, .index = operand_72, .references = operand_73, };
        };

        var state_capacity_76: (std).ArrayList(u32) = .empty;

        var state_capacity_started_77 = false;

        defer (state_capacity_76).deinit(allocator);

        var state_67: (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (operand_75).count, .first = (operand_75).first, .index = (operand_75).index, .mapping = (operand_75).mapping, .references = (operand_75).references, .values = (operand_75).values, .zx_origin = (&operand_75), };

        while (((state_67).index < (state_67).count)) {
            state_67 = block_98: {
                const value_11: u64 = (try function_0(allocator, block_97: {
                    const operand_95 = (state_67).values;
                    const operand_96 = ((state_67).first + (state_67).index);

                    if ((operand_96 >= (operand_95).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_97 (operand_95)[@intCast(operand_96)];
                }));
                const value_12: (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_94: {
                    break :block_94 @as((zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (state_67).count, .first = (state_67).first, .index = (state_67).index, .mapping = (state_67).mapping, .references = @as([]const u32, (if (((buffers).lane_0 != null)) block_86: {
                        const operand_80 = (state_67).references;
                        const operand_85 = block_84: {
                            const operand_82 = (state_67).mapping;
                            const operand_83 = block_81: {
                                break :block_81 value_11;
                            };

                            if ((operand_83 >= (operand_82).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_84 (operand_82)[@intCast(operand_83)];
                        };

                        _ = (try ((std).math).add(usize, (operand_80).len, 1));

                        if ((!(((buffers).lane_0.?).started).*)) {
                            (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_80));

                            (((buffers).lane_0.?).started).* = true;
                        } else {
                            (((((buffers).lane_0.?).buffer).*).items).len = (operand_80).len;
                        }

                        (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_85));

                        break :block_86 ((((buffers).lane_0.?).buffer).*).items;
                    } else (block_93: {
                        const operand_87 = (state_67).references;
                        const operand_92 = block_91: {
                            const operand_89 = (state_67).mapping;
                            const operand_90 = block_88: {
                                break :block_88 value_11;
                            };

                            if ((operand_90 >= (operand_89).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_91 (operand_89)[@intCast(operand_90)];
                        };

                        _ = (try ((std).math).add(usize, (operand_87).len, 1));

                        if ((!state_capacity_started_77)) {
                            (try (state_capacity_76).appendSlice(allocator, operand_87));

                            state_capacity_started_77 = true;
                        } else {
                            ((state_capacity_76).items).len = (operand_87).len;
                        }

                        (try (state_capacity_76).append(allocator, operand_92));

                        break :block_93 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_76).items, {}, null, });
                    }).@"0")), .values = (state_67).values, });
                };
                const value_13: u64 = (value_12).index;
                const value_14: (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_79: {
                    break :block_79 @as((zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (value_12).count, .first = (value_12).first, .index = (block_78: {
                        break :block_78 value_13;
                    } + @as(u64, 1)), .mapping = (value_12).mapping, .references = (value_12).references, .values = (value_12).values, });
                };

                break :block_98 value_14;
            };
        }

        var state_owned_99: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_99);

        if (state_capacity_started_77) {
            ((state_capacity_76).items).len = ((state_67).references).len;

            state_owned_99 = (try (state_capacity_76).toOwnedSlice(allocator));
        }

        if (state_capacity_started_77) {
            state_67 = (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (state_67).count, .first = (state_67).first, .index = (state_67).index, .mapping = (state_67).mapping, .references = state_owned_99, .values = (state_67).values, };
        }

        break :block_102 block_101: {
            break :block_101 (if (((state_67).zx_origin != null)) ((state_67).zx_origin.?).* else block_100: {
                break :block_100 (zx_abi).zx_type_53{ .count = (state_67).count, .first = (state_67).first, .index = (state_67).index, .mapping = (state_67).mapping, .references = (state_67).references, .values = (state_67).values, };
            });
        };
    }).references;
}

fn function_19_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_38, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, Overflow, }![]const u32 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_11 = (try function_5(allocator, block_236: {
        const operand_234 = ((in).source).kinds;
        const operand_235 = (in).index;

        if ((operand_235 >= (operand_234).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_236 (operand_234)[@intCast(operand_235)];
    }));
    const value_2: []const u32 = block_233: {
        const operand_226 = (in).references;
        const operand_227 = @as(u64, 0);
        const operand_228 = @as(u64, 0);
        const operand_230 = block_229: {
            break :block_229 (try (allocator).dupe(u32, (&[_]u32{})));
        };

        if (((operand_227 > (operand_226).len) or (operand_228 > ((operand_226).len - operand_227)))) {
            return error.IndexOutOfBounds;
        }

        const operand_231 = @as(usize, @intCast(operand_227));
        const operand_232 = @as(usize, @intCast(operand_228));

        _ = (try ((std).math).add(usize, ((operand_226).len - operand_232), (operand_230).len));

        break :block_233 (operand_226)[operand_231..(operand_231 + operand_232)];
    };

    if ((((value_1 == @as((zx_abi).zx_type_11, .Optional)) or (value_1 == @as((zx_abi).zx_type_11, .List))) or (value_1 == @as((zx_abi).zx_type_11, .Task)))) {
        const value_3: u32 = block_225: {
            const operand_223 = (in).mapping;
            const operand_224 = (try function_0(allocator, block_222: {
                const operand_220 = ((in).source).first;
                const operand_221 = (in).index;

                if ((operand_221 >= (operand_220).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_222 (operand_220)[@intCast(operand_221)];
            }));

            if ((operand_224 >= (operand_223).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_225 (operand_223)[@intCast(operand_224)];
        };
        const value_4: []const u32 = @as([]const u32, (if (((buffers).lane_0 != null)) block_215: {
            const operand_213 = value_2;
            const operand_214 = value_3;

            _ = (try ((std).math).add(usize, (operand_213).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_213));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_213).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_214));

            break :block_215 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_219: {
            const operand_216 = value_2;
            const operand_217 = value_3;
            const operand_218 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_216).len, 1))));

            @memcpy((operand_218)[0..(operand_216).len], operand_216);

            (operand_218)[(operand_216).len] = operand_217;

            break :block_219 @as((zx_abi).zx_type_48, .{ operand_218, {}, });
        }).@"0"));

        return (if ((value_1 == @as((zx_abi).zx_type_11, .Task))) @as([]const u32, (if (((buffers).lane_0 != null)) block_202: {
            const operand_194 = value_4;
            const operand_201 = block_200: {
                const operand_198 = (in).mapping;
                const operand_199 = (try function_0(allocator, block_197: {
                    const operand_195 = ((in).source).second;
                    const operand_196 = (in).index;

                    if ((operand_196 >= (operand_195).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_197 (operand_195)[@intCast(operand_196)];
                }));

                if ((operand_199 >= (operand_198).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_200 (operand_198)[@intCast(operand_199)];
            };

            _ = (try ((std).math).add(usize, (operand_194).len, 1));

            if ((!(((buffers).lane_0.?).started).*)) {
                (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_194));

                (((buffers).lane_0.?).started).* = true;
            } else {
                (((((buffers).lane_0.?).buffer).*).items).len = (operand_194).len;
            }

            (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_201));

            break :block_202 ((((buffers).lane_0.?).buffer).*).items;
        } else (block_212: {
            const operand_203 = value_4;
            const operand_210 = block_209: {
                const operand_207 = (in).mapping;
                const operand_208 = (try function_0(allocator, block_206: {
                    const operand_204 = ((in).source).second;
                    const operand_205 = (in).index;

                    if ((operand_205 >= (operand_204).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_206 (operand_204)[@intCast(operand_205)];
                }));

                if ((operand_208 >= (operand_207).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_209 (operand_207)[@intCast(operand_208)];
            };
            const operand_211 = (try (allocator).alloc(u32, (try ((std).math).add(usize, (operand_203).len, 1))));

            @memcpy((operand_211)[0..(operand_203).len], operand_203);

            (operand_211)[(operand_203).len] = operand_210;

            break :block_212 @as((zx_abi).zx_type_48, .{ operand_211, {}, });
        }).@"0")) else value_4);
    }

    const value_5: bool = ((value_1 == @as((zx_abi).zx_type_11, .Tuple)) or (value_1 == @as((zx_abi).zx_type_11, .Object)));
    const value_6: []const u32 = (if ((value_1 == @as((zx_abi).zx_type_11, .Tuple))) ((in).source).children else ((in).source).field_types);
    const value_7: u64 = (if (value_5) (try function_0(allocator, block_193: {
        const operand_191 = ((in).source).second;
        const operand_192 = (in).index;

        if ((operand_192 >= (operand_191).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_193 (operand_191)[@intCast(operand_192)];
    })) else @as(u64, 0));
    const value_8: u64 = (try function_0(allocator, block_190: {
        const operand_188 = ((in).source).first;
        const operand_189 = (in).index;

        if ((operand_189 >= (operand_188).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_190 (operand_188)[@intCast(operand_189)];
    }));

    return (block_187: {
        const operand_160 = block_159: {
            const operand_153 = (in).mapping;
            const operand_154 = value_6;
            const operand_155 = value_8;
            const operand_156 = value_7;
            const operand_157 = @as(u64, 0);
            const operand_158 = value_2;

            break :block_159 (zx_abi).zx_type_53{ .mapping = operand_153, .values = operand_154, .first = operand_155, .count = operand_156, .index = operand_157, .references = operand_158, };
        };

        var state_capacity_161: (std).ArrayList(u32) = .empty;

        var state_capacity_started_162 = false;

        defer (state_capacity_161).deinit(allocator);

        var state_152: (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (operand_160).count, .first = (operand_160).first, .index = (operand_160).index, .mapping = (operand_160).mapping, .references = (operand_160).references, .values = (operand_160).values, .zx_origin = (&operand_160), };

        while (((state_152).index < (state_152).count)) {
            state_152 = block_183: {
                const value_11: u64 = (try function_0(allocator, block_182: {
                    const operand_180 = (state_152).values;
                    const operand_181 = ((state_152).first + (state_152).index);

                    if ((operand_181 >= (operand_180).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_182 (operand_180)[@intCast(operand_181)];
                }));
                const value_12: (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_179: {
                    break :block_179 @as((zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (state_152).count, .first = (state_152).first, .index = (state_152).index, .mapping = (state_152).mapping, .references = @as([]const u32, (if (((buffers).lane_0 != null)) block_171: {
                        const operand_165 = (state_152).references;
                        const operand_170 = block_169: {
                            const operand_167 = (state_152).mapping;
                            const operand_168 = block_166: {
                                break :block_166 value_11;
                            };

                            if ((operand_168 >= (operand_167).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_169 (operand_167)[@intCast(operand_168)];
                        };

                        _ = (try ((std).math).add(usize, (operand_165).len, 1));

                        if ((!(((buffers).lane_0.?).started).*)) {
                            (try ((((buffers).lane_0.?).buffer).*).appendSlice(allocator, operand_165));

                            (((buffers).lane_0.?).started).* = true;
                        } else {
                            (((((buffers).lane_0.?).buffer).*).items).len = (operand_165).len;
                        }

                        (try ((((buffers).lane_0.?).buffer).*).append(allocator, operand_170));

                        break :block_171 ((((buffers).lane_0.?).buffer).*).items;
                    } else (block_178: {
                        const operand_172 = (state_152).references;
                        const operand_177 = block_176: {
                            const operand_174 = (state_152).mapping;
                            const operand_175 = block_173: {
                                break :block_173 value_11;
                            };

                            if ((operand_175 >= (operand_174).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_176 (operand_174)[@intCast(operand_175)];
                        };

                        _ = (try ((std).math).add(usize, (operand_172).len, 1));

                        if ((!state_capacity_started_162)) {
                            (try (state_capacity_161).appendSlice(allocator, operand_172));

                            state_capacity_started_162 = true;
                        } else {
                            ((state_capacity_161).items).len = (operand_172).len;
                        }

                        (try (state_capacity_161).append(allocator, operand_177));

                        break :block_178 @as((zx_abi).value_zx_type_48_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_161).items, {}, null, });
                    }).@"0")), .values = (state_152).values, });
                };
                const value_13: u64 = (value_12).index;
                const value_14: (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_164: {
                    break :block_164 @as((zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (value_12).count, .first = (value_12).first, .index = (block_163: {
                        break :block_163 value_13;
                    } + @as(u64, 1)), .mapping = (value_12).mapping, .references = (value_12).references, .values = (value_12).values, });
                };

                break :block_183 value_14;
            };
        }

        var state_owned_184: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_184);

        if (state_capacity_started_162) {
            ((state_capacity_161).items).len = ((state_152).references).len;

            state_owned_184 = (try (state_capacity_161).toOwnedSlice(allocator));
        }

        if (state_capacity_started_162) {
            state_152 = (zx_abi).value_zx_type_53_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = (state_152).count, .first = (state_152).first, .index = (state_152).index, .mapping = (state_152).mapping, .references = state_owned_184, .values = (state_152).values, };
        }

        break :block_187 block_186: {
            break :block_186 (if (((state_152).zx_origin != null)) ((state_152).zx_origin.?).* else block_185: {
                break :block_185 (zx_abi).zx_type_53{ .count = (state_152).count, .first = (state_152).first, .index = (state_152).index, .mapping = (state_152).mapping, .references = (state_152).references, .values = (state_152).values, };
            });
        };
    }).references;
}

fn function_20(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_39) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }!*const (zx_abi).zx_type_25 {
    @setRuntimeSafety(true);

    if (((((in).candidate).kind == @as((zx_abi).zx_type_11, .Enumeration)) or (((in).candidate).kind == @as((zx_abi).zx_type_11, .NativeReference)))) {
        return block_51: {
            const operand_47 = false;
            const operand_48 = @as(u32, 0);

            break :block_51 block_50: {
                const operand_49 = (try (allocator).create((zx_abi).zx_type_25));

                (operand_49).* = @as((zx_abi).zx_type_25, (zx_abi).zx_type_25{ .found = operand_47, .id = operand_48, });

                break :block_50 @as(*const (zx_abi).zx_type_25, operand_49);
            };
        };
    }

    const value_1: u32 = @as(u32, 0);
    const value_2: u64 = (@as(u64, ((((in).tables).base).kinds).len) + @as(u64, ((((in).tables).delta).kinds).len));

    return block_46: {
        const state_type_2 = struct {
            names: []const []const u8,
            types: []const u32,
        };
        const state_type_3 = struct {
            children: []const u32,
            fields: state_type_2,
            first: u32,
            kind: (zx_abi).zx_type_11,
            label: []const u8,
            names: []const []const u8,
            second: u32,
        };
        const state_type_4 = struct {
            children: []const u32,
            field_names: []const []const u8,
            field_types: []const u32,
            first: []const u32,
            kinds: []const u8,
            labels: []const []const u8,
            names: []const []const u8,
            second: []const u32,
        };
        const state_type_5 = struct {
            base: state_type_4,
            delta: state_type_4,
        };
        const state_type_6 = struct {
            candidate: state_type_3,
            count: u64,
            found: bool,
            id: u32,
            index: u64,
            tables: state_type_5,
        };
        const state_type_8 = struct {
            candidate: state_type_3,
            tables: state_type_5,
        };
        const operand_19 = block_18: {
            const operand_10 = (block_9: {
                const operand_7 = in;

                break :block_9 state_type_8{ .candidate = state_type_3{ .children = ((operand_7).candidate).children, .fields = state_type_2{ .names = (((operand_7).candidate).fields).names, .types = (((operand_7).candidate).fields).types, }, .first = ((operand_7).candidate).first, .kind = ((operand_7).candidate).kind, .label = ((operand_7).candidate).label, .names = ((operand_7).candidate).names, .second = ((operand_7).candidate).second, }, .tables = state_type_5{ .base = state_type_4{ .children = (((operand_7).tables).base).children, .field_names = (((operand_7).tables).base).field_names, .field_types = (((operand_7).tables).base).field_types, .first = (((operand_7).tables).base).first, .kinds = (((operand_7).tables).base).kinds, .labels = (((operand_7).tables).base).labels, .names = (((operand_7).tables).base).names, .second = (((operand_7).tables).base).second, }, .delta = state_type_4{ .children = (((operand_7).tables).delta).children, .field_names = (((operand_7).tables).delta).field_names, .field_types = (((operand_7).tables).delta).field_types, .first = (((operand_7).tables).delta).first, .kinds = (((operand_7).tables).delta).kinds, .labels = (((operand_7).tables).delta).labels, .names = (((operand_7).tables).delta).names, .second = (((operand_7).tables).delta).second, }, }, };
            }).tables;
            const operand_13 = (block_12: {
                const operand_11 = in;

                break :block_12 state_type_8{ .candidate = state_type_3{ .children = ((operand_11).candidate).children, .fields = state_type_2{ .names = (((operand_11).candidate).fields).names, .types = (((operand_11).candidate).fields).types, }, .first = ((operand_11).candidate).first, .kind = ((operand_11).candidate).kind, .label = ((operand_11).candidate).label, .names = ((operand_11).candidate).names, .second = ((operand_11).candidate).second, }, .tables = state_type_5{ .base = state_type_4{ .children = (((operand_11).tables).base).children, .field_names = (((operand_11).tables).base).field_names, .field_types = (((operand_11).tables).base).field_types, .first = (((operand_11).tables).base).first, .kinds = (((operand_11).tables).base).kinds, .labels = (((operand_11).tables).base).labels, .names = (((operand_11).tables).base).names, .second = (((operand_11).tables).base).second, }, .delta = state_type_4{ .children = (((operand_11).tables).delta).children, .field_names = (((operand_11).tables).delta).field_names, .field_types = (((operand_11).tables).delta).field_types, .first = (((operand_11).tables).delta).first, .kinds = (((operand_11).tables).delta).kinds, .labels = (((operand_11).tables).delta).labels, .names = (((operand_11).tables).delta).names, .second = (((operand_11).tables).delta).second, }, }, };
            }).candidate;
            const operand_14 = value_2;
            const operand_15 = @as(u64, 0);
            const operand_16 = false;
            const operand_17 = value_1;

            break :block_18 state_type_6{ .tables = operand_10, .candidate = operand_13, .count = operand_14, .index = operand_15, .found = operand_16, .id = operand_17, };
        };
        const state_type_26 = struct {
            candidate: state_type_3,
            id: u32,
            tables: state_type_5,
        };

        var state_1: state_type_6 = operand_19;

        var state_changed_20 = false;

        while (((!(state_1).found) and ((state_1).index < (state_1).count))) {
            state_1 = block_40: {
                const value_5: u32 = (try function_2(allocator, (state_1).index));
                const value_6: bool = block_39: {
                    const operand_31 = block_30: {
                        const operand_27 = (state_1).tables;
                        const operand_28 = value_5;
                        const operand_29 = (state_1).candidate;

                        break :block_30 state_type_26{ .tables = operand_27, .id = operand_28, .candidate = operand_29, };
                    };
                    const operand_32 = (zx_abi).zx_type_17{ .names = (((operand_31).candidate).fields).names, .types = (((operand_31).candidate).fields).types, };
                    const operand_33 = (zx_abi).zx_type_24{ .children = ((operand_31).candidate).children, .fields = (&operand_32), .first = ((operand_31).candidate).first, .kind = ((operand_31).candidate).kind, .label = ((operand_31).candidate).label, .names = ((operand_31).candidate).names, .second = ((operand_31).candidate).second, };
                    const operand_34 = (zx_abi).zx_type_15{ .children = (((operand_31).tables).base).children, .field_names = (((operand_31).tables).base).field_names, .field_types = (((operand_31).tables).base).field_types, .first = (((operand_31).tables).base).first, .kinds = (((operand_31).tables).base).kinds, .labels = (((operand_31).tables).base).labels, .names = (((operand_31).tables).base).names, .second = (((operand_31).tables).base).second, };
                    const operand_35 = (zx_abi).zx_type_15{ .children = (((operand_31).tables).delta).children, .field_names = (((operand_31).tables).delta).field_names, .field_types = (((operand_31).tables).delta).field_types, .first = (((operand_31).tables).delta).first, .kinds = (((operand_31).tables).delta).kinds, .labels = (((operand_31).tables).delta).labels, .names = (((operand_31).tables).delta).names, .second = (((operand_31).tables).delta).second, };
                    const operand_36 = (zx_abi).zx_type_16{ .base = (&operand_34), .delta = (&operand_35), };
                    const operand_37 = (zx_abi).zx_type_31{ .candidate = (&operand_33), .id = (operand_31).id, .tables = (&operand_36), };
                    const operand_38 = (try function_13(allocator, (&operand_37)));

                    break :block_39 operand_38;
                };
                const value_7: state_type_6 = block_25: {
                    const operand_21 = state_1;
                    const operand_22 = ((state_1).index + @as(u64, 1));
                    const operand_23 = value_6;
                    const operand_24 = value_5;

                    break :block_25 state_type_6{ .candidate = (operand_21).candidate, .count = (operand_21).count, .found = operand_23, .id = operand_24, .index = operand_22, .tables = (operand_21).tables, };
                };

                break :block_40 value_7;
            };

            state_changed_20 = true;
        }

        break :block_46 block_45: {
            const operand_41 = (state_1).found;
            const operand_42 = (state_1).id;

            break :block_45 block_44: {
                const operand_43 = (try (allocator).create((zx_abi).zx_type_25));

                (operand_43).* = @as((zx_abi).zx_type_25, (zx_abi).zx_type_25{ .found = operand_41, .id = operand_42, });

                break :block_44 @as(*const (zx_abi).zx_type_25, operand_43);
            };
        };
    };
}

fn function_20_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_39_3afcb41c858ed0378286c06aa6741c09757edf7ccb0bae1f3f323f9df6195319) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }!(zx_abi).value_zx_type_25_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    if (((((in).candidate).kind == @as((zx_abi).zx_type_11, .Enumeration)) or (((in).candidate).kind == @as((zx_abi).zx_type_11, .NativeReference)))) {
        return block_100: {
            const operand_98 = false;
            const operand_99 = @as(u32, 0);

            break :block_100 @as((zx_abi).value_zx_type_25_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_25_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .found = operand_98, .id = operand_99, });
        };
    }

    const value_1: u32 = @as(u32, 0);
    const value_2: u64 = (@as(u64, ((((in).tables).base).kinds).len) + @as(u64, ((((in).tables).delta).kinds).len));
    const value_8: (zx_abi).value_zx_type_54_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e = block_97: {
        const operand_66 = block_65: {
            const operand_57 = (in).tables;
            const operand_58 = (in).candidate;
            const operand_59 = block_60: {
                break :block_60 value_2;
            };
            const operand_61 = @as(u64, 0);
            const operand_62 = false;
            const operand_63 = block_64: {
                break :block_64 value_1;
            };

            break :block_65 @as((zx_abi).value_zx_type_54_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e, (zx_abi).value_zx_type_54_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e{ .tables = operand_57, .candidate = operand_58, .count = operand_59, .index = operand_61, .found = operand_62, .id = operand_63, });
        };

        var state_56: (zx_abi).value_zx_type_54_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e = operand_66;

        var state_changed_67 = false;

        while (((!(state_56).found) and ((state_56).index < (state_56).count))) {
            state_56 = block_95: {
                const value_5: u32 = (try function_2(allocator, (state_56).index));
                const value_6: bool = block_94: {
                    const operand_75 = (state_56).tables;

                    var state_borrow_76: (zx_abi).zx_type_15 = undefined;

                    state_borrow_76 = (zx_abi).zx_type_15{ .children = ((operand_75).base).children, .field_names = ((operand_75).base).field_names, .field_types = ((operand_75).base).field_types, .first = ((operand_75).base).first, .kinds = ((operand_75).base).kinds, .labels = ((operand_75).base).labels, .names = ((operand_75).base).names, .second = ((operand_75).base).second, };

                    var state_borrow_77: (zx_abi).zx_type_15 = undefined;

                    state_borrow_77 = (zx_abi).zx_type_15{ .children = ((operand_75).delta).children, .field_names = ((operand_75).delta).field_names, .field_types = ((operand_75).delta).field_types, .first = ((operand_75).delta).first, .kinds = ((operand_75).delta).kinds, .labels = ((operand_75).delta).labels, .names = ((operand_75).delta).names, .second = ((operand_75).delta).second, };

                    var state_borrow_78: (zx_abi).zx_type_16 = undefined;

                    state_borrow_78 = (zx_abi).zx_type_16{ .base = (((operand_75).base).zx_origin orelse (&state_borrow_76)), .delta = (((operand_75).delta).zx_origin orelse (&state_borrow_77)), };

                    const operand_79 = ((operand_75).zx_origin orelse (&state_borrow_78));
                    const operand_81 = block_80: {
                        break :block_80 value_5;
                    };
                    const operand_82 = (state_56).candidate;

                    var state_borrow_83: (zx_abi).zx_type_17 = undefined;

                    state_borrow_83 = (zx_abi).zx_type_17{ .names = ((operand_82).fields).names, .types = ((operand_82).fields).types, };

                    var state_borrow_84: (zx_abi).zx_type_24 = undefined;

                    state_borrow_84 = (zx_abi).zx_type_24{ .children = (operand_82).children, .fields = (((operand_82).fields).zx_origin orelse (&state_borrow_83)), .first = (operand_82).first, .kind = (operand_82).kind, .label = (operand_82).label, .names = (operand_82).names, .second = (operand_82).second, };

                    const operand_85 = ((operand_82).zx_origin orelse (&state_borrow_84));
                    const operand_86 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_79).base).children, .field_names = ((operand_79).base).field_names, .field_types = ((operand_79).base).field_types, .first = ((operand_79).base).first, .kinds = ((operand_79).base).kinds, .labels = ((operand_79).base).labels, .names = ((operand_79).base).names, .second = ((operand_79).base).second, .zx_origin = (operand_79).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_79).delta).children, .field_names = ((operand_79).delta).field_names, .field_types = ((operand_79).delta).field_types, .first = ((operand_79).delta).first, .kinds = ((operand_79).delta).kinds, .labels = ((operand_79).delta).labels, .names = ((operand_79).delta).names, .second = ((operand_79).delta).second, .zx_origin = (operand_79).delta, }, .zx_origin = operand_79, };

                    var state_borrow_87: (zx_abi).zx_type_15 = undefined;

                    state_borrow_87 = (zx_abi).zx_type_15{ .children = ((operand_86).base).children, .field_names = ((operand_86).base).field_names, .field_types = ((operand_86).base).field_types, .first = ((operand_86).base).first, .kinds = ((operand_86).base).kinds, .labels = ((operand_86).base).labels, .names = ((operand_86).base).names, .second = ((operand_86).base).second, };

                    var state_borrow_88: (zx_abi).zx_type_15 = undefined;

                    state_borrow_88 = (zx_abi).zx_type_15{ .children = ((operand_86).delta).children, .field_names = ((operand_86).delta).field_names, .field_types = ((operand_86).delta).field_types, .first = ((operand_86).delta).first, .kinds = ((operand_86).delta).kinds, .labels = ((operand_86).delta).labels, .names = ((operand_86).delta).names, .second = ((operand_86).delta).second, };

                    var state_borrow_89: (zx_abi).zx_type_16 = undefined;

                    state_borrow_89 = (zx_abi).zx_type_16{ .base = (((operand_86).base).zx_origin orelse (&state_borrow_87)), .delta = (((operand_86).delta).zx_origin orelse (&state_borrow_88)), };

                    const operand_90 = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_85).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_85).fields).names, .types = ((operand_85).fields).types, .zx_origin = (operand_85).fields, }, .first = (operand_85).first, .kind = (operand_85).kind, .label = (operand_85).label, .names = (operand_85).names, .second = (operand_85).second, .zx_origin = operand_85, };

                    var state_borrow_91: (zx_abi).zx_type_17 = undefined;

                    state_borrow_91 = (zx_abi).zx_type_17{ .names = ((operand_90).fields).names, .types = ((operand_90).fields).types, };

                    var state_borrow_92: (zx_abi).zx_type_24 = undefined;

                    state_borrow_92 = (zx_abi).zx_type_24{ .children = (operand_90).children, .fields = (((operand_90).fields).zx_origin orelse (&state_borrow_91)), .first = (operand_90).first, .kind = (operand_90).kind, .label = (operand_90).label, .names = (operand_90).names, .second = (operand_90).second, };

                    const operand_93 = (zx_abi).zx_type_31{ .tables = ((operand_86).zx_origin orelse (&state_borrow_89)), .id = operand_81, .candidate = ((operand_90).zx_origin orelse (&state_borrow_92)), };

                    break :block_94 (try function_13(allocator, (&operand_93)));
                };
                const value_7: (zx_abi).value_zx_type_54_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e = block_74: {
                    const operand_68 = state_56;
                    const operand_69 = ((state_56).index + @as(u64, 1));
                    const operand_70 = block_71: {
                        break :block_71 value_6;
                    };
                    const operand_72 = block_73: {
                        break :block_73 value_5;
                    };

                    break :block_74 @as((zx_abi).value_zx_type_54_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e, (zx_abi).value_zx_type_54_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e{ .candidate = (operand_68).candidate, .count = (operand_68).count, .found = operand_70, .id = operand_72, .index = operand_69, .tables = (operand_68).tables, });
                };

                break :block_95 value_7;
            };

            state_changed_67 = true;
        }

        break :block_97 (if (state_changed_67) state_56 else operand_66);
    };

    return block_55: {
        const operand_53 = (value_8).found;
        const operand_54 = (value_8).id;

        break :block_55 @as((zx_abi).value_zx_type_25_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_25_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .found = operand_53, .id = operand_54, });
    };
}

fn function_21(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_39) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }!u64 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_25 = block_4: {
        const operand_1 = in;
        const operand_2 = (try function_20_value(allocator, (zx_abi).value_zx_type_39_3afcb41c858ed0378286c06aa6741c09757edf7ccb0bae1f3f323f9df6195319{ .candidate = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = ((operand_1).candidate).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = (((operand_1).candidate).fields).names, .types = (((operand_1).candidate).fields).types, .zx_origin = ((operand_1).candidate).fields, }, .first = ((operand_1).candidate).first, .kind = ((operand_1).candidate).kind, .label = ((operand_1).candidate).label, .names = ((operand_1).candidate).names, .second = ((operand_1).candidate).second, .zx_origin = (operand_1).candidate, }, .tables = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).base).children, .field_names = (((operand_1).tables).base).field_names, .field_types = (((operand_1).tables).base).field_types, .first = (((operand_1).tables).base).first, .kinds = (((operand_1).tables).base).kinds, .labels = (((operand_1).tables).base).labels, .names = (((operand_1).tables).base).names, .second = (((operand_1).tables).base).second, .zx_origin = ((operand_1).tables).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).delta).children, .field_names = (((operand_1).tables).delta).field_names, .field_types = (((operand_1).tables).delta).field_types, .first = (((operand_1).tables).delta).first, .kinds = (((operand_1).tables).delta).kinds, .labels = (((operand_1).tables).delta).labels, .names = (((operand_1).tables).delta).names, .second = (((operand_1).tables).delta).second, .zx_origin = ((operand_1).tables).delta, }, .zx_origin = (operand_1).tables, }, .zx_origin = operand_1, }));

        break :block_4 (if (((operand_2).zx_origin != null)) ((operand_2).zx_origin.?).* else block_3: {
            break :block_3 (zx_abi).zx_type_25{ .found = (operand_2).found, .id = (operand_2).id, };
        });
    };

    return (if (((&value_1)).found) ((try function_0(allocator, ((&value_1)).id)) + @as(u64, 2)) else @as(u64, 0));
}

fn function_22(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_42 {
    @setRuntimeSafety(true);

    return (block_232: {
        const operand_6 = block_5: {
            const operand_2 = (in).request;
            const operand_3 = (in).state;
            const operand_4 = ((in).request).first;

            break :block_5 (zx_abi).zx_type_55{ .request = operand_2, .state = operand_3, .index = operand_4, };
        };

        var state_capacity_7: (std).ArrayList(u32) = .empty;

        var state_capacity_started_8 = false;

        defer (state_capacity_7).deinit(allocator);

        var state_capacity_9: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_10 = false;

        defer (state_capacity_9).deinit(allocator);

        var state_capacity_11: (std).ArrayList(u32) = .empty;

        var state_capacity_started_12 = false;

        defer (state_capacity_11).deinit(allocator);

        var state_capacity_13: (std).ArrayList(u32) = .empty;

        var state_capacity_started_14 = false;

        defer (state_capacity_13).deinit(allocator);

        var state_capacity_15: (std).ArrayList(u8) = .empty;

        var state_capacity_started_16 = false;

        defer (state_capacity_15).deinit(allocator);

        var state_capacity_17: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_18 = false;

        defer (state_capacity_17).deinit(allocator);

        var state_capacity_19: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_20 = false;

        defer (state_capacity_19).deinit(allocator);

        var state_capacity_21: (std).ArrayList(u32) = .empty;

        var state_capacity_started_22 = false;

        defer (state_capacity_21).deinit(allocator);

        var state_items_23: []u32 = undefined;

        var state_items_started_24 = false;

        var state_capacity_25: (std).ArrayList(u32) = .empty;

        var state_capacity_started_26 = false;

        defer (state_capacity_25).deinit(allocator);

        var state_capacity_27: (std).ArrayList(u8) = .empty;

        var state_capacity_started_28 = false;

        defer (state_capacity_27).deinit(allocator);

        var state_capacity_29: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_30 = false;

        defer (state_capacity_29).deinit(allocator);

        var state_capacity_31: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_32 = false;

        defer (state_capacity_31).deinit(allocator);

        var state_capacity_33: (std).ArrayList(u32) = .empty;

        var state_capacity_started_34 = false;

        defer (state_capacity_33).deinit(allocator);

        var state_1: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (operand_6).index, .request = (zx_abi).value_zx_type_41_3540ff82cd7401f2790fb0b97d3e60eb4ca97c3dede3a7b74038ab46d2dcac57{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_6).request).base).children, .field_names = (((operand_6).request).base).field_names, .field_types = (((operand_6).request).base).field_types, .first = (((operand_6).request).base).first, .kinds = (((operand_6).request).base).kinds, .labels = (((operand_6).request).base).labels, .names = (((operand_6).request).base).names, .second = (((operand_6).request).base).second, .zx_origin = ((operand_6).request).base, }, .base_origins = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_6).request).base_origins).ids, .kinds = (((operand_6).request).base_origins).kinds, .members = (((operand_6).request).base_origins).members, .owners = (((operand_6).request).base_origins).owners, .zx_origin = ((operand_6).request).base_origins, }, .first = ((operand_6).request).first, .origin_indices = ((operand_6).request).origin_indices, .origins = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_6).request).origins).ids, .kinds = (((operand_6).request).origins).kinds, .members = (((operand_6).request).origins).members, .owners = (((operand_6).request).origins).owners, .zx_origin = ((operand_6).request).origins, }, .source = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_6).request).source).children, .field_names = (((operand_6).request).source).field_names, .field_types = (((operand_6).request).source).field_types, .first = (((operand_6).request).source).first, .kinds = (((operand_6).request).source).kinds, .labels = (((operand_6).request).source).labels, .names = (((operand_6).request).source).names, .second = (((operand_6).request).source).second, .zx_origin = ((operand_6).request).source, }, .zx_origin = (operand_6).request, }, .state = (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_6).state).delta).children, .field_names = (((operand_6).state).delta).field_names, .field_types = (((operand_6).state).delta).field_types, .first = (((operand_6).state).delta).first, .kinds = (((operand_6).state).delta).kinds, .labels = (((operand_6).state).delta).labels, .names = (((operand_6).state).delta).names, .second = (((operand_6).state).delta).second, .zx_origin = ((operand_6).state).delta, }, .mapping = ((operand_6).state).mapping, .origins = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_6).state).origins).ids, .kinds = (((operand_6).state).origins).kinds, .members = (((operand_6).state).origins).members, .owners = (((operand_6).state).origins).owners, .zx_origin = ((operand_6).state).origins, }, .references = ((operand_6).state).references, .status = ((operand_6).state).status, .zx_origin = (operand_6).state, }, .zx_origin = (&operand_6), };

        while (((((state_1).state).status == @as(u64, 0)) and ((state_1).index < @as(u64, ((((state_1).request).source).kinds).len)))) {
            state_1 = block_200: {
                const value_3: (zx_abi).value_zx_type_41_3540ff82cd7401f2790fb0b97d3e60eb4ca97c3dede3a7b74038ab46d2dcac57 = (state_1).request;
                const value_4: u64 = (state_1).index;
                const value_5: []const u32 = block_199: {
                    const operand_196 = block_195: {
                        const operand_190 = (value_3).source;
                        const operand_191 = block_192: {
                            break :block_192 value_4;
                        };
                        const operand_193 = ((state_1).state).mapping;
                        const operand_194 = ((state_1).state).references;

                        break :block_195 @as((zx_abi).value_zx_type_38_b007dd1e4c63d95a3155329e1f60b16a22582c9bf6a4aa0bbdeb58811f8f72c5, (zx_abi).value_zx_type_38_b007dd1e4c63d95a3155329e1f60b16a22582c9bf6a4aa0bbdeb58811f8f72c5{ .source = operand_190, .index = operand_191, .mapping = operand_193, .references = operand_194, });
                    };

                    var state_borrow_197: (zx_abi).zx_type_15 = undefined;

                    state_borrow_197 = (zx_abi).zx_type_15{ .children = ((operand_196).source).children, .field_names = ((operand_196).source).field_names, .field_types = ((operand_196).source).field_types, .first = ((operand_196).source).first, .kinds = ((operand_196).source).kinds, .labels = ((operand_196).source).labels, .names = ((operand_196).source).names, .second = ((operand_196).source).second, };

                    var state_borrow_198: (zx_abi).zx_type_38 = undefined;

                    state_borrow_198 = (zx_abi).zx_type_38{ .index = (operand_196).index, .mapping = (operand_196).mapping, .references = (operand_196).references, .source = (((operand_196).source).zx_origin orelse (&state_borrow_197)), };

                    break :block_199 (try function_19_buffered(allocator, ((operand_196).zx_origin orelse (&state_borrow_198)), .{ .lane_0 = .{ .buffer = (&state_capacity_33), .started = (&state_capacity_started_34), }, }));
                };
                const value_6: (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = block_189: {
                    break :block_189 (try function_10_value(allocator, block_188: {
                        const operand_183 = (value_3).source;
                        const operand_184 = block_185: {
                            break :block_185 value_4;
                        };
                        const operand_186 = block_187: {
                            break :block_187 value_5;
                        };

                        break :block_188 @as((zx_abi).value_zx_type_28_bc0beef4baed6cbec65527f285ce2af317364f06c28bd549a5782c80f0e63a13, (zx_abi).value_zx_type_28_bc0beef4baed6cbec65527f285ce2af317364f06c28bd549a5782c80f0e63a13{ .source = operand_183, .index = operand_184, .references = operand_186, });
                    }));
                };
                const value_7: (zx_abi).zx_type_11 = (try function_5(allocator, block_182: {
                    const operand_180 = ((value_3).source).kinds;
                    const operand_181 = block_179: {
                        break :block_179 value_4;
                    };

                    if ((operand_181 >= (operand_180).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_182 (operand_180)[@intCast(operand_181)];
                }));
                const value_8: bool = ((block_177: {
                    break :block_177 value_7;
                } == @as((zx_abi).zx_type_11, .Enumeration)) or (block_178: {
                    break :block_178 value_7;
                } == @as((zx_abi).zx_type_11, .NativeReference)));
                const value_21: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = (if ((block_37: {
                    break :block_37 value_8;
                } and (block_41: {
                    const operand_39 = (value_3).origin_indices;
                    const operand_40 = block_38: {
                        break :block_38 value_4;
                    };

                    if ((operand_40 >= (operand_39).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_41 (operand_39)[@intCast(operand_40)];
                } == @as(u64, 0)))) block_48: {
                    const value_9: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_47: {
                        break :block_47 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = block_46: {
                            const operand_42 = (state_1).state;
                            const operand_43 = block_44: {
                                break :block_44 value_5;
                            };
                            const operand_45 = @as(u64, 1);

                            break :block_46 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_42).delta, .mapping = (operand_42).mapping, .origins = (operand_42).origins, .references = operand_43, .status = operand_45, });
                        }, });
                    };

                    break :block_48 value_9;
                } else block_176: {
                    const value_10: u64 = (if (block_171: {
                        break :block_171 value_8;
                    }) (block_175: {
                        const operand_173 = (value_3).origin_indices;
                        const operand_174 = block_172: {
                            break :block_172 value_4;
                        };

                        if ((operand_174 >= (operand_173).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_175 (operand_173)[@intCast(operand_174)];
                    } - @as(u64, 1)) else @as(u64, 0));
                    const value_11: (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (if (block_150: {
                        break :block_150 value_8;
                    }) block_166: {
                        const operand_151 = block_155: {
                            const operand_153 = ((value_3).origins).kinds;
                            const operand_154 = block_152: {
                                break :block_152 value_10;
                            };

                            if ((operand_154 >= (operand_153).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_155 (operand_153)[@intCast(operand_154)];
                        };
                        const operand_156 = block_160: {
                            const operand_158 = ((value_3).origins).owners;
                            const operand_159 = block_157: {
                                break :block_157 value_10;
                            };

                            if ((operand_159 >= (operand_158).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_160 (operand_158)[@intCast(operand_159)];
                        };
                        const operand_161 = block_165: {
                            const operand_163 = ((value_3).origins).members;
                            const operand_164 = block_162: {
                                break :block_162 value_10;
                            };

                            if ((operand_164 >= (operand_163).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_165 (operand_163)[@intCast(operand_164)];
                        };

                        break :block_166 @as((zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = operand_151, .owner = operand_156, .member = operand_161, });
                    } else block_170: {
                        const operand_167 = @as(u8, 0);
                        const operand_168 = @as([]const u8, "");
                        const operand_169 = @as([]const u8, "");

                        break :block_170 @as((zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = operand_167, .owner = operand_168, .member = operand_169, });
                    });
                    const value_12: (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9 = block_149: {
                        const operand_147 = (value_3).base;
                        const operand_148 = ((state_1).state).delta;

                        break :block_149 @as((zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9, (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = operand_147, .delta = operand_148, });
                    };
                    const value_13: u64 = (if (block_89: {
                        break :block_89 value_8;
                    }) block_128: {
                        const operand_90 = value_12;

                        var state_borrow_91: (zx_abi).zx_type_15 = undefined;

                        state_borrow_91 = (zx_abi).zx_type_15{ .children = ((operand_90).base).children, .field_names = ((operand_90).base).field_names, .field_types = ((operand_90).base).field_types, .first = ((operand_90).base).first, .kinds = ((operand_90).base).kinds, .labels = ((operand_90).base).labels, .names = ((operand_90).base).names, .second = ((operand_90).base).second, };

                        var state_borrow_92: (zx_abi).zx_type_15 = undefined;

                        state_borrow_92 = (zx_abi).zx_type_15{ .children = ((operand_90).delta).children, .field_names = ((operand_90).delta).field_names, .field_types = ((operand_90).delta).field_types, .first = ((operand_90).delta).first, .kinds = ((operand_90).delta).kinds, .labels = ((operand_90).delta).labels, .names = ((operand_90).delta).names, .second = ((operand_90).delta).second, };

                        var state_borrow_93: (zx_abi).zx_type_16 = undefined;

                        state_borrow_93 = (zx_abi).zx_type_16{ .base = (((operand_90).base).zx_origin orelse (&state_borrow_91)), .delta = (((operand_90).delta).zx_origin orelse (&state_borrow_92)), };

                        const operand_94 = ((operand_90).zx_origin orelse (&state_borrow_93));
                        const operand_95 = (value_3).base_origins;

                        var state_borrow_96: (zx_abi).zx_type_34 = undefined;

                        state_borrow_96 = (zx_abi).zx_type_34{ .ids = (operand_95).ids, .kinds = (operand_95).kinds, .members = (operand_95).members, .owners = (operand_95).owners, };

                        const operand_97 = ((operand_95).zx_origin orelse (&state_borrow_96));
                        const operand_98 = ((state_1).state).origins;

                        var state_borrow_99: (zx_abi).zx_type_34 = undefined;

                        state_borrow_99 = (zx_abi).zx_type_34{ .ids = (operand_98).ids, .kinds = (operand_98).kinds, .members = (operand_98).members, .owners = (operand_98).owners, };

                        const operand_100 = ((operand_98).zx_origin orelse (&state_borrow_99));
                        const operand_101 = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (operand_97).ids, .kinds = (operand_97).kinds, .members = (operand_97).members, .owners = (operand_97).owners, .zx_origin = operand_97, };

                        var state_borrow_102: (zx_abi).zx_type_34 = undefined;

                        state_borrow_102 = (zx_abi).zx_type_34{ .ids = (operand_101).ids, .kinds = (operand_101).kinds, .members = (operand_101).members, .owners = (operand_101).owners, };

                        const operand_103 = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (operand_100).ids, .kinds = (operand_100).kinds, .members = (operand_100).members, .owners = (operand_100).owners, .zx_origin = operand_100, };

                        var state_borrow_104: (zx_abi).zx_type_34 = undefined;

                        state_borrow_104 = (zx_abi).zx_type_34{ .ids = (operand_103).ids, .kinds = (operand_103).kinds, .members = (operand_103).members, .owners = (operand_103).owners, };

                        const operand_105 = (zx_abi).zx_type_35{ .base = ((operand_101).zx_origin orelse (&state_borrow_102)), .delta = ((operand_103).zx_origin orelse (&state_borrow_104)), };
                        const operand_106 = (&operand_105);
                        const operand_107 = value_11;

                        var state_borrow_108: (zx_abi).zx_type_33 = undefined;

                        state_borrow_108 = (zx_abi).zx_type_33{ .kind = (operand_107).kind, .member = (operand_107).member, .owner = (operand_107).owner, };

                        const operand_109 = ((operand_107).zx_origin orelse (&state_borrow_108));
                        const operand_110 = value_6;

                        var state_borrow_111: (zx_abi).zx_type_17 = undefined;

                        state_borrow_111 = (zx_abi).zx_type_17{ .names = ((operand_110).fields).names, .types = ((operand_110).fields).types, };

                        var state_borrow_112: (zx_abi).zx_type_24 = undefined;

                        state_borrow_112 = (zx_abi).zx_type_24{ .children = (operand_110).children, .fields = (((operand_110).fields).zx_origin orelse (&state_borrow_111)), .first = (operand_110).first, .kind = (operand_110).kind, .label = (operand_110).label, .names = (operand_110).names, .second = (operand_110).second, };

                        const operand_113 = ((operand_110).zx_origin orelse (&state_borrow_112));
                        const operand_114 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_94).base).children, .field_names = ((operand_94).base).field_names, .field_types = ((operand_94).base).field_types, .first = ((operand_94).base).first, .kinds = ((operand_94).base).kinds, .labels = ((operand_94).base).labels, .names = ((operand_94).base).names, .second = ((operand_94).base).second, .zx_origin = (operand_94).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_94).delta).children, .field_names = ((operand_94).delta).field_names, .field_types = ((operand_94).delta).field_types, .first = ((operand_94).delta).first, .kinds = ((operand_94).delta).kinds, .labels = ((operand_94).delta).labels, .names = ((operand_94).delta).names, .second = ((operand_94).delta).second, .zx_origin = (operand_94).delta, }, .zx_origin = operand_94, };

                        var state_borrow_115: (zx_abi).zx_type_15 = undefined;

                        state_borrow_115 = (zx_abi).zx_type_15{ .children = ((operand_114).base).children, .field_names = ((operand_114).base).field_names, .field_types = ((operand_114).base).field_types, .first = ((operand_114).base).first, .kinds = ((operand_114).base).kinds, .labels = ((operand_114).base).labels, .names = ((operand_114).base).names, .second = ((operand_114).base).second, };

                        var state_borrow_116: (zx_abi).zx_type_15 = undefined;

                        state_borrow_116 = (zx_abi).zx_type_15{ .children = ((operand_114).delta).children, .field_names = ((operand_114).delta).field_names, .field_types = ((operand_114).delta).field_types, .first = ((operand_114).delta).first, .kinds = ((operand_114).delta).kinds, .labels = ((operand_114).delta).labels, .names = ((operand_114).delta).names, .second = ((operand_114).delta).second, };

                        var state_borrow_117: (zx_abi).zx_type_16 = undefined;

                        state_borrow_117 = (zx_abi).zx_type_16{ .base = (((operand_114).base).zx_origin orelse (&state_borrow_115)), .delta = (((operand_114).delta).zx_origin orelse (&state_borrow_116)), };

                        const operand_118 = (zx_abi).value_zx_type_35_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53{ .base = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = ((operand_106).base).ids, .kinds = ((operand_106).base).kinds, .members = ((operand_106).base).members, .owners = ((operand_106).base).owners, .zx_origin = (operand_106).base, }, .delta = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = ((operand_106).delta).ids, .kinds = ((operand_106).delta).kinds, .members = ((operand_106).delta).members, .owners = ((operand_106).delta).owners, .zx_origin = (operand_106).delta, }, .zx_origin = operand_106, };

                        var state_borrow_119: (zx_abi).zx_type_34 = undefined;

                        state_borrow_119 = (zx_abi).zx_type_34{ .ids = ((operand_118).base).ids, .kinds = ((operand_118).base).kinds, .members = ((operand_118).base).members, .owners = ((operand_118).base).owners, };

                        var state_borrow_120: (zx_abi).zx_type_34 = undefined;

                        state_borrow_120 = (zx_abi).zx_type_34{ .ids = ((operand_118).delta).ids, .kinds = ((operand_118).delta).kinds, .members = ((operand_118).delta).members, .owners = ((operand_118).delta).owners, };

                        var state_borrow_121: (zx_abi).zx_type_35 = undefined;

                        state_borrow_121 = (zx_abi).zx_type_35{ .base = (((operand_118).base).zx_origin orelse (&state_borrow_119)), .delta = (((operand_118).delta).zx_origin orelse (&state_borrow_120)), };

                        const operand_122 = (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = (operand_109).kind, .member = (operand_109).member, .owner = (operand_109).owner, .zx_origin = operand_109, };

                        var state_borrow_123: (zx_abi).zx_type_33 = undefined;

                        state_borrow_123 = (zx_abi).zx_type_33{ .kind = (operand_122).kind, .member = (operand_122).member, .owner = (operand_122).owner, };

                        const operand_124 = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_113).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_113).fields).names, .types = ((operand_113).fields).types, .zx_origin = (operand_113).fields, }, .first = (operand_113).first, .kind = (operand_113).kind, .label = (operand_113).label, .names = (operand_113).names, .second = (operand_113).second, .zx_origin = operand_113, };

                        var state_borrow_125: (zx_abi).zx_type_17 = undefined;

                        state_borrow_125 = (zx_abi).zx_type_17{ .names = ((operand_124).fields).names, .types = ((operand_124).fields).types, };

                        var state_borrow_126: (zx_abi).zx_type_24 = undefined;

                        state_borrow_126 = (zx_abi).zx_type_24{ .children = (operand_124).children, .fields = (((operand_124).fields).zx_origin orelse (&state_borrow_125)), .first = (operand_124).first, .kind = (operand_124).kind, .label = (operand_124).label, .names = (operand_124).names, .second = (operand_124).second, };

                        const operand_127 = (zx_abi).zx_type_36{ .tables = ((operand_114).zx_origin orelse (&state_borrow_117)), .origins = ((operand_118).zx_origin orelse (&state_borrow_121)), .origin = ((operand_122).zx_origin orelse (&state_borrow_123)), .candidate = ((operand_124).zx_origin orelse (&state_borrow_126)), };

                        break :block_128 (try function_17(allocator, (&operand_127)));
                    } else block_146: {
                        const operand_129 = value_12;

                        var state_borrow_130: (zx_abi).zx_type_15 = undefined;

                        state_borrow_130 = (zx_abi).zx_type_15{ .children = ((operand_129).base).children, .field_names = ((operand_129).base).field_names, .field_types = ((operand_129).base).field_types, .first = ((operand_129).base).first, .kinds = ((operand_129).base).kinds, .labels = ((operand_129).base).labels, .names = ((operand_129).base).names, .second = ((operand_129).base).second, };

                        var state_borrow_131: (zx_abi).zx_type_15 = undefined;

                        state_borrow_131 = (zx_abi).zx_type_15{ .children = ((operand_129).delta).children, .field_names = ((operand_129).delta).field_names, .field_types = ((operand_129).delta).field_types, .first = ((operand_129).delta).first, .kinds = ((operand_129).delta).kinds, .labels = ((operand_129).delta).labels, .names = ((operand_129).delta).names, .second = ((operand_129).delta).second, };

                        var state_borrow_132: (zx_abi).zx_type_16 = undefined;

                        state_borrow_132 = (zx_abi).zx_type_16{ .base = (((operand_129).base).zx_origin orelse (&state_borrow_130)), .delta = (((operand_129).delta).zx_origin orelse (&state_borrow_131)), };

                        const operand_133 = ((operand_129).zx_origin orelse (&state_borrow_132));
                        const operand_134 = value_6;

                        var state_borrow_135: (zx_abi).zx_type_17 = undefined;

                        state_borrow_135 = (zx_abi).zx_type_17{ .names = ((operand_134).fields).names, .types = ((operand_134).fields).types, };

                        var state_borrow_136: (zx_abi).zx_type_24 = undefined;

                        state_borrow_136 = (zx_abi).zx_type_24{ .children = (operand_134).children, .fields = (((operand_134).fields).zx_origin orelse (&state_borrow_135)), .first = (operand_134).first, .kind = (operand_134).kind, .label = (operand_134).label, .names = (operand_134).names, .second = (operand_134).second, };

                        const operand_137 = ((operand_134).zx_origin orelse (&state_borrow_136));
                        const operand_138 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_133).base).children, .field_names = ((operand_133).base).field_names, .field_types = ((operand_133).base).field_types, .first = ((operand_133).base).first, .kinds = ((operand_133).base).kinds, .labels = ((operand_133).base).labels, .names = ((operand_133).base).names, .second = ((operand_133).base).second, .zx_origin = (operand_133).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_133).delta).children, .field_names = ((operand_133).delta).field_names, .field_types = ((operand_133).delta).field_types, .first = ((operand_133).delta).first, .kinds = ((operand_133).delta).kinds, .labels = ((operand_133).delta).labels, .names = ((operand_133).delta).names, .second = ((operand_133).delta).second, .zx_origin = (operand_133).delta, }, .zx_origin = operand_133, };

                        var state_borrow_139: (zx_abi).zx_type_15 = undefined;

                        state_borrow_139 = (zx_abi).zx_type_15{ .children = ((operand_138).base).children, .field_names = ((operand_138).base).field_names, .field_types = ((operand_138).base).field_types, .first = ((operand_138).base).first, .kinds = ((operand_138).base).kinds, .labels = ((operand_138).base).labels, .names = ((operand_138).base).names, .second = ((operand_138).base).second, };

                        var state_borrow_140: (zx_abi).zx_type_15 = undefined;

                        state_borrow_140 = (zx_abi).zx_type_15{ .children = ((operand_138).delta).children, .field_names = ((operand_138).delta).field_names, .field_types = ((operand_138).delta).field_types, .first = ((operand_138).delta).first, .kinds = ((operand_138).delta).kinds, .labels = ((operand_138).delta).labels, .names = ((operand_138).delta).names, .second = ((operand_138).delta).second, };

                        var state_borrow_141: (zx_abi).zx_type_16 = undefined;

                        state_borrow_141 = (zx_abi).zx_type_16{ .base = (((operand_138).base).zx_origin orelse (&state_borrow_139)), .delta = (((operand_138).delta).zx_origin orelse (&state_borrow_140)), };

                        const operand_142 = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_137).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_137).fields).names, .types = ((operand_137).fields).types, .zx_origin = (operand_137).fields, }, .first = (operand_137).first, .kind = (operand_137).kind, .label = (operand_137).label, .names = (operand_137).names, .second = (operand_137).second, .zx_origin = operand_137, };

                        var state_borrow_143: (zx_abi).zx_type_17 = undefined;

                        state_borrow_143 = (zx_abi).zx_type_17{ .names = ((operand_142).fields).names, .types = ((operand_142).fields).types, };

                        var state_borrow_144: (zx_abi).zx_type_24 = undefined;

                        state_borrow_144 = (zx_abi).zx_type_24{ .children = (operand_142).children, .fields = (((operand_142).fields).zx_origin orelse (&state_borrow_143)), .first = (operand_142).first, .kind = (operand_142).kind, .label = (operand_142).label, .names = (operand_142).names, .second = (operand_142).second, };

                        const operand_145 = (zx_abi).zx_type_39{ .tables = ((operand_138).zx_origin orelse (&state_borrow_141)), .candidate = ((operand_142).zx_origin orelse (&state_borrow_144)), };

                        break :block_146 (try function_21(allocator, (&operand_145)));
                    });
                    const value_20: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = (if ((block_49: {
                        break :block_49 value_13;
                    } == @as(u64, 1))) block_56: {
                        const value_14: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_55: {
                            break :block_55 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = block_54: {
                                const operand_50 = (state_1).state;
                                const operand_51 = block_52: {
                                    break :block_52 value_5;
                                };
                                const operand_53 = @as(u64, 2);

                                break :block_54 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_50).delta, .mapping = (operand_50).mapping, .origins = (operand_50).origins, .references = operand_51, .status = operand_53, });
                            }, });
                        };

                        break :block_56 value_14;
                    } else block_88: {
                        const value_15: u32 = (if ((block_86: {
                            break :block_86 value_13;
                        } == @as(u64, 0))) (try function_2(allocator, (@as(u64, (((value_3).base).kinds).len) + @as(u64, ((((state_1).state).delta).kinds).len)))) else (try function_2(allocator, (block_87: {
                            break :block_87 value_13;
                        } - @as(u64, 2)))));
                        const value_16: (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = (if ((block_81: {
                            break :block_81 value_13;
                        } == @as(u64, 0))) @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, block_85: {
                            break :block_85 (try function_9_buffered(allocator, block_84: {
                                const operand_82 = ((state_1).state).delta;
                                const operand_83 = value_6;

                                break :block_84 @as((zx_abi).value_zx_type_27_eb83b36bd9eb840e506cc8c01a38c13a9cdff0b6a9636a9eecf085d3c539269b, (zx_abi).value_zx_type_27_eb83b36bd9eb840e506cc8c01a38c13a9cdff0b6a9636a9eecf085d3c539269b{ .delta = operand_82, .candidate = operand_83, });
                            }, .{ .lane_0 = .{ .buffer = (&state_capacity_7), .started = (&state_capacity_started_8), }, .lane_1 = .{ .buffer = (&state_capacity_9), .started = (&state_capacity_started_10), }, .lane_2 = .{ .buffer = (&state_capacity_11), .started = (&state_capacity_started_12), }, .lane_3 = .{ .buffer = (&state_capacity_13), .started = (&state_capacity_started_14), }, .lane_4 = .{ .buffer = (&state_capacity_15), .started = (&state_capacity_started_16), }, .lane_5 = .{ .buffer = (&state_capacity_17), .started = (&state_capacity_started_18), }, .lane_6 = .{ .buffer = (&state_capacity_19), .started = (&state_capacity_started_20), }, .lane_7 = .{ .buffer = (&state_capacity_21), .started = (&state_capacity_started_22), }, }));
                        }) else ((state_1).state).delta);
                        const value_17: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if (((block_73: {
                            break :block_73 value_13;
                        } == @as(u64, 0)) and block_74: {
                            break :block_74 value_8;
                        })) @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, block_80: {
                            break :block_80 (try function_18_buffered(allocator, block_79: {
                                const operand_75 = ((state_1).state).origins;
                                const operand_76 = value_11;
                                const operand_77 = block_78: {
                                    break :block_78 value_15;
                                };

                                break :block_79 @as((zx_abi).value_zx_type_37_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39, (zx_abi).value_zx_type_37_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39{ .bindings = operand_75, .origin = operand_76, .id = operand_77, });
                            }, .{ .lane_0 = .{ .buffer = (&state_capacity_25), .started = (&state_capacity_started_26), }, .lane_1 = .{ .buffer = (&state_capacity_27), .started = (&state_capacity_started_28), }, .lane_2 = .{ .buffer = (&state_capacity_29), .started = (&state_capacity_started_30), }, .lane_3 = .{ .buffer = (&state_capacity_31), .started = (&state_capacity_started_32), }, }));
                        }) else ((state_1).state).origins);
                        const value_18: []const u32 = block_72: {
                            const operand_66 = ((state_1).state).mapping;
                            const operand_68 = block_67: {
                                break :block_67 value_4;
                            };

                            if ((operand_68 >= (operand_66).len)) {
                                return error.IndexOutOfBounds;
                            }

                            const operand_70 = block_69: {
                                break :block_69 value_15;
                            };

                            break :block_72 block_71: {
                                if ((!state_items_started_24)) {
                                    state_items_23 = (try (allocator).dupe(u32, operand_66));

                                    state_items_started_24 = true;
                                }

                                (state_items_23)[@intCast(operand_68)] = operand_70;

                                break :block_71 state_items_23;
                            };
                        };
                        const value_19: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_65: {
                            break :block_65 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = block_64: {
                                const operand_57 = block_58: {
                                    break :block_58 value_18;
                                };
                                const operand_59 = value_16;
                                const operand_60 = value_17;
                                const operand_61 = block_62: {
                                    break :block_62 value_5;
                                };
                                const operand_63 = @as(u64, 0);

                                break :block_64 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .mapping = operand_57, .delta = operand_59, .origins = operand_60, .references = operand_61, .status = operand_63, });
                            }, });
                        };

                        break :block_88 value_19;
                    });

                    break :block_176 value_20;
                });
                const value_22: u64 = (value_21).index;
                const value_23: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_36: {
                    break :block_36 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (block_35: {
                        break :block_35 value_22;
                    } + @as(u64, 1)), .request = (value_21).request, .state = (value_21).state, });
                };

                break :block_200 value_23;
            };
        }

        var state_owned_201: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_201);

        if (state_capacity_started_8) {
            ((state_capacity_7).items).len = ((((state_1).state).delta).children).len;

            state_owned_201 = (try (state_capacity_7).toOwnedSlice(allocator));
        }

        if (state_capacity_started_8) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = state_owned_201, .field_names = (((state_1).state).delta).field_names, .field_types = (((state_1).state).delta).field_types, .first = (((state_1).state).delta).first, .kinds = (((state_1).state).delta).kinds, .labels = (((state_1).state).delta).labels, .names = (((state_1).state).delta).names, .second = (((state_1).state).delta).second, }), .mapping = ((state_1).state).mapping, .origins = ((state_1).state).origins, .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_202: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_202);

        if (state_capacity_started_10) {
            ((state_capacity_9).items).len = ((((state_1).state).delta).field_names).len;

            state_owned_202 = (try (state_capacity_9).toOwnedSlice(allocator));
        }

        if (state_capacity_started_10) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_1).state).delta).children, .field_names = state_owned_202, .field_types = (((state_1).state).delta).field_types, .first = (((state_1).state).delta).first, .kinds = (((state_1).state).delta).kinds, .labels = (((state_1).state).delta).labels, .names = (((state_1).state).delta).names, .second = (((state_1).state).delta).second, }), .mapping = ((state_1).state).mapping, .origins = ((state_1).state).origins, .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_203: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_203);

        if (state_capacity_started_12) {
            ((state_capacity_11).items).len = ((((state_1).state).delta).field_types).len;

            state_owned_203 = (try (state_capacity_11).toOwnedSlice(allocator));
        }

        if (state_capacity_started_12) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_1).state).delta).children, .field_names = (((state_1).state).delta).field_names, .field_types = state_owned_203, .first = (((state_1).state).delta).first, .kinds = (((state_1).state).delta).kinds, .labels = (((state_1).state).delta).labels, .names = (((state_1).state).delta).names, .second = (((state_1).state).delta).second, }), .mapping = ((state_1).state).mapping, .origins = ((state_1).state).origins, .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_204: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_204);

        if (state_capacity_started_14) {
            ((state_capacity_13).items).len = ((((state_1).state).delta).first).len;

            state_owned_204 = (try (state_capacity_13).toOwnedSlice(allocator));
        }

        if (state_capacity_started_14) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_1).state).delta).children, .field_names = (((state_1).state).delta).field_names, .field_types = (((state_1).state).delta).field_types, .first = state_owned_204, .kinds = (((state_1).state).delta).kinds, .labels = (((state_1).state).delta).labels, .names = (((state_1).state).delta).names, .second = (((state_1).state).delta).second, }), .mapping = ((state_1).state).mapping, .origins = ((state_1).state).origins, .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_205: []const u8 = (&[_]u8{});

        errdefer (allocator).free(state_owned_205);

        if (state_capacity_started_16) {
            ((state_capacity_15).items).len = ((((state_1).state).delta).kinds).len;

            state_owned_205 = (try (state_capacity_15).toOwnedSlice(allocator));
        }

        if (state_capacity_started_16) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_1).state).delta).children, .field_names = (((state_1).state).delta).field_names, .field_types = (((state_1).state).delta).field_types, .first = (((state_1).state).delta).first, .kinds = state_owned_205, .labels = (((state_1).state).delta).labels, .names = (((state_1).state).delta).names, .second = (((state_1).state).delta).second, }), .mapping = ((state_1).state).mapping, .origins = ((state_1).state).origins, .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_206: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_206);

        if (state_capacity_started_18) {
            ((state_capacity_17).items).len = ((((state_1).state).delta).labels).len;

            state_owned_206 = (try (state_capacity_17).toOwnedSlice(allocator));
        }

        if (state_capacity_started_18) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_1).state).delta).children, .field_names = (((state_1).state).delta).field_names, .field_types = (((state_1).state).delta).field_types, .first = (((state_1).state).delta).first, .kinds = (((state_1).state).delta).kinds, .labels = state_owned_206, .names = (((state_1).state).delta).names, .second = (((state_1).state).delta).second, }), .mapping = ((state_1).state).mapping, .origins = ((state_1).state).origins, .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_207: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_207);

        if (state_capacity_started_20) {
            ((state_capacity_19).items).len = ((((state_1).state).delta).names).len;

            state_owned_207 = (try (state_capacity_19).toOwnedSlice(allocator));
        }

        if (state_capacity_started_20) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_1).state).delta).children, .field_names = (((state_1).state).delta).field_names, .field_types = (((state_1).state).delta).field_types, .first = (((state_1).state).delta).first, .kinds = (((state_1).state).delta).kinds, .labels = (((state_1).state).delta).labels, .names = state_owned_207, .second = (((state_1).state).delta).second, }), .mapping = ((state_1).state).mapping, .origins = ((state_1).state).origins, .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_208: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_208);

        if (state_capacity_started_22) {
            ((state_capacity_21).items).len = ((((state_1).state).delta).second).len;

            state_owned_208 = (try (state_capacity_21).toOwnedSlice(allocator));
        }

        if (state_capacity_started_22) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_1).state).delta).children, .field_names = (((state_1).state).delta).field_names, .field_types = (((state_1).state).delta).field_types, .first = (((state_1).state).delta).first, .kinds = (((state_1).state).delta).kinds, .labels = (((state_1).state).delta).labels, .names = (((state_1).state).delta).names, .second = state_owned_208, }), .mapping = ((state_1).state).mapping, .origins = ((state_1).state).origins, .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_209: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_209);

        if (state_capacity_started_26) {
            ((state_capacity_25).items).len = ((((state_1).state).origins).ids).len;

            state_owned_209 = (try (state_capacity_25).toOwnedSlice(allocator));
        }

        if (state_capacity_started_26) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_1).state).delta, .mapping = ((state_1).state).mapping, .origins = @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = state_owned_209, .kinds = (((state_1).state).origins).kinds, .members = (((state_1).state).origins).members, .owners = (((state_1).state).origins).owners, }), .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_210: []const u8 = (&[_]u8{});

        errdefer (allocator).free(state_owned_210);

        if (state_capacity_started_28) {
            ((state_capacity_27).items).len = ((((state_1).state).origins).kinds).len;

            state_owned_210 = (try (state_capacity_27).toOwnedSlice(allocator));
        }

        if (state_capacity_started_28) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_1).state).delta, .mapping = ((state_1).state).mapping, .origins = @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((state_1).state).origins).ids, .kinds = state_owned_210, .members = (((state_1).state).origins).members, .owners = (((state_1).state).origins).owners, }), .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_211: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_211);

        if (state_capacity_started_30) {
            ((state_capacity_29).items).len = ((((state_1).state).origins).members).len;

            state_owned_211 = (try (state_capacity_29).toOwnedSlice(allocator));
        }

        if (state_capacity_started_30) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_1).state).delta, .mapping = ((state_1).state).mapping, .origins = @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((state_1).state).origins).ids, .kinds = (((state_1).state).origins).kinds, .members = state_owned_211, .owners = (((state_1).state).origins).owners, }), .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_212: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_212);

        if (state_capacity_started_32) {
            ((state_capacity_31).items).len = ((((state_1).state).origins).owners).len;

            state_owned_212 = (try (state_capacity_31).toOwnedSlice(allocator));
        }

        if (state_capacity_started_32) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_1).state).delta, .mapping = ((state_1).state).mapping, .origins = @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((state_1).state).origins).ids, .kinds = (((state_1).state).origins).kinds, .members = (((state_1).state).origins).members, .owners = state_owned_212, }), .references = ((state_1).state).references, .status = ((state_1).state).status, }), };
        }

        var state_owned_213: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_213);

        if (state_capacity_started_34) {
            ((state_capacity_33).items).len = (((state_1).state).references).len;

            state_owned_213 = (try (state_capacity_33).toOwnedSlice(allocator));
        }

        if (state_capacity_started_34) {
            state_1 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_1).index, .request = (state_1).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_1).state).delta, .mapping = ((state_1).state).mapping, .origins = ((state_1).state).origins, .references = state_owned_213, .status = ((state_1).state).status, }), };
        }

        break :block_232 block_231: {
            break :block_231 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_230: {
                break :block_230 (zx_abi).zx_type_55{ .index = (state_1).index, .request = (if ((((state_1).request).zx_origin != null)) ((state_1).request).zx_origin.? else block_223: {
                    const operand_222 = (try (allocator).create((zx_abi).zx_type_41));

                    (operand_222).* = (zx_abi).zx_type_41{ .base = (if (((((state_1).request).base).zx_origin != null)) (((state_1).request).base).zx_origin.? else block_215: {
                        const operand_214 = (try (allocator).create((zx_abi).zx_type_15));

                        (operand_214).* = (zx_abi).zx_type_15{ .children = (((state_1).request).base).children, .field_names = (((state_1).request).base).field_names, .field_types = (((state_1).request).base).field_types, .first = (((state_1).request).base).first, .kinds = (((state_1).request).base).kinds, .labels = (((state_1).request).base).labels, .names = (((state_1).request).base).names, .second = (((state_1).request).base).second, };

                        break :block_215 @as(*const (zx_abi).zx_type_15, operand_214);
                    }), .base_origins = (if (((((state_1).request).base_origins).zx_origin != null)) (((state_1).request).base_origins).zx_origin.? else block_217: {
                        const operand_216 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_216).* = (zx_abi).zx_type_34{ .ids = (((state_1).request).base_origins).ids, .kinds = (((state_1).request).base_origins).kinds, .members = (((state_1).request).base_origins).members, .owners = (((state_1).request).base_origins).owners, };

                        break :block_217 @as(*const (zx_abi).zx_type_34, operand_216);
                    }), .first = ((state_1).request).first, .origin_indices = ((state_1).request).origin_indices, .origins = (if (((((state_1).request).origins).zx_origin != null)) (((state_1).request).origins).zx_origin.? else block_219: {
                        const operand_218 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_218).* = (zx_abi).zx_type_34{ .ids = (((state_1).request).origins).ids, .kinds = (((state_1).request).origins).kinds, .members = (((state_1).request).origins).members, .owners = (((state_1).request).origins).owners, };

                        break :block_219 @as(*const (zx_abi).zx_type_34, operand_218);
                    }), .source = (if (((((state_1).request).source).zx_origin != null)) (((state_1).request).source).zx_origin.? else block_221: {
                        const operand_220 = (try (allocator).create((zx_abi).zx_type_15));

                        (operand_220).* = (zx_abi).zx_type_15{ .children = (((state_1).request).source).children, .field_names = (((state_1).request).source).field_names, .field_types = (((state_1).request).source).field_types, .first = (((state_1).request).source).first, .kinds = (((state_1).request).source).kinds, .labels = (((state_1).request).source).labels, .names = (((state_1).request).source).names, .second = (((state_1).request).source).second, };

                        break :block_221 @as(*const (zx_abi).zx_type_15, operand_220);
                    }), };

                    break :block_223 @as(*const (zx_abi).zx_type_41, operand_222);
                }), .state = (if ((((state_1).state).zx_origin != null)) ((state_1).state).zx_origin.? else block_229: {
                    const operand_228 = (try (allocator).create((zx_abi).zx_type_42));

                    (operand_228).* = (zx_abi).zx_type_42{ .delta = (if (((((state_1).state).delta).zx_origin != null)) (((state_1).state).delta).zx_origin.? else block_225: {
                        const operand_224 = (try (allocator).create((zx_abi).zx_type_15));

                        (operand_224).* = (zx_abi).zx_type_15{ .children = (((state_1).state).delta).children, .field_names = (((state_1).state).delta).field_names, .field_types = (((state_1).state).delta).field_types, .first = (((state_1).state).delta).first, .kinds = (((state_1).state).delta).kinds, .labels = (((state_1).state).delta).labels, .names = (((state_1).state).delta).names, .second = (((state_1).state).delta).second, };

                        break :block_225 @as(*const (zx_abi).zx_type_15, operand_224);
                    }), .mapping = ((state_1).state).mapping, .origins = (if (((((state_1).state).origins).zx_origin != null)) (((state_1).state).origins).zx_origin.? else block_227: {
                        const operand_226 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_226).* = (zx_abi).zx_type_34{ .ids = (((state_1).state).origins).ids, .kinds = (((state_1).state).origins).kinds, .members = (((state_1).state).origins).members, .owners = (((state_1).state).origins).owners, };

                        break :block_227 @as(*const (zx_abi).zx_type_34, operand_226);
                    }), .references = ((state_1).state).references, .status = ((state_1).state).status, };

                    break :block_229 @as(*const (zx_abi).zx_type_42, operand_228);
                }), };
            });
        };
    }).state;
}

fn function_22_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_43_76edbce8b833ad8fc4a424ad25e03d4bc8082e4a04d7fc427f9bd621935b8ee6) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9 {
    @setRuntimeSafety(true);

    return (block_448: {
        const operand_238 = block_237: {
            const operand_234 = (in).request;
            const operand_235 = (in).state;
            const operand_236 = ((in).request).first;

            break :block_237 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .request = operand_234, .state = operand_235, .index = operand_236, });
        };

        var state_capacity_240: (std).ArrayList(u32) = .empty;

        var state_capacity_started_241 = false;

        defer (state_capacity_240).deinit(allocator);

        var state_capacity_242: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_243 = false;

        defer (state_capacity_242).deinit(allocator);

        var state_capacity_244: (std).ArrayList(u32) = .empty;

        var state_capacity_started_245 = false;

        defer (state_capacity_244).deinit(allocator);

        var state_capacity_246: (std).ArrayList(u32) = .empty;

        var state_capacity_started_247 = false;

        defer (state_capacity_246).deinit(allocator);

        var state_capacity_248: (std).ArrayList(u8) = .empty;

        var state_capacity_started_249 = false;

        defer (state_capacity_248).deinit(allocator);

        var state_capacity_250: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_251 = false;

        defer (state_capacity_250).deinit(allocator);

        var state_capacity_252: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_253 = false;

        defer (state_capacity_252).deinit(allocator);

        var state_capacity_254: (std).ArrayList(u32) = .empty;

        var state_capacity_started_255 = false;

        defer (state_capacity_254).deinit(allocator);

        var state_items_256: []u32 = undefined;

        var state_items_started_257 = false;

        var state_capacity_258: (std).ArrayList(u32) = .empty;

        var state_capacity_started_259 = false;

        defer (state_capacity_258).deinit(allocator);

        var state_capacity_260: (std).ArrayList(u8) = .empty;

        var state_capacity_started_261 = false;

        defer (state_capacity_260).deinit(allocator);

        var state_capacity_262: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_263 = false;

        defer (state_capacity_262).deinit(allocator);

        var state_capacity_264: (std).ArrayList([]const u8) = .empty;

        var state_capacity_started_265 = false;

        defer (state_capacity_264).deinit(allocator);

        var state_capacity_266: (std).ArrayList(u32) = .empty;

        var state_capacity_started_267 = false;

        defer (state_capacity_266).deinit(allocator);

        var state_233: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = operand_238;

        var state_changed_239 = false;

        while (((((state_233).state).status == @as(u64, 0)) and ((state_233).index < @as(u64, ((((state_233).request).source).kinds).len)))) {
            state_233 = block_433: {
                const value_3: (zx_abi).value_zx_type_41_3540ff82cd7401f2790fb0b97d3e60eb4ca97c3dede3a7b74038ab46d2dcac57 = (state_233).request;
                const value_4: u64 = (state_233).index;
                const value_5: []const u32 = block_432: {
                    const operand_429 = block_428: {
                        const operand_423 = (value_3).source;
                        const operand_424 = block_425: {
                            break :block_425 value_4;
                        };
                        const operand_426 = ((state_233).state).mapping;
                        const operand_427 = ((state_233).state).references;

                        break :block_428 @as((zx_abi).value_zx_type_38_b007dd1e4c63d95a3155329e1f60b16a22582c9bf6a4aa0bbdeb58811f8f72c5, (zx_abi).value_zx_type_38_b007dd1e4c63d95a3155329e1f60b16a22582c9bf6a4aa0bbdeb58811f8f72c5{ .source = operand_423, .index = operand_424, .mapping = operand_426, .references = operand_427, });
                    };

                    var state_borrow_430: (zx_abi).zx_type_15 = undefined;

                    state_borrow_430 = (zx_abi).zx_type_15{ .children = ((operand_429).source).children, .field_names = ((operand_429).source).field_names, .field_types = ((operand_429).source).field_types, .first = ((operand_429).source).first, .kinds = ((operand_429).source).kinds, .labels = ((operand_429).source).labels, .names = ((operand_429).source).names, .second = ((operand_429).source).second, };

                    var state_borrow_431: (zx_abi).zx_type_38 = undefined;

                    state_borrow_431 = (zx_abi).zx_type_38{ .index = (operand_429).index, .mapping = (operand_429).mapping, .references = (operand_429).references, .source = (((operand_429).source).zx_origin orelse (&state_borrow_430)), };

                    break :block_432 (try function_19_buffered(allocator, ((operand_429).zx_origin orelse (&state_borrow_431)), .{ .lane_0 = .{ .buffer = (&state_capacity_266), .started = (&state_capacity_started_267), }, }));
                };
                const value_6: (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = block_422: {
                    break :block_422 (try function_10_value(allocator, block_421: {
                        const operand_416 = (value_3).source;
                        const operand_417 = block_418: {
                            break :block_418 value_4;
                        };
                        const operand_419 = block_420: {
                            break :block_420 value_5;
                        };

                        break :block_421 @as((zx_abi).value_zx_type_28_bc0beef4baed6cbec65527f285ce2af317364f06c28bd549a5782c80f0e63a13, (zx_abi).value_zx_type_28_bc0beef4baed6cbec65527f285ce2af317364f06c28bd549a5782c80f0e63a13{ .source = operand_416, .index = operand_417, .references = operand_419, });
                    }));
                };
                const value_7: (zx_abi).zx_type_11 = (try function_5(allocator, block_415: {
                    const operand_413 = ((value_3).source).kinds;
                    const operand_414 = block_412: {
                        break :block_412 value_4;
                    };

                    if ((operand_414 >= (operand_413).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_415 (operand_413)[@intCast(operand_414)];
                }));
                const value_8: bool = ((block_410: {
                    break :block_410 value_7;
                } == @as((zx_abi).zx_type_11, .Enumeration)) or (block_411: {
                    break :block_411 value_7;
                } == @as((zx_abi).zx_type_11, .NativeReference)));
                const value_21: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = (if ((block_270: {
                    break :block_270 value_8;
                } and (block_274: {
                    const operand_272 = (value_3).origin_indices;
                    const operand_273 = block_271: {
                        break :block_271 value_4;
                    };

                    if ((operand_273 >= (operand_272).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_274 (operand_272)[@intCast(operand_273)];
                } == @as(u64, 0)))) block_281: {
                    const value_9: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_280: {
                        break :block_280 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = block_279: {
                            const operand_275 = (state_233).state;
                            const operand_276 = block_277: {
                                break :block_277 value_5;
                            };
                            const operand_278 = @as(u64, 1);

                            break :block_279 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_275).delta, .mapping = (operand_275).mapping, .origins = (operand_275).origins, .references = operand_276, .status = operand_278, });
                        }, });
                    };

                    break :block_281 value_9;
                } else block_409: {
                    const value_10: u64 = (if (block_404: {
                        break :block_404 value_8;
                    }) (block_408: {
                        const operand_406 = (value_3).origin_indices;
                        const operand_407 = block_405: {
                            break :block_405 value_4;
                        };

                        if ((operand_407 >= (operand_406).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_408 (operand_406)[@intCast(operand_407)];
                    } - @as(u64, 1)) else @as(u64, 0));
                    const value_11: (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (if (block_383: {
                        break :block_383 value_8;
                    }) block_399: {
                        const operand_384 = block_388: {
                            const operand_386 = ((value_3).origins).kinds;
                            const operand_387 = block_385: {
                                break :block_385 value_10;
                            };

                            if ((operand_387 >= (operand_386).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_388 (operand_386)[@intCast(operand_387)];
                        };
                        const operand_389 = block_393: {
                            const operand_391 = ((value_3).origins).owners;
                            const operand_392 = block_390: {
                                break :block_390 value_10;
                            };

                            if ((operand_392 >= (operand_391).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_393 (operand_391)[@intCast(operand_392)];
                        };
                        const operand_394 = block_398: {
                            const operand_396 = ((value_3).origins).members;
                            const operand_397 = block_395: {
                                break :block_395 value_10;
                            };

                            if ((operand_397 >= (operand_396).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_398 (operand_396)[@intCast(operand_397)];
                        };

                        break :block_399 @as((zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = operand_384, .owner = operand_389, .member = operand_394, });
                    } else block_403: {
                        const operand_400 = @as(u8, 0);
                        const operand_401 = @as([]const u8, "");
                        const operand_402 = @as([]const u8, "");

                        break :block_403 @as((zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = operand_400, .owner = operand_401, .member = operand_402, });
                    });
                    const value_12: (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9 = block_382: {
                        const operand_380 = (value_3).base;
                        const operand_381 = ((state_233).state).delta;

                        break :block_382 @as((zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9, (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = operand_380, .delta = operand_381, });
                    };
                    const value_13: u64 = (if (block_322: {
                        break :block_322 value_8;
                    }) block_361: {
                        const operand_323 = value_12;

                        var state_borrow_324: (zx_abi).zx_type_15 = undefined;

                        state_borrow_324 = (zx_abi).zx_type_15{ .children = ((operand_323).base).children, .field_names = ((operand_323).base).field_names, .field_types = ((operand_323).base).field_types, .first = ((operand_323).base).first, .kinds = ((operand_323).base).kinds, .labels = ((operand_323).base).labels, .names = ((operand_323).base).names, .second = ((operand_323).base).second, };

                        var state_borrow_325: (zx_abi).zx_type_15 = undefined;

                        state_borrow_325 = (zx_abi).zx_type_15{ .children = ((operand_323).delta).children, .field_names = ((operand_323).delta).field_names, .field_types = ((operand_323).delta).field_types, .first = ((operand_323).delta).first, .kinds = ((operand_323).delta).kinds, .labels = ((operand_323).delta).labels, .names = ((operand_323).delta).names, .second = ((operand_323).delta).second, };

                        var state_borrow_326: (zx_abi).zx_type_16 = undefined;

                        state_borrow_326 = (zx_abi).zx_type_16{ .base = (((operand_323).base).zx_origin orelse (&state_borrow_324)), .delta = (((operand_323).delta).zx_origin orelse (&state_borrow_325)), };

                        const operand_327 = ((operand_323).zx_origin orelse (&state_borrow_326));
                        const operand_328 = (value_3).base_origins;

                        var state_borrow_329: (zx_abi).zx_type_34 = undefined;

                        state_borrow_329 = (zx_abi).zx_type_34{ .ids = (operand_328).ids, .kinds = (operand_328).kinds, .members = (operand_328).members, .owners = (operand_328).owners, };

                        const operand_330 = ((operand_328).zx_origin orelse (&state_borrow_329));
                        const operand_331 = ((state_233).state).origins;

                        var state_borrow_332: (zx_abi).zx_type_34 = undefined;

                        state_borrow_332 = (zx_abi).zx_type_34{ .ids = (operand_331).ids, .kinds = (operand_331).kinds, .members = (operand_331).members, .owners = (operand_331).owners, };

                        const operand_333 = ((operand_331).zx_origin orelse (&state_borrow_332));
                        const operand_334 = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (operand_330).ids, .kinds = (operand_330).kinds, .members = (operand_330).members, .owners = (operand_330).owners, .zx_origin = operand_330, };

                        var state_borrow_335: (zx_abi).zx_type_34 = undefined;

                        state_borrow_335 = (zx_abi).zx_type_34{ .ids = (operand_334).ids, .kinds = (operand_334).kinds, .members = (operand_334).members, .owners = (operand_334).owners, };

                        const operand_336 = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (operand_333).ids, .kinds = (operand_333).kinds, .members = (operand_333).members, .owners = (operand_333).owners, .zx_origin = operand_333, };

                        var state_borrow_337: (zx_abi).zx_type_34 = undefined;

                        state_borrow_337 = (zx_abi).zx_type_34{ .ids = (operand_336).ids, .kinds = (operand_336).kinds, .members = (operand_336).members, .owners = (operand_336).owners, };

                        const operand_338 = (zx_abi).zx_type_35{ .base = ((operand_334).zx_origin orelse (&state_borrow_335)), .delta = ((operand_336).zx_origin orelse (&state_borrow_337)), };
                        const operand_339 = (&operand_338);
                        const operand_340 = value_11;

                        var state_borrow_341: (zx_abi).zx_type_33 = undefined;

                        state_borrow_341 = (zx_abi).zx_type_33{ .kind = (operand_340).kind, .member = (operand_340).member, .owner = (operand_340).owner, };

                        const operand_342 = ((operand_340).zx_origin orelse (&state_borrow_341));
                        const operand_343 = value_6;

                        var state_borrow_344: (zx_abi).zx_type_17 = undefined;

                        state_borrow_344 = (zx_abi).zx_type_17{ .names = ((operand_343).fields).names, .types = ((operand_343).fields).types, };

                        var state_borrow_345: (zx_abi).zx_type_24 = undefined;

                        state_borrow_345 = (zx_abi).zx_type_24{ .children = (operand_343).children, .fields = (((operand_343).fields).zx_origin orelse (&state_borrow_344)), .first = (operand_343).first, .kind = (operand_343).kind, .label = (operand_343).label, .names = (operand_343).names, .second = (operand_343).second, };

                        const operand_346 = ((operand_343).zx_origin orelse (&state_borrow_345));
                        const operand_347 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_327).base).children, .field_names = ((operand_327).base).field_names, .field_types = ((operand_327).base).field_types, .first = ((operand_327).base).first, .kinds = ((operand_327).base).kinds, .labels = ((operand_327).base).labels, .names = ((operand_327).base).names, .second = ((operand_327).base).second, .zx_origin = (operand_327).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_327).delta).children, .field_names = ((operand_327).delta).field_names, .field_types = ((operand_327).delta).field_types, .first = ((operand_327).delta).first, .kinds = ((operand_327).delta).kinds, .labels = ((operand_327).delta).labels, .names = ((operand_327).delta).names, .second = ((operand_327).delta).second, .zx_origin = (operand_327).delta, }, .zx_origin = operand_327, };

                        var state_borrow_348: (zx_abi).zx_type_15 = undefined;

                        state_borrow_348 = (zx_abi).zx_type_15{ .children = ((operand_347).base).children, .field_names = ((operand_347).base).field_names, .field_types = ((operand_347).base).field_types, .first = ((operand_347).base).first, .kinds = ((operand_347).base).kinds, .labels = ((operand_347).base).labels, .names = ((operand_347).base).names, .second = ((operand_347).base).second, };

                        var state_borrow_349: (zx_abi).zx_type_15 = undefined;

                        state_borrow_349 = (zx_abi).zx_type_15{ .children = ((operand_347).delta).children, .field_names = ((operand_347).delta).field_names, .field_types = ((operand_347).delta).field_types, .first = ((operand_347).delta).first, .kinds = ((operand_347).delta).kinds, .labels = ((operand_347).delta).labels, .names = ((operand_347).delta).names, .second = ((operand_347).delta).second, };

                        var state_borrow_350: (zx_abi).zx_type_16 = undefined;

                        state_borrow_350 = (zx_abi).zx_type_16{ .base = (((operand_347).base).zx_origin orelse (&state_borrow_348)), .delta = (((operand_347).delta).zx_origin orelse (&state_borrow_349)), };

                        const operand_351 = (zx_abi).value_zx_type_35_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53{ .base = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = ((operand_339).base).ids, .kinds = ((operand_339).base).kinds, .members = ((operand_339).base).members, .owners = ((operand_339).base).owners, .zx_origin = (operand_339).base, }, .delta = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = ((operand_339).delta).ids, .kinds = ((operand_339).delta).kinds, .members = ((operand_339).delta).members, .owners = ((operand_339).delta).owners, .zx_origin = (operand_339).delta, }, .zx_origin = operand_339, };

                        var state_borrow_352: (zx_abi).zx_type_34 = undefined;

                        state_borrow_352 = (zx_abi).zx_type_34{ .ids = ((operand_351).base).ids, .kinds = ((operand_351).base).kinds, .members = ((operand_351).base).members, .owners = ((operand_351).base).owners, };

                        var state_borrow_353: (zx_abi).zx_type_34 = undefined;

                        state_borrow_353 = (zx_abi).zx_type_34{ .ids = ((operand_351).delta).ids, .kinds = ((operand_351).delta).kinds, .members = ((operand_351).delta).members, .owners = ((operand_351).delta).owners, };

                        var state_borrow_354: (zx_abi).zx_type_35 = undefined;

                        state_borrow_354 = (zx_abi).zx_type_35{ .base = (((operand_351).base).zx_origin orelse (&state_borrow_352)), .delta = (((operand_351).delta).zx_origin orelse (&state_borrow_353)), };

                        const operand_355 = (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = (operand_342).kind, .member = (operand_342).member, .owner = (operand_342).owner, .zx_origin = operand_342, };

                        var state_borrow_356: (zx_abi).zx_type_33 = undefined;

                        state_borrow_356 = (zx_abi).zx_type_33{ .kind = (operand_355).kind, .member = (operand_355).member, .owner = (operand_355).owner, };

                        const operand_357 = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_346).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_346).fields).names, .types = ((operand_346).fields).types, .zx_origin = (operand_346).fields, }, .first = (operand_346).first, .kind = (operand_346).kind, .label = (operand_346).label, .names = (operand_346).names, .second = (operand_346).second, .zx_origin = operand_346, };

                        var state_borrow_358: (zx_abi).zx_type_17 = undefined;

                        state_borrow_358 = (zx_abi).zx_type_17{ .names = ((operand_357).fields).names, .types = ((operand_357).fields).types, };

                        var state_borrow_359: (zx_abi).zx_type_24 = undefined;

                        state_borrow_359 = (zx_abi).zx_type_24{ .children = (operand_357).children, .fields = (((operand_357).fields).zx_origin orelse (&state_borrow_358)), .first = (operand_357).first, .kind = (operand_357).kind, .label = (operand_357).label, .names = (operand_357).names, .second = (operand_357).second, };

                        const operand_360 = (zx_abi).zx_type_36{ .tables = ((operand_347).zx_origin orelse (&state_borrow_350)), .origins = ((operand_351).zx_origin orelse (&state_borrow_354)), .origin = ((operand_355).zx_origin orelse (&state_borrow_356)), .candidate = ((operand_357).zx_origin orelse (&state_borrow_359)), };

                        break :block_361 (try function_17(allocator, (&operand_360)));
                    } else block_379: {
                        const operand_362 = value_12;

                        var state_borrow_363: (zx_abi).zx_type_15 = undefined;

                        state_borrow_363 = (zx_abi).zx_type_15{ .children = ((operand_362).base).children, .field_names = ((operand_362).base).field_names, .field_types = ((operand_362).base).field_types, .first = ((operand_362).base).first, .kinds = ((operand_362).base).kinds, .labels = ((operand_362).base).labels, .names = ((operand_362).base).names, .second = ((operand_362).base).second, };

                        var state_borrow_364: (zx_abi).zx_type_15 = undefined;

                        state_borrow_364 = (zx_abi).zx_type_15{ .children = ((operand_362).delta).children, .field_names = ((operand_362).delta).field_names, .field_types = ((operand_362).delta).field_types, .first = ((operand_362).delta).first, .kinds = ((operand_362).delta).kinds, .labels = ((operand_362).delta).labels, .names = ((operand_362).delta).names, .second = ((operand_362).delta).second, };

                        var state_borrow_365: (zx_abi).zx_type_16 = undefined;

                        state_borrow_365 = (zx_abi).zx_type_16{ .base = (((operand_362).base).zx_origin orelse (&state_borrow_363)), .delta = (((operand_362).delta).zx_origin orelse (&state_borrow_364)), };

                        const operand_366 = ((operand_362).zx_origin orelse (&state_borrow_365));
                        const operand_367 = value_6;

                        var state_borrow_368: (zx_abi).zx_type_17 = undefined;

                        state_borrow_368 = (zx_abi).zx_type_17{ .names = ((operand_367).fields).names, .types = ((operand_367).fields).types, };

                        var state_borrow_369: (zx_abi).zx_type_24 = undefined;

                        state_borrow_369 = (zx_abi).zx_type_24{ .children = (operand_367).children, .fields = (((operand_367).fields).zx_origin orelse (&state_borrow_368)), .first = (operand_367).first, .kind = (operand_367).kind, .label = (operand_367).label, .names = (operand_367).names, .second = (operand_367).second, };

                        const operand_370 = ((operand_367).zx_origin orelse (&state_borrow_369));
                        const operand_371 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_366).base).children, .field_names = ((operand_366).base).field_names, .field_types = ((operand_366).base).field_types, .first = ((operand_366).base).first, .kinds = ((operand_366).base).kinds, .labels = ((operand_366).base).labels, .names = ((operand_366).base).names, .second = ((operand_366).base).second, .zx_origin = (operand_366).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_366).delta).children, .field_names = ((operand_366).delta).field_names, .field_types = ((operand_366).delta).field_types, .first = ((operand_366).delta).first, .kinds = ((operand_366).delta).kinds, .labels = ((operand_366).delta).labels, .names = ((operand_366).delta).names, .second = ((operand_366).delta).second, .zx_origin = (operand_366).delta, }, .zx_origin = operand_366, };

                        var state_borrow_372: (zx_abi).zx_type_15 = undefined;

                        state_borrow_372 = (zx_abi).zx_type_15{ .children = ((operand_371).base).children, .field_names = ((operand_371).base).field_names, .field_types = ((operand_371).base).field_types, .first = ((operand_371).base).first, .kinds = ((operand_371).base).kinds, .labels = ((operand_371).base).labels, .names = ((operand_371).base).names, .second = ((operand_371).base).second, };

                        var state_borrow_373: (zx_abi).zx_type_15 = undefined;

                        state_borrow_373 = (zx_abi).zx_type_15{ .children = ((operand_371).delta).children, .field_names = ((operand_371).delta).field_names, .field_types = ((operand_371).delta).field_types, .first = ((operand_371).delta).first, .kinds = ((operand_371).delta).kinds, .labels = ((operand_371).delta).labels, .names = ((operand_371).delta).names, .second = ((operand_371).delta).second, };

                        var state_borrow_374: (zx_abi).zx_type_16 = undefined;

                        state_borrow_374 = (zx_abi).zx_type_16{ .base = (((operand_371).base).zx_origin orelse (&state_borrow_372)), .delta = (((operand_371).delta).zx_origin orelse (&state_borrow_373)), };

                        const operand_375 = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_370).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_370).fields).names, .types = ((operand_370).fields).types, .zx_origin = (operand_370).fields, }, .first = (operand_370).first, .kind = (operand_370).kind, .label = (operand_370).label, .names = (operand_370).names, .second = (operand_370).second, .zx_origin = operand_370, };

                        var state_borrow_376: (zx_abi).zx_type_17 = undefined;

                        state_borrow_376 = (zx_abi).zx_type_17{ .names = ((operand_375).fields).names, .types = ((operand_375).fields).types, };

                        var state_borrow_377: (zx_abi).zx_type_24 = undefined;

                        state_borrow_377 = (zx_abi).zx_type_24{ .children = (operand_375).children, .fields = (((operand_375).fields).zx_origin orelse (&state_borrow_376)), .first = (operand_375).first, .kind = (operand_375).kind, .label = (operand_375).label, .names = (operand_375).names, .second = (operand_375).second, };

                        const operand_378 = (zx_abi).zx_type_39{ .tables = ((operand_371).zx_origin orelse (&state_borrow_374)), .candidate = ((operand_375).zx_origin orelse (&state_borrow_377)), };

                        break :block_379 (try function_21(allocator, (&operand_378)));
                    });
                    const value_20: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = (if ((block_282: {
                        break :block_282 value_13;
                    } == @as(u64, 1))) block_289: {
                        const value_14: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_288: {
                            break :block_288 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = block_287: {
                                const operand_283 = (state_233).state;
                                const operand_284 = block_285: {
                                    break :block_285 value_5;
                                };
                                const operand_286 = @as(u64, 2);

                                break :block_287 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_283).delta, .mapping = (operand_283).mapping, .origins = (operand_283).origins, .references = operand_284, .status = operand_286, });
                            }, });
                        };

                        break :block_289 value_14;
                    } else block_321: {
                        const value_15: u32 = (if ((block_319: {
                            break :block_319 value_13;
                        } == @as(u64, 0))) (try function_2(allocator, (@as(u64, (((value_3).base).kinds).len) + @as(u64, ((((state_233).state).delta).kinds).len)))) else (try function_2(allocator, (block_320: {
                            break :block_320 value_13;
                        } - @as(u64, 2)))));
                        const value_16: (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = (if ((block_314: {
                            break :block_314 value_13;
                        } == @as(u64, 0))) @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, block_318: {
                            break :block_318 (try function_9_buffered(allocator, block_317: {
                                const operand_315 = ((state_233).state).delta;
                                const operand_316 = value_6;

                                break :block_317 @as((zx_abi).value_zx_type_27_eb83b36bd9eb840e506cc8c01a38c13a9cdff0b6a9636a9eecf085d3c539269b, (zx_abi).value_zx_type_27_eb83b36bd9eb840e506cc8c01a38c13a9cdff0b6a9636a9eecf085d3c539269b{ .delta = operand_315, .candidate = operand_316, });
                            }, .{ .lane_0 = .{ .buffer = (&state_capacity_240), .started = (&state_capacity_started_241), }, .lane_1 = .{ .buffer = (&state_capacity_242), .started = (&state_capacity_started_243), }, .lane_2 = .{ .buffer = (&state_capacity_244), .started = (&state_capacity_started_245), }, .lane_3 = .{ .buffer = (&state_capacity_246), .started = (&state_capacity_started_247), }, .lane_4 = .{ .buffer = (&state_capacity_248), .started = (&state_capacity_started_249), }, .lane_5 = .{ .buffer = (&state_capacity_250), .started = (&state_capacity_started_251), }, .lane_6 = .{ .buffer = (&state_capacity_252), .started = (&state_capacity_started_253), }, .lane_7 = .{ .buffer = (&state_capacity_254), .started = (&state_capacity_started_255), }, }));
                        }) else ((state_233).state).delta);
                        const value_17: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if (((block_306: {
                            break :block_306 value_13;
                        } == @as(u64, 0)) and block_307: {
                            break :block_307 value_8;
                        })) @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, block_313: {
                            break :block_313 (try function_18_buffered(allocator, block_312: {
                                const operand_308 = ((state_233).state).origins;
                                const operand_309 = value_11;
                                const operand_310 = block_311: {
                                    break :block_311 value_15;
                                };

                                break :block_312 @as((zx_abi).value_zx_type_37_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39, (zx_abi).value_zx_type_37_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39{ .bindings = operand_308, .origin = operand_309, .id = operand_310, });
                            }, .{ .lane_0 = .{ .buffer = (&state_capacity_258), .started = (&state_capacity_started_259), }, .lane_1 = .{ .buffer = (&state_capacity_260), .started = (&state_capacity_started_261), }, .lane_2 = .{ .buffer = (&state_capacity_262), .started = (&state_capacity_started_263), }, .lane_3 = .{ .buffer = (&state_capacity_264), .started = (&state_capacity_started_265), }, }));
                        }) else ((state_233).state).origins);
                        const value_18: []const u32 = block_305: {
                            const operand_299 = ((state_233).state).mapping;
                            const operand_301 = block_300: {
                                break :block_300 value_4;
                            };

                            if ((operand_301 >= (operand_299).len)) {
                                return error.IndexOutOfBounds;
                            }

                            const operand_303 = block_302: {
                                break :block_302 value_15;
                            };

                            break :block_305 block_304: {
                                if ((!state_items_started_257)) {
                                    state_items_256 = (try (allocator).dupe(u32, operand_299));

                                    state_items_started_257 = true;
                                }

                                (state_items_256)[@intCast(operand_301)] = operand_303;

                                break :block_304 state_items_256;
                            };
                        };
                        const value_19: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_298: {
                            break :block_298 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = block_297: {
                                const operand_290 = block_291: {
                                    break :block_291 value_18;
                                };
                                const operand_292 = value_16;
                                const operand_293 = value_17;
                                const operand_294 = block_295: {
                                    break :block_295 value_5;
                                };
                                const operand_296 = @as(u64, 0);

                                break :block_297 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .mapping = operand_290, .delta = operand_292, .origins = operand_293, .references = operand_294, .status = operand_296, });
                            }, });
                        };

                        break :block_321 value_19;
                    });

                    break :block_409 value_20;
                });
                const value_22: u64 = (value_21).index;
                const value_23: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_269: {
                    break :block_269 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (block_268: {
                        break :block_268 value_22;
                    } + @as(u64, 1)), .request = (value_21).request, .state = (value_21).state, });
                };

                break :block_433 value_23;
            };

            state_changed_239 = true;
        }

        var state_owned_434: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_434);

        if (state_capacity_started_241) {
            ((state_capacity_240).items).len = ((((state_233).state).delta).children).len;

            state_owned_434 = (try (state_capacity_240).toOwnedSlice(allocator));
        }

        if (state_capacity_started_241) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = state_owned_434, .field_names = (((state_233).state).delta).field_names, .field_types = (((state_233).state).delta).field_types, .first = (((state_233).state).delta).first, .kinds = (((state_233).state).delta).kinds, .labels = (((state_233).state).delta).labels, .names = (((state_233).state).delta).names, .second = (((state_233).state).delta).second, }), .mapping = ((state_233).state).mapping, .origins = ((state_233).state).origins, .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_435: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_435);

        if (state_capacity_started_243) {
            ((state_capacity_242).items).len = ((((state_233).state).delta).field_names).len;

            state_owned_435 = (try (state_capacity_242).toOwnedSlice(allocator));
        }

        if (state_capacity_started_243) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_233).state).delta).children, .field_names = state_owned_435, .field_types = (((state_233).state).delta).field_types, .first = (((state_233).state).delta).first, .kinds = (((state_233).state).delta).kinds, .labels = (((state_233).state).delta).labels, .names = (((state_233).state).delta).names, .second = (((state_233).state).delta).second, }), .mapping = ((state_233).state).mapping, .origins = ((state_233).state).origins, .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_436: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_436);

        if (state_capacity_started_245) {
            ((state_capacity_244).items).len = ((((state_233).state).delta).field_types).len;

            state_owned_436 = (try (state_capacity_244).toOwnedSlice(allocator));
        }

        if (state_capacity_started_245) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_233).state).delta).children, .field_names = (((state_233).state).delta).field_names, .field_types = state_owned_436, .first = (((state_233).state).delta).first, .kinds = (((state_233).state).delta).kinds, .labels = (((state_233).state).delta).labels, .names = (((state_233).state).delta).names, .second = (((state_233).state).delta).second, }), .mapping = ((state_233).state).mapping, .origins = ((state_233).state).origins, .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_437: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_437);

        if (state_capacity_started_247) {
            ((state_capacity_246).items).len = ((((state_233).state).delta).first).len;

            state_owned_437 = (try (state_capacity_246).toOwnedSlice(allocator));
        }

        if (state_capacity_started_247) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_233).state).delta).children, .field_names = (((state_233).state).delta).field_names, .field_types = (((state_233).state).delta).field_types, .first = state_owned_437, .kinds = (((state_233).state).delta).kinds, .labels = (((state_233).state).delta).labels, .names = (((state_233).state).delta).names, .second = (((state_233).state).delta).second, }), .mapping = ((state_233).state).mapping, .origins = ((state_233).state).origins, .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_438: []const u8 = (&[_]u8{});

        errdefer (allocator).free(state_owned_438);

        if (state_capacity_started_249) {
            ((state_capacity_248).items).len = ((((state_233).state).delta).kinds).len;

            state_owned_438 = (try (state_capacity_248).toOwnedSlice(allocator));
        }

        if (state_capacity_started_249) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_233).state).delta).children, .field_names = (((state_233).state).delta).field_names, .field_types = (((state_233).state).delta).field_types, .first = (((state_233).state).delta).first, .kinds = state_owned_438, .labels = (((state_233).state).delta).labels, .names = (((state_233).state).delta).names, .second = (((state_233).state).delta).second, }), .mapping = ((state_233).state).mapping, .origins = ((state_233).state).origins, .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_439: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_439);

        if (state_capacity_started_251) {
            ((state_capacity_250).items).len = ((((state_233).state).delta).labels).len;

            state_owned_439 = (try (state_capacity_250).toOwnedSlice(allocator));
        }

        if (state_capacity_started_251) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_233).state).delta).children, .field_names = (((state_233).state).delta).field_names, .field_types = (((state_233).state).delta).field_types, .first = (((state_233).state).delta).first, .kinds = (((state_233).state).delta).kinds, .labels = state_owned_439, .names = (((state_233).state).delta).names, .second = (((state_233).state).delta).second, }), .mapping = ((state_233).state).mapping, .origins = ((state_233).state).origins, .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_440: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_440);

        if (state_capacity_started_253) {
            ((state_capacity_252).items).len = ((((state_233).state).delta).names).len;

            state_owned_440 = (try (state_capacity_252).toOwnedSlice(allocator));
        }

        if (state_capacity_started_253) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_233).state).delta).children, .field_names = (((state_233).state).delta).field_names, .field_types = (((state_233).state).delta).field_types, .first = (((state_233).state).delta).first, .kinds = (((state_233).state).delta).kinds, .labels = (((state_233).state).delta).labels, .names = state_owned_440, .second = (((state_233).state).delta).second, }), .mapping = ((state_233).state).mapping, .origins = ((state_233).state).origins, .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_441: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_441);

        if (state_capacity_started_255) {
            ((state_capacity_254).items).len = ((((state_233).state).delta).second).len;

            state_owned_441 = (try (state_capacity_254).toOwnedSlice(allocator));
        }

        if (state_capacity_started_255) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((state_233).state).delta).children, .field_names = (((state_233).state).delta).field_names, .field_types = (((state_233).state).delta).field_types, .first = (((state_233).state).delta).first, .kinds = (((state_233).state).delta).kinds, .labels = (((state_233).state).delta).labels, .names = (((state_233).state).delta).names, .second = state_owned_441, }), .mapping = ((state_233).state).mapping, .origins = ((state_233).state).origins, .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_442: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_442);

        if (state_capacity_started_259) {
            ((state_capacity_258).items).len = ((((state_233).state).origins).ids).len;

            state_owned_442 = (try (state_capacity_258).toOwnedSlice(allocator));
        }

        if (state_capacity_started_259) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_233).state).delta, .mapping = ((state_233).state).mapping, .origins = @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = state_owned_442, .kinds = (((state_233).state).origins).kinds, .members = (((state_233).state).origins).members, .owners = (((state_233).state).origins).owners, }), .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_443: []const u8 = (&[_]u8{});

        errdefer (allocator).free(state_owned_443);

        if (state_capacity_started_261) {
            ((state_capacity_260).items).len = ((((state_233).state).origins).kinds).len;

            state_owned_443 = (try (state_capacity_260).toOwnedSlice(allocator));
        }

        if (state_capacity_started_261) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_233).state).delta, .mapping = ((state_233).state).mapping, .origins = @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((state_233).state).origins).ids, .kinds = state_owned_443, .members = (((state_233).state).origins).members, .owners = (((state_233).state).origins).owners, }), .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_444: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_444);

        if (state_capacity_started_263) {
            ((state_capacity_262).items).len = ((((state_233).state).origins).members).len;

            state_owned_444 = (try (state_capacity_262).toOwnedSlice(allocator));
        }

        if (state_capacity_started_263) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_233).state).delta, .mapping = ((state_233).state).mapping, .origins = @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((state_233).state).origins).ids, .kinds = (((state_233).state).origins).kinds, .members = state_owned_444, .owners = (((state_233).state).origins).owners, }), .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_445: []const []const u8 = (&[_][]const u8{});

        errdefer (allocator).free(state_owned_445);

        if (state_capacity_started_265) {
            ((state_capacity_264).items).len = ((((state_233).state).origins).owners).len;

            state_owned_445 = (try (state_capacity_264).toOwnedSlice(allocator));
        }

        if (state_capacity_started_265) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_233).state).delta, .mapping = ((state_233).state).mapping, .origins = @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((state_233).state).origins).ids, .kinds = (((state_233).state).origins).kinds, .members = (((state_233).state).origins).members, .owners = state_owned_445, }), .references = ((state_233).state).references, .status = ((state_233).state).status, }), };
        }

        var state_owned_446: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_446);

        if (state_capacity_started_267) {
            ((state_capacity_266).items).len = (((state_233).state).references).len;

            state_owned_446 = (try (state_capacity_266).toOwnedSlice(allocator));
        }

        if (state_capacity_started_267) {
            state_233 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_233).index, .request = (state_233).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_233).state).delta, .mapping = ((state_233).state).mapping, .origins = ((state_233).state).origins, .references = state_owned_446, .status = ((state_233).state).status, }), };
        }

        break :block_448 (if (state_changed_239) state_233 else operand_238);
    }).state;
}

fn function_22_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_43_76edbce8b833ad8fc4a424ad25e03d4bc8082e4a04d7fc427f9bd621935b8ee6, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u8),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_8: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_9: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_10: ?struct {
        buffer: *(std).ArrayList(u8),
        started: *bool,
    },
    lane_11: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_12: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_13: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9 {
    @setRuntimeSafety(true);

    return (block_627: {
        const operand_454 = block_453: {
            const operand_450 = (in).request;
            const operand_451 = (in).state;
            const operand_452 = ((in).request).first;

            break :block_453 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .request = operand_450, .state = operand_451, .index = operand_452, });
        };

        var state_capacity_456: (std).ArrayList(u32) = .empty;

        var state_capacity_started_457 = false;

        defer (state_capacity_456).deinit(allocator);

        var state_449: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = operand_454;

        var state_changed_455 = false;

        while (((((state_449).state).status == @as(u64, 0)) and ((state_449).index < @as(u64, ((((state_449).request).source).kinds).len)))) {
            state_449 = block_624: {
                const value_3: (zx_abi).value_zx_type_41_3540ff82cd7401f2790fb0b97d3e60eb4ca97c3dede3a7b74038ab46d2dcac57 = (state_449).request;
                const value_4: u64 = (state_449).index;
                const value_5: []const u32 = block_623: {
                    const operand_620 = block_619: {
                        const operand_614 = (value_3).source;
                        const operand_615 = block_616: {
                            break :block_616 value_4;
                        };
                        const operand_617 = ((state_449).state).mapping;
                        const operand_618 = ((state_449).state).references;

                        break :block_619 @as((zx_abi).value_zx_type_38_b007dd1e4c63d95a3155329e1f60b16a22582c9bf6a4aa0bbdeb58811f8f72c5, (zx_abi).value_zx_type_38_b007dd1e4c63d95a3155329e1f60b16a22582c9bf6a4aa0bbdeb58811f8f72c5{ .source = operand_614, .index = operand_615, .mapping = operand_617, .references = operand_618, });
                    };

                    var state_borrow_621: (zx_abi).zx_type_15 = undefined;

                    state_borrow_621 = (zx_abi).zx_type_15{ .children = ((operand_620).source).children, .field_names = ((operand_620).source).field_names, .field_types = ((operand_620).source).field_types, .first = ((operand_620).source).first, .kinds = ((operand_620).source).kinds, .labels = ((operand_620).source).labels, .names = ((operand_620).source).names, .second = ((operand_620).source).second, };

                    var state_borrow_622: (zx_abi).zx_type_38 = undefined;

                    state_borrow_622 = (zx_abi).zx_type_38{ .index = (operand_620).index, .mapping = (operand_620).mapping, .references = (operand_620).references, .source = (((operand_620).source).zx_origin orelse (&state_borrow_621)), };

                    break :block_623 (try function_19_buffered(allocator, ((operand_620).zx_origin orelse (&state_borrow_622)), .{ .lane_0 = (if (((buffers).lane_13 != null)) .{ .buffer = (&(((buffers).lane_13.?).buffer).*), .started = (&(((buffers).lane_13.?).started).*), } else null), }));
                };
                const value_6: (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = block_613: {
                    break :block_613 (try function_10_value(allocator, block_612: {
                        const operand_607 = (value_3).source;
                        const operand_608 = block_609: {
                            break :block_609 value_4;
                        };
                        const operand_610 = block_611: {
                            break :block_611 value_5;
                        };

                        break :block_612 @as((zx_abi).value_zx_type_28_bc0beef4baed6cbec65527f285ce2af317364f06c28bd549a5782c80f0e63a13, (zx_abi).value_zx_type_28_bc0beef4baed6cbec65527f285ce2af317364f06c28bd549a5782c80f0e63a13{ .source = operand_607, .index = operand_608, .references = operand_610, });
                    }));
                };
                const value_7: (zx_abi).zx_type_11 = (try function_5(allocator, block_606: {
                    const operand_604 = ((value_3).source).kinds;
                    const operand_605 = block_603: {
                        break :block_603 value_4;
                    };

                    if ((operand_605 >= (operand_604).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_606 (operand_604)[@intCast(operand_605)];
                }));
                const value_8: bool = ((block_601: {
                    break :block_601 value_7;
                } == @as((zx_abi).zx_type_11, .Enumeration)) or (block_602: {
                    break :block_602 value_7;
                } == @as((zx_abi).zx_type_11, .NativeReference)));
                const value_21: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = (if ((block_460: {
                    break :block_460 value_8;
                } and (block_464: {
                    const operand_462 = (value_3).origin_indices;
                    const operand_463 = block_461: {
                        break :block_461 value_4;
                    };

                    if ((operand_463 >= (operand_462).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_464 (operand_462)[@intCast(operand_463)];
                } == @as(u64, 0)))) block_471: {
                    const value_9: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_470: {
                        break :block_470 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_449).index, .request = (state_449).request, .state = block_469: {
                            const operand_465 = (state_449).state;
                            const operand_466 = block_467: {
                                break :block_467 value_5;
                            };
                            const operand_468 = @as(u64, 1);

                            break :block_469 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_465).delta, .mapping = (operand_465).mapping, .origins = (operand_465).origins, .references = operand_466, .status = operand_468, });
                        }, });
                    };

                    break :block_471 value_9;
                } else block_600: {
                    const value_10: u64 = (if (block_595: {
                        break :block_595 value_8;
                    }) (block_599: {
                        const operand_597 = (value_3).origin_indices;
                        const operand_598 = block_596: {
                            break :block_596 value_4;
                        };

                        if ((operand_598 >= (operand_597).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_599 (operand_597)[@intCast(operand_598)];
                    } - @as(u64, 1)) else @as(u64, 0));
                    const value_11: (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (if (block_574: {
                        break :block_574 value_8;
                    }) block_590: {
                        const operand_575 = block_579: {
                            const operand_577 = ((value_3).origins).kinds;
                            const operand_578 = block_576: {
                                break :block_576 value_10;
                            };

                            if ((operand_578 >= (operand_577).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_579 (operand_577)[@intCast(operand_578)];
                        };
                        const operand_580 = block_584: {
                            const operand_582 = ((value_3).origins).owners;
                            const operand_583 = block_581: {
                                break :block_581 value_10;
                            };

                            if ((operand_583 >= (operand_582).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_584 (operand_582)[@intCast(operand_583)];
                        };
                        const operand_585 = block_589: {
                            const operand_587 = ((value_3).origins).members;
                            const operand_588 = block_586: {
                                break :block_586 value_10;
                            };

                            if ((operand_588 >= (operand_587).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_589 (operand_587)[@intCast(operand_588)];
                        };

                        break :block_590 @as((zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = operand_575, .owner = operand_580, .member = operand_585, });
                    } else block_594: {
                        const operand_591 = @as(u8, 0);
                        const operand_592 = @as([]const u8, "");
                        const operand_593 = @as([]const u8, "");

                        break :block_594 @as((zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = operand_591, .owner = operand_592, .member = operand_593, });
                    });
                    const value_12: (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9 = block_573: {
                        const operand_571 = (value_3).base;
                        const operand_572 = ((state_449).state).delta;

                        break :block_573 @as((zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9, (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = operand_571, .delta = operand_572, });
                    };
                    const value_13: u64 = (if (block_513: {
                        break :block_513 value_8;
                    }) block_552: {
                        const operand_514 = value_12;

                        var state_borrow_515: (zx_abi).zx_type_15 = undefined;

                        state_borrow_515 = (zx_abi).zx_type_15{ .children = ((operand_514).base).children, .field_names = ((operand_514).base).field_names, .field_types = ((operand_514).base).field_types, .first = ((operand_514).base).first, .kinds = ((operand_514).base).kinds, .labels = ((operand_514).base).labels, .names = ((operand_514).base).names, .second = ((operand_514).base).second, };

                        var state_borrow_516: (zx_abi).zx_type_15 = undefined;

                        state_borrow_516 = (zx_abi).zx_type_15{ .children = ((operand_514).delta).children, .field_names = ((operand_514).delta).field_names, .field_types = ((operand_514).delta).field_types, .first = ((operand_514).delta).first, .kinds = ((operand_514).delta).kinds, .labels = ((operand_514).delta).labels, .names = ((operand_514).delta).names, .second = ((operand_514).delta).second, };

                        var state_borrow_517: (zx_abi).zx_type_16 = undefined;

                        state_borrow_517 = (zx_abi).zx_type_16{ .base = (((operand_514).base).zx_origin orelse (&state_borrow_515)), .delta = (((operand_514).delta).zx_origin orelse (&state_borrow_516)), };

                        const operand_518 = ((operand_514).zx_origin orelse (&state_borrow_517));
                        const operand_519 = (value_3).base_origins;

                        var state_borrow_520: (zx_abi).zx_type_34 = undefined;

                        state_borrow_520 = (zx_abi).zx_type_34{ .ids = (operand_519).ids, .kinds = (operand_519).kinds, .members = (operand_519).members, .owners = (operand_519).owners, };

                        const operand_521 = ((operand_519).zx_origin orelse (&state_borrow_520));
                        const operand_522 = ((state_449).state).origins;

                        var state_borrow_523: (zx_abi).zx_type_34 = undefined;

                        state_borrow_523 = (zx_abi).zx_type_34{ .ids = (operand_522).ids, .kinds = (operand_522).kinds, .members = (operand_522).members, .owners = (operand_522).owners, };

                        const operand_524 = ((operand_522).zx_origin orelse (&state_borrow_523));
                        const operand_525 = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (operand_521).ids, .kinds = (operand_521).kinds, .members = (operand_521).members, .owners = (operand_521).owners, .zx_origin = operand_521, };

                        var state_borrow_526: (zx_abi).zx_type_34 = undefined;

                        state_borrow_526 = (zx_abi).zx_type_34{ .ids = (operand_525).ids, .kinds = (operand_525).kinds, .members = (operand_525).members, .owners = (operand_525).owners, };

                        const operand_527 = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (operand_524).ids, .kinds = (operand_524).kinds, .members = (operand_524).members, .owners = (operand_524).owners, .zx_origin = operand_524, };

                        var state_borrow_528: (zx_abi).zx_type_34 = undefined;

                        state_borrow_528 = (zx_abi).zx_type_34{ .ids = (operand_527).ids, .kinds = (operand_527).kinds, .members = (operand_527).members, .owners = (operand_527).owners, };

                        const operand_529 = (zx_abi).zx_type_35{ .base = ((operand_525).zx_origin orelse (&state_borrow_526)), .delta = ((operand_527).zx_origin orelse (&state_borrow_528)), };
                        const operand_530 = (&operand_529);
                        const operand_531 = value_11;

                        var state_borrow_532: (zx_abi).zx_type_33 = undefined;

                        state_borrow_532 = (zx_abi).zx_type_33{ .kind = (operand_531).kind, .member = (operand_531).member, .owner = (operand_531).owner, };

                        const operand_533 = ((operand_531).zx_origin orelse (&state_borrow_532));
                        const operand_534 = value_6;

                        var state_borrow_535: (zx_abi).zx_type_17 = undefined;

                        state_borrow_535 = (zx_abi).zx_type_17{ .names = ((operand_534).fields).names, .types = ((operand_534).fields).types, };

                        var state_borrow_536: (zx_abi).zx_type_24 = undefined;

                        state_borrow_536 = (zx_abi).zx_type_24{ .children = (operand_534).children, .fields = (((operand_534).fields).zx_origin orelse (&state_borrow_535)), .first = (operand_534).first, .kind = (operand_534).kind, .label = (operand_534).label, .names = (operand_534).names, .second = (operand_534).second, };

                        const operand_537 = ((operand_534).zx_origin orelse (&state_borrow_536));
                        const operand_538 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_518).base).children, .field_names = ((operand_518).base).field_names, .field_types = ((operand_518).base).field_types, .first = ((operand_518).base).first, .kinds = ((operand_518).base).kinds, .labels = ((operand_518).base).labels, .names = ((operand_518).base).names, .second = ((operand_518).base).second, .zx_origin = (operand_518).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_518).delta).children, .field_names = ((operand_518).delta).field_names, .field_types = ((operand_518).delta).field_types, .first = ((operand_518).delta).first, .kinds = ((operand_518).delta).kinds, .labels = ((operand_518).delta).labels, .names = ((operand_518).delta).names, .second = ((operand_518).delta).second, .zx_origin = (operand_518).delta, }, .zx_origin = operand_518, };

                        var state_borrow_539: (zx_abi).zx_type_15 = undefined;

                        state_borrow_539 = (zx_abi).zx_type_15{ .children = ((operand_538).base).children, .field_names = ((operand_538).base).field_names, .field_types = ((operand_538).base).field_types, .first = ((operand_538).base).first, .kinds = ((operand_538).base).kinds, .labels = ((operand_538).base).labels, .names = ((operand_538).base).names, .second = ((operand_538).base).second, };

                        var state_borrow_540: (zx_abi).zx_type_15 = undefined;

                        state_borrow_540 = (zx_abi).zx_type_15{ .children = ((operand_538).delta).children, .field_names = ((operand_538).delta).field_names, .field_types = ((operand_538).delta).field_types, .first = ((operand_538).delta).first, .kinds = ((operand_538).delta).kinds, .labels = ((operand_538).delta).labels, .names = ((operand_538).delta).names, .second = ((operand_538).delta).second, };

                        var state_borrow_541: (zx_abi).zx_type_16 = undefined;

                        state_borrow_541 = (zx_abi).zx_type_16{ .base = (((operand_538).base).zx_origin orelse (&state_borrow_539)), .delta = (((operand_538).delta).zx_origin orelse (&state_borrow_540)), };

                        const operand_542 = (zx_abi).value_zx_type_35_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53{ .base = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = ((operand_530).base).ids, .kinds = ((operand_530).base).kinds, .members = ((operand_530).base).members, .owners = ((operand_530).base).owners, .zx_origin = (operand_530).base, }, .delta = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = ((operand_530).delta).ids, .kinds = ((operand_530).delta).kinds, .members = ((operand_530).delta).members, .owners = ((operand_530).delta).owners, .zx_origin = (operand_530).delta, }, .zx_origin = operand_530, };

                        var state_borrow_543: (zx_abi).zx_type_34 = undefined;

                        state_borrow_543 = (zx_abi).zx_type_34{ .ids = ((operand_542).base).ids, .kinds = ((operand_542).base).kinds, .members = ((operand_542).base).members, .owners = ((operand_542).base).owners, };

                        var state_borrow_544: (zx_abi).zx_type_34 = undefined;

                        state_borrow_544 = (zx_abi).zx_type_34{ .ids = ((operand_542).delta).ids, .kinds = ((operand_542).delta).kinds, .members = ((operand_542).delta).members, .owners = ((operand_542).delta).owners, };

                        var state_borrow_545: (zx_abi).zx_type_35 = undefined;

                        state_borrow_545 = (zx_abi).zx_type_35{ .base = (((operand_542).base).zx_origin orelse (&state_borrow_543)), .delta = (((operand_542).delta).zx_origin orelse (&state_borrow_544)), };

                        const operand_546 = (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = (operand_533).kind, .member = (operand_533).member, .owner = (operand_533).owner, .zx_origin = operand_533, };

                        var state_borrow_547: (zx_abi).zx_type_33 = undefined;

                        state_borrow_547 = (zx_abi).zx_type_33{ .kind = (operand_546).kind, .member = (operand_546).member, .owner = (operand_546).owner, };

                        const operand_548 = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_537).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_537).fields).names, .types = ((operand_537).fields).types, .zx_origin = (operand_537).fields, }, .first = (operand_537).first, .kind = (operand_537).kind, .label = (operand_537).label, .names = (operand_537).names, .second = (operand_537).second, .zx_origin = operand_537, };

                        var state_borrow_549: (zx_abi).zx_type_17 = undefined;

                        state_borrow_549 = (zx_abi).zx_type_17{ .names = ((operand_548).fields).names, .types = ((operand_548).fields).types, };

                        var state_borrow_550: (zx_abi).zx_type_24 = undefined;

                        state_borrow_550 = (zx_abi).zx_type_24{ .children = (operand_548).children, .fields = (((operand_548).fields).zx_origin orelse (&state_borrow_549)), .first = (operand_548).first, .kind = (operand_548).kind, .label = (operand_548).label, .names = (operand_548).names, .second = (operand_548).second, };

                        const operand_551 = (zx_abi).zx_type_36{ .tables = ((operand_538).zx_origin orelse (&state_borrow_541)), .origins = ((operand_542).zx_origin orelse (&state_borrow_545)), .origin = ((operand_546).zx_origin orelse (&state_borrow_547)), .candidate = ((operand_548).zx_origin orelse (&state_borrow_550)), };

                        break :block_552 (try function_17(allocator, (&operand_551)));
                    } else block_570: {
                        const operand_553 = value_12;

                        var state_borrow_554: (zx_abi).zx_type_15 = undefined;

                        state_borrow_554 = (zx_abi).zx_type_15{ .children = ((operand_553).base).children, .field_names = ((operand_553).base).field_names, .field_types = ((operand_553).base).field_types, .first = ((operand_553).base).first, .kinds = ((operand_553).base).kinds, .labels = ((operand_553).base).labels, .names = ((operand_553).base).names, .second = ((operand_553).base).second, };

                        var state_borrow_555: (zx_abi).zx_type_15 = undefined;

                        state_borrow_555 = (zx_abi).zx_type_15{ .children = ((operand_553).delta).children, .field_names = ((operand_553).delta).field_names, .field_types = ((operand_553).delta).field_types, .first = ((operand_553).delta).first, .kinds = ((operand_553).delta).kinds, .labels = ((operand_553).delta).labels, .names = ((operand_553).delta).names, .second = ((operand_553).delta).second, };

                        var state_borrow_556: (zx_abi).zx_type_16 = undefined;

                        state_borrow_556 = (zx_abi).zx_type_16{ .base = (((operand_553).base).zx_origin orelse (&state_borrow_554)), .delta = (((operand_553).delta).zx_origin orelse (&state_borrow_555)), };

                        const operand_557 = ((operand_553).zx_origin orelse (&state_borrow_556));
                        const operand_558 = value_6;

                        var state_borrow_559: (zx_abi).zx_type_17 = undefined;

                        state_borrow_559 = (zx_abi).zx_type_17{ .names = ((operand_558).fields).names, .types = ((operand_558).fields).types, };

                        var state_borrow_560: (zx_abi).zx_type_24 = undefined;

                        state_borrow_560 = (zx_abi).zx_type_24{ .children = (operand_558).children, .fields = (((operand_558).fields).zx_origin orelse (&state_borrow_559)), .first = (operand_558).first, .kind = (operand_558).kind, .label = (operand_558).label, .names = (operand_558).names, .second = (operand_558).second, };

                        const operand_561 = ((operand_558).zx_origin orelse (&state_borrow_560));
                        const operand_562 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_557).base).children, .field_names = ((operand_557).base).field_names, .field_types = ((operand_557).base).field_types, .first = ((operand_557).base).first, .kinds = ((operand_557).base).kinds, .labels = ((operand_557).base).labels, .names = ((operand_557).base).names, .second = ((operand_557).base).second, .zx_origin = (operand_557).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_557).delta).children, .field_names = ((operand_557).delta).field_names, .field_types = ((operand_557).delta).field_types, .first = ((operand_557).delta).first, .kinds = ((operand_557).delta).kinds, .labels = ((operand_557).delta).labels, .names = ((operand_557).delta).names, .second = ((operand_557).delta).second, .zx_origin = (operand_557).delta, }, .zx_origin = operand_557, };

                        var state_borrow_563: (zx_abi).zx_type_15 = undefined;

                        state_borrow_563 = (zx_abi).zx_type_15{ .children = ((operand_562).base).children, .field_names = ((operand_562).base).field_names, .field_types = ((operand_562).base).field_types, .first = ((operand_562).base).first, .kinds = ((operand_562).base).kinds, .labels = ((operand_562).base).labels, .names = ((operand_562).base).names, .second = ((operand_562).base).second, };

                        var state_borrow_564: (zx_abi).zx_type_15 = undefined;

                        state_borrow_564 = (zx_abi).zx_type_15{ .children = ((operand_562).delta).children, .field_names = ((operand_562).delta).field_names, .field_types = ((operand_562).delta).field_types, .first = ((operand_562).delta).first, .kinds = ((operand_562).delta).kinds, .labels = ((operand_562).delta).labels, .names = ((operand_562).delta).names, .second = ((operand_562).delta).second, };

                        var state_borrow_565: (zx_abi).zx_type_16 = undefined;

                        state_borrow_565 = (zx_abi).zx_type_16{ .base = (((operand_562).base).zx_origin orelse (&state_borrow_563)), .delta = (((operand_562).delta).zx_origin orelse (&state_borrow_564)), };

                        const operand_566 = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_561).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_561).fields).names, .types = ((operand_561).fields).types, .zx_origin = (operand_561).fields, }, .first = (operand_561).first, .kind = (operand_561).kind, .label = (operand_561).label, .names = (operand_561).names, .second = (operand_561).second, .zx_origin = operand_561, };

                        var state_borrow_567: (zx_abi).zx_type_17 = undefined;

                        state_borrow_567 = (zx_abi).zx_type_17{ .names = ((operand_566).fields).names, .types = ((operand_566).fields).types, };

                        var state_borrow_568: (zx_abi).zx_type_24 = undefined;

                        state_borrow_568 = (zx_abi).zx_type_24{ .children = (operand_566).children, .fields = (((operand_566).fields).zx_origin orelse (&state_borrow_567)), .first = (operand_566).first, .kind = (operand_566).kind, .label = (operand_566).label, .names = (operand_566).names, .second = (operand_566).second, };

                        const operand_569 = (zx_abi).zx_type_39{ .tables = ((operand_562).zx_origin orelse (&state_borrow_565)), .candidate = ((operand_566).zx_origin orelse (&state_borrow_568)), };

                        break :block_570 (try function_21(allocator, (&operand_569)));
                    });
                    const value_20: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = (if ((block_472: {
                        break :block_472 value_13;
                    } == @as(u64, 1))) block_479: {
                        const value_14: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_478: {
                            break :block_478 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_449).index, .request = (state_449).request, .state = block_477: {
                                const operand_473 = (state_449).state;
                                const operand_474 = block_475: {
                                    break :block_475 value_5;
                                };
                                const operand_476 = @as(u64, 2);

                                break :block_477 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_473).delta, .mapping = (operand_473).mapping, .origins = (operand_473).origins, .references = operand_474, .status = operand_476, });
                            }, });
                        };

                        break :block_479 value_14;
                    } else block_512: {
                        const value_15: u32 = (if ((block_510: {
                            break :block_510 value_13;
                        } == @as(u64, 0))) (try function_2(allocator, (@as(u64, (((value_3).base).kinds).len) + @as(u64, ((((state_449).state).delta).kinds).len)))) else (try function_2(allocator, (block_511: {
                            break :block_511 value_13;
                        } - @as(u64, 2)))));
                        const value_16: (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = (if ((block_505: {
                            break :block_505 value_13;
                        } == @as(u64, 0))) @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, block_509: {
                            break :block_509 (try function_9_buffered(allocator, block_508: {
                                const operand_506 = ((state_449).state).delta;
                                const operand_507 = value_6;

                                break :block_508 @as((zx_abi).value_zx_type_27_eb83b36bd9eb840e506cc8c01a38c13a9cdff0b6a9636a9eecf085d3c539269b, (zx_abi).value_zx_type_27_eb83b36bd9eb840e506cc8c01a38c13a9cdff0b6a9636a9eecf085d3c539269b{ .delta = operand_506, .candidate = operand_507, });
                            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), .lane_3 = (if (((buffers).lane_3 != null)) .{ .buffer = (&(((buffers).lane_3.?).buffer).*), .started = (&(((buffers).lane_3.?).started).*), } else null), .lane_4 = (if (((buffers).lane_4 != null)) .{ .buffer = (&(((buffers).lane_4.?).buffer).*), .started = (&(((buffers).lane_4.?).started).*), } else null), .lane_5 = (if (((buffers).lane_5 != null)) .{ .buffer = (&(((buffers).lane_5.?).buffer).*), .started = (&(((buffers).lane_5.?).started).*), } else null), .lane_6 = (if (((buffers).lane_6 != null)) .{ .buffer = (&(((buffers).lane_6.?).buffer).*), .started = (&(((buffers).lane_6.?).started).*), } else null), .lane_7 = (if (((buffers).lane_7 != null)) .{ .buffer = (&(((buffers).lane_7.?).buffer).*), .started = (&(((buffers).lane_7.?).started).*), } else null), }));
                        }) else ((state_449).state).delta);
                        const value_17: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if (((block_497: {
                            break :block_497 value_13;
                        } == @as(u64, 0)) and block_498: {
                            break :block_498 value_8;
                        })) @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, block_504: {
                            break :block_504 (try function_18_buffered(allocator, block_503: {
                                const operand_499 = ((state_449).state).origins;
                                const operand_500 = value_11;
                                const operand_501 = block_502: {
                                    break :block_502 value_15;
                                };

                                break :block_503 @as((zx_abi).value_zx_type_37_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39, (zx_abi).value_zx_type_37_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39{ .bindings = operand_499, .origin = operand_500, .id = operand_501, });
                            }, .{ .lane_0 = (if (((buffers).lane_9 != null)) .{ .buffer = (&(((buffers).lane_9.?).buffer).*), .started = (&(((buffers).lane_9.?).started).*), } else null), .lane_1 = (if (((buffers).lane_10 != null)) .{ .buffer = (&(((buffers).lane_10.?).buffer).*), .started = (&(((buffers).lane_10.?).started).*), } else null), .lane_2 = (if (((buffers).lane_11 != null)) .{ .buffer = (&(((buffers).lane_11.?).buffer).*), .started = (&(((buffers).lane_11.?).started).*), } else null), .lane_3 = (if (((buffers).lane_12 != null)) .{ .buffer = (&(((buffers).lane_12.?).buffer).*), .started = (&(((buffers).lane_12.?).started).*), } else null), }));
                        }) else ((state_449).state).origins);
                        const value_18: []const u32 = block_496: {
                            const operand_489 = ((state_449).state).mapping;
                            const operand_491 = block_490: {
                                break :block_490 value_4;
                            };

                            if ((operand_491 >= (operand_489).len)) {
                                return error.IndexOutOfBounds;
                            }

                            const operand_493 = block_492: {
                                break :block_492 value_15;
                            };

                            break :block_496 @as([]const u32, (if (((buffers).lane_8 != null)) block_494: {
                                if ((!(((buffers).lane_8.?).started).*)) {
                                    (try ((((buffers).lane_8.?).buffer).*).appendSlice(allocator, operand_489));

                                    (((buffers).lane_8.?).started).* = true;
                                } else {
                                    (((((buffers).lane_8.?).buffer).*).items).len = (operand_489).len;
                                }

                                (((((buffers).lane_8.?).buffer).*).items)[@intCast(operand_491)] = operand_493;

                                break :block_494 ((((buffers).lane_8.?).buffer).*).items;
                            } else block_495: {
                                if ((!state_capacity_started_457)) {
                                    (try (state_capacity_456).appendSlice(allocator, operand_489));

                                    state_capacity_started_457 = true;
                                } else {
                                    ((state_capacity_456).items).len = (operand_489).len;
                                }

                                ((state_capacity_456).items)[@intCast(operand_491)] = operand_493;

                                break :block_495 (state_capacity_456).items;
                            }));
                        };
                        const value_19: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_488: {
                            break :block_488 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_449).index, .request = (state_449).request, .state = block_487: {
                                const operand_480 = block_481: {
                                    break :block_481 value_18;
                                };
                                const operand_482 = value_16;
                                const operand_483 = value_17;
                                const operand_484 = block_485: {
                                    break :block_485 value_5;
                                };
                                const operand_486 = @as(u64, 0);

                                break :block_487 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .mapping = operand_480, .delta = operand_482, .origins = operand_483, .references = operand_484, .status = operand_486, });
                            }, });
                        };

                        break :block_512 value_19;
                    });

                    break :block_600 value_20;
                });
                const value_22: u64 = (value_21).index;
                const value_23: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_459: {
                    break :block_459 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (block_458: {
                        break :block_458 value_22;
                    } + @as(u64, 1)), .request = (value_21).request, .state = (value_21).state, });
                };

                break :block_624 value_23;
            };

            state_changed_455 = true;
        }

        var state_owned_625: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_625);

        if (state_capacity_started_457) {
            ((state_capacity_456).items).len = (((state_449).state).mapping).len;

            state_owned_625 = (try (state_capacity_456).toOwnedSlice(allocator));
        }

        if (state_capacity_started_457) {
            state_449 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_449).index, .request = (state_449).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_449).state).delta, .mapping = state_owned_625, .origins = ((state_449).state).origins, .references = ((state_449).state).references, .status = ((state_449).state).status, }), };
        }

        break :block_627 (if (state_changed_455) state_449 else operand_454);
    }).state;
}

fn function_22_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_43, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u8),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_8: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_9: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_10: ?struct {
        buffer: *(std).ArrayList(u8),
        started: *bool,
    },
    lane_11: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_12: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_13: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_42 {
    @setRuntimeSafety(true);

    return (block_822: {
        const operand_633 = block_632: {
            const operand_629 = (in).request;
            const operand_630 = (in).state;
            const operand_631 = ((in).request).first;

            break :block_632 (zx_abi).zx_type_55{ .request = operand_629, .state = operand_630, .index = operand_631, };
        };

        var state_capacity_634: (std).ArrayList(u32) = .empty;

        var state_capacity_started_635 = false;

        defer (state_capacity_634).deinit(allocator);

        var state_628: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (operand_633).index, .request = (zx_abi).value_zx_type_41_3540ff82cd7401f2790fb0b97d3e60eb4ca97c3dede3a7b74038ab46d2dcac57{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_633).request).base).children, .field_names = (((operand_633).request).base).field_names, .field_types = (((operand_633).request).base).field_types, .first = (((operand_633).request).base).first, .kinds = (((operand_633).request).base).kinds, .labels = (((operand_633).request).base).labels, .names = (((operand_633).request).base).names, .second = (((operand_633).request).base).second, .zx_origin = ((operand_633).request).base, }, .base_origins = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_633).request).base_origins).ids, .kinds = (((operand_633).request).base_origins).kinds, .members = (((operand_633).request).base_origins).members, .owners = (((operand_633).request).base_origins).owners, .zx_origin = ((operand_633).request).base_origins, }, .first = ((operand_633).request).first, .origin_indices = ((operand_633).request).origin_indices, .origins = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_633).request).origins).ids, .kinds = (((operand_633).request).origins).kinds, .members = (((operand_633).request).origins).members, .owners = (((operand_633).request).origins).owners, .zx_origin = ((operand_633).request).origins, }, .source = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_633).request).source).children, .field_names = (((operand_633).request).source).field_names, .field_types = (((operand_633).request).source).field_types, .first = (((operand_633).request).source).first, .kinds = (((operand_633).request).source).kinds, .labels = (((operand_633).request).source).labels, .names = (((operand_633).request).source).names, .second = (((operand_633).request).source).second, .zx_origin = ((operand_633).request).source, }, .zx_origin = (operand_633).request, }, .state = (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_633).state).delta).children, .field_names = (((operand_633).state).delta).field_names, .field_types = (((operand_633).state).delta).field_types, .first = (((operand_633).state).delta).first, .kinds = (((operand_633).state).delta).kinds, .labels = (((operand_633).state).delta).labels, .names = (((operand_633).state).delta).names, .second = (((operand_633).state).delta).second, .zx_origin = ((operand_633).state).delta, }, .mapping = ((operand_633).state).mapping, .origins = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_633).state).origins).ids, .kinds = (((operand_633).state).origins).kinds, .members = (((operand_633).state).origins).members, .owners = (((operand_633).state).origins).owners, .zx_origin = ((operand_633).state).origins, }, .references = ((operand_633).state).references, .status = ((operand_633).state).status, .zx_origin = (operand_633).state, }, .zx_origin = (&operand_633), };

        while (((((state_628).state).status == @as(u64, 0)) and ((state_628).index < @as(u64, ((((state_628).request).source).kinds).len)))) {
            state_628 = block_802: {
                const value_3: (zx_abi).value_zx_type_41_3540ff82cd7401f2790fb0b97d3e60eb4ca97c3dede3a7b74038ab46d2dcac57 = (state_628).request;
                const value_4: u64 = (state_628).index;
                const value_5: []const u32 = block_801: {
                    const operand_798 = block_797: {
                        const operand_792 = (value_3).source;
                        const operand_793 = block_794: {
                            break :block_794 value_4;
                        };
                        const operand_795 = ((state_628).state).mapping;
                        const operand_796 = ((state_628).state).references;

                        break :block_797 @as((zx_abi).value_zx_type_38_b007dd1e4c63d95a3155329e1f60b16a22582c9bf6a4aa0bbdeb58811f8f72c5, (zx_abi).value_zx_type_38_b007dd1e4c63d95a3155329e1f60b16a22582c9bf6a4aa0bbdeb58811f8f72c5{ .source = operand_792, .index = operand_793, .mapping = operand_795, .references = operand_796, });
                    };

                    var state_borrow_799: (zx_abi).zx_type_15 = undefined;

                    state_borrow_799 = (zx_abi).zx_type_15{ .children = ((operand_798).source).children, .field_names = ((operand_798).source).field_names, .field_types = ((operand_798).source).field_types, .first = ((operand_798).source).first, .kinds = ((operand_798).source).kinds, .labels = ((operand_798).source).labels, .names = ((operand_798).source).names, .second = ((operand_798).source).second, };

                    var state_borrow_800: (zx_abi).zx_type_38 = undefined;

                    state_borrow_800 = (zx_abi).zx_type_38{ .index = (operand_798).index, .mapping = (operand_798).mapping, .references = (operand_798).references, .source = (((operand_798).source).zx_origin orelse (&state_borrow_799)), };

                    break :block_801 (try function_19_buffered(allocator, ((operand_798).zx_origin orelse (&state_borrow_800)), .{ .lane_0 = (if (((buffers).lane_13 != null)) .{ .buffer = (&(((buffers).lane_13.?).buffer).*), .started = (&(((buffers).lane_13.?).started).*), } else null), }));
                };
                const value_6: (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = block_791: {
                    break :block_791 (try function_10_value(allocator, block_790: {
                        const operand_785 = (value_3).source;
                        const operand_786 = block_787: {
                            break :block_787 value_4;
                        };
                        const operand_788 = block_789: {
                            break :block_789 value_5;
                        };

                        break :block_790 @as((zx_abi).value_zx_type_28_bc0beef4baed6cbec65527f285ce2af317364f06c28bd549a5782c80f0e63a13, (zx_abi).value_zx_type_28_bc0beef4baed6cbec65527f285ce2af317364f06c28bd549a5782c80f0e63a13{ .source = operand_785, .index = operand_786, .references = operand_788, });
                    }));
                };
                const value_7: (zx_abi).zx_type_11 = (try function_5(allocator, block_784: {
                    const operand_782 = ((value_3).source).kinds;
                    const operand_783 = block_781: {
                        break :block_781 value_4;
                    };

                    if ((operand_783 >= (operand_782).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_784 (operand_782)[@intCast(operand_783)];
                }));
                const value_8: bool = ((block_779: {
                    break :block_779 value_7;
                } == @as((zx_abi).zx_type_11, .Enumeration)) or (block_780: {
                    break :block_780 value_7;
                } == @as((zx_abi).zx_type_11, .NativeReference)));
                const value_21: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = (if ((block_638: {
                    break :block_638 value_8;
                } and (block_642: {
                    const operand_640 = (value_3).origin_indices;
                    const operand_641 = block_639: {
                        break :block_639 value_4;
                    };

                    if ((operand_641 >= (operand_640).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_642 (operand_640)[@intCast(operand_641)];
                } == @as(u64, 0)))) block_649: {
                    const value_9: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_648: {
                        break :block_648 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_628).index, .request = (state_628).request, .state = block_647: {
                            const operand_643 = (state_628).state;
                            const operand_644 = block_645: {
                                break :block_645 value_5;
                            };
                            const operand_646 = @as(u64, 1);

                            break :block_647 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_643).delta, .mapping = (operand_643).mapping, .origins = (operand_643).origins, .references = operand_644, .status = operand_646, });
                        }, });
                    };

                    break :block_649 value_9;
                } else block_778: {
                    const value_10: u64 = (if (block_773: {
                        break :block_773 value_8;
                    }) (block_777: {
                        const operand_775 = (value_3).origin_indices;
                        const operand_776 = block_774: {
                            break :block_774 value_4;
                        };

                        if ((operand_776 >= (operand_775).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_777 (operand_775)[@intCast(operand_776)];
                    } - @as(u64, 1)) else @as(u64, 0));
                    const value_11: (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (if (block_752: {
                        break :block_752 value_8;
                    }) block_768: {
                        const operand_753 = block_757: {
                            const operand_755 = ((value_3).origins).kinds;
                            const operand_756 = block_754: {
                                break :block_754 value_10;
                            };

                            if ((operand_756 >= (operand_755).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_757 (operand_755)[@intCast(operand_756)];
                        };
                        const operand_758 = block_762: {
                            const operand_760 = ((value_3).origins).owners;
                            const operand_761 = block_759: {
                                break :block_759 value_10;
                            };

                            if ((operand_761 >= (operand_760).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_762 (operand_760)[@intCast(operand_761)];
                        };
                        const operand_763 = block_767: {
                            const operand_765 = ((value_3).origins).members;
                            const operand_766 = block_764: {
                                break :block_764 value_10;
                            };

                            if ((operand_766 >= (operand_765).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_767 (operand_765)[@intCast(operand_766)];
                        };

                        break :block_768 @as((zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = operand_753, .owner = operand_758, .member = operand_763, });
                    } else block_772: {
                        const operand_769 = @as(u8, 0);
                        const operand_770 = @as([]const u8, "");
                        const operand_771 = @as([]const u8, "");

                        break :block_772 @as((zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = operand_769, .owner = operand_770, .member = operand_771, });
                    });
                    const value_12: (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9 = block_751: {
                        const operand_749 = (value_3).base;
                        const operand_750 = ((state_628).state).delta;

                        break :block_751 @as((zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9, (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = operand_749, .delta = operand_750, });
                    };
                    const value_13: u64 = (if (block_691: {
                        break :block_691 value_8;
                    }) block_730: {
                        const operand_692 = value_12;

                        var state_borrow_693: (zx_abi).zx_type_15 = undefined;

                        state_borrow_693 = (zx_abi).zx_type_15{ .children = ((operand_692).base).children, .field_names = ((operand_692).base).field_names, .field_types = ((operand_692).base).field_types, .first = ((operand_692).base).first, .kinds = ((operand_692).base).kinds, .labels = ((operand_692).base).labels, .names = ((operand_692).base).names, .second = ((operand_692).base).second, };

                        var state_borrow_694: (zx_abi).zx_type_15 = undefined;

                        state_borrow_694 = (zx_abi).zx_type_15{ .children = ((operand_692).delta).children, .field_names = ((operand_692).delta).field_names, .field_types = ((operand_692).delta).field_types, .first = ((operand_692).delta).first, .kinds = ((operand_692).delta).kinds, .labels = ((operand_692).delta).labels, .names = ((operand_692).delta).names, .second = ((operand_692).delta).second, };

                        var state_borrow_695: (zx_abi).zx_type_16 = undefined;

                        state_borrow_695 = (zx_abi).zx_type_16{ .base = (((operand_692).base).zx_origin orelse (&state_borrow_693)), .delta = (((operand_692).delta).zx_origin orelse (&state_borrow_694)), };

                        const operand_696 = ((operand_692).zx_origin orelse (&state_borrow_695));
                        const operand_697 = (value_3).base_origins;

                        var state_borrow_698: (zx_abi).zx_type_34 = undefined;

                        state_borrow_698 = (zx_abi).zx_type_34{ .ids = (operand_697).ids, .kinds = (operand_697).kinds, .members = (operand_697).members, .owners = (operand_697).owners, };

                        const operand_699 = ((operand_697).zx_origin orelse (&state_borrow_698));
                        const operand_700 = ((state_628).state).origins;

                        var state_borrow_701: (zx_abi).zx_type_34 = undefined;

                        state_borrow_701 = (zx_abi).zx_type_34{ .ids = (operand_700).ids, .kinds = (operand_700).kinds, .members = (operand_700).members, .owners = (operand_700).owners, };

                        const operand_702 = ((operand_700).zx_origin orelse (&state_borrow_701));
                        const operand_703 = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (operand_699).ids, .kinds = (operand_699).kinds, .members = (operand_699).members, .owners = (operand_699).owners, .zx_origin = operand_699, };

                        var state_borrow_704: (zx_abi).zx_type_34 = undefined;

                        state_borrow_704 = (zx_abi).zx_type_34{ .ids = (operand_703).ids, .kinds = (operand_703).kinds, .members = (operand_703).members, .owners = (operand_703).owners, };

                        const operand_705 = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (operand_702).ids, .kinds = (operand_702).kinds, .members = (operand_702).members, .owners = (operand_702).owners, .zx_origin = operand_702, };

                        var state_borrow_706: (zx_abi).zx_type_34 = undefined;

                        state_borrow_706 = (zx_abi).zx_type_34{ .ids = (operand_705).ids, .kinds = (operand_705).kinds, .members = (operand_705).members, .owners = (operand_705).owners, };

                        const operand_707 = (zx_abi).zx_type_35{ .base = ((operand_703).zx_origin orelse (&state_borrow_704)), .delta = ((operand_705).zx_origin orelse (&state_borrow_706)), };
                        const operand_708 = (&operand_707);
                        const operand_709 = value_11;

                        var state_borrow_710: (zx_abi).zx_type_33 = undefined;

                        state_borrow_710 = (zx_abi).zx_type_33{ .kind = (operand_709).kind, .member = (operand_709).member, .owner = (operand_709).owner, };

                        const operand_711 = ((operand_709).zx_origin orelse (&state_borrow_710));
                        const operand_712 = value_6;

                        var state_borrow_713: (zx_abi).zx_type_17 = undefined;

                        state_borrow_713 = (zx_abi).zx_type_17{ .names = ((operand_712).fields).names, .types = ((operand_712).fields).types, };

                        var state_borrow_714: (zx_abi).zx_type_24 = undefined;

                        state_borrow_714 = (zx_abi).zx_type_24{ .children = (operand_712).children, .fields = (((operand_712).fields).zx_origin orelse (&state_borrow_713)), .first = (operand_712).first, .kind = (operand_712).kind, .label = (operand_712).label, .names = (operand_712).names, .second = (operand_712).second, };

                        const operand_715 = ((operand_712).zx_origin orelse (&state_borrow_714));
                        const operand_716 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_696).base).children, .field_names = ((operand_696).base).field_names, .field_types = ((operand_696).base).field_types, .first = ((operand_696).base).first, .kinds = ((operand_696).base).kinds, .labels = ((operand_696).base).labels, .names = ((operand_696).base).names, .second = ((operand_696).base).second, .zx_origin = (operand_696).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_696).delta).children, .field_names = ((operand_696).delta).field_names, .field_types = ((operand_696).delta).field_types, .first = ((operand_696).delta).first, .kinds = ((operand_696).delta).kinds, .labels = ((operand_696).delta).labels, .names = ((operand_696).delta).names, .second = ((operand_696).delta).second, .zx_origin = (operand_696).delta, }, .zx_origin = operand_696, };

                        var state_borrow_717: (zx_abi).zx_type_15 = undefined;

                        state_borrow_717 = (zx_abi).zx_type_15{ .children = ((operand_716).base).children, .field_names = ((operand_716).base).field_names, .field_types = ((operand_716).base).field_types, .first = ((operand_716).base).first, .kinds = ((operand_716).base).kinds, .labels = ((operand_716).base).labels, .names = ((operand_716).base).names, .second = ((operand_716).base).second, };

                        var state_borrow_718: (zx_abi).zx_type_15 = undefined;

                        state_borrow_718 = (zx_abi).zx_type_15{ .children = ((operand_716).delta).children, .field_names = ((operand_716).delta).field_names, .field_types = ((operand_716).delta).field_types, .first = ((operand_716).delta).first, .kinds = ((operand_716).delta).kinds, .labels = ((operand_716).delta).labels, .names = ((operand_716).delta).names, .second = ((operand_716).delta).second, };

                        var state_borrow_719: (zx_abi).zx_type_16 = undefined;

                        state_borrow_719 = (zx_abi).zx_type_16{ .base = (((operand_716).base).zx_origin orelse (&state_borrow_717)), .delta = (((operand_716).delta).zx_origin orelse (&state_borrow_718)), };

                        const operand_720 = (zx_abi).value_zx_type_35_34a7043d93013edc2fea5c5649b2eacd4cda88a7491617ddd8833cf1f6d00f53{ .base = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = ((operand_708).base).ids, .kinds = ((operand_708).base).kinds, .members = ((operand_708).base).members, .owners = ((operand_708).base).owners, .zx_origin = (operand_708).base, }, .delta = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = ((operand_708).delta).ids, .kinds = ((operand_708).delta).kinds, .members = ((operand_708).delta).members, .owners = ((operand_708).delta).owners, .zx_origin = (operand_708).delta, }, .zx_origin = operand_708, };

                        var state_borrow_721: (zx_abi).zx_type_34 = undefined;

                        state_borrow_721 = (zx_abi).zx_type_34{ .ids = ((operand_720).base).ids, .kinds = ((operand_720).base).kinds, .members = ((operand_720).base).members, .owners = ((operand_720).base).owners, };

                        var state_borrow_722: (zx_abi).zx_type_34 = undefined;

                        state_borrow_722 = (zx_abi).zx_type_34{ .ids = ((operand_720).delta).ids, .kinds = ((operand_720).delta).kinds, .members = ((operand_720).delta).members, .owners = ((operand_720).delta).owners, };

                        var state_borrow_723: (zx_abi).zx_type_35 = undefined;

                        state_borrow_723 = (zx_abi).zx_type_35{ .base = (((operand_720).base).zx_origin orelse (&state_borrow_721)), .delta = (((operand_720).delta).zx_origin orelse (&state_borrow_722)), };

                        const operand_724 = (zx_abi).value_zx_type_33_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .kind = (operand_711).kind, .member = (operand_711).member, .owner = (operand_711).owner, .zx_origin = operand_711, };

                        var state_borrow_725: (zx_abi).zx_type_33 = undefined;

                        state_borrow_725 = (zx_abi).zx_type_33{ .kind = (operand_724).kind, .member = (operand_724).member, .owner = (operand_724).owner, };

                        const operand_726 = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_715).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_715).fields).names, .types = ((operand_715).fields).types, .zx_origin = (operand_715).fields, }, .first = (operand_715).first, .kind = (operand_715).kind, .label = (operand_715).label, .names = (operand_715).names, .second = (operand_715).second, .zx_origin = operand_715, };

                        var state_borrow_727: (zx_abi).zx_type_17 = undefined;

                        state_borrow_727 = (zx_abi).zx_type_17{ .names = ((operand_726).fields).names, .types = ((operand_726).fields).types, };

                        var state_borrow_728: (zx_abi).zx_type_24 = undefined;

                        state_borrow_728 = (zx_abi).zx_type_24{ .children = (operand_726).children, .fields = (((operand_726).fields).zx_origin orelse (&state_borrow_727)), .first = (operand_726).first, .kind = (operand_726).kind, .label = (operand_726).label, .names = (operand_726).names, .second = (operand_726).second, };

                        const operand_729 = (zx_abi).zx_type_36{ .tables = ((operand_716).zx_origin orelse (&state_borrow_719)), .origins = ((operand_720).zx_origin orelse (&state_borrow_723)), .origin = ((operand_724).zx_origin orelse (&state_borrow_725)), .candidate = ((operand_726).zx_origin orelse (&state_borrow_728)), };

                        break :block_730 (try function_17(allocator, (&operand_729)));
                    } else block_748: {
                        const operand_731 = value_12;

                        var state_borrow_732: (zx_abi).zx_type_15 = undefined;

                        state_borrow_732 = (zx_abi).zx_type_15{ .children = ((operand_731).base).children, .field_names = ((operand_731).base).field_names, .field_types = ((operand_731).base).field_types, .first = ((operand_731).base).first, .kinds = ((operand_731).base).kinds, .labels = ((operand_731).base).labels, .names = ((operand_731).base).names, .second = ((operand_731).base).second, };

                        var state_borrow_733: (zx_abi).zx_type_15 = undefined;

                        state_borrow_733 = (zx_abi).zx_type_15{ .children = ((operand_731).delta).children, .field_names = ((operand_731).delta).field_names, .field_types = ((operand_731).delta).field_types, .first = ((operand_731).delta).first, .kinds = ((operand_731).delta).kinds, .labels = ((operand_731).delta).labels, .names = ((operand_731).delta).names, .second = ((operand_731).delta).second, };

                        var state_borrow_734: (zx_abi).zx_type_16 = undefined;

                        state_borrow_734 = (zx_abi).zx_type_16{ .base = (((operand_731).base).zx_origin orelse (&state_borrow_732)), .delta = (((operand_731).delta).zx_origin orelse (&state_borrow_733)), };

                        const operand_735 = ((operand_731).zx_origin orelse (&state_borrow_734));
                        const operand_736 = value_6;

                        var state_borrow_737: (zx_abi).zx_type_17 = undefined;

                        state_borrow_737 = (zx_abi).zx_type_17{ .names = ((operand_736).fields).names, .types = ((operand_736).fields).types, };

                        var state_borrow_738: (zx_abi).zx_type_24 = undefined;

                        state_borrow_738 = (zx_abi).zx_type_24{ .children = (operand_736).children, .fields = (((operand_736).fields).zx_origin orelse (&state_borrow_737)), .first = (operand_736).first, .kind = (operand_736).kind, .label = (operand_736).label, .names = (operand_736).names, .second = (operand_736).second, };

                        const operand_739 = ((operand_736).zx_origin orelse (&state_borrow_738));
                        const operand_740 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_735).base).children, .field_names = ((operand_735).base).field_names, .field_types = ((operand_735).base).field_types, .first = ((operand_735).base).first, .kinds = ((operand_735).base).kinds, .labels = ((operand_735).base).labels, .names = ((operand_735).base).names, .second = ((operand_735).base).second, .zx_origin = (operand_735).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_735).delta).children, .field_names = ((operand_735).delta).field_names, .field_types = ((operand_735).delta).field_types, .first = ((operand_735).delta).first, .kinds = ((operand_735).delta).kinds, .labels = ((operand_735).delta).labels, .names = ((operand_735).delta).names, .second = ((operand_735).delta).second, .zx_origin = (operand_735).delta, }, .zx_origin = operand_735, };

                        var state_borrow_741: (zx_abi).zx_type_15 = undefined;

                        state_borrow_741 = (zx_abi).zx_type_15{ .children = ((operand_740).base).children, .field_names = ((operand_740).base).field_names, .field_types = ((operand_740).base).field_types, .first = ((operand_740).base).first, .kinds = ((operand_740).base).kinds, .labels = ((operand_740).base).labels, .names = ((operand_740).base).names, .second = ((operand_740).base).second, };

                        var state_borrow_742: (zx_abi).zx_type_15 = undefined;

                        state_borrow_742 = (zx_abi).zx_type_15{ .children = ((operand_740).delta).children, .field_names = ((operand_740).delta).field_names, .field_types = ((operand_740).delta).field_types, .first = ((operand_740).delta).first, .kinds = ((operand_740).delta).kinds, .labels = ((operand_740).delta).labels, .names = ((operand_740).delta).names, .second = ((operand_740).delta).second, };

                        var state_borrow_743: (zx_abi).zx_type_16 = undefined;

                        state_borrow_743 = (zx_abi).zx_type_16{ .base = (((operand_740).base).zx_origin orelse (&state_borrow_741)), .delta = (((operand_740).delta).zx_origin orelse (&state_borrow_742)), };

                        const operand_744 = (zx_abi).value_zx_type_24_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_739).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_739).fields).names, .types = ((operand_739).fields).types, .zx_origin = (operand_739).fields, }, .first = (operand_739).first, .kind = (operand_739).kind, .label = (operand_739).label, .names = (operand_739).names, .second = (operand_739).second, .zx_origin = operand_739, };

                        var state_borrow_745: (zx_abi).zx_type_17 = undefined;

                        state_borrow_745 = (zx_abi).zx_type_17{ .names = ((operand_744).fields).names, .types = ((operand_744).fields).types, };

                        var state_borrow_746: (zx_abi).zx_type_24 = undefined;

                        state_borrow_746 = (zx_abi).zx_type_24{ .children = (operand_744).children, .fields = (((operand_744).fields).zx_origin orelse (&state_borrow_745)), .first = (operand_744).first, .kind = (operand_744).kind, .label = (operand_744).label, .names = (operand_744).names, .second = (operand_744).second, };

                        const operand_747 = (zx_abi).zx_type_39{ .tables = ((operand_740).zx_origin orelse (&state_borrow_743)), .candidate = ((operand_744).zx_origin orelse (&state_borrow_746)), };

                        break :block_748 (try function_21(allocator, (&operand_747)));
                    });
                    const value_20: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = (if ((block_650: {
                        break :block_650 value_13;
                    } == @as(u64, 1))) block_657: {
                        const value_14: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_656: {
                            break :block_656 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_628).index, .request = (state_628).request, .state = block_655: {
                                const operand_651 = (state_628).state;
                                const operand_652 = block_653: {
                                    break :block_653 value_5;
                                };
                                const operand_654 = @as(u64, 2);

                                break :block_655 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_651).delta, .mapping = (operand_651).mapping, .origins = (operand_651).origins, .references = operand_652, .status = operand_654, });
                            }, });
                        };

                        break :block_657 value_14;
                    } else block_690: {
                        const value_15: u32 = (if ((block_688: {
                            break :block_688 value_13;
                        } == @as(u64, 0))) (try function_2(allocator, (@as(u64, (((value_3).base).kinds).len) + @as(u64, ((((state_628).state).delta).kinds).len)))) else (try function_2(allocator, (block_689: {
                            break :block_689 value_13;
                        } - @as(u64, 2)))));
                        const value_16: (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = (if ((block_683: {
                            break :block_683 value_13;
                        } == @as(u64, 0))) @as((zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b, block_687: {
                            break :block_687 (try function_9_buffered(allocator, block_686: {
                                const operand_684 = ((state_628).state).delta;
                                const operand_685 = value_6;

                                break :block_686 @as((zx_abi).value_zx_type_27_eb83b36bd9eb840e506cc8c01a38c13a9cdff0b6a9636a9eecf085d3c539269b, (zx_abi).value_zx_type_27_eb83b36bd9eb840e506cc8c01a38c13a9cdff0b6a9636a9eecf085d3c539269b{ .delta = operand_684, .candidate = operand_685, });
                            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), .lane_3 = (if (((buffers).lane_3 != null)) .{ .buffer = (&(((buffers).lane_3.?).buffer).*), .started = (&(((buffers).lane_3.?).started).*), } else null), .lane_4 = (if (((buffers).lane_4 != null)) .{ .buffer = (&(((buffers).lane_4.?).buffer).*), .started = (&(((buffers).lane_4.?).started).*), } else null), .lane_5 = (if (((buffers).lane_5 != null)) .{ .buffer = (&(((buffers).lane_5.?).buffer).*), .started = (&(((buffers).lane_5.?).started).*), } else null), .lane_6 = (if (((buffers).lane_6 != null)) .{ .buffer = (&(((buffers).lane_6.?).buffer).*), .started = (&(((buffers).lane_6.?).started).*), } else null), .lane_7 = (if (((buffers).lane_7 != null)) .{ .buffer = (&(((buffers).lane_7.?).buffer).*), .started = (&(((buffers).lane_7.?).started).*), } else null), }));
                        }) else ((state_628).state).delta);
                        const value_17: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if (((block_675: {
                            break :block_675 value_13;
                        } == @as(u64, 0)) and block_676: {
                            break :block_676 value_8;
                        })) @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, block_682: {
                            break :block_682 (try function_18_buffered(allocator, block_681: {
                                const operand_677 = ((state_628).state).origins;
                                const operand_678 = value_11;
                                const operand_679 = block_680: {
                                    break :block_680 value_15;
                                };

                                break :block_681 @as((zx_abi).value_zx_type_37_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39, (zx_abi).value_zx_type_37_ff33271d86407a1a4cc8db9426efc73a7ebf7b21ef43c997cf912489bc99bd39{ .bindings = operand_677, .origin = operand_678, .id = operand_679, });
                            }, .{ .lane_0 = (if (((buffers).lane_9 != null)) .{ .buffer = (&(((buffers).lane_9.?).buffer).*), .started = (&(((buffers).lane_9.?).started).*), } else null), .lane_1 = (if (((buffers).lane_10 != null)) .{ .buffer = (&(((buffers).lane_10.?).buffer).*), .started = (&(((buffers).lane_10.?).started).*), } else null), .lane_2 = (if (((buffers).lane_11 != null)) .{ .buffer = (&(((buffers).lane_11.?).buffer).*), .started = (&(((buffers).lane_11.?).started).*), } else null), .lane_3 = (if (((buffers).lane_12 != null)) .{ .buffer = (&(((buffers).lane_12.?).buffer).*), .started = (&(((buffers).lane_12.?).started).*), } else null), }));
                        }) else ((state_628).state).origins);
                        const value_18: []const u32 = block_674: {
                            const operand_667 = ((state_628).state).mapping;
                            const operand_669 = block_668: {
                                break :block_668 value_4;
                            };

                            if ((operand_669 >= (operand_667).len)) {
                                return error.IndexOutOfBounds;
                            }

                            const operand_671 = block_670: {
                                break :block_670 value_15;
                            };

                            break :block_674 @as([]const u32, (if (((buffers).lane_8 != null)) block_672: {
                                if ((!(((buffers).lane_8.?).started).*)) {
                                    (try ((((buffers).lane_8.?).buffer).*).appendSlice(allocator, operand_667));

                                    (((buffers).lane_8.?).started).* = true;
                                } else {
                                    (((((buffers).lane_8.?).buffer).*).items).len = (operand_667).len;
                                }

                                (((((buffers).lane_8.?).buffer).*).items)[@intCast(operand_669)] = operand_671;

                                break :block_672 ((((buffers).lane_8.?).buffer).*).items;
                            } else block_673: {
                                if ((!state_capacity_started_635)) {
                                    (try (state_capacity_634).appendSlice(allocator, operand_667));

                                    state_capacity_started_635 = true;
                                } else {
                                    ((state_capacity_634).items).len = (operand_667).len;
                                }

                                ((state_capacity_634).items)[@intCast(operand_669)] = operand_671;

                                break :block_673 (state_capacity_634).items;
                            }));
                        };
                        const value_19: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_666: {
                            break :block_666 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_628).index, .request = (state_628).request, .state = block_665: {
                                const operand_658 = block_659: {
                                    break :block_659 value_18;
                                };
                                const operand_660 = value_16;
                                const operand_661 = value_17;
                                const operand_662 = block_663: {
                                    break :block_663 value_5;
                                };
                                const operand_664 = @as(u64, 0);

                                break :block_665 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .mapping = operand_658, .delta = operand_660, .origins = operand_661, .references = operand_662, .status = operand_664, });
                            }, });
                        };

                        break :block_690 value_19;
                    });

                    break :block_778 value_20;
                });
                const value_22: u64 = (value_21).index;
                const value_23: (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa = block_637: {
                    break :block_637 @as((zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa, (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (block_636: {
                        break :block_636 value_22;
                    } + @as(u64, 1)), .request = (value_21).request, .state = (value_21).state, });
                };

                break :block_802 value_23;
            };
        }

        var state_owned_803: []const u32 = (&[_]u32{});

        errdefer (allocator).free(state_owned_803);

        if (state_capacity_started_635) {
            ((state_capacity_634).items).len = (((state_628).state).mapping).len;

            state_owned_803 = (try (state_capacity_634).toOwnedSlice(allocator));
        }

        if (state_capacity_started_635) {
            state_628 = (zx_abi).value_zx_type_55_7b8f40510d4ec3aa9dc7eaf9d16b32594418dab4b81c2a6f0b3c5a59566428aa{ .index = (state_628).index, .request = (state_628).request, .state = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = ((state_628).state).delta, .mapping = state_owned_803, .origins = ((state_628).state).origins, .references = ((state_628).state).references, .status = ((state_628).state).status, }), };
        }

        break :block_822 block_821: {
            break :block_821 (if (((state_628).zx_origin != null)) ((state_628).zx_origin.?).* else block_820: {
                break :block_820 (zx_abi).zx_type_55{ .index = (state_628).index, .request = (if ((((state_628).request).zx_origin != null)) ((state_628).request).zx_origin.? else block_813: {
                    const operand_812 = (try (allocator).create((zx_abi).zx_type_41));

                    (operand_812).* = (zx_abi).zx_type_41{ .base = (if (((((state_628).request).base).zx_origin != null)) (((state_628).request).base).zx_origin.? else block_805: {
                        const operand_804 = (try (allocator).create((zx_abi).zx_type_15));

                        (operand_804).* = (zx_abi).zx_type_15{ .children = (((state_628).request).base).children, .field_names = (((state_628).request).base).field_names, .field_types = (((state_628).request).base).field_types, .first = (((state_628).request).base).first, .kinds = (((state_628).request).base).kinds, .labels = (((state_628).request).base).labels, .names = (((state_628).request).base).names, .second = (((state_628).request).base).second, };

                        break :block_805 @as(*const (zx_abi).zx_type_15, operand_804);
                    }), .base_origins = (if (((((state_628).request).base_origins).zx_origin != null)) (((state_628).request).base_origins).zx_origin.? else block_807: {
                        const operand_806 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_806).* = (zx_abi).zx_type_34{ .ids = (((state_628).request).base_origins).ids, .kinds = (((state_628).request).base_origins).kinds, .members = (((state_628).request).base_origins).members, .owners = (((state_628).request).base_origins).owners, };

                        break :block_807 @as(*const (zx_abi).zx_type_34, operand_806);
                    }), .first = ((state_628).request).first, .origin_indices = ((state_628).request).origin_indices, .origins = (if (((((state_628).request).origins).zx_origin != null)) (((state_628).request).origins).zx_origin.? else block_809: {
                        const operand_808 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_808).* = (zx_abi).zx_type_34{ .ids = (((state_628).request).origins).ids, .kinds = (((state_628).request).origins).kinds, .members = (((state_628).request).origins).members, .owners = (((state_628).request).origins).owners, };

                        break :block_809 @as(*const (zx_abi).zx_type_34, operand_808);
                    }), .source = (if (((((state_628).request).source).zx_origin != null)) (((state_628).request).source).zx_origin.? else block_811: {
                        const operand_810 = (try (allocator).create((zx_abi).zx_type_15));

                        (operand_810).* = (zx_abi).zx_type_15{ .children = (((state_628).request).source).children, .field_names = (((state_628).request).source).field_names, .field_types = (((state_628).request).source).field_types, .first = (((state_628).request).source).first, .kinds = (((state_628).request).source).kinds, .labels = (((state_628).request).source).labels, .names = (((state_628).request).source).names, .second = (((state_628).request).source).second, };

                        break :block_811 @as(*const (zx_abi).zx_type_15, operand_810);
                    }), };

                    break :block_813 @as(*const (zx_abi).zx_type_41, operand_812);
                }), .state = (if ((((state_628).state).zx_origin != null)) ((state_628).state).zx_origin.? else block_819: {
                    const operand_818 = (try (allocator).create((zx_abi).zx_type_42));

                    (operand_818).* = (zx_abi).zx_type_42{ .delta = (if (((((state_628).state).delta).zx_origin != null)) (((state_628).state).delta).zx_origin.? else block_815: {
                        const operand_814 = (try (allocator).create((zx_abi).zx_type_15));

                        (operand_814).* = (zx_abi).zx_type_15{ .children = (((state_628).state).delta).children, .field_names = (((state_628).state).delta).field_names, .field_types = (((state_628).state).delta).field_types, .first = (((state_628).state).delta).first, .kinds = (((state_628).state).delta).kinds, .labels = (((state_628).state).delta).labels, .names = (((state_628).state).delta).names, .second = (((state_628).state).delta).second, };

                        break :block_815 @as(*const (zx_abi).zx_type_15, operand_814);
                    }), .mapping = ((state_628).state).mapping, .origins = (if (((((state_628).state).origins).zx_origin != null)) (((state_628).state).origins).zx_origin.? else block_817: {
                        const operand_816 = (try (allocator).create((zx_abi).zx_type_34));

                        (operand_816).* = (zx_abi).zx_type_34{ .ids = (((state_628).state).origins).ids, .kinds = (((state_628).state).origins).kinds, .members = (((state_628).state).origins).members, .owners = (((state_628).state).origins).owners, };

                        break :block_817 @as(*const (zx_abi).zx_type_34, operand_816);
                    }), .references = ((state_628).state).references, .status = ((state_628).state).status, };

                    break :block_819 @as(*const (zx_abi).zx_type_42, operand_818);
                }), };
            });
        };
    }).state;
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_43) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_42 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = block_35: {
        const operand_31 = ((in).request).source;
        const operand_32 = ((in).request).base;
        const operand_33 = ((in).request).first;
        const operand_34 = (zx_abi).zx_type_22{ .source = operand_31, .target = operand_32, .first = operand_33, };

        break :block_35 (try function_7(allocator, (&operand_34)));
    };
    const switch_1 = value_1;

    if ((switch_1 == true)) {
        const value_2: []const u32 = (try function_8(allocator, block_30: {
            const operand_26 = ((in).state).mapping;
            const operand_27 = ((in).request).first;

            break :block_30 block_29: {
                const operand_28 = (try (allocator).create((zx_abi).zx_type_23));

                (operand_28).* = @as((zx_abi).zx_type_23, (zx_abi).zx_type_23{ .mapping = operand_26, .first = operand_27, });

                break :block_29 @as(*const (zx_abi).zx_type_23, operand_28);
            };
        }));
        const value_3: *const (zx_abi).zx_type_42 = block_25: {
            const operand_17 = block_16: {
                const operand_7 = (in).request;
                const operand_8 = block_13: {
                    const operand_9 = (in).state;
                    const operand_10 = value_2;

                    break :block_13 block_12: {
                        const operand_11 = (try (allocator).create((zx_abi).zx_type_42));

                        (operand_11).* = @as((zx_abi).zx_type_42, (zx_abi).zx_type_42{ .delta = (operand_9).delta, .mapping = operand_10, .origins = (operand_9).origins, .references = (operand_9).references, .status = (operand_9).status, });

                        break :block_12 @as(*const (zx_abi).zx_type_42, operand_11);
                    };
                };

                break :block_16 block_15: {
                    const operand_14 = (try (allocator).create((zx_abi).zx_type_43));

                    (operand_14).* = @as((zx_abi).zx_type_43, (zx_abi).zx_type_43{ .request = operand_7, .state = operand_8, });

                    break :block_15 @as(*const (zx_abi).zx_type_43, operand_14);
                };
            };
            const operand_18 = (try function_22_value(allocator, (zx_abi).value_zx_type_43_76edbce8b833ad8fc4a424ad25e03d4bc8082e4a04d7fc427f9bd621935b8ee6{ .request = (zx_abi).value_zx_type_41_3540ff82cd7401f2790fb0b97d3e60eb4ca97c3dede3a7b74038ab46d2dcac57{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_17).request).base).children, .field_names = (((operand_17).request).base).field_names, .field_types = (((operand_17).request).base).field_types, .first = (((operand_17).request).base).first, .kinds = (((operand_17).request).base).kinds, .labels = (((operand_17).request).base).labels, .names = (((operand_17).request).base).names, .second = (((operand_17).request).base).second, .zx_origin = ((operand_17).request).base, }, .base_origins = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_17).request).base_origins).ids, .kinds = (((operand_17).request).base_origins).kinds, .members = (((operand_17).request).base_origins).members, .owners = (((operand_17).request).base_origins).owners, .zx_origin = ((operand_17).request).base_origins, }, .first = ((operand_17).request).first, .origin_indices = ((operand_17).request).origin_indices, .origins = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_17).request).origins).ids, .kinds = (((operand_17).request).origins).kinds, .members = (((operand_17).request).origins).members, .owners = (((operand_17).request).origins).owners, .zx_origin = ((operand_17).request).origins, }, .source = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_17).request).source).children, .field_names = (((operand_17).request).source).field_names, .field_types = (((operand_17).request).source).field_types, .first = (((operand_17).request).source).first, .kinds = (((operand_17).request).source).kinds, .labels = (((operand_17).request).source).labels, .names = (((operand_17).request).source).names, .second = (((operand_17).request).source).second, .zx_origin = ((operand_17).request).source, }, .zx_origin = (operand_17).request, }, .state = (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_17).state).delta).children, .field_names = (((operand_17).state).delta).field_names, .field_types = (((operand_17).state).delta).field_types, .first = (((operand_17).state).delta).first, .kinds = (((operand_17).state).delta).kinds, .labels = (((operand_17).state).delta).labels, .names = (((operand_17).state).delta).names, .second = (((operand_17).state).delta).second, .zx_origin = ((operand_17).state).delta, }, .mapping = ((operand_17).state).mapping, .origins = (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .ids = (((operand_17).state).origins).ids, .kinds = (((operand_17).state).origins).kinds, .members = (((operand_17).state).origins).members, .owners = (((operand_17).state).origins).owners, .zx_origin = ((operand_17).state).origins, }, .references = ((operand_17).state).references, .status = ((operand_17).state).status, .zx_origin = (operand_17).state, }, .zx_origin = operand_17, }));

            break :block_25 (if (((operand_18).zx_origin != null)) (operand_18).zx_origin.? else block_24: {
                const operand_23 = (try (allocator).create((zx_abi).zx_type_42));

                (operand_23).* = (zx_abi).zx_type_42{ .delta = (if ((((operand_18).delta).zx_origin != null)) ((operand_18).delta).zx_origin.? else block_20: {
                    const operand_19 = (try (allocator).create((zx_abi).zx_type_15));

                    (operand_19).* = (zx_abi).zx_type_15{ .children = ((operand_18).delta).children, .field_names = ((operand_18).delta).field_names, .field_types = ((operand_18).delta).field_types, .first = ((operand_18).delta).first, .kinds = ((operand_18).delta).kinds, .labels = ((operand_18).delta).labels, .names = ((operand_18).delta).names, .second = ((operand_18).delta).second, };

                    break :block_20 @as(*const (zx_abi).zx_type_15, operand_19);
                }), .mapping = (operand_18).mapping, .origins = (if ((((operand_18).origins).zx_origin != null)) ((operand_18).origins).zx_origin.? else block_22: {
                    const operand_21 = (try (allocator).create((zx_abi).zx_type_34));

                    (operand_21).* = (zx_abi).zx_type_34{ .ids = ((operand_18).origins).ids, .kinds = ((operand_18).origins).kinds, .members = ((operand_18).origins).members, .owners = ((operand_18).origins).owners, };

                    break :block_22 @as(*const (zx_abi).zx_type_34, operand_21);
                }), .references = (operand_18).references, .status = (operand_18).status, };

                break :block_24 @as(*const (zx_abi).zx_type_42, operand_23);
            });
        };

        return value_3;
    } else {
        return block_6: {
            const operand_2 = (in).state;
            const operand_3 = @as(u64, 3);

            break :block_6 block_5: {
                const operand_4 = (try (allocator).create((zx_abi).zx_type_42));

                (operand_4).* = @as((zx_abi).zx_type_42, (zx_abi).zx_type_42{ .delta = (operand_2).delta, .mapping = (operand_2).mapping, .origins = (operand_2).origins, .references = (operand_2).references, .status = operand_3, });

                break :block_5 @as(*const (zx_abi).zx_type_42, operand_4);
            };
        };
    }
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_43_76edbce8b833ad8fc4a424ad25e03d4bc8082e4a04d7fc427f9bd621935b8ee6) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9 {
    @setRuntimeSafety(true);

    const value_1: bool = block_67: {
        const operand_55 = ((in).request).source;

        var state_borrow_56: (zx_abi).zx_type_15 = undefined;

        state_borrow_56 = (zx_abi).zx_type_15{ .children = (operand_55).children, .field_names = (operand_55).field_names, .field_types = (operand_55).field_types, .first = (operand_55).first, .kinds = (operand_55).kinds, .labels = (operand_55).labels, .names = (operand_55).names, .second = (operand_55).second, };

        const operand_57 = ((operand_55).zx_origin orelse (&state_borrow_56));
        const operand_58 = ((in).request).base;

        var state_borrow_59: (zx_abi).zx_type_15 = undefined;

        state_borrow_59 = (zx_abi).zx_type_15{ .children = (operand_58).children, .field_names = (operand_58).field_names, .field_types = (operand_58).field_types, .first = (operand_58).first, .kinds = (operand_58).kinds, .labels = (operand_58).labels, .names = (operand_58).names, .second = (operand_58).second, };

        const operand_60 = ((operand_58).zx_origin orelse (&state_borrow_59));
        const operand_61 = ((in).request).first;
        const operand_62 = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (operand_57).children, .field_names = (operand_57).field_names, .field_types = (operand_57).field_types, .first = (operand_57).first, .kinds = (operand_57).kinds, .labels = (operand_57).labels, .names = (operand_57).names, .second = (operand_57).second, .zx_origin = operand_57, };

        var state_borrow_63: (zx_abi).zx_type_15 = undefined;

        state_borrow_63 = (zx_abi).zx_type_15{ .children = (operand_62).children, .field_names = (operand_62).field_names, .field_types = (operand_62).field_types, .first = (operand_62).first, .kinds = (operand_62).kinds, .labels = (operand_62).labels, .names = (operand_62).names, .second = (operand_62).second, };

        const operand_64 = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (operand_60).children, .field_names = (operand_60).field_names, .field_types = (operand_60).field_types, .first = (operand_60).first, .kinds = (operand_60).kinds, .labels = (operand_60).labels, .names = (operand_60).names, .second = (operand_60).second, .zx_origin = operand_60, };

        var state_borrow_65: (zx_abi).zx_type_15 = undefined;

        state_borrow_65 = (zx_abi).zx_type_15{ .children = (operand_64).children, .field_names = (operand_64).field_names, .field_types = (operand_64).field_types, .first = (operand_64).first, .kinds = (operand_64).kinds, .labels = (operand_64).labels, .names = (operand_64).names, .second = (operand_64).second, };

        const operand_66 = (zx_abi).zx_type_22{ .source = ((operand_62).zx_origin orelse (&state_borrow_63)), .target = ((operand_64).zx_origin orelse (&state_borrow_65)), .first = operand_61, };

        break :block_67 (try function_7(allocator, (&operand_66)));
    };
    const switch_36 = block_37: {
        break :block_37 value_1;
    };

    if ((switch_36 == true)) {
        const value_2: []const u32 = block_54: {
            const operand_52 = block_51: {
                const operand_49 = ((in).state).mapping;
                const operand_50 = ((in).request).first;

                break :block_51 @as((zx_abi).value_zx_type_23_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_23_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .mapping = operand_49, .first = operand_50, });
            };

            var state_borrow_53: (zx_abi).zx_type_23 = undefined;

            state_borrow_53 = (zx_abi).zx_type_23{ .first = (operand_52).first, .mapping = (operand_52).mapping, };

            break :block_54 (try function_8(allocator, ((operand_52).zx_origin orelse (&state_borrow_53))));
        };
        const value_3: (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9 = block_48: {
            break :block_48 (try function_22_value(allocator, block_47: {
                const operand_41 = (in).request;
                const operand_42 = block_46: {
                    const operand_43 = (in).state;
                    const operand_44 = block_45: {
                        break :block_45 value_2;
                    };

                    break :block_46 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_43).delta, .mapping = operand_44, .origins = (operand_43).origins, .references = (operand_43).references, .status = (operand_43).status, });
                };

                break :block_47 @as((zx_abi).value_zx_type_43_76edbce8b833ad8fc4a424ad25e03d4bc8082e4a04d7fc427f9bd621935b8ee6, (zx_abi).value_zx_type_43_76edbce8b833ad8fc4a424ad25e03d4bc8082e4a04d7fc427f9bd621935b8ee6{ .request = operand_41, .state = operand_42, });
            }));
        };

        return value_3;
    } else {
        return block_40: {
            const operand_38 = (in).state;
            const operand_39 = @as(u64, 3);

            break :block_40 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_38).delta, .mapping = (operand_38).mapping, .origins = (operand_38).origins, .references = (operand_38).references, .status = operand_39, });
        };
    }
}

pub fn executeBuffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_43_76edbce8b833ad8fc4a424ad25e03d4bc8082e4a04d7fc427f9bd621935b8ee6, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_4: ?struct {
        buffer: *(std).ArrayList(u8),
        started: *bool,
    },
    lane_5: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_6: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_7: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_8: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_9: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_10: ?struct {
        buffer: *(std).ArrayList(u8),
        started: *bool,
    },
    lane_11: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_12: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_13: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
}) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9 {
    @setRuntimeSafety(true);

    const value_1: bool = block_99: {
        const operand_87 = ((in).request).source;

        var state_borrow_88: (zx_abi).zx_type_15 = undefined;

        state_borrow_88 = (zx_abi).zx_type_15{ .children = (operand_87).children, .field_names = (operand_87).field_names, .field_types = (operand_87).field_types, .first = (operand_87).first, .kinds = (operand_87).kinds, .labels = (operand_87).labels, .names = (operand_87).names, .second = (operand_87).second, };

        const operand_89 = ((operand_87).zx_origin orelse (&state_borrow_88));
        const operand_90 = ((in).request).base;

        var state_borrow_91: (zx_abi).zx_type_15 = undefined;

        state_borrow_91 = (zx_abi).zx_type_15{ .children = (operand_90).children, .field_names = (operand_90).field_names, .field_types = (operand_90).field_types, .first = (operand_90).first, .kinds = (operand_90).kinds, .labels = (operand_90).labels, .names = (operand_90).names, .second = (operand_90).second, };

        const operand_92 = ((operand_90).zx_origin orelse (&state_borrow_91));
        const operand_93 = ((in).request).first;
        const operand_94 = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (operand_89).children, .field_names = (operand_89).field_names, .field_types = (operand_89).field_types, .first = (operand_89).first, .kinds = (operand_89).kinds, .labels = (operand_89).labels, .names = (operand_89).names, .second = (operand_89).second, .zx_origin = operand_89, };

        var state_borrow_95: (zx_abi).zx_type_15 = undefined;

        state_borrow_95 = (zx_abi).zx_type_15{ .children = (operand_94).children, .field_names = (operand_94).field_names, .field_types = (operand_94).field_types, .first = (operand_94).first, .kinds = (operand_94).kinds, .labels = (operand_94).labels, .names = (operand_94).names, .second = (operand_94).second, };

        const operand_96 = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (operand_92).children, .field_names = (operand_92).field_names, .field_types = (operand_92).field_types, .first = (operand_92).first, .kinds = (operand_92).kinds, .labels = (operand_92).labels, .names = (operand_92).names, .second = (operand_92).second, .zx_origin = operand_92, };

        var state_borrow_97: (zx_abi).zx_type_15 = undefined;

        state_borrow_97 = (zx_abi).zx_type_15{ .children = (operand_96).children, .field_names = (operand_96).field_names, .field_types = (operand_96).field_types, .first = (operand_96).first, .kinds = (operand_96).kinds, .labels = (operand_96).labels, .names = (operand_96).names, .second = (operand_96).second, };

        const operand_98 = (zx_abi).zx_type_22{ .source = ((operand_94).zx_origin orelse (&state_borrow_95)), .target = ((operand_96).zx_origin orelse (&state_borrow_97)), .first = operand_93, };

        break :block_99 (try function_7(allocator, (&operand_98)));
    };
    const switch_68 = block_69: {
        break :block_69 value_1;
    };

    if ((switch_68 == true)) {
        const value_2: []const u32 = block_86: {
            const operand_84 = block_83: {
                const operand_81 = ((in).state).mapping;
                const operand_82 = ((in).request).first;

                break :block_83 @as((zx_abi).value_zx_type_23_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_23_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .mapping = operand_81, .first = operand_82, });
            };

            var state_borrow_85: (zx_abi).zx_type_23 = undefined;

            state_borrow_85 = (zx_abi).zx_type_23{ .first = (operand_84).first, .mapping = (operand_84).mapping, };

            break :block_86 (try function_8_buffered(allocator, ((operand_84).zx_origin orelse (&state_borrow_85)), .{ .lane_0 = (if (((buffers).lane_8 != null)) .{ .buffer = (&(((buffers).lane_8.?).buffer).*), .started = (&(((buffers).lane_8.?).started).*), } else null), }));
        };
        const value_3: (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9 = @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, block_80: {
            break :block_80 (try function_22_buffered(allocator, block_79: {
                const operand_73 = (in).request;
                const operand_74 = block_78: {
                    const operand_75 = (in).state;
                    const operand_76 = block_77: {
                        break :block_77 value_2;
                    };

                    break :block_78 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_75).delta, .mapping = operand_76, .origins = (operand_75).origins, .references = (operand_75).references, .status = (operand_75).status, });
                };

                break :block_79 @as((zx_abi).value_zx_type_43_76edbce8b833ad8fc4a424ad25e03d4bc8082e4a04d7fc427f9bd621935b8ee6, (zx_abi).value_zx_type_43_76edbce8b833ad8fc4a424ad25e03d4bc8082e4a04d7fc427f9bd621935b8ee6{ .request = operand_73, .state = operand_74, });
            }, .{ .lane_0 = (if (((buffers).lane_0 != null)) .{ .buffer = (&(((buffers).lane_0.?).buffer).*), .started = (&(((buffers).lane_0.?).started).*), } else null), .lane_1 = (if (((buffers).lane_1 != null)) .{ .buffer = (&(((buffers).lane_1.?).buffer).*), .started = (&(((buffers).lane_1.?).started).*), } else null), .lane_2 = (if (((buffers).lane_2 != null)) .{ .buffer = (&(((buffers).lane_2.?).buffer).*), .started = (&(((buffers).lane_2.?).started).*), } else null), .lane_3 = (if (((buffers).lane_3 != null)) .{ .buffer = (&(((buffers).lane_3.?).buffer).*), .started = (&(((buffers).lane_3.?).started).*), } else null), .lane_4 = (if (((buffers).lane_4 != null)) .{ .buffer = (&(((buffers).lane_4.?).buffer).*), .started = (&(((buffers).lane_4.?).started).*), } else null), .lane_5 = (if (((buffers).lane_5 != null)) .{ .buffer = (&(((buffers).lane_5.?).buffer).*), .started = (&(((buffers).lane_5.?).started).*), } else null), .lane_6 = (if (((buffers).lane_6 != null)) .{ .buffer = (&(((buffers).lane_6.?).buffer).*), .started = (&(((buffers).lane_6.?).started).*), } else null), .lane_7 = (if (((buffers).lane_7 != null)) .{ .buffer = (&(((buffers).lane_7.?).buffer).*), .started = (&(((buffers).lane_7.?).started).*), } else null), .lane_8 = (if (((buffers).lane_8 != null)) .{ .buffer = (&(((buffers).lane_8.?).buffer).*), .started = (&(((buffers).lane_8.?).started).*), } else null), .lane_9 = (if (((buffers).lane_9 != null)) .{ .buffer = (&(((buffers).lane_9.?).buffer).*), .started = (&(((buffers).lane_9.?).started).*), } else null), .lane_10 = (if (((buffers).lane_10 != null)) .{ .buffer = (&(((buffers).lane_10.?).buffer).*), .started = (&(((buffers).lane_10.?).started).*), } else null), .lane_11 = (if (((buffers).lane_11 != null)) .{ .buffer = (&(((buffers).lane_11.?).buffer).*), .started = (&(((buffers).lane_11.?).started).*), } else null), .lane_12 = (if (((buffers).lane_12 != null)) .{ .buffer = (&(((buffers).lane_12.?).buffer).*), .started = (&(((buffers).lane_12.?).started).*), } else null), .lane_13 = (if (((buffers).lane_13 != null)) .{ .buffer = (&(((buffers).lane_13.?).buffer).*), .started = (&(((buffers).lane_13.?).started).*), } else null), }));
        });

        return value_3;
    } else {
        return block_72: {
            const operand_70 = (in).state;
            const operand_71 = @as(u64, 3);

            break :block_72 @as((zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9, (zx_abi).value_zx_type_42_8b4ecbd311ed19268e0754ff4c3c07911e3e405dfd543929a30efbb3d2601ec9{ .delta = (operand_70).delta, .mapping = (operand_70).mapping, .origins = (operand_70).origins, .references = (operand_70).references, .status = operand_71, });
        };
    }
}

pub const buffer_lanes = .{ .{ .slot = "lane_0", .input = .{ "state", "delta", "children", }, .output = .{ "delta", "children", }, }, .{ .slot = "lane_1", .input = .{ "state", "delta", "field_names", }, .output = .{ "delta", "field_names", }, }, .{ .slot = "lane_2", .input = .{ "state", "delta", "field_types", }, .output = .{ "delta", "field_types", }, }, .{ .slot = "lane_3", .input = .{ "state", "delta", "first", }, .output = .{ "delta", "first", }, }, .{ .slot = "lane_4", .input = .{ "state", "delta", "kinds", }, .output = .{ "delta", "kinds", }, }, .{ .slot = "lane_5", .input = .{ "state", "delta", "labels", }, .output = .{ "delta", "labels", }, }, .{ .slot = "lane_6", .input = .{ "state", "delta", "names", }, .output = .{ "delta", "names", }, }, .{ .slot = "lane_7", .input = .{ "state", "delta", "second", }, .output = .{ "delta", "second", }, }, .{ .slot = "lane_8", .input = .{ "state", "mapping", }, .output = .{ "mapping", }, }, .{ .slot = "lane_9", .input = .{ "state", "origins", "ids", }, .output = .{ "origins", "ids", }, }, .{ .slot = "lane_10", .input = .{ "state", "origins", "kinds", }, .output = .{ "origins", "kinds", }, }, .{ .slot = "lane_11", .input = .{ "state", "origins", "members", }, .output = .{ "origins", "members", }, }, .{ .slot = "lane_12", .input = .{ "state", "origins", "owners", }, .output = .{ "origins", "owners", }, }, .{ .slot = "lane_13", .input = .{ "state", "references", }, .output = .{ "references", }, }, };

