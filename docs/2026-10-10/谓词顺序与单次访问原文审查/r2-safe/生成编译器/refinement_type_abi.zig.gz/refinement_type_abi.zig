pub const zx_type_11 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_15 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_16 = struct {
    base: *const zx_type_15,
    delta: *const zx_type_15,
};

pub const zx_type_17 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_18 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    second: u32,
};

pub const zx_type_19 = struct {
    id: u32,
    tables: *const zx_type_16,
};

pub const zx_type_20 = struct {
    children: []const u32,
    fields: *const zx_type_17,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_21 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_22 = struct {
    delta: *const zx_type_15,
    id: u32,
};

pub const zx_type_23 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
};

pub const zx_type_24 = struct {
    captures: u64,
    nonnull: u64,
};

pub const zx_type_25 = struct {
    facts: *const zx_type_23,
    symbol: u32,
};

pub const zx_type_26 = struct {
    facts: *const zx_type_23,
    symbol: u32,
    tables: *const zx_type_16,
    type_id: u32,
};

pub const zx_type_27 = struct {
    found: bool,
    index: u64,
    symbol: u32,
    values: []const u32,
};

pub const zx_type_28 = struct { *const zx_type_26, };

pub const zx_type_29 = struct { *const zx_type_26, u32, };

pub const value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
    zx_origin: ?*const zx_type_15 = null,
};

pub const value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9 = struct {
    base: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    delta: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_18 = null,
};

pub const value_zx_type_19_f08fcb4e07c58cc783aca9d5b2400d2a67a6fed4661e21bffce688804d6b144d = struct {
    id: u32,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_20_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_21 = null,
};

pub const value_zx_type_22_3fd235e03c65a6809dbfc1f8c9af05ad3740e7bdb3ee2ec0b25cf4f091780922 = struct {
    delta: value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    id: u32,
    zx_origin: ?*const zx_type_22 = null,
};

pub const value_zx_type_23_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    capture_errors: []const u32,
    capture_results: []const u32,
    nonnull: []const u32,
    zx_origin: ?*const zx_type_23 = null,
};

pub const value_zx_type_24_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    captures: u64,
    nonnull: u64,
    zx_origin: ?*const zx_type_24 = null,
};

pub const value_zx_type_25_654b20ccf64f2ca64b6802425f9952e8447842f7a750a25aaabc98a2fcd9a52f = struct {
    facts: value_zx_type_23_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    symbol: u32,
    zx_origin: ?*const zx_type_25 = null,
};

pub const value_zx_type_26_5e32f7140395018d5dc9ba0f647610d0dedbb2e498ffcd612f069b39c80e9c01 = struct {
    facts: value_zx_type_23_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    symbol: u32,
    tables: value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9,
    type_id: u32,
    zx_origin: ?*const zx_type_26 = null,
};

pub const value_zx_type_27_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    found: bool,
    index: u64,
    symbol: u32,
    values: []const u32,
    zx_origin: ?*const zx_type_27 = null,
};

pub const value_zx_type_28_fd36ad14780ef604781f7b4e35d3a4f2289d6a5f5ea3163d0027418883d3d60f = struct { value_zx_type_26_5e32f7140395018d5dc9ba0f647610d0dedbb2e498ffcd612f069b39c80e9c01, ?*const zx_type_28, };

pub const value_zx_type_29_195d9307b19148457a732a55652d8bf85bac0a73dfdd0536757bdbc872a29610 = struct { value_zx_type_26_5e32f7140395018d5dc9ba0f647610d0dedbb2e498ffcd612f069b39c80e9c01, u32, ?*const zx_type_29, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const widenByte = struct {
            pub const Input = u8;
            pub const Output = u64;
            pub const InputValue = u8;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
};

