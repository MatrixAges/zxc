const std = @import("std");

const zx_native_0 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_14 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .field_names = zx_shape_14, .field_types = zx_shape_13, .first = zx_shape_13, .kinds = zx_shape_12, .labels = zx_shape_14, .names = zx_shape_14, .second = zx_shape_13, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .base = zx_shape_15, .delta = zx_shape_15, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .names = zx_shape_14, .types = zx_shape_13, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .delta = zx_shape_1, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .second = zx_shape_4, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .fields = zx_shape_17, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .names = zx_shape_14, .second = zx_shape_4, }, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .id = zx_shape_4, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .delta = zx_shape_15, .id = zx_shape_4, }, };

const zx_shape_22 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .count = zx_shape_5, .field_names = zx_shape_14, .field_types = zx_shape_13, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .names = zx_shape_14, .offset = zx_shape_5, .second = zx_shape_4, }, };

const zx_shape_23 = .{ .kind = .object, .fields = .{ .left = zx_shape_22, .right = zx_shape_22, }, };

const zx_shape_24 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .table = zx_shape_15, }, };

const zx_shape_25 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_19, .id = zx_shape_4, .tables = zx_shape_16, }, };

const zx_shape_26 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_19, .tables = zx_shape_16, }, };

const zx_shape_27 = .{ .kind = .optional, .child = zx_shape_4, };

const zx_shape_28 = .{ .kind = .object, .fields = .{ .equal = zx_shape_1, .index = zx_shape_5, .left = zx_shape_22, .right = zx_shape_22, }, };

const zx_shape_29 = .{ .kind = .object, .fields = .{ .candidate = zx_shape_19, .count = zx_shape_5, .found = zx_shape_1, .id = zx_shape_4, .index = zx_shape_5, .tables = zx_shape_16, }, };

const zx_shape_30 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_26, }, };

const zx_shape_31 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_26, .@"1" = zx_shape_20, }, };

pub const input_shape = zx_shape_26;

pub const output_shape = zx_shape_27;

pub const Input = *const (zx_abi).zx_type_26;

pub const Output = ?u32;

fn function_0(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: u8) error{ }!u64 {
    const native_result = (zx_native_0).widenByte(in);

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_19) error{ OutOfMemory, }!*const (zx_abi).zx_type_22 {
    @setRuntimeSafety(true);

    const value_1: u64 = block_15: {
        const operand_14 = (in).kind;

        break :block_15 (if ((operand_14 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_14 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_13: {
        const operand_1 = (in).kind;
        const operand_2 = (in).first;
        const operand_3 = (in).second;
        const operand_4 = (in).label;
        const operand_5 = @as(u64, 0);
        const operand_6 = value_1;
        const operand_7 = (in).children;
        const operand_8 = ((in).fields).names;
        const operand_9 = ((in).fields).types;
        const operand_10 = (in).names;

        break :block_13 block_12: {
            const operand_11 = (try (allocator).create((zx_abi).zx_type_22));

            (operand_11).* = @as((zx_abi).zx_type_22, (zx_abi).zx_type_22{ .kind = operand_1, .first = operand_2, .second = operand_3, .label = operand_4, .offset = operand_5, .count = operand_6, .children = operand_7, .field_names = operand_8, .field_types = operand_9, .names = operand_10, });

            break :block_12 @as(*const (zx_abi).zx_type_22, operand_11);
        };
    };
}

fn function_3_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384) error{ OutOfMemory, }!(zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: u64 = block_29: {
        const operand_28 = (in).kind;

        break :block_29 (if ((operand_28 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_28 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_27: {
        const operand_16 = (in).kind;
        const operand_17 = (in).first;
        const operand_18 = (in).second;
        const operand_19 = (in).label;
        const operand_20 = @as(u64, 0);
        const operand_21 = block_22: {
            break :block_22 value_1;
        };
        const operand_23 = (in).children;
        const operand_24 = ((in).fields).names;
        const operand_25 = ((in).fields).types;
        const operand_26 = (in).names;

        break :block_27 @as((zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_16, .first = operand_17, .second = operand_18, .label = operand_19, .offset = operand_20, .count = operand_21, .children = operand_23, .field_names = operand_24, .field_types = operand_25, .names = operand_26, });
    };
}

fn function_3_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ OutOfMemory, }!(zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    _ = allocator;

    _ = buffers;

    const value_1: u64 = block_43: {
        const operand_42 = (in).kind;

        break :block_43 (if ((operand_42 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_42 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_41: {
        const operand_30 = (in).kind;
        const operand_31 = (in).first;
        const operand_32 = (in).second;
        const operand_33 = (in).label;
        const operand_34 = @as(u64, 0);
        const operand_35 = block_36: {
            break :block_36 value_1;
        };
        const operand_37 = (in).children;
        const operand_38 = ((in).fields).names;
        const operand_39 = ((in).fields).types;
        const operand_40 = (in).names;

        break :block_41 @as((zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_30, .first = operand_31, .second = operand_32, .label = operand_33, .offset = operand_34, .count = operand_35, .children = operand_37, .field_names = operand_38, .field_types = operand_39, .names = operand_40, });
    };
}

fn function_3_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_19, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ OutOfMemory, }!*const (zx_abi).zx_type_22 {
    @setRuntimeSafety(true);

    _ = buffers;

    const value_1: u64 = block_58: {
        const operand_57 = (in).kind;

        break :block_58 (if ((operand_57 == @as((zx_abi).zx_type_11, .Object))) @as(u64, (((in).fields).names).len) else (if ((operand_57 == @as((zx_abi).zx_type_11, .Tuple))) @as(u64, ((in).children).len) else @as(u64, ((in).names).len)));
    };

    return block_56: {
        const operand_44 = (in).kind;
        const operand_45 = (in).first;
        const operand_46 = (in).second;
        const operand_47 = (in).label;
        const operand_48 = @as(u64, 0);
        const operand_49 = value_1;
        const operand_50 = (in).children;
        const operand_51 = ((in).fields).names;
        const operand_52 = ((in).fields).types;
        const operand_53 = (in).names;

        break :block_56 block_55: {
            const operand_54 = (try (allocator).create((zx_abi).zx_type_22));

            (operand_54).* = @as((zx_abi).zx_type_22, (zx_abi).zx_type_22{ .kind = operand_44, .first = operand_45, .second = operand_46, .label = operand_47, .offset = operand_48, .count = operand_49, .children = operand_50, .field_names = operand_51, .field_types = operand_52, .names = operand_53, });

            break :block_55 @as(*const (zx_abi).zx_type_22, operand_54);
        };
    };
}

fn function_4(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_23) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: (zx_abi).zx_type_22 = ((in).left).*;
    const value_2: (zx_abi).zx_type_22 = ((in).right).*;

    if ((((&value_1)).kind != ((&value_2)).kind)) {
        return false;
    }

    if ((((((&value_1)).kind == @as((zx_abi).zx_type_11, .Scalar)) or (((&value_1)).kind == @as((zx_abi).zx_type_11, .Optional))) or (((&value_1)).kind == @as((zx_abi).zx_type_11, .List)))) {
        return (((&value_1)).first == ((&value_2)).first);
    }

    if ((((&value_1)).kind == @as((zx_abi).zx_type_11, .Task))) {
        return ((((&value_1)).first == ((&value_2)).first) and (((&value_1)).second == ((&value_2)).second));
    }

    if ((((&value_1)).kind == @as((zx_abi).zx_type_11, .NativeReference))) {
        return block_56: {
            const operand_54 = ((&value_1)).label;
            const operand_55 = ((&value_2)).label;

            break :block_56 ((std).mem).eql(u8, operand_54, operand_55);
        };
    }

    if (((((&value_1)).kind == @as((zx_abi).zx_type_11, .Enumeration)) and (!block_53: {
        const operand_51 = ((&value_1)).label;
        const operand_52 = ((&value_2)).label;

        break :block_53 ((std).mem).eql(u8, operand_51, operand_52);
    }))) {
        return false;
    }

    if ((((&value_1)).count != ((&value_2)).count)) {
        return false;
    }

    return block_50: {
        const state_type_2 = struct {
            children: []const u32,
            count: u64,
            field_names: []const []const u8,
            field_types: []const u32,
            first: u32,
            kind: (zx_abi).zx_type_11,
            label: []const u8,
            names: []const []const u8,
            offset: u64,
            second: u32,
        };
        const state_type_3 = struct {
            equal: bool,
            index: u64,
            left: state_type_2,
            right: state_type_2,
        };
        const operand_13 = block_12: {
            const operand_6 = block_5: {
                const operand_4 = (&value_1);

                break :block_5 state_type_2{ .children = (operand_4).children, .count = (operand_4).count, .field_names = (operand_4).field_names, .field_types = (operand_4).field_types, .first = (operand_4).first, .kind = (operand_4).kind, .label = (operand_4).label, .names = (operand_4).names, .offset = (operand_4).offset, .second = (operand_4).second, };
            };
            const operand_9 = block_8: {
                const operand_7 = (&value_2);

                break :block_8 state_type_2{ .children = (operand_7).children, .count = (operand_7).count, .field_names = (operand_7).field_names, .field_types = (operand_7).field_types, .first = (operand_7).first, .kind = (operand_7).kind, .label = (operand_7).label, .names = (operand_7).names, .offset = (operand_7).offset, .second = (operand_7).second, };
            };
            const operand_10 = @as(u64, 0);
            const operand_11 = true;

            break :block_12 state_type_3{ .left = operand_6, .right = operand_9, .index = operand_10, .equal = operand_11, };
        };

        var state_1: state_type_3 = operand_13;

        var state_changed_14 = false;

        while (((state_1).equal and ((state_1).index < ((state_1).left).count))) {
            state_1 = block_49: {
                const value_5: u64 = (((state_1).left).offset + (state_1).index);
                const value_6: u64 = (((state_1).right).offset + (state_1).index);
                const value_7: bool = block_48: {
                    const operand_17 = ((state_1).left).kind;

                    break :block_48 (if ((operand_17 == @as((zx_abi).zx_type_11, .Object))) (block_41: {
                        const operand_39 = block_35: {
                            const operand_33 = ((state_1).left).field_names;
                            const operand_34 = value_5;

                            if ((operand_34 >= (operand_33).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_35 (operand_33)[@intCast(operand_34)];
                        };
                        const operand_40 = block_38: {
                            const operand_36 = ((state_1).right).field_names;
                            const operand_37 = value_6;

                            if ((operand_37 >= (operand_36).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_38 (operand_36)[@intCast(operand_37)];
                        };

                        break :block_41 ((std).mem).eql(u8, operand_39, operand_40);
                    } and (block_44: {
                        const operand_42 = ((state_1).left).field_types;
                        const operand_43 = value_5;

                        if ((operand_43 >= (operand_42).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_44 (operand_42)[@intCast(operand_43)];
                    } == block_47: {
                        const operand_45 = ((state_1).right).field_types;
                        const operand_46 = value_6;

                        if ((operand_46 >= (operand_45).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_47 (operand_45)[@intCast(operand_46)];
                    })) else (if ((operand_17 == @as((zx_abi).zx_type_11, .Tuple))) (block_29: {
                        const operand_27 = ((state_1).left).children;
                        const operand_28 = value_5;

                        if ((operand_28 >= (operand_27).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_29 (operand_27)[@intCast(operand_28)];
                    } == block_32: {
                        const operand_30 = ((state_1).right).children;
                        const operand_31 = value_6;

                        if ((operand_31 >= (operand_30).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_32 (operand_30)[@intCast(operand_31)];
                    }) else block_26: {
                        const operand_24 = block_20: {
                            const operand_18 = ((state_1).left).names;
                            const operand_19 = value_5;

                            if ((operand_19 >= (operand_18).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_20 (operand_18)[@intCast(operand_19)];
                        };
                        const operand_25 = block_23: {
                            const operand_21 = ((state_1).right).names;
                            const operand_22 = value_6;

                            if ((operand_22 >= (operand_21).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_23 (operand_21)[@intCast(operand_22)];
                        };

                        break :block_26 ((std).mem).eql(u8, operand_24, operand_25);
                    }));
                };
                const value_8: state_type_3 = block_16: {
                    break :block_16 state_type_3{ .equal = value_7, .index = (state_1).index, .left = (state_1).left, .right = (state_1).right, };
                };
                const value_9: u64 = (value_8).index;
                const value_10: state_type_3 = block_15: {
                    break :block_15 state_type_3{ .equal = (value_8).equal, .index = (value_9 + @as(u64, 1)), .left = (value_8).left, .right = (value_8).right, };
                };

                break :block_49 value_10;
            };

            state_changed_14 = true;
        }

        break :block_50 (state_1).equal;
    };
}

fn function_5(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_11 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_2: {
        const operand_1 = in;

        break :block_2 (if ((operand_1 == @as(u8, 0))) @as((zx_abi).zx_type_11, .Scalar) else (if ((operand_1 == @as(u8, 1))) @as((zx_abi).zx_type_11, .Object) else (if ((operand_1 == @as(u8, 2))) @as((zx_abi).zx_type_11, .Optional) else (if ((operand_1 == @as(u8, 3))) @as((zx_abi).zx_type_11, .List) else (if ((operand_1 == @as(u8, 4))) @as((zx_abi).zx_type_11, .Tuple) else (if ((operand_1 == @as(u8, 5))) @as((zx_abi).zx_type_11, .ErrorSet) else (if ((operand_1 == @as(u8, 6))) @as((zx_abi).zx_type_11, .Task) else (if ((operand_1 == @as(u8, 7))) @as((zx_abi).zx_type_11, .Enumeration) else @as((zx_abi).zx_type_11, .NativeReference)))))))));
    };
}

fn function_6(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_11 {
    @setRuntimeSafety(true);

    return (try function_5(allocator, in));
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_24) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_22 {
    @setRuntimeSafety(true);

    return block_31: {
        const operand_1 = (try function_6(allocator, block_4: {
            const operand_2 = ((in).table).kinds;
            const operand_3 = (in).index;

            if ((operand_3 >= (operand_2).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_4 (operand_2)[@intCast(operand_3)];
        }));
        const operand_5 = block_8: {
            const operand_6 = ((in).table).first;
            const operand_7 = (in).index;

            if ((operand_7 >= (operand_6).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_8 (operand_6)[@intCast(operand_7)];
        };
        const operand_9 = block_12: {
            const operand_10 = ((in).table).second;
            const operand_11 = (in).index;

            if ((operand_11 >= (operand_10).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_12 (operand_10)[@intCast(operand_11)];
        };
        const operand_13 = block_16: {
            const operand_14 = ((in).table).labels;
            const operand_15 = (in).index;

            if ((operand_15 >= (operand_14).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_16 (operand_14)[@intCast(operand_15)];
        };
        const operand_17 = (try function_0(allocator, block_20: {
            const operand_18 = ((in).table).first;
            const operand_19 = (in).index;

            if ((operand_19 >= (operand_18).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_20 (operand_18)[@intCast(operand_19)];
        }));
        const operand_21 = (try function_0(allocator, block_24: {
            const operand_22 = ((in).table).second;
            const operand_23 = (in).index;

            if ((operand_23 >= (operand_22).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_24 (operand_22)[@intCast(operand_23)];
        }));
        const operand_25 = ((in).table).children;
        const operand_26 = ((in).table).field_names;
        const operand_27 = ((in).table).field_types;
        const operand_28 = ((in).table).names;

        break :block_31 block_30: {
            const operand_29 = (try (allocator).create((zx_abi).zx_type_22));

            (operand_29).* = @as((zx_abi).zx_type_22, (zx_abi).zx_type_22{ .kind = operand_1, .first = operand_5, .second = operand_9, .label = operand_13, .offset = operand_17, .count = operand_21, .children = operand_25, .field_names = operand_26, .field_types = operand_27, .names = operand_28, });

            break :block_30 @as(*const (zx_abi).zx_type_22, operand_29);
        };
    };
}

fn function_7_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_24_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    return block_60: {
        const operand_32 = (try function_6(allocator, block_35: {
            const operand_33 = ((in).table).kinds;
            const operand_34 = (in).index;

            if ((operand_34 >= (operand_33).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_35 (operand_33)[@intCast(operand_34)];
        }));
        const operand_36 = block_39: {
            const operand_37 = ((in).table).first;
            const operand_38 = (in).index;

            if ((operand_38 >= (operand_37).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_39 (operand_37)[@intCast(operand_38)];
        };
        const operand_40 = block_43: {
            const operand_41 = ((in).table).second;
            const operand_42 = (in).index;

            if ((operand_42 >= (operand_41).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_43 (operand_41)[@intCast(operand_42)];
        };
        const operand_44 = block_47: {
            const operand_45 = ((in).table).labels;
            const operand_46 = (in).index;

            if ((operand_46 >= (operand_45).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_47 (operand_45)[@intCast(operand_46)];
        };
        const operand_48 = (try function_0(allocator, block_51: {
            const operand_49 = ((in).table).first;
            const operand_50 = (in).index;

            if ((operand_50 >= (operand_49).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_51 (operand_49)[@intCast(operand_50)];
        }));
        const operand_52 = (try function_0(allocator, block_55: {
            const operand_53 = ((in).table).second;
            const operand_54 = (in).index;

            if ((operand_54 >= (operand_53).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_55 (operand_53)[@intCast(operand_54)];
        }));
        const operand_56 = ((in).table).children;
        const operand_57 = ((in).table).field_names;
        const operand_58 = ((in).table).field_types;
        const operand_59 = ((in).table).names;

        break :block_60 @as((zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_32, .first = operand_36, .second = operand_40, .label = operand_44, .offset = operand_48, .count = operand_52, .children = operand_56, .field_names = operand_57, .field_types = operand_58, .names = operand_59, });
    };
}

fn function_7_buffered(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_24_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d {
    @setRuntimeSafety(true);

    _ = buffers;

    return block_89: {
        const operand_61 = (try function_6(allocator, block_64: {
            const operand_62 = ((in).table).kinds;
            const operand_63 = (in).index;

            if ((operand_63 >= (operand_62).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_64 (operand_62)[@intCast(operand_63)];
        }));
        const operand_65 = block_68: {
            const operand_66 = ((in).table).first;
            const operand_67 = (in).index;

            if ((operand_67 >= (operand_66).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_68 (operand_66)[@intCast(operand_67)];
        };
        const operand_69 = block_72: {
            const operand_70 = ((in).table).second;
            const operand_71 = (in).index;

            if ((operand_71 >= (operand_70).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_72 (operand_70)[@intCast(operand_71)];
        };
        const operand_73 = block_76: {
            const operand_74 = ((in).table).labels;
            const operand_75 = (in).index;

            if ((operand_75 >= (operand_74).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_76 (operand_74)[@intCast(operand_75)];
        };
        const operand_77 = (try function_0(allocator, block_80: {
            const operand_78 = ((in).table).first;
            const operand_79 = (in).index;

            if ((operand_79 >= (operand_78).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_80 (operand_78)[@intCast(operand_79)];
        }));
        const operand_81 = (try function_0(allocator, block_84: {
            const operand_82 = ((in).table).second;
            const operand_83 = (in).index;

            if ((operand_83 >= (operand_82).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_84 (operand_82)[@intCast(operand_83)];
        }));
        const operand_85 = ((in).table).children;
        const operand_86 = ((in).table).field_names;
        const operand_87 = ((in).table).field_types;
        const operand_88 = ((in).table).names;

        break :block_89 @as((zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d, (zx_abi).value_zx_type_22_da661b49334d413f36d3d895c2756a9e593006d5314c17c8350b6eb2653d308d{ .kind = operand_61, .first = operand_65, .second = operand_69, .label = operand_73, .offset = operand_77, .count = operand_81, .children = operand_85, .field_names = operand_86, .field_types = operand_87, .names = operand_88, });
    };
}

fn function_7_buffered_pointer(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_24, buffers: struct {
    lane_0: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_1: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
    lane_2: ?struct {
        buffer: *(std).ArrayList(u32),
        started: *bool,
    },
    lane_3: ?struct {
        buffer: *(std).ArrayList([]const u8),
        started: *bool,
    },
}) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_22 {
    @setRuntimeSafety(true);

    _ = buffers;

    return block_120: {
        const operand_90 = (try function_6(allocator, block_93: {
            const operand_91 = ((in).table).kinds;
            const operand_92 = (in).index;

            if ((operand_92 >= (operand_91).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_93 (operand_91)[@intCast(operand_92)];
        }));
        const operand_94 = block_97: {
            const operand_95 = ((in).table).first;
            const operand_96 = (in).index;

            if ((operand_96 >= (operand_95).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_97 (operand_95)[@intCast(operand_96)];
        };
        const operand_98 = block_101: {
            const operand_99 = ((in).table).second;
            const operand_100 = (in).index;

            if ((operand_100 >= (operand_99).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_101 (operand_99)[@intCast(operand_100)];
        };
        const operand_102 = block_105: {
            const operand_103 = ((in).table).labels;
            const operand_104 = (in).index;

            if ((operand_104 >= (operand_103).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_105 (operand_103)[@intCast(operand_104)];
        };
        const operand_106 = (try function_0(allocator, block_109: {
            const operand_107 = ((in).table).first;
            const operand_108 = (in).index;

            if ((operand_108 >= (operand_107).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_109 (operand_107)[@intCast(operand_108)];
        }));
        const operand_110 = (try function_0(allocator, block_113: {
            const operand_111 = ((in).table).second;
            const operand_112 = (in).index;

            if ((operand_112 >= (operand_111).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_113 (operand_111)[@intCast(operand_112)];
        }));
        const operand_114 = ((in).table).children;
        const operand_115 = ((in).table).field_names;
        const operand_116 = ((in).table).field_types;
        const operand_117 = ((in).table).names;

        break :block_120 block_119: {
            const operand_118 = (try (allocator).create((zx_abi).zx_type_22));

            (operand_118).* = @as((zx_abi).zx_type_22, (zx_abi).zx_type_22{ .kind = operand_90, .first = operand_94, .second = operand_98, .label = operand_102, .offset = operand_106, .count = operand_110, .children = operand_114, .field_names = operand_115, .field_types = operand_116, .names = operand_117, });

            break :block_119 @as(*const (zx_abi).zx_type_22, operand_118);
        };
    };
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_25) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_0(allocator, (in).id));
    const value_2: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_3: bool = (value_1 >= value_2);
    const value_4: (zx_abi).zx_type_15 = (if (value_3) (((in).tables).delta).* else (((in).tables).base).*);
    const value_5: u64 = (if (value_3) (value_1 - value_2) else value_1);

    return block_13: {
        const operand_1 = (&value_4);
        const operand_2 = value_5;
        const operand_3 = (zx_abi).zx_type_24{ .table = operand_1, .index = operand_2, };
        const operand_4 = (&operand_3);
        const operand_5 = (try function_7_value(allocator, (zx_abi).value_zx_type_24_e13f2ae2715b62f8bb48c4d65f0c60942a231b21f296c9a31710843cfcd55d77{ .index = (operand_4).index, .table = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_4).table).children, .field_names = ((operand_4).table).field_names, .field_types = ((operand_4).table).field_types, .first = ((operand_4).table).first, .kinds = ((operand_4).table).kinds, .labels = ((operand_4).table).labels, .names = ((operand_4).table).names, .second = ((operand_4).table).second, .zx_origin = (operand_4).table, }, .zx_origin = operand_4, }));

        var state_borrow_6: (zx_abi).zx_type_22 = undefined;

        state_borrow_6 = (zx_abi).zx_type_22{ .children = (operand_5).children, .count = (operand_5).count, .field_names = (operand_5).field_names, .field_types = (operand_5).field_types, .first = (operand_5).first, .kind = (operand_5).kind, .label = (operand_5).label, .names = (operand_5).names, .offset = (operand_5).offset, .second = (operand_5).second, };

        const operand_7 = ((operand_5).zx_origin orelse (&state_borrow_6));
        const operand_8 = (in).candidate;
        const operand_9 = (try function_3_value(allocator, (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_8).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_8).fields).names, .types = ((operand_8).fields).types, .zx_origin = (operand_8).fields, }, .first = (operand_8).first, .kind = (operand_8).kind, .label = (operand_8).label, .names = (operand_8).names, .second = (operand_8).second, .zx_origin = operand_8, }));

        var state_borrow_10: (zx_abi).zx_type_22 = undefined;

        state_borrow_10 = (zx_abi).zx_type_22{ .children = (operand_9).children, .count = (operand_9).count, .field_names = (operand_9).field_names, .field_types = (operand_9).field_types, .first = (operand_9).first, .kind = (operand_9).kind, .label = (operand_9).label, .names = (operand_9).names, .offset = (operand_9).offset, .second = (operand_9).second, };

        const operand_11 = ((operand_9).zx_origin orelse (&state_borrow_10));
        const operand_12 = (zx_abi).zx_type_23{ .left = operand_7, .right = operand_11, };

        break :block_13 (try function_4(allocator, (&operand_12)));
    };
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_26) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }!*const (zx_abi).zx_type_20 {
    @setRuntimeSafety(true);

    if (((((in).candidate).kind == @as((zx_abi).zx_type_11, .Enumeration)) or (((in).candidate).kind == @as((zx_abi).zx_type_11, .NativeReference)))) {
        return block_51: {
            const operand_47 = false;
            const operand_48 = @as(u32, 0);

            break :block_51 block_50: {
                const operand_49 = (try (allocator).create((zx_abi).zx_type_20));

                (operand_49).* = @as((zx_abi).zx_type_20, (zx_abi).zx_type_20{ .found = operand_47, .id = operand_48, });

                break :block_50 @as(*const (zx_abi).zx_type_20, operand_49);
            };
        };
    }

    const value_1: u32 = @as(u32, 0);
    const value_2: u64 = (@as(u64, ((((in).tables).base).kinds).len) + @as(u64, ((((in).tables).delta).kinds).len));

    return block_46: {
        const state_type_2 = struct {
            names: []const []const u8,
            types: []const u32,
        };
        const state_type_3 = struct {
            children: []const u32,
            fields: state_type_2,
            first: u32,
            kind: (zx_abi).zx_type_11,
            label: []const u8,
            names: []const []const u8,
            second: u32,
        };
        const state_type_4 = struct {
            children: []const u32,
            field_names: []const []const u8,
            field_types: []const u32,
            first: []const u32,
            kinds: []const u8,
            labels: []const []const u8,
            names: []const []const u8,
            second: []const u32,
        };
        const state_type_5 = struct {
            base: state_type_4,
            delta: state_type_4,
        };
        const state_type_6 = struct {
            candidate: state_type_3,
            count: u64,
            found: bool,
            id: u32,
            index: u64,
            tables: state_type_5,
        };
        const state_type_8 = struct {
            candidate: state_type_3,
            tables: state_type_5,
        };
        const operand_19 = block_18: {
            const operand_10 = (block_9: {
                const operand_7 = in;

                break :block_9 state_type_8{ .candidate = state_type_3{ .children = ((operand_7).candidate).children, .fields = state_type_2{ .names = (((operand_7).candidate).fields).names, .types = (((operand_7).candidate).fields).types, }, .first = ((operand_7).candidate).first, .kind = ((operand_7).candidate).kind, .label = ((operand_7).candidate).label, .names = ((operand_7).candidate).names, .second = ((operand_7).candidate).second, }, .tables = state_type_5{ .base = state_type_4{ .children = (((operand_7).tables).base).children, .field_names = (((operand_7).tables).base).field_names, .field_types = (((operand_7).tables).base).field_types, .first = (((operand_7).tables).base).first, .kinds = (((operand_7).tables).base).kinds, .labels = (((operand_7).tables).base).labels, .names = (((operand_7).tables).base).names, .second = (((operand_7).tables).base).second, }, .delta = state_type_4{ .children = (((operand_7).tables).delta).children, .field_names = (((operand_7).tables).delta).field_names, .field_types = (((operand_7).tables).delta).field_types, .first = (((operand_7).tables).delta).first, .kinds = (((operand_7).tables).delta).kinds, .labels = (((operand_7).tables).delta).labels, .names = (((operand_7).tables).delta).names, .second = (((operand_7).tables).delta).second, }, }, };
            }).tables;
            const operand_13 = (block_12: {
                const operand_11 = in;

                break :block_12 state_type_8{ .candidate = state_type_3{ .children = ((operand_11).candidate).children, .fields = state_type_2{ .names = (((operand_11).candidate).fields).names, .types = (((operand_11).candidate).fields).types, }, .first = ((operand_11).candidate).first, .kind = ((operand_11).candidate).kind, .label = ((operand_11).candidate).label, .names = ((operand_11).candidate).names, .second = ((operand_11).candidate).second, }, .tables = state_type_5{ .base = state_type_4{ .children = (((operand_11).tables).base).children, .field_names = (((operand_11).tables).base).field_names, .field_types = (((operand_11).tables).base).field_types, .first = (((operand_11).tables).base).first, .kinds = (((operand_11).tables).base).kinds, .labels = (((operand_11).tables).base).labels, .names = (((operand_11).tables).base).names, .second = (((operand_11).tables).base).second, }, .delta = state_type_4{ .children = (((operand_11).tables).delta).children, .field_names = (((operand_11).tables).delta).field_names, .field_types = (((operand_11).tables).delta).field_types, .first = (((operand_11).tables).delta).first, .kinds = (((operand_11).tables).delta).kinds, .labels = (((operand_11).tables).delta).labels, .names = (((operand_11).tables).delta).names, .second = (((operand_11).tables).delta).second, }, }, };
            }).candidate;
            const operand_14 = value_2;
            const operand_15 = @as(u64, 0);
            const operand_16 = false;
            const operand_17 = value_1;

            break :block_18 state_type_6{ .tables = operand_10, .candidate = operand_13, .count = operand_14, .index = operand_15, .found = operand_16, .id = operand_17, };
        };
        const state_type_26 = struct {
            candidate: state_type_3,
            id: u32,
            tables: state_type_5,
        };

        var state_1: state_type_6 = operand_19;

        var state_changed_20 = false;

        while (((!(state_1).found) and ((state_1).index < (state_1).count))) {
            state_1 = block_40: {
                const value_5: u32 = (try function_2(allocator, (state_1).index));
                const value_6: bool = block_39: {
                    const operand_31 = block_30: {
                        const operand_27 = (state_1).tables;
                        const operand_28 = value_5;
                        const operand_29 = (state_1).candidate;

                        break :block_30 state_type_26{ .tables = operand_27, .id = operand_28, .candidate = operand_29, };
                    };
                    const operand_32 = (zx_abi).zx_type_17{ .names = (((operand_31).candidate).fields).names, .types = (((operand_31).candidate).fields).types, };
                    const operand_33 = (zx_abi).zx_type_19{ .children = ((operand_31).candidate).children, .fields = (&operand_32), .first = ((operand_31).candidate).first, .kind = ((operand_31).candidate).kind, .label = ((operand_31).candidate).label, .names = ((operand_31).candidate).names, .second = ((operand_31).candidate).second, };
                    const operand_34 = (zx_abi).zx_type_15{ .children = (((operand_31).tables).base).children, .field_names = (((operand_31).tables).base).field_names, .field_types = (((operand_31).tables).base).field_types, .first = (((operand_31).tables).base).first, .kinds = (((operand_31).tables).base).kinds, .labels = (((operand_31).tables).base).labels, .names = (((operand_31).tables).base).names, .second = (((operand_31).tables).base).second, };
                    const operand_35 = (zx_abi).zx_type_15{ .children = (((operand_31).tables).delta).children, .field_names = (((operand_31).tables).delta).field_names, .field_types = (((operand_31).tables).delta).field_types, .first = (((operand_31).tables).delta).first, .kinds = (((operand_31).tables).delta).kinds, .labels = (((operand_31).tables).delta).labels, .names = (((operand_31).tables).delta).names, .second = (((operand_31).tables).delta).second, };
                    const operand_36 = (zx_abi).zx_type_16{ .base = (&operand_34), .delta = (&operand_35), };
                    const operand_37 = (zx_abi).zx_type_25{ .candidate = (&operand_33), .id = (operand_31).id, .tables = (&operand_36), };
                    const operand_38 = (try function_8(allocator, (&operand_37)));

                    break :block_39 operand_38;
                };
                const value_7: state_type_6 = block_25: {
                    const operand_21 = state_1;
                    const operand_22 = ((state_1).index + @as(u64, 1));
                    const operand_23 = value_6;
                    const operand_24 = value_5;

                    break :block_25 state_type_6{ .candidate = (operand_21).candidate, .count = (operand_21).count, .found = operand_23, .id = operand_24, .index = operand_22, .tables = (operand_21).tables, };
                };

                break :block_40 value_7;
            };

            state_changed_20 = true;
        }

        break :block_46 block_45: {
            const operand_41 = (state_1).found;
            const operand_42 = (state_1).id;

            break :block_45 block_44: {
                const operand_43 = (try (allocator).create((zx_abi).zx_type_20));

                (operand_43).* = @as((zx_abi).zx_type_20, (zx_abi).zx_type_20{ .found = operand_41, .id = operand_42, });

                break :block_44 @as(*const (zx_abi).zx_type_20, operand_43);
            };
        };
    };
}

fn function_9_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_26_3afcb41c858ed0378286c06aa6741c09757edf7ccb0bae1f3f323f9df6195319) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }!(zx_abi).value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 {
    @setRuntimeSafety(true);

    if (((((in).candidate).kind == @as((zx_abi).zx_type_11, .Enumeration)) or (((in).candidate).kind == @as((zx_abi).zx_type_11, .NativeReference)))) {
        return block_100: {
            const operand_98 = false;
            const operand_99 = @as(u32, 0);

            break :block_100 @as((zx_abi).value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .found = operand_98, .id = operand_99, });
        };
    }

    const value_1: u32 = @as(u32, 0);
    const value_2: u64 = (@as(u64, ((((in).tables).base).kinds).len) + @as(u64, ((((in).tables).delta).kinds).len));
    const value_8: (zx_abi).value_zx_type_29_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e = block_97: {
        const operand_66 = block_65: {
            const operand_57 = (in).tables;
            const operand_58 = (in).candidate;
            const operand_59 = block_60: {
                break :block_60 value_2;
            };
            const operand_61 = @as(u64, 0);
            const operand_62 = false;
            const operand_63 = block_64: {
                break :block_64 value_1;
            };

            break :block_65 @as((zx_abi).value_zx_type_29_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e, (zx_abi).value_zx_type_29_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e{ .tables = operand_57, .candidate = operand_58, .count = operand_59, .index = operand_61, .found = operand_62, .id = operand_63, });
        };

        var state_56: (zx_abi).value_zx_type_29_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e = operand_66;

        var state_changed_67 = false;

        while (((!(state_56).found) and ((state_56).index < (state_56).count))) {
            state_56 = block_95: {
                const value_5: u32 = (try function_2(allocator, (state_56).index));
                const value_6: bool = block_94: {
                    const operand_75 = (state_56).tables;

                    var state_borrow_76: (zx_abi).zx_type_15 = undefined;

                    state_borrow_76 = (zx_abi).zx_type_15{ .children = ((operand_75).base).children, .field_names = ((operand_75).base).field_names, .field_types = ((operand_75).base).field_types, .first = ((operand_75).base).first, .kinds = ((operand_75).base).kinds, .labels = ((operand_75).base).labels, .names = ((operand_75).base).names, .second = ((operand_75).base).second, };

                    var state_borrow_77: (zx_abi).zx_type_15 = undefined;

                    state_borrow_77 = (zx_abi).zx_type_15{ .children = ((operand_75).delta).children, .field_names = ((operand_75).delta).field_names, .field_types = ((operand_75).delta).field_types, .first = ((operand_75).delta).first, .kinds = ((operand_75).delta).kinds, .labels = ((operand_75).delta).labels, .names = ((operand_75).delta).names, .second = ((operand_75).delta).second, };

                    var state_borrow_78: (zx_abi).zx_type_16 = undefined;

                    state_borrow_78 = (zx_abi).zx_type_16{ .base = (((operand_75).base).zx_origin orelse (&state_borrow_76)), .delta = (((operand_75).delta).zx_origin orelse (&state_borrow_77)), };

                    const operand_79 = ((operand_75).zx_origin orelse (&state_borrow_78));
                    const operand_81 = block_80: {
                        break :block_80 value_5;
                    };
                    const operand_82 = (state_56).candidate;

                    var state_borrow_83: (zx_abi).zx_type_17 = undefined;

                    state_borrow_83 = (zx_abi).zx_type_17{ .names = ((operand_82).fields).names, .types = ((operand_82).fields).types, };

                    var state_borrow_84: (zx_abi).zx_type_19 = undefined;

                    state_borrow_84 = (zx_abi).zx_type_19{ .children = (operand_82).children, .fields = (((operand_82).fields).zx_origin orelse (&state_borrow_83)), .first = (operand_82).first, .kind = (operand_82).kind, .label = (operand_82).label, .names = (operand_82).names, .second = (operand_82).second, };

                    const operand_85 = ((operand_82).zx_origin orelse (&state_borrow_84));
                    const operand_86 = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_79).base).children, .field_names = ((operand_79).base).field_names, .field_types = ((operand_79).base).field_types, .first = ((operand_79).base).first, .kinds = ((operand_79).base).kinds, .labels = ((operand_79).base).labels, .names = ((operand_79).base).names, .second = ((operand_79).base).second, .zx_origin = (operand_79).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = ((operand_79).delta).children, .field_names = ((operand_79).delta).field_names, .field_types = ((operand_79).delta).field_types, .first = ((operand_79).delta).first, .kinds = ((operand_79).delta).kinds, .labels = ((operand_79).delta).labels, .names = ((operand_79).delta).names, .second = ((operand_79).delta).second, .zx_origin = (operand_79).delta, }, .zx_origin = operand_79, };

                    var state_borrow_87: (zx_abi).zx_type_15 = undefined;

                    state_borrow_87 = (zx_abi).zx_type_15{ .children = ((operand_86).base).children, .field_names = ((operand_86).base).field_names, .field_types = ((operand_86).base).field_types, .first = ((operand_86).base).first, .kinds = ((operand_86).base).kinds, .labels = ((operand_86).base).labels, .names = ((operand_86).base).names, .second = ((operand_86).base).second, };

                    var state_borrow_88: (zx_abi).zx_type_15 = undefined;

                    state_borrow_88 = (zx_abi).zx_type_15{ .children = ((operand_86).delta).children, .field_names = ((operand_86).delta).field_names, .field_types = ((operand_86).delta).field_types, .first = ((operand_86).delta).first, .kinds = ((operand_86).delta).kinds, .labels = ((operand_86).delta).labels, .names = ((operand_86).delta).names, .second = ((operand_86).delta).second, };

                    var state_borrow_89: (zx_abi).zx_type_16 = undefined;

                    state_borrow_89 = (zx_abi).zx_type_16{ .base = (((operand_86).base).zx_origin orelse (&state_borrow_87)), .delta = (((operand_86).delta).zx_origin orelse (&state_borrow_88)), };

                    const operand_90 = (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = (operand_85).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = ((operand_85).fields).names, .types = ((operand_85).fields).types, .zx_origin = (operand_85).fields, }, .first = (operand_85).first, .kind = (operand_85).kind, .label = (operand_85).label, .names = (operand_85).names, .second = (operand_85).second, .zx_origin = operand_85, };

                    var state_borrow_91: (zx_abi).zx_type_17 = undefined;

                    state_borrow_91 = (zx_abi).zx_type_17{ .names = ((operand_90).fields).names, .types = ((operand_90).fields).types, };

                    var state_borrow_92: (zx_abi).zx_type_19 = undefined;

                    state_borrow_92 = (zx_abi).zx_type_19{ .children = (operand_90).children, .fields = (((operand_90).fields).zx_origin orelse (&state_borrow_91)), .first = (operand_90).first, .kind = (operand_90).kind, .label = (operand_90).label, .names = (operand_90).names, .second = (operand_90).second, };

                    const operand_93 = (zx_abi).zx_type_25{ .tables = ((operand_86).zx_origin orelse (&state_borrow_89)), .id = operand_81, .candidate = ((operand_90).zx_origin orelse (&state_borrow_92)), };

                    break :block_94 (try function_8(allocator, (&operand_93)));
                };
                const value_7: (zx_abi).value_zx_type_29_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e = block_74: {
                    const operand_68 = state_56;
                    const operand_69 = ((state_56).index + @as(u64, 1));
                    const operand_70 = block_71: {
                        break :block_71 value_6;
                    };
                    const operand_72 = block_73: {
                        break :block_73 value_5;
                    };

                    break :block_74 @as((zx_abi).value_zx_type_29_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e, (zx_abi).value_zx_type_29_fc8ef4bf7751be970b22012a7a78fdcf72f2bd9ded6a00a7c4d96f3ae896f19e{ .candidate = (operand_68).candidate, .count = (operand_68).count, .found = operand_70, .id = operand_72, .index = operand_69, .tables = (operand_68).tables, });
                };

                break :block_95 value_7;
            };

            state_changed_67 = true;
        }

        break :block_97 (if (state_changed_67) state_56 else operand_66);
    };

    return block_55: {
        const operand_53 = (value_8).found;
        const operand_54 = (value_8).id;

        break :block_55 @as((zx_abi).value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, (zx_abi).value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .found = operand_53, .id = operand_54, });
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_26) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }!?u32 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: (zx_abi).zx_type_20 = block_4: {
        const operand_1 = in;
        const operand_2 = (try function_9_value(allocator, (zx_abi).value_zx_type_26_3afcb41c858ed0378286c06aa6741c09757edf7ccb0bae1f3f323f9df6195319{ .candidate = (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = ((operand_1).candidate).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = (((operand_1).candidate).fields).names, .types = (((operand_1).candidate).fields).types, .zx_origin = ((operand_1).candidate).fields, }, .first = ((operand_1).candidate).first, .kind = ((operand_1).candidate).kind, .label = ((operand_1).candidate).label, .names = ((operand_1).candidate).names, .second = ((operand_1).candidate).second, .zx_origin = (operand_1).candidate, }, .tables = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).base).children, .field_names = (((operand_1).tables).base).field_names, .field_types = (((operand_1).tables).base).field_types, .first = (((operand_1).tables).base).first, .kinds = (((operand_1).tables).base).kinds, .labels = (((operand_1).tables).base).labels, .names = (((operand_1).tables).base).names, .second = (((operand_1).tables).base).second, .zx_origin = ((operand_1).tables).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_1).tables).delta).children, .field_names = (((operand_1).tables).delta).field_names, .field_types = (((operand_1).tables).delta).field_types, .first = (((operand_1).tables).delta).first, .kinds = (((operand_1).tables).delta).kinds, .labels = (((operand_1).tables).delta).labels, .names = (((operand_1).tables).delta).names, .second = (((operand_1).tables).delta).second, .zx_origin = ((operand_1).tables).delta, }, .zx_origin = (operand_1).tables, }, .zx_origin = operand_1, }));

        break :block_4 (if (((operand_2).zx_origin != null)) ((operand_2).zx_origin.?).* else block_3: {
            break :block_3 (zx_abi).zx_type_20{ .found = (operand_2).found, .id = (operand_2).id, };
        });
    };

    return (if (((&value_1)).found) @as(?u32, ((&value_1)).id) else @as(?u32, null));
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_26) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }!?u32 {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_20 = block_8: {
        const operand_5 = in;
        const operand_6 = (try function_9_value(allocator, (zx_abi).value_zx_type_26_3afcb41c858ed0378286c06aa6741c09757edf7ccb0bae1f3f323f9df6195319{ .candidate = (zx_abi).value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384{ .children = ((operand_5).candidate).children, .fields = (zx_abi).value_zx_type_17_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .names = (((operand_5).candidate).fields).names, .types = (((operand_5).candidate).fields).types, .zx_origin = ((operand_5).candidate).fields, }, .first = ((operand_5).candidate).first, .kind = ((operand_5).candidate).kind, .label = ((operand_5).candidate).label, .names = ((operand_5).candidate).names, .second = ((operand_5).candidate).second, .zx_origin = (operand_5).candidate, }, .tables = (zx_abi).value_zx_type_16_1bf0f3d4598512e2e335a8e5fc12bb2fae6bd59146b286ad0a91789b850ba8e9{ .base = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_5).tables).base).children, .field_names = (((operand_5).tables).base).field_names, .field_types = (((operand_5).tables).base).field_types, .first = (((operand_5).tables).base).first, .kinds = (((operand_5).tables).base).kinds, .labels = (((operand_5).tables).base).labels, .names = (((operand_5).tables).base).names, .second = (((operand_5).tables).base).second, .zx_origin = ((operand_5).tables).base, }, .delta = (zx_abi).value_zx_type_15_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b{ .children = (((operand_5).tables).delta).children, .field_names = (((operand_5).tables).delta).field_names, .field_types = (((operand_5).tables).delta).field_types, .first = (((operand_5).tables).delta).first, .kinds = (((operand_5).tables).delta).kinds, .labels = (((operand_5).tables).delta).labels, .names = (((operand_5).tables).delta).names, .second = (((operand_5).tables).delta).second, .zx_origin = ((operand_5).tables).delta, }, .zx_origin = (operand_5).tables, }, .zx_origin = operand_5, }));

        break :block_8 (if (((operand_6).zx_origin != null)) ((operand_6).zx_origin.?).* else block_7: {
            break :block_7 (zx_abi).zx_type_20{ .found = (operand_6).found, .id = (operand_6).id, };
        });
    };

    return (if (((&value_1)).found) @as(?u32, ((&value_1)).id) else @as(?u32, null));
}

