const std = @import("std");

const zx_type_13 = struct {
    negative: bool,
    offset: u64,
    seen: bool,
    source: []const u8,
    started: bool,
    valid: bool,
    value: u64,
};

const zx_type_14 = struct { []const u8, };

const zx_type_15 = struct { []const u8, ?u64, };

const value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    negative: bool,
    offset: u64,
    seen: bool,
    source: []const u8,
    started: bool,
    valid: bool,
    value: u64,
    zx_origin: ?*const zx_type_13 = null,
};

const value_zx_type_14_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744 = struct { []const u8, ?*const zx_type_14, };

const value_zx_type_15_344581c368434156cd88cf3641a6cfe630cd1d8ac42f32876816bef0967e7754 = struct { []const u8, ?u64, ?*const zx_type_15, };

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_12 = .{ .kind = .optional, .child = zx_shape_5, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .negative = zx_shape_1, .offset = zx_shape_5, .seen = zx_shape_1, .source = zx_shape_11, .started = zx_shape_1, .valid = zx_shape_1, .value = zx_shape_5, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_12, }, };

pub const input_shape = zx_shape_11;

pub const output_shape = zx_shape_12;

pub const Input = []const u8;

pub const Output = ?u64;

fn function_0(allocator: ((std).mem).Allocator, in: u8) error{ }!u64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const switch_1 = in;

    if ((switch_1 == @as(u8, 48))) {
        return @as(u64, 0);
    } else {
        if ((switch_1 == @as(u8, 49))) {
            return @as(u64, 1);
        } else {
            if ((switch_1 == @as(u8, 50))) {
                return @as(u64, 2);
            } else {
                if ((switch_1 == @as(u8, 51))) {
                    return @as(u64, 3);
                } else {
                    if ((switch_1 == @as(u8, 52))) {
                        return @as(u64, 4);
                    } else {
                        if ((switch_1 == @as(u8, 53))) {
                            return @as(u64, 5);
                        } else {
                            if ((switch_1 == @as(u8, 54))) {
                                return @as(u64, 6);
                            } else {
                                if ((switch_1 == @as(u8, 55))) {
                                    return @as(u64, 7);
                                } else {
                                    if ((switch_1 == @as(u8, 56))) {
                                        return @as(u64, 8);
                                    } else {
                                        if ((switch_1 == @as(u8, 57))) {
                                            return @as(u64, 9);
                                        } else {
                                            return @as(u64, 10);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fn function_1(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!?u64 {
    @setRuntimeSafety(true);

    const value_16: zx_type_13 = block_38: {
        const operand_10 = block_9: {
            const operand_2 = in;
            const operand_3 = @as(u64, 0);
            const operand_4 = @as(u64, 0);
            const operand_5 = true;
            const operand_6 = false;
            const operand_7 = false;
            const operand_8 = false;

            break :block_9 zx_type_13{ .source = operand_2, .offset = operand_3, .value = operand_4, .valid = operand_5, .started = operand_6, .seen = operand_7, .negative = operand_8, };
        };

        var state_1: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .negative = (operand_10).negative, .offset = (operand_10).offset, .seen = (operand_10).seen, .source = (operand_10).source, .started = (operand_10).started, .valid = (operand_10).valid, .value = (operand_10).value, .zx_origin = (&operand_10), };

        while (((state_1).valid and ((state_1).offset < @as(u64, ((state_1).source).len)))) {
            state_1 = block_35: {
                const value_3: u8 = block_34: {
                    const operand_32 = (state_1).source;
                    const operand_33 = (state_1).offset;

                    if ((operand_33 >= (operand_32).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_34 (operand_32)[@intCast(operand_33)];
                };
                const value_13: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if ((block_13: {
                    break :block_13 value_3;
                } != @as(u8, 95))) block_31: {
                    const value_12: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if (((!(state_1).started) and ((block_14: {
                        break :block_14 value_3;
                    } == @as(u8, 43)) or (block_15: {
                        break :block_15 value_3;
                    } == @as(u8, 45))))) block_19: {
                        const value_4: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_18: {
                            break :block_18 @as(value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .negative = (state_1).negative, .offset = (state_1).offset, .seen = (state_1).seen, .source = (state_1).source, .started = true, .valid = (state_1).valid, .value = (state_1).value, });
                        };
                        const value_5: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_17: {
                            break :block_17 @as(value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .negative = (block_16: {
                                break :block_16 value_3;
                            } == @as(u8, 45)), .offset = (value_4).offset, .seen = (value_4).seen, .source = (value_4).source, .started = (value_4).started, .valid = (value_4).valid, .value = (value_4).value, });
                        };

                        break :block_19 value_5;
                    } else block_30: {
                        const value_6: u64 = (try function_0(allocator, block_29: {
                            break :block_29 value_3;
                        }));
                        const value_7: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_28: {
                            break :block_28 @as(value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .negative = (state_1).negative, .offset = (state_1).offset, .seen = (state_1).seen, .source = (state_1).source, .started = (state_1).started, .valid = (((block_25: {
                                break :block_25 value_6;
                            } < @as(u64, 10)) and ((!(state_1).negative) or (block_26: {
                                break :block_26 value_6;
                            } == @as(u64, 0)))) and (((state_1).value < @as(u64, 1844674407370955161)) or (((state_1).value == @as(u64, 1844674407370955161)) and (block_27: {
                                break :block_27 value_6;
                            } <= @as(u64, 5))))), .value = (state_1).value, });
                        };
                        const value_10: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = (if ((value_7).valid) block_24: {
                            const value_8: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_23: {
                                break :block_23 @as(value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .negative = (value_7).negative, .offset = (value_7).offset, .seen = (value_7).seen, .source = (value_7).source, .started = (value_7).started, .valid = (value_7).valid, .value = (((value_7).value * @as(u64, 10)) + block_22: {
                                    break :block_22 value_6;
                                }), });
                            };
                            const value_9: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_21: {
                                break :block_21 @as(value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .negative = (value_8).negative, .offset = (value_8).offset, .seen = true, .source = (value_8).source, .started = (value_8).started, .valid = (value_8).valid, .value = (value_8).value, });
                            };

                            break :block_24 value_9;
                        } else value_7);
                        const value_11: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_20: {
                            break :block_20 @as(value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .negative = (value_10).negative, .offset = (value_10).offset, .seen = (value_10).seen, .source = (value_10).source, .started = true, .valid = (value_10).valid, .value = (value_10).value, });
                        };

                        break :block_30 value_11;
                    });

                    break :block_31 value_12;
                } else state_1);
                const value_14: u64 = (value_13).offset;
                const value_15: value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = block_12: {
                    break :block_12 @as(value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca, value_zx_type_13_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca{ .negative = (value_13).negative, .offset = (block_11: {
                        break :block_11 value_14;
                    } + @as(u64, 1)), .seen = (value_13).seen, .source = (value_13).source, .started = (value_13).started, .valid = (value_13).valid, .value = (value_13).value, });
                };

                break :block_35 value_15;
            };
        }

        break :block_38 block_37: {
            break :block_37 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_36: {
                break :block_36 zx_type_13{ .negative = (state_1).negative, .offset = (state_1).offset, .seen = (state_1).seen, .source = (state_1).source, .started = (state_1).started, .valid = (state_1).valid, .value = (state_1).value, };
            });
        };
    };

    return (if ((((&value_16)).valid and ((&value_16)).seen)) @as(?u64, ((&value_16)).value) else @as(?u64, null));
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!?u64 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: ?u64 = (try function_1(allocator, in));

    return value_1;
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: []const u8) error{ IndexOutOfBounds, OutOfMemory, }!?u64 {
    @setRuntimeSafety(true);

    const value_1: ?u64 = (try function_1(allocator, in));

    return value_1;
}

