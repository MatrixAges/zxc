const std = @import("std");

const zx_abi = @import("zxc_abi");

const zx_native = @import("library_native_548342be9273bad8c4760e8d54cb1f8c7458a71351c177953725e1b8a55cdc8b");

pub fn call(allocator: ((std).mem).Allocator, in: []const i64) error{ }![]const i64 {
    const native_result = (zx_native).source(in);

    _ = allocator;

    return native_result;
}

