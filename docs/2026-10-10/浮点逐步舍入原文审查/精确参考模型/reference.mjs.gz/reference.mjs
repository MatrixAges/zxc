import assert from 'node:assert/strict'
import { pathToFileURL } from 'node:url'

const root = process.argv[2]
const load = name => import(pathToFileURL(root + '/packages/test/src/models/' + name + '.ts'))
const [{ default: Rational }, { encode, divide }, { default: add }, { default: subtract }] = await Promise.all(['rational', 'ieee', 'add', 'subtract'].map(load))
const integer = value => encode({ magnitude: new Rational(value), negative: false, width: 64 })
const step = value => {
    assert.equal(typeof value, 'bigint')

    return value
}
const one = integer(1n)
const x = integer(9007199254740994n)
const quotient = step(divide({ left_bits: one, right_bits: integer(65536n), width: 64 }))
const y = step(subtract({ left_bits: one, right_bits: quotient, width: 64 }))
const z = step(add({ left_bits: x, right_bits: y, width: 64 }))
const d = step(subtract({ left_bits: z, right_bits: x, width: 64 }))
const expected = { x, quotient, y, z, d }
const node_x = 9007199254740994.0
const node_quotient = 1 / 65536.0
const node_y = 1.0 - node_quotient
const node_z = node_x + node_y
const node_d = node_z - node_x
const actual = { x: node_x, quotient: node_quotient, y: node_y, z: node_z, d: node_d }
const buffer = Buffer.alloc(8)
const trace = {}

for (const [name, value] of Object.entries(actual)) {
    buffer.writeDoubleBE(value)

    assert.equal(buffer.readBigUInt64BE(), expected[name])
    trace[name] = { value, bits: expected[name].toString(16).padStart(16, '0') }
}

assert.equal(node_d === 0, true)
assert.equal(node_d !== 2, true)
console.log(JSON.stringify({ trace, assertions: { equals_zero: node_d === 0, differs_two: node_d !== 2 }, scope: 'Exact binary64 reference and Node cross-check only; no zxc execution.' }, null, 4))
