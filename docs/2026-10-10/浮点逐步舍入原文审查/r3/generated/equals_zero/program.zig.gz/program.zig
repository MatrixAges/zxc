const std = @import("std");

pub const Input = f64;

pub const Output = bool;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

pub const input_shape = zx_shape_9;

pub const output_shape = zx_shape_1;

fn function_0(allocator: ((std).mem).Allocator, in: f64) error{ }!f64 {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: f64 = in;
    const value_2: f64 = (@as(f64, @as(f64, @bitCast(@as(u64, 4607182418800017408)))) - (@as(f64, @as(f64, @bitCast(@as(u64, 4607182418800017408)))) / @as(f64, @as(f64, @bitCast(@as(u64, 4679240012837945344))))));
    const value_3: f64 = (value_1 + value_2);
    const value_4: f64 = (value_3 - value_1);

    return value_4;
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: f64) error{ }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();

    return ((try function_0(allocator, in)) == @as(f64, @as(f64, @bitCast(@as(u64, 0)))));
}

pub fn executeValue(allocator: ((std).mem).Allocator, in: f64) error{ }!bool {
    @setRuntimeSafety(true);

    return ((try function_0(allocator, in)) == @as(f64, @as(f64, @bitCast(@as(u64, 0)))));
}

