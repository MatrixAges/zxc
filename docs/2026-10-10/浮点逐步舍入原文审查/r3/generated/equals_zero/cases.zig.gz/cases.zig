const check = @import("support").check;

test "language/types/number/rounding/equals_zero/original" {
    try check(@import("program"), 9007199254740994, .{ .value = true });
}

test "language/types/number/rounding/equals_zero/zero_input" {
    try check(@import("program"), 0, .{ .value = false });
}
