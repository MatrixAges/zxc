const check = @import("support").check;

test "language/types/number/rounding/differs_two/original" {
    try check(@import("program"), 9007199254740994, .{ .value = true });
}
