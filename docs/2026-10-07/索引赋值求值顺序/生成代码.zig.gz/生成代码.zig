const std = @import("std");

const zx_native_0 = @import("zxc_standard");

const zx_abi = @import("zxc_abi");

pub const Input = *const (zx_abi).zx_type_15;

pub const State = *const (zx_abi).zx_type_16;

pub const Output = []const i64;

pub const requires_io = true;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_12 = .{ .kind = .optional, .child = zx_shape_10, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_14 = .{ .kind = .list, .child = zx_shape_7, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .values = zx_shape_14, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .index = zx_shape_5, .values = zx_shape_14, }, };

pub const input_shape = zx_shape_15;

pub const output_shape = zx_shape_14;

fn function_0(allocator: ((std).mem).Allocator, in: void, process: (((std).process).Init).Minimal) error{ InvalidUtf8, OutOfMemory, }![]const []const u8 {
    _ = in;

    const native_result = (try ((zx_native_0).process).argv(allocator, process));

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: []const u8, process: (((std).process).Init).Minimal) error{ EnvironmentVariableMissing, InvalidEnvironmentKey, InvalidUtf8, InvalidWtf8, OutOfMemory, }!?[]const u8 {
    const native_result = (try ((zx_native_0).process).getEnv(allocator, process, in));

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: void, io: (std).Io) error{ Canceled, CurrentDirUnlinked, InvalidUtf8, NameTooLong, OutOfMemory, PathExceedsLimit, Unexpected, }![]const u8 {
    _ = in;

    const native_result = (try ((zx_native_0).process).cwd(allocator, io));

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: u64, io: (std).Io) error{ OutOfMemory, ReadFailed, StreamTooLong, }![]const u8 {
    const native_result = (try ((zx_native_0).process).readStdin(allocator, io, in));

    return native_result;
}

fn function_4(allocator: ((std).mem).Allocator, in: u64, io: (std).Io) error{ InvalidUtf8, OutOfMemory, ReadFailed, StreamTooLong, }![]const u8 {
    const native_result = (try ((zx_native_0).process).readStdinText(allocator, io, in));

    return native_result;
}

fn function_5(allocator: ((std).mem).Allocator, in: []const u8, io: (std).Io) error{ WriteFailed, }!void {
    const native_result = (try ((zx_native_0).process).writeStdout(io, in));

    _ = allocator;

    return native_result;
}

fn function_6(allocator: ((std).mem).Allocator, in: []const u8, io: (std).Io) error{ InvalidUtf8, WriteFailed, }!void {
    const native_result = (try ((zx_native_0).process).writeStdoutText(io, in));

    _ = allocator;

    return native_result;
}

fn function_7(allocator: ((std).mem).Allocator, in: []const u8, io: (std).Io) error{ WriteFailed, }!void {
    const native_result = (try ((zx_native_0).process).writeStderr(io, in));

    _ = allocator;

    return native_result;
}

fn function_8(allocator: ((std).mem).Allocator, in: []const u8, io: (std).Io) error{ InvalidUtf8, WriteFailed, }!void {
    const native_result = (try ((zx_native_0).process).writeStderrText(io, in));

    _ = allocator;

    return native_result;
}

fn function_9(allocator: ((std).mem).Allocator, in: u64, io: (std).Io) error{ InvalidUtf8, WriteFailed, }!u64 {
    @setRuntimeSafety(true);

    _ = (try function_6(allocator, @as([]const u8, "P|"), io));

    return in;
}

fn function_10(allocator: ((std).mem).Allocator, in: i64, io: (std).Io) error{ InvalidUtf8, WriteFailed, }!i64 {
    @setRuntimeSafety(true);

    _ = (try function_6(allocator, @as([]const u8, "V|"), io));

    return in;
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_15, io: (std).Io) error{ IndexOutOfBounds, InvalidUtf8, OutOfMemory, WriteFailed, }![]const i64 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: *const (zx_abi).zx_type_16 = block_22: {
        const operand_17 = (in).values;
        const operand_18 = (in).count;
        const operand_19 = @as(u64, 0);

        break :block_22 block_21: {
            const operand_20 = (try (allocator).create((zx_abi).zx_type_16));

            (operand_20).* = @as((zx_abi).zx_type_16, (zx_abi).zx_type_16{ .values = operand_17, .count = operand_18, .index = operand_19, });

            break :block_21 @as(*const (zx_abi).zx_type_16, operand_20);
        };
    };
    const value_11: *const (zx_abi).zx_type_16 = block_16: {
        var state_1: *const (zx_abi).zx_type_16 = value_1;

        while (((state_1).index < (state_1).count)) {
            state_1 = block_14: {
                const value_4: *const (zx_abi).zx_type_16 = state_1;
                const value_5: []const i64 = (value_4).values;
                const value_6: u64 = (try function_9(allocator, (state_1).index, io));
                const value_7: *const (zx_abi).zx_type_16 = block_13: {
                    break :block_13 block_12: {
                        const operand_11 = (try (allocator).create((zx_abi).zx_type_16));

                        (operand_11).* = @as((zx_abi).zx_type_16, (zx_abi).zx_type_16{ .count = (value_4).count, .index = (value_4).index, .values = block_10: {
                            const operand_5 = value_5;
                            const operand_6 = value_6;

                            if ((operand_6 >= (operand_5).len)) {
                                return error.IndexOutOfBounds;
                            }

                            const operand_7 = (try function_10(allocator, @as(i64, 7), io));

                            break :block_10 block_9: {
                                const operand_8 = (try (allocator).dupe(i64, operand_5));

                                (operand_8)[@intCast(operand_6)] = operand_7;

                                break :block_9 operand_8;
                            };
                        }, });

                        break :block_12 @as(*const (zx_abi).zx_type_16, operand_11);
                    };
                };
                const value_8: *const (zx_abi).zx_type_16 = value_7;
                const value_9: u64 = (value_8).index;
                const value_10: *const (zx_abi).zx_type_16 = block_4: {
                    break :block_4 block_3: {
                        const operand_2 = (try (allocator).create((zx_abi).zx_type_16));

                        (operand_2).* = @as((zx_abi).zx_type_16, (zx_abi).zx_type_16{ .count = (value_8).count, .index = (value_9 + @as(u64, 1)), .values = (value_8).values, });

                        break :block_3 @as(*const (zx_abi).zx_type_16, operand_2);
                    };
                };

                break :block_14 value_10;
            };
        }

        break :block_16 state_1;
    };

    return (value_11).values;
}

