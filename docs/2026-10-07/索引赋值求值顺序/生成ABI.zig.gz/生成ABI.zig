pub const zx_type_15 = struct {
    count: u64,
    values: []const i64,
};

pub const zx_type_16 = struct {
    count: u64,
    index: u64,
    values: []const i64,
};

pub const value_zx_type_15_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    count: u64,
    values: []const i64,
    zx_origin: ?*const zx_type_15 = null,
};

pub const value_zx_type_16_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    index: u64,
    values: []const i64,
    zx_origin: ?*const zx_type_16 = null,
};

pub const native = struct {
    pub const @"std:process" = struct {
        pub const argv = struct {
            pub const Input = void;
            pub const Output = []const []const u8;
            pub const InputValue = void;
            pub const OutputValue = []const []const u8;
        };
        pub const getEnv = struct {
            pub const Input = []const u8;
            pub const Output = ?[]const u8;
            pub const InputValue = []const u8;
            pub const OutputValue = ?[]const u8;
        };
        pub const cwd = struct {
            pub const Input = void;
            pub const Output = []const u8;
            pub const InputValue = void;
            pub const OutputValue = []const u8;
        };
        pub const readStdin = struct {
            pub const Input = u64;
            pub const Output = []const u8;
            pub const InputValue = u64;
            pub const OutputValue = []const u8;
        };
        pub const readStdinText = struct {
            pub const Input = u64;
            pub const Output = []const u8;
            pub const InputValue = u64;
            pub const OutputValue = []const u8;
        };
        pub const writeStdout = struct {
            pub const Input = []const u8;
            pub const Output = void;
            pub const InputValue = []const u8;
            pub const OutputValue = void;
        };
        pub const writeStdoutText = struct {
            pub const Input = []const u8;
            pub const Output = void;
            pub const InputValue = []const u8;
            pub const OutputValue = void;
        };
        pub const writeStderr = struct {
            pub const Input = []const u8;
            pub const Output = void;
            pub const InputValue = []const u8;
            pub const OutputValue = void;
        };
        pub const writeStderrText = struct {
            pub const Input = []const u8;
            pub const Output = void;
            pub const InputValue = []const u8;
            pub const OutputValue = void;
        };
    };
};

pub const layouts = struct {
    pub const @"std:process" = struct {
    };
};

