pub const zx_type_11 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_15 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_16 = struct {
    base: *const zx_type_15,
    delta: *const zx_type_15,
};

pub const zx_type_17 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    second: u32,
};

pub const zx_type_18 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_19 = struct {
    children: []const u32,
    fields: *const zx_type_18,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_20 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_21 = struct {
    delta: *const zx_type_15,
    id: u32,
};

pub const zx_type_22 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_23 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_24 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_25 = enum { Negate, Not, };

pub const zx_type_26 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_37 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_26,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_23,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_22,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_24,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_25,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_38 = enum { Copy, Borrowed, Owned, };

pub const zx_type_40 = struct {
    names: []const []const u8,
    ownership: []const zx_type_38,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_41 = enum { Requires, Ensures, };

pub const zx_type_45 = struct {
    expressions: []const *const zx_type_37,
    kinds: []const zx_type_41,
    predicates: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    symbols: []const *const zx_type_40,
};

pub const zx_type_46 = struct {
    contracts: *const zx_type_45,
    input_type: u32,
    max_offset: u64,
    output_type: u32,
    table: *const zx_type_15,
};

pub const zx_type_47 = struct {
    expressions: *const zx_type_37,
    id: u32,
    index: u64,
    type_id: u32,
};

pub const zx_type_48 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_50 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_48,
};

pub const zx_type_51 = struct {
    expressions: *const zx_type_37,
    functions: *const zx_type_50,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_48,
    symbols: *const zx_type_40,
    table: *const zx_type_15,
};

pub const zx_type_52 = struct {
    context: *const zx_type_51,
    kind: zx_type_22,
    payload: u64,
    target: zx_type_11,
    type_id: u32,
};

pub const zx_type_53 = enum { Other, Integer, Signed, Float, };

pub const zx_type_54 = struct {
    available: *const zx_type_48,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_48,
    slots: []const u32,
};

pub const zx_type_55 = struct {
    available: *const zx_type_48,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_48,
    slots: []const u32,
    valid: bool,
};

pub const zx_type_56 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
};

pub const zx_type_57 = struct {
    condition_type: u32,
    context: *const zx_type_51,
    count: u64,
    first: u64,
    index: u64,
    result_type: u32,
    valid: bool,
};

pub const zx_type_58 = struct {
    context: *const zx_type_51,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_59 = struct {
    context: *const zx_type_51,
    count: u64,
    first: u64,
    index: u64,
    type_first: u64,
    valid: bool,
};

pub const zx_type_60 = struct {
    field: u64,
    first: u64,
    found: bool,
    index: u64,
    indices: []const u32,
    limit: u64,
};

pub const zx_type_61 = struct {
    context: *const zx_type_51,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_23,
    source: u32,
    valid: bool,
};

pub const zx_type_62 = struct {
    table: *const zx_type_15,
    type_id: u32,
};

pub const zx_type_63 = struct {
    check: *const zx_type_52,
    count: u64,
    fields: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_64 = struct {
    field: ?u32,
    fields: []const ?u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    task: u32,
    tasks: []const u32,
};

pub const zx_type_65 = struct {
    check: *const zx_type_52,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_66 = struct {
    captures: []const u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    symbol: u32,
};

pub const zx_type_67 = struct {
    context: *const zx_type_51,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_24,
    result: u32,
    valid: bool,
};

pub const zx_type_68 = struct {
    index: u64,
    program: *const zx_type_46,
};

pub const zx_type_69 = struct {
    expressions: *const zx_type_37,
    functions: *const zx_type_50,
    index: u64,
    stores: *const zx_type_48,
    symbols: *const zx_type_40,
    table: *const zx_type_15,
    valid: bool,
};

pub const zx_type_70 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
};

pub const zx_type_71 = struct {
    index: u64,
    input: *const zx_type_70,
    valid: bool,
};

pub const zx_type_72 = struct {
    max_offset: u64,
    symbols: *const zx_type_40,
};

pub const zx_type_73 = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_37,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
};

pub const zx_type_74 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
};

pub const zx_type_75 = struct {
    index: u64,
    input: *const zx_type_74,
    next: u64,
    valid: bool,
};

pub const zx_type_76 = struct {
    max_offset: u64,
    table: *const zx_type_37,
};

pub const zx_type_77 = struct {
    contracts: *const zx_type_45,
    max_offset: u64,
};

pub const zx_type_78 = struct {
    contracts: *const zx_type_45,
    index: u64,
    max_offset: u64,
    valid: bool,
};

pub const zx_type_79 = struct {
    has_ensures: bool,
    index: u64,
    program: *const zx_type_46,
    valid: bool,
};

pub const zx_type_80 = struct { *const zx_type_46, };

pub const zx_type_81 = struct { *const zx_type_46, bool, };

pub const value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    base: *const zx_type_15,
    delta: *const zx_type_15,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_18 = null,
};

pub const value_zx_type_19_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_18_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_11,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_20_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    delta: *const zx_type_15,
    id: u32,
    zx_origin: ?*const zx_type_21 = null,
};

pub const value_zx_type_45_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    expressions: []const *const zx_type_37,
    kinds: []const zx_type_41,
    predicates: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    symbols: []const *const zx_type_40,
    zx_origin: ?*const zx_type_45 = null,
};

pub const value_zx_type_46_e366d4f93466af93bfbf8b4815757383af115756f7364062c2c9d566a0fb2311 = struct {
    contracts: value_zx_type_45_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    input_type: u32,
    max_offset: u64,
    output_type: u32,
    table: *const zx_type_15,
    zx_origin: ?*const zx_type_46 = null,
};

pub const value_zx_type_47_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: *const zx_type_37,
    id: u32,
    index: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_47 = null,
};

pub const value_zx_type_50_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_48,
    zx_origin: ?*const zx_type_50 = null,
};

pub const value_zx_type_51_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6 = struct {
    expressions: *const zx_type_37,
    functions: value_zx_type_50_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_48,
    symbols: *const zx_type_40,
    table: *const zx_type_15,
    zx_origin: ?*const zx_type_51 = null,
};

pub const value_zx_type_52_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed = struct {
    context: value_zx_type_51_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    kind: zx_type_22,
    payload: u64,
    target: zx_type_11,
    type_id: u32,
    zx_origin: ?*const zx_type_52 = null,
};

pub const value_zx_type_54_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    available: *const zx_type_48,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_48,
    slots: []const u32,
    zx_origin: ?*const zx_type_54 = null,
};

pub const value_zx_type_55_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    available: *const zx_type_48,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_48,
    slots: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_55 = null,
};

pub const value_zx_type_56_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
    zx_origin: ?*const zx_type_56 = null,
};

pub const value_zx_type_57_c6f082592747bfb97c58ad22751dc4616b503541b82be1a501dcd45ec633ad7a = struct {
    condition_type: u32,
    context: value_zx_type_51_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    first: u64,
    index: u64,
    result_type: u32,
    valid: bool,
    zx_origin: ?*const zx_type_57 = null,
};

pub const value_zx_type_58_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed = struct {
    context: value_zx_type_51_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_58 = null,
};

pub const value_zx_type_59_c65f606cad38c9bde5a22d060283f020c6df16f448945ff8555407599cee695f = struct {
    context: value_zx_type_51_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    first: u64,
    index: u64,
    type_first: u64,
    valid: bool,
    zx_origin: ?*const zx_type_59 = null,
};

pub const value_zx_type_60_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    field: u64,
    first: u64,
    found: bool,
    index: u64,
    indices: []const u32,
    limit: u64,
    zx_origin: ?*const zx_type_60 = null,
};

pub const value_zx_type_61_0226e38872eacdc3e44e606ef924db3a519c6f4fa1a6333f3794af990383ea77 = struct {
    context: value_zx_type_51_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_23,
    source: u32,
    valid: bool,
    zx_origin: ?*const zx_type_61 = null,
};

pub const value_zx_type_62_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    table: *const zx_type_15,
    type_id: u32,
    zx_origin: ?*const zx_type_62 = null,
};

pub const value_zx_type_63_88d54f056223ef8ac2f93da2e10b59b5e31b44b0c33166e8b7201a394c231718 = struct {
    check: value_zx_type_52_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed,
    count: u64,
    fields: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_63 = null,
};

pub const value_zx_type_64_e407d21589b2375c92a1211613c5cec575dda969be2f9d5b054d0b88d2c4a077 = struct {
    field: ?u32,
    fields: []const ?u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    task: u32,
    tasks: []const u32,
    zx_origin: ?*const zx_type_64 = null,
};

pub const value_zx_type_65_f3a9fcf220984d9746551b1ea2c8c509f64c311c9dd8964488d8c18fdae2ce12 = struct {
    check: value_zx_type_52_0417268fe8f126e7087887871bea74c13f4e018185eed8d351e5cc1cd543bbed,
    count: u64,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_65 = null,
};

pub const value_zx_type_66_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    captures: []const u32,
    first: u64,
    found: bool,
    index: u64,
    limit: u64,
    symbol: u32,
    zx_origin: ?*const zx_type_66 = null,
};

pub const value_zx_type_67_0226e38872eacdc3e44e606ef924db3a519c6f4fa1a6333f3794af990383ea77 = struct {
    context: value_zx_type_51_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6,
    count: u64,
    element: u32,
    first: u64,
    index: u64,
    operation: zx_type_24,
    result: u32,
    valid: bool,
    zx_origin: ?*const zx_type_67 = null,
};

pub const value_zx_type_68_2d843d35eb1167b518f8112234365ab5ac4503cb64e443b208d0ca1674edf4a9 = struct {
    index: u64,
    program: value_zx_type_46_e366d4f93466af93bfbf8b4815757383af115756f7364062c2c9d566a0fb2311,
    zx_origin: ?*const zx_type_68 = null,
};

pub const value_zx_type_69_133939f190bd0b250c9b5b27f7b5a8ff4066b75725c0138992d8b899a6a527e6 = struct {
    expressions: *const zx_type_37,
    functions: value_zx_type_50_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    stores: *const zx_type_48,
    symbols: *const zx_type_40,
    table: *const zx_type_15,
    valid: bool,
    zx_origin: ?*const zx_type_69 = null,
};

pub const value_zx_type_70_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
    zx_origin: ?*const zx_type_70 = null,
};

pub const value_zx_type_71_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    index: u64,
    input: value_zx_type_70_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    valid: bool,
    zx_origin: ?*const zx_type_71 = null,
};

pub const value_zx_type_72_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    max_offset: u64,
    symbols: *const zx_type_40,
    zx_origin: ?*const zx_type_72 = null,
};

pub const value_zx_type_73_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_37,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
    zx_origin: ?*const zx_type_73 = null,
};

pub const value_zx_type_74_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
    zx_origin: ?*const zx_type_74 = null,
};

pub const value_zx_type_75_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    index: u64,
    input: value_zx_type_74_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    next: u64,
    valid: bool,
    zx_origin: ?*const zx_type_75 = null,
};

pub const value_zx_type_76_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    max_offset: u64,
    table: *const zx_type_37,
    zx_origin: ?*const zx_type_76 = null,
};

pub const value_zx_type_77_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct {
    contracts: value_zx_type_45_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    max_offset: u64,
    zx_origin: ?*const zx_type_77 = null,
};

pub const value_zx_type_78_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8 = struct {
    contracts: value_zx_type_45_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    max_offset: u64,
    valid: bool,
    zx_origin: ?*const zx_type_78 = null,
};

pub const value_zx_type_79_77f92a94475a19d8ed0cfd5a8514d16e10084be3ce8b69601f9888c24377d312 = struct {
    has_ensures: bool,
    index: u64,
    program: value_zx_type_46_e366d4f93466af93bfbf8b4815757383af115756f7364062c2c9d566a0fb2311,
    valid: bool,
    zx_origin: ?*const zx_type_79 = null,
};

pub const value_zx_type_80_5c313489c23e32ceb598bb1ec4fec487cc713ac7322bf041fdc53b4e12d32b93 = struct { value_zx_type_46_e366d4f93466af93bfbf8b4815757383af115756f7364062c2c9d566a0fb2311, ?*const zx_type_80, };

pub const value_zx_type_81_60451259cf31e510553235f54e0434b72b6fbe03b2f9ed46cbf296041cb3f4c2 = struct { value_zx_type_46_e366d4f93466af93bfbf8b4815757383af115756f7364062c2c9d566a0fb2311, bool, ?*const zx_type_81, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
    pub const @"zig:floats" = struct {
        pub const narrow = struct {
            pub const Input = f64;
            pub const Output = f32;
            pub const InputValue = f64;
            pub const OutputValue = f32;
        };
        pub const widen = struct {
            pub const Input = f32;
            pub const Output = f64;
            pub const InputValue = f32;
            pub const OutputValue = f64;
        };
        pub const isFinite = struct {
            pub const Input = f64;
            pub const Output = bool;
            pub const InputValue = f64;
            pub const OutputValue = bool;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
    pub const @"zig:floats" = struct {
    };
};

