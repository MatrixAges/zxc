pub const zx_type_12 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
};

pub const zx_type_13 = struct {
    index: u64,
    input: *const zx_type_12,
    valid: bool,
};

pub const zx_type_14 = enum { Copy, Borrowed, Owned, };

pub const zx_type_18 = struct {
    names: []const []const u8,
    ownership: []const zx_type_14,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_19 = struct {
    max_offset: u64,
    symbols: *const zx_type_18,
};

pub const zx_type_20 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_21 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_22 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_23 = enum { Negate, Not, };

pub const zx_type_24 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_34 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_24,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_21,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_20,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_22,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_23,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_35 = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_34,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
};

pub const zx_type_36 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
};

pub const zx_type_37 = struct {
    index: u64,
    input: *const zx_type_36,
    next: u64,
    valid: bool,
};

pub const zx_type_38 = struct {
    max_offset: u64,
    table: *const zx_type_34,
};

pub const zx_type_39 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_41 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_42 = struct {
    base: *const zx_type_41,
    delta: *const zx_type_41,
};

pub const zx_type_43 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_39,
    label: []const u8,
    second: u32,
};

pub const zx_type_44 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_45 = struct {
    children: []const u32,
    fields: *const zx_type_44,
    first: u32,
    kind: zx_type_39,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_46 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_47 = struct {
    delta: *const zx_type_41,
    id: u32,
};

pub const zx_type_48 = enum { Requires, Ensures, };

pub const zx_type_52 = struct {
    expressions: []const *const zx_type_34,
    kinds: []const zx_type_48,
    predicates: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    symbols: []const *const zx_type_18,
};

pub const zx_type_53 = struct {
    contracts: *const zx_type_52,
    input_type: u32,
    max_offset: u64,
    output_type: u32,
    table: *const zx_type_41,
};

pub const zx_type_54 = struct {
    contracts: *const zx_type_52,
    max_offset: u64,
};

pub const zx_type_55 = struct {
    contracts: *const zx_type_52,
    index: u64,
    max_offset: u64,
    valid: bool,
};

pub const zx_type_56 = struct { *const zx_type_54, };

pub const zx_type_57 = struct { *const zx_type_54, bool, };

pub const value_zx_type_12_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    ends: []const u64,
    max_offset: u64,
    starts: []const u64,
    zx_origin: ?*const zx_type_12 = null,
};

pub const value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = struct {
    index: u64,
    input: value_zx_type_12_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    valid: bool,
    zx_origin: ?*const zx_type_13 = null,
};

pub const value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    max_offset: u64,
    symbols: *const zx_type_18,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = struct {
    awaits: u64,
    binary: u64,
    booleans: u64,
    calls: u64,
    cancellations: u64,
    captures: u64,
    collections: u64,
    conditionals: u64,
    enumerations: u64,
    errors: u64,
    floats: u64,
    index: u64,
    indices: u64,
    integers: u64,
    iterations: u64,
    lengths: u64,
    matches: u64,
    negative_integers: u64,
    objects: u64,
    optional_values: u64,
    parallels: u64,
    projections: u64,
    references: u64,
    scopes: u64,
    sequences: u64,
    some: u64,
    stores: u64,
    strings: u64,
    table: *const zx_type_34,
    tasks: u64,
    transforms: u64,
    unary: u64,
    updates: u64,
    valid: bool,
    zx_origin: ?*const zx_type_35 = null,
};

pub const value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: []const u32,
    first: []const u32,
    length: u64,
    zx_origin: ?*const zx_type_36 = null,
};

pub const value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = struct {
    index: u64,
    input: value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    next: u64,
    valid: bool,
    zx_origin: ?*const zx_type_37 = null,
};

pub const value_zx_type_38_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    max_offset: u64,
    table: *const zx_type_34,
    zx_origin: ?*const zx_type_38 = null,
};

pub const value_zx_type_42_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    base: *const zx_type_41,
    delta: *const zx_type_41,
    zx_origin: ?*const zx_type_42 = null,
};

pub const value_zx_type_43_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_39,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_43 = null,
};

pub const value_zx_type_44_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_44 = null,
};

pub const value_zx_type_45_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_44_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_39,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_45 = null,
};

pub const value_zx_type_46_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_46 = null,
};

pub const value_zx_type_47_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    delta: *const zx_type_41,
    id: u32,
    zx_origin: ?*const zx_type_47 = null,
};

pub const value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    expressions: []const *const zx_type_34,
    kinds: []const zx_type_48,
    predicates: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    symbols: []const *const zx_type_18,
    zx_origin: ?*const zx_type_52 = null,
};

pub const value_zx_type_53_e366d4f93466af93bfbf8b4815757383af115756f7364062c2c9d566a0fb2311 = struct {
    contracts: value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    input_type: u32,
    max_offset: u64,
    output_type: u32,
    table: *const zx_type_41,
    zx_origin: ?*const zx_type_53 = null,
};

pub const value_zx_type_54_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct {
    contracts: value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    max_offset: u64,
    zx_origin: ?*const zx_type_54 = null,
};

pub const value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8 = struct {
    contracts: value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    index: u64,
    max_offset: u64,
    valid: bool,
    zx_origin: ?*const zx_type_55 = null,
};

pub const value_zx_type_56_4bb438ff01f237569bb9646dc2578b71e2a1e16fa8fe9e4b0b9d926ac5640cd1 = struct { value_zx_type_54_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, ?*const zx_type_56, };

pub const value_zx_type_57_80fa3f09fde2ea8660c1d43e969ee3d68c4cda0e85a50de87ab5f1fb43c5c390 = struct { value_zx_type_54_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, ?*const zx_type_57, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
};

