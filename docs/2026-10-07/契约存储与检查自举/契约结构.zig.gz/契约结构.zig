const std = @import("std");

const zx_native_0 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .ends = zx_shape_11, .max_offset = zx_shape_5, .starts = zx_shape_11, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .input = zx_shape_12, .valid = zx_shape_1, }, };

const zx_shape_14 = .{ .kind = .scalar, };

const zx_shape_15 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_16 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_17 = .{ .kind = .list, .child = zx_shape_14, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .names = zx_shape_15, .ownership = zx_shape_17, .span_end = zx_shape_11, .span_start = zx_shape_11, .types = zx_shape_16, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .max_offset = zx_shape_5, .symbols = zx_shape_18, }, };

const zx_shape_20 = .{ .kind = .scalar, };

const zx_shape_21 = .{ .kind = .scalar, };

const zx_shape_22 = .{ .kind = .scalar, };

const zx_shape_23 = .{ .kind = .scalar, };

const zx_shape_24 = .{ .kind = .scalar, };

const zx_shape_25 = .{ .kind = .list, .child = zx_shape_20, };

const zx_shape_26 = .{ .kind = .list, .child = zx_shape_9, };

const zx_shape_27 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_28 = .{ .kind = .optional, .child = zx_shape_4, };

const zx_shape_29 = .{ .kind = .list, .child = zx_shape_28, };

const zx_shape_30 = .{ .kind = .list, .child = zx_shape_21, };

const zx_shape_31 = .{ .kind = .list, .child = zx_shape_22, };

const zx_shape_32 = .{ .kind = .list, .child = zx_shape_23, };

const zx_shape_33 = .{ .kind = .list, .child = zx_shape_24, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .awaits = zx_shape_16, .binary_left = zx_shape_16, .binary_operators = zx_shape_33, .binary_right = zx_shape_16, .booleans = zx_shape_27, .call_arguments = zx_shape_16, .call_functions = zx_shape_16, .call_store_count = zx_shape_16, .call_store_first = zx_shape_16, .call_stores = zx_shape_16, .cancellations = zx_shape_16, .captures = zx_shape_16, .collection_arguments = zx_shape_16, .collection_count = zx_shape_16, .collection_first = zx_shape_16, .collection_kinds = zx_shape_30, .collection_targets = zx_shape_16, .conditional_conditions = zx_shape_16, .conditional_no = zx_shape_16, .conditional_yes = zx_shape_16, .enumerations = zx_shape_16, .errors = zx_shape_16, .floats = zx_shape_26, .index_targets = zx_shape_16, .index_values = zx_shape_16, .integers = zx_shape_11, .iteration_bodies = zx_shape_16, .iteration_condition_parameters = zx_shape_16, .iteration_conditions = zx_shape_16, .iteration_initials = zx_shape_16, .iteration_parameters = zx_shape_16, .iteration_postconditions = zx_shape_27, .kinds = zx_shape_25, .lengths = zx_shape_16, .match_conditions = zx_shape_16, .match_count = zx_shape_16, .match_fallbacks = zx_shape_16, .match_first = zx_shape_16, .match_results = zx_shape_16, .match_subjects = zx_shape_29, .negative_integers = zx_shape_11, .object_count = zx_shape_16, .object_evaluation_count = zx_shape_16, .object_evaluation_first = zx_shape_16, .object_evaluation_values = zx_shape_16, .object_field_indices = zx_shape_16, .object_field_values = zx_shape_16, .object_first = zx_shape_16, .optional_values = zx_shape_16, .parallel_count = zx_shape_16, .parallel_fields = zx_shape_29, .parallel_first = zx_shape_16, .parallel_tasks = zx_shape_16, .payloads = zx_shape_16, .projection_indices = zx_shape_16, .projection_targets = zx_shape_16, .references = zx_shape_16, .scope_borrows = zx_shape_27, .scope_count = zx_shape_16, .scope_first = zx_shape_16, .scope_results = zx_shape_16, .scope_symbols = zx_shape_29, .scope_values = zx_shape_16, .sequence_count = zx_shape_16, .sequence_first = zx_shape_16, .sequence_items = zx_shape_16, .some = zx_shape_16, .span_end = zx_shape_11, .span_start = zx_shape_11, .stores = zx_shape_16, .strings = zx_shape_15, .task_bodies = zx_shape_16, .task_capture_count = zx_shape_16, .task_capture_first = zx_shape_16, .task_captures = zx_shape_16, .transform_bodies = zx_shape_16, .transform_count = zx_shape_16, .transform_first = zx_shape_16, .transform_initials = zx_shape_29, .transform_kinds = zx_shape_31, .transform_parameters = zx_shape_16, .transform_targets = zx_shape_16, .types = zx_shape_16, .unary_operands = zx_shape_16, .unary_operators = zx_shape_32, .update_indices = zx_shape_16, .update_targets = zx_shape_16, .update_values = zx_shape_16, }, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .awaits = zx_shape_5, .binary = zx_shape_5, .booleans = zx_shape_5, .calls = zx_shape_5, .cancellations = zx_shape_5, .captures = zx_shape_5, .collections = zx_shape_5, .conditionals = zx_shape_5, .enumerations = zx_shape_5, .errors = zx_shape_5, .floats = zx_shape_5, .index = zx_shape_5, .indices = zx_shape_5, .integers = zx_shape_5, .iterations = zx_shape_5, .lengths = zx_shape_5, .matches = zx_shape_5, .negative_integers = zx_shape_5, .objects = zx_shape_5, .optional_values = zx_shape_5, .parallels = zx_shape_5, .projections = zx_shape_5, .references = zx_shape_5, .scopes = zx_shape_5, .sequences = zx_shape_5, .some = zx_shape_5, .stores = zx_shape_5, .strings = zx_shape_5, .table = zx_shape_34, .tasks = zx_shape_5, .transforms = zx_shape_5, .unary = zx_shape_5, .updates = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_36 = .{ .kind = .object, .fields = .{ .count = zx_shape_16, .first = zx_shape_16, .length = zx_shape_5, }, };

const zx_shape_37 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .input = zx_shape_36, .next = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_38 = .{ .kind = .object, .fields = .{ .max_offset = zx_shape_5, .table = zx_shape_34, }, };

const zx_shape_39 = .{ .kind = .scalar, };

const zx_shape_40 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_41 = .{ .kind = .object, .fields = .{ .children = zx_shape_16, .field_names = zx_shape_15, .field_types = zx_shape_16, .first = zx_shape_16, .kinds = zx_shape_40, .labels = zx_shape_15, .names = zx_shape_15, .second = zx_shape_16, }, };

const zx_shape_42 = .{ .kind = .object, .fields = .{ .base = zx_shape_41, .delta = zx_shape_41, }, };

const zx_shape_43 = .{ .kind = .object, .fields = .{ .delta = zx_shape_1, .first = zx_shape_4, .kind = zx_shape_39, .label = zx_shape_10, .second = zx_shape_4, }, };

const zx_shape_44 = .{ .kind = .object, .fields = .{ .names = zx_shape_15, .types = zx_shape_16, }, };

const zx_shape_45 = .{ .kind = .object, .fields = .{ .children = zx_shape_16, .fields = zx_shape_44, .first = zx_shape_4, .kind = zx_shape_39, .label = zx_shape_10, .names = zx_shape_15, .second = zx_shape_4, }, };

const zx_shape_46 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .id = zx_shape_4, }, };

const zx_shape_47 = .{ .kind = .object, .fields = .{ .delta = zx_shape_41, .id = zx_shape_4, }, };

const zx_shape_48 = .{ .kind = .scalar, };

const zx_shape_49 = .{ .kind = .list, .child = zx_shape_48, };

const zx_shape_50 = .{ .kind = .list, .child = zx_shape_18, };

const zx_shape_51 = .{ .kind = .list, .child = zx_shape_34, };

const zx_shape_52 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_51, .kinds = zx_shape_49, .predicates = zx_shape_16, .span_end = zx_shape_11, .span_start = zx_shape_11, .symbols = zx_shape_50, }, };

const zx_shape_53 = .{ .kind = .object, .fields = .{ .contracts = zx_shape_52, .input_type = zx_shape_4, .max_offset = zx_shape_5, .output_type = zx_shape_4, .table = zx_shape_41, }, };

const zx_shape_54 = .{ .kind = .object, .fields = .{ .contracts = zx_shape_52, .max_offset = zx_shape_5, }, };

const zx_shape_55 = .{ .kind = .object, .fields = .{ .contracts = zx_shape_52, .index = zx_shape_5, .max_offset = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_56 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_54, }, };

const zx_shape_57 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_54, .@"1" = zx_shape_1, }, };

pub const input_shape = zx_shape_54;

pub const output_shape = zx_shape_1;

pub const Input = *const (zx_abi).zx_type_54;

pub const Output = bool;

fn function_0(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_12) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_17: {
        const operand_6 = block_5: {
            const operand_2 = in;
            const operand_3 = @as(u64, 0);
            const operand_4 = true;

            break :block_5 (zx_abi).zx_type_13{ .input = operand_2, .index = operand_3, .valid = operand_4, };
        };

        var state_1: (zx_abi).value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = (zx_abi).value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f{ .index = (operand_6).index, .input = (zx_abi).value_zx_type_12_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .ends = ((operand_6).input).ends, .max_offset = ((operand_6).input).max_offset, .starts = ((operand_6).input).starts, .zx_origin = (operand_6).input, }, .valid = (operand_6).valid, .zx_origin = (&operand_6), };

        while (((state_1).valid and ((state_1).index < @as(u64, (((state_1).input).starts).len)))) {
            state_1 = block_16: {
                const value_3: (zx_abi).value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = state_1;
                const value_4: (zx_abi).value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = block_15: {
                    break :block_15 @as((zx_abi).value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f, (zx_abi).value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f{ .index = (value_3).index, .input = (value_3).input, .valid = ((block_11: {
                        const operand_9 = ((state_1).input).starts;
                        const operand_10 = (state_1).index;

                        if ((operand_10 >= (operand_9).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_11 (operand_9)[@intCast(operand_10)];
                    } <= ((state_1).input).max_offset) and (block_14: {
                        const operand_12 = ((state_1).input).ends;
                        const operand_13 = (state_1).index;

                        if ((operand_13 >= (operand_12).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_14 (operand_12)[@intCast(operand_13)];
                    } <= ((state_1).input).max_offset)), });
                };
                const value_5: (zx_abi).value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = value_4;
                const value_6: u64 = (value_5).index;
                const value_7: (zx_abi).value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f = block_8: {
                    break :block_8 @as((zx_abi).value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f, (zx_abi).value_zx_type_13_8aba688e92428ec178bbadc7c92370aee8b1dc4844a62c0720bc84c764544a8f{ .index = (block_7: {
                        break :block_7 value_6;
                    } + @as(u64, 1)), .input = (value_5).input, .valid = (value_5).valid, });
                };

                break :block_16 value_7;
            };
        }

        break :block_17 (state_1).valid;
    };
}

fn function_1(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_19) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: u64 = @as(u64, (((in).symbols).names).len);

    if ((((((value_1 > @as(u64, 4294967295)) or (value_1 != @as(u64, (((in).symbols).types).len))) or (value_1 != @as(u64, (((in).symbols).ownership).len))) or (value_1 != @as(u64, (((in).symbols).span_start).len))) or (value_1 != @as(u64, (((in).symbols).span_end).len)))) {
        return false;
    }

    return block_5: {
        const operand_1 = ((in).symbols).span_start;
        const operand_2 = ((in).symbols).span_end;
        const operand_3 = (in).max_offset;
        const operand_4 = (zx_abi).zx_type_12{ .starts = operand_1, .ends = operand_2, .max_offset = operand_3, };

        break :block_5 (try function_0(allocator, (&operand_4)));
    };
}

fn function_2(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_4(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_34) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_197: (zx_abi).zx_type_35 = block_307: {
        const operand_37 = block_36: {
            const operand_2 = in;
            const operand_3 = @as(u64, 0);
            const operand_4 = true;
            const operand_5 = @as(u64, 0);
            const operand_6 = @as(u64, 0);
            const operand_7 = @as(u64, 0);
            const operand_8 = @as(u64, 0);
            const operand_9 = @as(u64, 0);
            const operand_10 = @as(u64, 0);
            const operand_11 = @as(u64, 0);
            const operand_12 = @as(u64, 0);
            const operand_13 = @as(u64, 0);
            const operand_14 = @as(u64, 0);
            const operand_15 = @as(u64, 0);
            const operand_16 = @as(u64, 0);
            const operand_17 = @as(u64, 0);
            const operand_18 = @as(u64, 0);
            const operand_19 = @as(u64, 0);
            const operand_20 = @as(u64, 0);
            const operand_21 = @as(u64, 0);
            const operand_22 = @as(u64, 0);
            const operand_23 = @as(u64, 0);
            const operand_24 = @as(u64, 0);
            const operand_25 = @as(u64, 0);
            const operand_26 = @as(u64, 0);
            const operand_27 = @as(u64, 0);
            const operand_28 = @as(u64, 0);
            const operand_29 = @as(u64, 0);
            const operand_30 = @as(u64, 0);
            const operand_31 = @as(u64, 0);
            const operand_32 = @as(u64, 0);
            const operand_33 = @as(u64, 0);
            const operand_34 = @as(u64, 0);
            const operand_35 = @as(u64, 0);

            break :block_36 (zx_abi).zx_type_35{ .table = operand_2, .index = operand_3, .valid = operand_4, .integers = operand_5, .negative_integers = operand_6, .floats = operand_7, .strings = operand_8, .booleans = operand_9, .some = operand_10, .captures = operand_11, .tasks = operand_12, .awaits = operand_13, .cancellations = operand_14, .parallels = operand_15, .optional_values = operand_16, .enumerations = operand_17, .errors = operand_18, .references = operand_19, .stores = operand_20, .projections = operand_21, .indices = operand_22, .lengths = operand_23, .sequences = operand_24, .collections = operand_25, .transforms = operand_26, .scopes = operand_27, .iterations = operand_28, .updates = operand_29, .calls = operand_30, .unary = operand_31, .binary = operand_32, .conditionals = operand_33, .matches = operand_34, .objects = operand_35, };
        };

        var state_1: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (operand_37).awaits, .binary = (operand_37).binary, .booleans = (operand_37).booleans, .calls = (operand_37).calls, .cancellations = (operand_37).cancellations, .captures = (operand_37).captures, .collections = (operand_37).collections, .conditionals = (operand_37).conditionals, .enumerations = (operand_37).enumerations, .errors = (operand_37).errors, .floats = (operand_37).floats, .index = (operand_37).index, .indices = (operand_37).indices, .integers = (operand_37).integers, .iterations = (operand_37).iterations, .lengths = (operand_37).lengths, .matches = (operand_37).matches, .negative_integers = (operand_37).negative_integers, .objects = (operand_37).objects, .optional_values = (operand_37).optional_values, .parallels = (operand_37).parallels, .projections = (operand_37).projections, .references = (operand_37).references, .scopes = (operand_37).scopes, .sequences = (operand_37).sequences, .some = (operand_37).some, .stores = (operand_37).stores, .strings = (operand_37).strings, .table = (operand_37).table, .tasks = (operand_37).tasks, .transforms = (operand_37).transforms, .unary = (operand_37).unary, .updates = (operand_37).updates, .valid = (operand_37).valid, .zx_origin = (&operand_37), };

        while (((state_1).valid and ((state_1).index < @as(u64, (((state_1).table).kinds).len)))) {
            state_1 = block_304: {
                const value_3: (zx_abi).zx_type_20 = block_303: {
                    const operand_301 = ((state_1).table).kinds;
                    const operand_302 = (state_1).index;

                    if ((operand_302 >= (operand_301).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_303 (operand_301)[@intCast(operand_302)];
                };
                const value_4: u64 = block_300: {
                    const operand_299 = block_298: {
                        const operand_296 = ((state_1).table).payloads;
                        const operand_297 = (state_1).index;

                        if ((operand_297 >= (operand_296).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_298 (operand_296)[@intCast(operand_297)];
                    };

                    break :block_300 (try function_2(allocator, operand_299));
                };
                const value_193: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if (((block_40: {
                    break :block_40 value_3;
                } == @as((zx_abi).zx_type_20, .None)) or (block_41: {
                    break :block_41 value_3;
                } == @as((zx_abi).zx_type_20, .Unit)))) block_44: {
                    const value_5: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                    const value_6: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_43: {
                        break :block_43 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_5).awaits, .binary = (value_5).binary, .booleans = (value_5).booleans, .calls = (value_5).calls, .cancellations = (value_5).cancellations, .captures = (value_5).captures, .collections = (value_5).collections, .conditionals = (value_5).conditionals, .enumerations = (value_5).enumerations, .errors = (value_5).errors, .floats = (value_5).floats, .index = (value_5).index, .indices = (value_5).indices, .integers = (value_5).integers, .iterations = (value_5).iterations, .lengths = (value_5).lengths, .matches = (value_5).matches, .negative_integers = (value_5).negative_integers, .objects = (value_5).objects, .optional_values = (value_5).optional_values, .parallels = (value_5).parallels, .projections = (value_5).projections, .references = (value_5).references, .scopes = (value_5).scopes, .sequences = (value_5).sequences, .some = (value_5).some, .stores = (value_5).stores, .strings = (value_5).strings, .table = (value_5).table, .tasks = (value_5).tasks, .transforms = (value_5).transforms, .unary = (value_5).unary, .updates = (value_5).updates, .valid = (block_42: {
                            break :block_42 value_4;
                        } == @as(u64, 0)), });
                    };

                    break :block_44 value_6;
                } else block_295: {
                    const value_192: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_45: {
                        break :block_45 value_3;
                    } == @as((zx_abi).zx_type_20, .Integer))) block_51: {
                        const value_7: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                        const value_8: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_50: {
                            break :block_50 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_7).awaits, .binary = (value_7).binary, .booleans = (value_7).booleans, .calls = (value_7).calls, .cancellations = (value_7).cancellations, .captures = (value_7).captures, .collections = (value_7).collections, .conditionals = (value_7).conditionals, .enumerations = (value_7).enumerations, .errors = (value_7).errors, .floats = (value_7).floats, .index = (value_7).index, .indices = (value_7).indices, .integers = (value_7).integers, .iterations = (value_7).iterations, .lengths = (value_7).lengths, .matches = (value_7).matches, .negative_integers = (value_7).negative_integers, .objects = (value_7).objects, .optional_values = (value_7).optional_values, .parallels = (value_7).parallels, .projections = (value_7).projections, .references = (value_7).references, .scopes = (value_7).scopes, .sequences = (value_7).sequences, .some = (value_7).some, .stores = (value_7).stores, .strings = (value_7).strings, .table = (value_7).table, .tasks = (value_7).tasks, .transforms = (value_7).transforms, .unary = (value_7).unary, .updates = (value_7).updates, .valid = ((block_48: {
                                break :block_48 value_4;
                            } == (state_1).integers) and (block_49: {
                                break :block_49 value_4;
                            } < @as(u64, (((state_1).table).integers).len))), });
                        };
                        const value_9: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_8;
                        const value_10: u64 = (value_9).integers;
                        const value_11: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_47: {
                            break :block_47 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_9).awaits, .binary = (value_9).binary, .booleans = (value_9).booleans, .calls = (value_9).calls, .cancellations = (value_9).cancellations, .captures = (value_9).captures, .collections = (value_9).collections, .conditionals = (value_9).conditionals, .enumerations = (value_9).enumerations, .errors = (value_9).errors, .floats = (value_9).floats, .index = (value_9).index, .indices = (value_9).indices, .integers = (block_46: {
                                break :block_46 value_10;
                            } + @as(u64, 1)), .iterations = (value_9).iterations, .lengths = (value_9).lengths, .matches = (value_9).matches, .negative_integers = (value_9).negative_integers, .objects = (value_9).objects, .optional_values = (value_9).optional_values, .parallels = (value_9).parallels, .projections = (value_9).projections, .references = (value_9).references, .scopes = (value_9).scopes, .sequences = (value_9).sequences, .some = (value_9).some, .stores = (value_9).stores, .strings = (value_9).strings, .table = (value_9).table, .tasks = (value_9).tasks, .transforms = (value_9).transforms, .unary = (value_9).unary, .updates = (value_9).updates, .valid = (value_9).valid, });
                        };

                        break :block_51 value_11;
                    } else block_294: {
                        const value_191: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_52: {
                            break :block_52 value_3;
                        } == @as((zx_abi).zx_type_20, .NegativeInteger))) block_58: {
                            const value_12: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                            const value_13: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_57: {
                                break :block_57 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_12).awaits, .binary = (value_12).binary, .booleans = (value_12).booleans, .calls = (value_12).calls, .cancellations = (value_12).cancellations, .captures = (value_12).captures, .collections = (value_12).collections, .conditionals = (value_12).conditionals, .enumerations = (value_12).enumerations, .errors = (value_12).errors, .floats = (value_12).floats, .index = (value_12).index, .indices = (value_12).indices, .integers = (value_12).integers, .iterations = (value_12).iterations, .lengths = (value_12).lengths, .matches = (value_12).matches, .negative_integers = (value_12).negative_integers, .objects = (value_12).objects, .optional_values = (value_12).optional_values, .parallels = (value_12).parallels, .projections = (value_12).projections, .references = (value_12).references, .scopes = (value_12).scopes, .sequences = (value_12).sequences, .some = (value_12).some, .stores = (value_12).stores, .strings = (value_12).strings, .table = (value_12).table, .tasks = (value_12).tasks, .transforms = (value_12).transforms, .unary = (value_12).unary, .updates = (value_12).updates, .valid = ((block_55: {
                                    break :block_55 value_4;
                                } == (state_1).negative_integers) and (block_56: {
                                    break :block_56 value_4;
                                } < @as(u64, (((state_1).table).negative_integers).len))), });
                            };
                            const value_14: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_13;
                            const value_15: u64 = (value_14).negative_integers;
                            const value_16: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_54: {
                                break :block_54 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_14).awaits, .binary = (value_14).binary, .booleans = (value_14).booleans, .calls = (value_14).calls, .cancellations = (value_14).cancellations, .captures = (value_14).captures, .collections = (value_14).collections, .conditionals = (value_14).conditionals, .enumerations = (value_14).enumerations, .errors = (value_14).errors, .floats = (value_14).floats, .index = (value_14).index, .indices = (value_14).indices, .integers = (value_14).integers, .iterations = (value_14).iterations, .lengths = (value_14).lengths, .matches = (value_14).matches, .negative_integers = (block_53: {
                                    break :block_53 value_15;
                                } + @as(u64, 1)), .objects = (value_14).objects, .optional_values = (value_14).optional_values, .parallels = (value_14).parallels, .projections = (value_14).projections, .references = (value_14).references, .scopes = (value_14).scopes, .sequences = (value_14).sequences, .some = (value_14).some, .stores = (value_14).stores, .strings = (value_14).strings, .table = (value_14).table, .tasks = (value_14).tasks, .transforms = (value_14).transforms, .unary = (value_14).unary, .updates = (value_14).updates, .valid = (value_14).valid, });
                            };

                            break :block_58 value_16;
                        } else block_293: {
                            const value_190: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_59: {
                                break :block_59 value_3;
                            } == @as((zx_abi).zx_type_20, .Float))) block_65: {
                                const value_17: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                const value_18: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_64: {
                                    break :block_64 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_17).awaits, .binary = (value_17).binary, .booleans = (value_17).booleans, .calls = (value_17).calls, .cancellations = (value_17).cancellations, .captures = (value_17).captures, .collections = (value_17).collections, .conditionals = (value_17).conditionals, .enumerations = (value_17).enumerations, .errors = (value_17).errors, .floats = (value_17).floats, .index = (value_17).index, .indices = (value_17).indices, .integers = (value_17).integers, .iterations = (value_17).iterations, .lengths = (value_17).lengths, .matches = (value_17).matches, .negative_integers = (value_17).negative_integers, .objects = (value_17).objects, .optional_values = (value_17).optional_values, .parallels = (value_17).parallels, .projections = (value_17).projections, .references = (value_17).references, .scopes = (value_17).scopes, .sequences = (value_17).sequences, .some = (value_17).some, .stores = (value_17).stores, .strings = (value_17).strings, .table = (value_17).table, .tasks = (value_17).tasks, .transforms = (value_17).transforms, .unary = (value_17).unary, .updates = (value_17).updates, .valid = ((block_62: {
                                        break :block_62 value_4;
                                    } == (state_1).floats) and (block_63: {
                                        break :block_63 value_4;
                                    } < @as(u64, (((state_1).table).floats).len))), });
                                };
                                const value_19: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_18;
                                const value_20: u64 = (value_19).floats;
                                const value_21: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_61: {
                                    break :block_61 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_19).awaits, .binary = (value_19).binary, .booleans = (value_19).booleans, .calls = (value_19).calls, .cancellations = (value_19).cancellations, .captures = (value_19).captures, .collections = (value_19).collections, .conditionals = (value_19).conditionals, .enumerations = (value_19).enumerations, .errors = (value_19).errors, .floats = (block_60: {
                                        break :block_60 value_20;
                                    } + @as(u64, 1)), .index = (value_19).index, .indices = (value_19).indices, .integers = (value_19).integers, .iterations = (value_19).iterations, .lengths = (value_19).lengths, .matches = (value_19).matches, .negative_integers = (value_19).negative_integers, .objects = (value_19).objects, .optional_values = (value_19).optional_values, .parallels = (value_19).parallels, .projections = (value_19).projections, .references = (value_19).references, .scopes = (value_19).scopes, .sequences = (value_19).sequences, .some = (value_19).some, .stores = (value_19).stores, .strings = (value_19).strings, .table = (value_19).table, .tasks = (value_19).tasks, .transforms = (value_19).transforms, .unary = (value_19).unary, .updates = (value_19).updates, .valid = (value_19).valid, });
                                };

                                break :block_65 value_21;
                            } else block_292: {
                                const value_189: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_66: {
                                    break :block_66 value_3;
                                } == @as((zx_abi).zx_type_20, .String))) block_72: {
                                    const value_22: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                    const value_23: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_71: {
                                        break :block_71 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_22).awaits, .binary = (value_22).binary, .booleans = (value_22).booleans, .calls = (value_22).calls, .cancellations = (value_22).cancellations, .captures = (value_22).captures, .collections = (value_22).collections, .conditionals = (value_22).conditionals, .enumerations = (value_22).enumerations, .errors = (value_22).errors, .floats = (value_22).floats, .index = (value_22).index, .indices = (value_22).indices, .integers = (value_22).integers, .iterations = (value_22).iterations, .lengths = (value_22).lengths, .matches = (value_22).matches, .negative_integers = (value_22).negative_integers, .objects = (value_22).objects, .optional_values = (value_22).optional_values, .parallels = (value_22).parallels, .projections = (value_22).projections, .references = (value_22).references, .scopes = (value_22).scopes, .sequences = (value_22).sequences, .some = (value_22).some, .stores = (value_22).stores, .strings = (value_22).strings, .table = (value_22).table, .tasks = (value_22).tasks, .transforms = (value_22).transforms, .unary = (value_22).unary, .updates = (value_22).updates, .valid = ((block_69: {
                                            break :block_69 value_4;
                                        } == (state_1).strings) and (block_70: {
                                            break :block_70 value_4;
                                        } < @as(u64, (((state_1).table).strings).len))), });
                                    };
                                    const value_24: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_23;
                                    const value_25: u64 = (value_24).strings;
                                    const value_26: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_68: {
                                        break :block_68 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_24).awaits, .binary = (value_24).binary, .booleans = (value_24).booleans, .calls = (value_24).calls, .cancellations = (value_24).cancellations, .captures = (value_24).captures, .collections = (value_24).collections, .conditionals = (value_24).conditionals, .enumerations = (value_24).enumerations, .errors = (value_24).errors, .floats = (value_24).floats, .index = (value_24).index, .indices = (value_24).indices, .integers = (value_24).integers, .iterations = (value_24).iterations, .lengths = (value_24).lengths, .matches = (value_24).matches, .negative_integers = (value_24).negative_integers, .objects = (value_24).objects, .optional_values = (value_24).optional_values, .parallels = (value_24).parallels, .projections = (value_24).projections, .references = (value_24).references, .scopes = (value_24).scopes, .sequences = (value_24).sequences, .some = (value_24).some, .stores = (value_24).stores, .strings = (block_67: {
                                            break :block_67 value_25;
                                        } + @as(u64, 1)), .table = (value_24).table, .tasks = (value_24).tasks, .transforms = (value_24).transforms, .unary = (value_24).unary, .updates = (value_24).updates, .valid = (value_24).valid, });
                                    };

                                    break :block_72 value_26;
                                } else block_291: {
                                    const value_188: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_73: {
                                        break :block_73 value_3;
                                    } == @as((zx_abi).zx_type_20, .Boolean))) block_79: {
                                        const value_27: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                        const value_28: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_78: {
                                            break :block_78 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_27).awaits, .binary = (value_27).binary, .booleans = (value_27).booleans, .calls = (value_27).calls, .cancellations = (value_27).cancellations, .captures = (value_27).captures, .collections = (value_27).collections, .conditionals = (value_27).conditionals, .enumerations = (value_27).enumerations, .errors = (value_27).errors, .floats = (value_27).floats, .index = (value_27).index, .indices = (value_27).indices, .integers = (value_27).integers, .iterations = (value_27).iterations, .lengths = (value_27).lengths, .matches = (value_27).matches, .negative_integers = (value_27).negative_integers, .objects = (value_27).objects, .optional_values = (value_27).optional_values, .parallels = (value_27).parallels, .projections = (value_27).projections, .references = (value_27).references, .scopes = (value_27).scopes, .sequences = (value_27).sequences, .some = (value_27).some, .stores = (value_27).stores, .strings = (value_27).strings, .table = (value_27).table, .tasks = (value_27).tasks, .transforms = (value_27).transforms, .unary = (value_27).unary, .updates = (value_27).updates, .valid = ((block_76: {
                                                break :block_76 value_4;
                                            } == (state_1).booleans) and (block_77: {
                                                break :block_77 value_4;
                                            } < @as(u64, (((state_1).table).booleans).len))), });
                                        };
                                        const value_29: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_28;
                                        const value_30: u64 = (value_29).booleans;
                                        const value_31: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_75: {
                                            break :block_75 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_29).awaits, .binary = (value_29).binary, .booleans = (block_74: {
                                                break :block_74 value_30;
                                            } + @as(u64, 1)), .calls = (value_29).calls, .cancellations = (value_29).cancellations, .captures = (value_29).captures, .collections = (value_29).collections, .conditionals = (value_29).conditionals, .enumerations = (value_29).enumerations, .errors = (value_29).errors, .floats = (value_29).floats, .index = (value_29).index, .indices = (value_29).indices, .integers = (value_29).integers, .iterations = (value_29).iterations, .lengths = (value_29).lengths, .matches = (value_29).matches, .negative_integers = (value_29).negative_integers, .objects = (value_29).objects, .optional_values = (value_29).optional_values, .parallels = (value_29).parallels, .projections = (value_29).projections, .references = (value_29).references, .scopes = (value_29).scopes, .sequences = (value_29).sequences, .some = (value_29).some, .stores = (value_29).stores, .strings = (value_29).strings, .table = (value_29).table, .tasks = (value_29).tasks, .transforms = (value_29).transforms, .unary = (value_29).unary, .updates = (value_29).updates, .valid = (value_29).valid, });
                                        };

                                        break :block_79 value_31;
                                    } else block_290: {
                                        const value_187: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_80: {
                                            break :block_80 value_3;
                                        } == @as((zx_abi).zx_type_20, .Some))) block_86: {
                                            const value_32: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                            const value_33: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_85: {
                                                break :block_85 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_32).awaits, .binary = (value_32).binary, .booleans = (value_32).booleans, .calls = (value_32).calls, .cancellations = (value_32).cancellations, .captures = (value_32).captures, .collections = (value_32).collections, .conditionals = (value_32).conditionals, .enumerations = (value_32).enumerations, .errors = (value_32).errors, .floats = (value_32).floats, .index = (value_32).index, .indices = (value_32).indices, .integers = (value_32).integers, .iterations = (value_32).iterations, .lengths = (value_32).lengths, .matches = (value_32).matches, .negative_integers = (value_32).negative_integers, .objects = (value_32).objects, .optional_values = (value_32).optional_values, .parallels = (value_32).parallels, .projections = (value_32).projections, .references = (value_32).references, .scopes = (value_32).scopes, .sequences = (value_32).sequences, .some = (value_32).some, .stores = (value_32).stores, .strings = (value_32).strings, .table = (value_32).table, .tasks = (value_32).tasks, .transforms = (value_32).transforms, .unary = (value_32).unary, .updates = (value_32).updates, .valid = ((block_83: {
                                                    break :block_83 value_4;
                                                } == (state_1).some) and (block_84: {
                                                    break :block_84 value_4;
                                                } < @as(u64, (((state_1).table).some).len))), });
                                            };
                                            const value_34: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_33;
                                            const value_35: u64 = (value_34).some;
                                            const value_36: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_82: {
                                                break :block_82 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_34).awaits, .binary = (value_34).binary, .booleans = (value_34).booleans, .calls = (value_34).calls, .cancellations = (value_34).cancellations, .captures = (value_34).captures, .collections = (value_34).collections, .conditionals = (value_34).conditionals, .enumerations = (value_34).enumerations, .errors = (value_34).errors, .floats = (value_34).floats, .index = (value_34).index, .indices = (value_34).indices, .integers = (value_34).integers, .iterations = (value_34).iterations, .lengths = (value_34).lengths, .matches = (value_34).matches, .negative_integers = (value_34).negative_integers, .objects = (value_34).objects, .optional_values = (value_34).optional_values, .parallels = (value_34).parallels, .projections = (value_34).projections, .references = (value_34).references, .scopes = (value_34).scopes, .sequences = (value_34).sequences, .some = (block_81: {
                                                    break :block_81 value_35;
                                                } + @as(u64, 1)), .stores = (value_34).stores, .strings = (value_34).strings, .table = (value_34).table, .tasks = (value_34).tasks, .transforms = (value_34).transforms, .unary = (value_34).unary, .updates = (value_34).updates, .valid = (value_34).valid, });
                                            };

                                            break :block_86 value_36;
                                        } else block_289: {
                                            const value_186: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_87: {
                                                break :block_87 value_3;
                                            } == @as((zx_abi).zx_type_20, .Capture))) block_93: {
                                                const value_37: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                const value_38: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_92: {
                                                    break :block_92 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_37).awaits, .binary = (value_37).binary, .booleans = (value_37).booleans, .calls = (value_37).calls, .cancellations = (value_37).cancellations, .captures = (value_37).captures, .collections = (value_37).collections, .conditionals = (value_37).conditionals, .enumerations = (value_37).enumerations, .errors = (value_37).errors, .floats = (value_37).floats, .index = (value_37).index, .indices = (value_37).indices, .integers = (value_37).integers, .iterations = (value_37).iterations, .lengths = (value_37).lengths, .matches = (value_37).matches, .negative_integers = (value_37).negative_integers, .objects = (value_37).objects, .optional_values = (value_37).optional_values, .parallels = (value_37).parallels, .projections = (value_37).projections, .references = (value_37).references, .scopes = (value_37).scopes, .sequences = (value_37).sequences, .some = (value_37).some, .stores = (value_37).stores, .strings = (value_37).strings, .table = (value_37).table, .tasks = (value_37).tasks, .transforms = (value_37).transforms, .unary = (value_37).unary, .updates = (value_37).updates, .valid = ((block_90: {
                                                        break :block_90 value_4;
                                                    } == (state_1).captures) and (block_91: {
                                                        break :block_91 value_4;
                                                    } < @as(u64, (((state_1).table).captures).len))), });
                                                };
                                                const value_39: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_38;
                                                const value_40: u64 = (value_39).captures;
                                                const value_41: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_89: {
                                                    break :block_89 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_39).awaits, .binary = (value_39).binary, .booleans = (value_39).booleans, .calls = (value_39).calls, .cancellations = (value_39).cancellations, .captures = (block_88: {
                                                        break :block_88 value_40;
                                                    } + @as(u64, 1)), .collections = (value_39).collections, .conditionals = (value_39).conditionals, .enumerations = (value_39).enumerations, .errors = (value_39).errors, .floats = (value_39).floats, .index = (value_39).index, .indices = (value_39).indices, .integers = (value_39).integers, .iterations = (value_39).iterations, .lengths = (value_39).lengths, .matches = (value_39).matches, .negative_integers = (value_39).negative_integers, .objects = (value_39).objects, .optional_values = (value_39).optional_values, .parallels = (value_39).parallels, .projections = (value_39).projections, .references = (value_39).references, .scopes = (value_39).scopes, .sequences = (value_39).sequences, .some = (value_39).some, .stores = (value_39).stores, .strings = (value_39).strings, .table = (value_39).table, .tasks = (value_39).tasks, .transforms = (value_39).transforms, .unary = (value_39).unary, .updates = (value_39).updates, .valid = (value_39).valid, });
                                                };

                                                break :block_93 value_41;
                                            } else block_288: {
                                                const value_185: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_94: {
                                                    break :block_94 value_3;
                                                } == @as((zx_abi).zx_type_20, .Task))) block_100: {
                                                    const value_42: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                    const value_43: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_99: {
                                                        break :block_99 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_42).awaits, .binary = (value_42).binary, .booleans = (value_42).booleans, .calls = (value_42).calls, .cancellations = (value_42).cancellations, .captures = (value_42).captures, .collections = (value_42).collections, .conditionals = (value_42).conditionals, .enumerations = (value_42).enumerations, .errors = (value_42).errors, .floats = (value_42).floats, .index = (value_42).index, .indices = (value_42).indices, .integers = (value_42).integers, .iterations = (value_42).iterations, .lengths = (value_42).lengths, .matches = (value_42).matches, .negative_integers = (value_42).negative_integers, .objects = (value_42).objects, .optional_values = (value_42).optional_values, .parallels = (value_42).parallels, .projections = (value_42).projections, .references = (value_42).references, .scopes = (value_42).scopes, .sequences = (value_42).sequences, .some = (value_42).some, .stores = (value_42).stores, .strings = (value_42).strings, .table = (value_42).table, .tasks = (value_42).tasks, .transforms = (value_42).transforms, .unary = (value_42).unary, .updates = (value_42).updates, .valid = ((block_97: {
                                                            break :block_97 value_4;
                                                        } == (state_1).tasks) and (block_98: {
                                                            break :block_98 value_4;
                                                        } < @as(u64, (((state_1).table).task_bodies).len))), });
                                                    };
                                                    const value_44: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_43;
                                                    const value_45: u64 = (value_44).tasks;
                                                    const value_46: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_96: {
                                                        break :block_96 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_44).awaits, .binary = (value_44).binary, .booleans = (value_44).booleans, .calls = (value_44).calls, .cancellations = (value_44).cancellations, .captures = (value_44).captures, .collections = (value_44).collections, .conditionals = (value_44).conditionals, .enumerations = (value_44).enumerations, .errors = (value_44).errors, .floats = (value_44).floats, .index = (value_44).index, .indices = (value_44).indices, .integers = (value_44).integers, .iterations = (value_44).iterations, .lengths = (value_44).lengths, .matches = (value_44).matches, .negative_integers = (value_44).negative_integers, .objects = (value_44).objects, .optional_values = (value_44).optional_values, .parallels = (value_44).parallels, .projections = (value_44).projections, .references = (value_44).references, .scopes = (value_44).scopes, .sequences = (value_44).sequences, .some = (value_44).some, .stores = (value_44).stores, .strings = (value_44).strings, .table = (value_44).table, .tasks = (block_95: {
                                                            break :block_95 value_45;
                                                        } + @as(u64, 1)), .transforms = (value_44).transforms, .unary = (value_44).unary, .updates = (value_44).updates, .valid = (value_44).valid, });
                                                    };

                                                    break :block_100 value_46;
                                                } else block_287: {
                                                    const value_184: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_101: {
                                                        break :block_101 value_3;
                                                    } == @as((zx_abi).zx_type_20, .AwaitTask))) block_107: {
                                                        const value_47: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                        const value_48: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_106: {
                                                            break :block_106 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_47).awaits, .binary = (value_47).binary, .booleans = (value_47).booleans, .calls = (value_47).calls, .cancellations = (value_47).cancellations, .captures = (value_47).captures, .collections = (value_47).collections, .conditionals = (value_47).conditionals, .enumerations = (value_47).enumerations, .errors = (value_47).errors, .floats = (value_47).floats, .index = (value_47).index, .indices = (value_47).indices, .integers = (value_47).integers, .iterations = (value_47).iterations, .lengths = (value_47).lengths, .matches = (value_47).matches, .negative_integers = (value_47).negative_integers, .objects = (value_47).objects, .optional_values = (value_47).optional_values, .parallels = (value_47).parallels, .projections = (value_47).projections, .references = (value_47).references, .scopes = (value_47).scopes, .sequences = (value_47).sequences, .some = (value_47).some, .stores = (value_47).stores, .strings = (value_47).strings, .table = (value_47).table, .tasks = (value_47).tasks, .transforms = (value_47).transforms, .unary = (value_47).unary, .updates = (value_47).updates, .valid = ((block_104: {
                                                                break :block_104 value_4;
                                                            } == (state_1).awaits) and (block_105: {
                                                                break :block_105 value_4;
                                                            } < @as(u64, (((state_1).table).awaits).len))), });
                                                        };
                                                        const value_49: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_48;
                                                        const value_50: u64 = (value_49).awaits;
                                                        const value_51: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_103: {
                                                            break :block_103 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (block_102: {
                                                                break :block_102 value_50;
                                                            } + @as(u64, 1)), .binary = (value_49).binary, .booleans = (value_49).booleans, .calls = (value_49).calls, .cancellations = (value_49).cancellations, .captures = (value_49).captures, .collections = (value_49).collections, .conditionals = (value_49).conditionals, .enumerations = (value_49).enumerations, .errors = (value_49).errors, .floats = (value_49).floats, .index = (value_49).index, .indices = (value_49).indices, .integers = (value_49).integers, .iterations = (value_49).iterations, .lengths = (value_49).lengths, .matches = (value_49).matches, .negative_integers = (value_49).negative_integers, .objects = (value_49).objects, .optional_values = (value_49).optional_values, .parallels = (value_49).parallels, .projections = (value_49).projections, .references = (value_49).references, .scopes = (value_49).scopes, .sequences = (value_49).sequences, .some = (value_49).some, .stores = (value_49).stores, .strings = (value_49).strings, .table = (value_49).table, .tasks = (value_49).tasks, .transforms = (value_49).transforms, .unary = (value_49).unary, .updates = (value_49).updates, .valid = (value_49).valid, });
                                                        };

                                                        break :block_107 value_51;
                                                    } else block_286: {
                                                        const value_183: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_108: {
                                                            break :block_108 value_3;
                                                        } == @as((zx_abi).zx_type_20, .CancelTask))) block_114: {
                                                            const value_52: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                            const value_53: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_113: {
                                                                break :block_113 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_52).awaits, .binary = (value_52).binary, .booleans = (value_52).booleans, .calls = (value_52).calls, .cancellations = (value_52).cancellations, .captures = (value_52).captures, .collections = (value_52).collections, .conditionals = (value_52).conditionals, .enumerations = (value_52).enumerations, .errors = (value_52).errors, .floats = (value_52).floats, .index = (value_52).index, .indices = (value_52).indices, .integers = (value_52).integers, .iterations = (value_52).iterations, .lengths = (value_52).lengths, .matches = (value_52).matches, .negative_integers = (value_52).negative_integers, .objects = (value_52).objects, .optional_values = (value_52).optional_values, .parallels = (value_52).parallels, .projections = (value_52).projections, .references = (value_52).references, .scopes = (value_52).scopes, .sequences = (value_52).sequences, .some = (value_52).some, .stores = (value_52).stores, .strings = (value_52).strings, .table = (value_52).table, .tasks = (value_52).tasks, .transforms = (value_52).transforms, .unary = (value_52).unary, .updates = (value_52).updates, .valid = ((block_111: {
                                                                    break :block_111 value_4;
                                                                } == (state_1).cancellations) and (block_112: {
                                                                    break :block_112 value_4;
                                                                } < @as(u64, (((state_1).table).cancellations).len))), });
                                                            };
                                                            const value_54: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_53;
                                                            const value_55: u64 = (value_54).cancellations;
                                                            const value_56: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_110: {
                                                                break :block_110 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_54).awaits, .binary = (value_54).binary, .booleans = (value_54).booleans, .calls = (value_54).calls, .cancellations = (block_109: {
                                                                    break :block_109 value_55;
                                                                } + @as(u64, 1)), .captures = (value_54).captures, .collections = (value_54).collections, .conditionals = (value_54).conditionals, .enumerations = (value_54).enumerations, .errors = (value_54).errors, .floats = (value_54).floats, .index = (value_54).index, .indices = (value_54).indices, .integers = (value_54).integers, .iterations = (value_54).iterations, .lengths = (value_54).lengths, .matches = (value_54).matches, .negative_integers = (value_54).negative_integers, .objects = (value_54).objects, .optional_values = (value_54).optional_values, .parallels = (value_54).parallels, .projections = (value_54).projections, .references = (value_54).references, .scopes = (value_54).scopes, .sequences = (value_54).sequences, .some = (value_54).some, .stores = (value_54).stores, .strings = (value_54).strings, .table = (value_54).table, .tasks = (value_54).tasks, .transforms = (value_54).transforms, .unary = (value_54).unary, .updates = (value_54).updates, .valid = (value_54).valid, });
                                                            };

                                                            break :block_114 value_56;
                                                        } else block_285: {
                                                            const value_182: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_115: {
                                                                break :block_115 value_3;
                                                            } == @as((zx_abi).zx_type_20, .Parallel))) block_121: {
                                                                const value_57: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                const value_58: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_120: {
                                                                    break :block_120 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_57).awaits, .binary = (value_57).binary, .booleans = (value_57).booleans, .calls = (value_57).calls, .cancellations = (value_57).cancellations, .captures = (value_57).captures, .collections = (value_57).collections, .conditionals = (value_57).conditionals, .enumerations = (value_57).enumerations, .errors = (value_57).errors, .floats = (value_57).floats, .index = (value_57).index, .indices = (value_57).indices, .integers = (value_57).integers, .iterations = (value_57).iterations, .lengths = (value_57).lengths, .matches = (value_57).matches, .negative_integers = (value_57).negative_integers, .objects = (value_57).objects, .optional_values = (value_57).optional_values, .parallels = (value_57).parallels, .projections = (value_57).projections, .references = (value_57).references, .scopes = (value_57).scopes, .sequences = (value_57).sequences, .some = (value_57).some, .stores = (value_57).stores, .strings = (value_57).strings, .table = (value_57).table, .tasks = (value_57).tasks, .transforms = (value_57).transforms, .unary = (value_57).unary, .updates = (value_57).updates, .valid = ((block_118: {
                                                                        break :block_118 value_4;
                                                                    } == (state_1).parallels) and (block_119: {
                                                                        break :block_119 value_4;
                                                                    } < @as(u64, (((state_1).table).parallel_first).len))), });
                                                                };
                                                                const value_59: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_58;
                                                                const value_60: u64 = (value_59).parallels;
                                                                const value_61: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_117: {
                                                                    break :block_117 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_59).awaits, .binary = (value_59).binary, .booleans = (value_59).booleans, .calls = (value_59).calls, .cancellations = (value_59).cancellations, .captures = (value_59).captures, .collections = (value_59).collections, .conditionals = (value_59).conditionals, .enumerations = (value_59).enumerations, .errors = (value_59).errors, .floats = (value_59).floats, .index = (value_59).index, .indices = (value_59).indices, .integers = (value_59).integers, .iterations = (value_59).iterations, .lengths = (value_59).lengths, .matches = (value_59).matches, .negative_integers = (value_59).negative_integers, .objects = (value_59).objects, .optional_values = (value_59).optional_values, .parallels = (block_116: {
                                                                        break :block_116 value_60;
                                                                    } + @as(u64, 1)), .projections = (value_59).projections, .references = (value_59).references, .scopes = (value_59).scopes, .sequences = (value_59).sequences, .some = (value_59).some, .stores = (value_59).stores, .strings = (value_59).strings, .table = (value_59).table, .tasks = (value_59).tasks, .transforms = (value_59).transforms, .unary = (value_59).unary, .updates = (value_59).updates, .valid = (value_59).valid, });
                                                                };

                                                                break :block_121 value_61;
                                                            } else block_284: {
                                                                const value_181: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_122: {
                                                                    break :block_122 value_3;
                                                                } == @as((zx_abi).zx_type_20, .OptionalValue))) block_128: {
                                                                    const value_62: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                    const value_63: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_127: {
                                                                        break :block_127 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_62).awaits, .binary = (value_62).binary, .booleans = (value_62).booleans, .calls = (value_62).calls, .cancellations = (value_62).cancellations, .captures = (value_62).captures, .collections = (value_62).collections, .conditionals = (value_62).conditionals, .enumerations = (value_62).enumerations, .errors = (value_62).errors, .floats = (value_62).floats, .index = (value_62).index, .indices = (value_62).indices, .integers = (value_62).integers, .iterations = (value_62).iterations, .lengths = (value_62).lengths, .matches = (value_62).matches, .negative_integers = (value_62).negative_integers, .objects = (value_62).objects, .optional_values = (value_62).optional_values, .parallels = (value_62).parallels, .projections = (value_62).projections, .references = (value_62).references, .scopes = (value_62).scopes, .sequences = (value_62).sequences, .some = (value_62).some, .stores = (value_62).stores, .strings = (value_62).strings, .table = (value_62).table, .tasks = (value_62).tasks, .transforms = (value_62).transforms, .unary = (value_62).unary, .updates = (value_62).updates, .valid = ((block_125: {
                                                                            break :block_125 value_4;
                                                                        } == (state_1).optional_values) and (block_126: {
                                                                            break :block_126 value_4;
                                                                        } < @as(u64, (((state_1).table).optional_values).len))), });
                                                                    };
                                                                    const value_64: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_63;
                                                                    const value_65: u64 = (value_64).optional_values;
                                                                    const value_66: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_124: {
                                                                        break :block_124 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_64).awaits, .binary = (value_64).binary, .booleans = (value_64).booleans, .calls = (value_64).calls, .cancellations = (value_64).cancellations, .captures = (value_64).captures, .collections = (value_64).collections, .conditionals = (value_64).conditionals, .enumerations = (value_64).enumerations, .errors = (value_64).errors, .floats = (value_64).floats, .index = (value_64).index, .indices = (value_64).indices, .integers = (value_64).integers, .iterations = (value_64).iterations, .lengths = (value_64).lengths, .matches = (value_64).matches, .negative_integers = (value_64).negative_integers, .objects = (value_64).objects, .optional_values = (block_123: {
                                                                            break :block_123 value_65;
                                                                        } + @as(u64, 1)), .parallels = (value_64).parallels, .projections = (value_64).projections, .references = (value_64).references, .scopes = (value_64).scopes, .sequences = (value_64).sequences, .some = (value_64).some, .stores = (value_64).stores, .strings = (value_64).strings, .table = (value_64).table, .tasks = (value_64).tasks, .transforms = (value_64).transforms, .unary = (value_64).unary, .updates = (value_64).updates, .valid = (value_64).valid, });
                                                                    };

                                                                    break :block_128 value_66;
                                                                } else block_283: {
                                                                    const value_180: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_129: {
                                                                        break :block_129 value_3;
                                                                    } == @as((zx_abi).zx_type_20, .EnumValue))) block_135: {
                                                                        const value_67: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                        const value_68: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_134: {
                                                                            break :block_134 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_67).awaits, .binary = (value_67).binary, .booleans = (value_67).booleans, .calls = (value_67).calls, .cancellations = (value_67).cancellations, .captures = (value_67).captures, .collections = (value_67).collections, .conditionals = (value_67).conditionals, .enumerations = (value_67).enumerations, .errors = (value_67).errors, .floats = (value_67).floats, .index = (value_67).index, .indices = (value_67).indices, .integers = (value_67).integers, .iterations = (value_67).iterations, .lengths = (value_67).lengths, .matches = (value_67).matches, .negative_integers = (value_67).negative_integers, .objects = (value_67).objects, .optional_values = (value_67).optional_values, .parallels = (value_67).parallels, .projections = (value_67).projections, .references = (value_67).references, .scopes = (value_67).scopes, .sequences = (value_67).sequences, .some = (value_67).some, .stores = (value_67).stores, .strings = (value_67).strings, .table = (value_67).table, .tasks = (value_67).tasks, .transforms = (value_67).transforms, .unary = (value_67).unary, .updates = (value_67).updates, .valid = ((block_132: {
                                                                                break :block_132 value_4;
                                                                            } == (state_1).enumerations) and (block_133: {
                                                                                break :block_133 value_4;
                                                                            } < @as(u64, (((state_1).table).enumerations).len))), });
                                                                        };
                                                                        const value_69: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_68;
                                                                        const value_70: u64 = (value_69).enumerations;
                                                                        const value_71: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_131: {
                                                                            break :block_131 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_69).awaits, .binary = (value_69).binary, .booleans = (value_69).booleans, .calls = (value_69).calls, .cancellations = (value_69).cancellations, .captures = (value_69).captures, .collections = (value_69).collections, .conditionals = (value_69).conditionals, .enumerations = (block_130: {
                                                                                break :block_130 value_70;
                                                                            } + @as(u64, 1)), .errors = (value_69).errors, .floats = (value_69).floats, .index = (value_69).index, .indices = (value_69).indices, .integers = (value_69).integers, .iterations = (value_69).iterations, .lengths = (value_69).lengths, .matches = (value_69).matches, .negative_integers = (value_69).negative_integers, .objects = (value_69).objects, .optional_values = (value_69).optional_values, .parallels = (value_69).parallels, .projections = (value_69).projections, .references = (value_69).references, .scopes = (value_69).scopes, .sequences = (value_69).sequences, .some = (value_69).some, .stores = (value_69).stores, .strings = (value_69).strings, .table = (value_69).table, .tasks = (value_69).tasks, .transforms = (value_69).transforms, .unary = (value_69).unary, .updates = (value_69).updates, .valid = (value_69).valid, });
                                                                        };

                                                                        break :block_135 value_71;
                                                                    } else block_282: {
                                                                        const value_179: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_136: {
                                                                            break :block_136 value_3;
                                                                        } == @as((zx_abi).zx_type_20, .ErrorValue))) block_142: {
                                                                            const value_72: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                            const value_73: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_141: {
                                                                                break :block_141 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_72).awaits, .binary = (value_72).binary, .booleans = (value_72).booleans, .calls = (value_72).calls, .cancellations = (value_72).cancellations, .captures = (value_72).captures, .collections = (value_72).collections, .conditionals = (value_72).conditionals, .enumerations = (value_72).enumerations, .errors = (value_72).errors, .floats = (value_72).floats, .index = (value_72).index, .indices = (value_72).indices, .integers = (value_72).integers, .iterations = (value_72).iterations, .lengths = (value_72).lengths, .matches = (value_72).matches, .negative_integers = (value_72).negative_integers, .objects = (value_72).objects, .optional_values = (value_72).optional_values, .parallels = (value_72).parallels, .projections = (value_72).projections, .references = (value_72).references, .scopes = (value_72).scopes, .sequences = (value_72).sequences, .some = (value_72).some, .stores = (value_72).stores, .strings = (value_72).strings, .table = (value_72).table, .tasks = (value_72).tasks, .transforms = (value_72).transforms, .unary = (value_72).unary, .updates = (value_72).updates, .valid = ((block_139: {
                                                                                    break :block_139 value_4;
                                                                                } == (state_1).errors) and (block_140: {
                                                                                    break :block_140 value_4;
                                                                                } < @as(u64, (((state_1).table).errors).len))), });
                                                                            };
                                                                            const value_74: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_73;
                                                                            const value_75: u64 = (value_74).errors;
                                                                            const value_76: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_138: {
                                                                                break :block_138 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_74).awaits, .binary = (value_74).binary, .booleans = (value_74).booleans, .calls = (value_74).calls, .cancellations = (value_74).cancellations, .captures = (value_74).captures, .collections = (value_74).collections, .conditionals = (value_74).conditionals, .enumerations = (value_74).enumerations, .errors = (block_137: {
                                                                                    break :block_137 value_75;
                                                                                } + @as(u64, 1)), .floats = (value_74).floats, .index = (value_74).index, .indices = (value_74).indices, .integers = (value_74).integers, .iterations = (value_74).iterations, .lengths = (value_74).lengths, .matches = (value_74).matches, .negative_integers = (value_74).negative_integers, .objects = (value_74).objects, .optional_values = (value_74).optional_values, .parallels = (value_74).parallels, .projections = (value_74).projections, .references = (value_74).references, .scopes = (value_74).scopes, .sequences = (value_74).sequences, .some = (value_74).some, .stores = (value_74).stores, .strings = (value_74).strings, .table = (value_74).table, .tasks = (value_74).tasks, .transforms = (value_74).transforms, .unary = (value_74).unary, .updates = (value_74).updates, .valid = (value_74).valid, });
                                                                            };

                                                                            break :block_142 value_76;
                                                                        } else block_281: {
                                                                            const value_178: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_143: {
                                                                                break :block_143 value_3;
                                                                            } == @as((zx_abi).zx_type_20, .Reference))) block_149: {
                                                                                const value_77: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                const value_78: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_148: {
                                                                                    break :block_148 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_77).awaits, .binary = (value_77).binary, .booleans = (value_77).booleans, .calls = (value_77).calls, .cancellations = (value_77).cancellations, .captures = (value_77).captures, .collections = (value_77).collections, .conditionals = (value_77).conditionals, .enumerations = (value_77).enumerations, .errors = (value_77).errors, .floats = (value_77).floats, .index = (value_77).index, .indices = (value_77).indices, .integers = (value_77).integers, .iterations = (value_77).iterations, .lengths = (value_77).lengths, .matches = (value_77).matches, .negative_integers = (value_77).negative_integers, .objects = (value_77).objects, .optional_values = (value_77).optional_values, .parallels = (value_77).parallels, .projections = (value_77).projections, .references = (value_77).references, .scopes = (value_77).scopes, .sequences = (value_77).sequences, .some = (value_77).some, .stores = (value_77).stores, .strings = (value_77).strings, .table = (value_77).table, .tasks = (value_77).tasks, .transforms = (value_77).transforms, .unary = (value_77).unary, .updates = (value_77).updates, .valid = ((block_146: {
                                                                                        break :block_146 value_4;
                                                                                    } == (state_1).references) and (block_147: {
                                                                                        break :block_147 value_4;
                                                                                    } < @as(u64, (((state_1).table).references).len))), });
                                                                                };
                                                                                const value_79: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_78;
                                                                                const value_80: u64 = (value_79).references;
                                                                                const value_81: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_145: {
                                                                                    break :block_145 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_79).awaits, .binary = (value_79).binary, .booleans = (value_79).booleans, .calls = (value_79).calls, .cancellations = (value_79).cancellations, .captures = (value_79).captures, .collections = (value_79).collections, .conditionals = (value_79).conditionals, .enumerations = (value_79).enumerations, .errors = (value_79).errors, .floats = (value_79).floats, .index = (value_79).index, .indices = (value_79).indices, .integers = (value_79).integers, .iterations = (value_79).iterations, .lengths = (value_79).lengths, .matches = (value_79).matches, .negative_integers = (value_79).negative_integers, .objects = (value_79).objects, .optional_values = (value_79).optional_values, .parallels = (value_79).parallels, .projections = (value_79).projections, .references = (block_144: {
                                                                                        break :block_144 value_80;
                                                                                    } + @as(u64, 1)), .scopes = (value_79).scopes, .sequences = (value_79).sequences, .some = (value_79).some, .stores = (value_79).stores, .strings = (value_79).strings, .table = (value_79).table, .tasks = (value_79).tasks, .transforms = (value_79).transforms, .unary = (value_79).unary, .updates = (value_79).updates, .valid = (value_79).valid, });
                                                                                };

                                                                                break :block_149 value_81;
                                                                            } else block_280: {
                                                                                const value_177: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_150: {
                                                                                    break :block_150 value_3;
                                                                                } == @as((zx_abi).zx_type_20, .StoreGet))) block_156: {
                                                                                    const value_82: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                    const value_83: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_155: {
                                                                                        break :block_155 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_82).awaits, .binary = (value_82).binary, .booleans = (value_82).booleans, .calls = (value_82).calls, .cancellations = (value_82).cancellations, .captures = (value_82).captures, .collections = (value_82).collections, .conditionals = (value_82).conditionals, .enumerations = (value_82).enumerations, .errors = (value_82).errors, .floats = (value_82).floats, .index = (value_82).index, .indices = (value_82).indices, .integers = (value_82).integers, .iterations = (value_82).iterations, .lengths = (value_82).lengths, .matches = (value_82).matches, .negative_integers = (value_82).negative_integers, .objects = (value_82).objects, .optional_values = (value_82).optional_values, .parallels = (value_82).parallels, .projections = (value_82).projections, .references = (value_82).references, .scopes = (value_82).scopes, .sequences = (value_82).sequences, .some = (value_82).some, .stores = (value_82).stores, .strings = (value_82).strings, .table = (value_82).table, .tasks = (value_82).tasks, .transforms = (value_82).transforms, .unary = (value_82).unary, .updates = (value_82).updates, .valid = ((block_153: {
                                                                                            break :block_153 value_4;
                                                                                        } == (state_1).stores) and (block_154: {
                                                                                            break :block_154 value_4;
                                                                                        } < @as(u64, (((state_1).table).stores).len))), });
                                                                                    };
                                                                                    const value_84: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_83;
                                                                                    const value_85: u64 = (value_84).stores;
                                                                                    const value_86: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_152: {
                                                                                        break :block_152 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_84).awaits, .binary = (value_84).binary, .booleans = (value_84).booleans, .calls = (value_84).calls, .cancellations = (value_84).cancellations, .captures = (value_84).captures, .collections = (value_84).collections, .conditionals = (value_84).conditionals, .enumerations = (value_84).enumerations, .errors = (value_84).errors, .floats = (value_84).floats, .index = (value_84).index, .indices = (value_84).indices, .integers = (value_84).integers, .iterations = (value_84).iterations, .lengths = (value_84).lengths, .matches = (value_84).matches, .negative_integers = (value_84).negative_integers, .objects = (value_84).objects, .optional_values = (value_84).optional_values, .parallels = (value_84).parallels, .projections = (value_84).projections, .references = (value_84).references, .scopes = (value_84).scopes, .sequences = (value_84).sequences, .some = (value_84).some, .stores = (block_151: {
                                                                                            break :block_151 value_85;
                                                                                        } + @as(u64, 1)), .strings = (value_84).strings, .table = (value_84).table, .tasks = (value_84).tasks, .transforms = (value_84).transforms, .unary = (value_84).unary, .updates = (value_84).updates, .valid = (value_84).valid, });
                                                                                    };

                                                                                    break :block_156 value_86;
                                                                                } else block_279: {
                                                                                    const value_176: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if (((block_157: {
                                                                                        break :block_157 value_3;
                                                                                    } == @as((zx_abi).zx_type_20, .Field)) or (block_158: {
                                                                                        break :block_158 value_3;
                                                                                    } == @as((zx_abi).zx_type_20, .TupleField)))) block_164: {
                                                                                        const value_87: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                        const value_88: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_163: {
                                                                                            break :block_163 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_87).awaits, .binary = (value_87).binary, .booleans = (value_87).booleans, .calls = (value_87).calls, .cancellations = (value_87).cancellations, .captures = (value_87).captures, .collections = (value_87).collections, .conditionals = (value_87).conditionals, .enumerations = (value_87).enumerations, .errors = (value_87).errors, .floats = (value_87).floats, .index = (value_87).index, .indices = (value_87).indices, .integers = (value_87).integers, .iterations = (value_87).iterations, .lengths = (value_87).lengths, .matches = (value_87).matches, .negative_integers = (value_87).negative_integers, .objects = (value_87).objects, .optional_values = (value_87).optional_values, .parallels = (value_87).parallels, .projections = (value_87).projections, .references = (value_87).references, .scopes = (value_87).scopes, .sequences = (value_87).sequences, .some = (value_87).some, .stores = (value_87).stores, .strings = (value_87).strings, .table = (value_87).table, .tasks = (value_87).tasks, .transforms = (value_87).transforms, .unary = (value_87).unary, .updates = (value_87).updates, .valid = ((block_161: {
                                                                                                break :block_161 value_4;
                                                                                            } == (state_1).projections) and (block_162: {
                                                                                                break :block_162 value_4;
                                                                                            } < @as(u64, (((state_1).table).projection_targets).len))), });
                                                                                        };
                                                                                        const value_89: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_88;
                                                                                        const value_90: u64 = (value_89).projections;
                                                                                        const value_91: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_160: {
                                                                                            break :block_160 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_89).awaits, .binary = (value_89).binary, .booleans = (value_89).booleans, .calls = (value_89).calls, .cancellations = (value_89).cancellations, .captures = (value_89).captures, .collections = (value_89).collections, .conditionals = (value_89).conditionals, .enumerations = (value_89).enumerations, .errors = (value_89).errors, .floats = (value_89).floats, .index = (value_89).index, .indices = (value_89).indices, .integers = (value_89).integers, .iterations = (value_89).iterations, .lengths = (value_89).lengths, .matches = (value_89).matches, .negative_integers = (value_89).negative_integers, .objects = (value_89).objects, .optional_values = (value_89).optional_values, .parallels = (value_89).parallels, .projections = (block_159: {
                                                                                                break :block_159 value_90;
                                                                                            } + @as(u64, 1)), .references = (value_89).references, .scopes = (value_89).scopes, .sequences = (value_89).sequences, .some = (value_89).some, .stores = (value_89).stores, .strings = (value_89).strings, .table = (value_89).table, .tasks = (value_89).tasks, .transforms = (value_89).transforms, .unary = (value_89).unary, .updates = (value_89).updates, .valid = (value_89).valid, });
                                                                                        };

                                                                                        break :block_164 value_91;
                                                                                    } else block_278: {
                                                                                        const value_175: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_165: {
                                                                                            break :block_165 value_3;
                                                                                        } == @as((zx_abi).zx_type_20, .Index))) block_171: {
                                                                                            const value_92: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                            const value_93: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_170: {
                                                                                                break :block_170 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_92).awaits, .binary = (value_92).binary, .booleans = (value_92).booleans, .calls = (value_92).calls, .cancellations = (value_92).cancellations, .captures = (value_92).captures, .collections = (value_92).collections, .conditionals = (value_92).conditionals, .enumerations = (value_92).enumerations, .errors = (value_92).errors, .floats = (value_92).floats, .index = (value_92).index, .indices = (value_92).indices, .integers = (value_92).integers, .iterations = (value_92).iterations, .lengths = (value_92).lengths, .matches = (value_92).matches, .negative_integers = (value_92).negative_integers, .objects = (value_92).objects, .optional_values = (value_92).optional_values, .parallels = (value_92).parallels, .projections = (value_92).projections, .references = (value_92).references, .scopes = (value_92).scopes, .sequences = (value_92).sequences, .some = (value_92).some, .stores = (value_92).stores, .strings = (value_92).strings, .table = (value_92).table, .tasks = (value_92).tasks, .transforms = (value_92).transforms, .unary = (value_92).unary, .updates = (value_92).updates, .valid = ((block_168: {
                                                                                                    break :block_168 value_4;
                                                                                                } == (state_1).indices) and (block_169: {
                                                                                                    break :block_169 value_4;
                                                                                                } < @as(u64, (((state_1).table).index_targets).len))), });
                                                                                            };
                                                                                            const value_94: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_93;
                                                                                            const value_95: u64 = (value_94).indices;
                                                                                            const value_96: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_167: {
                                                                                                break :block_167 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_94).awaits, .binary = (value_94).binary, .booleans = (value_94).booleans, .calls = (value_94).calls, .cancellations = (value_94).cancellations, .captures = (value_94).captures, .collections = (value_94).collections, .conditionals = (value_94).conditionals, .enumerations = (value_94).enumerations, .errors = (value_94).errors, .floats = (value_94).floats, .index = (value_94).index, .indices = (block_166: {
                                                                                                    break :block_166 value_95;
                                                                                                } + @as(u64, 1)), .integers = (value_94).integers, .iterations = (value_94).iterations, .lengths = (value_94).lengths, .matches = (value_94).matches, .negative_integers = (value_94).negative_integers, .objects = (value_94).objects, .optional_values = (value_94).optional_values, .parallels = (value_94).parallels, .projections = (value_94).projections, .references = (value_94).references, .scopes = (value_94).scopes, .sequences = (value_94).sequences, .some = (value_94).some, .stores = (value_94).stores, .strings = (value_94).strings, .table = (value_94).table, .tasks = (value_94).tasks, .transforms = (value_94).transforms, .unary = (value_94).unary, .updates = (value_94).updates, .valid = (value_94).valid, });
                                                                                            };

                                                                                            break :block_171 value_96;
                                                                                        } else block_277: {
                                                                                            const value_174: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_172: {
                                                                                                break :block_172 value_3;
                                                                                            } == @as((zx_abi).zx_type_20, .Length))) block_178: {
                                                                                                const value_97: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                const value_98: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_177: {
                                                                                                    break :block_177 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_97).awaits, .binary = (value_97).binary, .booleans = (value_97).booleans, .calls = (value_97).calls, .cancellations = (value_97).cancellations, .captures = (value_97).captures, .collections = (value_97).collections, .conditionals = (value_97).conditionals, .enumerations = (value_97).enumerations, .errors = (value_97).errors, .floats = (value_97).floats, .index = (value_97).index, .indices = (value_97).indices, .integers = (value_97).integers, .iterations = (value_97).iterations, .lengths = (value_97).lengths, .matches = (value_97).matches, .negative_integers = (value_97).negative_integers, .objects = (value_97).objects, .optional_values = (value_97).optional_values, .parallels = (value_97).parallels, .projections = (value_97).projections, .references = (value_97).references, .scopes = (value_97).scopes, .sequences = (value_97).sequences, .some = (value_97).some, .stores = (value_97).stores, .strings = (value_97).strings, .table = (value_97).table, .tasks = (value_97).tasks, .transforms = (value_97).transforms, .unary = (value_97).unary, .updates = (value_97).updates, .valid = ((block_175: {
                                                                                                        break :block_175 value_4;
                                                                                                    } == (state_1).lengths) and (block_176: {
                                                                                                        break :block_176 value_4;
                                                                                                    } < @as(u64, (((state_1).table).lengths).len))), });
                                                                                                };
                                                                                                const value_99: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_98;
                                                                                                const value_100: u64 = (value_99).lengths;
                                                                                                const value_101: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_174: {
                                                                                                    break :block_174 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_99).awaits, .binary = (value_99).binary, .booleans = (value_99).booleans, .calls = (value_99).calls, .cancellations = (value_99).cancellations, .captures = (value_99).captures, .collections = (value_99).collections, .conditionals = (value_99).conditionals, .enumerations = (value_99).enumerations, .errors = (value_99).errors, .floats = (value_99).floats, .index = (value_99).index, .indices = (value_99).indices, .integers = (value_99).integers, .iterations = (value_99).iterations, .lengths = (block_173: {
                                                                                                        break :block_173 value_100;
                                                                                                    } + @as(u64, 1)), .matches = (value_99).matches, .negative_integers = (value_99).negative_integers, .objects = (value_99).objects, .optional_values = (value_99).optional_values, .parallels = (value_99).parallels, .projections = (value_99).projections, .references = (value_99).references, .scopes = (value_99).scopes, .sequences = (value_99).sequences, .some = (value_99).some, .stores = (value_99).stores, .strings = (value_99).strings, .table = (value_99).table, .tasks = (value_99).tasks, .transforms = (value_99).transforms, .unary = (value_99).unary, .updates = (value_99).updates, .valid = (value_99).valid, });
                                                                                                };

                                                                                                break :block_178 value_101;
                                                                                            } else block_276: {
                                                                                                const value_173: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((((block_179: {
                                                                                                    break :block_179 value_3;
                                                                                                } == @as((zx_abi).zx_type_20, .List)) or (block_180: {
                                                                                                    break :block_180 value_3;
                                                                                                } == @as((zx_abi).zx_type_20, .Tuple))) or (block_181: {
                                                                                                    break :block_181 value_3;
                                                                                                } == @as((zx_abi).zx_type_20, .Template)))) block_187: {
                                                                                                    const value_102: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                    const value_103: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_186: {
                                                                                                        break :block_186 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_102).awaits, .binary = (value_102).binary, .booleans = (value_102).booleans, .calls = (value_102).calls, .cancellations = (value_102).cancellations, .captures = (value_102).captures, .collections = (value_102).collections, .conditionals = (value_102).conditionals, .enumerations = (value_102).enumerations, .errors = (value_102).errors, .floats = (value_102).floats, .index = (value_102).index, .indices = (value_102).indices, .integers = (value_102).integers, .iterations = (value_102).iterations, .lengths = (value_102).lengths, .matches = (value_102).matches, .negative_integers = (value_102).negative_integers, .objects = (value_102).objects, .optional_values = (value_102).optional_values, .parallels = (value_102).parallels, .projections = (value_102).projections, .references = (value_102).references, .scopes = (value_102).scopes, .sequences = (value_102).sequences, .some = (value_102).some, .stores = (value_102).stores, .strings = (value_102).strings, .table = (value_102).table, .tasks = (value_102).tasks, .transforms = (value_102).transforms, .unary = (value_102).unary, .updates = (value_102).updates, .valid = ((block_184: {
                                                                                                            break :block_184 value_4;
                                                                                                        } == (state_1).sequences) and (block_185: {
                                                                                                            break :block_185 value_4;
                                                                                                        } < @as(u64, (((state_1).table).sequence_first).len))), });
                                                                                                    };
                                                                                                    const value_104: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_103;
                                                                                                    const value_105: u64 = (value_104).sequences;
                                                                                                    const value_106: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_183: {
                                                                                                        break :block_183 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_104).awaits, .binary = (value_104).binary, .booleans = (value_104).booleans, .calls = (value_104).calls, .cancellations = (value_104).cancellations, .captures = (value_104).captures, .collections = (value_104).collections, .conditionals = (value_104).conditionals, .enumerations = (value_104).enumerations, .errors = (value_104).errors, .floats = (value_104).floats, .index = (value_104).index, .indices = (value_104).indices, .integers = (value_104).integers, .iterations = (value_104).iterations, .lengths = (value_104).lengths, .matches = (value_104).matches, .negative_integers = (value_104).negative_integers, .objects = (value_104).objects, .optional_values = (value_104).optional_values, .parallels = (value_104).parallels, .projections = (value_104).projections, .references = (value_104).references, .scopes = (value_104).scopes, .sequences = (block_182: {
                                                                                                            break :block_182 value_105;
                                                                                                        } + @as(u64, 1)), .some = (value_104).some, .stores = (value_104).stores, .strings = (value_104).strings, .table = (value_104).table, .tasks = (value_104).tasks, .transforms = (value_104).transforms, .unary = (value_104).unary, .updates = (value_104).updates, .valid = (value_104).valid, });
                                                                                                    };

                                                                                                    break :block_187 value_106;
                                                                                                } else block_275: {
                                                                                                    const value_172: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_188: {
                                                                                                        break :block_188 value_3;
                                                                                                    } == @as((zx_abi).zx_type_20, .ListOperation))) block_194: {
                                                                                                        const value_107: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                        const value_108: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_193: {
                                                                                                            break :block_193 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_107).awaits, .binary = (value_107).binary, .booleans = (value_107).booleans, .calls = (value_107).calls, .cancellations = (value_107).cancellations, .captures = (value_107).captures, .collections = (value_107).collections, .conditionals = (value_107).conditionals, .enumerations = (value_107).enumerations, .errors = (value_107).errors, .floats = (value_107).floats, .index = (value_107).index, .indices = (value_107).indices, .integers = (value_107).integers, .iterations = (value_107).iterations, .lengths = (value_107).lengths, .matches = (value_107).matches, .negative_integers = (value_107).negative_integers, .objects = (value_107).objects, .optional_values = (value_107).optional_values, .parallels = (value_107).parallels, .projections = (value_107).projections, .references = (value_107).references, .scopes = (value_107).scopes, .sequences = (value_107).sequences, .some = (value_107).some, .stores = (value_107).stores, .strings = (value_107).strings, .table = (value_107).table, .tasks = (value_107).tasks, .transforms = (value_107).transforms, .unary = (value_107).unary, .updates = (value_107).updates, .valid = ((block_191: {
                                                                                                                break :block_191 value_4;
                                                                                                            } == (state_1).collections) and (block_192: {
                                                                                                                break :block_192 value_4;
                                                                                                            } < @as(u64, (((state_1).table).collection_kinds).len))), });
                                                                                                        };
                                                                                                        const value_109: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_108;
                                                                                                        const value_110: u64 = (value_109).collections;
                                                                                                        const value_111: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_190: {
                                                                                                            break :block_190 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_109).awaits, .binary = (value_109).binary, .booleans = (value_109).booleans, .calls = (value_109).calls, .cancellations = (value_109).cancellations, .captures = (value_109).captures, .collections = (block_189: {
                                                                                                                break :block_189 value_110;
                                                                                                            } + @as(u64, 1)), .conditionals = (value_109).conditionals, .enumerations = (value_109).enumerations, .errors = (value_109).errors, .floats = (value_109).floats, .index = (value_109).index, .indices = (value_109).indices, .integers = (value_109).integers, .iterations = (value_109).iterations, .lengths = (value_109).lengths, .matches = (value_109).matches, .negative_integers = (value_109).negative_integers, .objects = (value_109).objects, .optional_values = (value_109).optional_values, .parallels = (value_109).parallels, .projections = (value_109).projections, .references = (value_109).references, .scopes = (value_109).scopes, .sequences = (value_109).sequences, .some = (value_109).some, .stores = (value_109).stores, .strings = (value_109).strings, .table = (value_109).table, .tasks = (value_109).tasks, .transforms = (value_109).transforms, .unary = (value_109).unary, .updates = (value_109).updates, .valid = (value_109).valid, });
                                                                                                        };

                                                                                                        break :block_194 value_111;
                                                                                                    } else block_274: {
                                                                                                        const value_171: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_195: {
                                                                                                            break :block_195 value_3;
                                                                                                        } == @as((zx_abi).zx_type_20, .Transform))) block_201: {
                                                                                                            const value_112: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                            const value_113: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_200: {
                                                                                                                break :block_200 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_112).awaits, .binary = (value_112).binary, .booleans = (value_112).booleans, .calls = (value_112).calls, .cancellations = (value_112).cancellations, .captures = (value_112).captures, .collections = (value_112).collections, .conditionals = (value_112).conditionals, .enumerations = (value_112).enumerations, .errors = (value_112).errors, .floats = (value_112).floats, .index = (value_112).index, .indices = (value_112).indices, .integers = (value_112).integers, .iterations = (value_112).iterations, .lengths = (value_112).lengths, .matches = (value_112).matches, .negative_integers = (value_112).negative_integers, .objects = (value_112).objects, .optional_values = (value_112).optional_values, .parallels = (value_112).parallels, .projections = (value_112).projections, .references = (value_112).references, .scopes = (value_112).scopes, .sequences = (value_112).sequences, .some = (value_112).some, .stores = (value_112).stores, .strings = (value_112).strings, .table = (value_112).table, .tasks = (value_112).tasks, .transforms = (value_112).transforms, .unary = (value_112).unary, .updates = (value_112).updates, .valid = ((block_198: {
                                                                                                                    break :block_198 value_4;
                                                                                                                } == (state_1).transforms) and (block_199: {
                                                                                                                    break :block_199 value_4;
                                                                                                                } < @as(u64, (((state_1).table).transform_kinds).len))), });
                                                                                                            };
                                                                                                            const value_114: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_113;
                                                                                                            const value_115: u64 = (value_114).transforms;
                                                                                                            const value_116: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_197: {
                                                                                                                break :block_197 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_114).awaits, .binary = (value_114).binary, .booleans = (value_114).booleans, .calls = (value_114).calls, .cancellations = (value_114).cancellations, .captures = (value_114).captures, .collections = (value_114).collections, .conditionals = (value_114).conditionals, .enumerations = (value_114).enumerations, .errors = (value_114).errors, .floats = (value_114).floats, .index = (value_114).index, .indices = (value_114).indices, .integers = (value_114).integers, .iterations = (value_114).iterations, .lengths = (value_114).lengths, .matches = (value_114).matches, .negative_integers = (value_114).negative_integers, .objects = (value_114).objects, .optional_values = (value_114).optional_values, .parallels = (value_114).parallels, .projections = (value_114).projections, .references = (value_114).references, .scopes = (value_114).scopes, .sequences = (value_114).sequences, .some = (value_114).some, .stores = (value_114).stores, .strings = (value_114).strings, .table = (value_114).table, .tasks = (value_114).tasks, .transforms = (block_196: {
                                                                                                                    break :block_196 value_115;
                                                                                                                } + @as(u64, 1)), .unary = (value_114).unary, .updates = (value_114).updates, .valid = (value_114).valid, });
                                                                                                            };

                                                                                                            break :block_201 value_116;
                                                                                                        } else block_273: {
                                                                                                            const value_170: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_202: {
                                                                                                                break :block_202 value_3;
                                                                                                            } == @as((zx_abi).zx_type_20, .Scope))) block_208: {
                                                                                                                const value_117: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                                const value_118: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_207: {
                                                                                                                    break :block_207 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_117).awaits, .binary = (value_117).binary, .booleans = (value_117).booleans, .calls = (value_117).calls, .cancellations = (value_117).cancellations, .captures = (value_117).captures, .collections = (value_117).collections, .conditionals = (value_117).conditionals, .enumerations = (value_117).enumerations, .errors = (value_117).errors, .floats = (value_117).floats, .index = (value_117).index, .indices = (value_117).indices, .integers = (value_117).integers, .iterations = (value_117).iterations, .lengths = (value_117).lengths, .matches = (value_117).matches, .negative_integers = (value_117).negative_integers, .objects = (value_117).objects, .optional_values = (value_117).optional_values, .parallels = (value_117).parallels, .projections = (value_117).projections, .references = (value_117).references, .scopes = (value_117).scopes, .sequences = (value_117).sequences, .some = (value_117).some, .stores = (value_117).stores, .strings = (value_117).strings, .table = (value_117).table, .tasks = (value_117).tasks, .transforms = (value_117).transforms, .unary = (value_117).unary, .updates = (value_117).updates, .valid = ((block_205: {
                                                                                                                        break :block_205 value_4;
                                                                                                                    } == (state_1).scopes) and (block_206: {
                                                                                                                        break :block_206 value_4;
                                                                                                                    } < @as(u64, (((state_1).table).scope_results).len))), });
                                                                                                                };
                                                                                                                const value_119: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_118;
                                                                                                                const value_120: u64 = (value_119).scopes;
                                                                                                                const value_121: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_204: {
                                                                                                                    break :block_204 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_119).awaits, .binary = (value_119).binary, .booleans = (value_119).booleans, .calls = (value_119).calls, .cancellations = (value_119).cancellations, .captures = (value_119).captures, .collections = (value_119).collections, .conditionals = (value_119).conditionals, .enumerations = (value_119).enumerations, .errors = (value_119).errors, .floats = (value_119).floats, .index = (value_119).index, .indices = (value_119).indices, .integers = (value_119).integers, .iterations = (value_119).iterations, .lengths = (value_119).lengths, .matches = (value_119).matches, .negative_integers = (value_119).negative_integers, .objects = (value_119).objects, .optional_values = (value_119).optional_values, .parallels = (value_119).parallels, .projections = (value_119).projections, .references = (value_119).references, .scopes = (block_203: {
                                                                                                                        break :block_203 value_120;
                                                                                                                    } + @as(u64, 1)), .sequences = (value_119).sequences, .some = (value_119).some, .stores = (value_119).stores, .strings = (value_119).strings, .table = (value_119).table, .tasks = (value_119).tasks, .transforms = (value_119).transforms, .unary = (value_119).unary, .updates = (value_119).updates, .valid = (value_119).valid, });
                                                                                                                };

                                                                                                                break :block_208 value_121;
                                                                                                            } else block_272: {
                                                                                                                const value_169: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_209: {
                                                                                                                    break :block_209 value_3;
                                                                                                                } == @as((zx_abi).zx_type_20, .Iteration))) block_215: {
                                                                                                                    const value_122: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                                    const value_123: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_214: {
                                                                                                                        break :block_214 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_122).awaits, .binary = (value_122).binary, .booleans = (value_122).booleans, .calls = (value_122).calls, .cancellations = (value_122).cancellations, .captures = (value_122).captures, .collections = (value_122).collections, .conditionals = (value_122).conditionals, .enumerations = (value_122).enumerations, .errors = (value_122).errors, .floats = (value_122).floats, .index = (value_122).index, .indices = (value_122).indices, .integers = (value_122).integers, .iterations = (value_122).iterations, .lengths = (value_122).lengths, .matches = (value_122).matches, .negative_integers = (value_122).negative_integers, .objects = (value_122).objects, .optional_values = (value_122).optional_values, .parallels = (value_122).parallels, .projections = (value_122).projections, .references = (value_122).references, .scopes = (value_122).scopes, .sequences = (value_122).sequences, .some = (value_122).some, .stores = (value_122).stores, .strings = (value_122).strings, .table = (value_122).table, .tasks = (value_122).tasks, .transforms = (value_122).transforms, .unary = (value_122).unary, .updates = (value_122).updates, .valid = ((block_212: {
                                                                                                                            break :block_212 value_4;
                                                                                                                        } == (state_1).iterations) and (block_213: {
                                                                                                                            break :block_213 value_4;
                                                                                                                        } < @as(u64, (((state_1).table).iteration_initials).len))), });
                                                                                                                    };
                                                                                                                    const value_124: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_123;
                                                                                                                    const value_125: u64 = (value_124).iterations;
                                                                                                                    const value_126: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_211: {
                                                                                                                        break :block_211 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_124).awaits, .binary = (value_124).binary, .booleans = (value_124).booleans, .calls = (value_124).calls, .cancellations = (value_124).cancellations, .captures = (value_124).captures, .collections = (value_124).collections, .conditionals = (value_124).conditionals, .enumerations = (value_124).enumerations, .errors = (value_124).errors, .floats = (value_124).floats, .index = (value_124).index, .indices = (value_124).indices, .integers = (value_124).integers, .iterations = (block_210: {
                                                                                                                            break :block_210 value_125;
                                                                                                                        } + @as(u64, 1)), .lengths = (value_124).lengths, .matches = (value_124).matches, .negative_integers = (value_124).negative_integers, .objects = (value_124).objects, .optional_values = (value_124).optional_values, .parallels = (value_124).parallels, .projections = (value_124).projections, .references = (value_124).references, .scopes = (value_124).scopes, .sequences = (value_124).sequences, .some = (value_124).some, .stores = (value_124).stores, .strings = (value_124).strings, .table = (value_124).table, .tasks = (value_124).tasks, .transforms = (value_124).transforms, .unary = (value_124).unary, .updates = (value_124).updates, .valid = (value_124).valid, });
                                                                                                                    };

                                                                                                                    break :block_215 value_126;
                                                                                                                } else block_271: {
                                                                                                                    const value_168: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_216: {
                                                                                                                        break :block_216 value_3;
                                                                                                                    } == @as((zx_abi).zx_type_20, .ListUpdate))) block_222: {
                                                                                                                        const value_127: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                                        const value_128: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_221: {
                                                                                                                            break :block_221 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_127).awaits, .binary = (value_127).binary, .booleans = (value_127).booleans, .calls = (value_127).calls, .cancellations = (value_127).cancellations, .captures = (value_127).captures, .collections = (value_127).collections, .conditionals = (value_127).conditionals, .enumerations = (value_127).enumerations, .errors = (value_127).errors, .floats = (value_127).floats, .index = (value_127).index, .indices = (value_127).indices, .integers = (value_127).integers, .iterations = (value_127).iterations, .lengths = (value_127).lengths, .matches = (value_127).matches, .negative_integers = (value_127).negative_integers, .objects = (value_127).objects, .optional_values = (value_127).optional_values, .parallels = (value_127).parallels, .projections = (value_127).projections, .references = (value_127).references, .scopes = (value_127).scopes, .sequences = (value_127).sequences, .some = (value_127).some, .stores = (value_127).stores, .strings = (value_127).strings, .table = (value_127).table, .tasks = (value_127).tasks, .transforms = (value_127).transforms, .unary = (value_127).unary, .updates = (value_127).updates, .valid = ((block_219: {
                                                                                                                                break :block_219 value_4;
                                                                                                                            } == (state_1).updates) and (block_220: {
                                                                                                                                break :block_220 value_4;
                                                                                                                            } < @as(u64, (((state_1).table).update_targets).len))), });
                                                                                                                        };
                                                                                                                        const value_129: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_128;
                                                                                                                        const value_130: u64 = (value_129).updates;
                                                                                                                        const value_131: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_218: {
                                                                                                                            break :block_218 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_129).awaits, .binary = (value_129).binary, .booleans = (value_129).booleans, .calls = (value_129).calls, .cancellations = (value_129).cancellations, .captures = (value_129).captures, .collections = (value_129).collections, .conditionals = (value_129).conditionals, .enumerations = (value_129).enumerations, .errors = (value_129).errors, .floats = (value_129).floats, .index = (value_129).index, .indices = (value_129).indices, .integers = (value_129).integers, .iterations = (value_129).iterations, .lengths = (value_129).lengths, .matches = (value_129).matches, .negative_integers = (value_129).negative_integers, .objects = (value_129).objects, .optional_values = (value_129).optional_values, .parallels = (value_129).parallels, .projections = (value_129).projections, .references = (value_129).references, .scopes = (value_129).scopes, .sequences = (value_129).sequences, .some = (value_129).some, .stores = (value_129).stores, .strings = (value_129).strings, .table = (value_129).table, .tasks = (value_129).tasks, .transforms = (value_129).transforms, .unary = (value_129).unary, .updates = (block_217: {
                                                                                                                                break :block_217 value_130;
                                                                                                                            } + @as(u64, 1)), .valid = (value_129).valid, });
                                                                                                                        };

                                                                                                                        break :block_222 value_131;
                                                                                                                    } else block_270: {
                                                                                                                        const value_167: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_223: {
                                                                                                                            break :block_223 value_3;
                                                                                                                        } == @as((zx_abi).zx_type_20, .Call))) block_229: {
                                                                                                                            const value_132: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                                            const value_133: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_228: {
                                                                                                                                break :block_228 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_132).awaits, .binary = (value_132).binary, .booleans = (value_132).booleans, .calls = (value_132).calls, .cancellations = (value_132).cancellations, .captures = (value_132).captures, .collections = (value_132).collections, .conditionals = (value_132).conditionals, .enumerations = (value_132).enumerations, .errors = (value_132).errors, .floats = (value_132).floats, .index = (value_132).index, .indices = (value_132).indices, .integers = (value_132).integers, .iterations = (value_132).iterations, .lengths = (value_132).lengths, .matches = (value_132).matches, .negative_integers = (value_132).negative_integers, .objects = (value_132).objects, .optional_values = (value_132).optional_values, .parallels = (value_132).parallels, .projections = (value_132).projections, .references = (value_132).references, .scopes = (value_132).scopes, .sequences = (value_132).sequences, .some = (value_132).some, .stores = (value_132).stores, .strings = (value_132).strings, .table = (value_132).table, .tasks = (value_132).tasks, .transforms = (value_132).transforms, .unary = (value_132).unary, .updates = (value_132).updates, .valid = ((block_226: {
                                                                                                                                    break :block_226 value_4;
                                                                                                                                } == (state_1).calls) and (block_227: {
                                                                                                                                    break :block_227 value_4;
                                                                                                                                } < @as(u64, (((state_1).table).call_functions).len))), });
                                                                                                                            };
                                                                                                                            const value_134: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_133;
                                                                                                                            const value_135: u64 = (value_134).calls;
                                                                                                                            const value_136: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_225: {
                                                                                                                                break :block_225 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_134).awaits, .binary = (value_134).binary, .booleans = (value_134).booleans, .calls = (block_224: {
                                                                                                                                    break :block_224 value_135;
                                                                                                                                } + @as(u64, 1)), .cancellations = (value_134).cancellations, .captures = (value_134).captures, .collections = (value_134).collections, .conditionals = (value_134).conditionals, .enumerations = (value_134).enumerations, .errors = (value_134).errors, .floats = (value_134).floats, .index = (value_134).index, .indices = (value_134).indices, .integers = (value_134).integers, .iterations = (value_134).iterations, .lengths = (value_134).lengths, .matches = (value_134).matches, .negative_integers = (value_134).negative_integers, .objects = (value_134).objects, .optional_values = (value_134).optional_values, .parallels = (value_134).parallels, .projections = (value_134).projections, .references = (value_134).references, .scopes = (value_134).scopes, .sequences = (value_134).sequences, .some = (value_134).some, .stores = (value_134).stores, .strings = (value_134).strings, .table = (value_134).table, .tasks = (value_134).tasks, .transforms = (value_134).transforms, .unary = (value_134).unary, .updates = (value_134).updates, .valid = (value_134).valid, });
                                                                                                                            };

                                                                                                                            break :block_229 value_136;
                                                                                                                        } else block_269: {
                                                                                                                            const value_166: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_230: {
                                                                                                                                break :block_230 value_3;
                                                                                                                            } == @as((zx_abi).zx_type_20, .Unary))) block_236: {
                                                                                                                                const value_137: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                                                const value_138: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_235: {
                                                                                                                                    break :block_235 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_137).awaits, .binary = (value_137).binary, .booleans = (value_137).booleans, .calls = (value_137).calls, .cancellations = (value_137).cancellations, .captures = (value_137).captures, .collections = (value_137).collections, .conditionals = (value_137).conditionals, .enumerations = (value_137).enumerations, .errors = (value_137).errors, .floats = (value_137).floats, .index = (value_137).index, .indices = (value_137).indices, .integers = (value_137).integers, .iterations = (value_137).iterations, .lengths = (value_137).lengths, .matches = (value_137).matches, .negative_integers = (value_137).negative_integers, .objects = (value_137).objects, .optional_values = (value_137).optional_values, .parallels = (value_137).parallels, .projections = (value_137).projections, .references = (value_137).references, .scopes = (value_137).scopes, .sequences = (value_137).sequences, .some = (value_137).some, .stores = (value_137).stores, .strings = (value_137).strings, .table = (value_137).table, .tasks = (value_137).tasks, .transforms = (value_137).transforms, .unary = (value_137).unary, .updates = (value_137).updates, .valid = ((block_233: {
                                                                                                                                        break :block_233 value_4;
                                                                                                                                    } == (state_1).unary) and (block_234: {
                                                                                                                                        break :block_234 value_4;
                                                                                                                                    } < @as(u64, (((state_1).table).unary_operands).len))), });
                                                                                                                                };
                                                                                                                                const value_139: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_138;
                                                                                                                                const value_140: u64 = (value_139).unary;
                                                                                                                                const value_141: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_232: {
                                                                                                                                    break :block_232 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_139).awaits, .binary = (value_139).binary, .booleans = (value_139).booleans, .calls = (value_139).calls, .cancellations = (value_139).cancellations, .captures = (value_139).captures, .collections = (value_139).collections, .conditionals = (value_139).conditionals, .enumerations = (value_139).enumerations, .errors = (value_139).errors, .floats = (value_139).floats, .index = (value_139).index, .indices = (value_139).indices, .integers = (value_139).integers, .iterations = (value_139).iterations, .lengths = (value_139).lengths, .matches = (value_139).matches, .negative_integers = (value_139).negative_integers, .objects = (value_139).objects, .optional_values = (value_139).optional_values, .parallels = (value_139).parallels, .projections = (value_139).projections, .references = (value_139).references, .scopes = (value_139).scopes, .sequences = (value_139).sequences, .some = (value_139).some, .stores = (value_139).stores, .strings = (value_139).strings, .table = (value_139).table, .tasks = (value_139).tasks, .transforms = (value_139).transforms, .unary = (block_231: {
                                                                                                                                        break :block_231 value_140;
                                                                                                                                    } + @as(u64, 1)), .updates = (value_139).updates, .valid = (value_139).valid, });
                                                                                                                                };

                                                                                                                                break :block_236 value_141;
                                                                                                                            } else block_268: {
                                                                                                                                const value_165: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_237: {
                                                                                                                                    break :block_237 value_3;
                                                                                                                                } == @as((zx_abi).zx_type_20, .Binary))) block_243: {
                                                                                                                                    const value_142: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                                                    const value_143: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_242: {
                                                                                                                                        break :block_242 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_142).awaits, .binary = (value_142).binary, .booleans = (value_142).booleans, .calls = (value_142).calls, .cancellations = (value_142).cancellations, .captures = (value_142).captures, .collections = (value_142).collections, .conditionals = (value_142).conditionals, .enumerations = (value_142).enumerations, .errors = (value_142).errors, .floats = (value_142).floats, .index = (value_142).index, .indices = (value_142).indices, .integers = (value_142).integers, .iterations = (value_142).iterations, .lengths = (value_142).lengths, .matches = (value_142).matches, .negative_integers = (value_142).negative_integers, .objects = (value_142).objects, .optional_values = (value_142).optional_values, .parallels = (value_142).parallels, .projections = (value_142).projections, .references = (value_142).references, .scopes = (value_142).scopes, .sequences = (value_142).sequences, .some = (value_142).some, .stores = (value_142).stores, .strings = (value_142).strings, .table = (value_142).table, .tasks = (value_142).tasks, .transforms = (value_142).transforms, .unary = (value_142).unary, .updates = (value_142).updates, .valid = ((block_240: {
                                                                                                                                            break :block_240 value_4;
                                                                                                                                        } == (state_1).binary) and (block_241: {
                                                                                                                                            break :block_241 value_4;
                                                                                                                                        } < @as(u64, (((state_1).table).binary_operators).len))), });
                                                                                                                                    };
                                                                                                                                    const value_144: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_143;
                                                                                                                                    const value_145: u64 = (value_144).binary;
                                                                                                                                    const value_146: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_239: {
                                                                                                                                        break :block_239 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_144).awaits, .binary = (block_238: {
                                                                                                                                            break :block_238 value_145;
                                                                                                                                        } + @as(u64, 1)), .booleans = (value_144).booleans, .calls = (value_144).calls, .cancellations = (value_144).cancellations, .captures = (value_144).captures, .collections = (value_144).collections, .conditionals = (value_144).conditionals, .enumerations = (value_144).enumerations, .errors = (value_144).errors, .floats = (value_144).floats, .index = (value_144).index, .indices = (value_144).indices, .integers = (value_144).integers, .iterations = (value_144).iterations, .lengths = (value_144).lengths, .matches = (value_144).matches, .negative_integers = (value_144).negative_integers, .objects = (value_144).objects, .optional_values = (value_144).optional_values, .parallels = (value_144).parallels, .projections = (value_144).projections, .references = (value_144).references, .scopes = (value_144).scopes, .sequences = (value_144).sequences, .some = (value_144).some, .stores = (value_144).stores, .strings = (value_144).strings, .table = (value_144).table, .tasks = (value_144).tasks, .transforms = (value_144).transforms, .unary = (value_144).unary, .updates = (value_144).updates, .valid = (value_144).valid, });
                                                                                                                                    };

                                                                                                                                    break :block_243 value_146;
                                                                                                                                } else block_267: {
                                                                                                                                    const value_164: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_244: {
                                                                                                                                        break :block_244 value_3;
                                                                                                                                    } == @as((zx_abi).zx_type_20, .Conditional))) block_250: {
                                                                                                                                        const value_147: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                                                        const value_148: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_249: {
                                                                                                                                            break :block_249 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_147).awaits, .binary = (value_147).binary, .booleans = (value_147).booleans, .calls = (value_147).calls, .cancellations = (value_147).cancellations, .captures = (value_147).captures, .collections = (value_147).collections, .conditionals = (value_147).conditionals, .enumerations = (value_147).enumerations, .errors = (value_147).errors, .floats = (value_147).floats, .index = (value_147).index, .indices = (value_147).indices, .integers = (value_147).integers, .iterations = (value_147).iterations, .lengths = (value_147).lengths, .matches = (value_147).matches, .negative_integers = (value_147).negative_integers, .objects = (value_147).objects, .optional_values = (value_147).optional_values, .parallels = (value_147).parallels, .projections = (value_147).projections, .references = (value_147).references, .scopes = (value_147).scopes, .sequences = (value_147).sequences, .some = (value_147).some, .stores = (value_147).stores, .strings = (value_147).strings, .table = (value_147).table, .tasks = (value_147).tasks, .transforms = (value_147).transforms, .unary = (value_147).unary, .updates = (value_147).updates, .valid = ((block_247: {
                                                                                                                                                break :block_247 value_4;
                                                                                                                                            } == (state_1).conditionals) and (block_248: {
                                                                                                                                                break :block_248 value_4;
                                                                                                                                            } < @as(u64, (((state_1).table).conditional_conditions).len))), });
                                                                                                                                        };
                                                                                                                                        const value_149: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_148;
                                                                                                                                        const value_150: u64 = (value_149).conditionals;
                                                                                                                                        const value_151: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_246: {
                                                                                                                                            break :block_246 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_149).awaits, .binary = (value_149).binary, .booleans = (value_149).booleans, .calls = (value_149).calls, .cancellations = (value_149).cancellations, .captures = (value_149).captures, .collections = (value_149).collections, .conditionals = (block_245: {
                                                                                                                                                break :block_245 value_150;
                                                                                                                                            } + @as(u64, 1)), .enumerations = (value_149).enumerations, .errors = (value_149).errors, .floats = (value_149).floats, .index = (value_149).index, .indices = (value_149).indices, .integers = (value_149).integers, .iterations = (value_149).iterations, .lengths = (value_149).lengths, .matches = (value_149).matches, .negative_integers = (value_149).negative_integers, .objects = (value_149).objects, .optional_values = (value_149).optional_values, .parallels = (value_149).parallels, .projections = (value_149).projections, .references = (value_149).references, .scopes = (value_149).scopes, .sequences = (value_149).sequences, .some = (value_149).some, .stores = (value_149).stores, .strings = (value_149).strings, .table = (value_149).table, .tasks = (value_149).tasks, .transforms = (value_149).transforms, .unary = (value_149).unary, .updates = (value_149).updates, .valid = (value_149).valid, });
                                                                                                                                        };

                                                                                                                                        break :block_250 value_151;
                                                                                                                                    } else block_266: {
                                                                                                                                        const value_163: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_251: {
                                                                                                                                            break :block_251 value_3;
                                                                                                                                        } == @as((zx_abi).zx_type_20, .Match))) block_257: {
                                                                                                                                            const value_152: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                                                            const value_153: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_256: {
                                                                                                                                                break :block_256 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_152).awaits, .binary = (value_152).binary, .booleans = (value_152).booleans, .calls = (value_152).calls, .cancellations = (value_152).cancellations, .captures = (value_152).captures, .collections = (value_152).collections, .conditionals = (value_152).conditionals, .enumerations = (value_152).enumerations, .errors = (value_152).errors, .floats = (value_152).floats, .index = (value_152).index, .indices = (value_152).indices, .integers = (value_152).integers, .iterations = (value_152).iterations, .lengths = (value_152).lengths, .matches = (value_152).matches, .negative_integers = (value_152).negative_integers, .objects = (value_152).objects, .optional_values = (value_152).optional_values, .parallels = (value_152).parallels, .projections = (value_152).projections, .references = (value_152).references, .scopes = (value_152).scopes, .sequences = (value_152).sequences, .some = (value_152).some, .stores = (value_152).stores, .strings = (value_152).strings, .table = (value_152).table, .tasks = (value_152).tasks, .transforms = (value_152).transforms, .unary = (value_152).unary, .updates = (value_152).updates, .valid = ((block_254: {
                                                                                                                                                    break :block_254 value_4;
                                                                                                                                                } == (state_1).matches) and (block_255: {
                                                                                                                                                    break :block_255 value_4;
                                                                                                                                                } < @as(u64, (((state_1).table).match_subjects).len))), });
                                                                                                                                            };
                                                                                                                                            const value_154: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_153;
                                                                                                                                            const value_155: u64 = (value_154).matches;
                                                                                                                                            const value_156: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_253: {
                                                                                                                                                break :block_253 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_154).awaits, .binary = (value_154).binary, .booleans = (value_154).booleans, .calls = (value_154).calls, .cancellations = (value_154).cancellations, .captures = (value_154).captures, .collections = (value_154).collections, .conditionals = (value_154).conditionals, .enumerations = (value_154).enumerations, .errors = (value_154).errors, .floats = (value_154).floats, .index = (value_154).index, .indices = (value_154).indices, .integers = (value_154).integers, .iterations = (value_154).iterations, .lengths = (value_154).lengths, .matches = (block_252: {
                                                                                                                                                    break :block_252 value_155;
                                                                                                                                                } + @as(u64, 1)), .negative_integers = (value_154).negative_integers, .objects = (value_154).objects, .optional_values = (value_154).optional_values, .parallels = (value_154).parallels, .projections = (value_154).projections, .references = (value_154).references, .scopes = (value_154).scopes, .sequences = (value_154).sequences, .some = (value_154).some, .stores = (value_154).stores, .strings = (value_154).strings, .table = (value_154).table, .tasks = (value_154).tasks, .transforms = (value_154).transforms, .unary = (value_154).unary, .updates = (value_154).updates, .valid = (value_154).valid, });
                                                                                                                                            };

                                                                                                                                            break :block_257 value_156;
                                                                                                                                        } else block_265: {
                                                                                                                                            const value_162: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = (if ((block_258: {
                                                                                                                                                break :block_258 value_3;
                                                                                                                                            } == @as((zx_abi).zx_type_20, .Object))) block_264: {
                                                                                                                                                const value_157: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = state_1;
                                                                                                                                                const value_158: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_263: {
                                                                                                                                                    break :block_263 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_157).awaits, .binary = (value_157).binary, .booleans = (value_157).booleans, .calls = (value_157).calls, .cancellations = (value_157).cancellations, .captures = (value_157).captures, .collections = (value_157).collections, .conditionals = (value_157).conditionals, .enumerations = (value_157).enumerations, .errors = (value_157).errors, .floats = (value_157).floats, .index = (value_157).index, .indices = (value_157).indices, .integers = (value_157).integers, .iterations = (value_157).iterations, .lengths = (value_157).lengths, .matches = (value_157).matches, .negative_integers = (value_157).negative_integers, .objects = (value_157).objects, .optional_values = (value_157).optional_values, .parallels = (value_157).parallels, .projections = (value_157).projections, .references = (value_157).references, .scopes = (value_157).scopes, .sequences = (value_157).sequences, .some = (value_157).some, .stores = (value_157).stores, .strings = (value_157).strings, .table = (value_157).table, .tasks = (value_157).tasks, .transforms = (value_157).transforms, .unary = (value_157).unary, .updates = (value_157).updates, .valid = ((block_261: {
                                                                                                                                                        break :block_261 value_4;
                                                                                                                                                    } == (state_1).objects) and (block_262: {
                                                                                                                                                        break :block_262 value_4;
                                                                                                                                                    } < @as(u64, (((state_1).table).object_first).len))), });
                                                                                                                                                };
                                                                                                                                                const value_159: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_158;
                                                                                                                                                const value_160: u64 = (value_159).objects;
                                                                                                                                                const value_161: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_260: {
                                                                                                                                                    break :block_260 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_159).awaits, .binary = (value_159).binary, .booleans = (value_159).booleans, .calls = (value_159).calls, .cancellations = (value_159).cancellations, .captures = (value_159).captures, .collections = (value_159).collections, .conditionals = (value_159).conditionals, .enumerations = (value_159).enumerations, .errors = (value_159).errors, .floats = (value_159).floats, .index = (value_159).index, .indices = (value_159).indices, .integers = (value_159).integers, .iterations = (value_159).iterations, .lengths = (value_159).lengths, .matches = (value_159).matches, .negative_integers = (value_159).negative_integers, .objects = (block_259: {
                                                                                                                                                        break :block_259 value_160;
                                                                                                                                                    } + @as(u64, 1)), .optional_values = (value_159).optional_values, .parallels = (value_159).parallels, .projections = (value_159).projections, .references = (value_159).references, .scopes = (value_159).scopes, .sequences = (value_159).sequences, .some = (value_159).some, .stores = (value_159).stores, .strings = (value_159).strings, .table = (value_159).table, .tasks = (value_159).tasks, .transforms = (value_159).transforms, .unary = (value_159).unary, .updates = (value_159).updates, .valid = (value_159).valid, });
                                                                                                                                                };

                                                                                                                                                break :block_264 value_161;
                                                                                                                                            } else state_1);

                                                                                                                                            break :block_265 value_162;
                                                                                                                                        });

                                                                                                                                        break :block_266 value_163;
                                                                                                                                    });

                                                                                                                                    break :block_267 value_164;
                                                                                                                                });

                                                                                                                                break :block_268 value_165;
                                                                                                                            });

                                                                                                                            break :block_269 value_166;
                                                                                                                        });

                                                                                                                        break :block_270 value_167;
                                                                                                                    });

                                                                                                                    break :block_271 value_168;
                                                                                                                });

                                                                                                                break :block_272 value_169;
                                                                                                            });

                                                                                                            break :block_273 value_170;
                                                                                                        });

                                                                                                        break :block_274 value_171;
                                                                                                    });

                                                                                                    break :block_275 value_172;
                                                                                                });

                                                                                                break :block_276 value_173;
                                                                                            });

                                                                                            break :block_277 value_174;
                                                                                        });

                                                                                        break :block_278 value_175;
                                                                                    });

                                                                                    break :block_279 value_176;
                                                                                });

                                                                                break :block_280 value_177;
                                                                            });

                                                                            break :block_281 value_178;
                                                                        });

                                                                        break :block_282 value_179;
                                                                    });

                                                                    break :block_283 value_180;
                                                                });

                                                                break :block_284 value_181;
                                                            });

                                                            break :block_285 value_182;
                                                        });

                                                        break :block_286 value_183;
                                                    });

                                                    break :block_287 value_184;
                                                });

                                                break :block_288 value_185;
                                            });

                                            break :block_289 value_186;
                                        });

                                        break :block_290 value_187;
                                    });

                                    break :block_291 value_188;
                                });

                                break :block_292 value_189;
                            });

                            break :block_293 value_190;
                        });

                        break :block_294 value_191;
                    });

                    break :block_295 value_192;
                });
                const value_194: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = value_193;
                const value_195: u64 = (value_194).index;
                const value_196: (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a = block_39: {
                    break :block_39 @as((zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a, (zx_abi).value_zx_type_35_5c6955c10d11f29e92e1a233cce1994c7adf38e167ee2f9594626941757ca41a{ .awaits = (value_194).awaits, .binary = (value_194).binary, .booleans = (value_194).booleans, .calls = (value_194).calls, .cancellations = (value_194).cancellations, .captures = (value_194).captures, .collections = (value_194).collections, .conditionals = (value_194).conditionals, .enumerations = (value_194).enumerations, .errors = (value_194).errors, .floats = (value_194).floats, .index = (block_38: {
                        break :block_38 value_195;
                    } + @as(u64, 1)), .indices = (value_194).indices, .integers = (value_194).integers, .iterations = (value_194).iterations, .lengths = (value_194).lengths, .matches = (value_194).matches, .negative_integers = (value_194).negative_integers, .objects = (value_194).objects, .optional_values = (value_194).optional_values, .parallels = (value_194).parallels, .projections = (value_194).projections, .references = (value_194).references, .scopes = (value_194).scopes, .sequences = (value_194).sequences, .some = (value_194).some, .stores = (value_194).stores, .strings = (value_194).strings, .table = (value_194).table, .tasks = (value_194).tasks, .transforms = (value_194).transforms, .unary = (value_194).unary, .updates = (value_194).updates, .valid = (value_194).valid, });
                };

                break :block_304 value_196;
            };
        }

        break :block_307 block_306: {
            break :block_306 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_305: {
                break :block_305 (zx_abi).zx_type_35{ .awaits = (state_1).awaits, .binary = (state_1).binary, .booleans = (state_1).booleans, .calls = (state_1).calls, .cancellations = (state_1).cancellations, .captures = (state_1).captures, .collections = (state_1).collections, .conditionals = (state_1).conditionals, .enumerations = (state_1).enumerations, .errors = (state_1).errors, .floats = (state_1).floats, .index = (state_1).index, .indices = (state_1).indices, .integers = (state_1).integers, .iterations = (state_1).iterations, .lengths = (state_1).lengths, .matches = (state_1).matches, .negative_integers = (state_1).negative_integers, .objects = (state_1).objects, .optional_values = (state_1).optional_values, .parallels = (state_1).parallels, .projections = (state_1).projections, .references = (state_1).references, .scopes = (state_1).scopes, .sequences = (state_1).sequences, .some = (state_1).some, .stores = (state_1).stores, .strings = (state_1).strings, .table = (state_1).table, .tasks = (state_1).tasks, .transforms = (state_1).transforms, .unary = (state_1).unary, .updates = (state_1).updates, .valid = (state_1).valid, };
            });
        };
    };

    return (((((((((((((((((((((((((((((((((&value_197)).valid and (((&value_197)).integers == @as(u64, ((in).integers).len))) and (((&value_197)).negative_integers == @as(u64, ((in).negative_integers).len))) and (((&value_197)).floats == @as(u64, ((in).floats).len))) and (((&value_197)).strings == @as(u64, ((in).strings).len))) and (((&value_197)).booleans == @as(u64, ((in).booleans).len))) and (((&value_197)).some == @as(u64, ((in).some).len))) and (((&value_197)).captures == @as(u64, ((in).captures).len))) and (((&value_197)).tasks == @as(u64, ((in).task_bodies).len))) and (((&value_197)).awaits == @as(u64, ((in).awaits).len))) and (((&value_197)).cancellations == @as(u64, ((in).cancellations).len))) and (((&value_197)).parallels == @as(u64, ((in).parallel_first).len))) and (((&value_197)).optional_values == @as(u64, ((in).optional_values).len))) and (((&value_197)).enumerations == @as(u64, ((in).enumerations).len))) and (((&value_197)).errors == @as(u64, ((in).errors).len))) and (((&value_197)).references == @as(u64, ((in).references).len))) and (((&value_197)).stores == @as(u64, ((in).stores).len))) and (((&value_197)).projections == @as(u64, ((in).projection_targets).len))) and (((&value_197)).indices == @as(u64, ((in).index_targets).len))) and (((&value_197)).lengths == @as(u64, ((in).lengths).len))) and (((&value_197)).sequences == @as(u64, ((in).sequence_first).len))) and (((&value_197)).collections == @as(u64, ((in).collection_kinds).len))) and (((&value_197)).transforms == @as(u64, ((in).transform_kinds).len))) and (((&value_197)).scopes == @as(u64, ((in).scope_results).len))) and (((&value_197)).iterations == @as(u64, ((in).iteration_initials).len))) and (((&value_197)).updates == @as(u64, ((in).update_targets).len))) and (((&value_197)).calls == @as(u64, ((in).call_functions).len))) and (((&value_197)).unary == @as(u64, ((in).unary_operands).len))) and (((&value_197)).binary == @as(u64, ((in).binary_operators).len))) and (((&value_197)).conditionals == @as(u64, ((in).conditional_conditions).len))) and (((&value_197)).matches == @as(u64, ((in).match_subjects).len))) and (((&value_197)).objects == @as(u64, ((in).object_first).len)));
}

fn function_5(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_36) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if (((((in).length > @as(u64, 4294967295)) or (@as(u64, ((in).first).len) > @as(u64, 4294967295))) or (@as(u64, ((in).first).len) != @as(u64, ((in).count).len)))) {
        return false;
    }

    const value_16: (zx_abi).zx_type_37 = block_38: {
        const operand_7 = block_6: {
            const operand_2 = in;
            const operand_3 = @as(u64, 0);
            const operand_4 = @as(u64, 0);
            const operand_5 = true;

            break :block_6 (zx_abi).zx_type_37{ .input = operand_2, .index = operand_3, .next = operand_4, .valid = operand_5, };
        };

        var state_1: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f{ .index = (operand_7).index, .input = (zx_abi).value_zx_type_36_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = ((operand_7).input).count, .first = ((operand_7).input).first, .length = ((operand_7).input).length, .zx_origin = (operand_7).input, }, .next = (operand_7).next, .valid = (operand_7).valid, .zx_origin = (&operand_7), };

        while (((state_1).valid and ((state_1).index < @as(u64, (((state_1).input).first).len)))) {
            state_1 = block_33: {
                const value_3: u64 = block_32: {
                    const operand_31 = block_30: {
                        const operand_28 = ((state_1).input).first;
                        const operand_29 = (state_1).index;

                        if ((operand_29 >= (operand_28).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_30 (operand_28)[@intCast(operand_29)];
                    };

                    break :block_32 (try function_2(allocator, operand_31));
                };
                const value_4: u64 = block_27: {
                    const operand_26 = block_25: {
                        const operand_23 = ((state_1).input).count;
                        const operand_24 = (state_1).index;

                        if ((operand_24 >= (operand_23).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_25 (operand_23)[@intCast(operand_24)];
                    };

                    break :block_27 (try function_2(allocator, operand_26));
                };
                const value_12: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = (if (((block_10: {
                    break :block_10 value_3;
                } != (state_1).next) or (block_11: {
                    break :block_11 value_3;
                } > ((state_1).input).length))) block_13: {
                    const value_5: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = state_1;
                    const value_6: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = block_12: {
                        break :block_12 @as((zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f, (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f{ .index = (value_5).index, .input = (value_5).input, .next = (value_5).next, .valid = false, });
                    };

                    break :block_13 value_6;
                } else block_22: {
                    const value_11: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = (if ((block_14: {
                        break :block_14 value_4;
                    } > (((state_1).input).length - block_15: {
                        break :block_15 value_3;
                    }))) block_17: {
                        const value_7: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = state_1;
                        const value_8: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = block_16: {
                            break :block_16 @as((zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f, (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f{ .index = (value_7).index, .input = (value_7).input, .next = (value_7).next, .valid = false, });
                        };

                        break :block_17 value_8;
                    } else block_21: {
                        const value_9: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = state_1;
                        const value_10: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = block_20: {
                            break :block_20 @as((zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f, (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f{ .index = (value_9).index, .input = (value_9).input, .next = (block_18: {
                                break :block_18 value_3;
                            } + block_19: {
                                break :block_19 value_4;
                            }), .valid = (value_9).valid, });
                        };

                        break :block_21 value_10;
                    });

                    break :block_22 value_11;
                });
                const value_13: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = value_12;
                const value_14: u64 = (value_13).index;
                const value_15: (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f = block_9: {
                    break :block_9 @as((zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f, (zx_abi).value_zx_type_37_0ae173ac67b7b98de25225b36b9f35ef42c7a39404a299ff73091ed9136a838f{ .index = (block_8: {
                        break :block_8 value_14;
                    } + @as(u64, 1)), .input = (value_13).input, .next = (value_13).next, .valid = (value_13).valid, });
                };

                break :block_33 value_15;
            };
        }

        break :block_38 block_37: {
            break :block_37 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_36: {
                break :block_36 (zx_abi).zx_type_37{ .index = (state_1).index, .input = (if ((((state_1).input).zx_origin != null)) ((state_1).input).zx_origin.? else block_35: {
                    const operand_34 = (try (allocator).create((zx_abi).zx_type_36));

                    (operand_34).* = (zx_abi).zx_type_36{ .count = ((state_1).input).count, .first = ((state_1).input).first, .length = ((state_1).input).length, };

                    break :block_35 @as(*const (zx_abi).zx_type_36, operand_34);
                }), .next = (state_1).next, .valid = (state_1).valid, };
            });
        };
    };

    return (((&value_16)).valid and (((&value_16)).next == (in).length));
}

fn function_6(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_34) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if ((!block_50: {
        const operand_46 = (in).sequence_first;
        const operand_47 = (in).sequence_count;
        const operand_48 = @as(u64, ((in).sequence_items).len);
        const operand_49 = (zx_abi).zx_type_36{ .first = operand_46, .count = operand_47, .length = operand_48, };

        break :block_50 (try function_5(allocator, (&operand_49)));
    })) {
        return false;
    }

    if ((!block_45: {
        const operand_41 = (in).task_capture_first;
        const operand_42 = (in).task_capture_count;
        const operand_43 = @as(u64, ((in).task_captures).len);
        const operand_44 = (zx_abi).zx_type_36{ .first = operand_41, .count = operand_42, .length = operand_43, };

        break :block_45 (try function_5(allocator, (&operand_44)));
    })) {
        return false;
    }

    if ((!block_40: {
        const operand_36 = (in).parallel_first;
        const operand_37 = (in).parallel_count;
        const operand_38 = @as(u64, ((in).parallel_tasks).len);
        const operand_39 = (zx_abi).zx_type_36{ .first = operand_36, .count = operand_37, .length = operand_38, };

        break :block_40 (try function_5(allocator, (&operand_39)));
    })) {
        return false;
    }

    if ((!block_35: {
        const operand_31 = (in).collection_first;
        const operand_32 = (in).collection_count;
        const operand_33 = @as(u64, ((in).collection_arguments).len);
        const operand_34 = (zx_abi).zx_type_36{ .first = operand_31, .count = operand_32, .length = operand_33, };

        break :block_35 (try function_5(allocator, (&operand_34)));
    })) {
        return false;
    }

    if ((!block_30: {
        const operand_26 = (in).transform_first;
        const operand_27 = (in).transform_count;
        const operand_28 = @as(u64, ((in).transform_parameters).len);
        const operand_29 = (zx_abi).zx_type_36{ .first = operand_26, .count = operand_27, .length = operand_28, };

        break :block_30 (try function_5(allocator, (&operand_29)));
    })) {
        return false;
    }

    if ((!block_25: {
        const operand_21 = (in).scope_first;
        const operand_22 = (in).scope_count;
        const operand_23 = @as(u64, ((in).scope_symbols).len);
        const operand_24 = (zx_abi).zx_type_36{ .first = operand_21, .count = operand_22, .length = operand_23, };

        break :block_25 (try function_5(allocator, (&operand_24)));
    })) {
        return false;
    }

    if ((!block_20: {
        const operand_16 = (in).call_store_first;
        const operand_17 = (in).call_store_count;
        const operand_18 = @as(u64, ((in).call_stores).len);
        const operand_19 = (zx_abi).zx_type_36{ .first = operand_16, .count = operand_17, .length = operand_18, };

        break :block_20 (try function_5(allocator, (&operand_19)));
    })) {
        return false;
    }

    if ((!block_15: {
        const operand_11 = (in).match_first;
        const operand_12 = (in).match_count;
        const operand_13 = @as(u64, ((in).match_conditions).len);
        const operand_14 = (zx_abi).zx_type_36{ .first = operand_11, .count = operand_12, .length = operand_13, };

        break :block_15 (try function_5(allocator, (&operand_14)));
    })) {
        return false;
    }

    if ((!block_10: {
        const operand_6 = (in).object_first;
        const operand_7 = (in).object_count;
        const operand_8 = @as(u64, ((in).object_field_indices).len);
        const operand_9 = (zx_abi).zx_type_36{ .first = operand_6, .count = operand_7, .length = operand_8, };

        break :block_10 (try function_5(allocator, (&operand_9)));
    })) {
        return false;
    }

    if ((!block_5: {
        const operand_1 = (in).object_evaluation_first;
        const operand_2 = (in).object_evaluation_count;
        const operand_3 = @as(u64, ((in).object_evaluation_values).len);
        const operand_4 = (zx_abi).zx_type_36{ .first = operand_1, .count = operand_2, .length = operand_3, };

        break :block_5 (try function_5(allocator, (&operand_4)));
    })) {
        return false;
    }

    return true;
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_34) error{ }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    if ((@as(u64, ((in).kinds).len) > @as(u64, 4294967295))) {
        return false;
    }

    if (((((@as(u64, ((in).kinds).len) != @as(u64, ((in).types).len)) or (@as(u64, ((in).kinds).len) != @as(u64, ((in).span_start).len))) or (@as(u64, ((in).kinds).len) != @as(u64, ((in).span_end).len))) or (@as(u64, ((in).kinds).len) != @as(u64, ((in).payloads).len)))) {
        return false;
    }

    if ((@as(u64, ((in).sequence_first).len) != @as(u64, ((in).sequence_count).len))) {
        return false;
    }

    if ((@as(u64, ((in).projection_targets).len) != @as(u64, ((in).projection_indices).len))) {
        return false;
    }

    if ((@as(u64, ((in).index_targets).len) != @as(u64, ((in).index_values).len))) {
        return false;
    }

    if (((@as(u64, ((in).task_bodies).len) != @as(u64, ((in).task_capture_first).len)) or (@as(u64, ((in).task_bodies).len) != @as(u64, ((in).task_capture_count).len)))) {
        return false;
    }

    if ((@as(u64, ((in).parallel_first).len) != @as(u64, ((in).parallel_count).len))) {
        return false;
    }

    if ((@as(u64, ((in).parallel_tasks).len) != @as(u64, ((in).parallel_fields).len))) {
        return false;
    }

    if ((((@as(u64, ((in).collection_kinds).len) != @as(u64, ((in).collection_targets).len)) or (@as(u64, ((in).collection_kinds).len) != @as(u64, ((in).collection_first).len))) or (@as(u64, ((in).collection_kinds).len) != @as(u64, ((in).collection_count).len)))) {
        return false;
    }

    if ((((((@as(u64, ((in).transform_kinds).len) != @as(u64, ((in).transform_targets).len)) or (@as(u64, ((in).transform_kinds).len) != @as(u64, ((in).transform_bodies).len))) or (@as(u64, ((in).transform_kinds).len) != @as(u64, ((in).transform_initials).len))) or (@as(u64, ((in).transform_kinds).len) != @as(u64, ((in).transform_first).len))) or (@as(u64, ((in).transform_kinds).len) != @as(u64, ((in).transform_count).len)))) {
        return false;
    }

    if (((@as(u64, ((in).scope_results).len) != @as(u64, ((in).scope_first).len)) or (@as(u64, ((in).scope_results).len) != @as(u64, ((in).scope_count).len)))) {
        return false;
    }

    if (((@as(u64, ((in).scope_symbols).len) != @as(u64, ((in).scope_values).len)) or (@as(u64, ((in).scope_symbols).len) != @as(u64, ((in).scope_borrows).len)))) {
        return false;
    }

    if ((((((@as(u64, ((in).iteration_initials).len) != @as(u64, ((in).iteration_condition_parameters).len)) or (@as(u64, ((in).iteration_initials).len) != @as(u64, ((in).iteration_parameters).len))) or (@as(u64, ((in).iteration_initials).len) != @as(u64, ((in).iteration_conditions).len))) or (@as(u64, ((in).iteration_initials).len) != @as(u64, ((in).iteration_bodies).len))) or (@as(u64, ((in).iteration_initials).len) != @as(u64, ((in).iteration_postconditions).len)))) {
        return false;
    }

    if (((@as(u64, ((in).update_targets).len) != @as(u64, ((in).update_indices).len)) or (@as(u64, ((in).update_targets).len) != @as(u64, ((in).update_values).len)))) {
        return false;
    }

    if ((((@as(u64, ((in).call_functions).len) != @as(u64, ((in).call_arguments).len)) or (@as(u64, ((in).call_functions).len) != @as(u64, ((in).call_store_first).len))) or (@as(u64, ((in).call_functions).len) != @as(u64, ((in).call_store_count).len)))) {
        return false;
    }

    if ((@as(u64, ((in).unary_operators).len) != @as(u64, ((in).unary_operands).len))) {
        return false;
    }

    if (((@as(u64, ((in).binary_operators).len) != @as(u64, ((in).binary_left).len)) or (@as(u64, ((in).binary_operators).len) != @as(u64, ((in).binary_right).len)))) {
        return false;
    }

    if (((@as(u64, ((in).conditional_conditions).len) != @as(u64, ((in).conditional_yes).len)) or (@as(u64, ((in).conditional_conditions).len) != @as(u64, ((in).conditional_no).len)))) {
        return false;
    }

    if ((((@as(u64, ((in).match_subjects).len) != @as(u64, ((in).match_fallbacks).len)) or (@as(u64, ((in).match_subjects).len) != @as(u64, ((in).match_first).len))) or (@as(u64, ((in).match_subjects).len) != @as(u64, ((in).match_count).len)))) {
        return false;
    }

    if ((@as(u64, ((in).match_conditions).len) != @as(u64, ((in).match_results).len))) {
        return false;
    }

    if ((((@as(u64, ((in).object_first).len) != @as(u64, ((in).object_count).len)) or (@as(u64, ((in).object_first).len) != @as(u64, ((in).object_evaluation_first).len))) or (@as(u64, ((in).object_first).len) != @as(u64, ((in).object_evaluation_count).len)))) {
        return false;
    }

    if ((@as(u64, ((in).object_field_indices).len) != @as(u64, ((in).object_field_values).len))) {
        return false;
    }

    return true;
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_38) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if ((!(try function_7(allocator, (in).table)))) {
        return false;
    }

    if (((!(try function_6(allocator, (in).table))) or (!(try function_4(allocator, (in).table))))) {
        return false;
    }

    return block_5: {
        const operand_1 = ((in).table).span_start;
        const operand_2 = ((in).table).span_end;
        const operand_3 = (in).max_offset;
        const operand_4 = (zx_abi).zx_type_12{ .starts = operand_1, .ends = operand_2, .max_offset = operand_3, };

        break :block_5 (try function_0(allocator, (&operand_4)));
    };
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_54) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_52 = ((in).contracts).*;
    const value_2: u64 = @as(u64, (((&value_1)).kinds).len);

    if (((((((value_2 > @as(u64, 4294967295)) or (@as(u64, (((&value_1)).predicates).len) != value_2)) or (@as(u64, (((&value_1)).symbols).len) != value_2)) or (@as(u64, (((&value_1)).expressions).len) != value_2)) or (@as(u64, (((&value_1)).span_start).len) != value_2)) or (@as(u64, (((&value_1)).span_end).len) != value_2))) {
        return false;
    }

    if ((!block_31: {
        const operand_27 = ((&value_1)).span_start;
        const operand_28 = ((&value_1)).span_end;
        const operand_29 = (in).max_offset;
        const operand_30 = (zx_abi).zx_type_12{ .starts = operand_27, .ends = operand_28, .max_offset = operand_29, };

        break :block_31 (try function_0(allocator, (&operand_30)));
    })) {
        return false;
    }

    return block_26: {
        const operand_7 = block_6: {
            const operand_2 = (&value_1);
            const operand_3 = (in).max_offset;
            const operand_4 = @as(u64, 0);
            const operand_5 = true;

            break :block_6 (zx_abi).zx_type_55{ .contracts = operand_2, .max_offset = operand_3, .index = operand_4, .valid = operand_5, };
        };

        var state_1: (zx_abi).value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8 = (zx_abi).value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8{ .contracts = (zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .expressions = ((operand_7).contracts).expressions, .kinds = ((operand_7).contracts).kinds, .predicates = ((operand_7).contracts).predicates, .span_end = ((operand_7).contracts).span_end, .span_start = ((operand_7).contracts).span_start, .symbols = ((operand_7).contracts).symbols, .zx_origin = (operand_7).contracts, }, .index = (operand_7).index, .max_offset = (operand_7).max_offset, .valid = (operand_7).valid, .zx_origin = (&operand_7), };

        while (((state_1).valid and ((state_1).index < @as(u64, (((state_1).contracts).kinds).len)))) {
            state_1 = block_25: {
                const value_5: (zx_abi).value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8 = state_1;
                const value_6: (zx_abi).value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8 = block_24: {
                    break :block_24 @as((zx_abi).value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8, (zx_abi).value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8{ .contracts = (value_5).contracts, .index = (value_5).index, .max_offset = (value_5).max_offset, .valid = (block_16: {
                        const operand_13 = block_12: {
                            const operand_10 = ((state_1).contracts).symbols;
                            const operand_11 = (state_1).index;

                            if ((operand_11 >= (operand_10).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_12 (operand_10)[@intCast(operand_11)];
                        };
                        const operand_14 = (state_1).max_offset;
                        const operand_15 = (zx_abi).zx_type_19{ .symbols = operand_13, .max_offset = operand_14, };

                        break :block_16 (try function_1(allocator, (&operand_15)));
                    } and block_23: {
                        const operand_20 = block_19: {
                            const operand_17 = ((state_1).contracts).expressions;
                            const operand_18 = (state_1).index;

                            if ((operand_18 >= (operand_17).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_19 (operand_17)[@intCast(operand_18)];
                        };
                        const operand_21 = (state_1).max_offset;
                        const operand_22 = (zx_abi).zx_type_38{ .table = operand_20, .max_offset = operand_21, };

                        break :block_23 (try function_8(allocator, (&operand_22)));
                    }), });
                };
                const value_7: (zx_abi).value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8 = value_6;
                const value_8: u64 = (value_7).index;
                const value_9: (zx_abi).value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8 = block_9: {
                    break :block_9 @as((zx_abi).value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8, (zx_abi).value_zx_type_55_57f85255c4e0f481bb9dba6f1c5c53a3c79606b4646e8359ba48db8ca9d7abe8{ .contracts = (value_7).contracts, .index = (block_8: {
                        break :block_8 value_8;
                    } + @as(u64, 1)), .max_offset = (value_7).max_offset, .valid = (value_7).valid, });
                };

                break :block_25 value_9;
            };
        }

        break :block_26 (state_1).valid;
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_54) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = (try function_9(allocator, in));

    return value_1;
}

