const std = @import("std");

const zx_native_0 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .scalar, };

const zx_shape_13 = .{ .kind = .scalar, };

const zx_shape_14 = .{ .kind = .scalar, };

const zx_shape_15 = .{ .kind = .scalar, };

const zx_shape_16 = .{ .kind = .list, .child = zx_shape_11, };

const zx_shape_17 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_18 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_19 = .{ .kind = .list, .child = zx_shape_9, };

const zx_shape_20 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_21 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_22 = .{ .kind = .optional, .child = zx_shape_4, };

const zx_shape_23 = .{ .kind = .list, .child = zx_shape_22, };

const zx_shape_24 = .{ .kind = .list, .child = zx_shape_12, };

const zx_shape_25 = .{ .kind = .list, .child = zx_shape_13, };

const zx_shape_26 = .{ .kind = .list, .child = zx_shape_14, };

const zx_shape_27 = .{ .kind = .list, .child = zx_shape_15, };

const zx_shape_28 = .{ .kind = .object, .fields = .{ .awaits = zx_shape_17, .binary_left = zx_shape_17, .binary_operators = zx_shape_27, .binary_right = zx_shape_17, .booleans = zx_shape_21, .call_arguments = zx_shape_17, .call_functions = zx_shape_17, .call_store_count = zx_shape_17, .call_store_first = zx_shape_17, .call_stores = zx_shape_17, .cancellations = zx_shape_17, .captures = zx_shape_17, .collection_arguments = zx_shape_17, .collection_count = zx_shape_17, .collection_first = zx_shape_17, .collection_kinds = zx_shape_24, .collection_targets = zx_shape_17, .conditional_conditions = zx_shape_17, .conditional_no = zx_shape_17, .conditional_yes = zx_shape_17, .enumerations = zx_shape_17, .errors = zx_shape_17, .floats = zx_shape_19, .index_targets = zx_shape_17, .index_values = zx_shape_17, .integers = zx_shape_18, .iteration_bodies = zx_shape_17, .iteration_condition_parameters = zx_shape_17, .iteration_conditions = zx_shape_17, .iteration_initials = zx_shape_17, .iteration_parameters = zx_shape_17, .iteration_postconditions = zx_shape_21, .kinds = zx_shape_16, .lengths = zx_shape_17, .match_conditions = zx_shape_17, .match_count = zx_shape_17, .match_fallbacks = zx_shape_17, .match_first = zx_shape_17, .match_results = zx_shape_17, .match_subjects = zx_shape_23, .negative_integers = zx_shape_18, .object_count = zx_shape_17, .object_evaluation_count = zx_shape_17, .object_evaluation_first = zx_shape_17, .object_evaluation_values = zx_shape_17, .object_field_indices = zx_shape_17, .object_field_values = zx_shape_17, .object_first = zx_shape_17, .optional_values = zx_shape_17, .parallel_count = zx_shape_17, .parallel_fields = zx_shape_23, .parallel_first = zx_shape_17, .parallel_tasks = zx_shape_17, .payloads = zx_shape_17, .projection_indices = zx_shape_17, .projection_targets = zx_shape_17, .references = zx_shape_17, .scope_borrows = zx_shape_21, .scope_count = zx_shape_17, .scope_first = zx_shape_17, .scope_results = zx_shape_17, .scope_symbols = zx_shape_23, .scope_values = zx_shape_17, .sequence_count = zx_shape_17, .sequence_first = zx_shape_17, .sequence_items = zx_shape_17, .some = zx_shape_17, .span_end = zx_shape_18, .span_start = zx_shape_18, .stores = zx_shape_17, .strings = zx_shape_20, .task_bodies = zx_shape_17, .task_capture_count = zx_shape_17, .task_capture_first = zx_shape_17, .task_captures = zx_shape_17, .transform_bodies = zx_shape_17, .transform_count = zx_shape_17, .transform_first = zx_shape_17, .transform_initials = zx_shape_23, .transform_kinds = zx_shape_25, .transform_parameters = zx_shape_17, .transform_targets = zx_shape_17, .types = zx_shape_17, .unary_operands = zx_shape_17, .unary_operators = zx_shape_26, .update_indices = zx_shape_17, .update_targets = zx_shape_17, .update_values = zx_shape_17, }, };

const zx_shape_29 = .{ .kind = .object, .fields = .{ .allowed = zx_shape_21, .concurrent = zx_shape_1, .expressions = zx_shape_28, .limit = zx_shape_5, }, };

const zx_shape_30 = .{ .kind = .object, .fields = .{ .allowed = zx_shape_21, .concurrent = zx_shape_1, .expressions = zx_shape_28, .index = zx_shape_5, .limit = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_31 = .{ .kind = .object, .fields = .{ .handles = zx_shape_20, .paths = zx_shape_20, .readable = zx_shape_21, .types = zx_shape_17, .writable = zx_shape_21, }, };

const zx_shape_32 = .{ .kind = .list, .child = zx_shape_31, };

const zx_shape_33 = .{ .kind = .list, .child = zx_shape_28, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_33, .native_concurrent = zx_shape_21, .native_modules = zx_shape_23, .stores = zx_shape_32, }, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .concurrent = zx_shape_1, .functions = zx_shape_34, }, };

const zx_shape_36 = .{ .kind = .object, .fields = .{ .concurrent = zx_shape_1, .functions = zx_shape_34, .index = zx_shape_5, .values = zx_shape_21, }, };

const zx_shape_37 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_34, }, };

const zx_shape_38 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_34, .@"1" = zx_shape_21, }, };

pub const input_shape = zx_shape_34;

pub const output_shape = zx_shape_21;

pub const Input = *const (zx_abi).zx_type_34;

pub const Output = []const bool;

fn function_0(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_29) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    return block_50: {
        const operand_9 = block_8: {
            const operand_2 = (in).expressions;
            const operand_3 = (in).allowed;
            const operand_4 = (in).limit;
            const operand_5 = (in).concurrent;
            const operand_6 = @as(u64, 0);
            const operand_7 = true;

            break :block_8 (zx_abi).zx_type_30{ .expressions = operand_2, .allowed = operand_3, .limit = operand_4, .concurrent = operand_5, .index = operand_6, .valid = operand_7, };
        };

        var state_1: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .allowed = (operand_9).allowed, .concurrent = (operand_9).concurrent, .expressions = (operand_9).expressions, .index = (operand_9).index, .limit = (operand_9).limit, .valid = (operand_9).valid, .zx_origin = (&operand_9), };

        while (((state_1).valid and ((state_1).index < @as(u64, (((state_1).expressions).kinds).len)))) {
            state_1 = block_49: {
                const value_3: (zx_abi).zx_type_11 = block_48: {
                    const operand_46 = ((state_1).expressions).kinds;
                    const operand_47 = (state_1).index;

                    if ((operand_47 >= (operand_46).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_48 (operand_46)[@intCast(operand_47)];
                };
                const value_14: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (if ((block_12: {
                    break :block_12 value_3;
                } == @as((zx_abi).zx_type_11, .StoreGet))) block_14: {
                    const value_4: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = state_1;
                    const value_5: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_13: {
                        break :block_13 @as((zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .allowed = (value_4).allowed, .concurrent = (value_4).concurrent, .expressions = (value_4).expressions, .index = (value_4).index, .limit = (value_4).limit, .valid = false, });
                    };

                    break :block_14 value_5;
                } else block_45: {
                    const value_13: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (if (((!(state_1).concurrent) and ((((block_15: {
                        break :block_15 value_3;
                    } == @as((zx_abi).zx_type_11, .Task)) or (block_16: {
                        break :block_16 value_3;
                    } == @as((zx_abi).zx_type_11, .AwaitTask))) or (block_17: {
                        break :block_17 value_3;
                    } == @as((zx_abi).zx_type_11, .CancelTask))) or (block_18: {
                        break :block_18 value_3;
                    } == @as((zx_abi).zx_type_11, .Parallel))))) block_20: {
                        const value_6: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = state_1;
                        const value_7: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_19: {
                            break :block_19 @as((zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .allowed = (value_6).allowed, .concurrent = (value_6).concurrent, .expressions = (value_6).expressions, .index = (value_6).index, .limit = (value_6).limit, .valid = false, });
                        };

                        break :block_20 value_7;
                    } else block_44: {
                        const value_12: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (if ((block_21: {
                            break :block_21 value_3;
                        } == @as((zx_abi).zx_type_11, .Call))) block_43: {
                            const value_8: u64 = block_42: {
                                const operand_41 = block_40: {
                                    const operand_38 = ((state_1).expressions).payloads;
                                    const operand_39 = (state_1).index;

                                    if ((operand_39 >= (operand_38).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_40 (operand_38)[@intCast(operand_39)];
                                };

                                break :block_42 (try function_0(allocator, operand_41));
                            };
                            const value_9: u64 = block_37: {
                                const operand_36 = block_35: {
                                    const operand_33 = ((state_1).expressions).call_functions;
                                    const operand_34 = block_32: {
                                        break :block_32 value_8;
                                    };

                                    if ((operand_34 >= (operand_33).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_35 (operand_33)[@intCast(operand_34)];
                                };

                                break :block_37 (try function_0(allocator, operand_36));
                            };
                            const value_10: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = state_1;
                            const value_11: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_31: {
                                break :block_31 @as((zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .allowed = (value_10).allowed, .concurrent = (value_10).concurrent, .expressions = (value_10).expressions, .index = (value_10).index, .limit = (value_10).limit, .valid = (((block_25: {
                                    const operand_23 = ((state_1).expressions).call_store_count;
                                    const operand_24 = block_22: {
                                        break :block_22 value_8;
                                    };

                                    if ((operand_24 >= (operand_23).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_25 (operand_23)[@intCast(operand_24)];
                                } == @as(u32, 0)) and (block_26: {
                                    break :block_26 value_9;
                                } < (state_1).limit)) and block_30: {
                                    const operand_28 = (state_1).allowed;
                                    const operand_29 = block_27: {
                                        break :block_27 value_9;
                                    };

                                    if ((operand_29 >= (operand_28).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_30 (operand_28)[@intCast(operand_29)];
                                }), });
                            };

                            break :block_43 value_11;
                        } else state_1);

                        break :block_44 value_12;
                    });

                    break :block_45 value_13;
                });
                const value_15: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = value_14;
                const value_16: u64 = (value_15).index;
                const value_17: (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_11: {
                    break :block_11 @as((zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_30_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .allowed = (value_15).allowed, .concurrent = (value_15).concurrent, .expressions = (value_15).expressions, .index = (block_10: {
                        break :block_10 value_16;
                    } + @as(u64, 1)), .limit = (value_15).limit, .valid = (value_15).valid, });
                };

                break :block_49 value_17;
            };
        }

        break :block_50 (state_1).valid;
    };
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_35) error{ IndexOutOfBounds, OutOfMemory, }![]const bool {
    @setRuntimeSafety(true);

    const value_2: []const bool = block_61: {
        const operand_58 = ((in).functions).native_modules;
        const operand_59 = (try (allocator).alloc(bool, (operand_58).len));

        for (operand_58, 0..) |_, index_60| {
            (operand_59)[index_60] = false;
        }

        break :block_61 operand_59;
    };
    const value_13: *const (zx_abi).zx_type_36 = block_57: {
        const operand_9 = block_8: {
            const operand_2 = (in).functions;
            const operand_3 = (in).concurrent;
            const operand_4 = value_2;
            const operand_5 = @as(u64, 0);

            break :block_8 block_7: {
                const operand_6 = (try (allocator).create((zx_abi).zx_type_36));

                (operand_6).* = @as((zx_abi).zx_type_36, (zx_abi).zx_type_36{ .functions = operand_2, .concurrent = operand_3, .values = operand_4, .index = operand_5, });

                break :block_7 @as(*const (zx_abi).zx_type_36, operand_6);
            };
        };

        var state_items_11: []bool = undefined;

        var state_items_started_12 = false;

        const state_type_13 = struct {
            expressions: []const *const (zx_abi).zx_type_28,
            native_concurrent: []const bool,
            native_modules: []const ?u32,
            stores: []const *const (zx_abi).zx_type_31,
        };
        const state_type_14 = struct {
            concurrent: bool,
            functions: state_type_13,
            index: u64,
            values: []const bool,
        };
        const state_type_26 = struct {
            handles: []const []const u8,
            paths: []const []const u8,
            readable: []const bool,
            types: []const u32,
            writable: []const bool,
        };
        const state_type_34 = struct {
            awaits: []const u32,
            binary_left: []const u32,
            binary_operators: []const (zx_abi).zx_type_15,
            binary_right: []const u32,
            booleans: []const bool,
            call_arguments: []const u32,
            call_functions: []const u32,
            call_store_count: []const u32,
            call_store_first: []const u32,
            call_stores: []const u32,
            cancellations: []const u32,
            captures: []const u32,
            collection_arguments: []const u32,
            collection_count: []const u32,
            collection_first: []const u32,
            collection_kinds: []const (zx_abi).zx_type_12,
            collection_targets: []const u32,
            conditional_conditions: []const u32,
            conditional_no: []const u32,
            conditional_yes: []const u32,
            enumerations: []const u32,
            errors: []const u32,
            floats: []const f64,
            index_targets: []const u32,
            index_values: []const u32,
            integers: []const u64,
            iteration_bodies: []const u32,
            iteration_condition_parameters: []const u32,
            iteration_conditions: []const u32,
            iteration_initials: []const u32,
            iteration_parameters: []const u32,
            iteration_postconditions: []const bool,
            kinds: []const (zx_abi).zx_type_11,
            lengths: []const u32,
            match_conditions: []const u32,
            match_count: []const u32,
            match_fallbacks: []const u32,
            match_first: []const u32,
            match_results: []const u32,
            match_subjects: []const ?u32,
            negative_integers: []const u64,
            object_count: []const u32,
            object_evaluation_count: []const u32,
            object_evaluation_first: []const u32,
            object_evaluation_values: []const u32,
            object_field_indices: []const u32,
            object_field_values: []const u32,
            object_first: []const u32,
            optional_values: []const u32,
            parallel_count: []const u32,
            parallel_fields: []const ?u32,
            parallel_first: []const u32,
            parallel_tasks: []const u32,
            payloads: []const u32,
            projection_indices: []const u32,
            projection_targets: []const u32,
            references: []const u32,
            scope_borrows: []const bool,
            scope_count: []const u32,
            scope_first: []const u32,
            scope_results: []const u32,
            scope_symbols: []const ?u32,
            scope_values: []const u32,
            sequence_count: []const u32,
            sequence_first: []const u32,
            sequence_items: []const u32,
            some: []const u32,
            span_end: []const u64,
            span_start: []const u64,
            stores: []const u32,
            strings: []const []const u8,
            task_bodies: []const u32,
            task_capture_count: []const u32,
            task_capture_first: []const u32,
            task_captures: []const u32,
            transform_bodies: []const u32,
            transform_count: []const u32,
            transform_first: []const u32,
            transform_initials: []const ?u32,
            transform_kinds: []const (zx_abi).zx_type_13,
            transform_parameters: []const u32,
            transform_targets: []const u32,
            types: []const u32,
            unary_operands: []const u32,
            unary_operators: []const (zx_abi).zx_type_14,
            update_indices: []const u32,
            update_targets: []const u32,
            update_values: []const u32,
        };
        const state_type_35 = struct {
            allowed: []const bool,
            concurrent: bool,
            expressions: state_type_34,
            limit: u64,
        };

        var state_1: state_type_14 = state_type_14{ .concurrent = (operand_9).concurrent, .functions = state_type_13{ .expressions = ((operand_9).functions).expressions, .native_concurrent = ((operand_9).functions).native_concurrent, .native_modules = ((operand_9).functions).native_modules, .stores = ((operand_9).functions).stores, }, .index = (operand_9).index, .values = (operand_9).values, };

        var state_changed_10 = false;

        while (((state_1).index < @as(u64, ((state_1).values).len))) {
            state_1 = block_51: {
                const value_5: bool = ((@as(u64, ((block_27: {
                    const operand_25 = block_24: {
                        const operand_22 = ((state_1).functions).stores;
                        const operand_23 = (state_1).index;

                        if ((operand_23 >= (operand_22).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_24 (operand_22)[@intCast(operand_23)];
                    };

                    break :block_27 state_type_26{ .handles = (operand_25).handles, .paths = (operand_25).paths, .readable = (operand_25).readable, .types = (operand_25).types, .writable = (operand_25).writable, };
                }).paths).len) == @as(u64, 0)) and (if ((block_30: {
                    const operand_28 = ((state_1).functions).native_modules;
                    const operand_29 = (state_1).index;

                    if ((operand_29 >= (operand_28).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_30 (operand_28)[@intCast(operand_29)];
                } != null)) ((state_1).concurrent and block_33: {
                    const operand_31 = ((state_1).functions).native_concurrent;
                    const operand_32 = (state_1).index;

                    if ((operand_32 >= (operand_31).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_33 (operand_31)[@intCast(operand_32)];
                }) else block_50: {
                    const operand_46 = block_45: {
                        const operand_41 = block_40: {
                            const operand_39 = block_38: {
                                const operand_36 = ((state_1).functions).expressions;
                                const operand_37 = (state_1).index;

                                if ((operand_37 >= (operand_36).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_38 (operand_36)[@intCast(operand_37)];
                            };

                            break :block_40 state_type_34{ .awaits = (operand_39).awaits, .binary_left = (operand_39).binary_left, .binary_operators = (operand_39).binary_operators, .binary_right = (operand_39).binary_right, .booleans = (operand_39).booleans, .call_arguments = (operand_39).call_arguments, .call_functions = (operand_39).call_functions, .call_store_count = (operand_39).call_store_count, .call_store_first = (operand_39).call_store_first, .call_stores = (operand_39).call_stores, .cancellations = (operand_39).cancellations, .captures = (operand_39).captures, .collection_arguments = (operand_39).collection_arguments, .collection_count = (operand_39).collection_count, .collection_first = (operand_39).collection_first, .collection_kinds = (operand_39).collection_kinds, .collection_targets = (operand_39).collection_targets, .conditional_conditions = (operand_39).conditional_conditions, .conditional_no = (operand_39).conditional_no, .conditional_yes = (operand_39).conditional_yes, .enumerations = (operand_39).enumerations, .errors = (operand_39).errors, .floats = (operand_39).floats, .index_targets = (operand_39).index_targets, .index_values = (operand_39).index_values, .integers = (operand_39).integers, .iteration_bodies = (operand_39).iteration_bodies, .iteration_condition_parameters = (operand_39).iteration_condition_parameters, .iteration_conditions = (operand_39).iteration_conditions, .iteration_initials = (operand_39).iteration_initials, .iteration_parameters = (operand_39).iteration_parameters, .iteration_postconditions = (operand_39).iteration_postconditions, .kinds = (operand_39).kinds, .lengths = (operand_39).lengths, .match_conditions = (operand_39).match_conditions, .match_count = (operand_39).match_count, .match_fallbacks = (operand_39).match_fallbacks, .match_first = (operand_39).match_first, .match_results = (operand_39).match_results, .match_subjects = (operand_39).match_subjects, .negative_integers = (operand_39).negative_integers, .object_count = (operand_39).object_count, .object_evaluation_count = (operand_39).object_evaluation_count, .object_evaluation_first = (operand_39).object_evaluation_first, .object_evaluation_values = (operand_39).object_evaluation_values, .object_field_indices = (operand_39).object_field_indices, .object_field_values = (operand_39).object_field_values, .object_first = (operand_39).object_first, .optional_values = (operand_39).optional_values, .parallel_count = (operand_39).parallel_count, .parallel_fields = (operand_39).parallel_fields, .parallel_first = (operand_39).parallel_first, .parallel_tasks = (operand_39).parallel_tasks, .payloads = (operand_39).payloads, .projection_indices = (operand_39).projection_indices, .projection_targets = (operand_39).projection_targets, .references = (operand_39).references, .scope_borrows = (operand_39).scope_borrows, .scope_count = (operand_39).scope_count, .scope_first = (operand_39).scope_first, .scope_results = (operand_39).scope_results, .scope_symbols = (operand_39).scope_symbols, .scope_values = (operand_39).scope_values, .sequence_count = (operand_39).sequence_count, .sequence_first = (operand_39).sequence_first, .sequence_items = (operand_39).sequence_items, .some = (operand_39).some, .span_end = (operand_39).span_end, .span_start = (operand_39).span_start, .stores = (operand_39).stores, .strings = (operand_39).strings, .task_bodies = (operand_39).task_bodies, .task_capture_count = (operand_39).task_capture_count, .task_capture_first = (operand_39).task_capture_first, .task_captures = (operand_39).task_captures, .transform_bodies = (operand_39).transform_bodies, .transform_count = (operand_39).transform_count, .transform_first = (operand_39).transform_first, .transform_initials = (operand_39).transform_initials, .transform_kinds = (operand_39).transform_kinds, .transform_parameters = (operand_39).transform_parameters, .transform_targets = (operand_39).transform_targets, .types = (operand_39).types, .unary_operands = (operand_39).unary_operands, .unary_operators = (operand_39).unary_operators, .update_indices = (operand_39).update_indices, .update_targets = (operand_39).update_targets, .update_values = (operand_39).update_values, };
                        };
                        const operand_42 = (state_1).values;
                        const operand_43 = (state_1).index;
                        const operand_44 = (state_1).concurrent;

                        break :block_45 state_type_35{ .expressions = operand_41, .allowed = operand_42, .limit = operand_43, .concurrent = operand_44, };
                    };
                    const operand_47 = (zx_abi).zx_type_28{ .awaits = ((operand_46).expressions).awaits, .binary_left = ((operand_46).expressions).binary_left, .binary_operators = ((operand_46).expressions).binary_operators, .binary_right = ((operand_46).expressions).binary_right, .booleans = ((operand_46).expressions).booleans, .call_arguments = ((operand_46).expressions).call_arguments, .call_functions = ((operand_46).expressions).call_functions, .call_store_count = ((operand_46).expressions).call_store_count, .call_store_first = ((operand_46).expressions).call_store_first, .call_stores = ((operand_46).expressions).call_stores, .cancellations = ((operand_46).expressions).cancellations, .captures = ((operand_46).expressions).captures, .collection_arguments = ((operand_46).expressions).collection_arguments, .collection_count = ((operand_46).expressions).collection_count, .collection_first = ((operand_46).expressions).collection_first, .collection_kinds = ((operand_46).expressions).collection_kinds, .collection_targets = ((operand_46).expressions).collection_targets, .conditional_conditions = ((operand_46).expressions).conditional_conditions, .conditional_no = ((operand_46).expressions).conditional_no, .conditional_yes = ((operand_46).expressions).conditional_yes, .enumerations = ((operand_46).expressions).enumerations, .errors = ((operand_46).expressions).errors, .floats = ((operand_46).expressions).floats, .index_targets = ((operand_46).expressions).index_targets, .index_values = ((operand_46).expressions).index_values, .integers = ((operand_46).expressions).integers, .iteration_bodies = ((operand_46).expressions).iteration_bodies, .iteration_condition_parameters = ((operand_46).expressions).iteration_condition_parameters, .iteration_conditions = ((operand_46).expressions).iteration_conditions, .iteration_initials = ((operand_46).expressions).iteration_initials, .iteration_parameters = ((operand_46).expressions).iteration_parameters, .iteration_postconditions = ((operand_46).expressions).iteration_postconditions, .kinds = ((operand_46).expressions).kinds, .lengths = ((operand_46).expressions).lengths, .match_conditions = ((operand_46).expressions).match_conditions, .match_count = ((operand_46).expressions).match_count, .match_fallbacks = ((operand_46).expressions).match_fallbacks, .match_first = ((operand_46).expressions).match_first, .match_results = ((operand_46).expressions).match_results, .match_subjects = ((operand_46).expressions).match_subjects, .negative_integers = ((operand_46).expressions).negative_integers, .object_count = ((operand_46).expressions).object_count, .object_evaluation_count = ((operand_46).expressions).object_evaluation_count, .object_evaluation_first = ((operand_46).expressions).object_evaluation_first, .object_evaluation_values = ((operand_46).expressions).object_evaluation_values, .object_field_indices = ((operand_46).expressions).object_field_indices, .object_field_values = ((operand_46).expressions).object_field_values, .object_first = ((operand_46).expressions).object_first, .optional_values = ((operand_46).expressions).optional_values, .parallel_count = ((operand_46).expressions).parallel_count, .parallel_fields = ((operand_46).expressions).parallel_fields, .parallel_first = ((operand_46).expressions).parallel_first, .parallel_tasks = ((operand_46).expressions).parallel_tasks, .payloads = ((operand_46).expressions).payloads, .projection_indices = ((operand_46).expressions).projection_indices, .projection_targets = ((operand_46).expressions).projection_targets, .references = ((operand_46).expressions).references, .scope_borrows = ((operand_46).expressions).scope_borrows, .scope_count = ((operand_46).expressions).scope_count, .scope_first = ((operand_46).expressions).scope_first, .scope_results = ((operand_46).expressions).scope_results, .scope_symbols = ((operand_46).expressions).scope_symbols, .scope_values = ((operand_46).expressions).scope_values, .sequence_count = ((operand_46).expressions).sequence_count, .sequence_first = ((operand_46).expressions).sequence_first, .sequence_items = ((operand_46).expressions).sequence_items, .some = ((operand_46).expressions).some, .span_end = ((operand_46).expressions).span_end, .span_start = ((operand_46).expressions).span_start, .stores = ((operand_46).expressions).stores, .strings = ((operand_46).expressions).strings, .task_bodies = ((operand_46).expressions).task_bodies, .task_capture_count = ((operand_46).expressions).task_capture_count, .task_capture_first = ((operand_46).expressions).task_capture_first, .task_captures = ((operand_46).expressions).task_captures, .transform_bodies = ((operand_46).expressions).transform_bodies, .transform_count = ((operand_46).expressions).transform_count, .transform_first = ((operand_46).expressions).transform_first, .transform_initials = ((operand_46).expressions).transform_initials, .transform_kinds = ((operand_46).expressions).transform_kinds, .transform_parameters = ((operand_46).expressions).transform_parameters, .transform_targets = ((operand_46).expressions).transform_targets, .types = ((operand_46).expressions).types, .unary_operands = ((operand_46).expressions).unary_operands, .unary_operators = ((operand_46).expressions).unary_operators, .update_indices = ((operand_46).expressions).update_indices, .update_targets = ((operand_46).expressions).update_targets, .update_values = ((operand_46).expressions).update_values, };
                    const operand_48 = (zx_abi).zx_type_29{ .allowed = (operand_46).allowed, .concurrent = (operand_46).concurrent, .expressions = (&operand_47), .limit = (operand_46).limit, };
                    const operand_49 = (try function_2(allocator, (&operand_48)));

                    break :block_50 operand_49;
                }));
                const value_6: state_type_14 = state_1;
                const value_7: []const bool = (value_6).values;
                const value_8: u64 = (state_1).index;
                const value_9: state_type_14 = block_21: {
                    break :block_21 state_type_14{ .concurrent = (value_6).concurrent, .functions = (value_6).functions, .index = (value_6).index, .values = block_20: {
                        const operand_16 = value_7;
                        const operand_17 = value_8;

                        if ((operand_17 >= (operand_16).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_18 = value_5;

                        break :block_20 block_19: {
                            if ((!state_items_started_12)) {
                                state_items_11 = @constCast(operand_16);

                                state_items_started_12 = true;
                            }

                            (state_items_11)[@intCast(operand_17)] = operand_18;

                            break :block_19 state_items_11;
                        };
                    }, };
                };
                const value_10: state_type_14 = value_9;
                const value_11: u64 = (value_10).index;
                const value_12: state_type_14 = block_15: {
                    break :block_15 state_type_14{ .concurrent = (value_10).concurrent, .functions = (value_10).functions, .index = (value_11 + @as(u64, 1)), .values = (value_10).values, };
                };

                break :block_51 value_12;
            };

            state_changed_10 = true;
        }

        break :block_57 (if (state_changed_10) block_56: {
            const operand_55 = (try (allocator).create((zx_abi).zx_type_36));

            (operand_55).* = @as((zx_abi).zx_type_36, (zx_abi).zx_type_36{ .concurrent = (state_1).concurrent, .functions = block_54: {
                const operand_53 = (try (allocator).create((zx_abi).zx_type_34));

                (operand_53).* = @as((zx_abi).zx_type_34, (zx_abi).zx_type_34{ .expressions = ((state_1).functions).expressions, .native_concurrent = ((state_1).functions).native_concurrent, .native_modules = ((state_1).functions).native_modules, .stores = ((state_1).functions).stores, });

                break :block_54 @as(*const (zx_abi).zx_type_34, operand_53);
            }, .index = (state_1).index, .values = (state_1).values, });

            break :block_56 @as(*const (zx_abi).zx_type_36, operand_55);
        } else operand_9);
    };

    return (value_13).values;
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_34) error{ IndexOutOfBounds, OutOfMemory, }![]const bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: []const bool = (try function_3(allocator, block_5: {
        const operand_1 = in;
        const operand_2 = false;

        break :block_5 block_4: {
            const operand_3 = (try (allocator).create((zx_abi).zx_type_35));

            (operand_3).* = @as((zx_abi).zx_type_35, (zx_abi).zx_type_35{ .functions = operand_1, .concurrent = operand_2, });

            break :block_4 @as(*const (zx_abi).zx_type_35, operand_3);
        };
    }));

    return value_1;
}

