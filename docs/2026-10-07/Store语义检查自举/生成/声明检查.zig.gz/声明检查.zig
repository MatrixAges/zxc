const std = @import("std");

const zx_native_0 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_14 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .field_names = zx_shape_14, .field_types = zx_shape_13, .first = zx_shape_13, .kinds = zx_shape_12, .labels = zx_shape_14, .names = zx_shape_14, .second = zx_shape_13, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .base = zx_shape_15, .delta = zx_shape_15, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .delta = zx_shape_1, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .second = zx_shape_4, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .names = zx_shape_14, .types = zx_shape_13, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .fields = zx_shape_18, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .names = zx_shape_14, .second = zx_shape_4, }, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .id = zx_shape_4, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .delta = zx_shape_15, .id = zx_shape_4, }, };

const zx_shape_22 = .{ .kind = .object, .fields = .{ .id = zx_shape_4, .tables = zx_shape_16, }, };

const zx_shape_23 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_24 = .{ .kind = .object, .fields = .{ .flags = zx_shape_23, .index = zx_shape_5, .native_references = zx_shape_1, .tables = zx_shape_16, }, };

const zx_shape_25 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .count = zx_shape_5, .flags = zx_shape_23, .found = zx_shape_1, .index = zx_shape_5, .offset = zx_shape_5, }, };

const zx_shape_26 = .{ .kind = .object, .fields = .{ .id = zx_shape_4, .native_references = zx_shape_1, .tables = zx_shape_16, }, };

const zx_shape_27 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .index = zx_shape_5, .limit = zx_shape_5, .tables = zx_shape_16, .target = zx_shape_11, }, };

const zx_shape_28 = .{ .kind = .object, .fields = .{ .first = zx_shape_5, .flags = zx_shape_23, .index = zx_shape_5, .limit = zx_shape_5, .native_references = zx_shape_1, .tables = zx_shape_16, }, };

const zx_shape_29 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_23, .@"1" = zx_shape_0, }, };

const zx_shape_30 = .{ .kind = .object, .fields = .{ .id = zx_shape_4, .native_references = zx_shape_1, .table = zx_shape_15, }, };

const zx_shape_31 = .{ .kind = .list, .child = zx_shape_12, };

const zx_shape_32 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .paths = zx_shape_31, }, };

const zx_shape_33 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .limit = zx_shape_5, .path = zx_shape_12, .paths = zx_shape_31, .repeated = zx_shape_1, }, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .equal = zx_shape_1, .index = zx_shape_5, .left = zx_shape_12, .right = zx_shape_12, }, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .paths = zx_shape_31, .slot_types = zx_shape_13, .table = zx_shape_15, .type_only = zx_shape_1, }, };

const zx_shape_36 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .paths = zx_shape_31, .slot_types = zx_shape_13, .table = zx_shape_15, .valid = zx_shape_1, }, };

const zx_shape_37 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_35, }, };

const zx_shape_38 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_35, .@"1" = zx_shape_1, }, };

pub const input_shape = zx_shape_35;

pub const output_shape = zx_shape_1;

pub const Input = *const (zx_abi).zx_type_35;

pub const Output = bool;

fn function_0(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_11 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_2: {
        const operand_1 = in;

        break :block_2 (if ((operand_1 == @as(u8, 0))) @as((zx_abi).zx_type_11, .Scalar) else (if ((operand_1 == @as(u8, 1))) @as((zx_abi).zx_type_11, .Object) else (if ((operand_1 == @as(u8, 2))) @as((zx_abi).zx_type_11, .Optional) else (if ((operand_1 == @as(u8, 3))) @as((zx_abi).zx_type_11, .List) else (if ((operand_1 == @as(u8, 4))) @as((zx_abi).zx_type_11, .Tuple) else (if ((operand_1 == @as(u8, 5))) @as((zx_abi).zx_type_11, .ErrorSet) else (if ((operand_1 == @as(u8, 6))) @as((zx_abi).zx_type_11, .Task) else (if ((operand_1 == @as(u8, 7))) @as((zx_abi).zx_type_11, .Enumeration) else @as((zx_abi).zx_type_11, .NativeReference)))))))));
    };
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_22) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_17 {
    @setRuntimeSafety(true);

    const value_1: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_2: u64 = (try function_0(allocator, (in).id));
    const value_3: bool = (value_2 >= value_1);
    const value_4: *const (zx_abi).zx_type_15 = (if (value_3) ((in).tables).delta else ((in).tables).base);
    const value_5: u64 = (if (value_3) (value_2 - value_1) else value_2);

    return block_20: {
        const operand_1 = (try function_2(allocator, block_4: {
            const operand_2 = (value_4).kinds;
            const operand_3 = value_5;

            if ((operand_3 >= (operand_2).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_4 (operand_2)[@intCast(operand_3)];
        }));
        const operand_5 = block_8: {
            const operand_6 = (value_4).first;
            const operand_7 = value_5;

            if ((operand_7 >= (operand_6).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_8 (operand_6)[@intCast(operand_7)];
        };
        const operand_9 = block_12: {
            const operand_10 = (value_4).second;
            const operand_11 = value_5;

            if ((operand_11 >= (operand_10).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_12 (operand_10)[@intCast(operand_11)];
        };
        const operand_13 = block_16: {
            const operand_14 = (value_4).labels;
            const operand_15 = value_5;

            if ((operand_15 >= (operand_14).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_16 (operand_14)[@intCast(operand_15)];
        };
        const operand_17 = value_3;

        break :block_20 block_19: {
            const operand_18 = (try (allocator).create((zx_abi).zx_type_17));

            (operand_18).* = @as((zx_abi).zx_type_17, (zx_abi).zx_type_17{ .kind = operand_1, .first = operand_5, .second = operand_9, .label = operand_13, .delta = operand_17, });

            break :block_19 @as(*const (zx_abi).zx_type_17, operand_18);
        };
    };
}

fn function_3_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_22_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce {
    @setRuntimeSafety(true);

    const value_1: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_2: u64 = block_58: {
        const operand_57 = (in).id;

        break :block_58 (try function_0(allocator, operand_57));
    };
    const value_3: bool = (block_55: {
        break :block_55 value_2;
    } >= block_56: {
        break :block_56 value_1;
    });
    const value_4: (zx_abi).zx_type_15 = (if (block_54: {
        break :block_54 value_3;
    }) (((in).tables).delta).* else (((in).tables).base).*);
    const value_5: u64 = (if (block_50: {
        break :block_50 value_3;
    }) (block_51: {
        break :block_51 value_2;
    } - block_52: {
        break :block_52 value_1;
    }) else block_53: {
        break :block_53 value_2;
    });

    return block_49: {
        const operand_21 = block_28: {
            const operand_27 = block_26: {
                const operand_24 = (block_22: {
                    break :block_22 (&value_4);
                }).kinds;
                const operand_25 = block_23: {
                    break :block_23 value_5;
                };

                if ((operand_25 >= (operand_24).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_26 (operand_24)[@intCast(operand_25)];
            };

            break :block_28 (try function_2(allocator, operand_27));
        };
        const operand_29 = block_34: {
            const operand_32 = (block_30: {
                break :block_30 (&value_4);
            }).first;
            const operand_33 = block_31: {
                break :block_31 value_5;
            };

            if ((operand_33 >= (operand_32).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_34 (operand_32)[@intCast(operand_33)];
        };
        const operand_35 = block_40: {
            const operand_38 = (block_36: {
                break :block_36 (&value_4);
            }).second;
            const operand_39 = block_37: {
                break :block_37 value_5;
            };

            if ((operand_39 >= (operand_38).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_40 (operand_38)[@intCast(operand_39)];
        };
        const operand_41 = block_46: {
            const operand_44 = (block_42: {
                break :block_42 (&value_4);
            }).labels;
            const operand_45 = block_43: {
                break :block_43 value_5;
            };

            if ((operand_45 >= (operand_44).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_46 (operand_44)[@intCast(operand_45)];
        };
        const operand_47 = block_48: {
            break :block_48 value_3;
        };

        break :block_49 @as((zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .kind = operand_21, .first = operand_29, .second = operand_35, .label = operand_41, .delta = operand_47, });
    };
}

fn function_4(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_24) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_17 = block_32: {
        const operand_26 = (in).tables;
        const operand_27 = (try function_1(allocator, (in).index));
        const operand_28 = (zx_abi).zx_type_22{ .tables = operand_26, .id = operand_27, };
        const operand_29 = (&operand_28);
        const operand_30 = (try function_3_value(allocator, (zx_abi).value_zx_type_22_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec{ .id = (operand_29).id, .tables = (zx_abi).value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .base = ((operand_29).tables).base, .delta = ((operand_29).tables).delta, .zx_origin = (operand_29).tables, }, .zx_origin = operand_29, }));

        break :block_32 (if (((operand_30).zx_origin != null)) ((operand_30).zx_origin.?).* else block_31: {
            break :block_31 (zx_abi).zx_type_17{ .delta = (operand_30).delta, .first = (operand_30).first, .kind = (operand_30).kind, .label = (operand_30).label, .second = (operand_30).second, };
        });
    };
    const value_2: (zx_abi).zx_type_11 = ((&value_1)).kind;
    const value_3: (zx_abi).zx_type_11 = (if ((in).native_references) @as((zx_abi).zx_type_11, .NativeReference) else @as((zx_abi).zx_type_11, .List));

    if ((value_2 == value_3)) {
        return true;
    }

    if (((value_2 == @as((zx_abi).zx_type_11, .Optional)) or ((in).native_references and ((value_2 == @as((zx_abi).zx_type_11, .List)) or (value_2 == @as((zx_abi).zx_type_11, .Task)))))) {
        return block_25: {
            const operand_23 = (in).flags;
            const operand_24 = (try function_0(allocator, ((&value_1)).first));

            if ((operand_24 >= (operand_23).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_25 (operand_23)[@intCast(operand_24)];
        };
    }

    if (((value_2 != @as((zx_abi).zx_type_11, .Tuple)) and (value_2 != @as((zx_abi).zx_type_11, .Object)))) {
        return false;
    }

    const value_4: (zx_abi).zx_type_15 = (if (((&value_1)).delta) (((in).tables).delta).* else (((in).tables).base).*);
    const value_5: []const u32 = (if ((value_2 == @as((zx_abi).zx_type_11, .Tuple))) ((&value_4)).children else ((&value_4)).field_types);

    return block_22: {
        const operand_9 = block_8: {
            const operand_2 = (in).flags;
            const operand_3 = value_5;
            const operand_4 = (try function_0(allocator, ((&value_1)).first));
            const operand_5 = (try function_0(allocator, ((&value_1)).second));
            const operand_6 = @as(u64, 0);
            const operand_7 = false;

            break :block_8 (zx_abi).zx_type_25{ .flags = operand_2, .children = operand_3, .offset = operand_4, .count = operand_5, .index = operand_6, .found = operand_7, };
        };

        var state_1: (zx_abi).value_zx_type_25_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (zx_abi).value_zx_type_25_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .children = (operand_9).children, .count = (operand_9).count, .flags = (operand_9).flags, .found = (operand_9).found, .index = (operand_9).index, .offset = (operand_9).offset, .zx_origin = (&operand_9), };

        while (((!(state_1).found) and ((state_1).index < (state_1).count))) {
            state_1 = block_21: {
                const value_8: (zx_abi).value_zx_type_25_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = state_1;
                const value_9: (zx_abi).value_zx_type_25_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_20: {
                    break :block_20 @as((zx_abi).value_zx_type_25_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_25_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .children = (value_8).children, .count = (value_8).count, .flags = (value_8).flags, .found = block_19: {
                        const operand_17 = (state_1).flags;
                        const operand_18 = block_16: {
                            const operand_15 = block_14: {
                                const operand_12 = (state_1).children;
                                const operand_13 = ((state_1).offset + (state_1).index);

                                if ((operand_13 >= (operand_12).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_14 (operand_12)[@intCast(operand_13)];
                            };

                            break :block_16 (try function_0(allocator, operand_15));
                        };

                        if ((operand_18 >= (operand_17).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_19 (operand_17)[@intCast(operand_18)];
                    }, .index = (value_8).index, .offset = (value_8).offset, });
                };
                const value_10: (zx_abi).value_zx_type_25_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = value_9;
                const value_11: u64 = (value_10).index;
                const value_12: (zx_abi).value_zx_type_25_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_11: {
                    break :block_11 @as((zx_abi).value_zx_type_25_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_25_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .children = (value_10).children, .count = (value_10).count, .flags = (value_10).flags, .found = (value_10).found, .index = (block_10: {
                        break :block_10 value_11;
                    } + @as(u64, 1)), .offset = (value_10).offset, });
                };

                break :block_21 value_12;
            };
        }

        break :block_22 (state_1).found;
    };
}

fn function_5(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_26) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_0(allocator, (in).id));
    const value_2: (zx_abi).zx_type_11 = (if ((in).native_references) @as((zx_abi).zx_type_11, .NativeReference) else @as((zx_abi).zx_type_11, .List));

    if (((block_64: {
        const operand_58 = (in).tables;
        const operand_59 = (in).id;
        const operand_60 = (zx_abi).zx_type_22{ .tables = operand_58, .id = operand_59, };
        const operand_61 = (&operand_60);
        const operand_62 = (try function_3_value(allocator, (zx_abi).value_zx_type_22_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec{ .id = (operand_61).id, .tables = (zx_abi).value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .base = ((operand_61).tables).base, .delta = ((operand_61).tables).delta, .zx_origin = (operand_61).tables, }, .zx_origin = operand_61, }));

        break :block_64 (if (((operand_62).zx_origin != null)) ((operand_62).zx_origin.?).* else block_63: {
            break :block_63 (zx_abi).zx_type_17{ .delta = (operand_62).delta, .first = (operand_62).first, .kind = (operand_62).kind, .label = (operand_62).label, .second = (operand_62).second, };
        });
    }).kind == value_2)) {
        return true;
    }

    const value_10: (zx_abi).zx_type_27 = block_57: {
        const operand_42 = block_41: {
            const operand_36 = (in).tables;
            const operand_37 = value_1;
            const operand_38 = value_2;
            const operand_39 = @as(u64, 0);
            const operand_40 = false;

            break :block_41 (zx_abi).zx_type_27{ .tables = operand_36, .limit = operand_37, .target = operand_38, .index = operand_39, .found = operand_40, };
        };

        var state_35: (zx_abi).value_zx_type_27_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = (zx_abi).value_zx_type_27_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc{ .found = (operand_42).found, .index = (operand_42).index, .limit = (operand_42).limit, .tables = (zx_abi).value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .base = ((operand_42).tables).base, .delta = ((operand_42).tables).delta, .zx_origin = (operand_42).tables, }, .target = (operand_42).target, .zx_origin = (&operand_42), };

        while (((!(state_35).found) and ((state_35).index < (state_35).limit))) {
            state_35 = block_52: {
                const value_5: (zx_abi).value_zx_type_27_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = state_35;
                const value_6: (zx_abi).value_zx_type_27_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = block_51: {
                    break :block_51 @as((zx_abi).value_zx_type_27_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc, (zx_abi).value_zx_type_27_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc{ .found = ((block_50: {
                        break :block_50 (try function_3_value(allocator, block_49: {
                            const operand_45 = (state_35).tables;
                            const operand_46 = block_48: {
                                const operand_47 = (state_35).index;

                                break :block_48 (try function_1(allocator, operand_47));
                            };

                            break :block_49 @as((zx_abi).value_zx_type_22_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec, (zx_abi).value_zx_type_22_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec{ .tables = operand_45, .id = operand_46, });
                        }));
                    }).kind == (state_35).target), .index = (value_5).index, .limit = (value_5).limit, .tables = (value_5).tables, .target = (value_5).target, });
                };
                const value_7: (zx_abi).value_zx_type_27_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = value_6;
                const value_8: u64 = (value_7).index;
                const value_9: (zx_abi).value_zx_type_27_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = block_44: {
                    break :block_44 @as((zx_abi).value_zx_type_27_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc, (zx_abi).value_zx_type_27_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc{ .found = (value_7).found, .index = (block_43: {
                        break :block_43 value_8;
                    } + @as(u64, 1)), .limit = (value_7).limit, .tables = (value_7).tables, .target = (value_7).target, });
                };

                break :block_52 value_9;
            };
        }

        break :block_57 block_56: {
            break :block_56 (if (((state_35).zx_origin != null)) ((state_35).zx_origin.?).* else block_55: {
                break :block_55 (zx_abi).zx_type_27{ .found = (state_35).found, .index = (state_35).index, .limit = (state_35).limit, .tables = (if ((((state_35).tables).zx_origin != null)) ((state_35).tables).zx_origin.? else block_54: {
                    const operand_53 = (try (allocator).create((zx_abi).zx_type_16));

                    (operand_53).* = (zx_abi).zx_type_16{ .base = ((state_35).tables).base, .delta = ((state_35).tables).delta, };

                    break :block_54 @as(*const (zx_abi).zx_type_16, operand_53);
                }), .target = (state_35).target, };
            });
        };
    };

    if ((!((&value_10)).found)) {
        return false;
    }

    const value_11: []const bool = @as([]const bool, (comptime (&[_]bool{})));

    return block_34: {
        const operand_9 = block_8: {
            const operand_2 = (in).tables;
            const operand_3 = @as(u64, 0);
            const operand_4 = (((&value_10)).index - @as(u64, 1));
            const operand_5 = (value_1 + @as(u64, 1));
            const operand_6 = value_11;
            const operand_7 = (in).native_references;

            break :block_8 (zx_abi).zx_type_28{ .tables = operand_2, .index = operand_3, .first = operand_4, .limit = operand_5, .flags = operand_6, .native_references = operand_7, };
        };

        var state_capacity_10: (std).ArrayList(bool) = .empty;

        var state_capacity_started_11 = false;

        defer (state_capacity_10).deinit(allocator);

        var state_1: (zx_abi).value_zx_type_28_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = (zx_abi).value_zx_type_28_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e{ .first = (operand_9).first, .flags = (operand_9).flags, .index = (operand_9).index, .limit = (operand_9).limit, .native_references = (operand_9).native_references, .tables = (zx_abi).value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .base = ((operand_9).tables).base, .delta = ((operand_9).tables).delta, .zx_origin = (operand_9).tables, }, .zx_origin = (&operand_9), };

        while (((state_1).index < (state_1).limit)) {
            state_1 = block_29: {
                const value_14: bool = (((state_1).index >= (state_1).first) and block_28: {
                    const operand_19 = (state_1).tables;

                    var state_borrow_20: (zx_abi).zx_type_16 = undefined;

                    state_borrow_20 = (zx_abi).zx_type_16{ .base = (operand_19).base, .delta = (operand_19).delta, };

                    const operand_21 = ((operand_19).zx_origin orelse (&state_borrow_20));
                    const operand_22 = (state_1).index;
                    const operand_23 = (state_1).flags;
                    const operand_24 = (state_1).native_references;
                    const operand_25 = (zx_abi).value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .base = (operand_21).base, .delta = (operand_21).delta, .zx_origin = operand_21, };

                    var state_borrow_26: (zx_abi).zx_type_16 = undefined;

                    state_borrow_26 = (zx_abi).zx_type_16{ .base = (operand_25).base, .delta = (operand_25).delta, };

                    const operand_27 = (zx_abi).zx_type_24{ .tables = ((operand_25).zx_origin orelse (&state_borrow_26)), .index = operand_22, .flags = operand_23, .native_references = operand_24, };

                    break :block_28 (try function_4(allocator, (&operand_27)));
                });
                const value_15: (zx_abi).value_zx_type_28_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = state_1;
                const value_16: (zx_abi).value_zx_type_28_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = block_18: {
                    break :block_18 @as((zx_abi).value_zx_type_28_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e, (zx_abi).value_zx_type_28_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e{ .first = (value_15).first, .flags = (block_17: {
                        const operand_14 = (state_1).flags;
                        const operand_16 = block_15: {
                            break :block_15 value_14;
                        };

                        _ = (try ((std).math).add(usize, (operand_14).len, 1));

                        if ((!state_capacity_started_11)) {
                            (try (state_capacity_10).appendSlice(allocator, operand_14));

                            state_capacity_started_11 = true;
                        } else {
                            ((state_capacity_10).items).len = (operand_14).len;
                        }

                        (try (state_capacity_10).append(allocator, operand_16));

                        break :block_17 @as((zx_abi).value_zx_type_29_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_10).items, {}, null, });
                    }).@"0", .index = (value_15).index, .limit = (value_15).limit, .native_references = (value_15).native_references, .tables = (value_15).tables, });
                };
                const value_17: (zx_abi).value_zx_type_28_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = value_16;
                const value_18: u64 = (value_17).index;
                const value_19: (zx_abi).value_zx_type_28_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = block_13: {
                    break :block_13 @as((zx_abi).value_zx_type_28_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e, (zx_abi).value_zx_type_28_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e{ .first = (value_17).first, .flags = (value_17).flags, .index = (block_12: {
                        break :block_12 value_18;
                    } + @as(u64, 1)), .limit = (value_17).limit, .native_references = (value_17).native_references, .tables = (value_17).tables, });
                };

                break :block_29 value_19;
            };
        }

        break :block_34 block_33: {
            const operand_31 = (state_1).flags;
            const operand_32 = block_30: {
                break :block_30 value_1;
            };

            if ((operand_32 >= (operand_31).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_33 (operand_31)[@intCast(operand_32)];
        };
    };
}

fn function_6(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_30) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_15 = block_17: {
        const operand_9 = @as([]const u8, (comptime (&[_]u8{})));
        const operand_10 = @as([]const u32, (comptime (&[_]u32{})));
        const operand_11 = @as([]const u32, (comptime (&[_]u32{})));
        const operand_12 = @as([]const []const u8, (comptime (&[_][]const u8{})));
        const operand_13 = @as([]const u32, (comptime (&[_]u32{})));
        const operand_14 = @as([]const u32, (comptime (&[_]u32{})));
        const operand_15 = @as([]const []const u8, (comptime (&[_][]const u8{})));
        const operand_16 = @as([]const []const u8, (comptime (&[_][]const u8{})));

        break :block_17 (zx_abi).zx_type_15{ .kinds = operand_9, .first = operand_10, .second = operand_11, .labels = operand_12, .children = operand_13, .field_types = operand_14, .field_names = operand_15, .names = operand_16, };
    };

    return block_8: {
        const operand_1 = (in).table;
        const operand_2 = (&value_1);
        const operand_3 = (zx_abi).zx_type_16{ .base = operand_1, .delta = operand_2, };
        const operand_4 = (&operand_3);
        const operand_5 = (in).id;
        const operand_6 = (in).native_references;
        const operand_7 = (zx_abi).zx_type_26{ .tables = operand_4, .id = operand_5, .native_references = operand_6, };

        break :block_8 (try function_5(allocator, (&operand_7)));
    };
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_32) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: []const u8 = block_61: {
        const operand_59 = (in).paths;
        const operand_60 = (in).index;

        if ((operand_60 >= (operand_59).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_61 (operand_59)[@intCast(operand_60)];
    };

    if ((((((((@as(u64, (value_1).len) < @as(u64, 6)) or (block_43: {
        const operand_41 = value_1;
        const operand_42 = @as(u64, 0);

        if ((operand_42 >= (operand_41).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_43 (operand_41)[@intCast(operand_42)];
    } != @as(u8, 115))) or (block_46: {
        const operand_44 = value_1;
        const operand_45 = @as(u64, 1);

        if ((operand_45 >= (operand_44).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_46 (operand_44)[@intCast(operand_45)];
    } != @as(u8, 116))) or (block_49: {
        const operand_47 = value_1;
        const operand_48 = @as(u64, 2);

        if ((operand_48 >= (operand_47).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_49 (operand_47)[@intCast(operand_48)];
    } != @as(u8, 111))) or (block_52: {
        const operand_50 = value_1;
        const operand_51 = @as(u64, 3);

        if ((operand_51 >= (operand_50).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_52 (operand_50)[@intCast(operand_51)];
    } != @as(u8, 114))) or (block_55: {
        const operand_53 = value_1;
        const operand_54 = @as(u64, 4);

        if ((operand_54 >= (operand_53).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_55 (operand_53)[@intCast(operand_54)];
    } != @as(u8, 101))) or (block_58: {
        const operand_56 = value_1;
        const operand_57 = @as(u64, 5);

        if ((operand_57 >= (operand_56).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_58 (operand_56)[@intCast(operand_57)];
    } != @as(u8, 46)))) {
        return false;
    }

    const value_18: (zx_abi).zx_type_33 = block_40: {
        const operand_8 = block_7: {
            const operand_2 = (in).paths;
            const operand_3 = value_1;
            const operand_4 = (in).index;
            const operand_5 = @as(u64, 0);
            const operand_6 = false;

            break :block_7 (zx_abi).zx_type_33{ .paths = operand_2, .path = operand_3, .limit = operand_4, .index = operand_5, .repeated = operand_6, };
        };

        var state_1: (zx_abi).value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = (zx_abi).value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .index = (operand_8).index, .limit = (operand_8).limit, .path = (operand_8).path, .paths = (operand_8).paths, .repeated = (operand_8).repeated, .zx_origin = (&operand_8), };

        while ((((state_1).index < (state_1).limit) and (!(state_1).repeated))) {
            state_1 = block_37: {
                const value_4: []const u8 = block_36: {
                    const operand_34 = (state_1).paths;
                    const operand_35 = (state_1).index;

                    if ((operand_35 >= (operand_34).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_36 (operand_34)[@intCast(operand_35)];
                };
                const value_12: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_33: {
                    const operand_20 = block_19: {
                        const operand_13 = (state_1).path;
                        const operand_14 = block_15: {
                            break :block_15 value_4;
                        };
                        const operand_16 = @as(u64, 0);
                        const operand_17 = (@as(u64, ((state_1).path).len) == @as(u64, (block_18: {
                            break :block_18 value_4;
                        }).len));

                        break :block_19 @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .left = operand_13, .right = operand_14, .index = operand_16, .equal = operand_17, });
                    };

                    var state_12: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = operand_20;

                    var state_changed_21 = false;

                    while (((state_12).equal and ((state_12).index < @as(u64, ((state_12).left).len)))) {
                        state_12 = block_31: {
                            const value_7: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = state_12;
                            const value_8: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_30: {
                                break :block_30 @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .equal = (block_26: {
                                    const operand_24 = (state_12).left;
                                    const operand_25 = (state_12).index;

                                    if ((operand_25 >= (operand_24).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_26 (operand_24)[@intCast(operand_25)];
                                } == block_29: {
                                    const operand_27 = (state_12).right;
                                    const operand_28 = (state_12).index;

                                    if ((operand_28 >= (operand_27).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_29 (operand_27)[@intCast(operand_28)];
                                }), .index = (value_7).index, .left = (value_7).left, .right = (value_7).right, });
                            };
                            const value_9: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = value_8;
                            const value_10: u64 = (value_9).index;
                            const value_11: (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_23: {
                                break :block_23 @as((zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_34_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .equal = (value_9).equal, .index = (block_22: {
                                    break :block_22 value_10;
                                } + @as(u64, 1)), .left = (value_9).left, .right = (value_9).right, });
                            };

                            break :block_31 value_11;
                        };

                        state_changed_21 = true;
                    }

                    break :block_33 (if (state_changed_21) state_12 else operand_20);
                };
                const value_13: (zx_abi).value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = state_1;
                const value_14: (zx_abi).value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_11: {
                    break :block_11 @as((zx_abi).value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .index = (value_13).index, .limit = (value_13).limit, .path = (value_13).path, .paths = (value_13).paths, .repeated = (value_12).equal, });
                };
                const value_15: (zx_abi).value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = value_14;
                const value_16: u64 = (value_15).index;
                const value_17: (zx_abi).value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_10: {
                    break :block_10 @as((zx_abi).value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_33_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .index = (block_9: {
                        break :block_9 value_16;
                    } + @as(u64, 1)), .limit = (value_15).limit, .path = (value_15).path, .paths = (value_15).paths, .repeated = (value_15).repeated, });
                };

                break :block_37 value_17;
            };
        }

        break :block_40 block_39: {
            break :block_39 (if (((state_1).zx_origin != null)) ((state_1).zx_origin.?).* else block_38: {
                break :block_38 (zx_abi).zx_type_33{ .index = (state_1).index, .limit = (state_1).limit, .path = (state_1).path, .paths = (state_1).paths, .repeated = (state_1).repeated, };
            });
        };
    };

    return (!((&value_18)).repeated);
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_35) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    if (((@as(u64, ((in).paths).len) != @as(u64, ((in).slot_types).len)) or ((in).type_only and (@as(u64, ((in).paths).len) != @as(u64, 0))))) {
        return false;
    }

    return block_36: {
        const operand_8 = block_7: {
            const operand_2 = (in).table;
            const operand_3 = (in).paths;
            const operand_4 = (in).slot_types;
            const operand_5 = @as(u64, 0);
            const operand_6 = true;

            break :block_7 (zx_abi).zx_type_36{ .table = operand_2, .paths = operand_3, .slot_types = operand_4, .index = operand_5, .valid = operand_6, };
        };

        var state_1: (zx_abi).value_zx_type_36_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = (zx_abi).value_zx_type_36_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .index = (operand_8).index, .paths = (operand_8).paths, .slot_types = (operand_8).slot_types, .table = (operand_8).table, .valid = (operand_8).valid, .zx_origin = (&operand_8), };

        while (((state_1).valid and ((state_1).index < @as(u64, ((state_1).paths).len)))) {
            state_1 = block_35: {
                const value_3: u32 = block_34: {
                    const operand_32 = (state_1).slot_types;
                    const operand_33 = (state_1).index;

                    if ((operand_33 >= (operand_32).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_34 (operand_32)[@intCast(operand_33)];
                };
                const value_4: u64 = block_31: {
                    const operand_30 = block_29: {
                        break :block_29 value_3;
                    };

                    break :block_31 (try function_0(allocator, operand_30));
                };
                const value_5: (zx_abi).value_zx_type_36_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = state_1;
                const value_6: (zx_abi).value_zx_type_36_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_28: {
                    break :block_28 @as((zx_abi).value_zx_type_36_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_36_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .index = (value_5).index, .paths = (value_5).paths, .slot_types = (value_5).slot_types, .table = (value_5).table, .valid = ((((block_11: {
                        break :block_11 value_4;
                    } < @as(u64, (((state_1).table).kinds).len)) and (block_17: {
                        const operand_16 = block_15: {
                            const operand_13 = ((state_1).table).kinds;
                            const operand_14 = block_12: {
                                break :block_12 value_4;
                            };

                            if ((operand_14 >= (operand_13).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_15 (operand_13)[@intCast(operand_14)];
                        };

                        break :block_17 (try function_2(allocator, operand_16));
                    } == @as((zx_abi).zx_type_11, .Object))) and block_21: {
                        const operand_18 = (state_1).paths;
                        const operand_19 = (state_1).index;
                        const operand_20 = (zx_abi).zx_type_32{ .paths = operand_18, .index = operand_19, };

                        break :block_21 (try function_7(allocator, (&operand_20)));
                    }) and (!block_27: {
                        const operand_22 = (state_1).table;
                        const operand_24 = block_23: {
                            break :block_23 value_3;
                        };
                        const operand_25 = true;
                        const operand_26 = (zx_abi).zx_type_30{ .table = operand_22, .id = operand_24, .native_references = operand_25, };

                        break :block_27 (try function_6(allocator, (&operand_26)));
                    })), });
                };
                const value_7: (zx_abi).value_zx_type_36_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = value_6;
                const value_8: u64 = (value_7).index;
                const value_9: (zx_abi).value_zx_type_36_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_10: {
                    break :block_10 @as((zx_abi).value_zx_type_36_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_36_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .index = (block_9: {
                        break :block_9 value_8;
                    } + @as(u64, 1)), .paths = (value_7).paths, .slot_types = (value_7).slot_types, .table = (value_7).table, .valid = (value_7).valid, });
                };

                break :block_35 value_9;
            };
        }

        break :block_36 (state_1).valid;
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_35) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = (try function_8(allocator, in));

    return value_1;
}

