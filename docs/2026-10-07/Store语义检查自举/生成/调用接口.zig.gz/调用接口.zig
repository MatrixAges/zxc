pub const zx_type_14 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_15 = struct {
    available: *const zx_type_14,
    orchestration: bool,
    required: *const zx_type_14,
    slots: []const u32,
};

pub const zx_type_16 = struct {
    available: *const zx_type_14,
    index: u64,
    required: *const zx_type_14,
    slots: []const u32,
    valid: bool,
};

pub const zx_type_17 = struct {
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
};

pub const zx_type_18 = struct { *const zx_type_15, };

pub const zx_type_19 = struct { *const zx_type_15, bool, };

pub const value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    available: *const zx_type_14,
    orchestration: bool,
    required: *const zx_type_14,
    slots: []const u32,
    zx_origin: ?*const zx_type_15 = null,
};

pub const value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    available: *const zx_type_14,
    index: u64,
    required: *const zx_type_14,
    slots: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_009b209c29dfed37d6f0ddf10651eb819801430299ea03fd6bf9a11471606d6e = struct { value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, ?*const zx_type_18, };

pub const value_zx_type_19_9068dcb27588fc549cd15008d3bd15e507480c6631115fd15614e1d02077b29f = struct { value_zx_type_15_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, bool, ?*const zx_type_19, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
};

