const std = @import("std");

const zx_native_0 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .handles = zx_shape_11, .paths = zx_shape_11, .readable = zx_shape_13, .types = zx_shape_12, .writable = zx_shape_13, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .available = zx_shape_14, .orchestration = zx_shape_1, .required = zx_shape_14, .slots = zx_shape_12, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .available = zx_shape_14, .index = zx_shape_5, .required = zx_shape_14, .slots = zx_shape_12, .valid = zx_shape_1, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .id = zx_shape_4, .index = zx_shape_5, .limit = zx_shape_5, .slots = zx_shape_12, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_15, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_15, .@"1" = zx_shape_1, }, };

pub const input_shape = zx_shape_15;

pub const output_shape = zx_shape_1;

pub const Input = *const (zx_abi).zx_type_15;

pub const Output = bool;

fn function_0(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_14) error{ }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: u64 = @as(u64, ((in).paths).len);

    return (((((value_1 <= @as(u64, 4294967295)) and (@as(u64, ((in).types).len) == value_1)) and (@as(u64, ((in).handles).len) == value_1)) and (@as(u64, ((in).readable).len) == value_1)) and (@as(u64, ((in).writable).len) == value_1));
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_15) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if (((((!(try function_2(allocator, (in).available))) or (!(try function_2(allocator, (in).required)))) or (@as(u64, ((in).slots).len) != @as(u64, (((in).required).paths).len))) or ((@as(u64, ((in).slots).len) != @as(u64, 0)) and (!(in).orchestration)))) {
        return false;
    }

    return block_73: {
        const operand_8 = block_7: {
            const operand_2 = (in).available;
            const operand_3 = (in).required;
            const operand_4 = (in).slots;
            const operand_5 = @as(u64, 0);
            const operand_6 = true;

            break :block_7 (zx_abi).zx_type_16{ .available = operand_2, .required = operand_3, .slots = operand_4, .index = operand_5, .valid = operand_6, };
        };

        var state_1: (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .available = (operand_8).available, .index = (operand_8).index, .required = (operand_8).required, .slots = (operand_8).slots, .valid = (operand_8).valid, .zx_origin = (&operand_8), };

        while (((state_1).valid and ((state_1).index < @as(u64, ((state_1).slots).len)))) {
            state_1 = block_72: {
                const value_3: u32 = block_71: {
                    const operand_69 = (state_1).slots;
                    const operand_70 = (state_1).index;

                    if ((operand_70 >= (operand_69).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_71 (operand_69)[@intCast(operand_70)];
                };
                const value_4: u64 = block_68: {
                    const operand_67 = block_66: {
                        break :block_66 value_3;
                    };

                    break :block_68 (try function_0(allocator, operand_67));
                };
                const value_17: (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = (if ((block_11: {
                    break :block_11 value_4;
                } >= @as(u64, (((state_1).available).paths).len))) block_13: {
                    const value_5: (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = state_1;
                    const value_6: (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_12: {
                        break :block_12 @as((zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .available = (value_5).available, .index = (value_5).index, .required = (value_5).required, .slots = (value_5).slots, .valid = false, });
                    };

                    break :block_13 value_6;
                } else block_65: {
                    const value_14: (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_64: {
                        const operand_54 = block_53: {
                            const operand_47 = (state_1).slots;
                            const operand_48 = (state_1).index;
                            const operand_49 = @as(u64, 0);
                            const operand_50 = block_51: {
                                break :block_51 value_3;
                            };
                            const operand_52 = false;

                            break :block_53 @as((zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .slots = operand_47, .limit = operand_48, .index = operand_49, .id = operand_50, .found = operand_52, });
                        };

                        var state_46: (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = operand_54;

                        var state_changed_55 = false;

                        while ((((state_46).index < (state_46).limit) and (!(state_46).found))) {
                            state_46 = block_62: {
                                const value_9: (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = state_46;
                                const value_10: (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_61: {
                                    break :block_61 @as((zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .found = (block_60: {
                                        const operand_58 = (state_46).slots;
                                        const operand_59 = (state_46).index;

                                        if ((operand_59 >= (operand_58).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_60 (operand_58)[@intCast(operand_59)];
                                    } == (state_46).id), .id = (value_9).id, .index = (value_9).index, .limit = (value_9).limit, .slots = (value_9).slots, });
                                };
                                const value_11: (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = value_10;
                                const value_12: u64 = (value_11).index;
                                const value_13: (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_57: {
                                    break :block_57 @as((zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .found = (value_11).found, .id = (value_11).id, .index = (block_56: {
                                        break :block_56 value_12;
                                    } + @as(u64, 1)), .limit = (value_11).limit, .slots = (value_11).slots, });
                                };

                                break :block_62 value_13;
                            };

                            state_changed_55 = true;
                        }

                        break :block_64 (if (state_changed_55) state_46 else operand_54);
                    };
                    const value_15: (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = state_1;
                    const value_16: (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_45: {
                        break :block_45 @as((zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .available = (value_15).available, .index = (value_15).index, .required = (value_15).required, .slots = (value_15).slots, .valid = (((((!(value_14).found) and (block_17: {
                            const operand_15 = ((state_1).available).types;
                            const operand_16 = block_14: {
                                break :block_14 value_4;
                            };

                            if ((operand_16 >= (operand_15).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_17 (operand_15)[@intCast(operand_16)];
                        } == block_20: {
                            const operand_18 = ((state_1).required).types;
                            const operand_19 = (state_1).index;

                            if ((operand_19 >= (operand_18).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_20 (operand_18)[@intCast(operand_19)];
                        })) and block_30: {
                            const operand_28 = block_24: {
                                const operand_22 = ((state_1).available).paths;
                                const operand_23 = block_21: {
                                    break :block_21 value_4;
                                };

                                if ((operand_23 >= (operand_22).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_24 (operand_22)[@intCast(operand_23)];
                            };
                            const operand_29 = block_27: {
                                const operand_25 = ((state_1).required).paths;
                                const operand_26 = (state_1).index;

                                if ((operand_26 >= (operand_25).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_27 (operand_25)[@intCast(operand_26)];
                            };

                            break :block_30 ((std).mem).eql(u8, operand_28, operand_29);
                        }) and ((!block_33: {
                            const operand_31 = ((state_1).required).readable;
                            const operand_32 = (state_1).index;

                            if ((operand_32 >= (operand_31).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_33 (operand_31)[@intCast(operand_32)];
                        }) or block_37: {
                            const operand_35 = ((state_1).available).readable;
                            const operand_36 = block_34: {
                                break :block_34 value_4;
                            };

                            if ((operand_36 >= (operand_35).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_37 (operand_35)[@intCast(operand_36)];
                        })) and ((!block_40: {
                            const operand_38 = ((state_1).required).writable;
                            const operand_39 = (state_1).index;

                            if ((operand_39 >= (operand_38).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_40 (operand_38)[@intCast(operand_39)];
                        }) or block_44: {
                            const operand_42 = ((state_1).available).writable;
                            const operand_43 = block_41: {
                                break :block_41 value_4;
                            };

                            if ((operand_43 >= (operand_42).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_44 (operand_42)[@intCast(operand_43)];
                        })), });
                    };

                    break :block_65 value_16;
                });
                const value_18: (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = value_17;
                const value_19: u64 = (value_18).index;
                const value_20: (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_10: {
                    break :block_10 @as((zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_16_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .available = (value_18).available, .index = (block_9: {
                        break :block_9 value_19;
                    } + @as(u64, 1)), .required = (value_18).required, .slots = (value_18).slots, .valid = (value_18).valid, });
                };

                break :block_72 value_20;
            };
        }

        break :block_73 (state_1).valid;
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_15) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = (try function_3(allocator, in));

    return value_1;
}

