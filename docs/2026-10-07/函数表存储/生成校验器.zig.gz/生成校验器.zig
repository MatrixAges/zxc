const std = @import("std");

const zx_type_11 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

const zx_type_12 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

const zx_type_13 = enum { Map, Filter, Reduce, Every, Some, };

const zx_type_14 = enum { Negate, Not, };

const zx_type_15 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

const zx_type_16 = enum { Copy, Borrowed, Owned, };

const zx_type_17 = enum { Evaluate, Constant, Parallel, Destructure, Branch, Switch, StoreSet, Result, };

const zx_type_23 = struct {
    block_count: []const u32,
    block_first: []const u32,
    branch_conditions: []const u32,
    branch_no: []const u32,
    branch_yes: []const u32,
    case_bodies: []const u32,
    case_values: []const ?u32,
    constant_symbols: []const u32,
    constant_values: []const u32,
    destructure_count: []const u32,
    destructure_first: []const u32,
    destructure_symbols: []const ?u32,
    destructure_values: []const u32,
    evaluations: []const u32,
    parallel_count: []const u32,
    parallel_first: []const u32,
    parallel_symbols: []const ?u32,
    parallel_values: []const u32,
    results: []const ?u32,
    selection_count: []const u32,
    selection_exhaustive: []const bool,
    selection_first: []const u32,
    selection_subjects: []const u32,
    setter_slots: []const u32,
    setter_values: []const u32,
    statement_kinds: []const zx_type_17,
    statement_payloads: []const u32,
};

const zx_type_32 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_15,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_12,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_11,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_13,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_14,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

const zx_type_33 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

const zx_type_35 = struct {
    names: []const []const u8,
    ownership: []const zx_type_16,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

const zx_type_40 = struct {
    control: []const *const zx_type_23,
    expressions: []const *const zx_type_32,
    files: []const []const u8,
    input_types: []const u32,
    output_types: []const u32,
    ownership: []const zx_type_16,
    roots: []const ?u32,
    stores: []const *const zx_type_33,
    symbols: []const *const zx_type_35,
};

const zx_type_41 = struct {
    functions: *const zx_type_40,
};

const zx_type_42 = struct { *const zx_type_41, };

const zx_type_43 = struct { *const zx_type_41, bool, };

const value_zx_type_40_36e32a7d36ecb8b71dbe7e25a4158128c7836c2521d5fee40349f25f49cdbf83 = struct {
    control: []const *const zx_type_23,
    expressions: []const *const zx_type_32,
    files: []const []const u8,
    input_types: []const u32,
    output_types: []const u32,
    ownership: []const zx_type_16,
    roots: []const ?u32,
    stores: []const *const zx_type_33,
    symbols: []const *const zx_type_35,
    zx_origin: ?*const zx_type_40 = null,
};

const value_zx_type_41_550d2e9496ddc556559e8611f04bb3e997619e133dc3af6c951d7263d72910d0 = struct {
    functions: value_zx_type_40_36e32a7d36ecb8b71dbe7e25a4158128c7836c2521d5fee40349f25f49cdbf83,
    zx_origin: ?*const zx_type_41 = null,
};

const value_zx_type_42_e6ab8f9edcc20aebf08249cea08d75f34408f58b332ea607857383eff443177c = struct { value_zx_type_41_550d2e9496ddc556559e8611f04bb3e997619e133dc3af6c951d7263d72910d0, ?*const zx_type_42, };

const value_zx_type_43_ab983f00ae49198092d0b98558de4c6a61b832010074ba813faedd385b47f3d6 = struct { value_zx_type_41_550d2e9496ddc556559e8611f04bb3e997619e133dc3af6c951d7263d72910d0, bool, ?*const zx_type_43, };

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .scalar, };

const zx_shape_13 = .{ .kind = .scalar, };

const zx_shape_14 = .{ .kind = .scalar, };

const zx_shape_15 = .{ .kind = .scalar, };

const zx_shape_16 = .{ .kind = .scalar, };

const zx_shape_17 = .{ .kind = .scalar, };

const zx_shape_18 = .{ .kind = .list, .child = zx_shape_17, };

const zx_shape_19 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_20 = .{ .kind = .optional, .child = zx_shape_4, };

const zx_shape_21 = .{ .kind = .list, .child = zx_shape_20, };

const zx_shape_22 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_23 = .{ .kind = .object, .fields = .{ .block_count = zx_shape_19, .block_first = zx_shape_19, .branch_conditions = zx_shape_19, .branch_no = zx_shape_19, .branch_yes = zx_shape_19, .case_bodies = zx_shape_19, .case_values = zx_shape_21, .constant_symbols = zx_shape_19, .constant_values = zx_shape_19, .destructure_count = zx_shape_19, .destructure_first = zx_shape_19, .destructure_symbols = zx_shape_21, .destructure_values = zx_shape_19, .evaluations = zx_shape_19, .parallel_count = zx_shape_19, .parallel_first = zx_shape_19, .parallel_symbols = zx_shape_21, .parallel_values = zx_shape_19, .results = zx_shape_21, .selection_count = zx_shape_19, .selection_exhaustive = zx_shape_22, .selection_first = zx_shape_19, .selection_subjects = zx_shape_19, .setter_slots = zx_shape_19, .setter_values = zx_shape_19, .statement_kinds = zx_shape_18, .statement_payloads = zx_shape_19, }, };

const zx_shape_24 = .{ .kind = .list, .child = zx_shape_11, };

const zx_shape_25 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_26 = .{ .kind = .list, .child = zx_shape_9, };

const zx_shape_27 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_28 = .{ .kind = .list, .child = zx_shape_12, };

const zx_shape_29 = .{ .kind = .list, .child = zx_shape_13, };

const zx_shape_30 = .{ .kind = .list, .child = zx_shape_14, };

const zx_shape_31 = .{ .kind = .list, .child = zx_shape_15, };

const zx_shape_32 = .{ .kind = .object, .fields = .{ .awaits = zx_shape_19, .binary_left = zx_shape_19, .binary_operators = zx_shape_31, .binary_right = zx_shape_19, .booleans = zx_shape_22, .call_arguments = zx_shape_19, .call_functions = zx_shape_19, .call_store_count = zx_shape_19, .call_store_first = zx_shape_19, .call_stores = zx_shape_19, .cancellations = zx_shape_19, .captures = zx_shape_19, .collection_arguments = zx_shape_19, .collection_count = zx_shape_19, .collection_first = zx_shape_19, .collection_kinds = zx_shape_28, .collection_targets = zx_shape_19, .conditional_conditions = zx_shape_19, .conditional_no = zx_shape_19, .conditional_yes = zx_shape_19, .enumerations = zx_shape_19, .errors = zx_shape_19, .floats = zx_shape_26, .index_targets = zx_shape_19, .index_values = zx_shape_19, .integers = zx_shape_25, .iteration_bodies = zx_shape_19, .iteration_condition_parameters = zx_shape_19, .iteration_conditions = zx_shape_19, .iteration_initials = zx_shape_19, .iteration_parameters = zx_shape_19, .iteration_postconditions = zx_shape_22, .kinds = zx_shape_24, .lengths = zx_shape_19, .match_conditions = zx_shape_19, .match_count = zx_shape_19, .match_fallbacks = zx_shape_19, .match_first = zx_shape_19, .match_results = zx_shape_19, .match_subjects = zx_shape_21, .negative_integers = zx_shape_25, .object_count = zx_shape_19, .object_evaluation_count = zx_shape_19, .object_evaluation_first = zx_shape_19, .object_evaluation_values = zx_shape_19, .object_field_indices = zx_shape_19, .object_field_values = zx_shape_19, .object_first = zx_shape_19, .optional_values = zx_shape_19, .parallel_count = zx_shape_19, .parallel_fields = zx_shape_21, .parallel_first = zx_shape_19, .parallel_tasks = zx_shape_19, .payloads = zx_shape_19, .projection_indices = zx_shape_19, .projection_targets = zx_shape_19, .references = zx_shape_19, .scope_borrows = zx_shape_22, .scope_count = zx_shape_19, .scope_first = zx_shape_19, .scope_results = zx_shape_19, .scope_symbols = zx_shape_21, .scope_values = zx_shape_19, .sequence_count = zx_shape_19, .sequence_first = zx_shape_19, .sequence_items = zx_shape_19, .some = zx_shape_19, .span_end = zx_shape_25, .span_start = zx_shape_25, .stores = zx_shape_19, .strings = zx_shape_27, .task_bodies = zx_shape_19, .task_capture_count = zx_shape_19, .task_capture_first = zx_shape_19, .task_captures = zx_shape_19, .transform_bodies = zx_shape_19, .transform_count = zx_shape_19, .transform_first = zx_shape_19, .transform_initials = zx_shape_21, .transform_kinds = zx_shape_29, .transform_parameters = zx_shape_19, .transform_targets = zx_shape_19, .types = zx_shape_19, .unary_operands = zx_shape_19, .unary_operators = zx_shape_30, .update_indices = zx_shape_19, .update_targets = zx_shape_19, .update_values = zx_shape_19, }, };

const zx_shape_33 = .{ .kind = .object, .fields = .{ .handles = zx_shape_27, .paths = zx_shape_27, .readable = zx_shape_22, .types = zx_shape_19, .writable = zx_shape_22, }, };

const zx_shape_34 = .{ .kind = .list, .child = zx_shape_16, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .names = zx_shape_27, .ownership = zx_shape_34, .span_end = zx_shape_25, .span_start = zx_shape_25, .types = zx_shape_19, }, };

const zx_shape_36 = .{ .kind = .list, .child = zx_shape_35, };

const zx_shape_37 = .{ .kind = .list, .child = zx_shape_32, };

const zx_shape_38 = .{ .kind = .list, .child = zx_shape_23, };

const zx_shape_39 = .{ .kind = .list, .child = zx_shape_33, };

const zx_shape_40 = .{ .kind = .object, .fields = .{ .control = zx_shape_38, .expressions = zx_shape_37, .files = zx_shape_27, .input_types = zx_shape_19, .output_types = zx_shape_19, .ownership = zx_shape_34, .roots = zx_shape_21, .stores = zx_shape_39, .symbols = zx_shape_36, }, };

const zx_shape_41 = .{ .kind = .object, .fields = .{ .functions = zx_shape_40, }, };

const zx_shape_42 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_41, }, };

const zx_shape_43 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_41, .@"1" = zx_shape_1, }, };

pub const input_shape = zx_shape_41;

pub const output_shape = zx_shape_1;

pub const Input = *const zx_type_41;

pub const Output = bool;

fn function_0(allocator: ((std).mem).Allocator, in: *const zx_type_41) error{ }!bool {
    @setRuntimeSafety(true);

    _ = allocator;

    const value_1: u64 = @as(u64, (((in).functions).files).len);

    return (((((((((value_1 <= @as(u64, 4294967295)) and (@as(u64, (((in).functions).input_types).len) == value_1)) and (@as(u64, (((in).functions).output_types).len) == value_1)) and (@as(u64, (((in).functions).ownership).len) == value_1)) and (@as(u64, (((in).functions).roots).len) == value_1)) and (@as(u64, (((in).functions).symbols).len) == value_1)) and (@as(u64, (((in).functions).expressions).len) == value_1)) and (@as(u64, (((in).functions).control).len) == value_1)) and (@as(u64, (((in).functions).stores).len) == value_1));
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const zx_type_41) error{ }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = (try function_0(allocator, in));

    return value_1;
}

