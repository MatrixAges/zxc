pub const zx_type_11 = enum { File, Package, Zig, C, Standard, LegacyLibrary, Invalid, };

pub const zx_type_12 = struct {
    offset: u64,
    separator: u64,
    source: []const u8,
    valid: bool,
};

pub const zx_type_13 = struct {
    offset: u64,
    source: []const u8,
    start: u64,
    valid: bool,
};

pub const zx_type_14 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_18 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_19 = struct {
    base: *const zx_type_18,
    delta: *const zx_type_18,
};

pub const zx_type_20 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_14,
    label: []const u8,
    second: u32,
};

pub const zx_type_21 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_22 = struct {
    children: []const u32,
    fields: *const zx_type_21,
    first: u32,
    kind: zx_type_14,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_23 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_24 = struct {
    delta: *const zx_type_18,
    id: u32,
};

pub const zx_type_29 = struct {
    identities: []const ?[]const u8,
    import_names: []const []const u8,
    specifiers: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    type_namespaces: []const []const []const u8,
};

pub const zx_type_35 = struct {
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    output_types: []const u32,
};

pub const zx_type_36 = struct {
    modules: *const zx_type_29,
    table: *const zx_type_18,
};

pub const zx_type_37 = struct {
    functions: *const zx_type_35,
    index: u64,
    modules: *const zx_type_29,
};

pub const zx_type_38 = struct {
    index: u64,
    modules: *const zx_type_29,
};

pub const zx_type_39 = struct {
    high: u8,
    index: u64,
    low: u8,
    remaining: u64,
    text: []const u8,
    valid: bool,
};

pub const zx_type_40 = struct {
    context: *const zx_type_36,
    module: u64,
};

pub const zx_type_41 = struct {
    context: *const zx_type_36,
    index: u64,
    module: u64,
    owner: []const u8,
    valid: bool,
};

pub const zx_type_42 = struct {
    count: u64,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
};

pub const zx_type_43 = struct {
    count: u64,
    index: u64,
    modules: *const zx_type_29,
    name: []const u8,
    owner: []const u8,
    type_id: u32,
    valid: bool,
};

pub const zx_type_44 = struct {
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u32,
    valid: bool,
};

pub const zx_type_45 = struct {
    context: *const zx_type_36,
    index: u64,
};

pub const zx_type_46 = struct {
    index: u64,
    names: []const []const u8,
    valid: bool,
};

pub const zx_type_47 = struct {
    count: u64,
    found: bool,
    index: u64,
    modules: *const zx_type_29,
    name: []const u8,
    owner: []const u8,
};

pub const zx_type_48 = struct {
    context: *const zx_type_36,
    type_id: u64,
};

pub const zx_type_49 = struct {
    declared: bool,
    index: u64,
    modules: *const zx_type_29,
    name: []const u8,
    owner: ?[]const u8,
    type_id: u64,
    valid: bool,
};

pub const zx_type_50 = struct {
    declared: bool,
    found: bool,
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u64,
};

pub const zx_type_51 = struct {
    index: u64,
    modules: *const zx_type_29,
    valid: bool,
};

pub const zx_type_52 = struct {
    context: *const zx_type_36,
    index: u64,
    valid: bool,
};

pub const zx_type_53 = struct { *const zx_type_36, };

pub const zx_type_54 = struct { *const zx_type_36, bool, };

pub const value_zx_type_12_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    offset: u64,
    separator: u64,
    source: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_12 = null,
};

pub const value_zx_type_13_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    offset: u64,
    source: []const u8,
    start: u64,
    valid: bool,
    zx_origin: ?*const zx_type_13 = null,
};

pub const value_zx_type_19_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    base: *const zx_type_18,
    delta: *const zx_type_18,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_20_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_14,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_21 = null,
};

pub const value_zx_type_22_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_14,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_22 = null,
};

pub const value_zx_type_23_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_23 = null,
};

pub const value_zx_type_24_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    delta: *const zx_type_18,
    id: u32,
    zx_origin: ?*const zx_type_24 = null,
};

pub const value_zx_type_29_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    identities: []const ?[]const u8,
    import_names: []const []const u8,
    specifiers: []const []const u8,
    type_ids: []const []const u32,
    type_names: []const []const []const u8,
    type_namespaces: []const []const []const u8,
    zx_origin: ?*const zx_type_29 = null,
};

pub const value_zx_type_35_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b = struct {
    input_types: []const u32,
    native_concurrent: []const bool,
    native_errors: []const ?[]const []const u8,
    native_exports: []const ?[]const u8,
    native_fallible: []const bool,
    native_members: []const []const []const u8,
    native_modules: []const ?u32,
    output_types: []const u32,
    zx_origin: ?*const zx_type_35 = null,
};

pub const value_zx_type_36_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct {
    modules: value_zx_type_29_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    table: *const zx_type_18,
    zx_origin: ?*const zx_type_36 = null,
};

pub const value_zx_type_37_1dad68e6b0d0122b1476653abf673933ed027adc2ebd5fd855aec9b533a7b0ea = struct {
    functions: value_zx_type_35_74d420388c65b4f82d1929508045cc03e4c927fc5790f97f65a1df1f97c4c49b,
    index: u64,
    modules: value_zx_type_29_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_37 = null,
};

pub const value_zx_type_38_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    index: u64,
    modules: value_zx_type_29_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_38 = null,
};

pub const value_zx_type_39_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    high: u8,
    index: u64,
    low: u8,
    remaining: u64,
    text: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_39 = null,
};

pub const value_zx_type_40_80fa3f09fde2ea8660c1d43e969ee3d68c4cda0e85a50de87ab5f1fb43c5c390 = struct {
    context: value_zx_type_36_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189,
    module: u64,
    zx_origin: ?*const zx_type_40 = null,
};

pub const value_zx_type_41_d96b64d9a0cdeb5c4d9519515e9692cefd4e8b6e0fd3a4acd43c7a6cb54deb90 = struct {
    context: value_zx_type_36_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189,
    index: u64,
    module: u64,
    owner: []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_41 = null,
};

pub const value_zx_type_42_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    count: u64,
    found: bool,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    zx_origin: ?*const zx_type_42 = null,
};

pub const value_zx_type_43_ea1b7ae541093ece52c59f2de2f23eb593426bae77184c88543e9788bf3186e6 = struct {
    count: u64,
    index: u64,
    modules: value_zx_type_29_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: []const u8,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_43 = null,
};

pub const value_zx_type_44_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_44 = null,
};

pub const value_zx_type_45_80fa3f09fde2ea8660c1d43e969ee3d68c4cda0e85a50de87ab5f1fb43c5c390 = struct {
    context: value_zx_type_36_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189,
    index: u64,
    zx_origin: ?*const zx_type_45 = null,
};

pub const value_zx_type_46_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    index: u64,
    names: []const []const u8,
    valid: bool,
    zx_origin: ?*const zx_type_46 = null,
};

pub const value_zx_type_47_b1b23fbb7680b8cb1b3dadbfa986aa274ef1483cb6efee44a47ca580481a8e23 = struct {
    count: u64,
    found: bool,
    index: u64,
    modules: value_zx_type_29_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: []const u8,
    zx_origin: ?*const zx_type_47 = null,
};

pub const value_zx_type_48_80fa3f09fde2ea8660c1d43e969ee3d68c4cda0e85a50de87ab5f1fb43c5c390 = struct {
    context: value_zx_type_36_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189,
    type_id: u64,
    zx_origin: ?*const zx_type_48 = null,
};

pub const value_zx_type_49_39550f691687970b5dbfe4b46111ad44602515eab5c342208f2139f13ca4b8cf = struct {
    declared: bool,
    index: u64,
    modules: value_zx_type_29_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    name: []const u8,
    owner: ?[]const u8,
    type_id: u64,
    valid: bool,
    zx_origin: ?*const zx_type_49 = null,
};

pub const value_zx_type_50_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    declared: bool,
    found: bool,
    ids: []const u32,
    index: u64,
    name: []const u8,
    names: []const []const u8,
    type_id: u64,
    zx_origin: ?*const zx_type_50 = null,
};

pub const value_zx_type_51_4189088ef2050b9e5b16bc193b19a39cb02cc932c1e90ab4d4b2a647322cdcf0 = struct {
    index: u64,
    modules: value_zx_type_29_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    valid: bool,
    zx_origin: ?*const zx_type_51 = null,
};

pub const value_zx_type_52_ee123d0c630fe117230fb019f7a85eb490b50840dfc1899f8c57c79c91c3899f = struct {
    context: value_zx_type_36_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_52 = null,
};

pub const value_zx_type_53_4bb438ff01f237569bb9646dc2578b71e2a1e16fa8fe9e4b0b9d926ac5640cd1 = struct { value_zx_type_36_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, ?*const zx_type_53, };

pub const value_zx_type_54_80fa3f09fde2ea8660c1d43e969ee3d68c4cda0e85a50de87ab5f1fb43c5c390 = struct { value_zx_type_36_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189, bool, ?*const zx_type_54, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
};

