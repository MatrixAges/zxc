const std = @import("std");

const zx_native_0 = @import("flow_state");

const zx_native_1 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .native_reference, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_5, .@"2" = zx_shape_5, .@"3" = zx_shape_5, .@"4" = zx_shape_5, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_5, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_5, .@"2" = zx_shape_1, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_5, .@"2" = zx_shape_5, }, };

const zx_shape_16 = .{ .kind = .scalar, };

const zx_shape_17 = .{ .kind = .scalar, };

const zx_shape_18 = .{ .kind = .scalar, };

const zx_shape_19 = .{ .kind = .scalar, };

const zx_shape_20 = .{ .kind = .scalar, };

const zx_shape_21 = .{ .kind = .list, .child = zx_shape_16, };

const zx_shape_22 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_23 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_24 = .{ .kind = .list, .child = zx_shape_9, };

const zx_shape_25 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_26 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_27 = .{ .kind = .optional, .child = zx_shape_4, };

const zx_shape_28 = .{ .kind = .list, .child = zx_shape_27, };

const zx_shape_29 = .{ .kind = .list, .child = zx_shape_17, };

const zx_shape_30 = .{ .kind = .list, .child = zx_shape_18, };

const zx_shape_31 = .{ .kind = .list, .child = zx_shape_19, };

const zx_shape_32 = .{ .kind = .list, .child = zx_shape_20, };

const zx_shape_33 = .{ .kind = .object, .fields = .{ .awaits = zx_shape_22, .binary_left = zx_shape_22, .binary_operators = zx_shape_32, .binary_right = zx_shape_22, .booleans = zx_shape_26, .call_arguments = zx_shape_22, .call_functions = zx_shape_22, .call_store_count = zx_shape_22, .call_store_first = zx_shape_22, .call_stores = zx_shape_22, .cancellations = zx_shape_22, .captures = zx_shape_22, .collection_arguments = zx_shape_22, .collection_count = zx_shape_22, .collection_first = zx_shape_22, .collection_kinds = zx_shape_29, .collection_targets = zx_shape_22, .conditional_conditions = zx_shape_22, .conditional_no = zx_shape_22, .conditional_yes = zx_shape_22, .enumerations = zx_shape_22, .errors = zx_shape_22, .floats = zx_shape_24, .index_targets = zx_shape_22, .index_values = zx_shape_22, .integers = zx_shape_23, .iteration_bodies = zx_shape_22, .iteration_condition_parameters = zx_shape_22, .iteration_conditions = zx_shape_22, .iteration_initials = zx_shape_22, .iteration_parameters = zx_shape_22, .iteration_postconditions = zx_shape_26, .kinds = zx_shape_21, .lengths = zx_shape_22, .match_conditions = zx_shape_22, .match_count = zx_shape_22, .match_fallbacks = zx_shape_22, .match_first = zx_shape_22, .match_results = zx_shape_22, .match_subjects = zx_shape_28, .negative_integers = zx_shape_23, .object_count = zx_shape_22, .object_evaluation_count = zx_shape_22, .object_evaluation_first = zx_shape_22, .object_evaluation_values = zx_shape_22, .object_field_indices = zx_shape_22, .object_field_values = zx_shape_22, .object_first = zx_shape_22, .optional_values = zx_shape_22, .parallel_count = zx_shape_22, .parallel_fields = zx_shape_28, .parallel_first = zx_shape_22, .parallel_tasks = zx_shape_22, .payloads = zx_shape_22, .projection_indices = zx_shape_22, .projection_targets = zx_shape_22, .references = zx_shape_22, .scope_borrows = zx_shape_26, .scope_count = zx_shape_22, .scope_first = zx_shape_22, .scope_results = zx_shape_22, .scope_symbols = zx_shape_28, .scope_values = zx_shape_22, .sequence_count = zx_shape_22, .sequence_first = zx_shape_22, .sequence_items = zx_shape_22, .some = zx_shape_22, .span_end = zx_shape_23, .span_start = zx_shape_23, .stores = zx_shape_22, .strings = zx_shape_25, .task_bodies = zx_shape_22, .task_capture_count = zx_shape_22, .task_capture_first = zx_shape_22, .task_captures = zx_shape_22, .transform_bodies = zx_shape_22, .transform_count = zx_shape_22, .transform_first = zx_shape_22, .transform_initials = zx_shape_28, .transform_kinds = zx_shape_30, .transform_parameters = zx_shape_22, .transform_targets = zx_shape_22, .types = zx_shape_22, .unary_operands = zx_shape_22, .unary_operators = zx_shape_31, .update_indices = zx_shape_22, .update_targets = zx_shape_22, .update_values = zx_shape_22, }, };

const zx_shape_34 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_33, .payload = zx_shape_5, .truth = zx_shape_1, .writer = zx_shape_11, }, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .index = zx_shape_5, .symbol = zx_shape_5, .writer = zx_shape_11, }, };

const zx_shape_36 = .{ .kind = .object, .fields = .{ .condition = zx_shape_5, .expressions = zx_shape_33, .truth = zx_shape_1, .writer = zx_shape_11, }, };

const zx_shape_37 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_33, .mark = zx_shape_5, .writer = zx_shape_11, }, };

const zx_shape_38 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_36, }, };

pub const input_shape = zx_shape_36;

pub const output_shape = zx_shape_0;

pub const Input = *const (zx_abi).zx_type_36;

pub const Output = void;

fn function_0(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_12) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_0).push((in).@"0", (in).@"1", (in).@"2", (in).@"3", (in).@"4"));

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!void {
    const native_result = (zx_native_0).pop(in);

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).eventCount(in);

    _ = allocator;

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).eventKind(in);

    _ = allocator;

    return native_result;
}

fn function_4(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).eventA(in);

    _ = allocator;

    return native_result;
}

fn function_5(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).eventB(in);

    _ = allocator;

    return native_result;
}

fn function_6(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).eventC(in);

    _ = allocator;

    return native_result;
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!bool {
    const native_result = (zx_native_0).active((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_14) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_0).setActive((in).@"0", (in).@"1", (in).@"2"));

    _ = allocator;

    return native_result;
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).activeMark(in);

    _ = allocator;

    return native_result;
}

fn function_10(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!void {
    const native_result = (zx_native_0).restoreActive((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_11(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!bool {
    const native_result = (zx_native_0).declared((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_12(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!void {
    const native_result = (zx_native_0).setDeclared((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_13(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!u64 {
    const native_result = (zx_native_0).owner((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_14(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_15) error{ }!void {
    const native_result = (zx_native_0).setOwner((in).@"0", (in).@"1", (in).@"2");

    _ = allocator;

    return native_result;
}

fn function_15(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).factMark(in);

    _ = allocator;

    return native_result;
}

fn function_16(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).captureMark(in);

    _ = allocator;

    return native_result;
}

fn function_17(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_15) error{ }!void {
    const native_result = (zx_native_0).restoreFacts((in).@"0", (in).@"1", (in).@"2");

    _ = allocator;

    return native_result;
}

fn function_18(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!bool {
    const native_result = (zx_native_0).contains((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_19(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_0).appendFact((in).@"0", (in).@"1"));

    _ = allocator;

    return native_result;
}

fn function_20(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_15) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_0).appendCapture((in).@"0", (in).@"1", (in).@"2"));

    _ = allocator;

    return native_result;
}

fn function_21(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!u64 {
    const native_result = (zx_native_0).captureError((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_22(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!u64 {
    const native_result = (zx_native_0).captureResult((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_23(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_1).widen(in);

    _ = allocator;

    return native_result;
}

fn function_24(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_1).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_25(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_34) error{ IndexOutOfBounds, OutOfMemory, }!void {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_33 = ((in).expressions).*;
    const value_2: (zx_abi).zx_type_20 = block_72: {
        const operand_70 = ((&value_1)).binary_operators;
        const operand_71 = (in).payload;

        if ((operand_71 >= (operand_70).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_72 (operand_70)[@intCast(operand_71)];
    };

    if (((value_2 != @as((zx_abi).zx_type_20, .Equal)) and (value_2 != @as((zx_abi).zx_type_20, .NotEqual)))) {
        return;
    }

    const value_3: u64 = (try function_23(allocator, block_69: {
        const operand_67 = ((&value_1)).binary_left;
        const operand_68 = (in).payload;

        if ((operand_68 >= (operand_67).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_69 (operand_67)[@intCast(operand_68)];
    }));
    const value_4: u64 = (try function_23(allocator, block_66: {
        const operand_64 = ((&value_1)).binary_right;
        const operand_65 = (in).payload;

        if ((operand_65 >= (operand_64).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_66 (operand_64)[@intCast(operand_65)];
    }));
    const value_5: u64 = (if (((block_60: {
        const operand_58 = ((&value_1)).kinds;
        const operand_59 = value_3;

        if ((operand_59 >= (operand_58).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_60 (operand_58)[@intCast(operand_59)];
    } == @as((zx_abi).zx_type_16, .Reference)) and (block_63: {
        const operand_61 = ((&value_1)).kinds;
        const operand_62 = value_4;

        if ((operand_62 >= (operand_61).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_63 (operand_61)[@intCast(operand_62)];
    } == @as((zx_abi).zx_type_16, .None)))) value_3 else (if (((block_54: {
        const operand_52 = ((&value_1)).kinds;
        const operand_53 = value_4;

        if ((operand_53 >= (operand_52).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_54 (operand_52)[@intCast(operand_53)];
    } == @as((zx_abi).zx_type_16, .Reference)) and (block_57: {
        const operand_55 = ((&value_1)).kinds;
        const operand_56 = value_3;

        if ((operand_56 >= (operand_55).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_57 (operand_55)[@intCast(operand_56)];
    } == @as((zx_abi).zx_type_16, .None)))) value_4 else @as(u64, (((&value_1)).kinds).len)));

    if ((value_5 == @as(u64, (((&value_1)).kinds).len))) {
        return;
    }

    const value_6: u64 = (try function_23(allocator, block_51: {
        const operand_49 = ((&value_1)).references;
        const operand_50 = (try function_23(allocator, block_48: {
            const operand_46 = ((&value_1)).payloads;
            const operand_47 = value_5;

            if ((operand_47 >= (operand_46).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_48 (operand_46)[@intCast(operand_47)];
        }));

        if ((operand_50 >= (operand_49).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_51 (operand_49)[@intCast(operand_50)];
    }));
    const value_7: bool = (if ((value_2 == @as((zx_abi).zx_type_20, .NotEqual))) (in).truth else (!(in).truth));

    if (value_7) {
        if ((!block_5: {
            const operand_4 = @as((zx_abi).zx_type_13, block_3: {
                const operand_1 = (in).writer;
                const operand_2 = value_6;

                break :block_3 .{ operand_1, operand_2, };
            });

            break :block_5 (try function_18(allocator, (&operand_4)));
        })) {
            _ = block_10: {
                const operand_9 = @as((zx_abi).zx_type_13, block_8: {
                    const operand_6 = (in).writer;
                    const operand_7 = value_6;

                    break :block_8 .{ operand_6, operand_7, };
                });

                break :block_10 (try function_19(allocator, (&operand_9)));
            };
        }
    } else {
        _ = block_45: {
            const operand_17 = block_16: {
                const operand_12 = (in).writer;
                const operand_13 = value_6;
                const operand_14 = @as(u64, 0);
                const operand_15 = (try function_16(allocator, (in).writer));

                break :block_16 (zx_abi).zx_type_35{ .writer = operand_12, .symbol = operand_13, .index = operand_14, .count = operand_15, };
            };

            var state_11: (zx_abi).value_zx_type_35_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (zx_abi).value_zx_type_35_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (operand_17).count, .index = (operand_17).index, .symbol = (operand_17).symbol, .writer = (operand_17).writer, .zx_origin = (&operand_17), };

            while (((state_11).index < (state_11).count)) {
                state_11 = block_44: {
                    const value_12: (zx_abi).value_zx_type_35_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if ((block_24: {
                        const operand_23 = @as((zx_abi).zx_type_13, block_22: {
                            const operand_20 = (state_11).writer;
                            const operand_21 = (state_11).index;

                            break :block_22 .{ operand_20, operand_21, };
                        });

                        break :block_24 (try function_21(allocator, (&operand_23)));
                    } == (state_11).symbol)) block_43: {
                        const value_10: u64 = block_42: {
                            const operand_41 = @as((zx_abi).zx_type_13, block_40: {
                                const operand_38 = (state_11).writer;
                                const operand_39 = (state_11).index;

                                break :block_40 .{ operand_38, operand_39, };
                            });

                            break :block_42 (try function_22(allocator, (&operand_41)));
                        };
                        const value_11: (zx_abi).value_zx_type_35_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if ((!block_30: {
                            const operand_29 = @as((zx_abi).zx_type_13, block_28: {
                                const operand_25 = (state_11).writer;
                                const operand_27 = block_26: {
                                    break :block_26 value_10;
                                };

                                break :block_28 .{ operand_25, operand_27, };
                            });

                            break :block_30 (try function_18(allocator, (&operand_29)));
                        })) block_37: {
                            _ = block_36: {
                                const operand_35 = @as((zx_abi).zx_type_13, block_34: {
                                    const operand_31 = (state_11).writer;
                                    const operand_33 = block_32: {
                                        break :block_32 value_10;
                                    };

                                    break :block_34 .{ operand_31, operand_33, };
                                });

                                break :block_36 (try function_19(allocator, (&operand_35)));
                            };

                            break :block_37 state_11;
                        } else state_11);

                        break :block_43 value_11;
                    } else state_11);
                    const value_13: (zx_abi).value_zx_type_35_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = value_12;
                    const value_14: u64 = (value_13).index;
                    const value_15: (zx_abi).value_zx_type_35_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_19: {
                        break :block_19 @as((zx_abi).value_zx_type_35_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_35_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (value_13).count, .index = (block_18: {
                            break :block_18 value_14;
                        } + @as(u64, 1)), .symbol = (value_13).symbol, .writer = (value_13).writer, });
                    };

                    break :block_44 value_15;
                };
            }

            break :block_45 {};
        };
    }
}

fn function_26(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_36) error{ IndexOutOfBounds, OutOfMemory, }!void {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_2(allocator, (in).writer));

    _ = block_110: {
        const operand_109 = @as((zx_abi).zx_type_12, block_108: {
            const operand_103 = (in).writer;
            const operand_104 = @as(u64, 0);
            const operand_105 = (in).condition;
            const operand_106 = (if ((in).truth) @as(u64, 1) else @as(u64, 0));
            const operand_107 = @as(u64, 0);

            break :block_108 .{ operand_103, operand_104, operand_105, operand_106, operand_107, };
        });

        break :block_110 (try function_0(allocator, (&operand_109)));
    };

    _ = block_102: {
        const operand_6 = block_5: {
            const operand_2 = (in).writer;
            const operand_3 = (in).expressions;
            const operand_4 = value_1;

            break :block_5 (zx_abi).zx_type_37{ .writer = operand_2, .expressions = operand_3, .mark = operand_4, };
        };

        var state_1: (zx_abi).value_zx_type_37_8aa27d9e8aa391e57e5d507ee07733f106e8d2ef01e6f574a23201cf838bb27b = (zx_abi).value_zx_type_37_8aa27d9e8aa391e57e5d507ee07733f106e8d2ef01e6f574a23201cf838bb27b{ .expressions = (zx_abi).value_zx_type_33_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = ((operand_6).expressions).awaits, .binary_left = ((operand_6).expressions).binary_left, .binary_operators = ((operand_6).expressions).binary_operators, .binary_right = ((operand_6).expressions).binary_right, .booleans = ((operand_6).expressions).booleans, .call_arguments = ((operand_6).expressions).call_arguments, .call_functions = ((operand_6).expressions).call_functions, .call_store_count = ((operand_6).expressions).call_store_count, .call_store_first = ((operand_6).expressions).call_store_first, .call_stores = ((operand_6).expressions).call_stores, .cancellations = ((operand_6).expressions).cancellations, .captures = ((operand_6).expressions).captures, .collection_arguments = ((operand_6).expressions).collection_arguments, .collection_count = ((operand_6).expressions).collection_count, .collection_first = ((operand_6).expressions).collection_first, .collection_kinds = ((operand_6).expressions).collection_kinds, .collection_targets = ((operand_6).expressions).collection_targets, .conditional_conditions = ((operand_6).expressions).conditional_conditions, .conditional_no = ((operand_6).expressions).conditional_no, .conditional_yes = ((operand_6).expressions).conditional_yes, .enumerations = ((operand_6).expressions).enumerations, .errors = ((operand_6).expressions).errors, .floats = ((operand_6).expressions).floats, .index_targets = ((operand_6).expressions).index_targets, .index_values = ((operand_6).expressions).index_values, .integers = ((operand_6).expressions).integers, .iteration_bodies = ((operand_6).expressions).iteration_bodies, .iteration_condition_parameters = ((operand_6).expressions).iteration_condition_parameters, .iteration_conditions = ((operand_6).expressions).iteration_conditions, .iteration_initials = ((operand_6).expressions).iteration_initials, .iteration_parameters = ((operand_6).expressions).iteration_parameters, .iteration_postconditions = ((operand_6).expressions).iteration_postconditions, .kinds = ((operand_6).expressions).kinds, .lengths = ((operand_6).expressions).lengths, .match_conditions = ((operand_6).expressions).match_conditions, .match_count = ((operand_6).expressions).match_count, .match_fallbacks = ((operand_6).expressions).match_fallbacks, .match_first = ((operand_6).expressions).match_first, .match_results = ((operand_6).expressions).match_results, .match_subjects = ((operand_6).expressions).match_subjects, .negative_integers = ((operand_6).expressions).negative_integers, .object_count = ((operand_6).expressions).object_count, .object_evaluation_count = ((operand_6).expressions).object_evaluation_count, .object_evaluation_first = ((operand_6).expressions).object_evaluation_first, .object_evaluation_values = ((operand_6).expressions).object_evaluation_values, .object_field_indices = ((operand_6).expressions).object_field_indices, .object_field_values = ((operand_6).expressions).object_field_values, .object_first = ((operand_6).expressions).object_first, .optional_values = ((operand_6).expressions).optional_values, .parallel_count = ((operand_6).expressions).parallel_count, .parallel_fields = ((operand_6).expressions).parallel_fields, .parallel_first = ((operand_6).expressions).parallel_first, .parallel_tasks = ((operand_6).expressions).parallel_tasks, .payloads = ((operand_6).expressions).payloads, .projection_indices = ((operand_6).expressions).projection_indices, .projection_targets = ((operand_6).expressions).projection_targets, .references = ((operand_6).expressions).references, .scope_borrows = ((operand_6).expressions).scope_borrows, .scope_count = ((operand_6).expressions).scope_count, .scope_first = ((operand_6).expressions).scope_first, .scope_results = ((operand_6).expressions).scope_results, .scope_symbols = ((operand_6).expressions).scope_symbols, .scope_values = ((operand_6).expressions).scope_values, .sequence_count = ((operand_6).expressions).sequence_count, .sequence_first = ((operand_6).expressions).sequence_first, .sequence_items = ((operand_6).expressions).sequence_items, .some = ((operand_6).expressions).some, .span_end = ((operand_6).expressions).span_end, .span_start = ((operand_6).expressions).span_start, .stores = ((operand_6).expressions).stores, .strings = ((operand_6).expressions).strings, .task_bodies = ((operand_6).expressions).task_bodies, .task_capture_count = ((operand_6).expressions).task_capture_count, .task_capture_first = ((operand_6).expressions).task_capture_first, .task_captures = ((operand_6).expressions).task_captures, .transform_bodies = ((operand_6).expressions).transform_bodies, .transform_count = ((operand_6).expressions).transform_count, .transform_first = ((operand_6).expressions).transform_first, .transform_initials = ((operand_6).expressions).transform_initials, .transform_kinds = ((operand_6).expressions).transform_kinds, .transform_parameters = ((operand_6).expressions).transform_parameters, .transform_targets = ((operand_6).expressions).transform_targets, .types = ((operand_6).expressions).types, .unary_operands = ((operand_6).expressions).unary_operands, .unary_operators = ((operand_6).expressions).unary_operators, .update_indices = ((operand_6).expressions).update_indices, .update_targets = ((operand_6).expressions).update_targets, .update_values = ((operand_6).expressions).update_values, .zx_origin = (operand_6).expressions, }, .mark = (operand_6).mark, .writer = (operand_6).writer, .zx_origin = (&operand_6), };

        while ((block_8: {
            const operand_7 = (state_1).writer;

            break :block_8 (try function_2(allocator, operand_7));
        } > (state_1).mark)) {
            state_1 = block_101: {
                _ = block_100: {
                    const operand_99 = (state_1).writer;

                    break :block_100 (try function_1(allocator, operand_99));
                };

                const value_4: u64 = block_98: {
                    const operand_97 = (state_1).writer;

                    break :block_98 (try function_4(allocator, operand_97));
                };
                const value_5: bool = (block_96: {
                    const operand_95 = (state_1).writer;

                    break :block_96 (try function_5(allocator, operand_95));
                } != @as(u64, 0));
                const value_6: (zx_abi).value_zx_type_33_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788 = (state_1).expressions;
                const value_7: (zx_abi).zx_type_16 = block_94: {
                    const operand_92 = (value_6).kinds;
                    const operand_93 = block_91: {
                        break :block_91 value_4;
                    };

                    if ((operand_93 >= (operand_92).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_94 (operand_92)[@intCast(operand_93)];
                };
                const value_8: u64 = block_90: {
                    const operand_89 = block_88: {
                        const operand_86 = (value_6).payloads;
                        const operand_87 = block_85: {
                            break :block_85 value_4;
                        };

                        if ((operand_87 >= (operand_86).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_88 (operand_86)[@intCast(operand_87)];
                    };

                    break :block_90 (try function_23(allocator, operand_89));
                };
                const value_12: (zx_abi).value_zx_type_37_8aa27d9e8aa391e57e5d507ee07733f106e8d2ef01e6f574a23201cf838bb27b = (if (((block_9: {
                    break :block_9 value_7;
                } == @as((zx_abi).zx_type_16, .Unary)) and (block_13: {
                    const operand_11 = (value_6).unary_operators;
                    const operand_12 = block_10: {
                        break :block_10 value_8;
                    };

                    if ((operand_12 >= (operand_11).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_13 (operand_11)[@intCast(operand_12)];
                } == @as((zx_abi).zx_type_19, .Not)))) block_29: {
                    _ = block_28: {
                        const operand_27 = @as((zx_abi).zx_type_12, block_26: {
                            const operand_14 = (state_1).writer;
                            const operand_15 = @as(u64, 0);
                            const operand_22 = block_21: {
                                const operand_20 = block_19: {
                                    const operand_17 = (value_6).unary_operands;
                                    const operand_18 = block_16: {
                                        break :block_16 value_8;
                                    };

                                    if ((operand_18 >= (operand_17).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_19 (operand_17)[@intCast(operand_18)];
                                };

                                break :block_21 (try function_23(allocator, operand_20));
                            };
                            const operand_24 = (if (block_23: {
                                break :block_23 value_5;
                            }) @as(u64, 0) else @as(u64, 1));
                            const operand_25 = @as(u64, 0);

                            break :block_26 .{ operand_14, operand_15, operand_22, operand_24, operand_25, };
                        });

                        break :block_28 (try function_0(allocator, (&operand_27)));
                    };

                    break :block_29 state_1;
                } else block_84: {
                    const value_11: (zx_abi).value_zx_type_37_8aa27d9e8aa391e57e5d507ee07733f106e8d2ef01e6f574a23201cf838bb27b = (if ((block_30: {
                        break :block_30 value_7;
                    } == @as((zx_abi).zx_type_16, .Binary))) block_83: {
                        const value_9: (zx_abi).zx_type_20 = block_82: {
                            const operand_80 = (value_6).binary_operators;
                            const operand_81 = block_79: {
                                break :block_79 value_8;
                            };

                            if ((operand_81 >= (operand_80).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_82 (operand_80)[@intCast(operand_81)];
                        };
                        const value_10: (zx_abi).value_zx_type_37_8aa27d9e8aa391e57e5d507ee07733f106e8d2ef01e6f574a23201cf838bb27b = (if ((((block_31: {
                            break :block_31 value_9;
                        } == @as((zx_abi).zx_type_20, .LogicalAnd)) and block_32: {
                            break :block_32 value_5;
                        }) or ((block_33: {
                            break :block_33 value_9;
                        } == @as((zx_abi).zx_type_20, .LogicalOr)) and (!block_34: {
                            break :block_34 value_5;
                        })))) block_65: {
                            _ = block_64: {
                                const operand_63 = @as((zx_abi).zx_type_12, block_62: {
                                    const operand_50 = (state_1).writer;
                                    const operand_51 = @as(u64, 0);
                                    const operand_58 = block_57: {
                                        const operand_56 = block_55: {
                                            const operand_53 = (value_6).binary_right;
                                            const operand_54 = block_52: {
                                                break :block_52 value_8;
                                            };

                                            if ((operand_54 >= (operand_53).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            break :block_55 (operand_53)[@intCast(operand_54)];
                                        };

                                        break :block_57 (try function_23(allocator, operand_56));
                                    };
                                    const operand_60 = (if (block_59: {
                                        break :block_59 value_5;
                                    }) @as(u64, 1) else @as(u64, 0));
                                    const operand_61 = @as(u64, 0);

                                    break :block_62 .{ operand_50, operand_51, operand_58, operand_60, operand_61, };
                                });

                                break :block_64 (try function_0(allocator, (&operand_63)));
                            };

                            _ = block_49: {
                                const operand_48 = @as((zx_abi).zx_type_12, block_47: {
                                    const operand_35 = (state_1).writer;
                                    const operand_36 = @as(u64, 0);
                                    const operand_43 = block_42: {
                                        const operand_41 = block_40: {
                                            const operand_38 = (value_6).binary_left;
                                            const operand_39 = block_37: {
                                                break :block_37 value_8;
                                            };

                                            if ((operand_39 >= (operand_38).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            break :block_40 (operand_38)[@intCast(operand_39)];
                                        };

                                        break :block_42 (try function_23(allocator, operand_41));
                                    };
                                    const operand_45 = (if (block_44: {
                                        break :block_44 value_5;
                                    }) @as(u64, 1) else @as(u64, 0));
                                    const operand_46 = @as(u64, 0);

                                    break :block_47 .{ operand_35, operand_36, operand_43, operand_45, operand_46, };
                                });

                                break :block_49 (try function_0(allocator, (&operand_48)));
                            };

                            break :block_65 state_1;
                        } else block_78: {
                            _ = block_77: {
                                const operand_66 = (state_1).writer;
                                const operand_67 = value_6;

                                var state_borrow_68: (zx_abi).zx_type_33 = undefined;

                                state_borrow_68 = (zx_abi).zx_type_33{ .awaits = (operand_67).awaits, .binary_left = (operand_67).binary_left, .binary_operators = (operand_67).binary_operators, .binary_right = (operand_67).binary_right, .booleans = (operand_67).booleans, .call_arguments = (operand_67).call_arguments, .call_functions = (operand_67).call_functions, .call_store_count = (operand_67).call_store_count, .call_store_first = (operand_67).call_store_first, .call_stores = (operand_67).call_stores, .cancellations = (operand_67).cancellations, .captures = (operand_67).captures, .collection_arguments = (operand_67).collection_arguments, .collection_count = (operand_67).collection_count, .collection_first = (operand_67).collection_first, .collection_kinds = (operand_67).collection_kinds, .collection_targets = (operand_67).collection_targets, .conditional_conditions = (operand_67).conditional_conditions, .conditional_no = (operand_67).conditional_no, .conditional_yes = (operand_67).conditional_yes, .enumerations = (operand_67).enumerations, .errors = (operand_67).errors, .floats = (operand_67).floats, .index_targets = (operand_67).index_targets, .index_values = (operand_67).index_values, .integers = (operand_67).integers, .iteration_bodies = (operand_67).iteration_bodies, .iteration_condition_parameters = (operand_67).iteration_condition_parameters, .iteration_conditions = (operand_67).iteration_conditions, .iteration_initials = (operand_67).iteration_initials, .iteration_parameters = (operand_67).iteration_parameters, .iteration_postconditions = (operand_67).iteration_postconditions, .kinds = (operand_67).kinds, .lengths = (operand_67).lengths, .match_conditions = (operand_67).match_conditions, .match_count = (operand_67).match_count, .match_fallbacks = (operand_67).match_fallbacks, .match_first = (operand_67).match_first, .match_results = (operand_67).match_results, .match_subjects = (operand_67).match_subjects, .negative_integers = (operand_67).negative_integers, .object_count = (operand_67).object_count, .object_evaluation_count = (operand_67).object_evaluation_count, .object_evaluation_first = (operand_67).object_evaluation_first, .object_evaluation_values = (operand_67).object_evaluation_values, .object_field_indices = (operand_67).object_field_indices, .object_field_values = (operand_67).object_field_values, .object_first = (operand_67).object_first, .optional_values = (operand_67).optional_values, .parallel_count = (operand_67).parallel_count, .parallel_fields = (operand_67).parallel_fields, .parallel_first = (operand_67).parallel_first, .parallel_tasks = (operand_67).parallel_tasks, .payloads = (operand_67).payloads, .projection_indices = (operand_67).projection_indices, .projection_targets = (operand_67).projection_targets, .references = (operand_67).references, .scope_borrows = (operand_67).scope_borrows, .scope_count = (operand_67).scope_count, .scope_first = (operand_67).scope_first, .scope_results = (operand_67).scope_results, .scope_symbols = (operand_67).scope_symbols, .scope_values = (operand_67).scope_values, .sequence_count = (operand_67).sequence_count, .sequence_first = (operand_67).sequence_first, .sequence_items = (operand_67).sequence_items, .some = (operand_67).some, .span_end = (operand_67).span_end, .span_start = (operand_67).span_start, .stores = (operand_67).stores, .strings = (operand_67).strings, .task_bodies = (operand_67).task_bodies, .task_capture_count = (operand_67).task_capture_count, .task_capture_first = (operand_67).task_capture_first, .task_captures = (operand_67).task_captures, .transform_bodies = (operand_67).transform_bodies, .transform_count = (operand_67).transform_count, .transform_first = (operand_67).transform_first, .transform_initials = (operand_67).transform_initials, .transform_kinds = (operand_67).transform_kinds, .transform_parameters = (operand_67).transform_parameters, .transform_targets = (operand_67).transform_targets, .types = (operand_67).types, .unary_operands = (operand_67).unary_operands, .unary_operators = (operand_67).unary_operators, .update_indices = (operand_67).update_indices, .update_targets = (operand_67).update_targets, .update_values = (operand_67).update_values, };

                                const operand_69 = ((operand_67).zx_origin orelse (&state_borrow_68));
                                const operand_71 = block_70: {
                                    break :block_70 value_8;
                                };
                                const operand_73 = block_72: {
                                    break :block_72 value_5;
                                };
                                const operand_74 = (zx_abi).value_zx_type_33_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = (operand_69).awaits, .binary_left = (operand_69).binary_left, .binary_operators = (operand_69).binary_operators, .binary_right = (operand_69).binary_right, .booleans = (operand_69).booleans, .call_arguments = (operand_69).call_arguments, .call_functions = (operand_69).call_functions, .call_store_count = (operand_69).call_store_count, .call_store_first = (operand_69).call_store_first, .call_stores = (operand_69).call_stores, .cancellations = (operand_69).cancellations, .captures = (operand_69).captures, .collection_arguments = (operand_69).collection_arguments, .collection_count = (operand_69).collection_count, .collection_first = (operand_69).collection_first, .collection_kinds = (operand_69).collection_kinds, .collection_targets = (operand_69).collection_targets, .conditional_conditions = (operand_69).conditional_conditions, .conditional_no = (operand_69).conditional_no, .conditional_yes = (operand_69).conditional_yes, .enumerations = (operand_69).enumerations, .errors = (operand_69).errors, .floats = (operand_69).floats, .index_targets = (operand_69).index_targets, .index_values = (operand_69).index_values, .integers = (operand_69).integers, .iteration_bodies = (operand_69).iteration_bodies, .iteration_condition_parameters = (operand_69).iteration_condition_parameters, .iteration_conditions = (operand_69).iteration_conditions, .iteration_initials = (operand_69).iteration_initials, .iteration_parameters = (operand_69).iteration_parameters, .iteration_postconditions = (operand_69).iteration_postconditions, .kinds = (operand_69).kinds, .lengths = (operand_69).lengths, .match_conditions = (operand_69).match_conditions, .match_count = (operand_69).match_count, .match_fallbacks = (operand_69).match_fallbacks, .match_first = (operand_69).match_first, .match_results = (operand_69).match_results, .match_subjects = (operand_69).match_subjects, .negative_integers = (operand_69).negative_integers, .object_count = (operand_69).object_count, .object_evaluation_count = (operand_69).object_evaluation_count, .object_evaluation_first = (operand_69).object_evaluation_first, .object_evaluation_values = (operand_69).object_evaluation_values, .object_field_indices = (operand_69).object_field_indices, .object_field_values = (operand_69).object_field_values, .object_first = (operand_69).object_first, .optional_values = (operand_69).optional_values, .parallel_count = (operand_69).parallel_count, .parallel_fields = (operand_69).parallel_fields, .parallel_first = (operand_69).parallel_first, .parallel_tasks = (operand_69).parallel_tasks, .payloads = (operand_69).payloads, .projection_indices = (operand_69).projection_indices, .projection_targets = (operand_69).projection_targets, .references = (operand_69).references, .scope_borrows = (operand_69).scope_borrows, .scope_count = (operand_69).scope_count, .scope_first = (operand_69).scope_first, .scope_results = (operand_69).scope_results, .scope_symbols = (operand_69).scope_symbols, .scope_values = (operand_69).scope_values, .sequence_count = (operand_69).sequence_count, .sequence_first = (operand_69).sequence_first, .sequence_items = (operand_69).sequence_items, .some = (operand_69).some, .span_end = (operand_69).span_end, .span_start = (operand_69).span_start, .stores = (operand_69).stores, .strings = (operand_69).strings, .task_bodies = (operand_69).task_bodies, .task_capture_count = (operand_69).task_capture_count, .task_capture_first = (operand_69).task_capture_first, .task_captures = (operand_69).task_captures, .transform_bodies = (operand_69).transform_bodies, .transform_count = (operand_69).transform_count, .transform_first = (operand_69).transform_first, .transform_initials = (operand_69).transform_initials, .transform_kinds = (operand_69).transform_kinds, .transform_parameters = (operand_69).transform_parameters, .transform_targets = (operand_69).transform_targets, .types = (operand_69).types, .unary_operands = (operand_69).unary_operands, .unary_operators = (operand_69).unary_operators, .update_indices = (operand_69).update_indices, .update_targets = (operand_69).update_targets, .update_values = (operand_69).update_values, .zx_origin = operand_69, };

                                var state_borrow_75: (zx_abi).zx_type_33 = undefined;

                                state_borrow_75 = (zx_abi).zx_type_33{ .awaits = (operand_74).awaits, .binary_left = (operand_74).binary_left, .binary_operators = (operand_74).binary_operators, .binary_right = (operand_74).binary_right, .booleans = (operand_74).booleans, .call_arguments = (operand_74).call_arguments, .call_functions = (operand_74).call_functions, .call_store_count = (operand_74).call_store_count, .call_store_first = (operand_74).call_store_first, .call_stores = (operand_74).call_stores, .cancellations = (operand_74).cancellations, .captures = (operand_74).captures, .collection_arguments = (operand_74).collection_arguments, .collection_count = (operand_74).collection_count, .collection_first = (operand_74).collection_first, .collection_kinds = (operand_74).collection_kinds, .collection_targets = (operand_74).collection_targets, .conditional_conditions = (operand_74).conditional_conditions, .conditional_no = (operand_74).conditional_no, .conditional_yes = (operand_74).conditional_yes, .enumerations = (operand_74).enumerations, .errors = (operand_74).errors, .floats = (operand_74).floats, .index_targets = (operand_74).index_targets, .index_values = (operand_74).index_values, .integers = (operand_74).integers, .iteration_bodies = (operand_74).iteration_bodies, .iteration_condition_parameters = (operand_74).iteration_condition_parameters, .iteration_conditions = (operand_74).iteration_conditions, .iteration_initials = (operand_74).iteration_initials, .iteration_parameters = (operand_74).iteration_parameters, .iteration_postconditions = (operand_74).iteration_postconditions, .kinds = (operand_74).kinds, .lengths = (operand_74).lengths, .match_conditions = (operand_74).match_conditions, .match_count = (operand_74).match_count, .match_fallbacks = (operand_74).match_fallbacks, .match_first = (operand_74).match_first, .match_results = (operand_74).match_results, .match_subjects = (operand_74).match_subjects, .negative_integers = (operand_74).negative_integers, .object_count = (operand_74).object_count, .object_evaluation_count = (operand_74).object_evaluation_count, .object_evaluation_first = (operand_74).object_evaluation_first, .object_evaluation_values = (operand_74).object_evaluation_values, .object_field_indices = (operand_74).object_field_indices, .object_field_values = (operand_74).object_field_values, .object_first = (operand_74).object_first, .optional_values = (operand_74).optional_values, .parallel_count = (operand_74).parallel_count, .parallel_fields = (operand_74).parallel_fields, .parallel_first = (operand_74).parallel_first, .parallel_tasks = (operand_74).parallel_tasks, .payloads = (operand_74).payloads, .projection_indices = (operand_74).projection_indices, .projection_targets = (operand_74).projection_targets, .references = (operand_74).references, .scope_borrows = (operand_74).scope_borrows, .scope_count = (operand_74).scope_count, .scope_first = (operand_74).scope_first, .scope_results = (operand_74).scope_results, .scope_symbols = (operand_74).scope_symbols, .scope_values = (operand_74).scope_values, .sequence_count = (operand_74).sequence_count, .sequence_first = (operand_74).sequence_first, .sequence_items = (operand_74).sequence_items, .some = (operand_74).some, .span_end = (operand_74).span_end, .span_start = (operand_74).span_start, .stores = (operand_74).stores, .strings = (operand_74).strings, .task_bodies = (operand_74).task_bodies, .task_capture_count = (operand_74).task_capture_count, .task_capture_first = (operand_74).task_capture_first, .task_captures = (operand_74).task_captures, .transform_bodies = (operand_74).transform_bodies, .transform_count = (operand_74).transform_count, .transform_first = (operand_74).transform_first, .transform_initials = (operand_74).transform_initials, .transform_kinds = (operand_74).transform_kinds, .transform_parameters = (operand_74).transform_parameters, .transform_targets = (operand_74).transform_targets, .types = (operand_74).types, .unary_operands = (operand_74).unary_operands, .unary_operators = (operand_74).unary_operators, .update_indices = (operand_74).update_indices, .update_targets = (operand_74).update_targets, .update_values = (operand_74).update_values, };

                                const operand_76 = (zx_abi).zx_type_34{ .writer = operand_66, .expressions = ((operand_74).zx_origin orelse (&state_borrow_75)), .payload = operand_71, .truth = operand_73, };

                                break :block_77 (try function_25(allocator, (&operand_76)));
                            };

                            break :block_78 state_1;
                        });

                        break :block_83 value_10;
                    } else state_1);

                    break :block_84 value_11;
                });

                break :block_101 value_12;
            };
        }

        break :block_102 {};
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_36) error{ IndexOutOfBounds, OutOfMemory, }!void {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();

    _ = (try function_26(allocator, in));

    return;
}

