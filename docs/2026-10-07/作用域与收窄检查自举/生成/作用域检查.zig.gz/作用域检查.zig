const std = @import("std");

const zx_native_0 = @import("integers");

const zx_native_1 = @import("flow_state");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_11, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_14 = .{ .kind = .optional, .child = zx_shape_4, };

const zx_shape_15 = .{ .kind = .list, .child = zx_shape_14, };

const zx_shape_16 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .block_count = zx_shape_13, .block_first = zx_shape_13, .branch_conditions = zx_shape_13, .branch_no = zx_shape_13, .branch_yes = zx_shape_13, .case_bodies = zx_shape_13, .case_values = zx_shape_15, .constant_symbols = zx_shape_13, .constant_values = zx_shape_13, .destructure_count = zx_shape_13, .destructure_first = zx_shape_13, .destructure_symbols = zx_shape_15, .destructure_values = zx_shape_13, .evaluations = zx_shape_13, .parallel_count = zx_shape_13, .parallel_first = zx_shape_13, .parallel_symbols = zx_shape_15, .parallel_values = zx_shape_13, .results = zx_shape_15, .selection_count = zx_shape_13, .selection_exhaustive = zx_shape_16, .selection_first = zx_shape_13, .selection_subjects = zx_shape_13, .setter_slots = zx_shape_13, .setter_values = zx_shape_13, .statement_kinds = zx_shape_12, .statement_payloads = zx_shape_13, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .control = zx_shape_17, .returns = zx_shape_16, .selection = zx_shape_5, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .all = zx_shape_1, .bodies = zx_shape_13, .end = zx_shape_5, .index = zx_shape_5, .returns = zx_shape_16, }, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .block = zx_shape_5, .control = zx_shape_17, .returns = zx_shape_16, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_16, .@"1" = zx_shape_0, }, };

const zx_shape_22 = .{ .kind = .scalar, };

const zx_shape_23 = .{ .kind = .scalar, };

const zx_shape_24 = .{ .kind = .scalar, };

const zx_shape_25 = .{ .kind = .scalar, };

const zx_shape_26 = .{ .kind = .scalar, };

const zx_shape_27 = .{ .kind = .list, .child = zx_shape_22, };

const zx_shape_28 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_29 = .{ .kind = .list, .child = zx_shape_9, };

const zx_shape_30 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_31 = .{ .kind = .list, .child = zx_shape_23, };

const zx_shape_32 = .{ .kind = .list, .child = zx_shape_24, };

const zx_shape_33 = .{ .kind = .list, .child = zx_shape_25, };

const zx_shape_34 = .{ .kind = .list, .child = zx_shape_26, };

const zx_shape_35 = .{ .kind = .object, .fields = .{ .awaits = zx_shape_13, .binary_left = zx_shape_13, .binary_operators = zx_shape_34, .binary_right = zx_shape_13, .booleans = zx_shape_16, .call_arguments = zx_shape_13, .call_functions = zx_shape_13, .call_store_count = zx_shape_13, .call_store_first = zx_shape_13, .call_stores = zx_shape_13, .cancellations = zx_shape_13, .captures = zx_shape_13, .collection_arguments = zx_shape_13, .collection_count = zx_shape_13, .collection_first = zx_shape_13, .collection_kinds = zx_shape_31, .collection_targets = zx_shape_13, .conditional_conditions = zx_shape_13, .conditional_no = zx_shape_13, .conditional_yes = zx_shape_13, .enumerations = zx_shape_13, .errors = zx_shape_13, .floats = zx_shape_29, .index_targets = zx_shape_13, .index_values = zx_shape_13, .integers = zx_shape_28, .iteration_bodies = zx_shape_13, .iteration_condition_parameters = zx_shape_13, .iteration_conditions = zx_shape_13, .iteration_initials = zx_shape_13, .iteration_parameters = zx_shape_13, .iteration_postconditions = zx_shape_16, .kinds = zx_shape_27, .lengths = zx_shape_13, .match_conditions = zx_shape_13, .match_count = zx_shape_13, .match_fallbacks = zx_shape_13, .match_first = zx_shape_13, .match_results = zx_shape_13, .match_subjects = zx_shape_15, .negative_integers = zx_shape_28, .object_count = zx_shape_13, .object_evaluation_count = zx_shape_13, .object_evaluation_first = zx_shape_13, .object_evaluation_values = zx_shape_13, .object_field_indices = zx_shape_13, .object_field_values = zx_shape_13, .object_first = zx_shape_13, .optional_values = zx_shape_13, .parallel_count = zx_shape_13, .parallel_fields = zx_shape_15, .parallel_first = zx_shape_13, .parallel_tasks = zx_shape_13, .payloads = zx_shape_13, .projection_indices = zx_shape_13, .projection_targets = zx_shape_13, .references = zx_shape_13, .scope_borrows = zx_shape_16, .scope_count = zx_shape_13, .scope_first = zx_shape_13, .scope_results = zx_shape_13, .scope_symbols = zx_shape_15, .scope_values = zx_shape_13, .sequence_count = zx_shape_13, .sequence_first = zx_shape_13, .sequence_items = zx_shape_13, .some = zx_shape_13, .span_end = zx_shape_28, .span_start = zx_shape_28, .stores = zx_shape_13, .strings = zx_shape_30, .task_bodies = zx_shape_13, .task_capture_count = zx_shape_13, .task_capture_first = zx_shape_13, .task_captures = zx_shape_13, .transform_bodies = zx_shape_13, .transform_count = zx_shape_13, .transform_first = zx_shape_13, .transform_initials = zx_shape_15, .transform_kinds = zx_shape_32, .transform_parameters = zx_shape_13, .transform_targets = zx_shape_13, .types = zx_shape_13, .unary_operands = zx_shape_13, .unary_operators = zx_shape_33, .update_indices = zx_shape_13, .update_targets = zx_shape_13, .update_values = zx_shape_13, }, };

const zx_shape_36 = .{ .kind = .object, .fields = .{ .allowed = zx_shape_16, .concurrent = zx_shape_1, .expressions = zx_shape_35, .limit = zx_shape_5, }, };

const zx_shape_37 = .{ .kind = .object, .fields = .{ .allowed = zx_shape_16, .concurrent = zx_shape_1, .expressions = zx_shape_35, .index = zx_shape_5, .limit = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_38 = .{ .kind = .object, .fields = .{ .handles = zx_shape_30, .paths = zx_shape_30, .readable = zx_shape_16, .types = zx_shape_13, .writable = zx_shape_16, }, };

const zx_shape_39 = .{ .kind = .list, .child = zx_shape_38, };

const zx_shape_40 = .{ .kind = .list, .child = zx_shape_35, };

const zx_shape_41 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_40, .native_concurrent = zx_shape_16, .native_modules = zx_shape_15, .stores = zx_shape_39, }, };

const zx_shape_42 = .{ .kind = .object, .fields = .{ .concurrent = zx_shape_1, .functions = zx_shape_41, }, };

const zx_shape_43 = .{ .kind = .object, .fields = .{ .concurrent = zx_shape_1, .functions = zx_shape_41, .index = zx_shape_5, .values = zx_shape_16, }, };

const zx_shape_44 = .{ .kind = .native_reference, };

const zx_shape_45 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_44, .@"1" = zx_shape_5, .@"2" = zx_shape_5, .@"3" = zx_shape_5, .@"4" = zx_shape_5, }, };

const zx_shape_46 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_44, .@"1" = zx_shape_5, }, };

const zx_shape_47 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_44, .@"1" = zx_shape_5, .@"2" = zx_shape_1, }, };

const zx_shape_48 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_44, .@"1" = zx_shape_5, .@"2" = zx_shape_5, }, };

const zx_shape_49 = .{ .kind = .scalar, };

const zx_shape_50 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_51 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .field_names = zx_shape_30, .field_types = zx_shape_13, .first = zx_shape_13, .kinds = zx_shape_50, .labels = zx_shape_30, .names = zx_shape_30, .second = zx_shape_13, }, };

const zx_shape_52 = .{ .kind = .object, .fields = .{ .base = zx_shape_51, .delta = zx_shape_51, }, };

const zx_shape_53 = .{ .kind = .object, .fields = .{ .delta = zx_shape_1, .first = zx_shape_4, .kind = zx_shape_49, .label = zx_shape_10, .second = zx_shape_4, }, };

const zx_shape_54 = .{ .kind = .object, .fields = .{ .names = zx_shape_30, .types = zx_shape_13, }, };

const zx_shape_55 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .fields = zx_shape_54, .first = zx_shape_4, .kind = zx_shape_49, .label = zx_shape_10, .names = zx_shape_30, .second = zx_shape_4, }, };

const zx_shape_56 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .id = zx_shape_4, }, };

const zx_shape_57 = .{ .kind = .object, .fields = .{ .delta = zx_shape_51, .id = zx_shape_4, }, };

const zx_shape_58 = .{ .kind = .scalar, };

const zx_shape_59 = .{ .kind = .list, .child = zx_shape_58, };

const zx_shape_60 = .{ .kind = .object, .fields = .{ .names = zx_shape_30, .ownership = zx_shape_59, .span_end = zx_shape_28, .span_start = zx_shape_28, .types = zx_shape_13, }, };

const zx_shape_61 = .{ .kind = .object, .fields = .{ .control = zx_shape_17, .expressions = zx_shape_35, .root = zx_shape_14, .stores = zx_shape_38, .symbols = zx_shape_60, }, };

const zx_shape_62 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_35, .predicate = zx_shape_4, .span_end = zx_shape_5, .span_start = zx_shape_5, .symbols = zx_shape_60, }, };

const zx_shape_63 = .{ .kind = .scalar, };

const zx_shape_64 = .{ .kind = .object, .fields = .{ .a = zx_shape_5, .b = zx_shape_5, .c = zx_shape_5, .phase = zx_shape_63, }, };

const zx_shape_65 = .{ .kind = .object, .fields = .{ .body = zx_shape_61, .functions = zx_shape_41, .output_type = zx_shape_4, .table = zx_shape_51, .transaction = zx_shape_1, .writer = zx_shape_44, }, };

const zx_shape_66 = .{ .kind = .object, .fields = .{ .concurrent = zx_shape_16, .pure = zx_shape_16, .returns = zx_shape_16, }, };

const zx_shape_67 = .{ .kind = .object, .fields = .{ .prepared = zx_shape_66, .program = zx_shape_65, }, };

const zx_shape_68 = .{ .kind = .object, .fields = .{ .context = zx_shape_67, .frame = zx_shape_64, }, };

const zx_shape_69 = .{ .kind = .scalar, };

const zx_shape_70 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_35, .payload = zx_shape_5, .truth = zx_shape_1, .writer = zx_shape_44, }, };

const zx_shape_71 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .index = zx_shape_5, .symbol = zx_shape_5, .writer = zx_shape_44, }, };

const zx_shape_72 = .{ .kind = .object, .fields = .{ .condition = zx_shape_5, .expressions = zx_shape_35, .truth = zx_shape_1, .writer = zx_shape_44, }, };

const zx_shape_73 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_35, .mark = zx_shape_5, .writer = zx_shape_44, }, };

const zx_shape_74 = .{ .kind = .object, .fields = .{ .context = zx_shape_67, .statement = zx_shape_5, }, };

const zx_shape_75 = .{ .kind = .object, .fields = .{ .frame = zx_shape_64, .writer = zx_shape_44, }, };

const zx_shape_76 = .{ .kind = .object, .fields = .{ .first = zx_shape_5, .index = zx_shape_5, .program = zx_shape_65, }, };

const zx_shape_77 = .{ .kind = .object, .fields = .{ .context = zx_shape_67, .first = zx_shape_5, .index = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_78 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .index = zx_shape_5, .writer = zx_shape_44, }, };

const zx_shape_79 = .{ .kind = .object, .fields = .{ .mode = zx_shape_69, .owner = zx_shape_5, .program = zx_shape_65, .symbol = zx_shape_5, .type_id = zx_shape_4, }, };

const zx_shape_80 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .owner = zx_shape_5, .program = zx_shape_65, .valid = zx_shape_1, }, };

const zx_shape_81 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .err = zx_shape_14, .expressions = zx_shape_35, .result = zx_shape_14, .value = zx_shape_5, .writer = zx_shape_44, }, };

const zx_shape_82 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .program = zx_shape_65, .type_first = zx_shape_5, .valid = zx_shape_1, }, };

const zx_shape_83 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .depth = zx_shape_5, .first = zx_shape_5, .flags = zx_shape_5, .values = zx_shape_13, .writer = zx_shape_44, }, };

const zx_shape_84 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .input = zx_shape_83, }, };

const zx_shape_85 = .{ .kind = .object, .fields = .{ .depth = zx_shape_5, .first = zx_shape_5, .flags = zx_shape_5, .index = zx_shape_5, .program = zx_shape_65, }, };

const zx_shape_86 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .expressions = zx_shape_35, .first = zx_shape_5, .writer = zx_shape_44, }, };

const zx_shape_87 = .{ .kind = .object, .fields = .{ .index = zx_shape_5, .input = zx_shape_86, }, };

const zx_shape_88 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .err = zx_shape_14, .expressions = zx_shape_35, .first = zx_shape_5, .index = zx_shape_5, .result = zx_shape_14, .symbol = zx_shape_4, }, };

const zx_shape_89 = .{ .kind = .object, .fields = .{ .depth = zx_shape_5, .first = zx_shape_5, .flags = zx_shape_5, .index = zx_shape_5, .owner = zx_shape_5, .program = zx_shape_65, }, };

const zx_shape_90 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .program = zx_shape_65, .valid = zx_shape_1, }, };

const zx_shape_91 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .program = zx_shape_65, }, };

const zx_shape_92 = .{ .kind = .object, .fields = .{ .input_types = zx_shape_13, .output_types = zx_shape_13, .stores = zx_shape_39, }, };

const zx_shape_93 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_35, .functions = zx_shape_92, .index = zx_shape_5, .orchestration = zx_shape_1, .stores = zx_shape_38, .symbols = zx_shape_60, .table = zx_shape_51, }, };

const zx_shape_94 = .{ .kind = .object, .fields = .{ .context = zx_shape_93, .kind = zx_shape_22, .payload = zx_shape_5, .target = zx_shape_49, .type_id = zx_shape_4, }, };

const zx_shape_95 = .{ .kind = .scalar, };

const zx_shape_96 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_35, .left = zx_shape_5, .right = zx_shape_5, }, };

const zx_shape_97 = .{ .kind = .object, .fields = .{ .payload = zx_shape_5, .program = zx_shape_65, }, };

const zx_shape_98 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, .has_default = zx_shape_1, .index = zx_shape_5, .program = zx_shape_65, .type_id = zx_shape_4, .valid = zx_shape_1, }, };

const zx_shape_99 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .first = zx_shape_5, .found = zx_shape_1, .index = zx_shape_5, .program = zx_shape_65, .value = zx_shape_5, }, };

const zx_shape_100 = .{ .kind = .object, .fields = .{ .depth = zx_shape_5, .first = zx_shape_5, .index = zx_shape_5, .program = zx_shape_65, }, };

const zx_shape_101 = .{ .kind = .object, .fields = .{ .context = zx_shape_67, .valid = zx_shape_1, }, };

const zx_shape_102 = .{ .kind = .object, .fields = .{ .count = zx_shape_5, .index = zx_shape_5, .valid = zx_shape_1, .writer = zx_shape_44, }, };

const zx_shape_103 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_65, }, };

const zx_shape_104 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_65, .@"1" = zx_shape_66, }, };

const zx_shape_105 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_65, .@"1" = zx_shape_66, .@"2" = zx_shape_1, }, };

pub const input_shape = zx_shape_65;

pub const output_shape = zx_shape_1;

pub const Input = *const (zx_abi).zx_type_65;

pub const Output = bool;

fn function_0(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_18) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if ((!block_30: {
        const operand_28 = ((in).control).selection_exhaustive;
        const operand_29 = (in).selection;

        if ((operand_29 >= (operand_28).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_30 (operand_28)[@intCast(operand_29)];
    })) {
        return false;
    }

    const value_1: u64 = (try function_0(allocator, block_27: {
        const operand_25 = ((in).control).selection_first;
        const operand_26 = (in).selection;

        if ((operand_26 >= (operand_25).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_27 (operand_25)[@intCast(operand_26)];
    }));
    const value_2: u64 = (try function_0(allocator, block_24: {
        const operand_22 = ((in).control).selection_count;
        const operand_23 = (in).selection;

        if ((operand_23 >= (operand_22).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_24 (operand_22)[@intCast(operand_23)];
    }));

    return block_21: {
        const operand_8 = block_7: {
            const operand_2 = ((in).control).case_bodies;
            const operand_3 = (in).returns;
            const operand_4 = value_1;
            const operand_5 = (value_1 + value_2);
            const operand_6 = true;

            break :block_7 (zx_abi).zx_type_19{ .bodies = operand_2, .returns = operand_3, .index = operand_4, .end = operand_5, .all = operand_6, };
        };

        var state_1: (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .all = (operand_8).all, .bodies = (operand_8).bodies, .end = (operand_8).end, .index = (operand_8).index, .returns = (operand_8).returns, .zx_origin = (&operand_8), };

        while (((state_1).all and ((state_1).index < (state_1).end))) {
            state_1 = block_20: {
                const value_5: (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = state_1;
                const value_6: (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_19: {
                    break :block_19 @as((zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .all = block_18: {
                        const operand_16 = (state_1).returns;
                        const operand_17 = block_15: {
                            const operand_14 = block_13: {
                                const operand_11 = (state_1).bodies;
                                const operand_12 = (state_1).index;

                                if ((operand_12 >= (operand_11).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_13 (operand_11)[@intCast(operand_12)];
                            };

                            break :block_15 (try function_0(allocator, operand_14));
                        };

                        if ((operand_17 >= (operand_16).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_18 (operand_16)[@intCast(operand_17)];
                    }, .bodies = (value_5).bodies, .end = (value_5).end, .index = (value_5).index, .returns = (value_5).returns, });
                };
                const value_7: (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = value_6;
                const value_8: u64 = (value_7).index;
                const value_9: (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_10: {
                    break :block_10 @as((zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .all = (value_7).all, .bodies = (value_7).bodies, .end = (value_7).end, .index = (block_9: {
                        break :block_9 value_8;
                    } + @as(u64, 1)), .returns = (value_7).returns, });
                };

                break :block_20 value_9;
            };
        }

        break :block_21 (state_1).all;
    };
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_17) error{ IndexOutOfBounds, OutOfMemory, Overflow, }![]const bool {
    @setRuntimeSafety(true);

    const value_1: []const bool = block_86: {
        break :block_86 (try (allocator).dupe(bool, (&[_]bool{})));
    };
    const value_28: *const (zx_abi).zx_type_20 = block_85: {
        const operand_8 = block_7: {
            const operand_2 = in;
            const operand_3 = @as(u64, 0);
            const operand_4 = value_1;

            break :block_7 block_6: {
                const operand_5 = (try (allocator).create((zx_abi).zx_type_20));

                (operand_5).* = @as((zx_abi).zx_type_20, (zx_abi).zx_type_20{ .control = operand_2, .block = operand_3, .returns = operand_4, });

                break :block_6 @as(*const (zx_abi).zx_type_20, operand_5);
            };
        };

        var state_capacity_10: (std).ArrayList(bool) = .empty;

        var state_capacity_started_11 = false;

        defer (state_capacity_10).deinit(allocator);

        const state_type_12 = struct {
            block_count: []const u32,
            block_first: []const u32,
            branch_conditions: []const u32,
            branch_no: []const u32,
            branch_yes: []const u32,
            case_bodies: []const u32,
            case_values: []const ?u32,
            constant_symbols: []const u32,
            constant_values: []const u32,
            destructure_count: []const u32,
            destructure_first: []const u32,
            destructure_symbols: []const ?u32,
            destructure_values: []const u32,
            evaluations: []const u32,
            parallel_count: []const u32,
            parallel_first: []const u32,
            parallel_symbols: []const ?u32,
            parallel_values: []const u32,
            results: []const ?u32,
            selection_count: []const u32,
            selection_exhaustive: []const bool,
            selection_first: []const u32,
            selection_subjects: []const u32,
            setter_slots: []const u32,
            setter_values: []const u32,
            statement_kinds: []const (zx_abi).zx_type_11,
            statement_payloads: []const u32,
        };
        const state_type_13 = struct {
            block: u64,
            control: state_type_12,
            returns: []const bool,
        };
        const state_type_15 = struct { []const bool, void, };
        const state_type_47 = struct {
            control: state_type_12,
            returns: []const bool,
            selection: u64,
        };

        var state_1: state_type_13 = state_type_13{ .block = (operand_8).block, .control = state_type_12{ .block_count = ((operand_8).control).block_count, .block_first = ((operand_8).control).block_first, .branch_conditions = ((operand_8).control).branch_conditions, .branch_no = ((operand_8).control).branch_no, .branch_yes = ((operand_8).control).branch_yes, .case_bodies = ((operand_8).control).case_bodies, .case_values = ((operand_8).control).case_values, .constant_symbols = ((operand_8).control).constant_symbols, .constant_values = ((operand_8).control).constant_values, .destructure_count = ((operand_8).control).destructure_count, .destructure_first = ((operand_8).control).destructure_first, .destructure_symbols = ((operand_8).control).destructure_symbols, .destructure_values = ((operand_8).control).destructure_values, .evaluations = ((operand_8).control).evaluations, .parallel_count = ((operand_8).control).parallel_count, .parallel_first = ((operand_8).control).parallel_first, .parallel_symbols = ((operand_8).control).parallel_symbols, .parallel_values = ((operand_8).control).parallel_values, .results = ((operand_8).control).results, .selection_count = ((operand_8).control).selection_count, .selection_exhaustive = ((operand_8).control).selection_exhaustive, .selection_first = ((operand_8).control).selection_first, .selection_subjects = ((operand_8).control).selection_subjects, .setter_slots = ((operand_8).control).setter_slots, .setter_values = ((operand_8).control).setter_values, .statement_kinds = ((operand_8).control).statement_kinds, .statement_payloads = ((operand_8).control).statement_payloads, }, .returns = (operand_8).returns, };

        var state_changed_9 = false;

        while (((state_1).block < @as(u64, (((state_1).control).block_first).len))) {
            state_1 = block_78: {
                const value_4: u64 = (try function_0(allocator, block_77: {
                    const operand_75 = ((state_1).control).block_count;
                    const operand_76 = (state_1).block;

                    if ((operand_76 >= (operand_75).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_77 (operand_75)[@intCast(operand_76)];
                }));
                const value_24: state_type_13 = (if ((value_4 == @as(u64, 0))) block_20: {
                    const value_5: state_type_13 = state_1;
                    const value_6: state_type_13 = block_19: {
                        break :block_19 state_type_13{ .block = (value_5).block, .control = (value_5).control, .returns = (block_18: {
                            const operand_16 = (state_1).returns;
                            const operand_17 = false;

                            _ = (try ((std).math).add(usize, (operand_16).len, 1));

                            if ((!state_capacity_started_11)) {
                                (try (state_capacity_10).appendSlice(allocator, operand_16));

                                state_capacity_started_11 = true;
                            } else {
                                ((state_capacity_10).items).len = (operand_16).len;
                            }

                            (try (state_capacity_10).append(allocator, operand_17));

                            break :block_18 @as(state_type_15, .{ (state_capacity_10).items, {}, });
                        }).@"0", };
                    };

                    break :block_20 value_6;
                } else block_74: {
                    const value_7: u64 = (((try function_0(allocator, block_73: {
                        const operand_71 = ((state_1).control).block_first;
                        const operand_72 = (state_1).block;

                        if ((operand_72 >= (operand_71).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_73 (operand_71)[@intCast(operand_72)];
                    })) + value_4) - @as(u64, 1));
                    const value_8: (zx_abi).zx_type_11 = block_70: {
                        const operand_68 = ((state_1).control).statement_kinds;
                        const operand_69 = value_7;

                        if ((operand_69 >= (operand_68).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_70 (operand_68)[@intCast(operand_69)];
                    };
                    const value_9: u64 = (try function_0(allocator, block_67: {
                        const operand_65 = ((state_1).control).statement_payloads;
                        const operand_66 = value_7;

                        if ((operand_66 >= (operand_65).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_67 (operand_65)[@intCast(operand_66)];
                    }));
                    const value_23: state_type_13 = (if ((value_8 == @as((zx_abi).zx_type_11, .Result))) block_25: {
                        const value_10: state_type_13 = state_1;
                        const value_11: state_type_13 = block_24: {
                            break :block_24 state_type_13{ .block = (value_10).block, .control = (value_10).control, .returns = (block_23: {
                                const operand_21 = (state_1).returns;
                                const operand_22 = true;

                                _ = (try ((std).math).add(usize, (operand_21).len, 1));

                                if ((!state_capacity_started_11)) {
                                    (try (state_capacity_10).appendSlice(allocator, operand_21));

                                    state_capacity_started_11 = true;
                                } else {
                                    ((state_capacity_10).items).len = (operand_21).len;
                                }

                                (try (state_capacity_10).append(allocator, operand_22));

                                break :block_23 @as(state_type_15, .{ (state_capacity_10).items, {}, });
                            }).@"0", };
                        };

                        break :block_25 value_11;
                    } else block_64: {
                        const value_22: state_type_13 = (if ((value_8 == @as((zx_abi).zx_type_11, .Branch))) block_42: {
                            const value_12: u64 = (try function_0(allocator, block_41: {
                                const operand_39 = ((state_1).control).branch_yes;
                                const operand_40 = value_9;

                                if ((operand_40 >= (operand_39).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_41 (operand_39)[@intCast(operand_40)];
                            }));
                            const value_13: u64 = (try function_0(allocator, block_38: {
                                const operand_36 = ((state_1).control).branch_no;
                                const operand_37 = value_9;

                                if ((operand_37 >= (operand_36).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_38 (operand_36)[@intCast(operand_37)];
                            }));
                            const value_14: state_type_13 = state_1;
                            const value_15: state_type_13 = block_35: {
                                break :block_35 state_type_13{ .block = (value_14).block, .control = (value_14).control, .returns = (block_34: {
                                    const operand_26 = (state_1).returns;
                                    const operand_33 = (block_29: {
                                        const operand_27 = (state_1).returns;
                                        const operand_28 = value_12;

                                        if ((operand_28 >= (operand_27).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_29 (operand_27)[@intCast(operand_28)];
                                    } and block_32: {
                                        const operand_30 = (state_1).returns;
                                        const operand_31 = value_13;

                                        if ((operand_31 >= (operand_30).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_32 (operand_30)[@intCast(operand_31)];
                                    });

                                    _ = (try ((std).math).add(usize, (operand_26).len, 1));

                                    if ((!state_capacity_started_11)) {
                                        (try (state_capacity_10).appendSlice(allocator, operand_26));

                                        state_capacity_started_11 = true;
                                    } else {
                                        ((state_capacity_10).items).len = (operand_26).len;
                                    }

                                    (try (state_capacity_10).append(allocator, operand_33));

                                    break :block_34 @as(state_type_15, .{ (state_capacity_10).items, {}, });
                                }).@"0", };
                            };

                            break :block_42 value_15;
                        } else block_63: {
                            const value_21: state_type_13 = (if ((value_8 == @as((zx_abi).zx_type_11, .Switch))) block_57: {
                                const value_16: bool = block_56: {
                                    const operand_52 = block_51: {
                                        const operand_48 = (state_1).control;
                                        const operand_49 = value_9;
                                        const operand_50 = (state_1).returns;

                                        break :block_51 state_type_47{ .control = operand_48, .selection = operand_49, .returns = operand_50, };
                                    };
                                    const operand_53 = (zx_abi).zx_type_17{ .block_count = ((operand_52).control).block_count, .block_first = ((operand_52).control).block_first, .branch_conditions = ((operand_52).control).branch_conditions, .branch_no = ((operand_52).control).branch_no, .branch_yes = ((operand_52).control).branch_yes, .case_bodies = ((operand_52).control).case_bodies, .case_values = ((operand_52).control).case_values, .constant_symbols = ((operand_52).control).constant_symbols, .constant_values = ((operand_52).control).constant_values, .destructure_count = ((operand_52).control).destructure_count, .destructure_first = ((operand_52).control).destructure_first, .destructure_symbols = ((operand_52).control).destructure_symbols, .destructure_values = ((operand_52).control).destructure_values, .evaluations = ((operand_52).control).evaluations, .parallel_count = ((operand_52).control).parallel_count, .parallel_first = ((operand_52).control).parallel_first, .parallel_symbols = ((operand_52).control).parallel_symbols, .parallel_values = ((operand_52).control).parallel_values, .results = ((operand_52).control).results, .selection_count = ((operand_52).control).selection_count, .selection_exhaustive = ((operand_52).control).selection_exhaustive, .selection_first = ((operand_52).control).selection_first, .selection_subjects = ((operand_52).control).selection_subjects, .setter_slots = ((operand_52).control).setter_slots, .setter_values = ((operand_52).control).setter_values, .statement_kinds = ((operand_52).control).statement_kinds, .statement_payloads = ((operand_52).control).statement_payloads, };
                                    const operand_54 = (zx_abi).zx_type_18{ .control = (&operand_53), .returns = (operand_52).returns, .selection = (operand_52).selection, };
                                    const operand_55 = (try function_2(allocator, (&operand_54)));

                                    break :block_56 operand_55;
                                };
                                const value_17: state_type_13 = state_1;
                                const value_18: state_type_13 = block_46: {
                                    break :block_46 state_type_13{ .block = (value_17).block, .control = (value_17).control, .returns = (block_45: {
                                        const operand_43 = (state_1).returns;
                                        const operand_44 = value_16;

                                        _ = (try ((std).math).add(usize, (operand_43).len, 1));

                                        if ((!state_capacity_started_11)) {
                                            (try (state_capacity_10).appendSlice(allocator, operand_43));

                                            state_capacity_started_11 = true;
                                        } else {
                                            ((state_capacity_10).items).len = (operand_43).len;
                                        }

                                        (try (state_capacity_10).append(allocator, operand_44));

                                        break :block_45 @as(state_type_15, .{ (state_capacity_10).items, {}, });
                                    }).@"0", };
                                };

                                break :block_57 value_18;
                            } else block_62: {
                                const value_19: state_type_13 = state_1;
                                const value_20: state_type_13 = block_61: {
                                    break :block_61 state_type_13{ .block = (value_19).block, .control = (value_19).control, .returns = (block_60: {
                                        const operand_58 = (state_1).returns;
                                        const operand_59 = false;

                                        _ = (try ((std).math).add(usize, (operand_58).len, 1));

                                        if ((!state_capacity_started_11)) {
                                            (try (state_capacity_10).appendSlice(allocator, operand_58));

                                            state_capacity_started_11 = true;
                                        } else {
                                            ((state_capacity_10).items).len = (operand_58).len;
                                        }

                                        (try (state_capacity_10).append(allocator, operand_59));

                                        break :block_60 @as(state_type_15, .{ (state_capacity_10).items, {}, });
                                    }).@"0", };
                                };

                                break :block_62 value_20;
                            });

                            break :block_63 value_21;
                        });

                        break :block_64 value_22;
                    });

                    break :block_74 value_23;
                });
                const value_25: state_type_13 = value_24;
                const value_26: u64 = (value_25).block;
                const value_27: state_type_13 = block_14: {
                    break :block_14 state_type_13{ .block = (value_26 + @as(u64, 1)), .control = (value_25).control, .returns = (value_25).returns, };
                };

                break :block_78 value_27;
            };

            state_changed_9 = true;
        }

        var state_owned_79: []const bool = (&[_]bool{});

        errdefer (allocator).free(state_owned_79);

        if (state_capacity_started_11) {
            ((state_capacity_10).items).len = ((state_1).returns).len;

            state_owned_79 = (try (state_capacity_10).toOwnedSlice(allocator));
        }

        if (state_capacity_started_11) {
            (state_1).returns = state_owned_79;
        }

        break :block_85 (if (state_changed_9) block_84: {
            const operand_83 = (try (allocator).create((zx_abi).zx_type_20));

            (operand_83).* = @as((zx_abi).zx_type_20, (zx_abi).zx_type_20{ .block = (state_1).block, .control = block_82: {
                const operand_81 = (try (allocator).create((zx_abi).zx_type_17));

                (operand_81).* = @as((zx_abi).zx_type_17, (zx_abi).zx_type_17{ .block_count = ((state_1).control).block_count, .block_first = ((state_1).control).block_first, .branch_conditions = ((state_1).control).branch_conditions, .branch_no = ((state_1).control).branch_no, .branch_yes = ((state_1).control).branch_yes, .case_bodies = ((state_1).control).case_bodies, .case_values = ((state_1).control).case_values, .constant_symbols = ((state_1).control).constant_symbols, .constant_values = ((state_1).control).constant_values, .destructure_count = ((state_1).control).destructure_count, .destructure_first = ((state_1).control).destructure_first, .destructure_symbols = ((state_1).control).destructure_symbols, .destructure_values = ((state_1).control).destructure_values, .evaluations = ((state_1).control).evaluations, .parallel_count = ((state_1).control).parallel_count, .parallel_first = ((state_1).control).parallel_first, .parallel_symbols = ((state_1).control).parallel_symbols, .parallel_values = ((state_1).control).parallel_values, .results = ((state_1).control).results, .selection_count = ((state_1).control).selection_count, .selection_exhaustive = ((state_1).control).selection_exhaustive, .selection_first = ((state_1).control).selection_first, .selection_subjects = ((state_1).control).selection_subjects, .setter_slots = ((state_1).control).setter_slots, .setter_values = ((state_1).control).setter_values, .statement_kinds = ((state_1).control).statement_kinds, .statement_payloads = ((state_1).control).statement_payloads, });

                break :block_82 @as(*const (zx_abi).zx_type_17, operand_81);
            }, .returns = (state_1).returns, });

            break :block_84 @as(*const (zx_abi).zx_type_20, operand_83);
        } else operand_8);
    };

    return (value_28).returns;
}

fn function_4(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_36) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    return block_50: {
        const operand_9 = block_8: {
            const operand_2 = (in).expressions;
            const operand_3 = (in).allowed;
            const operand_4 = (in).limit;
            const operand_5 = (in).concurrent;
            const operand_6 = @as(u64, 0);
            const operand_7 = true;

            break :block_8 (zx_abi).zx_type_37{ .expressions = operand_2, .allowed = operand_3, .limit = operand_4, .concurrent = operand_5, .index = operand_6, .valid = operand_7, };
        };

        var state_1: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .allowed = (operand_9).allowed, .concurrent = (operand_9).concurrent, .expressions = (operand_9).expressions, .index = (operand_9).index, .limit = (operand_9).limit, .valid = (operand_9).valid, .zx_origin = (&operand_9), };

        while (((state_1).valid and ((state_1).index < @as(u64, (((state_1).expressions).kinds).len)))) {
            state_1 = block_49: {
                const value_3: (zx_abi).zx_type_22 = block_48: {
                    const operand_46 = ((state_1).expressions).kinds;
                    const operand_47 = (state_1).index;

                    if ((operand_47 >= (operand_46).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_48 (operand_46)[@intCast(operand_47)];
                };
                const value_14: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (if ((block_12: {
                    break :block_12 value_3;
                } == @as((zx_abi).zx_type_22, .StoreGet))) block_14: {
                    const value_4: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = state_1;
                    const value_5: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_13: {
                        break :block_13 @as((zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .allowed = (value_4).allowed, .concurrent = (value_4).concurrent, .expressions = (value_4).expressions, .index = (value_4).index, .limit = (value_4).limit, .valid = false, });
                    };

                    break :block_14 value_5;
                } else block_45: {
                    const value_13: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (if (((!(state_1).concurrent) and ((((block_15: {
                        break :block_15 value_3;
                    } == @as((zx_abi).zx_type_22, .Task)) or (block_16: {
                        break :block_16 value_3;
                    } == @as((zx_abi).zx_type_22, .AwaitTask))) or (block_17: {
                        break :block_17 value_3;
                    } == @as((zx_abi).zx_type_22, .CancelTask))) or (block_18: {
                        break :block_18 value_3;
                    } == @as((zx_abi).zx_type_22, .Parallel))))) block_20: {
                        const value_6: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = state_1;
                        const value_7: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_19: {
                            break :block_19 @as((zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .allowed = (value_6).allowed, .concurrent = (value_6).concurrent, .expressions = (value_6).expressions, .index = (value_6).index, .limit = (value_6).limit, .valid = false, });
                        };

                        break :block_20 value_7;
                    } else block_44: {
                        const value_12: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (if ((block_21: {
                            break :block_21 value_3;
                        } == @as((zx_abi).zx_type_22, .Call))) block_43: {
                            const value_8: u64 = block_42: {
                                const operand_41 = block_40: {
                                    const operand_38 = ((state_1).expressions).payloads;
                                    const operand_39 = (state_1).index;

                                    if ((operand_39 >= (operand_38).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_40 (operand_38)[@intCast(operand_39)];
                                };

                                break :block_42 (try function_0(allocator, operand_41));
                            };
                            const value_9: u64 = block_37: {
                                const operand_36 = block_35: {
                                    const operand_33 = ((state_1).expressions).call_functions;
                                    const operand_34 = block_32: {
                                        break :block_32 value_8;
                                    };

                                    if ((operand_34 >= (operand_33).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_35 (operand_33)[@intCast(operand_34)];
                                };

                                break :block_37 (try function_0(allocator, operand_36));
                            };
                            const value_10: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = state_1;
                            const value_11: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_31: {
                                break :block_31 @as((zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .allowed = (value_10).allowed, .concurrent = (value_10).concurrent, .expressions = (value_10).expressions, .index = (value_10).index, .limit = (value_10).limit, .valid = (((block_25: {
                                    const operand_23 = ((state_1).expressions).call_store_count;
                                    const operand_24 = block_22: {
                                        break :block_22 value_8;
                                    };

                                    if ((operand_24 >= (operand_23).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_25 (operand_23)[@intCast(operand_24)];
                                } == @as(u32, 0)) and (block_26: {
                                    break :block_26 value_9;
                                } < (state_1).limit)) and block_30: {
                                    const operand_28 = (state_1).allowed;
                                    const operand_29 = block_27: {
                                        break :block_27 value_9;
                                    };

                                    if ((operand_29 >= (operand_28).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_30 (operand_28)[@intCast(operand_29)];
                                }), });
                            };

                            break :block_43 value_11;
                        } else state_1);

                        break :block_44 value_12;
                    });

                    break :block_45 value_13;
                });
                const value_15: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = value_14;
                const value_16: u64 = (value_15).index;
                const value_17: (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_11: {
                    break :block_11 @as((zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .allowed = (value_15).allowed, .concurrent = (value_15).concurrent, .expressions = (value_15).expressions, .index = (block_10: {
                        break :block_10 value_16;
                    } + @as(u64, 1)), .limit = (value_15).limit, .valid = (value_15).valid, });
                };

                break :block_49 value_17;
            };
        }

        break :block_50 (state_1).valid;
    };
}

fn function_5(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_42) error{ IndexOutOfBounds, OutOfMemory, }![]const bool {
    @setRuntimeSafety(true);

    const value_2: []const bool = block_61: {
        const operand_58 = ((in).functions).native_modules;
        const operand_59 = (try (allocator).alloc(bool, (operand_58).len));

        for (operand_58, 0..) |_, index_60| {
            (operand_59)[index_60] = false;
        }

        break :block_61 operand_59;
    };
    const value_13: *const (zx_abi).zx_type_43 = block_57: {
        const operand_9 = block_8: {
            const operand_2 = (in).functions;
            const operand_3 = (in).concurrent;
            const operand_4 = value_2;
            const operand_5 = @as(u64, 0);

            break :block_8 block_7: {
                const operand_6 = (try (allocator).create((zx_abi).zx_type_43));

                (operand_6).* = @as((zx_abi).zx_type_43, (zx_abi).zx_type_43{ .functions = operand_2, .concurrent = operand_3, .values = operand_4, .index = operand_5, });

                break :block_7 @as(*const (zx_abi).zx_type_43, operand_6);
            };
        };

        var state_items_11: []bool = undefined;

        var state_items_started_12 = false;

        const state_type_13 = struct {
            expressions: []const *const (zx_abi).zx_type_35,
            native_concurrent: []const bool,
            native_modules: []const ?u32,
            stores: []const *const (zx_abi).zx_type_38,
        };
        const state_type_14 = struct {
            concurrent: bool,
            functions: state_type_13,
            index: u64,
            values: []const bool,
        };
        const state_type_26 = struct {
            handles: []const []const u8,
            paths: []const []const u8,
            readable: []const bool,
            types: []const u32,
            writable: []const bool,
        };
        const state_type_34 = struct {
            awaits: []const u32,
            binary_left: []const u32,
            binary_operators: []const (zx_abi).zx_type_26,
            binary_right: []const u32,
            booleans: []const bool,
            call_arguments: []const u32,
            call_functions: []const u32,
            call_store_count: []const u32,
            call_store_first: []const u32,
            call_stores: []const u32,
            cancellations: []const u32,
            captures: []const u32,
            collection_arguments: []const u32,
            collection_count: []const u32,
            collection_first: []const u32,
            collection_kinds: []const (zx_abi).zx_type_23,
            collection_targets: []const u32,
            conditional_conditions: []const u32,
            conditional_no: []const u32,
            conditional_yes: []const u32,
            enumerations: []const u32,
            errors: []const u32,
            floats: []const f64,
            index_targets: []const u32,
            index_values: []const u32,
            integers: []const u64,
            iteration_bodies: []const u32,
            iteration_condition_parameters: []const u32,
            iteration_conditions: []const u32,
            iteration_initials: []const u32,
            iteration_parameters: []const u32,
            iteration_postconditions: []const bool,
            kinds: []const (zx_abi).zx_type_22,
            lengths: []const u32,
            match_conditions: []const u32,
            match_count: []const u32,
            match_fallbacks: []const u32,
            match_first: []const u32,
            match_results: []const u32,
            match_subjects: []const ?u32,
            negative_integers: []const u64,
            object_count: []const u32,
            object_evaluation_count: []const u32,
            object_evaluation_first: []const u32,
            object_evaluation_values: []const u32,
            object_field_indices: []const u32,
            object_field_values: []const u32,
            object_first: []const u32,
            optional_values: []const u32,
            parallel_count: []const u32,
            parallel_fields: []const ?u32,
            parallel_first: []const u32,
            parallel_tasks: []const u32,
            payloads: []const u32,
            projection_indices: []const u32,
            projection_targets: []const u32,
            references: []const u32,
            scope_borrows: []const bool,
            scope_count: []const u32,
            scope_first: []const u32,
            scope_results: []const u32,
            scope_symbols: []const ?u32,
            scope_values: []const u32,
            sequence_count: []const u32,
            sequence_first: []const u32,
            sequence_items: []const u32,
            some: []const u32,
            span_end: []const u64,
            span_start: []const u64,
            stores: []const u32,
            strings: []const []const u8,
            task_bodies: []const u32,
            task_capture_count: []const u32,
            task_capture_first: []const u32,
            task_captures: []const u32,
            transform_bodies: []const u32,
            transform_count: []const u32,
            transform_first: []const u32,
            transform_initials: []const ?u32,
            transform_kinds: []const (zx_abi).zx_type_24,
            transform_parameters: []const u32,
            transform_targets: []const u32,
            types: []const u32,
            unary_operands: []const u32,
            unary_operators: []const (zx_abi).zx_type_25,
            update_indices: []const u32,
            update_targets: []const u32,
            update_values: []const u32,
        };
        const state_type_35 = struct {
            allowed: []const bool,
            concurrent: bool,
            expressions: state_type_34,
            limit: u64,
        };

        var state_1: state_type_14 = state_type_14{ .concurrent = (operand_9).concurrent, .functions = state_type_13{ .expressions = ((operand_9).functions).expressions, .native_concurrent = ((operand_9).functions).native_concurrent, .native_modules = ((operand_9).functions).native_modules, .stores = ((operand_9).functions).stores, }, .index = (operand_9).index, .values = (operand_9).values, };

        var state_changed_10 = false;

        while (((state_1).index < @as(u64, ((state_1).values).len))) {
            state_1 = block_51: {
                const value_5: bool = ((@as(u64, ((block_27: {
                    const operand_25 = block_24: {
                        const operand_22 = ((state_1).functions).stores;
                        const operand_23 = (state_1).index;

                        if ((operand_23 >= (operand_22).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_24 (operand_22)[@intCast(operand_23)];
                    };

                    break :block_27 state_type_26{ .handles = (operand_25).handles, .paths = (operand_25).paths, .readable = (operand_25).readable, .types = (operand_25).types, .writable = (operand_25).writable, };
                }).paths).len) == @as(u64, 0)) and (if ((block_30: {
                    const operand_28 = ((state_1).functions).native_modules;
                    const operand_29 = (state_1).index;

                    if ((operand_29 >= (operand_28).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_30 (operand_28)[@intCast(operand_29)];
                } != null)) ((state_1).concurrent and block_33: {
                    const operand_31 = ((state_1).functions).native_concurrent;
                    const operand_32 = (state_1).index;

                    if ((operand_32 >= (operand_31).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_33 (operand_31)[@intCast(operand_32)];
                }) else block_50: {
                    const operand_46 = block_45: {
                        const operand_41 = block_40: {
                            const operand_39 = block_38: {
                                const operand_36 = ((state_1).functions).expressions;
                                const operand_37 = (state_1).index;

                                if ((operand_37 >= (operand_36).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_38 (operand_36)[@intCast(operand_37)];
                            };

                            break :block_40 state_type_34{ .awaits = (operand_39).awaits, .binary_left = (operand_39).binary_left, .binary_operators = (operand_39).binary_operators, .binary_right = (operand_39).binary_right, .booleans = (operand_39).booleans, .call_arguments = (operand_39).call_arguments, .call_functions = (operand_39).call_functions, .call_store_count = (operand_39).call_store_count, .call_store_first = (operand_39).call_store_first, .call_stores = (operand_39).call_stores, .cancellations = (operand_39).cancellations, .captures = (operand_39).captures, .collection_arguments = (operand_39).collection_arguments, .collection_count = (operand_39).collection_count, .collection_first = (operand_39).collection_first, .collection_kinds = (operand_39).collection_kinds, .collection_targets = (operand_39).collection_targets, .conditional_conditions = (operand_39).conditional_conditions, .conditional_no = (operand_39).conditional_no, .conditional_yes = (operand_39).conditional_yes, .enumerations = (operand_39).enumerations, .errors = (operand_39).errors, .floats = (operand_39).floats, .index_targets = (operand_39).index_targets, .index_values = (operand_39).index_values, .integers = (operand_39).integers, .iteration_bodies = (operand_39).iteration_bodies, .iteration_condition_parameters = (operand_39).iteration_condition_parameters, .iteration_conditions = (operand_39).iteration_conditions, .iteration_initials = (operand_39).iteration_initials, .iteration_parameters = (operand_39).iteration_parameters, .iteration_postconditions = (operand_39).iteration_postconditions, .kinds = (operand_39).kinds, .lengths = (operand_39).lengths, .match_conditions = (operand_39).match_conditions, .match_count = (operand_39).match_count, .match_fallbacks = (operand_39).match_fallbacks, .match_first = (operand_39).match_first, .match_results = (operand_39).match_results, .match_subjects = (operand_39).match_subjects, .negative_integers = (operand_39).negative_integers, .object_count = (operand_39).object_count, .object_evaluation_count = (operand_39).object_evaluation_count, .object_evaluation_first = (operand_39).object_evaluation_first, .object_evaluation_values = (operand_39).object_evaluation_values, .object_field_indices = (operand_39).object_field_indices, .object_field_values = (operand_39).object_field_values, .object_first = (operand_39).object_first, .optional_values = (operand_39).optional_values, .parallel_count = (operand_39).parallel_count, .parallel_fields = (operand_39).parallel_fields, .parallel_first = (operand_39).parallel_first, .parallel_tasks = (operand_39).parallel_tasks, .payloads = (operand_39).payloads, .projection_indices = (operand_39).projection_indices, .projection_targets = (operand_39).projection_targets, .references = (operand_39).references, .scope_borrows = (operand_39).scope_borrows, .scope_count = (operand_39).scope_count, .scope_first = (operand_39).scope_first, .scope_results = (operand_39).scope_results, .scope_symbols = (operand_39).scope_symbols, .scope_values = (operand_39).scope_values, .sequence_count = (operand_39).sequence_count, .sequence_first = (operand_39).sequence_first, .sequence_items = (operand_39).sequence_items, .some = (operand_39).some, .span_end = (operand_39).span_end, .span_start = (operand_39).span_start, .stores = (operand_39).stores, .strings = (operand_39).strings, .task_bodies = (operand_39).task_bodies, .task_capture_count = (operand_39).task_capture_count, .task_capture_first = (operand_39).task_capture_first, .task_captures = (operand_39).task_captures, .transform_bodies = (operand_39).transform_bodies, .transform_count = (operand_39).transform_count, .transform_first = (operand_39).transform_first, .transform_initials = (operand_39).transform_initials, .transform_kinds = (operand_39).transform_kinds, .transform_parameters = (operand_39).transform_parameters, .transform_targets = (operand_39).transform_targets, .types = (operand_39).types, .unary_operands = (operand_39).unary_operands, .unary_operators = (operand_39).unary_operators, .update_indices = (operand_39).update_indices, .update_targets = (operand_39).update_targets, .update_values = (operand_39).update_values, };
                        };
                        const operand_42 = (state_1).values;
                        const operand_43 = (state_1).index;
                        const operand_44 = (state_1).concurrent;

                        break :block_45 state_type_35{ .expressions = operand_41, .allowed = operand_42, .limit = operand_43, .concurrent = operand_44, };
                    };
                    const operand_47 = (zx_abi).zx_type_35{ .awaits = ((operand_46).expressions).awaits, .binary_left = ((operand_46).expressions).binary_left, .binary_operators = ((operand_46).expressions).binary_operators, .binary_right = ((operand_46).expressions).binary_right, .booleans = ((operand_46).expressions).booleans, .call_arguments = ((operand_46).expressions).call_arguments, .call_functions = ((operand_46).expressions).call_functions, .call_store_count = ((operand_46).expressions).call_store_count, .call_store_first = ((operand_46).expressions).call_store_first, .call_stores = ((operand_46).expressions).call_stores, .cancellations = ((operand_46).expressions).cancellations, .captures = ((operand_46).expressions).captures, .collection_arguments = ((operand_46).expressions).collection_arguments, .collection_count = ((operand_46).expressions).collection_count, .collection_first = ((operand_46).expressions).collection_first, .collection_kinds = ((operand_46).expressions).collection_kinds, .collection_targets = ((operand_46).expressions).collection_targets, .conditional_conditions = ((operand_46).expressions).conditional_conditions, .conditional_no = ((operand_46).expressions).conditional_no, .conditional_yes = ((operand_46).expressions).conditional_yes, .enumerations = ((operand_46).expressions).enumerations, .errors = ((operand_46).expressions).errors, .floats = ((operand_46).expressions).floats, .index_targets = ((operand_46).expressions).index_targets, .index_values = ((operand_46).expressions).index_values, .integers = ((operand_46).expressions).integers, .iteration_bodies = ((operand_46).expressions).iteration_bodies, .iteration_condition_parameters = ((operand_46).expressions).iteration_condition_parameters, .iteration_conditions = ((operand_46).expressions).iteration_conditions, .iteration_initials = ((operand_46).expressions).iteration_initials, .iteration_parameters = ((operand_46).expressions).iteration_parameters, .iteration_postconditions = ((operand_46).expressions).iteration_postconditions, .kinds = ((operand_46).expressions).kinds, .lengths = ((operand_46).expressions).lengths, .match_conditions = ((operand_46).expressions).match_conditions, .match_count = ((operand_46).expressions).match_count, .match_fallbacks = ((operand_46).expressions).match_fallbacks, .match_first = ((operand_46).expressions).match_first, .match_results = ((operand_46).expressions).match_results, .match_subjects = ((operand_46).expressions).match_subjects, .negative_integers = ((operand_46).expressions).negative_integers, .object_count = ((operand_46).expressions).object_count, .object_evaluation_count = ((operand_46).expressions).object_evaluation_count, .object_evaluation_first = ((operand_46).expressions).object_evaluation_first, .object_evaluation_values = ((operand_46).expressions).object_evaluation_values, .object_field_indices = ((operand_46).expressions).object_field_indices, .object_field_values = ((operand_46).expressions).object_field_values, .object_first = ((operand_46).expressions).object_first, .optional_values = ((operand_46).expressions).optional_values, .parallel_count = ((operand_46).expressions).parallel_count, .parallel_fields = ((operand_46).expressions).parallel_fields, .parallel_first = ((operand_46).expressions).parallel_first, .parallel_tasks = ((operand_46).expressions).parallel_tasks, .payloads = ((operand_46).expressions).payloads, .projection_indices = ((operand_46).expressions).projection_indices, .projection_targets = ((operand_46).expressions).projection_targets, .references = ((operand_46).expressions).references, .scope_borrows = ((operand_46).expressions).scope_borrows, .scope_count = ((operand_46).expressions).scope_count, .scope_first = ((operand_46).expressions).scope_first, .scope_results = ((operand_46).expressions).scope_results, .scope_symbols = ((operand_46).expressions).scope_symbols, .scope_values = ((operand_46).expressions).scope_values, .sequence_count = ((operand_46).expressions).sequence_count, .sequence_first = ((operand_46).expressions).sequence_first, .sequence_items = ((operand_46).expressions).sequence_items, .some = ((operand_46).expressions).some, .span_end = ((operand_46).expressions).span_end, .span_start = ((operand_46).expressions).span_start, .stores = ((operand_46).expressions).stores, .strings = ((operand_46).expressions).strings, .task_bodies = ((operand_46).expressions).task_bodies, .task_capture_count = ((operand_46).expressions).task_capture_count, .task_capture_first = ((operand_46).expressions).task_capture_first, .task_captures = ((operand_46).expressions).task_captures, .transform_bodies = ((operand_46).expressions).transform_bodies, .transform_count = ((operand_46).expressions).transform_count, .transform_first = ((operand_46).expressions).transform_first, .transform_initials = ((operand_46).expressions).transform_initials, .transform_kinds = ((operand_46).expressions).transform_kinds, .transform_parameters = ((operand_46).expressions).transform_parameters, .transform_targets = ((operand_46).expressions).transform_targets, .types = ((operand_46).expressions).types, .unary_operands = ((operand_46).expressions).unary_operands, .unary_operators = ((operand_46).expressions).unary_operators, .update_indices = ((operand_46).expressions).update_indices, .update_targets = ((operand_46).expressions).update_targets, .update_values = ((operand_46).expressions).update_values, };
                    const operand_48 = (zx_abi).zx_type_36{ .allowed = (operand_46).allowed, .concurrent = (operand_46).concurrent, .expressions = (&operand_47), .limit = (operand_46).limit, };
                    const operand_49 = (try function_4(allocator, (&operand_48)));

                    break :block_50 operand_49;
                }));
                const value_6: state_type_14 = state_1;
                const value_7: []const bool = (value_6).values;
                const value_8: u64 = (state_1).index;
                const value_9: state_type_14 = block_21: {
                    break :block_21 state_type_14{ .concurrent = (value_6).concurrent, .functions = (value_6).functions, .index = (value_6).index, .values = block_20: {
                        const operand_16 = value_7;
                        const operand_17 = value_8;

                        if ((operand_17 >= (operand_16).len)) {
                            return error.IndexOutOfBounds;
                        }

                        const operand_18 = value_5;

                        break :block_20 block_19: {
                            if ((!state_items_started_12)) {
                                state_items_11 = @constCast(operand_16);

                                state_items_started_12 = true;
                            }

                            (state_items_11)[@intCast(operand_17)] = operand_18;

                            break :block_19 state_items_11;
                        };
                    }, };
                };
                const value_10: state_type_14 = value_9;
                const value_11: u64 = (value_10).index;
                const value_12: state_type_14 = block_15: {
                    break :block_15 state_type_14{ .concurrent = (value_10).concurrent, .functions = (value_10).functions, .index = (value_11 + @as(u64, 1)), .values = (value_10).values, };
                };

                break :block_51 value_12;
            };

            state_changed_10 = true;
        }

        break :block_57 (if (state_changed_10) block_56: {
            const operand_55 = (try (allocator).create((zx_abi).zx_type_43));

            (operand_55).* = @as((zx_abi).zx_type_43, (zx_abi).zx_type_43{ .concurrent = (state_1).concurrent, .functions = block_54: {
                const operand_53 = (try (allocator).create((zx_abi).zx_type_41));

                (operand_53).* = @as((zx_abi).zx_type_41, (zx_abi).zx_type_41{ .expressions = ((state_1).functions).expressions, .native_concurrent = ((state_1).functions).native_concurrent, .native_modules = ((state_1).functions).native_modules, .stores = ((state_1).functions).stores, });

                break :block_54 @as(*const (zx_abi).zx_type_41, operand_53);
            }, .index = (state_1).index, .values = (state_1).values, });

            break :block_56 @as(*const (zx_abi).zx_type_43, operand_55);
        } else operand_9);
    };

    return (value_13).values;
}

fn function_6(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_45) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_1).push((in).@"0", (in).@"1", (in).@"2", (in).@"3", (in).@"4"));

    _ = allocator;

    return native_result;
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!void {
    const native_result = (zx_native_1).pop(in);

    _ = allocator;

    return native_result;
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).eventCount(in);

    _ = allocator;

    return native_result;
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).eventKind(in);

    _ = allocator;

    return native_result;
}

fn function_10(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).eventA(in);

    _ = allocator;

    return native_result;
}

fn function_11(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).eventB(in);

    _ = allocator;

    return native_result;
}

fn function_12(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).eventC(in);

    _ = allocator;

    return native_result;
}

fn function_13(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!bool {
    const native_result = (zx_native_1).active((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_14(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_47) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_1).setActive((in).@"0", (in).@"1", (in).@"2"));

    _ = allocator;

    return native_result;
}

fn function_15(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).activeMark(in);

    _ = allocator;

    return native_result;
}

fn function_16(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!void {
    const native_result = (zx_native_1).restoreActive((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_17(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!bool {
    const native_result = (zx_native_1).declared((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_18(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!void {
    const native_result = (zx_native_1).setDeclared((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_19(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!u64 {
    const native_result = (zx_native_1).owner((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_20(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_48) error{ }!void {
    const native_result = (zx_native_1).setOwner((in).@"0", (in).@"1", (in).@"2");

    _ = allocator;

    return native_result;
}

fn function_21(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).factMark(in);

    _ = allocator;

    return native_result;
}

fn function_22(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).captureMark(in);

    _ = allocator;

    return native_result;
}

fn function_23(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_48) error{ }!void {
    const native_result = (zx_native_1).restoreFacts((in).@"0", (in).@"1", (in).@"2");

    _ = allocator;

    return native_result;
}

fn function_24(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!bool {
    const native_result = (zx_native_1).contains((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_25(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_1).appendFact((in).@"0", (in).@"1"));

    _ = allocator;

    return native_result;
}

fn function_26(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_48) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_1).appendCapture((in).@"0", (in).@"1", (in).@"2"));

    _ = allocator;

    return native_result;
}

fn function_27(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!u64 {
    const native_result = (zx_native_1).captureError((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_28(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!u64 {
    const native_result = (zx_native_1).captureResult((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_29(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_65) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!*const (zx_abi).zx_type_66 {
    @setRuntimeSafety(true);

    const value_1: []const bool = (try function_3(allocator, ((in).body).control));
    const value_2: []const bool = (if ((@as(u64, ((((in).body).control).parallel_first).len) == @as(u64, 0))) block_13: {
        break :block_13 (try (allocator).dupe(bool, (&[_]bool{})));
    } else (try function_5(allocator, block_18: {
        const operand_14 = (in).functions;
        const operand_15 = false;

        break :block_18 block_17: {
            const operand_16 = (try (allocator).create((zx_abi).zx_type_42));

            (operand_16).* = @as((zx_abi).zx_type_42, (zx_abi).zx_type_42{ .functions = operand_14, .concurrent = operand_15, });

            break :block_17 @as(*const (zx_abi).zx_type_42, operand_16);
        };
    })));
    const value_3: []const bool = (if ((@as(u64, ((((in).body).expressions).task_bodies).len) == @as(u64, 0))) block_7: {
        break :block_7 (try (allocator).dupe(bool, (&[_]bool{})));
    } else (try function_5(allocator, block_12: {
        const operand_8 = (in).functions;
        const operand_9 = true;

        break :block_12 block_11: {
            const operand_10 = (try (allocator).create((zx_abi).zx_type_42));

            (operand_10).* = @as((zx_abi).zx_type_42, (zx_abi).zx_type_42{ .functions = operand_8, .concurrent = operand_9, });

            break :block_11 @as(*const (zx_abi).zx_type_42, operand_10);
        };
    })));

    return block_6: {
        const operand_1 = value_1;
        const operand_2 = value_2;
        const operand_3 = value_3;

        break :block_6 block_5: {
            const operand_4 = (try (allocator).create((zx_abi).zx_type_66));

            (operand_4).* = @as((zx_abi).zx_type_66, (zx_abi).zx_type_66{ .returns = operand_1, .pure = operand_2, .concurrent = operand_3, });

            break :block_5 @as(*const (zx_abi).zx_type_66, operand_4);
        };
    };
}

fn function_29_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!(zx_abi).value_zx_type_66_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 {
    @setRuntimeSafety(true);

    const value_1: []const bool = block_44: {
        const operand_42 = ((in).body).control;

        var state_borrow_43: (zx_abi).zx_type_17 = undefined;

        state_borrow_43 = (zx_abi).zx_type_17{ .block_count = (operand_42).block_count, .block_first = (operand_42).block_first, .branch_conditions = (operand_42).branch_conditions, .branch_no = (operand_42).branch_no, .branch_yes = (operand_42).branch_yes, .case_bodies = (operand_42).case_bodies, .case_values = (operand_42).case_values, .constant_symbols = (operand_42).constant_symbols, .constant_values = (operand_42).constant_values, .destructure_count = (operand_42).destructure_count, .destructure_first = (operand_42).destructure_first, .destructure_symbols = (operand_42).destructure_symbols, .destructure_values = (operand_42).destructure_values, .evaluations = (operand_42).evaluations, .parallel_count = (operand_42).parallel_count, .parallel_first = (operand_42).parallel_first, .parallel_symbols = (operand_42).parallel_symbols, .parallel_values = (operand_42).parallel_values, .results = (operand_42).results, .selection_count = (operand_42).selection_count, .selection_exhaustive = (operand_42).selection_exhaustive, .selection_first = (operand_42).selection_first, .selection_subjects = (operand_42).selection_subjects, .setter_slots = (operand_42).setter_slots, .setter_values = (operand_42).setter_values, .statement_kinds = (operand_42).statement_kinds, .statement_payloads = (operand_42).statement_payloads, };

        break :block_44 (try function_3(allocator, ((operand_42).zx_origin orelse (&state_borrow_43))));
    };
    const value_2: []const bool = (if ((@as(u64, ((((in).body).control).parallel_first).len) == @as(u64, 0))) block_34: {
        break :block_34 (try (allocator).dupe(bool, (&[_]bool{})));
    } else block_41: {
        const operand_38 = block_37: {
            const operand_35 = (in).functions;
            const operand_36 = false;

            break :block_37 @as((zx_abi).value_zx_type_42_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b, (zx_abi).value_zx_type_42_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b{ .functions = operand_35, .concurrent = operand_36, });
        };

        var state_borrow_39: (zx_abi).zx_type_41 = undefined;

        state_borrow_39 = (zx_abi).zx_type_41{ .expressions = ((operand_38).functions).expressions, .native_concurrent = ((operand_38).functions).native_concurrent, .native_modules = ((operand_38).functions).native_modules, .stores = ((operand_38).functions).stores, };

        var state_borrow_40: (zx_abi).zx_type_42 = undefined;

        state_borrow_40 = (zx_abi).zx_type_42{ .concurrent = (operand_38).concurrent, .functions = (((operand_38).functions).zx_origin orelse (&state_borrow_39)), };

        break :block_41 (try function_5(allocator, ((operand_38).zx_origin orelse (&state_borrow_40))));
    });
    const value_3: []const bool = (if ((@as(u64, ((((in).body).expressions).task_bodies).len) == @as(u64, 0))) block_26: {
        break :block_26 (try (allocator).dupe(bool, (&[_]bool{})));
    } else block_33: {
        const operand_30 = block_29: {
            const operand_27 = (in).functions;
            const operand_28 = true;

            break :block_29 @as((zx_abi).value_zx_type_42_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b, (zx_abi).value_zx_type_42_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b{ .functions = operand_27, .concurrent = operand_28, });
        };

        var state_borrow_31: (zx_abi).zx_type_41 = undefined;

        state_borrow_31 = (zx_abi).zx_type_41{ .expressions = ((operand_30).functions).expressions, .native_concurrent = ((operand_30).functions).native_concurrent, .native_modules = ((operand_30).functions).native_modules, .stores = ((operand_30).functions).stores, };

        var state_borrow_32: (zx_abi).zx_type_42 = undefined;

        state_borrow_32 = (zx_abi).zx_type_42{ .concurrent = (operand_30).concurrent, .functions = (((operand_30).functions).zx_origin orelse (&state_borrow_31)), };

        break :block_33 (try function_5(allocator, ((operand_30).zx_origin orelse (&state_borrow_32))));
    });

    return block_25: {
        const operand_19 = block_20: {
            break :block_20 value_1;
        };
        const operand_21 = block_22: {
            break :block_22 value_2;
        };
        const operand_23 = block_24: {
            break :block_24 value_3;
        };

        break :block_25 @as((zx_abi).value_zx_type_66_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_66_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .returns = operand_19, .pure = operand_21, .concurrent = operand_23, });
    };
}

fn function_30(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_45) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_1).push((in).@"0", (in).@"1", (in).@"2", (in).@"3", (in).@"4"));

    _ = allocator;

    return native_result;
}

fn function_31(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!void {
    const native_result = (zx_native_1).pop(in);

    _ = allocator;

    return native_result;
}

fn function_32(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).eventCount(in);

    _ = allocator;

    return native_result;
}

fn function_33(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).eventKind(in);

    _ = allocator;

    return native_result;
}

fn function_34(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).eventA(in);

    _ = allocator;

    return native_result;
}

fn function_35(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).eventB(in);

    _ = allocator;

    return native_result;
}

fn function_36(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).eventC(in);

    _ = allocator;

    return native_result;
}

fn function_37(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!bool {
    const native_result = (zx_native_1).active((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_38(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_47) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_1).setActive((in).@"0", (in).@"1", (in).@"2"));

    _ = allocator;

    return native_result;
}

fn function_39(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).activeMark(in);

    _ = allocator;

    return native_result;
}

fn function_40(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!void {
    const native_result = (zx_native_1).restoreActive((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_41(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!bool {
    const native_result = (zx_native_1).declared((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_42(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!void {
    const native_result = (zx_native_1).setDeclared((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_43(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!u64 {
    const native_result = (zx_native_1).owner((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_44(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_48) error{ }!void {
    const native_result = (zx_native_1).setOwner((in).@"0", (in).@"1", (in).@"2");

    _ = allocator;

    return native_result;
}

fn function_45(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).factMark(in);

    _ = allocator;

    return native_result;
}

fn function_46(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ }!u64 {
    const native_result = (zx_native_1).captureMark(in);

    _ = allocator;

    return native_result;
}

fn function_47(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_48) error{ }!void {
    const native_result = (zx_native_1).restoreFacts((in).@"0", (in).@"1", (in).@"2");

    _ = allocator;

    return native_result;
}

fn function_48(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!bool {
    const native_result = (zx_native_1).contains((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_49(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_1).appendFact((in).@"0", (in).@"1"));

    _ = allocator;

    return native_result;
}

fn function_50(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_48) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_1).appendCapture((in).@"0", (in).@"1", (in).@"2"));

    _ = allocator;

    return native_result;
}

fn function_51(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!u64 {
    const native_result = (zx_native_1).captureError((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_52(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_46) error{ }!u64 {
    const native_result = (zx_native_1).captureResult((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_53(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_54(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_55(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_70) error{ IndexOutOfBounds, OutOfMemory, }!void {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_35 = ((in).expressions).*;
    const value_2: (zx_abi).zx_type_26 = block_72: {
        const operand_70 = ((&value_1)).binary_operators;
        const operand_71 = (in).payload;

        if ((operand_71 >= (operand_70).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_72 (operand_70)[@intCast(operand_71)];
    };

    if (((value_2 != @as((zx_abi).zx_type_26, .Equal)) and (value_2 != @as((zx_abi).zx_type_26, .NotEqual)))) {
        return;
    }

    const value_3: u64 = (try function_53(allocator, block_69: {
        const operand_67 = ((&value_1)).binary_left;
        const operand_68 = (in).payload;

        if ((operand_68 >= (operand_67).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_69 (operand_67)[@intCast(operand_68)];
    }));
    const value_4: u64 = (try function_53(allocator, block_66: {
        const operand_64 = ((&value_1)).binary_right;
        const operand_65 = (in).payload;

        if ((operand_65 >= (operand_64).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_66 (operand_64)[@intCast(operand_65)];
    }));
    const value_5: u64 = (if (((block_60: {
        const operand_58 = ((&value_1)).kinds;
        const operand_59 = value_3;

        if ((operand_59 >= (operand_58).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_60 (operand_58)[@intCast(operand_59)];
    } == @as((zx_abi).zx_type_22, .Reference)) and (block_63: {
        const operand_61 = ((&value_1)).kinds;
        const operand_62 = value_4;

        if ((operand_62 >= (operand_61).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_63 (operand_61)[@intCast(operand_62)];
    } == @as((zx_abi).zx_type_22, .None)))) value_3 else (if (((block_54: {
        const operand_52 = ((&value_1)).kinds;
        const operand_53 = value_4;

        if ((operand_53 >= (operand_52).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_54 (operand_52)[@intCast(operand_53)];
    } == @as((zx_abi).zx_type_22, .Reference)) and (block_57: {
        const operand_55 = ((&value_1)).kinds;
        const operand_56 = value_3;

        if ((operand_56 >= (operand_55).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_57 (operand_55)[@intCast(operand_56)];
    } == @as((zx_abi).zx_type_22, .None)))) value_4 else @as(u64, (((&value_1)).kinds).len)));

    if ((value_5 == @as(u64, (((&value_1)).kinds).len))) {
        return;
    }

    const value_6: u64 = (try function_53(allocator, block_51: {
        const operand_49 = ((&value_1)).references;
        const operand_50 = (try function_53(allocator, block_48: {
            const operand_46 = ((&value_1)).payloads;
            const operand_47 = value_5;

            if ((operand_47 >= (operand_46).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_48 (operand_46)[@intCast(operand_47)];
        }));

        if ((operand_50 >= (operand_49).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_51 (operand_49)[@intCast(operand_50)];
    }));
    const value_7: bool = (if ((value_2 == @as((zx_abi).zx_type_26, .NotEqual))) (in).truth else (!(in).truth));

    if (value_7) {
        if ((!block_5: {
            const operand_4 = @as((zx_abi).zx_type_46, block_3: {
                const operand_1 = (in).writer;
                const operand_2 = value_6;

                break :block_3 .{ operand_1, operand_2, };
            });

            break :block_5 (try function_48(allocator, (&operand_4)));
        })) {
            _ = block_10: {
                const operand_9 = @as((zx_abi).zx_type_46, block_8: {
                    const operand_6 = (in).writer;
                    const operand_7 = value_6;

                    break :block_8 .{ operand_6, operand_7, };
                });

                break :block_10 (try function_49(allocator, (&operand_9)));
            };
        }
    } else {
        _ = block_45: {
            const operand_17 = block_16: {
                const operand_12 = (in).writer;
                const operand_13 = value_6;
                const operand_14 = @as(u64, 0);
                const operand_15 = (try function_46(allocator, (in).writer));

                break :block_16 (zx_abi).zx_type_71{ .writer = operand_12, .symbol = operand_13, .index = operand_14, .count = operand_15, };
            };

            var state_11: (zx_abi).value_zx_type_71_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (zx_abi).value_zx_type_71_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (operand_17).count, .index = (operand_17).index, .symbol = (operand_17).symbol, .writer = (operand_17).writer, .zx_origin = (&operand_17), };

            while (((state_11).index < (state_11).count)) {
                state_11 = block_44: {
                    const value_12: (zx_abi).value_zx_type_71_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if ((block_24: {
                        const operand_23 = @as((zx_abi).zx_type_46, block_22: {
                            const operand_20 = (state_11).writer;
                            const operand_21 = (state_11).index;

                            break :block_22 .{ operand_20, operand_21, };
                        });

                        break :block_24 (try function_51(allocator, (&operand_23)));
                    } == (state_11).symbol)) block_43: {
                        const value_10: u64 = block_42: {
                            const operand_41 = @as((zx_abi).zx_type_46, block_40: {
                                const operand_38 = (state_11).writer;
                                const operand_39 = (state_11).index;

                                break :block_40 .{ operand_38, operand_39, };
                            });

                            break :block_42 (try function_52(allocator, (&operand_41)));
                        };
                        const value_11: (zx_abi).value_zx_type_71_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (if ((!block_30: {
                            const operand_29 = @as((zx_abi).zx_type_46, block_28: {
                                const operand_25 = (state_11).writer;
                                const operand_27 = block_26: {
                                    break :block_26 value_10;
                                };

                                break :block_28 .{ operand_25, operand_27, };
                            });

                            break :block_30 (try function_48(allocator, (&operand_29)));
                        })) block_37: {
                            _ = block_36: {
                                const operand_35 = @as((zx_abi).zx_type_46, block_34: {
                                    const operand_31 = (state_11).writer;
                                    const operand_33 = block_32: {
                                        break :block_32 value_10;
                                    };

                                    break :block_34 .{ operand_31, operand_33, };
                                });

                                break :block_36 (try function_49(allocator, (&operand_35)));
                            };

                            break :block_37 state_11;
                        } else state_11);

                        break :block_43 value_11;
                    } else state_11);
                    const value_13: (zx_abi).value_zx_type_71_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = value_12;
                    const value_14: u64 = (value_13).index;
                    const value_15: (zx_abi).value_zx_type_71_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_19: {
                        break :block_19 @as((zx_abi).value_zx_type_71_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_71_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (value_13).count, .index = (block_18: {
                            break :block_18 value_14;
                        } + @as(u64, 1)), .symbol = (value_13).symbol, .writer = (value_13).writer, });
                    };

                    break :block_44 value_15;
                };
            }

            break :block_45 {};
        };
    }
}

fn function_56(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_72) error{ IndexOutOfBounds, OutOfMemory, }!void {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_32(allocator, (in).writer));

    _ = block_114: {
        const operand_113 = @as((zx_abi).zx_type_45, block_112: {
            const operand_107 = (in).writer;
            const operand_108 = @as(u64, 0);
            const operand_109 = (in).condition;
            const operand_110 = (if ((in).truth) @as(u64, 1) else @as(u64, 0));
            const operand_111 = @as(u64, 0);

            break :block_112 .{ operand_107, operand_108, operand_109, operand_110, operand_111, };
        });

        break :block_114 (try function_30(allocator, (&operand_113)));
    };

    _ = block_106: {
        const operand_6 = block_5: {
            const operand_2 = (in).writer;
            const operand_3 = (in).expressions;
            const operand_4 = value_1;

            break :block_5 (zx_abi).zx_type_73{ .writer = operand_2, .expressions = operand_3, .mark = operand_4, };
        };

        var state_1: (zx_abi).value_zx_type_73_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_73_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .expressions = (operand_6).expressions, .mark = (operand_6).mark, .writer = (operand_6).writer, .zx_origin = (&operand_6), };

        while ((block_8: {
            const operand_7 = (state_1).writer;

            break :block_8 (try function_32(allocator, operand_7));
        } > (state_1).mark)) {
            state_1 = block_105: {
                _ = block_104: {
                    const operand_103 = (state_1).writer;

                    break :block_104 (try function_31(allocator, operand_103));
                };

                const value_4: u64 = block_102: {
                    const operand_101 = (state_1).writer;

                    break :block_102 (try function_34(allocator, operand_101));
                };
                const value_5: bool = (block_100: {
                    const operand_99 = (state_1).writer;

                    break :block_100 (try function_35(allocator, operand_99));
                } != @as(u64, 0));
                const value_6: *const (zx_abi).zx_type_35 = (state_1).expressions;
                const value_7: (zx_abi).zx_type_22 = block_98: {
                    const operand_96 = (block_94: {
                        break :block_94 value_6;
                    }).kinds;
                    const operand_97 = block_95: {
                        break :block_95 value_4;
                    };

                    if ((operand_97 >= (operand_96).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_98 (operand_96)[@intCast(operand_97)];
                };
                const value_8: u64 = block_93: {
                    const operand_92 = block_91: {
                        const operand_89 = (block_87: {
                            break :block_87 value_6;
                        }).payloads;
                        const operand_90 = block_88: {
                            break :block_88 value_4;
                        };

                        if ((operand_90 >= (operand_89).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_91 (operand_89)[@intCast(operand_90)];
                    };

                    break :block_93 (try function_53(allocator, operand_92));
                };
                const value_12: (zx_abi).value_zx_type_73_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (if (((block_9: {
                    break :block_9 value_7;
                } == @as((zx_abi).zx_type_22, .Unary)) and (block_14: {
                    const operand_12 = (block_10: {
                        break :block_10 value_6;
                    }).unary_operators;
                    const operand_13 = block_11: {
                        break :block_11 value_8;
                    };

                    if ((operand_13 >= (operand_12).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_14 (operand_12)[@intCast(operand_13)];
                } == @as((zx_abi).zx_type_25, .Not)))) block_31: {
                    _ = block_30: {
                        const operand_29 = @as((zx_abi).zx_type_45, block_28: {
                            const operand_15 = (state_1).writer;
                            const operand_16 = @as(u64, 0);
                            const operand_24 = block_23: {
                                const operand_22 = block_21: {
                                    const operand_19 = (block_17: {
                                        break :block_17 value_6;
                                    }).unary_operands;
                                    const operand_20 = block_18: {
                                        break :block_18 value_8;
                                    };

                                    if ((operand_20 >= (operand_19).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_21 (operand_19)[@intCast(operand_20)];
                                };

                                break :block_23 (try function_53(allocator, operand_22));
                            };
                            const operand_26 = (if (block_25: {
                                break :block_25 value_5;
                            }) @as(u64, 0) else @as(u64, 1));
                            const operand_27 = @as(u64, 0);

                            break :block_28 .{ operand_15, operand_16, operand_24, operand_26, operand_27, };
                        });

                        break :block_30 (try function_30(allocator, (&operand_29)));
                    };

                    break :block_31 state_1;
                } else block_86: {
                    const value_11: (zx_abi).value_zx_type_73_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (if ((block_32: {
                        break :block_32 value_7;
                    } == @as((zx_abi).zx_type_22, .Binary))) block_85: {
                        const value_9: (zx_abi).zx_type_26 = block_84: {
                            const operand_82 = (block_80: {
                                break :block_80 value_6;
                            }).binary_operators;
                            const operand_83 = block_81: {
                                break :block_81 value_8;
                            };

                            if ((operand_83 >= (operand_82).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_84 (operand_82)[@intCast(operand_83)];
                        };
                        const value_10: (zx_abi).value_zx_type_73_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (if ((((block_33: {
                            break :block_33 value_9;
                        } == @as((zx_abi).zx_type_26, .LogicalAnd)) and block_34: {
                            break :block_34 value_5;
                        }) or ((block_35: {
                            break :block_35 value_9;
                        } == @as((zx_abi).zx_type_26, .LogicalOr)) and (!block_36: {
                            break :block_36 value_5;
                        })))) block_69: {
                            _ = block_68: {
                                const operand_67 = @as((zx_abi).zx_type_45, block_66: {
                                    const operand_53 = (state_1).writer;
                                    const operand_54 = @as(u64, 0);
                                    const operand_62 = block_61: {
                                        const operand_60 = block_59: {
                                            const operand_57 = (block_55: {
                                                break :block_55 value_6;
                                            }).binary_right;
                                            const operand_58 = block_56: {
                                                break :block_56 value_8;
                                            };

                                            if ((operand_58 >= (operand_57).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            break :block_59 (operand_57)[@intCast(operand_58)];
                                        };

                                        break :block_61 (try function_53(allocator, operand_60));
                                    };
                                    const operand_64 = (if (block_63: {
                                        break :block_63 value_5;
                                    }) @as(u64, 1) else @as(u64, 0));
                                    const operand_65 = @as(u64, 0);

                                    break :block_66 .{ operand_53, operand_54, operand_62, operand_64, operand_65, };
                                });

                                break :block_68 (try function_30(allocator, (&operand_67)));
                            };

                            _ = block_52: {
                                const operand_51 = @as((zx_abi).zx_type_45, block_50: {
                                    const operand_37 = (state_1).writer;
                                    const operand_38 = @as(u64, 0);
                                    const operand_46 = block_45: {
                                        const operand_44 = block_43: {
                                            const operand_41 = (block_39: {
                                                break :block_39 value_6;
                                            }).binary_left;
                                            const operand_42 = block_40: {
                                                break :block_40 value_8;
                                            };

                                            if ((operand_42 >= (operand_41).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            break :block_43 (operand_41)[@intCast(operand_42)];
                                        };

                                        break :block_45 (try function_53(allocator, operand_44));
                                    };
                                    const operand_48 = (if (block_47: {
                                        break :block_47 value_5;
                                    }) @as(u64, 1) else @as(u64, 0));
                                    const operand_49 = @as(u64, 0);

                                    break :block_50 .{ operand_37, operand_38, operand_46, operand_48, operand_49, };
                                });

                                break :block_52 (try function_30(allocator, (&operand_51)));
                            };

                            break :block_69 state_1;
                        } else block_79: {
                            _ = block_78: {
                                const operand_70 = (state_1).writer;
                                const operand_72 = block_71: {
                                    break :block_71 value_6;
                                };
                                const operand_74 = block_73: {
                                    break :block_73 value_8;
                                };
                                const operand_76 = block_75: {
                                    break :block_75 value_5;
                                };
                                const operand_77 = (zx_abi).zx_type_70{ .writer = operand_70, .expressions = operand_72, .payload = operand_74, .truth = operand_76, };

                                break :block_78 (try function_55(allocator, (&operand_77)));
                            };

                            break :block_79 state_1;
                        });

                        break :block_85 value_10;
                    } else state_1);

                    break :block_86 value_11;
                });

                break :block_105 value_12;
            };
        }

        break :block_106 {};
    };
}

fn function_57(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_18) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    if ((!block_30: {
        const operand_28 = ((in).control).selection_exhaustive;
        const operand_29 = (in).selection;

        if ((operand_29 >= (operand_28).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_30 (operand_28)[@intCast(operand_29)];
    })) {
        return false;
    }

    const value_1: u64 = (try function_53(allocator, block_27: {
        const operand_25 = ((in).control).selection_first;
        const operand_26 = (in).selection;

        if ((operand_26 >= (operand_25).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_27 (operand_25)[@intCast(operand_26)];
    }));
    const value_2: u64 = (try function_53(allocator, block_24: {
        const operand_22 = ((in).control).selection_count;
        const operand_23 = (in).selection;

        if ((operand_23 >= (operand_22).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_24 (operand_22)[@intCast(operand_23)];
    }));

    return block_21: {
        const operand_8 = block_7: {
            const operand_2 = ((in).control).case_bodies;
            const operand_3 = (in).returns;
            const operand_4 = value_1;
            const operand_5 = (value_1 + value_2);
            const operand_6 = true;

            break :block_7 (zx_abi).zx_type_19{ .bodies = operand_2, .returns = operand_3, .index = operand_4, .end = operand_5, .all = operand_6, };
        };

        var state_1: (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .all = (operand_8).all, .bodies = (operand_8).bodies, .end = (operand_8).end, .index = (operand_8).index, .returns = (operand_8).returns, .zx_origin = (&operand_8), };

        while (((state_1).all and ((state_1).index < (state_1).end))) {
            state_1 = block_20: {
                const value_5: (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = state_1;
                const value_6: (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_19: {
                    break :block_19 @as((zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .all = block_18: {
                        const operand_16 = (state_1).returns;
                        const operand_17 = block_15: {
                            const operand_14 = block_13: {
                                const operand_11 = (state_1).bodies;
                                const operand_12 = (state_1).index;

                                if ((operand_12 >= (operand_11).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_13 (operand_11)[@intCast(operand_12)];
                            };

                            break :block_15 (try function_53(allocator, operand_14));
                        };

                        if ((operand_17 >= (operand_16).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_18 (operand_16)[@intCast(operand_17)];
                    }, .bodies = (value_5).bodies, .end = (value_5).end, .index = (value_5).index, .returns = (value_5).returns, });
                };
                const value_7: (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = value_6;
                const value_8: u64 = (value_7).index;
                const value_9: (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = block_10: {
                    break :block_10 @as((zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .all = (value_7).all, .bodies = (value_7).bodies, .end = (value_7).end, .index = (block_9: {
                        break :block_9 value_8;
                    } + @as(u64, 1)), .returns = (value_7).returns, });
                };

                break :block_20 value_9;
            };
        }

        break :block_21 (state_1).all;
    };
}

fn function_58(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_74) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_17 = (((((in).context).program).body).control).*;
    const value_2: u64 = (try function_53(allocator, block_25: {
        const operand_23 = ((&value_1)).statement_payloads;
        const operand_24 = (in).statement;

        if ((operand_24 >= (operand_23).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_25 (operand_23)[@intCast(operand_24)];
    }));

    return block_22: {
        const operand_4 = block_3: {
            const operand_1 = ((&value_1)).statement_kinds;
            const operand_2 = (in).statement;

            if ((operand_2 >= (operand_1).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_3 (operand_1)[@intCast(operand_2)];
        };

        break :block_22 (if ((operand_4 == @as((zx_abi).zx_type_11, .Result))) true else (if ((operand_4 == @as((zx_abi).zx_type_11, .Branch))) (block_15: {
            const operand_13 = (((in).context).prepared).returns;
            const operand_14 = (try function_53(allocator, block_12: {
                const operand_10 = ((&value_1)).branch_yes;
                const operand_11 = value_2;

                if ((operand_11 >= (operand_10).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_12 (operand_10)[@intCast(operand_11)];
            }));

            if ((operand_14 >= (operand_13).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_15 (operand_13)[@intCast(operand_14)];
        } and block_21: {
            const operand_19 = (((in).context).prepared).returns;
            const operand_20 = (try function_53(allocator, block_18: {
                const operand_16 = ((&value_1)).branch_no;
                const operand_17 = value_2;

                if ((operand_17 >= (operand_16).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_18 (operand_16)[@intCast(operand_17)];
            }));

            if ((operand_20 >= (operand_19).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_21 (operand_19)[@intCast(operand_20)];
        }) else (if ((operand_4 == @as((zx_abi).zx_type_11, .Switch))) block_9: {
            const operand_5 = (&value_1);
            const operand_6 = value_2;
            const operand_7 = (((in).context).prepared).returns;
            const operand_8 = (zx_abi).zx_type_18{ .control = operand_5, .selection = operand_6, .returns = operand_7, };

            break :block_9 (try function_57(allocator, (&operand_8)));
        } else false)));
    };
}

fn function_59(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_75) error{ OutOfMemory, }!void {
    @setRuntimeSafety(true);

    const value_1: u64 = block_10: {
        const operand_9 = ((in).frame).phase;

        break :block_10 (if ((operand_9 == @as((zx_abi).zx_type_63, .Block))) @as(u64, 0) else (if ((operand_9 == @as((zx_abi).zx_type_63, .BlockNext))) @as(u64, 1) else (if ((operand_9 == @as((zx_abi).zx_type_63, .Expression))) @as(u64, 2) else (if ((operand_9 == @as((zx_abi).zx_type_63, .Declare))) @as(u64, 3) else (if ((operand_9 == @as((zx_abi).zx_type_63, .ScopeDeclare))) @as(u64, 4) else (if ((operand_9 == @as((zx_abi).zx_type_63, .Destructure))) @as(u64, 5) else (if ((operand_9 == @as((zx_abi).zx_type_63, .Branch))) @as(u64, 6) else (if ((operand_9 == @as((zx_abi).zx_type_63, .BranchPost))) @as(u64, 7) else (if ((operand_9 == @as((zx_abi).zx_type_63, .Switch))) @as(u64, 8) else (if ((operand_9 == @as((zx_abi).zx_type_63, .Restore))) @as(u64, 9) else (if ((operand_9 == @as((zx_abi).zx_type_63, .RestoreFacts))) @as(u64, 10) else (if ((operand_9 == @as((zx_abi).zx_type_63, .Assume))) @as(u64, 11) else (if ((operand_9 == @as((zx_abi).zx_type_63, .IterationCondition))) @as(u64, 12) else (if ((operand_9 == @as((zx_abi).zx_type_63, .IterationBody))) @as(u64, 13) else (if ((operand_9 == @as((zx_abi).zx_type_63, .Transform))) @as(u64, 14) else @as(u64, 15))))))))))))))));
    };

    _ = block_8: {
        const operand_7 = @as((zx_abi).zx_type_45, block_6: {
            const operand_1 = (in).writer;
            const operand_2 = value_1;
            const operand_3 = ((in).frame).a;
            const operand_4 = ((in).frame).b;
            const operand_5 = ((in).frame).c;

            break :block_6 .{ operand_1, operand_2, operand_3, operand_4, operand_5, };
        });

        break :block_8 (try function_30(allocator, (&operand_7)));
    };
}

fn function_60(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: (zx_abi).zx_type_17 = ((((&value_1)).body).control).*;
    const value_3: u64 = (try function_53(allocator, block_98: {
        const operand_96 = ((&value_2)).parallel_count;
        const operand_97 = ((in).frame).a;

        if ((operand_97 >= (operand_96).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_98 (operand_96)[@intCast(operand_97)];
    }));
    const value_4: u64 = (try function_53(allocator, block_95: {
        const operand_93 = ((&value_2)).parallel_first;
        const operand_94 = ((in).frame).a;

        if ((operand_94 >= (operand_93).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_95 (operand_93)[@intCast(operand_94)];
    }));

    if ((value_3 == @as(u64, 0))) {
        return false;
    }

    _ = block_92: {
        const operand_62 = block_61: {
            const operand_58 = (&value_1);
            const operand_59 = value_4;
            const operand_60 = value_3;

            break :block_61 (zx_abi).zx_type_76{ .program = operand_58, .first = operand_59, .index = operand_60, };
        };

        var state_57: (zx_abi).value_zx_type_76_3ff1fc137cb0ea39e5e3fd7523e3f74084231cb48987c7743bd8dc8f42923f32 = (zx_abi).value_zx_type_76_3ff1fc137cb0ea39e5e3fd7523e3f74084231cb48987c7743bd8dc8f42923f32{ .first = (operand_62).first, .index = (operand_62).index, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = ((((operand_62).program).body).control).block_count, .block_first = ((((operand_62).program).body).control).block_first, .branch_conditions = ((((operand_62).program).body).control).branch_conditions, .branch_no = ((((operand_62).program).body).control).branch_no, .branch_yes = ((((operand_62).program).body).control).branch_yes, .case_bodies = ((((operand_62).program).body).control).case_bodies, .case_values = ((((operand_62).program).body).control).case_values, .constant_symbols = ((((operand_62).program).body).control).constant_symbols, .constant_values = ((((operand_62).program).body).control).constant_values, .destructure_count = ((((operand_62).program).body).control).destructure_count, .destructure_first = ((((operand_62).program).body).control).destructure_first, .destructure_symbols = ((((operand_62).program).body).control).destructure_symbols, .destructure_values = ((((operand_62).program).body).control).destructure_values, .evaluations = ((((operand_62).program).body).control).evaluations, .parallel_count = ((((operand_62).program).body).control).parallel_count, .parallel_first = ((((operand_62).program).body).control).parallel_first, .parallel_symbols = ((((operand_62).program).body).control).parallel_symbols, .parallel_values = ((((operand_62).program).body).control).parallel_values, .results = ((((operand_62).program).body).control).results, .selection_count = ((((operand_62).program).body).control).selection_count, .selection_exhaustive = ((((operand_62).program).body).control).selection_exhaustive, .selection_first = ((((operand_62).program).body).control).selection_first, .selection_subjects = ((((operand_62).program).body).control).selection_subjects, .setter_slots = ((((operand_62).program).body).control).setter_slots, .setter_values = ((((operand_62).program).body).control).setter_values, .statement_kinds = ((((operand_62).program).body).control).statement_kinds, .statement_payloads = ((((operand_62).program).body).control).statement_payloads, .zx_origin = (((operand_62).program).body).control, }, .expressions = (((operand_62).program).body).expressions, .root = (((operand_62).program).body).root, .stores = (((operand_62).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_62).program).body).symbols).names, .ownership = ((((operand_62).program).body).symbols).ownership, .span_end = ((((operand_62).program).body).symbols).span_end, .span_start = ((((operand_62).program).body).symbols).span_start, .types = ((((operand_62).program).body).symbols).types, .zx_origin = (((operand_62).program).body).symbols, }, .zx_origin = ((operand_62).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = (((operand_62).program).functions).expressions, .native_concurrent = (((operand_62).program).functions).native_concurrent, .native_modules = (((operand_62).program).functions).native_modules, .stores = (((operand_62).program).functions).stores, .zx_origin = ((operand_62).program).functions, }, .output_type = ((operand_62).program).output_type, .table = ((operand_62).program).table, .transaction = ((operand_62).program).transaction, .writer = ((operand_62).program).writer, .zx_origin = (operand_62).program, }, .zx_origin = (&operand_62), };

        while (((state_57).index != @as(u64, 0))) {
            state_57 = block_91: {
                const value_7: (zx_abi).value_zx_type_76_3ff1fc137cb0ea39e5e3fd7523e3f74084231cb48987c7743bd8dc8f42923f32 = state_57;
                const value_8: u64 = (value_7).index;
                const value_9: (zx_abi).value_zx_type_76_3ff1fc137cb0ea39e5e3fd7523e3f74084231cb48987c7743bd8dc8f42923f32 = block_90: {
                    break :block_90 @as((zx_abi).value_zx_type_76_3ff1fc137cb0ea39e5e3fd7523e3f74084231cb48987c7743bd8dc8f42923f32, (zx_abi).value_zx_type_76_3ff1fc137cb0ea39e5e3fd7523e3f74084231cb48987c7743bd8dc8f42923f32{ .first = (value_7).first, .index = (block_89: {
                        break :block_89 value_8;
                    } - @as(u64, 1)), .program = (value_7).program, });
                };
                const value_10: u64 = ((value_9).first + (value_9).index);
                const value_11: ?u32 = block_88: {
                    const operand_86 = ((((value_9).program).body).control).parallel_symbols;
                    const operand_87 = block_85: {
                        break :block_85 value_10;
                    };

                    if ((operand_87 >= (operand_86).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_88 (operand_86)[@intCast(operand_87)];
                };
                const value_12: (zx_abi).value_zx_type_76_3ff1fc137cb0ea39e5e3fd7523e3f74084231cb48987c7743bd8dc8f42923f32 = (if ((block_63: {
                    break :block_63 value_11;
                } != null)) block_84: {
                    _ = block_83: {
                        const operand_64 = ((value_9).program).writer;
                        const operand_65 = @as((zx_abi).zx_type_63, .Declare);
                        const operand_69 = block_68: {
                            const operand_67 = block_66: {
                                break :block_66 value_11;
                            }.?;

                            break :block_68 (try function_53(allocator, operand_67));
                        };
                        const operand_76 = block_75: {
                            const operand_74 = block_73: {
                                const operand_71 = ((((value_9).program).body).control).parallel_values;
                                const operand_72 = block_70: {
                                    break :block_70 value_10;
                                };

                                if ((operand_72 >= (operand_71).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_73 (operand_71)[@intCast(operand_72)];
                            };

                            break :block_75 (try function_53(allocator, operand_74));
                        };
                        const operand_77 = @as(u64, 0);
                        const operand_78 = (zx_abi).zx_type_64{ .phase = operand_65, .a = operand_69, .b = operand_76, .c = operand_77, };
                        const operand_79 = (&operand_78);
                        const operand_80 = (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .a = (operand_79).a, .b = (operand_79).b, .c = (operand_79).c, .phase = (operand_79).phase, .zx_origin = operand_79, };

                        var state_borrow_81: (zx_abi).zx_type_64 = undefined;

                        state_borrow_81 = (zx_abi).zx_type_64{ .a = (operand_80).a, .b = (operand_80).b, .c = (operand_80).c, .phase = (operand_80).phase, };

                        const operand_82 = (zx_abi).zx_type_75{ .writer = operand_64, .frame = ((operand_80).zx_origin orelse (&state_borrow_81)), };

                        break :block_83 (try function_59(allocator, (&operand_82)));
                    };

                    break :block_84 value_9;
                } else value_9);

                break :block_91 value_12;
            };
        }

        break :block_92 {};
    };

    return block_56: {
        const operand_7 = block_6: {
            const operand_2 = (in).context;
            const operand_3 = value_4;
            const operand_4 = value_3;
            const operand_5 = true;

            break :block_6 (zx_abi).zx_type_77{ .context = operand_2, .first = operand_3, .index = operand_4, .valid = operand_5, };
        };

        var state_1: (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850 = (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850{ .context = (zx_abi).value_zx_type_67_5f65b2d9e9df88722a81205116d90af0a141df9477ec1782450f762a068fd184{ .prepared = (zx_abi).value_zx_type_66_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .concurrent = (((operand_7).context).prepared).concurrent, .pure = (((operand_7).context).prepared).pure, .returns = (((operand_7).context).prepared).returns, .zx_origin = ((operand_7).context).prepared, }, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = (((((operand_7).context).program).body).control).block_count, .block_first = (((((operand_7).context).program).body).control).block_first, .branch_conditions = (((((operand_7).context).program).body).control).branch_conditions, .branch_no = (((((operand_7).context).program).body).control).branch_no, .branch_yes = (((((operand_7).context).program).body).control).branch_yes, .case_bodies = (((((operand_7).context).program).body).control).case_bodies, .case_values = (((((operand_7).context).program).body).control).case_values, .constant_symbols = (((((operand_7).context).program).body).control).constant_symbols, .constant_values = (((((operand_7).context).program).body).control).constant_values, .destructure_count = (((((operand_7).context).program).body).control).destructure_count, .destructure_first = (((((operand_7).context).program).body).control).destructure_first, .destructure_symbols = (((((operand_7).context).program).body).control).destructure_symbols, .destructure_values = (((((operand_7).context).program).body).control).destructure_values, .evaluations = (((((operand_7).context).program).body).control).evaluations, .parallel_count = (((((operand_7).context).program).body).control).parallel_count, .parallel_first = (((((operand_7).context).program).body).control).parallel_first, .parallel_symbols = (((((operand_7).context).program).body).control).parallel_symbols, .parallel_values = (((((operand_7).context).program).body).control).parallel_values, .results = (((((operand_7).context).program).body).control).results, .selection_count = (((((operand_7).context).program).body).control).selection_count, .selection_exhaustive = (((((operand_7).context).program).body).control).selection_exhaustive, .selection_first = (((((operand_7).context).program).body).control).selection_first, .selection_subjects = (((((operand_7).context).program).body).control).selection_subjects, .setter_slots = (((((operand_7).context).program).body).control).setter_slots, .setter_values = (((((operand_7).context).program).body).control).setter_values, .statement_kinds = (((((operand_7).context).program).body).control).statement_kinds, .statement_payloads = (((((operand_7).context).program).body).control).statement_payloads, .zx_origin = ((((operand_7).context).program).body).control, }, .expressions = ((((operand_7).context).program).body).expressions, .root = ((((operand_7).context).program).body).root, .stores = ((((operand_7).context).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((((operand_7).context).program).body).symbols).names, .ownership = (((((operand_7).context).program).body).symbols).ownership, .span_end = (((((operand_7).context).program).body).symbols).span_end, .span_start = (((((operand_7).context).program).body).symbols).span_start, .types = (((((operand_7).context).program).body).symbols).types, .zx_origin = ((((operand_7).context).program).body).symbols, }, .zx_origin = (((operand_7).context).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = ((((operand_7).context).program).functions).expressions, .native_concurrent = ((((operand_7).context).program).functions).native_concurrent, .native_modules = ((((operand_7).context).program).functions).native_modules, .stores = ((((operand_7).context).program).functions).stores, .zx_origin = (((operand_7).context).program).functions, }, .output_type = (((operand_7).context).program).output_type, .table = (((operand_7).context).program).table, .transaction = (((operand_7).context).program).transaction, .writer = (((operand_7).context).program).writer, .zx_origin = ((operand_7).context).program, }, .zx_origin = (operand_7).context, }, .first = (operand_7).first, .index = (operand_7).index, .valid = (operand_7).valid, .zx_origin = (&operand_7), };

        while (((state_1).valid and ((state_1).index != @as(u64, 0)))) {
            state_1 = block_55: {
                const value_15: (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850 = state_1;
                const value_16: u64 = (value_15).index;
                const value_17: (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850 = block_54: {
                    break :block_54 @as((zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850, (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850{ .context = (value_15).context, .first = (value_15).first, .index = (block_53: {
                        break :block_53 value_16;
                    } - @as(u64, 1)), .valid = (value_15).valid, });
                };
                const value_18: (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f = ((value_17).context).program;
                const value_19: u64 = block_52: {
                    const operand_51 = block_50: {
                        const operand_48 = (((value_18).body).control).parallel_values;
                        const operand_49 = ((value_17).first + (value_17).index);

                        if ((operand_49 >= (operand_48).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_50 (operand_48)[@intCast(operand_49)];
                    };

                    break :block_52 (try function_53(allocator, operand_51));
                };
                const value_20: *const (zx_abi).zx_type_35 = ((value_18).body).expressions;
                const value_27: (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850 = (if ((block_12: {
                    const operand_10 = (block_8: {
                        break :block_8 value_20;
                    }).kinds;
                    const operand_11 = block_9: {
                        break :block_9 value_19;
                    };

                    if ((operand_11 >= (operand_10).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_12 (operand_10)[@intCast(operand_11)];
                } != @as((zx_abi).zx_type_22, .Call))) block_14: {
                    const value_21: (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850 = value_17;
                    const value_22: (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850 = block_13: {
                        break :block_13 @as((zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850, (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850{ .context = (value_21).context, .first = (value_21).first, .index = (value_21).index, .valid = false, });
                    };

                    break :block_14 value_22;
                } else block_47: {
                    const value_23: u64 = block_46: {
                        const operand_45 = block_44: {
                            const operand_42 = (block_34: {
                                break :block_34 value_20;
                            }).call_functions;
                            const operand_43 = block_41: {
                                const operand_40 = block_39: {
                                    const operand_37 = (block_35: {
                                        break :block_35 value_20;
                                    }).payloads;
                                    const operand_38 = block_36: {
                                        break :block_36 value_19;
                                    };

                                    if ((operand_38 >= (operand_37).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_39 (operand_37)[@intCast(operand_38)];
                                };

                                break :block_41 (try function_53(allocator, operand_40));
                            };

                            if ((operand_43 >= (operand_42).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_44 (operand_42)[@intCast(operand_43)];
                        };

                        break :block_46 (try function_53(allocator, operand_45));
                    };
                    const value_26: (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850 = (if ((!block_18: {
                        const operand_16 = (((value_17).context).prepared).pure;
                        const operand_17 = block_15: {
                            break :block_15 value_23;
                        };

                        if ((operand_17 >= (operand_16).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_18 (operand_16)[@intCast(operand_17)];
                    })) block_20: {
                        const value_24: (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850 = value_17;
                        const value_25: (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850 = block_19: {
                            break :block_19 @as((zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850, (zx_abi).value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850{ .context = (value_24).context, .first = (value_24).first, .index = (value_24).index, .valid = false, });
                        };

                        break :block_20 value_25;
                    } else block_33: {
                        _ = block_32: {
                            const operand_21 = (value_18).writer;
                            const operand_22 = @as((zx_abi).zx_type_63, .Expression);
                            const operand_24 = block_23: {
                                break :block_23 value_19;
                            };
                            const operand_25 = @as(u64, 0);
                            const operand_26 = @as(u64, 0);
                            const operand_27 = (zx_abi).zx_type_64{ .phase = operand_22, .a = operand_24, .b = operand_25, .c = operand_26, };
                            const operand_28 = (&operand_27);
                            const operand_29 = (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .a = (operand_28).a, .b = (operand_28).b, .c = (operand_28).c, .phase = (operand_28).phase, .zx_origin = operand_28, };

                            var state_borrow_30: (zx_abi).zx_type_64 = undefined;

                            state_borrow_30 = (zx_abi).zx_type_64{ .a = (operand_29).a, .b = (operand_29).b, .c = (operand_29).c, .phase = (operand_29).phase, };

                            const operand_31 = (zx_abi).zx_type_75{ .writer = operand_21, .frame = ((operand_29).zx_origin orelse (&state_borrow_30)), };

                            break :block_32 (try function_59(allocator, (&operand_31)));
                        };

                        break :block_33 value_17;
                    });

                    break :block_47 value_26;
                });

                break :block_55 value_27;
            };
        }

        break :block_56 (state_1).valid;
    };
}

fn function_61(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: (zx_abi).zx_type_17 = ((((&value_1)).body).control).*;
    const value_3: (zx_abi).zx_type_11 = block_128: {
        const operand_126 = ((&value_2)).statement_kinds;
        const operand_127 = ((in).frame).a;

        if ((operand_127 >= (operand_126).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_128 (operand_126)[@intCast(operand_127)];
    };
    const value_4: u64 = (try function_53(allocator, block_125: {
        const operand_123 = ((&value_2)).statement_payloads;
        const operand_124 = ((in).frame).a;

        if ((operand_124 >= (operand_123).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_125 (operand_123)[@intCast(operand_124)];
    }));
    const value_5: *const (zx_abi).zx_type_44 = ((&value_1)).writer;

    if ((value_3 == @as((zx_abi).zx_type_11, .Parallel))) {
        return block_122: {
            const operand_114 = (in).context;
            const operand_115 = @as((zx_abi).zx_type_63, .BlockNext);
            const operand_116 = value_4;
            const operand_117 = @as(u64, 0);
            const operand_118 = @as(u64, 0);
            const operand_119 = (zx_abi).zx_type_64{ .phase = operand_115, .a = operand_116, .b = operand_117, .c = operand_118, };
            const operand_120 = (&operand_119);
            const operand_121 = (zx_abi).zx_type_68{ .context = operand_114, .frame = operand_120, };

            break :block_122 (try function_60(allocator, (&operand_121)));
        };
    }

    if ((value_3 == @as((zx_abi).zx_type_11, .Result))) {
        const value_6: ?u32 = block_113: {
            const operand_111 = ((&value_2)).results;
            const operand_112 = value_4;

            if ((operand_112 >= (operand_111).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_113 (operand_111)[@intCast(operand_112)];
        };

        if ((value_6 == null)) {
            return (((&value_1)).output_type == @as(u32, 0));
        }

        const value_7: u64 = (try function_53(allocator, value_6.?));

        if ((block_110: {
            const operand_108 = ((((&value_1)).body).expressions).types;
            const operand_109 = value_7;

            if ((operand_109 >= (operand_108).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_110 (operand_108)[@intCast(operand_109)];
        } != ((&value_1)).output_type)) {
            return false;
        }

        _ = block_107: {
            const operand_99 = value_5;
            const operand_100 = @as((zx_abi).zx_type_63, .Expression);
            const operand_101 = value_7;
            const operand_102 = @as(u64, 0);
            const operand_103 = @as(u64, 0);
            const operand_104 = (zx_abi).zx_type_64{ .phase = operand_100, .a = operand_101, .b = operand_102, .c = operand_103, };
            const operand_105 = (&operand_104);
            const operand_106 = (zx_abi).zx_type_75{ .writer = operand_99, .frame = operand_105, };

            break :block_107 (try function_59(allocator, (&operand_106)));
        };

        return true;
    }

    if ((value_3 == @as((zx_abi).zx_type_11, .StoreSet))) {
        const value_8: u64 = (try function_53(allocator, block_98: {
            const operand_96 = ((&value_2)).setter_slots;
            const operand_97 = value_4;

            if ((operand_97 >= (operand_96).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_98 (operand_96)[@intCast(operand_97)];
        }));
        const value_9: u64 = (try function_53(allocator, block_95: {
            const operand_93 = ((&value_2)).setter_values;
            const operand_94 = value_4;

            if ((operand_94 >= (operand_93).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_95 (operand_93)[@intCast(operand_94)];
        }));

        if (((((!((&value_1)).transaction) or (value_8 >= @as(u64, (((((&value_1)).body).stores).paths).len))) or (!block_86: {
            const operand_84 = ((((&value_1)).body).stores).writable;
            const operand_85 = value_8;

            if ((operand_85 >= (operand_84).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_86 (operand_84)[@intCast(operand_85)];
        })) or (block_89: {
            const operand_87 = ((((&value_1)).body).expressions).types;
            const operand_88 = value_9;

            if ((operand_88 >= (operand_87).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_89 (operand_87)[@intCast(operand_88)];
        } != block_92: {
            const operand_90 = ((((&value_1)).body).stores).types;
            const operand_91 = value_8;

            if ((operand_91 >= (operand_90).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_92 (operand_90)[@intCast(operand_91)];
        }))) {
            return false;
        }

        _ = block_83: {
            const operand_75 = value_5;
            const operand_76 = @as((zx_abi).zx_type_63, .Expression);
            const operand_77 = value_9;
            const operand_78 = @as(u64, 0);
            const operand_79 = @as(u64, 0);
            const operand_80 = (zx_abi).zx_type_64{ .phase = operand_76, .a = operand_77, .b = operand_78, .c = operand_79, };
            const operand_81 = (&operand_80);
            const operand_82 = (zx_abi).zx_type_75{ .writer = operand_75, .frame = operand_81, };

            break :block_83 (try function_59(allocator, (&operand_82)));
        };

        return true;
    }

    if ((value_3 == @as((zx_abi).zx_type_11, .Constant))) {
        _ = block_41: {
            const operand_27 = value_5;
            const operand_28 = @as((zx_abi).zx_type_63, .Declare);
            const operand_32 = (try function_53(allocator, block_31: {
                const operand_29 = ((&value_2)).constant_symbols;
                const operand_30 = value_4;

                if ((operand_30 >= (operand_29).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_31 (operand_29)[@intCast(operand_30)];
            }));
            const operand_36 = (try function_53(allocator, block_35: {
                const operand_33 = ((&value_2)).constant_values;
                const operand_34 = value_4;

                if ((operand_34 >= (operand_33).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_35 (operand_33)[@intCast(operand_34)];
            }));
            const operand_37 = @as(u64, 0);
            const operand_38 = (zx_abi).zx_type_64{ .phase = operand_28, .a = operand_32, .b = operand_36, .c = operand_37, };
            const operand_39 = (&operand_38);
            const operand_40 = (zx_abi).zx_type_75{ .writer = operand_27, .frame = operand_39, };

            break :block_41 (try function_59(allocator, (&operand_40)));
        };
    } else {
        if ((value_3 == @as((zx_abi).zx_type_11, .Destructure))) {
            _ = block_50: {
                const operand_42 = value_5;
                const operand_43 = @as((zx_abi).zx_type_63, .Destructure);
                const operand_44 = value_4;
                const operand_45 = @as(u64, 0);
                const operand_46 = @as(u64, 0);
                const operand_47 = (zx_abi).zx_type_64{ .phase = operand_43, .a = operand_44, .b = operand_45, .c = operand_46, };
                const operand_48 = (&operand_47);
                const operand_49 = (zx_abi).zx_type_75{ .writer = operand_42, .frame = operand_48, };

                break :block_50 (try function_59(allocator, (&operand_49)));
            };
        } else {
            if ((value_3 == @as((zx_abi).zx_type_11, .Branch))) {
                if ((block_65: {
                    const operand_63 = ((((&value_1)).body).expressions).types;
                    const operand_64 = (try function_53(allocator, block_62: {
                        const operand_60 = ((&value_2)).branch_conditions;
                        const operand_61 = value_4;

                        if ((operand_61 >= (operand_60).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_62 (operand_60)[@intCast(operand_61)];
                    }));

                    if ((operand_64 >= (operand_63).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_65 (operand_63)[@intCast(operand_64)];
                } != @as(u32, 1))) {
                    return false;
                }

                _ = block_59: {
                    const operand_51 = value_5;
                    const operand_52 = @as((zx_abi).zx_type_63, .Branch);
                    const operand_53 = value_4;
                    const operand_54 = ((in).frame).b;
                    const operand_55 = @as(u64, 0);
                    const operand_56 = (zx_abi).zx_type_64{ .phase = operand_52, .a = operand_53, .b = operand_54, .c = operand_55, };
                    const operand_57 = (&operand_56);
                    const operand_58 = (zx_abi).zx_type_75{ .writer = operand_51, .frame = operand_57, };

                    break :block_59 (try function_59(allocator, (&operand_58)));
                };
            } else {
                if ((value_3 == @as((zx_abi).zx_type_11, .Switch))) {
                    _ = block_74: {
                        const operand_66 = value_5;
                        const operand_67 = @as((zx_abi).zx_type_63, .Switch);
                        const operand_68 = value_4;
                        const operand_69 = ((in).frame).b;
                        const operand_70 = @as(u64, 0);
                        const operand_71 = (zx_abi).zx_type_64{ .phase = operand_67, .a = operand_68, .b = operand_69, .c = operand_70, };
                        const operand_72 = (&operand_71);
                        const operand_73 = (zx_abi).zx_type_75{ .writer = operand_66, .frame = operand_72, };

                        break :block_74 (try function_59(allocator, (&operand_73)));
                    };
                }
            }
        }
    }

    const value_10: u32 = block_26: {
        const operand_10 = value_3;

        break :block_26 (if ((operand_10 == @as((zx_abi).zx_type_11, .Constant))) block_25: {
            const operand_23 = ((&value_2)).constant_values;
            const operand_24 = value_4;

            if ((operand_24 >= (operand_23).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_25 (operand_23)[@intCast(operand_24)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_11, .Destructure))) block_22: {
            const operand_20 = ((&value_2)).destructure_values;
            const operand_21 = value_4;

            if ((operand_21 >= (operand_20).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_22 (operand_20)[@intCast(operand_21)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_11, .Branch))) block_19: {
            const operand_17 = ((&value_2)).branch_conditions;
            const operand_18 = value_4;

            if ((operand_18 >= (operand_17).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_19 (operand_17)[@intCast(operand_18)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_11, .Switch))) block_16: {
            const operand_14 = ((&value_2)).selection_subjects;
            const operand_15 = value_4;

            if ((operand_15 >= (operand_14).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_16 (operand_14)[@intCast(operand_15)];
        } else block_13: {
            const operand_11 = ((&value_2)).evaluations;
            const operand_12 = value_4;

            if ((operand_12 >= (operand_11).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_13 (operand_11)[@intCast(operand_12)];
        }))));
    };

    _ = block_9: {
        const operand_1 = value_5;
        const operand_2 = @as((zx_abi).zx_type_63, .Expression);
        const operand_3 = (try function_53(allocator, value_10));
        const operand_4 = @as(u64, 0);
        const operand_5 = @as(u64, 0);
        const operand_6 = (zx_abi).zx_type_64{ .phase = operand_2, .a = operand_3, .b = operand_4, .c = operand_5, };
        const operand_7 = (&operand_6);
        const operand_8 = (zx_abi).zx_type_75{ .writer = operand_1, .frame = operand_7, };

        break :block_9 (try function_59(allocator, (&operand_8)));
    };

    return true;
}

fn function_62(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_64 = ((in).frame).*;
    const value_2: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_3: (zx_abi).zx_type_17 = ((((&value_2)).body).control).*;

    if ((((&value_1)).phase == @as((zx_abi).zx_type_63, .Block))) {
        if ((((&value_1)).b > @as(u64, 256))) {
            return false;
        }

        _ = block_46: {
            const operand_38 = ((&value_2)).writer;
            const operand_39 = @as((zx_abi).zx_type_63, .Restore);
            const operand_40 = (try function_39(allocator, ((&value_2)).writer));
            const operand_41 = (try function_45(allocator, ((&value_2)).writer));
            const operand_42 = (try function_46(allocator, ((&value_2)).writer));
            const operand_43 = (zx_abi).zx_type_64{ .phase = operand_39, .a = operand_40, .b = operand_41, .c = operand_42, };
            const operand_44 = (&operand_43);
            const operand_45 = (zx_abi).zx_type_75{ .writer = operand_38, .frame = operand_44, };

            break :block_46 (try function_59(allocator, (&operand_45)));
        };

        _ = block_37: {
            const operand_29 = ((&value_2)).writer;
            const operand_30 = @as((zx_abi).zx_type_63, .BlockNext);
            const operand_31 = ((&value_1)).a;
            const operand_32 = @as(u64, 0);
            const operand_33 = ((&value_1)).b;
            const operand_34 = (zx_abi).zx_type_64{ .phase = operand_30, .a = operand_31, .b = operand_32, .c = operand_33, };
            const operand_35 = (&operand_34);
            const operand_36 = (zx_abi).zx_type_75{ .writer = operand_29, .frame = operand_35, };

            break :block_37 (try function_59(allocator, (&operand_36)));
        };

        return true;
    }

    const value_4: u64 = (try function_53(allocator, block_28: {
        const operand_26 = ((&value_3)).block_count;
        const operand_27 = ((&value_1)).a;

        if ((operand_27 >= (operand_26).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_28 (operand_26)[@intCast(operand_27)];
    }));

    if ((((&value_1)).b == value_4)) {
        return true;
    }

    const value_5: u64 = (try function_53(allocator, block_25: {
        const operand_23 = ((&value_3)).block_first;
        const operand_24 = ((&value_1)).a;

        if ((operand_24 >= (operand_23).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_25 (operand_23)[@intCast(operand_24)];
    }));

    if (((((&value_1)).b != @as(u64, 0)) and block_22: {
        const operand_19 = (in).context;
        const operand_20 = ((value_5 + ((&value_1)).b) - @as(u64, 1));
        const operand_21 = (zx_abi).zx_type_74{ .context = operand_19, .statement = operand_20, };

        break :block_22 (try function_58(allocator, (&operand_21)));
    })) {
        return false;
    }

    _ = block_18: {
        const operand_10 = ((&value_2)).writer;
        const operand_11 = @as((zx_abi).zx_type_63, .BlockNext);
        const operand_12 = ((&value_1)).a;
        const operand_13 = (((&value_1)).b + @as(u64, 1));
        const operand_14 = ((&value_1)).c;
        const operand_15 = (zx_abi).zx_type_64{ .phase = operand_11, .a = operand_12, .b = operand_13, .c = operand_14, };
        const operand_16 = (&operand_15);
        const operand_17 = (zx_abi).zx_type_75{ .writer = operand_10, .frame = operand_16, };

        break :block_18 (try function_59(allocator, (&operand_17)));
    };

    return block_9: {
        const operand_1 = (in).context;
        const operand_2 = @as((zx_abi).zx_type_63, .BlockNext);
        const operand_3 = (value_5 + ((&value_1)).b);
        const operand_4 = ((&value_1)).c;
        const operand_5 = @as(u64, 0);
        const operand_6 = (zx_abi).zx_type_64{ .phase = operand_2, .a = operand_3, .b = operand_4, .c = operand_5, };
        const operand_7 = (&operand_6);
        const operand_8 = (zx_abi).zx_type_68{ .context = operand_1, .frame = operand_7, };

        break :block_9 (try function_61(allocator, (&operand_8)));
    };
}

fn function_63(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: *const (zx_abi).zx_type_44 = (((in).context).program).writer;
    const value_2: (zx_abi).zx_type_17 = (((((in).context).program).body).control).*;
    const value_3: u64 = ((in).frame).a;
    const value_4: u64 = (try function_53(allocator, block_99: {
        const operand_97 = ((&value_2)).branch_conditions;
        const operand_98 = value_3;

        if ((operand_98 >= (operand_97).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_99 (operand_97)[@intCast(operand_98)];
    }));

    if ((((in).frame).phase == @as((zx_abi).zx_type_63, .BranchPost))) {
        _ = block_96: {
            const operand_95 = @as((zx_abi).zx_type_48, block_94: {
                const operand_91 = value_1;
                const operand_92 = ((in).frame).b;
                const operand_93 = ((in).frame).c;

                break :block_94 .{ operand_91, operand_92, operand_93, };
            });

            break :block_96 (try function_47(allocator, (&operand_95)));
        };

        if (block_81: {
            const operand_79 = (((in).context).prepared).returns;
            const operand_80 = (try function_53(allocator, block_78: {
                const operand_76 = ((&value_2)).branch_no;
                const operand_77 = value_3;

                if ((operand_77 >= (operand_76).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_78 (operand_76)[@intCast(operand_77)];
            }));

            if ((operand_80 >= (operand_79).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_81 (operand_79)[@intCast(operand_80)];
        }) {
            _ = block_90: {
                const operand_82 = value_1;
                const operand_83 = @as((zx_abi).zx_type_63, .Assume);
                const operand_84 = value_4;
                const operand_85 = @as(u64, 1);
                const operand_86 = @as(u64, 0);
                const operand_87 = (zx_abi).zx_type_64{ .phase = operand_83, .a = operand_84, .b = operand_85, .c = operand_86, };
                const operand_88 = (&operand_87);
                const operand_89 = (zx_abi).zx_type_75{ .writer = operand_82, .frame = operand_88, };

                break :block_90 (try function_59(allocator, (&operand_89)));
            };
        }

        if (block_66: {
            const operand_64 = (((in).context).prepared).returns;
            const operand_65 = (try function_53(allocator, block_63: {
                const operand_61 = ((&value_2)).branch_yes;
                const operand_62 = value_3;

                if ((operand_62 >= (operand_61).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_63 (operand_61)[@intCast(operand_62)];
            }));

            if ((operand_65 >= (operand_64).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_66 (operand_64)[@intCast(operand_65)];
        }) {
            _ = block_75: {
                const operand_67 = value_1;
                const operand_68 = @as((zx_abi).zx_type_63, .Assume);
                const operand_69 = value_4;
                const operand_70 = @as(u64, 0);
                const operand_71 = @as(u64, 0);
                const operand_72 = (zx_abi).zx_type_64{ .phase = operand_68, .a = operand_69, .b = operand_70, .c = operand_71, };
                const operand_73 = (&operand_72);
                const operand_74 = (zx_abi).zx_type_75{ .writer = operand_67, .frame = operand_73, };

                break :block_75 (try function_59(allocator, (&operand_74)));
            };
        }

        return true;
    }

    const value_5: u64 = (try function_45(allocator, value_1));
    const value_6: u64 = (try function_46(allocator, value_1));

    _ = block_60: {
        const operand_52 = value_1;
        const operand_53 = @as((zx_abi).zx_type_63, .BranchPost);
        const operand_54 = value_3;
        const operand_55 = value_5;
        const operand_56 = value_6;
        const operand_57 = (zx_abi).zx_type_64{ .phase = operand_53, .a = operand_54, .b = operand_55, .c = operand_56, };
        const operand_58 = (&operand_57);
        const operand_59 = (zx_abi).zx_type_75{ .writer = operand_52, .frame = operand_58, };

        break :block_60 (try function_59(allocator, (&operand_59)));
    };

    _ = block_51: {
        const operand_40 = value_1;
        const operand_41 = @as((zx_abi).zx_type_63, .Block);
        const operand_45 = (try function_53(allocator, block_44: {
            const operand_42 = ((&value_2)).branch_no;
            const operand_43 = value_3;

            if ((operand_43 >= (operand_42).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_44 (operand_42)[@intCast(operand_43)];
        }));
        const operand_46 = (((in).frame).b + @as(u64, 1));
        const operand_47 = @as(u64, 0);
        const operand_48 = (zx_abi).zx_type_64{ .phase = operand_41, .a = operand_45, .b = operand_46, .c = operand_47, };
        const operand_49 = (&operand_48);
        const operand_50 = (zx_abi).zx_type_75{ .writer = operand_40, .frame = operand_49, };

        break :block_51 (try function_59(allocator, (&operand_50)));
    };

    _ = block_39: {
        const operand_31 = value_1;
        const operand_32 = @as((zx_abi).zx_type_63, .Assume);
        const operand_33 = value_4;
        const operand_34 = @as(u64, 0);
        const operand_35 = @as(u64, 0);
        const operand_36 = (zx_abi).zx_type_64{ .phase = operand_32, .a = operand_33, .b = operand_34, .c = operand_35, };
        const operand_37 = (&operand_36);
        const operand_38 = (zx_abi).zx_type_75{ .writer = operand_31, .frame = operand_37, };

        break :block_39 (try function_59(allocator, (&operand_38)));
    };

    _ = block_30: {
        const operand_22 = value_1;
        const operand_23 = @as((zx_abi).zx_type_63, .RestoreFacts);
        const operand_24 = value_5;
        const operand_25 = value_6;
        const operand_26 = @as(u64, 0);
        const operand_27 = (zx_abi).zx_type_64{ .phase = operand_23, .a = operand_24, .b = operand_25, .c = operand_26, };
        const operand_28 = (&operand_27);
        const operand_29 = (zx_abi).zx_type_75{ .writer = operand_22, .frame = operand_28, };

        break :block_30 (try function_59(allocator, (&operand_29)));
    };

    _ = block_21: {
        const operand_10 = value_1;
        const operand_11 = @as((zx_abi).zx_type_63, .Block);
        const operand_15 = (try function_53(allocator, block_14: {
            const operand_12 = ((&value_2)).branch_yes;
            const operand_13 = value_3;

            if ((operand_13 >= (operand_12).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_14 (operand_12)[@intCast(operand_13)];
        }));
        const operand_16 = (((in).frame).b + @as(u64, 1));
        const operand_17 = @as(u64, 0);
        const operand_18 = (zx_abi).zx_type_64{ .phase = operand_11, .a = operand_15, .b = operand_16, .c = operand_17, };
        const operand_19 = (&operand_18);
        const operand_20 = (zx_abi).zx_type_75{ .writer = operand_10, .frame = operand_19, };

        break :block_21 (try function_59(allocator, (&operand_20)));
    };

    _ = block_9: {
        const operand_1 = value_1;
        const operand_2 = @as((zx_abi).zx_type_63, .Assume);
        const operand_3 = value_4;
        const operand_4 = @as(u64, 1);
        const operand_5 = @as(u64, 0);
        const operand_6 = (zx_abi).zx_type_64{ .phase = operand_2, .a = operand_3, .b = operand_4, .c = operand_5, };
        const operand_7 = (&operand_6);
        const operand_8 = (zx_abi).zx_type_75{ .writer = operand_1, .frame = operand_7, };

        break :block_9 (try function_59(allocator, (&operand_8)));
    };

    return true;
}

fn function_64(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_65) error{ OutOfMemory, }!void {
    @setRuntimeSafety(true);

    _ = block_16: {
        const operand_6 = block_5: {
            const operand_2 = (in).writer;
            const operand_3 = @as(u64, ((((in).body).symbols).names).len);
            const operand_4 = @as(u64, 0);

            break :block_5 (zx_abi).zx_type_78{ .writer = operand_2, .count = operand_3, .index = operand_4, };
        };

        var state_1: (zx_abi).value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = (zx_abi).value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (operand_6).count, .index = (operand_6).index, .writer = (operand_6).writer, .zx_origin = (&operand_6), };

        while (((state_1).index < (state_1).count)) {
            state_1 = block_15: {
                _ = block_14: {
                    const operand_13 = @as((zx_abi).zx_type_47, block_12: {
                        const operand_9 = (state_1).writer;
                        const operand_10 = (state_1).index;
                        const operand_11 = false;

                        break :block_12 .{ operand_9, operand_10, operand_11, };
                    });

                    break :block_14 (try function_38(allocator, (&operand_13)));
                };

                const value_3: (zx_abi).value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = state_1;
                const value_4: u64 = (value_3).index;
                const value_5: (zx_abi).value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = block_8: {
                    break :block_8 @as((zx_abi).value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, (zx_abi).value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .count = (value_3).count, .index = (block_7: {
                        break :block_7 value_4;
                    } + @as(u64, 1)), .writer = (value_3).writer, });
                };

                break :block_15 value_5;
            };
        }

        break :block_16 {};
    };
}

fn function_65(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_79) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: *const (zx_abi).zx_type_44 = ((in).program).writer;

    if (((in).symbol >= @as(u64, (((((in).program).body).symbols).names).len))) {
        return false;
    }

    const value_2: u32 = block_40: {
        const operand_38 = ((((in).program).body).symbols).types;
        const operand_39 = (in).symbol;

        if ((operand_39 >= (operand_38).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_40 (operand_38)[@intCast(operand_39)];
    };

    if (((in).mode == @as((zx_abi).zx_type_69, .Ordinary))) {
        if (((block_16: {
            const operand_15 = @as((zx_abi).zx_type_46, block_14: {
                const operand_12 = value_1;
                const operand_13 = (in).symbol;

                break :block_14 .{ operand_12, operand_13, };
            });

            break :block_16 (try function_41(allocator, (&operand_15)));
        } or (value_2 != (in).type_id)) or (value_2 == @as(u32, 0)))) {
            return false;
        }
    } else {
        if ((block_27: {
            const operand_26 = @as((zx_abi).zx_type_46, block_25: {
                const operand_23 = value_1;
                const operand_24 = (in).symbol;

                break :block_25 .{ operand_23, operand_24, };
            });

            break :block_27 (try function_37(allocator, (&operand_26)));
        } or (block_32: {
            const operand_31 = @as((zx_abi).zx_type_46, block_30: {
                const operand_28 = value_1;
                const operand_29 = (in).symbol;

                break :block_30 .{ operand_28, operand_29, };
            });

            break :block_32 (try function_41(allocator, (&operand_31)));
        } and (block_37: {
            const operand_36 = @as((zx_abi).zx_type_46, block_35: {
                const operand_33 = value_1;
                const operand_34 = (in).symbol;

                break :block_35 .{ operand_33, operand_34, };
            });

            break :block_37 (try function_43(allocator, (&operand_36)));
        } != ((in).owner + @as(u64, 1)))))) {
            return false;
        }

        if ((((in).mode == @as((zx_abi).zx_type_69, .Scope)) and (value_2 == @as(u32, 0)))) {
            return false;
        }

        _ = block_22: {
            const operand_21 = @as((zx_abi).zx_type_48, block_20: {
                const operand_17 = value_1;
                const operand_18 = (in).symbol;
                const operand_19 = ((in).owner + @as(u64, 1));

                break :block_20 .{ operand_17, operand_18, operand_19, };
            });

            break :block_22 (try function_44(allocator, (&operand_21)));
        };
    }

    _ = block_11: {
        const operand_10 = @as((zx_abi).zx_type_46, block_9: {
            const operand_7 = value_1;
            const operand_8 = (in).symbol;

            break :block_9 .{ operand_7, operand_8, };
        });

        break :block_11 (try function_42(allocator, (&operand_10)));
    };

    _ = block_6: {
        const operand_5 = @as((zx_abi).zx_type_47, block_4: {
            const operand_1 = value_1;
            const operand_2 = (in).symbol;
            const operand_3 = true;

            break :block_4 .{ operand_1, operand_2, operand_3, };
        });

        break :block_6 (try function_38(allocator, (&operand_5)));
    };

    return true;
}

fn function_66(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: *const (zx_abi).zx_type_44 = ((&value_1)).writer;
    const value_3: (zx_abi).zx_type_35 = ((((&value_1)).body).expressions).*;
    const value_4: u64 = (try function_53(allocator, block_118: {
        const operand_116 = ((&value_3)).payloads;
        const operand_117 = ((in).frame).a;

        if ((operand_117 >= (operand_116).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_118 (operand_116)[@intCast(operand_117)];
    }));

    if ((((in).frame).phase != @as((zx_abi).zx_type_63, .IterationBody))) {
        _ = block_115: {
            const operand_107 = value_2;
            const operand_108 = @as((zx_abi).zx_type_63, .Restore);
            const operand_109 = (try function_39(allocator, value_2));
            const operand_110 = (try function_45(allocator, value_2));
            const operand_111 = (try function_46(allocator, value_2));
            const operand_112 = (zx_abi).zx_type_64{ .phase = operand_108, .a = operand_109, .b = operand_110, .c = operand_111, };
            const operand_113 = (&operand_112);
            const operand_114 = (zx_abi).zx_type_75{ .writer = operand_107, .frame = operand_113, };

            break :block_115 (try function_59(allocator, (&operand_114)));
        };
    }

    _ = (try function_64(allocator, (&value_1)));

    if ((((in).frame).phase == @as((zx_abi).zx_type_63, .Transform))) {
        const value_13: (zx_abi).zx_type_80 = block_106: {
            const operand_64 = block_63: {
                const operand_51 = (&value_1);
                const operand_52 = ((in).frame).a;
                const operand_53 = (try function_53(allocator, block_56: {
                    const operand_54 = ((&value_3)).transform_first;
                    const operand_55 = value_4;

                    if ((operand_55 >= (operand_54).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_56 (operand_54)[@intCast(operand_55)];
                }));
                const operand_57 = (try function_53(allocator, block_60: {
                    const operand_58 = ((&value_3)).transform_count;
                    const operand_59 = value_4;

                    if ((operand_59 >= (operand_58).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_60 (operand_58)[@intCast(operand_59)];
                }));
                const operand_61 = @as(u64, 0);
                const operand_62 = true;

                break :block_63 (zx_abi).zx_type_80{ .program = operand_51, .owner = operand_52, .first = operand_53, .count = operand_57, .index = operand_61, .valid = operand_62, };
            };

            var state_50: (zx_abi).value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = (zx_abi).value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3{ .count = (operand_64).count, .first = (operand_64).first, .index = (operand_64).index, .owner = (operand_64).owner, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = ((((operand_64).program).body).control).block_count, .block_first = ((((operand_64).program).body).control).block_first, .branch_conditions = ((((operand_64).program).body).control).branch_conditions, .branch_no = ((((operand_64).program).body).control).branch_no, .branch_yes = ((((operand_64).program).body).control).branch_yes, .case_bodies = ((((operand_64).program).body).control).case_bodies, .case_values = ((((operand_64).program).body).control).case_values, .constant_symbols = ((((operand_64).program).body).control).constant_symbols, .constant_values = ((((operand_64).program).body).control).constant_values, .destructure_count = ((((operand_64).program).body).control).destructure_count, .destructure_first = ((((operand_64).program).body).control).destructure_first, .destructure_symbols = ((((operand_64).program).body).control).destructure_symbols, .destructure_values = ((((operand_64).program).body).control).destructure_values, .evaluations = ((((operand_64).program).body).control).evaluations, .parallel_count = ((((operand_64).program).body).control).parallel_count, .parallel_first = ((((operand_64).program).body).control).parallel_first, .parallel_symbols = ((((operand_64).program).body).control).parallel_symbols, .parallel_values = ((((operand_64).program).body).control).parallel_values, .results = ((((operand_64).program).body).control).results, .selection_count = ((((operand_64).program).body).control).selection_count, .selection_exhaustive = ((((operand_64).program).body).control).selection_exhaustive, .selection_first = ((((operand_64).program).body).control).selection_first, .selection_subjects = ((((operand_64).program).body).control).selection_subjects, .setter_slots = ((((operand_64).program).body).control).setter_slots, .setter_values = ((((operand_64).program).body).control).setter_values, .statement_kinds = ((((operand_64).program).body).control).statement_kinds, .statement_payloads = ((((operand_64).program).body).control).statement_payloads, .zx_origin = (((operand_64).program).body).control, }, .expressions = (((operand_64).program).body).expressions, .root = (((operand_64).program).body).root, .stores = (((operand_64).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_64).program).body).symbols).names, .ownership = ((((operand_64).program).body).symbols).ownership, .span_end = ((((operand_64).program).body).symbols).span_end, .span_start = ((((operand_64).program).body).symbols).span_start, .types = ((((operand_64).program).body).symbols).types, .zx_origin = (((operand_64).program).body).symbols, }, .zx_origin = ((operand_64).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = (((operand_64).program).functions).expressions, .native_concurrent = (((operand_64).program).functions).native_concurrent, .native_modules = (((operand_64).program).functions).native_modules, .stores = (((operand_64).program).functions).stores, .zx_origin = ((operand_64).program).functions, }, .output_type = ((operand_64).program).output_type, .table = ((operand_64).program).table, .transaction = ((operand_64).program).transaction, .writer = ((operand_64).program).writer, .zx_origin = (operand_64).program, }, .valid = (operand_64).valid, .zx_origin = (&operand_64), };

            while (((state_50).valid and ((state_50).index < (state_50).count))) {
                state_50 = block_93: {
                    const value_7: u64 = block_92: {
                        const operand_91 = block_90: {
                            const operand_88 = ((((state_50).program).body).expressions).transform_parameters;
                            const operand_89 = ((state_50).first + (state_50).index);

                            if ((operand_89 >= (operand_88).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_90 (operand_88)[@intCast(operand_89)];
                        };

                        break :block_92 (try function_53(allocator, operand_91));
                    };
                    const value_8: (zx_abi).value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = state_50;
                    const value_9: (zx_abi).value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = block_87: {
                        break :block_87 @as((zx_abi).value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3, (zx_abi).value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3{ .count = (value_8).count, .first = (value_8).first, .index = (value_8).index, .owner = (value_8).owner, .program = (value_8).program, .valid = block_86: {
                            const operand_67 = (state_50).program;

                            var state_borrow_68: (zx_abi).zx_type_17 = undefined;

                            state_borrow_68 = (zx_abi).zx_type_17{ .block_count = (((operand_67).body).control).block_count, .block_first = (((operand_67).body).control).block_first, .branch_conditions = (((operand_67).body).control).branch_conditions, .branch_no = (((operand_67).body).control).branch_no, .branch_yes = (((operand_67).body).control).branch_yes, .case_bodies = (((operand_67).body).control).case_bodies, .case_values = (((operand_67).body).control).case_values, .constant_symbols = (((operand_67).body).control).constant_symbols, .constant_values = (((operand_67).body).control).constant_values, .destructure_count = (((operand_67).body).control).destructure_count, .destructure_first = (((operand_67).body).control).destructure_first, .destructure_symbols = (((operand_67).body).control).destructure_symbols, .destructure_values = (((operand_67).body).control).destructure_values, .evaluations = (((operand_67).body).control).evaluations, .parallel_count = (((operand_67).body).control).parallel_count, .parallel_first = (((operand_67).body).control).parallel_first, .parallel_symbols = (((operand_67).body).control).parallel_symbols, .parallel_values = (((operand_67).body).control).parallel_values, .results = (((operand_67).body).control).results, .selection_count = (((operand_67).body).control).selection_count, .selection_exhaustive = (((operand_67).body).control).selection_exhaustive, .selection_first = (((operand_67).body).control).selection_first, .selection_subjects = (((operand_67).body).control).selection_subjects, .setter_slots = (((operand_67).body).control).setter_slots, .setter_values = (((operand_67).body).control).setter_values, .statement_kinds = (((operand_67).body).control).statement_kinds, .statement_payloads = (((operand_67).body).control).statement_payloads, };

                            var state_borrow_69: (zx_abi).zx_type_60 = undefined;

                            state_borrow_69 = (zx_abi).zx_type_60{ .names = (((operand_67).body).symbols).names, .ownership = (((operand_67).body).symbols).ownership, .span_end = (((operand_67).body).symbols).span_end, .span_start = (((operand_67).body).symbols).span_start, .types = (((operand_67).body).symbols).types, };

                            var state_borrow_70: (zx_abi).zx_type_61 = undefined;

                            state_borrow_70 = (zx_abi).zx_type_61{ .control = ((((operand_67).body).control).zx_origin orelse (&state_borrow_68)), .expressions = ((operand_67).body).expressions, .root = ((operand_67).body).root, .stores = ((operand_67).body).stores, .symbols = ((((operand_67).body).symbols).zx_origin orelse (&state_borrow_69)), };

                            var state_borrow_71: (zx_abi).zx_type_41 = undefined;

                            state_borrow_71 = (zx_abi).zx_type_41{ .expressions = ((operand_67).functions).expressions, .native_concurrent = ((operand_67).functions).native_concurrent, .native_modules = ((operand_67).functions).native_modules, .stores = ((operand_67).functions).stores, };

                            var state_borrow_72: (zx_abi).zx_type_65 = undefined;

                            state_borrow_72 = (zx_abi).zx_type_65{ .body = (((operand_67).body).zx_origin orelse (&state_borrow_70)), .functions = (((operand_67).functions).zx_origin orelse (&state_borrow_71)), .output_type = (operand_67).output_type, .table = (operand_67).table, .transaction = (operand_67).transaction, .writer = (operand_67).writer, };

                            const operand_73 = ((operand_67).zx_origin orelse (&state_borrow_72));
                            const operand_75 = block_74: {
                                break :block_74 value_7;
                            };
                            const operand_76 = @as(u32, 0);
                            const operand_77 = (state_50).owner;
                            const operand_78 = @as((zx_abi).zx_type_69, .Callback);
                            const operand_79 = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = (((operand_73).body).control).block_count, .block_first = (((operand_73).body).control).block_first, .branch_conditions = (((operand_73).body).control).branch_conditions, .branch_no = (((operand_73).body).control).branch_no, .branch_yes = (((operand_73).body).control).branch_yes, .case_bodies = (((operand_73).body).control).case_bodies, .case_values = (((operand_73).body).control).case_values, .constant_symbols = (((operand_73).body).control).constant_symbols, .constant_values = (((operand_73).body).control).constant_values, .destructure_count = (((operand_73).body).control).destructure_count, .destructure_first = (((operand_73).body).control).destructure_first, .destructure_symbols = (((operand_73).body).control).destructure_symbols, .destructure_values = (((operand_73).body).control).destructure_values, .evaluations = (((operand_73).body).control).evaluations, .parallel_count = (((operand_73).body).control).parallel_count, .parallel_first = (((operand_73).body).control).parallel_first, .parallel_symbols = (((operand_73).body).control).parallel_symbols, .parallel_values = (((operand_73).body).control).parallel_values, .results = (((operand_73).body).control).results, .selection_count = (((operand_73).body).control).selection_count, .selection_exhaustive = (((operand_73).body).control).selection_exhaustive, .selection_first = (((operand_73).body).control).selection_first, .selection_subjects = (((operand_73).body).control).selection_subjects, .setter_slots = (((operand_73).body).control).setter_slots, .setter_values = (((operand_73).body).control).setter_values, .statement_kinds = (((operand_73).body).control).statement_kinds, .statement_payloads = (((operand_73).body).control).statement_payloads, .zx_origin = ((operand_73).body).control, }, .expressions = ((operand_73).body).expressions, .root = ((operand_73).body).root, .stores = ((operand_73).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((operand_73).body).symbols).names, .ownership = (((operand_73).body).symbols).ownership, .span_end = (((operand_73).body).symbols).span_end, .span_start = (((operand_73).body).symbols).span_start, .types = (((operand_73).body).symbols).types, .zx_origin = ((operand_73).body).symbols, }, .zx_origin = (operand_73).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = ((operand_73).functions).expressions, .native_concurrent = ((operand_73).functions).native_concurrent, .native_modules = ((operand_73).functions).native_modules, .stores = ((operand_73).functions).stores, .zx_origin = (operand_73).functions, }, .output_type = (operand_73).output_type, .table = (operand_73).table, .transaction = (operand_73).transaction, .writer = (operand_73).writer, .zx_origin = operand_73, };

                            var state_borrow_80: (zx_abi).zx_type_17 = undefined;

                            state_borrow_80 = (zx_abi).zx_type_17{ .block_count = (((operand_79).body).control).block_count, .block_first = (((operand_79).body).control).block_first, .branch_conditions = (((operand_79).body).control).branch_conditions, .branch_no = (((operand_79).body).control).branch_no, .branch_yes = (((operand_79).body).control).branch_yes, .case_bodies = (((operand_79).body).control).case_bodies, .case_values = (((operand_79).body).control).case_values, .constant_symbols = (((operand_79).body).control).constant_symbols, .constant_values = (((operand_79).body).control).constant_values, .destructure_count = (((operand_79).body).control).destructure_count, .destructure_first = (((operand_79).body).control).destructure_first, .destructure_symbols = (((operand_79).body).control).destructure_symbols, .destructure_values = (((operand_79).body).control).destructure_values, .evaluations = (((operand_79).body).control).evaluations, .parallel_count = (((operand_79).body).control).parallel_count, .parallel_first = (((operand_79).body).control).parallel_first, .parallel_symbols = (((operand_79).body).control).parallel_symbols, .parallel_values = (((operand_79).body).control).parallel_values, .results = (((operand_79).body).control).results, .selection_count = (((operand_79).body).control).selection_count, .selection_exhaustive = (((operand_79).body).control).selection_exhaustive, .selection_first = (((operand_79).body).control).selection_first, .selection_subjects = (((operand_79).body).control).selection_subjects, .setter_slots = (((operand_79).body).control).setter_slots, .setter_values = (((operand_79).body).control).setter_values, .statement_kinds = (((operand_79).body).control).statement_kinds, .statement_payloads = (((operand_79).body).control).statement_payloads, };

                            var state_borrow_81: (zx_abi).zx_type_60 = undefined;

                            state_borrow_81 = (zx_abi).zx_type_60{ .names = (((operand_79).body).symbols).names, .ownership = (((operand_79).body).symbols).ownership, .span_end = (((operand_79).body).symbols).span_end, .span_start = (((operand_79).body).symbols).span_start, .types = (((operand_79).body).symbols).types, };

                            var state_borrow_82: (zx_abi).zx_type_61 = undefined;

                            state_borrow_82 = (zx_abi).zx_type_61{ .control = ((((operand_79).body).control).zx_origin orelse (&state_borrow_80)), .expressions = ((operand_79).body).expressions, .root = ((operand_79).body).root, .stores = ((operand_79).body).stores, .symbols = ((((operand_79).body).symbols).zx_origin orelse (&state_borrow_81)), };

                            var state_borrow_83: (zx_abi).zx_type_41 = undefined;

                            state_borrow_83 = (zx_abi).zx_type_41{ .expressions = ((operand_79).functions).expressions, .native_concurrent = ((operand_79).functions).native_concurrent, .native_modules = ((operand_79).functions).native_modules, .stores = ((operand_79).functions).stores, };

                            var state_borrow_84: (zx_abi).zx_type_65 = undefined;

                            state_borrow_84 = (zx_abi).zx_type_65{ .body = (((operand_79).body).zx_origin orelse (&state_borrow_82)), .functions = (((operand_79).functions).zx_origin orelse (&state_borrow_83)), .output_type = (operand_79).output_type, .table = (operand_79).table, .transaction = (operand_79).transaction, .writer = (operand_79).writer, };

                            const operand_85 = (zx_abi).zx_type_79{ .program = ((operand_79).zx_origin orelse (&state_borrow_84)), .symbol = operand_75, .type_id = operand_76, .owner = operand_77, .mode = operand_78, };

                            break :block_86 (try function_65(allocator, (&operand_85)));
                        }, });
                    };
                    const value_10: (zx_abi).value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = value_9;
                    const value_11: u64 = (value_10).index;
                    const value_12: (zx_abi).value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = block_66: {
                        break :block_66 @as((zx_abi).value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3, (zx_abi).value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3{ .count = (value_10).count, .first = (value_10).first, .index = (block_65: {
                            break :block_65 value_11;
                        } + @as(u64, 1)), .owner = (value_10).owner, .program = (value_10).program, .valid = (value_10).valid, });
                    };

                    break :block_93 value_12;
                };
            }

            break :block_106 block_105: {
                break :block_105 (if (((state_50).zx_origin != null)) ((state_50).zx_origin.?).* else block_104: {
                    break :block_104 (zx_abi).zx_type_80{ .count = (state_50).count, .first = (state_50).first, .index = (state_50).index, .owner = (state_50).owner, .program = (if ((((state_50).program).zx_origin != null)) ((state_50).program).zx_origin.? else block_103: {
                        const operand_102 = (try (allocator).create((zx_abi).zx_type_65));

                        (operand_102).* = (zx_abi).zx_type_65{ .body = (if (((((state_50).program).body).zx_origin != null)) (((state_50).program).body).zx_origin.? else block_99: {
                            const operand_98 = (try (allocator).create((zx_abi).zx_type_61));

                            (operand_98).* = (zx_abi).zx_type_61{ .control = (if ((((((state_50).program).body).control).zx_origin != null)) ((((state_50).program).body).control).zx_origin.? else block_95: {
                                const operand_94 = (try (allocator).create((zx_abi).zx_type_17));

                                (operand_94).* = (zx_abi).zx_type_17{ .block_count = ((((state_50).program).body).control).block_count, .block_first = ((((state_50).program).body).control).block_first, .branch_conditions = ((((state_50).program).body).control).branch_conditions, .branch_no = ((((state_50).program).body).control).branch_no, .branch_yes = ((((state_50).program).body).control).branch_yes, .case_bodies = ((((state_50).program).body).control).case_bodies, .case_values = ((((state_50).program).body).control).case_values, .constant_symbols = ((((state_50).program).body).control).constant_symbols, .constant_values = ((((state_50).program).body).control).constant_values, .destructure_count = ((((state_50).program).body).control).destructure_count, .destructure_first = ((((state_50).program).body).control).destructure_first, .destructure_symbols = ((((state_50).program).body).control).destructure_symbols, .destructure_values = ((((state_50).program).body).control).destructure_values, .evaluations = ((((state_50).program).body).control).evaluations, .parallel_count = ((((state_50).program).body).control).parallel_count, .parallel_first = ((((state_50).program).body).control).parallel_first, .parallel_symbols = ((((state_50).program).body).control).parallel_symbols, .parallel_values = ((((state_50).program).body).control).parallel_values, .results = ((((state_50).program).body).control).results, .selection_count = ((((state_50).program).body).control).selection_count, .selection_exhaustive = ((((state_50).program).body).control).selection_exhaustive, .selection_first = ((((state_50).program).body).control).selection_first, .selection_subjects = ((((state_50).program).body).control).selection_subjects, .setter_slots = ((((state_50).program).body).control).setter_slots, .setter_values = ((((state_50).program).body).control).setter_values, .statement_kinds = ((((state_50).program).body).control).statement_kinds, .statement_payloads = ((((state_50).program).body).control).statement_payloads, };

                                break :block_95 @as(*const (zx_abi).zx_type_17, operand_94);
                            }), .expressions = (((state_50).program).body).expressions, .root = (((state_50).program).body).root, .stores = (((state_50).program).body).stores, .symbols = (if ((((((state_50).program).body).symbols).zx_origin != null)) ((((state_50).program).body).symbols).zx_origin.? else block_97: {
                                const operand_96 = (try (allocator).create((zx_abi).zx_type_60));

                                (operand_96).* = (zx_abi).zx_type_60{ .names = ((((state_50).program).body).symbols).names, .ownership = ((((state_50).program).body).symbols).ownership, .span_end = ((((state_50).program).body).symbols).span_end, .span_start = ((((state_50).program).body).symbols).span_start, .types = ((((state_50).program).body).symbols).types, };

                                break :block_97 @as(*const (zx_abi).zx_type_60, operand_96);
                            }), };

                            break :block_99 @as(*const (zx_abi).zx_type_61, operand_98);
                        }), .functions = (if (((((state_50).program).functions).zx_origin != null)) (((state_50).program).functions).zx_origin.? else block_101: {
                            const operand_100 = (try (allocator).create((zx_abi).zx_type_41));

                            (operand_100).* = (zx_abi).zx_type_41{ .expressions = (((state_50).program).functions).expressions, .native_concurrent = (((state_50).program).functions).native_concurrent, .native_modules = (((state_50).program).functions).native_modules, .stores = (((state_50).program).functions).stores, };

                            break :block_101 @as(*const (zx_abi).zx_type_41, operand_100);
                        }), .output_type = ((state_50).program).output_type, .table = ((state_50).program).table, .transaction = ((state_50).program).transaction, .writer = ((state_50).program).writer, };

                        break :block_103 @as(*const (zx_abi).zx_type_65, operand_102);
                    }), .valid = (state_50).valid, };
                });
            };
        };

        if ((!((&value_13)).valid)) {
            return false;
        }

        _ = block_49: {
            const operand_38 = value_2;
            const operand_39 = @as((zx_abi).zx_type_63, .Expression);
            const operand_43 = (try function_53(allocator, block_42: {
                const operand_40 = ((&value_3)).transform_bodies;
                const operand_41 = value_4;

                if ((operand_41 >= (operand_40).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_42 (operand_40)[@intCast(operand_41)];
            }));
            const operand_44 = (((in).frame).b + @as(u64, 1));
            const operand_45 = (if ((((in).frame).c >= @as(u64, 2))) @as(u64, 3) else @as(u64, 1));
            const operand_46 = (zx_abi).zx_type_64{ .phase = operand_39, .a = operand_43, .b = operand_44, .c = operand_45, };
            const operand_47 = (&operand_46);
            const operand_48 = (zx_abi).zx_type_75{ .writer = operand_38, .frame = operand_47, };

            break :block_49 (try function_59(allocator, (&operand_48)));
        };

        return true;
    }

    const value_14: bool = (((in).frame).phase == @as((zx_abi).zx_type_63, .IterationCondition));
    const value_15: u32 = (if (value_14) block_34: {
        const operand_32 = ((&value_3)).iteration_condition_parameters;
        const operand_33 = value_4;

        if ((operand_33 >= (operand_32).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_34 (operand_32)[@intCast(operand_33)];
    } else block_37: {
        const operand_35 = ((&value_3)).iteration_parameters;
        const operand_36 = value_4;

        if ((operand_36 >= (operand_35).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_37 (operand_35)[@intCast(operand_36)];
    });
    const value_16: u32 = (if (value_14) block_28: {
        const operand_26 = ((&value_3)).iteration_conditions;
        const operand_27 = value_4;

        if ((operand_27 >= (operand_26).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_28 (operand_26)[@intCast(operand_27)];
    } else block_31: {
        const operand_29 = ((&value_3)).iteration_bodies;
        const operand_30 = value_4;

        if ((operand_30 >= (operand_29).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_31 (operand_29)[@intCast(operand_30)];
    });

    if ((!block_25: {
        const operand_19 = (&value_1);
        const operand_20 = (try function_53(allocator, value_15));
        const operand_21 = @as(u32, 0);
        const operand_22 = ((in).frame).a;
        const operand_23 = @as((zx_abi).zx_type_69, .Callback);
        const operand_24 = (zx_abi).zx_type_79{ .program = operand_19, .symbol = operand_20, .type_id = operand_21, .owner = operand_22, .mode = operand_23, };

        break :block_25 (try function_65(allocator, (&operand_24)));
    })) {
        return false;
    }

    if (value_14) {
        _ = block_18: {
            const operand_10 = value_2;
            const operand_11 = @as((zx_abi).zx_type_63, .IterationBody);
            const operand_12 = ((in).frame).a;
            const operand_13 = ((in).frame).b;
            const operand_14 = ((in).frame).c;
            const operand_15 = (zx_abi).zx_type_64{ .phase = operand_11, .a = operand_12, .b = operand_13, .c = operand_14, };
            const operand_16 = (&operand_15);
            const operand_17 = (zx_abi).zx_type_75{ .writer = operand_10, .frame = operand_16, };

            break :block_18 (try function_59(allocator, (&operand_17)));
        };
    }

    _ = block_9: {
        const operand_1 = value_2;
        const operand_2 = @as((zx_abi).zx_type_63, .Expression);
        const operand_3 = (try function_53(allocator, value_16));
        const operand_4 = (((in).frame).b + @as(u64, 1));
        const operand_5 = (if ((((in).frame).c >= @as(u64, 2))) @as(u64, 3) else @as(u64, 1));
        const operand_6 = (zx_abi).zx_type_64{ .phase = operand_2, .a = operand_3, .b = operand_4, .c = operand_5, };
        const operand_7 = (&operand_6);
        const operand_8 = (zx_abi).zx_type_75{ .writer = operand_1, .frame = operand_7, };

        break :block_9 (try function_59(allocator, (&operand_8)));
    };

    return true;
}

fn function_67(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_49 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_2: {
        const operand_1 = in;

        break :block_2 (if ((operand_1 == @as(u8, 0))) @as((zx_abi).zx_type_49, .Scalar) else (if ((operand_1 == @as(u8, 1))) @as((zx_abi).zx_type_49, .Object) else (if ((operand_1 == @as(u8, 2))) @as((zx_abi).zx_type_49, .Optional) else (if ((operand_1 == @as(u8, 3))) @as((zx_abi).zx_type_49, .List) else (if ((operand_1 == @as(u8, 4))) @as((zx_abi).zx_type_49, .Tuple) else (if ((operand_1 == @as(u8, 5))) @as((zx_abi).zx_type_49, .ErrorSet) else (if ((operand_1 == @as(u8, 6))) @as((zx_abi).zx_type_49, .Task) else (if ((operand_1 == @as(u8, 7))) @as((zx_abi).zx_type_49, .Enumeration) else @as((zx_abi).zx_type_49, .NativeReference)))))))));
    };
}

fn function_68(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_81) error{ IndexOutOfBounds, OutOfMemory, }!void {
    @setRuntimeSafety(true);

    const value_1: ?u32 = (in).err;
    const value_2: ?u32 = (in).result;

    if (((((block_3: {
        const operand_1 = ((in).expressions).kinds;
        const operand_2 = (in).value;

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    } == @as((zx_abi).zx_type_22, .Capture)) and ((in).count == @as(u64, 2))) and (value_1 != null)) and (value_2 != null))) {
        _ = block_9: {
            const operand_8 = @as((zx_abi).zx_type_48, block_7: {
                const operand_4 = (in).writer;
                const operand_5 = (try function_53(allocator, value_1.?));
                const operand_6 = (try function_53(allocator, value_2.?));

                break :block_7 .{ operand_4, operand_5, operand_6, };
            });

            break :block_9 (try function_50(allocator, (&operand_8)));
        };
    }
}

fn function_69(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: (zx_abi).zx_type_17 = ((((&value_1)).body).control).*;
    const value_3: u64 = ((in).frame).a;
    const value_4: u64 = (try function_53(allocator, block_91: {
        const operand_89 = ((&value_2)).destructure_values;
        const operand_90 = value_3;

        if ((operand_90 >= (operand_89).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_91 (operand_89)[@intCast(operand_90)];
    }));
    const value_5: u64 = (try function_53(allocator, block_88: {
        const operand_86 = ((((&value_1)).body).expressions).types;
        const operand_87 = value_4;

        if ((operand_87 >= (operand_86).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_88 (operand_86)[@intCast(operand_87)];
    }));
    const value_6: u64 = (try function_53(allocator, block_85: {
        const operand_83 = ((&value_2)).destructure_first;
        const operand_84 = value_3;

        if ((operand_84 >= (operand_83).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_85 (operand_83)[@intCast(operand_84)];
    }));
    const value_7: u64 = (try function_53(allocator, block_82: {
        const operand_80 = ((&value_2)).destructure_count;
        const operand_81 = value_3;

        if ((operand_81 >= (operand_80).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_82 (operand_80)[@intCast(operand_81)];
    }));

    if ((((try function_67(allocator, block_76: {
        const operand_74 = (((&value_1)).table).kinds;
        const operand_75 = value_5;

        if ((operand_75 >= (operand_74).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_76 (operand_74)[@intCast(operand_75)];
    })) != @as((zx_abi).zx_type_49, .Tuple)) or ((try function_53(allocator, block_79: {
        const operand_77 = (((&value_1)).table).second;
        const operand_78 = value_5;

        if ((operand_78 >= (operand_77).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_79 (operand_77)[@intCast(operand_78)];
    })) != value_7))) {
        return false;
    }

    const value_17: (zx_abi).zx_type_82 = block_73: {
        const operand_26 = block_25: {
            const operand_16 = (&value_1);
            const operand_17 = value_6;
            const operand_18 = value_7;
            const operand_19 = (try function_53(allocator, block_22: {
                const operand_20 = (((&value_1)).table).first;
                const operand_21 = value_5;

                if ((operand_21 >= (operand_20).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_22 (operand_20)[@intCast(operand_21)];
            }));
            const operand_23 = @as(u64, 0);
            const operand_24 = true;

            break :block_25 (zx_abi).zx_type_82{ .program = operand_16, .first = operand_17, .count = operand_18, .type_first = operand_19, .index = operand_23, .valid = operand_24, };
        };

        var state_15: (zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67 = (zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67{ .count = (operand_26).count, .first = (operand_26).first, .index = (operand_26).index, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = ((((operand_26).program).body).control).block_count, .block_first = ((((operand_26).program).body).control).block_first, .branch_conditions = ((((operand_26).program).body).control).branch_conditions, .branch_no = ((((operand_26).program).body).control).branch_no, .branch_yes = ((((operand_26).program).body).control).branch_yes, .case_bodies = ((((operand_26).program).body).control).case_bodies, .case_values = ((((operand_26).program).body).control).case_values, .constant_symbols = ((((operand_26).program).body).control).constant_symbols, .constant_values = ((((operand_26).program).body).control).constant_values, .destructure_count = ((((operand_26).program).body).control).destructure_count, .destructure_first = ((((operand_26).program).body).control).destructure_first, .destructure_symbols = ((((operand_26).program).body).control).destructure_symbols, .destructure_values = ((((operand_26).program).body).control).destructure_values, .evaluations = ((((operand_26).program).body).control).evaluations, .parallel_count = ((((operand_26).program).body).control).parallel_count, .parallel_first = ((((operand_26).program).body).control).parallel_first, .parallel_symbols = ((((operand_26).program).body).control).parallel_symbols, .parallel_values = ((((operand_26).program).body).control).parallel_values, .results = ((((operand_26).program).body).control).results, .selection_count = ((((operand_26).program).body).control).selection_count, .selection_exhaustive = ((((operand_26).program).body).control).selection_exhaustive, .selection_first = ((((operand_26).program).body).control).selection_first, .selection_subjects = ((((operand_26).program).body).control).selection_subjects, .setter_slots = ((((operand_26).program).body).control).setter_slots, .setter_values = ((((operand_26).program).body).control).setter_values, .statement_kinds = ((((operand_26).program).body).control).statement_kinds, .statement_payloads = ((((operand_26).program).body).control).statement_payloads, .zx_origin = (((operand_26).program).body).control, }, .expressions = (((operand_26).program).body).expressions, .root = (((operand_26).program).body).root, .stores = (((operand_26).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_26).program).body).symbols).names, .ownership = ((((operand_26).program).body).symbols).ownership, .span_end = ((((operand_26).program).body).symbols).span_end, .span_start = ((((operand_26).program).body).symbols).span_start, .types = ((((operand_26).program).body).symbols).types, .zx_origin = (((operand_26).program).body).symbols, }, .zx_origin = ((operand_26).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = (((operand_26).program).functions).expressions, .native_concurrent = (((operand_26).program).functions).native_concurrent, .native_modules = (((operand_26).program).functions).native_modules, .stores = (((operand_26).program).functions).stores, .zx_origin = ((operand_26).program).functions, }, .output_type = ((operand_26).program).output_type, .table = ((operand_26).program).table, .transaction = ((operand_26).program).transaction, .writer = ((operand_26).program).writer, .zx_origin = (operand_26).program, }, .type_first = (operand_26).type_first, .valid = (operand_26).valid, .zx_origin = (&operand_26), };

        while (((state_15).valid and ((state_15).index < (state_15).count))) {
            state_15 = block_60: {
                const value_10: ?u32 = block_59: {
                    const operand_57 = ((((state_15).program).body).control).destructure_symbols;
                    const operand_58 = ((state_15).first + (state_15).index);

                    if ((operand_58 >= (operand_57).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_59 (operand_57)[@intCast(operand_58)];
                };
                const value_13: (zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67 = (if ((block_29: {
                    break :block_29 value_10;
                } != null)) block_56: {
                    const value_11: (zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67 = state_15;
                    const value_12: (zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67 = block_55: {
                        break :block_55 @as((zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67, (zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67{ .count = (value_11).count, .first = (value_11).first, .index = (value_11).index, .program = (value_11).program, .type_first = (value_11).type_first, .valid = block_54: {
                            const operand_30 = (state_15).program;

                            var state_borrow_31: (zx_abi).zx_type_17 = undefined;

                            state_borrow_31 = (zx_abi).zx_type_17{ .block_count = (((operand_30).body).control).block_count, .block_first = (((operand_30).body).control).block_first, .branch_conditions = (((operand_30).body).control).branch_conditions, .branch_no = (((operand_30).body).control).branch_no, .branch_yes = (((operand_30).body).control).branch_yes, .case_bodies = (((operand_30).body).control).case_bodies, .case_values = (((operand_30).body).control).case_values, .constant_symbols = (((operand_30).body).control).constant_symbols, .constant_values = (((operand_30).body).control).constant_values, .destructure_count = (((operand_30).body).control).destructure_count, .destructure_first = (((operand_30).body).control).destructure_first, .destructure_symbols = (((operand_30).body).control).destructure_symbols, .destructure_values = (((operand_30).body).control).destructure_values, .evaluations = (((operand_30).body).control).evaluations, .parallel_count = (((operand_30).body).control).parallel_count, .parallel_first = (((operand_30).body).control).parallel_first, .parallel_symbols = (((operand_30).body).control).parallel_symbols, .parallel_values = (((operand_30).body).control).parallel_values, .results = (((operand_30).body).control).results, .selection_count = (((operand_30).body).control).selection_count, .selection_exhaustive = (((operand_30).body).control).selection_exhaustive, .selection_first = (((operand_30).body).control).selection_first, .selection_subjects = (((operand_30).body).control).selection_subjects, .setter_slots = (((operand_30).body).control).setter_slots, .setter_values = (((operand_30).body).control).setter_values, .statement_kinds = (((operand_30).body).control).statement_kinds, .statement_payloads = (((operand_30).body).control).statement_payloads, };

                            var state_borrow_32: (zx_abi).zx_type_60 = undefined;

                            state_borrow_32 = (zx_abi).zx_type_60{ .names = (((operand_30).body).symbols).names, .ownership = (((operand_30).body).symbols).ownership, .span_end = (((operand_30).body).symbols).span_end, .span_start = (((operand_30).body).symbols).span_start, .types = (((operand_30).body).symbols).types, };

                            var state_borrow_33: (zx_abi).zx_type_61 = undefined;

                            state_borrow_33 = (zx_abi).zx_type_61{ .control = ((((operand_30).body).control).zx_origin orelse (&state_borrow_31)), .expressions = ((operand_30).body).expressions, .root = ((operand_30).body).root, .stores = ((operand_30).body).stores, .symbols = ((((operand_30).body).symbols).zx_origin orelse (&state_borrow_32)), };

                            var state_borrow_34: (zx_abi).zx_type_41 = undefined;

                            state_borrow_34 = (zx_abi).zx_type_41{ .expressions = ((operand_30).functions).expressions, .native_concurrent = ((operand_30).functions).native_concurrent, .native_modules = ((operand_30).functions).native_modules, .stores = ((operand_30).functions).stores, };

                            var state_borrow_35: (zx_abi).zx_type_65 = undefined;

                            state_borrow_35 = (zx_abi).zx_type_65{ .body = (((operand_30).body).zx_origin orelse (&state_borrow_33)), .functions = (((operand_30).functions).zx_origin orelse (&state_borrow_34)), .output_type = (operand_30).output_type, .table = (operand_30).table, .transaction = (operand_30).transaction, .writer = (operand_30).writer, };

                            const operand_36 = ((operand_30).zx_origin orelse (&state_borrow_35));
                            const operand_40 = block_39: {
                                const operand_38 = block_37: {
                                    break :block_37 value_10;
                                }.?;

                                break :block_39 (try function_53(allocator, operand_38));
                            };
                            const operand_44 = block_43: {
                                const operand_41 = (((state_15).program).table).children;
                                const operand_42 = ((state_15).type_first + (state_15).index);

                                if ((operand_42 >= (operand_41).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_43 (operand_41)[@intCast(operand_42)];
                            };
                            const operand_45 = @as(u64, 0);
                            const operand_46 = @as((zx_abi).zx_type_69, .Ordinary);
                            const operand_47 = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = (((operand_36).body).control).block_count, .block_first = (((operand_36).body).control).block_first, .branch_conditions = (((operand_36).body).control).branch_conditions, .branch_no = (((operand_36).body).control).branch_no, .branch_yes = (((operand_36).body).control).branch_yes, .case_bodies = (((operand_36).body).control).case_bodies, .case_values = (((operand_36).body).control).case_values, .constant_symbols = (((operand_36).body).control).constant_symbols, .constant_values = (((operand_36).body).control).constant_values, .destructure_count = (((operand_36).body).control).destructure_count, .destructure_first = (((operand_36).body).control).destructure_first, .destructure_symbols = (((operand_36).body).control).destructure_symbols, .destructure_values = (((operand_36).body).control).destructure_values, .evaluations = (((operand_36).body).control).evaluations, .parallel_count = (((operand_36).body).control).parallel_count, .parallel_first = (((operand_36).body).control).parallel_first, .parallel_symbols = (((operand_36).body).control).parallel_symbols, .parallel_values = (((operand_36).body).control).parallel_values, .results = (((operand_36).body).control).results, .selection_count = (((operand_36).body).control).selection_count, .selection_exhaustive = (((operand_36).body).control).selection_exhaustive, .selection_first = (((operand_36).body).control).selection_first, .selection_subjects = (((operand_36).body).control).selection_subjects, .setter_slots = (((operand_36).body).control).setter_slots, .setter_values = (((operand_36).body).control).setter_values, .statement_kinds = (((operand_36).body).control).statement_kinds, .statement_payloads = (((operand_36).body).control).statement_payloads, .zx_origin = ((operand_36).body).control, }, .expressions = ((operand_36).body).expressions, .root = ((operand_36).body).root, .stores = ((operand_36).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((operand_36).body).symbols).names, .ownership = (((operand_36).body).symbols).ownership, .span_end = (((operand_36).body).symbols).span_end, .span_start = (((operand_36).body).symbols).span_start, .types = (((operand_36).body).symbols).types, .zx_origin = ((operand_36).body).symbols, }, .zx_origin = (operand_36).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = ((operand_36).functions).expressions, .native_concurrent = ((operand_36).functions).native_concurrent, .native_modules = ((operand_36).functions).native_modules, .stores = ((operand_36).functions).stores, .zx_origin = (operand_36).functions, }, .output_type = (operand_36).output_type, .table = (operand_36).table, .transaction = (operand_36).transaction, .writer = (operand_36).writer, .zx_origin = operand_36, };

                            var state_borrow_48: (zx_abi).zx_type_17 = undefined;

                            state_borrow_48 = (zx_abi).zx_type_17{ .block_count = (((operand_47).body).control).block_count, .block_first = (((operand_47).body).control).block_first, .branch_conditions = (((operand_47).body).control).branch_conditions, .branch_no = (((operand_47).body).control).branch_no, .branch_yes = (((operand_47).body).control).branch_yes, .case_bodies = (((operand_47).body).control).case_bodies, .case_values = (((operand_47).body).control).case_values, .constant_symbols = (((operand_47).body).control).constant_symbols, .constant_values = (((operand_47).body).control).constant_values, .destructure_count = (((operand_47).body).control).destructure_count, .destructure_first = (((operand_47).body).control).destructure_first, .destructure_symbols = (((operand_47).body).control).destructure_symbols, .destructure_values = (((operand_47).body).control).destructure_values, .evaluations = (((operand_47).body).control).evaluations, .parallel_count = (((operand_47).body).control).parallel_count, .parallel_first = (((operand_47).body).control).parallel_first, .parallel_symbols = (((operand_47).body).control).parallel_symbols, .parallel_values = (((operand_47).body).control).parallel_values, .results = (((operand_47).body).control).results, .selection_count = (((operand_47).body).control).selection_count, .selection_exhaustive = (((operand_47).body).control).selection_exhaustive, .selection_first = (((operand_47).body).control).selection_first, .selection_subjects = (((operand_47).body).control).selection_subjects, .setter_slots = (((operand_47).body).control).setter_slots, .setter_values = (((operand_47).body).control).setter_values, .statement_kinds = (((operand_47).body).control).statement_kinds, .statement_payloads = (((operand_47).body).control).statement_payloads, };

                            var state_borrow_49: (zx_abi).zx_type_60 = undefined;

                            state_borrow_49 = (zx_abi).zx_type_60{ .names = (((operand_47).body).symbols).names, .ownership = (((operand_47).body).symbols).ownership, .span_end = (((operand_47).body).symbols).span_end, .span_start = (((operand_47).body).symbols).span_start, .types = (((operand_47).body).symbols).types, };

                            var state_borrow_50: (zx_abi).zx_type_61 = undefined;

                            state_borrow_50 = (zx_abi).zx_type_61{ .control = ((((operand_47).body).control).zx_origin orelse (&state_borrow_48)), .expressions = ((operand_47).body).expressions, .root = ((operand_47).body).root, .stores = ((operand_47).body).stores, .symbols = ((((operand_47).body).symbols).zx_origin orelse (&state_borrow_49)), };

                            var state_borrow_51: (zx_abi).zx_type_41 = undefined;

                            state_borrow_51 = (zx_abi).zx_type_41{ .expressions = ((operand_47).functions).expressions, .native_concurrent = ((operand_47).functions).native_concurrent, .native_modules = ((operand_47).functions).native_modules, .stores = ((operand_47).functions).stores, };

                            var state_borrow_52: (zx_abi).zx_type_65 = undefined;

                            state_borrow_52 = (zx_abi).zx_type_65{ .body = (((operand_47).body).zx_origin orelse (&state_borrow_50)), .functions = (((operand_47).functions).zx_origin orelse (&state_borrow_51)), .output_type = (operand_47).output_type, .table = (operand_47).table, .transaction = (operand_47).transaction, .writer = (operand_47).writer, };

                            const operand_53 = (zx_abi).zx_type_79{ .program = ((operand_47).zx_origin orelse (&state_borrow_52)), .symbol = operand_40, .type_id = operand_44, .owner = operand_45, .mode = operand_46, };

                            break :block_54 (try function_65(allocator, (&operand_53)));
                        }, });
                    };

                    break :block_56 value_12;
                } else state_15);
                const value_14: (zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67 = value_13;
                const value_15: u64 = (value_14).index;
                const value_16: (zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67 = block_28: {
                    break :block_28 @as((zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67, (zx_abi).value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67{ .count = (value_14).count, .first = (value_14).first, .index = (block_27: {
                        break :block_27 value_15;
                    } + @as(u64, 1)), .program = (value_14).program, .type_first = (value_14).type_first, .valid = (value_14).valid, });
                };

                break :block_60 value_16;
            };
        }

        break :block_73 block_72: {
            break :block_72 (if (((state_15).zx_origin != null)) ((state_15).zx_origin.?).* else block_71: {
                break :block_71 (zx_abi).zx_type_82{ .count = (state_15).count, .first = (state_15).first, .index = (state_15).index, .program = (if ((((state_15).program).zx_origin != null)) ((state_15).program).zx_origin.? else block_70: {
                    const operand_69 = (try (allocator).create((zx_abi).zx_type_65));

                    (operand_69).* = (zx_abi).zx_type_65{ .body = (if (((((state_15).program).body).zx_origin != null)) (((state_15).program).body).zx_origin.? else block_66: {
                        const operand_65 = (try (allocator).create((zx_abi).zx_type_61));

                        (operand_65).* = (zx_abi).zx_type_61{ .control = (if ((((((state_15).program).body).control).zx_origin != null)) ((((state_15).program).body).control).zx_origin.? else block_62: {
                            const operand_61 = (try (allocator).create((zx_abi).zx_type_17));

                            (operand_61).* = (zx_abi).zx_type_17{ .block_count = ((((state_15).program).body).control).block_count, .block_first = ((((state_15).program).body).control).block_first, .branch_conditions = ((((state_15).program).body).control).branch_conditions, .branch_no = ((((state_15).program).body).control).branch_no, .branch_yes = ((((state_15).program).body).control).branch_yes, .case_bodies = ((((state_15).program).body).control).case_bodies, .case_values = ((((state_15).program).body).control).case_values, .constant_symbols = ((((state_15).program).body).control).constant_symbols, .constant_values = ((((state_15).program).body).control).constant_values, .destructure_count = ((((state_15).program).body).control).destructure_count, .destructure_first = ((((state_15).program).body).control).destructure_first, .destructure_symbols = ((((state_15).program).body).control).destructure_symbols, .destructure_values = ((((state_15).program).body).control).destructure_values, .evaluations = ((((state_15).program).body).control).evaluations, .parallel_count = ((((state_15).program).body).control).parallel_count, .parallel_first = ((((state_15).program).body).control).parallel_first, .parallel_symbols = ((((state_15).program).body).control).parallel_symbols, .parallel_values = ((((state_15).program).body).control).parallel_values, .results = ((((state_15).program).body).control).results, .selection_count = ((((state_15).program).body).control).selection_count, .selection_exhaustive = ((((state_15).program).body).control).selection_exhaustive, .selection_first = ((((state_15).program).body).control).selection_first, .selection_subjects = ((((state_15).program).body).control).selection_subjects, .setter_slots = ((((state_15).program).body).control).setter_slots, .setter_values = ((((state_15).program).body).control).setter_values, .statement_kinds = ((((state_15).program).body).control).statement_kinds, .statement_payloads = ((((state_15).program).body).control).statement_payloads, };

                            break :block_62 @as(*const (zx_abi).zx_type_17, operand_61);
                        }), .expressions = (((state_15).program).body).expressions, .root = (((state_15).program).body).root, .stores = (((state_15).program).body).stores, .symbols = (if ((((((state_15).program).body).symbols).zx_origin != null)) ((((state_15).program).body).symbols).zx_origin.? else block_64: {
                            const operand_63 = (try (allocator).create((zx_abi).zx_type_60));

                            (operand_63).* = (zx_abi).zx_type_60{ .names = ((((state_15).program).body).symbols).names, .ownership = ((((state_15).program).body).symbols).ownership, .span_end = ((((state_15).program).body).symbols).span_end, .span_start = ((((state_15).program).body).symbols).span_start, .types = ((((state_15).program).body).symbols).types, };

                            break :block_64 @as(*const (zx_abi).zx_type_60, operand_63);
                        }), };

                        break :block_66 @as(*const (zx_abi).zx_type_61, operand_65);
                    }), .functions = (if (((((state_15).program).functions).zx_origin != null)) (((state_15).program).functions).zx_origin.? else block_68: {
                        const operand_67 = (try (allocator).create((zx_abi).zx_type_41));

                        (operand_67).* = (zx_abi).zx_type_41{ .expressions = (((state_15).program).functions).expressions, .native_concurrent = (((state_15).program).functions).native_concurrent, .native_modules = (((state_15).program).functions).native_modules, .stores = (((state_15).program).functions).stores, };

                        break :block_68 @as(*const (zx_abi).zx_type_41, operand_67);
                    }), .output_type = ((state_15).program).output_type, .table = ((state_15).program).table, .transaction = ((state_15).program).transaction, .writer = ((state_15).program).writer, };

                    break :block_70 @as(*const (zx_abi).zx_type_65, operand_69);
                }), .type_first = (state_15).type_first, .valid = (state_15).valid, };
            });
        };
    };

    if ((((&value_17)).valid and (value_7 == @as(u64, 2)))) {
        _ = block_14: {
            const operand_1 = ((&value_1)).writer;
            const operand_2 = (((&value_1)).body).expressions;
            const operand_3 = value_4;
            const operand_4 = value_7;
            const operand_8 = block_7: {
                const operand_5 = ((&value_2)).destructure_symbols;
                const operand_6 = value_6;

                if ((operand_6 >= (operand_5).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_7 (operand_5)[@intCast(operand_6)];
            };
            const operand_12 = block_11: {
                const operand_9 = ((&value_2)).destructure_symbols;
                const operand_10 = (value_6 + @as(u64, 1));

                if ((operand_10 >= (operand_9).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_11 (operand_9)[@intCast(operand_10)];
            };
            const operand_13 = (zx_abi).zx_type_81{ .writer = operand_1, .expressions = operand_2, .value = operand_3, .count = operand_4, .err = operand_8, .result = operand_12, };

            break :block_14 (try function_68(allocator, (&operand_13)));
        };
    }

    return ((&value_17)).valid;
}

fn function_70(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_83) error{ IndexOutOfBounds, OutOfMemory, }!void {
    @setRuntimeSafety(true);

    _ = block_25: {
        const operand_5 = block_4: {
            const operand_2 = in;
            const operand_3 = (in).count;

            break :block_4 (zx_abi).zx_type_84{ .input = operand_2, .index = operand_3, };
        };

        var state_1: (zx_abi).value_zx_type_84_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = (zx_abi).value_zx_type_84_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699{ .index = (operand_5).index, .input = (zx_abi).value_zx_type_83_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .count = ((operand_5).input).count, .depth = ((operand_5).input).depth, .first = ((operand_5).input).first, .flags = ((operand_5).input).flags, .values = ((operand_5).input).values, .writer = ((operand_5).input).writer, .zx_origin = (operand_5).input, }, .zx_origin = (&operand_5), };

        while (((state_1).index != @as(u64, 0))) {
            state_1 = block_24: {
                const value_3: (zx_abi).value_zx_type_84_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = state_1;
                const value_4: u64 = (value_3).index;
                const value_5: (zx_abi).value_zx_type_84_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = block_23: {
                    break :block_23 @as((zx_abi).value_zx_type_84_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699, (zx_abi).value_zx_type_84_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699{ .index = (block_22: {
                        break :block_22 value_4;
                    } - @as(u64, 1)), .input = (value_3).input, });
                };
                const value_6: (zx_abi).value_zx_type_83_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (value_5).input;

                _ = block_21: {
                    const operand_6 = (value_6).writer;
                    const operand_7 = @as((zx_abi).zx_type_63, .Expression);
                    const operand_13 = block_12: {
                        const operand_11 = block_10: {
                            const operand_8 = (value_6).values;
                            const operand_9 = ((value_6).first + (value_5).index);

                            if ((operand_9 >= (operand_8).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_10 (operand_8)[@intCast(operand_9)];
                        };

                        break :block_12 (try function_53(allocator, operand_11));
                    };
                    const operand_14 = (value_6).depth;
                    const operand_15 = (value_6).flags;
                    const operand_16 = (zx_abi).zx_type_64{ .phase = operand_7, .a = operand_13, .b = operand_14, .c = operand_15, };
                    const operand_17 = (&operand_16);
                    const operand_18 = (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .a = (operand_17).a, .b = (operand_17).b, .c = (operand_17).c, .phase = (operand_17).phase, .zx_origin = operand_17, };

                    var state_borrow_19: (zx_abi).zx_type_64 = undefined;

                    state_borrow_19 = (zx_abi).zx_type_64{ .a = (operand_18).a, .b = (operand_18).b, .c = (operand_18).c, .phase = (operand_18).phase, };

                    const operand_20 = (zx_abi).zx_type_75{ .writer = operand_6, .frame = ((operand_18).zx_origin orelse (&state_borrow_19)), };

                    break :block_21 (try function_59(allocator, (&operand_20)));
                };

                break :block_24 value_5;
            };
        }

        break :block_25 {};
    };
}

fn function_71(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: (zx_abi).zx_type_35 = ((((&value_1)).body).expressions).*;
    const value_3: (zx_abi).zx_type_22 = block_162: {
        const operand_160 = ((&value_2)).kinds;
        const operand_161 = ((in).frame).a;

        if ((operand_161 >= (operand_160).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_162 (operand_160)[@intCast(operand_161)];
    };
    const value_4: u64 = (try function_53(allocator, block_159: {
        const operand_157 = ((&value_2)).payloads;
        const operand_158 = ((in).frame).a;

        if ((operand_158 >= (operand_157).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_159 (operand_157)[@intCast(operand_158)];
    }));
    const value_5: u64 = (((in).frame).b + @as(u64, 1));
    const value_6: u64 = ((in).frame).c;
    const value_7: *const (zx_abi).zx_type_44 = ((&value_1)).writer;

    if ((((value_3 == @as((zx_abi).zx_type_22, .List)) or (value_3 == @as((zx_abi).zx_type_22, .Tuple))) or (value_3 == @as((zx_abi).zx_type_22, .Template)))) {
        _ = block_156: {
            const operand_143 = value_7;
            const operand_144 = ((&value_2)).sequence_items;
            const operand_148 = (try function_53(allocator, block_147: {
                const operand_145 = ((&value_2)).sequence_first;
                const operand_146 = value_4;

                if ((operand_146 >= (operand_145).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_147 (operand_145)[@intCast(operand_146)];
            }));
            const operand_152 = (try function_53(allocator, block_151: {
                const operand_149 = ((&value_2)).sequence_count;
                const operand_150 = value_4;

                if ((operand_150 >= (operand_149).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_151 (operand_149)[@intCast(operand_150)];
            }));
            const operand_153 = value_5;
            const operand_154 = value_6;
            const operand_155 = (zx_abi).zx_type_83{ .writer = operand_143, .values = operand_144, .first = operand_148, .count = operand_152, .depth = operand_153, .flags = operand_154, };

            break :block_156 (try function_70(allocator, (&operand_155)));
        };

        return true;
    }

    if ((value_3 == @as((zx_abi).zx_type_22, .Parallel))) {
        _ = block_142: {
            const operand_129 = value_7;
            const operand_130 = ((&value_2)).parallel_tasks;
            const operand_134 = (try function_53(allocator, block_133: {
                const operand_131 = ((&value_2)).parallel_first;
                const operand_132 = value_4;

                if ((operand_132 >= (operand_131).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_133 (operand_131)[@intCast(operand_132)];
            }));
            const operand_138 = (try function_53(allocator, block_137: {
                const operand_135 = ((&value_2)).parallel_count;
                const operand_136 = value_4;

                if ((operand_136 >= (operand_135).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_137 (operand_135)[@intCast(operand_136)];
            }));
            const operand_139 = value_5;
            const operand_140 = value_6;
            const operand_141 = (zx_abi).zx_type_83{ .writer = operand_129, .values = operand_130, .first = operand_134, .count = operand_138, .depth = operand_139, .flags = operand_140, };

            break :block_142 (try function_70(allocator, (&operand_141)));
        };

        return true;
    }

    if ((value_3 == @as((zx_abi).zx_type_22, .Object))) {
        _ = block_128: {
            const operand_115 = value_7;
            const operand_116 = ((&value_2)).object_field_values;
            const operand_120 = (try function_53(allocator, block_119: {
                const operand_117 = ((&value_2)).object_first;
                const operand_118 = value_4;

                if ((operand_118 >= (operand_117).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_119 (operand_117)[@intCast(operand_118)];
            }));
            const operand_124 = (try function_53(allocator, block_123: {
                const operand_121 = ((&value_2)).object_count;
                const operand_122 = value_4;

                if ((operand_122 >= (operand_121).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_123 (operand_121)[@intCast(operand_122)];
            }));
            const operand_125 = value_5;
            const operand_126 = value_6;
            const operand_127 = (zx_abi).zx_type_83{ .writer = operand_115, .values = operand_116, .first = operand_120, .count = operand_124, .depth = operand_125, .flags = operand_126, };

            break :block_128 (try function_70(allocator, (&operand_127)));
        };

        _ = block_114: {
            const operand_101 = value_7;
            const operand_102 = ((&value_2)).object_evaluation_values;
            const operand_106 = (try function_53(allocator, block_105: {
                const operand_103 = ((&value_2)).object_evaluation_first;
                const operand_104 = value_4;

                if ((operand_104 >= (operand_103).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_105 (operand_103)[@intCast(operand_104)];
            }));
            const operand_110 = (try function_53(allocator, block_109: {
                const operand_107 = ((&value_2)).object_evaluation_count;
                const operand_108 = value_4;

                if ((operand_108 >= (operand_107).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_109 (operand_107)[@intCast(operand_108)];
            }));
            const operand_111 = value_5;
            const operand_112 = value_6;
            const operand_113 = (zx_abi).zx_type_83{ .writer = operand_101, .values = operand_102, .first = operand_106, .count = operand_110, .depth = operand_111, .flags = operand_112, };

            break :block_114 (try function_70(allocator, (&operand_113)));
        };

        return true;
    }

    if ((value_3 == @as((zx_abi).zx_type_22, .ListOperation))) {
        _ = block_64: {
            const operand_51 = value_7;
            const operand_52 = ((&value_2)).collection_arguments;
            const operand_56 = (try function_53(allocator, block_55: {
                const operand_53 = ((&value_2)).collection_first;
                const operand_54 = value_4;

                if ((operand_54 >= (operand_53).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_55 (operand_53)[@intCast(operand_54)];
            }));
            const operand_60 = (try function_53(allocator, block_59: {
                const operand_57 = ((&value_2)).collection_count;
                const operand_58 = value_4;

                if ((operand_58 >= (operand_57).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_59 (operand_57)[@intCast(operand_58)];
            }));
            const operand_61 = value_5;
            const operand_62 = value_6;
            const operand_63 = (zx_abi).zx_type_83{ .writer = operand_51, .values = operand_52, .first = operand_56, .count = operand_60, .depth = operand_61, .flags = operand_62, };

            break :block_64 (try function_70(allocator, (&operand_63)));
        };
    } else {
        if ((value_3 == @as((zx_abi).zx_type_22, .ListUpdate))) {
            _ = block_88: {
                const operand_77 = value_7;
                const operand_78 = @as((zx_abi).zx_type_63, .Expression);
                const operand_82 = (try function_53(allocator, block_81: {
                    const operand_79 = ((&value_2)).update_values;
                    const operand_80 = value_4;

                    if ((operand_80 >= (operand_79).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_81 (operand_79)[@intCast(operand_80)];
                }));
                const operand_83 = value_5;
                const operand_84 = value_6;
                const operand_85 = (zx_abi).zx_type_64{ .phase = operand_78, .a = operand_82, .b = operand_83, .c = operand_84, };
                const operand_86 = (&operand_85);
                const operand_87 = (zx_abi).zx_type_75{ .writer = operand_77, .frame = operand_86, };

                break :block_88 (try function_59(allocator, (&operand_87)));
            };

            _ = block_76: {
                const operand_65 = value_7;
                const operand_66 = @as((zx_abi).zx_type_63, .Expression);
                const operand_70 = (try function_53(allocator, block_69: {
                    const operand_67 = ((&value_2)).update_indices;
                    const operand_68 = value_4;

                    if ((operand_68 >= (operand_67).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_69 (operand_67)[@intCast(operand_68)];
                }));
                const operand_71 = value_5;
                const operand_72 = value_6;
                const operand_73 = (zx_abi).zx_type_64{ .phase = operand_66, .a = operand_70, .b = operand_71, .c = operand_72, };
                const operand_74 = (&operand_73);
                const operand_75 = (zx_abi).zx_type_75{ .writer = operand_65, .frame = operand_74, };

                break :block_76 (try function_59(allocator, (&operand_75)));
            };
        } else {
            if ((value_3 == @as((zx_abi).zx_type_22, .Index))) {
                _ = block_100: {
                    const operand_89 = value_7;
                    const operand_90 = @as((zx_abi).zx_type_63, .Expression);
                    const operand_94 = (try function_53(allocator, block_93: {
                        const operand_91 = ((&value_2)).index_values;
                        const operand_92 = value_4;

                        if ((operand_92 >= (operand_91).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_93 (operand_91)[@intCast(operand_92)];
                    }));
                    const operand_95 = value_5;
                    const operand_96 = value_6;
                    const operand_97 = (zx_abi).zx_type_64{ .phase = operand_90, .a = operand_94, .b = operand_95, .c = operand_96, };
                    const operand_98 = (&operand_97);
                    const operand_99 = (zx_abi).zx_type_75{ .writer = operand_89, .frame = operand_98, };

                    break :block_100 (try function_59(allocator, (&operand_99)));
                };
            }
        }
    }

    const value_8: u32 = block_50: {
        const operand_10 = value_3;

        break :block_50 (if ((operand_10 == @as((zx_abi).zx_type_22, .Field))) block_49: {
            const operand_47 = ((&value_2)).projection_targets;
            const operand_48 = value_4;

            if ((operand_48 >= (operand_47).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_49 (operand_47)[@intCast(operand_48)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .TupleField))) block_46: {
            const operand_44 = ((&value_2)).projection_targets;
            const operand_45 = value_4;

            if ((operand_45 >= (operand_44).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_46 (operand_44)[@intCast(operand_45)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .Index))) block_43: {
            const operand_41 = ((&value_2)).index_targets;
            const operand_42 = value_4;

            if ((operand_42 >= (operand_41).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_43 (operand_41)[@intCast(operand_42)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .Length))) block_40: {
            const operand_38 = ((&value_2)).lengths;
            const operand_39 = value_4;

            if ((operand_39 >= (operand_38).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_40 (operand_38)[@intCast(operand_39)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .Some))) block_37: {
            const operand_35 = ((&value_2)).some;
            const operand_36 = value_4;

            if ((operand_36 >= (operand_35).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_37 (operand_35)[@intCast(operand_36)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .Capture))) block_34: {
            const operand_32 = ((&value_2)).captures;
            const operand_33 = value_4;

            if ((operand_33 >= (operand_32).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_34 (operand_32)[@intCast(operand_33)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .AwaitTask))) block_31: {
            const operand_29 = ((&value_2)).awaits;
            const operand_30 = value_4;

            if ((operand_30 >= (operand_29).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_31 (operand_29)[@intCast(operand_30)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .CancelTask))) block_28: {
            const operand_26 = ((&value_2)).cancellations;
            const operand_27 = value_4;

            if ((operand_27 >= (operand_26).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_28 (operand_26)[@intCast(operand_27)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .OptionalValue))) block_25: {
            const operand_23 = ((&value_2)).optional_values;
            const operand_24 = value_4;

            if ((operand_24 >= (operand_23).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_25 (operand_23)[@intCast(operand_24)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .Unary))) block_22: {
            const operand_20 = ((&value_2)).unary_operands;
            const operand_21 = value_4;

            if ((operand_21 >= (operand_20).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_22 (operand_20)[@intCast(operand_21)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .ListOperation))) block_19: {
            const operand_17 = ((&value_2)).collection_targets;
            const operand_18 = value_4;

            if ((operand_18 >= (operand_17).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_19 (operand_17)[@intCast(operand_18)];
        } else (if ((operand_10 == @as((zx_abi).zx_type_22, .ListUpdate))) block_16: {
            const operand_14 = ((&value_2)).update_targets;
            const operand_15 = value_4;

            if ((operand_15 >= (operand_14).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_16 (operand_14)[@intCast(operand_15)];
        } else block_13: {
            const operand_11 = ((&value_2)).call_arguments;
            const operand_12 = value_4;

            if ((operand_12 >= (operand_11).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_13 (operand_11)[@intCast(operand_12)];
        }))))))))))));
    };

    _ = block_9: {
        const operand_1 = value_7;
        const operand_2 = @as((zx_abi).zx_type_63, .Expression);
        const operand_3 = (try function_53(allocator, value_8));
        const operand_4 = value_5;
        const operand_5 = value_6;
        const operand_6 = (zx_abi).zx_type_64{ .phase = operand_2, .a = operand_3, .b = operand_4, .c = operand_5, };
        const operand_7 = (&operand_6);
        const operand_8 = (zx_abi).zx_type_75{ .writer = operand_1, .frame = operand_7, };

        break :block_9 (try function_59(allocator, (&operand_8)));
    };

    return true;
}

fn function_72(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: (zx_abi).zx_type_35 = ((((&value_1)).body).expressions).*;
    const value_3: u64 = (try function_53(allocator, block_114: {
        const operand_112 = ((&value_2)).payloads;
        const operand_113 = ((in).frame).a;

        if ((operand_113 >= (operand_112).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_114 (operand_112)[@intCast(operand_113)];
    }));
    const value_4: *const (zx_abi).zx_type_44 = ((&value_1)).writer;
    const value_5: u64 = (try function_45(allocator, value_4));
    const value_6: u64 = (try function_46(allocator, value_4));
    const value_7: u64 = (((in).frame).b + @as(u64, 1));
    const value_8: u64 = ((in).frame).c;

    _ = block_111: {
        const operand_103 = value_4;
        const operand_104 = @as((zx_abi).zx_type_63, .RestoreFacts);
        const operand_105 = value_5;
        const operand_106 = value_6;
        const operand_107 = @as(u64, 0);
        const operand_108 = (zx_abi).zx_type_64{ .phase = operand_104, .a = operand_105, .b = operand_106, .c = operand_107, };
        const operand_109 = (&operand_108);
        const operand_110 = (zx_abi).zx_type_75{ .writer = operand_103, .frame = operand_109, };

        break :block_111 (try function_59(allocator, (&operand_110)));
    };

    if ((block_3: {
        const operand_1 = ((&value_2)).kinds;
        const operand_2 = ((in).frame).a;

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    } == @as((zx_abi).zx_type_22, .Conditional))) {
        const value_9: u64 = (try function_53(allocator, block_66: {
            const operand_64 = ((&value_2)).conditional_conditions;
            const operand_65 = value_3;

            if ((operand_65 >= (operand_64).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_66 (operand_64)[@intCast(operand_65)];
        }));

        _ = block_63: {
            const operand_52 = value_4;
            const operand_53 = @as((zx_abi).zx_type_63, .Expression);
            const operand_57 = (try function_53(allocator, block_56: {
                const operand_54 = ((&value_2)).conditional_no;
                const operand_55 = value_3;

                if ((operand_55 >= (operand_54).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_56 (operand_54)[@intCast(operand_55)];
            }));
            const operand_58 = value_7;
            const operand_59 = value_8;
            const operand_60 = (zx_abi).zx_type_64{ .phase = operand_53, .a = operand_57, .b = operand_58, .c = operand_59, };
            const operand_61 = (&operand_60);
            const operand_62 = (zx_abi).zx_type_75{ .writer = operand_52, .frame = operand_61, };

            break :block_63 (try function_59(allocator, (&operand_62)));
        };

        _ = block_51: {
            const operand_43 = value_4;
            const operand_44 = @as((zx_abi).zx_type_63, .Assume);
            const operand_45 = value_9;
            const operand_46 = @as(u64, 0);
            const operand_47 = @as(u64, 0);
            const operand_48 = (zx_abi).zx_type_64{ .phase = operand_44, .a = operand_45, .b = operand_46, .c = operand_47, };
            const operand_49 = (&operand_48);
            const operand_50 = (zx_abi).zx_type_75{ .writer = operand_43, .frame = operand_49, };

            break :block_51 (try function_59(allocator, (&operand_50)));
        };

        _ = block_42: {
            const operand_34 = value_4;
            const operand_35 = @as((zx_abi).zx_type_63, .RestoreFacts);
            const operand_36 = value_5;
            const operand_37 = value_6;
            const operand_38 = @as(u64, 0);
            const operand_39 = (zx_abi).zx_type_64{ .phase = operand_35, .a = operand_36, .b = operand_37, .c = operand_38, };
            const operand_40 = (&operand_39);
            const operand_41 = (zx_abi).zx_type_75{ .writer = operand_34, .frame = operand_40, };

            break :block_42 (try function_59(allocator, (&operand_41)));
        };

        _ = block_33: {
            const operand_22 = value_4;
            const operand_23 = @as((zx_abi).zx_type_63, .Expression);
            const operand_27 = (try function_53(allocator, block_26: {
                const operand_24 = ((&value_2)).conditional_yes;
                const operand_25 = value_3;

                if ((operand_25 >= (operand_24).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_26 (operand_24)[@intCast(operand_25)];
            }));
            const operand_28 = value_7;
            const operand_29 = value_8;
            const operand_30 = (zx_abi).zx_type_64{ .phase = operand_23, .a = operand_27, .b = operand_28, .c = operand_29, };
            const operand_31 = (&operand_30);
            const operand_32 = (zx_abi).zx_type_75{ .writer = operand_22, .frame = operand_31, };

            break :block_33 (try function_59(allocator, (&operand_32)));
        };

        _ = block_21: {
            const operand_13 = value_4;
            const operand_14 = @as((zx_abi).zx_type_63, .Assume);
            const operand_15 = value_9;
            const operand_16 = @as(u64, 1);
            const operand_17 = @as(u64, 0);
            const operand_18 = (zx_abi).zx_type_64{ .phase = operand_14, .a = operand_15, .b = operand_16, .c = operand_17, };
            const operand_19 = (&operand_18);
            const operand_20 = (zx_abi).zx_type_75{ .writer = operand_13, .frame = operand_19, };

            break :block_21 (try function_59(allocator, (&operand_20)));
        };

        _ = block_12: {
            const operand_4 = value_4;
            const operand_5 = @as((zx_abi).zx_type_63, .Expression);
            const operand_6 = value_9;
            const operand_7 = value_7;
            const operand_8 = value_8;
            const operand_9 = (zx_abi).zx_type_64{ .phase = operand_5, .a = operand_6, .b = operand_7, .c = operand_8, };
            const operand_10 = (&operand_9);
            const operand_11 = (zx_abi).zx_type_75{ .writer = operand_4, .frame = operand_10, };

            break :block_12 (try function_59(allocator, (&operand_11)));
        };
    } else {
        const value_10: u64 = (try function_53(allocator, block_102: {
            const operand_100 = ((&value_2)).binary_left;
            const operand_101 = value_3;

            if ((operand_101 >= (operand_100).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_102 (operand_100)[@intCast(operand_101)];
        }));
        const value_11: (zx_abi).zx_type_26 = block_99: {
            const operand_97 = ((&value_2)).binary_operators;
            const operand_98 = value_3;

            if ((operand_98 >= (operand_97).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_99 (operand_97)[@intCast(operand_98)];
        };

        _ = block_96: {
            const operand_85 = value_4;
            const operand_86 = @as((zx_abi).zx_type_63, .Expression);
            const operand_90 = (try function_53(allocator, block_89: {
                const operand_87 = ((&value_2)).binary_right;
                const operand_88 = value_3;

                if ((operand_88 >= (operand_87).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_89 (operand_87)[@intCast(operand_88)];
            }));
            const operand_91 = value_7;
            const operand_92 = value_8;
            const operand_93 = (zx_abi).zx_type_64{ .phase = operand_86, .a = operand_90, .b = operand_91, .c = operand_92, };
            const operand_94 = (&operand_93);
            const operand_95 = (zx_abi).zx_type_75{ .writer = operand_85, .frame = operand_94, };

            break :block_96 (try function_59(allocator, (&operand_95)));
        };

        if (((value_11 == @as((zx_abi).zx_type_26, .LogicalAnd)) or (value_11 == @as((zx_abi).zx_type_26, .LogicalOr)))) {
            _ = block_84: {
                const operand_76 = value_4;
                const operand_77 = @as((zx_abi).zx_type_63, .Assume);
                const operand_78 = value_10;
                const operand_79 = (if ((value_11 == @as((zx_abi).zx_type_26, .LogicalAnd))) @as(u64, 1) else @as(u64, 0));
                const operand_80 = @as(u64, 0);
                const operand_81 = (zx_abi).zx_type_64{ .phase = operand_77, .a = operand_78, .b = operand_79, .c = operand_80, };
                const operand_82 = (&operand_81);
                const operand_83 = (zx_abi).zx_type_75{ .writer = operand_76, .frame = operand_82, };

                break :block_84 (try function_59(allocator, (&operand_83)));
            };
        }

        _ = block_75: {
            const operand_67 = value_4;
            const operand_68 = @as((zx_abi).zx_type_63, .Expression);
            const operand_69 = value_10;
            const operand_70 = value_7;
            const operand_71 = value_8;
            const operand_72 = (zx_abi).zx_type_64{ .phase = operand_68, .a = operand_69, .b = operand_70, .c = operand_71, };
            const operand_73 = (&operand_72);
            const operand_74 = (zx_abi).zx_type_75{ .writer = operand_67, .frame = operand_73, };

            break :block_75 (try function_59(allocator, (&operand_74)));
        };
    }

    return true;
}

fn function_73(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: (zx_abi).zx_type_35 = ((((&value_1)).body).expressions).*;
    const value_3: u64 = (try function_53(allocator, block_81: {
        const operand_79 = ((&value_2)).payloads;
        const operand_80 = ((in).frame).a;

        if ((operand_80 >= (operand_79).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_81 (operand_79)[@intCast(operand_80)];
    }));
    const value_4: u64 = (((in).frame).b + @as(u64, 1));

    _ = block_78: {
        const operand_67 = ((&value_1)).writer;
        const operand_68 = @as((zx_abi).zx_type_63, .Expression);
        const operand_72 = (try function_53(allocator, block_71: {
            const operand_69 = ((&value_2)).match_fallbacks;
            const operand_70 = value_3;

            if ((operand_70 >= (operand_69).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_71 (operand_69)[@intCast(operand_70)];
        }));
        const operand_73 = value_4;
        const operand_74 = ((in).frame).c;
        const operand_75 = (zx_abi).zx_type_64{ .phase = operand_68, .a = operand_72, .b = operand_73, .c = operand_74, };
        const operand_76 = (&operand_75);
        const operand_77 = (zx_abi).zx_type_75{ .writer = operand_67, .frame = operand_76, };

        break :block_78 (try function_59(allocator, (&operand_77)));
    };

    _ = block_66: {
        const operand_26 = block_25: {
            const operand_14 = (&value_1);
            const operand_15 = (try function_53(allocator, block_18: {
                const operand_16 = ((&value_2)).match_first;
                const operand_17 = value_3;

                if ((operand_17 >= (operand_16).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_18 (operand_16)[@intCast(operand_17)];
            }));
            const operand_19 = (try function_53(allocator, block_22: {
                const operand_20 = ((&value_2)).match_count;
                const operand_21 = value_3;

                if ((operand_21 >= (operand_20).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_22 (operand_20)[@intCast(operand_21)];
            }));
            const operand_23 = value_4;
            const operand_24 = ((in).frame).c;

            break :block_25 (zx_abi).zx_type_85{ .program = operand_14, .first = operand_15, .index = operand_19, .depth = operand_23, .flags = operand_24, };
        };

        var state_13: (zx_abi).value_zx_type_85_31e15449bd18f804ffcfbc074a78d810e7463576437cf20dc181de102dcb6346 = (zx_abi).value_zx_type_85_31e15449bd18f804ffcfbc074a78d810e7463576437cf20dc181de102dcb6346{ .depth = (operand_26).depth, .first = (operand_26).first, .flags = (operand_26).flags, .index = (operand_26).index, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = ((((operand_26).program).body).control).block_count, .block_first = ((((operand_26).program).body).control).block_first, .branch_conditions = ((((operand_26).program).body).control).branch_conditions, .branch_no = ((((operand_26).program).body).control).branch_no, .branch_yes = ((((operand_26).program).body).control).branch_yes, .case_bodies = ((((operand_26).program).body).control).case_bodies, .case_values = ((((operand_26).program).body).control).case_values, .constant_symbols = ((((operand_26).program).body).control).constant_symbols, .constant_values = ((((operand_26).program).body).control).constant_values, .destructure_count = ((((operand_26).program).body).control).destructure_count, .destructure_first = ((((operand_26).program).body).control).destructure_first, .destructure_symbols = ((((operand_26).program).body).control).destructure_symbols, .destructure_values = ((((operand_26).program).body).control).destructure_values, .evaluations = ((((operand_26).program).body).control).evaluations, .parallel_count = ((((operand_26).program).body).control).parallel_count, .parallel_first = ((((operand_26).program).body).control).parallel_first, .parallel_symbols = ((((operand_26).program).body).control).parallel_symbols, .parallel_values = ((((operand_26).program).body).control).parallel_values, .results = ((((operand_26).program).body).control).results, .selection_count = ((((operand_26).program).body).control).selection_count, .selection_exhaustive = ((((operand_26).program).body).control).selection_exhaustive, .selection_first = ((((operand_26).program).body).control).selection_first, .selection_subjects = ((((operand_26).program).body).control).selection_subjects, .setter_slots = ((((operand_26).program).body).control).setter_slots, .setter_values = ((((operand_26).program).body).control).setter_values, .statement_kinds = ((((operand_26).program).body).control).statement_kinds, .statement_payloads = ((((operand_26).program).body).control).statement_payloads, .zx_origin = (((operand_26).program).body).control, }, .expressions = (((operand_26).program).body).expressions, .root = (((operand_26).program).body).root, .stores = (((operand_26).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_26).program).body).symbols).names, .ownership = ((((operand_26).program).body).symbols).ownership, .span_end = ((((operand_26).program).body).symbols).span_end, .span_start = ((((operand_26).program).body).symbols).span_start, .types = ((((operand_26).program).body).symbols).types, .zx_origin = (((operand_26).program).body).symbols, }, .zx_origin = ((operand_26).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = (((operand_26).program).functions).expressions, .native_concurrent = (((operand_26).program).functions).native_concurrent, .native_modules = (((operand_26).program).functions).native_modules, .stores = (((operand_26).program).functions).stores, .zx_origin = ((operand_26).program).functions, }, .output_type = ((operand_26).program).output_type, .table = ((operand_26).program).table, .transaction = ((operand_26).program).transaction, .writer = ((operand_26).program).writer, .zx_origin = (operand_26).program, }, .zx_origin = (&operand_26), };

        while (((state_13).index != @as(u64, 0))) {
            state_13 = block_65: {
                const value_7: (zx_abi).value_zx_type_85_31e15449bd18f804ffcfbc074a78d810e7463576437cf20dc181de102dcb6346 = state_13;
                const value_8: u64 = (value_7).index;
                const value_9: (zx_abi).value_zx_type_85_31e15449bd18f804ffcfbc074a78d810e7463576437cf20dc181de102dcb6346 = block_64: {
                    break :block_64 @as((zx_abi).value_zx_type_85_31e15449bd18f804ffcfbc074a78d810e7463576437cf20dc181de102dcb6346, (zx_abi).value_zx_type_85_31e15449bd18f804ffcfbc074a78d810e7463576437cf20dc181de102dcb6346{ .depth = (value_7).depth, .first = (value_7).first, .flags = (value_7).flags, .index = (block_63: {
                        break :block_63 value_8;
                    } - @as(u64, 1)), .program = (value_7).program, });
                };
                const value_10: u64 = ((value_9).first + (value_9).index);
                const value_11: *const (zx_abi).zx_type_35 = (((value_9).program).body).expressions;

                _ = block_62: {
                    const operand_45 = ((value_9).program).writer;
                    const operand_46 = @as((zx_abi).zx_type_63, .Expression);
                    const operand_54 = block_53: {
                        const operand_52 = block_51: {
                            const operand_49 = (block_47: {
                                break :block_47 value_11;
                            }).match_results;
                            const operand_50 = block_48: {
                                break :block_48 value_10;
                            };

                            if ((operand_50 >= (operand_49).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_51 (operand_49)[@intCast(operand_50)];
                        };

                        break :block_53 (try function_53(allocator, operand_52));
                    };
                    const operand_55 = (value_9).depth;
                    const operand_56 = (value_9).flags;
                    const operand_57 = (zx_abi).zx_type_64{ .phase = operand_46, .a = operand_54, .b = operand_55, .c = operand_56, };
                    const operand_58 = (&operand_57);
                    const operand_59 = (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .a = (operand_58).a, .b = (operand_58).b, .c = (operand_58).c, .phase = (operand_58).phase, .zx_origin = operand_58, };

                    var state_borrow_60: (zx_abi).zx_type_64 = undefined;

                    state_borrow_60 = (zx_abi).zx_type_64{ .a = (operand_59).a, .b = (operand_59).b, .c = (operand_59).c, .phase = (operand_59).phase, };

                    const operand_61 = (zx_abi).zx_type_75{ .writer = operand_45, .frame = ((operand_59).zx_origin orelse (&state_borrow_60)), };

                    break :block_62 (try function_59(allocator, (&operand_61)));
                };

                _ = block_44: {
                    const operand_27 = ((value_9).program).writer;
                    const operand_28 = @as((zx_abi).zx_type_63, .Expression);
                    const operand_36 = block_35: {
                        const operand_34 = block_33: {
                            const operand_31 = (block_29: {
                                break :block_29 value_11;
                            }).match_conditions;
                            const operand_32 = block_30: {
                                break :block_30 value_10;
                            };

                            if ((operand_32 >= (operand_31).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_33 (operand_31)[@intCast(operand_32)];
                        };

                        break :block_35 (try function_53(allocator, operand_34));
                    };
                    const operand_37 = (value_9).depth;
                    const operand_38 = (value_9).flags;
                    const operand_39 = (zx_abi).zx_type_64{ .phase = operand_28, .a = operand_36, .b = operand_37, .c = operand_38, };
                    const operand_40 = (&operand_39);
                    const operand_41 = (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .a = (operand_40).a, .b = (operand_40).b, .c = (operand_40).c, .phase = (operand_40).phase, .zx_origin = operand_40, };

                    var state_borrow_42: (zx_abi).zx_type_64 = undefined;

                    state_borrow_42 = (zx_abi).zx_type_64{ .a = (operand_41).a, .b = (operand_41).b, .c = (operand_41).c, .phase = (operand_41).phase, };

                    const operand_43 = (zx_abi).zx_type_75{ .writer = operand_27, .frame = ((operand_41).zx_origin orelse (&state_borrow_42)), };

                    break :block_44 (try function_59(allocator, (&operand_43)));
                };

                break :block_65 value_9;
            };
        }

        break :block_66 {};
    };

    const value_12: ?u32 = block_12: {
        const operand_10 = ((&value_2)).match_subjects;
        const operand_11 = value_3;

        if ((operand_11 >= (operand_10).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_12 (operand_10)[@intCast(operand_11)];
    };

    if ((value_12 != null)) {
        _ = block_9: {
            const operand_1 = ((&value_1)).writer;
            const operand_2 = @as((zx_abi).zx_type_63, .Expression);
            const operand_3 = (try function_53(allocator, value_12.?));
            const operand_4 = value_4;
            const operand_5 = ((in).frame).c;
            const operand_6 = (zx_abi).zx_type_64{ .phase = operand_2, .a = operand_3, .b = operand_4, .c = operand_5, };
            const operand_7 = (&operand_6);
            const operand_8 = (zx_abi).zx_type_75{ .writer = operand_1, .frame = operand_7, };

            break :block_9 (try function_59(allocator, (&operand_8)));
        };
    }

    return true;
}

fn function_74(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_86) error{ IndexOutOfBounds, OutOfMemory, }!void {
    @setRuntimeSafety(true);

    _ = block_126: {
        const operand_5 = block_4: {
            const operand_2 = in;
            const operand_3 = @as(u64, 0);

            break :block_4 (zx_abi).zx_type_87{ .input = operand_2, .index = operand_3, };
        };

        var state_1: (zx_abi).value_zx_type_87_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = (zx_abi).value_zx_type_87_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b{ .index = (operand_5).index, .input = (zx_abi).value_zx_type_86_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = ((operand_5).input).count, .expressions = ((operand_5).input).expressions, .first = ((operand_5).input).first, .writer = ((operand_5).input).writer, .zx_origin = (operand_5).input, }, .zx_origin = (&operand_5), };

        while (((state_1).index < ((state_1).input).count)) {
            state_1 = block_125: {
                const value_3: (zx_abi).value_zx_type_86_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (state_1).input;
                const value_4: *const (zx_abi).zx_type_35 = (value_3).expressions;
                const value_5: u64 = ((value_3).first + (state_1).index);
                const value_6: ?u32 = block_124: {
                    const operand_122 = (block_120: {
                        break :block_120 value_4;
                    }).scope_symbols;
                    const operand_123 = block_121: {
                        break :block_121 value_5;
                    };

                    if ((operand_123 >= (operand_122).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_124 (operand_122)[@intCast(operand_123)];
                };
                const value_7: u64 = block_119: {
                    const operand_118 = block_117: {
                        const operand_115 = (block_113: {
                            break :block_113 value_4;
                        }).scope_values;
                        const operand_116 = block_114: {
                            break :block_114 value_5;
                        };

                        if ((operand_116 >= (operand_115).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_117 (operand_115)[@intCast(operand_116)];
                    };

                    break :block_119 (try function_53(allocator, operand_118));
                };
                const value_27: (zx_abi).value_zx_type_87_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = (if (((block_8: {
                    break :block_8 value_6;
                } != null) and (block_13: {
                    const operand_11 = (block_9: {
                        break :block_9 value_4;
                    }).kinds;
                    const operand_12 = block_10: {
                        break :block_10 value_7;
                    };

                    if ((operand_12 >= (operand_11).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_13 (operand_11)[@intCast(operand_12)];
                } == @as((zx_abi).zx_type_22, .Capture)))) block_112: {
                    const value_8: ?u32 = @as(?u32, null);
                    const value_26: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = block_111: {
                        const operand_37 = block_36: {
                            const operand_25 = block_26: {
                                break :block_26 value_4;
                            };
                            const operand_27 = (value_3).first;
                            const operand_28 = (value_3).count;
                            const operand_29 = block_30: {
                                break :block_30 value_6;
                            }.?;
                            const operand_31 = ((state_1).index + @as(u64, 1));
                            const operand_32 = block_33: {
                                break :block_33 value_8;
                            };
                            const operand_34 = block_35: {
                                break :block_35 value_8;
                            };

                            break :block_36 @as((zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066, (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066{ .expressions = operand_25, .first = operand_27, .count = operand_28, .symbol = operand_29, .index = operand_31, .err = operand_32, .result = operand_34, });
                        };

                        var state_24: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = operand_37;

                        var state_changed_38 = false;

                        while (((state_24).index < (state_24).count)) {
                            state_24 = block_109: {
                                const value_11: *const (zx_abi).zx_type_35 = (state_24).expressions;
                                const value_12: u64 = ((state_24).first + (state_24).index);
                                const value_13: u64 = block_108: {
                                    const operand_107 = block_106: {
                                        const operand_104 = (block_102: {
                                            break :block_102 value_11;
                                        }).scope_values;
                                        const operand_105 = block_103: {
                                            break :block_103 value_12;
                                        };

                                        if ((operand_105 >= (operand_104).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_106 (operand_104)[@intCast(operand_105)];
                                    };

                                    break :block_108 (try function_53(allocator, operand_107));
                                };
                                const value_14: u64 = block_101: {
                                    const operand_100 = block_99: {
                                        const operand_97 = (block_95: {
                                            break :block_95 value_11;
                                        }).payloads;
                                        const operand_98 = block_96: {
                                            break :block_96 value_13;
                                        };

                                        if ((operand_98 >= (operand_97).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_99 (operand_97)[@intCast(operand_98)];
                                    };

                                    break :block_101 (try function_53(allocator, operand_100));
                                };
                                const value_22: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = (if (((block_45: {
                                    const operand_43 = (block_41: {
                                        break :block_41 value_11;
                                    }).kinds;
                                    const operand_44 = block_42: {
                                        break :block_42 value_13;
                                    };

                                    if ((operand_44 >= (operand_43).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_45 (operand_43)[@intCast(operand_44)];
                                } == @as((zx_abi).zx_type_22, .TupleField)) and (block_50: {
                                    const operand_48 = (block_46: {
                                        break :block_46 value_11;
                                    }).projection_indices;
                                    const operand_49 = block_47: {
                                        break :block_47 value_14;
                                    };

                                    if ((operand_49 >= (operand_48).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_50 (operand_48)[@intCast(operand_49)];
                                } < @as(u32, 2)))) block_94: {
                                    const value_15: u64 = block_93: {
                                        const operand_92 = block_91: {
                                            const operand_89 = (block_87: {
                                                break :block_87 value_11;
                                            }).projection_targets;
                                            const operand_90 = block_88: {
                                                break :block_88 value_14;
                                            };

                                            if ((operand_90 >= (operand_89).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            break :block_91 (operand_89)[@intCast(operand_90)];
                                        };

                                        break :block_93 (try function_53(allocator, operand_92));
                                    };
                                    const value_21: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = (if (((block_55: {
                                        const operand_53 = (block_51: {
                                            break :block_51 value_11;
                                        }).kinds;
                                        const operand_54 = block_52: {
                                            break :block_52 value_15;
                                        };

                                        if ((operand_54 >= (operand_53).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_55 (operand_53)[@intCast(operand_54)];
                                    } == @as((zx_abi).zx_type_22, .Reference)) and (block_66: {
                                        const operand_64 = (block_56: {
                                            break :block_56 value_11;
                                        }).references;
                                        const operand_65 = block_63: {
                                            const operand_62 = block_61: {
                                                const operand_59 = (block_57: {
                                                    break :block_57 value_11;
                                                }).payloads;
                                                const operand_60 = block_58: {
                                                    break :block_58 value_15;
                                                };

                                                if ((operand_60 >= (operand_59).len)) {
                                                    return error.IndexOutOfBounds;
                                                }

                                                break :block_61 (operand_59)[@intCast(operand_60)];
                                            };

                                            break :block_63 (try function_53(allocator, operand_62));
                                        };

                                        if ((operand_65 >= (operand_64).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_66 (operand_64)[@intCast(operand_65)];
                                    } == (state_24).symbol))) block_86: {
                                        const value_20: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = (if ((block_71: {
                                            const operand_69 = (block_67: {
                                                break :block_67 value_11;
                                            }).projection_indices;
                                            const operand_70 = block_68: {
                                                break :block_68 value_14;
                                            };

                                            if ((operand_70 >= (operand_69).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            break :block_71 (operand_69)[@intCast(operand_70)];
                                        } == @as(u32, 0))) block_78: {
                                            const value_16: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = state_24;
                                            const value_17: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = block_77: {
                                                break :block_77 @as((zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066, (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066{ .count = (value_16).count, .err = block_76: {
                                                    const operand_74 = (block_72: {
                                                        break :block_72 value_11;
                                                    }).scope_symbols;
                                                    const operand_75 = block_73: {
                                                        break :block_73 value_12;
                                                    };

                                                    if ((operand_75 >= (operand_74).len)) {
                                                        return error.IndexOutOfBounds;
                                                    }

                                                    break :block_76 (operand_74)[@intCast(operand_75)];
                                                }, .expressions = (value_16).expressions, .first = (value_16).first, .index = (value_16).index, .result = (value_16).result, .symbol = (value_16).symbol, });
                                            };

                                            break :block_78 value_17;
                                        } else block_85: {
                                            const value_18: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = state_24;
                                            const value_19: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = block_84: {
                                                break :block_84 @as((zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066, (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066{ .count = (value_18).count, .err = (value_18).err, .expressions = (value_18).expressions, .first = (value_18).first, .index = (value_18).index, .result = block_83: {
                                                    const operand_81 = (block_79: {
                                                        break :block_79 value_11;
                                                    }).scope_symbols;
                                                    const operand_82 = block_80: {
                                                        break :block_80 value_12;
                                                    };

                                                    if ((operand_82 >= (operand_81).len)) {
                                                        return error.IndexOutOfBounds;
                                                    }

                                                    break :block_83 (operand_81)[@intCast(operand_82)];
                                                }, .symbol = (value_18).symbol, });
                                            };

                                            break :block_85 value_19;
                                        });

                                        break :block_86 value_20;
                                    } else state_24);

                                    break :block_94 value_21;
                                } else state_24);
                                const value_23: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = value_22;
                                const value_24: u64 = (value_23).index;
                                const value_25: (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = block_40: {
                                    break :block_40 @as((zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066, (zx_abi).value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066{ .count = (value_23).count, .err = (value_23).err, .expressions = (value_23).expressions, .first = (value_23).first, .index = (block_39: {
                                        break :block_39 value_24;
                                    } + @as(u64, 1)), .result = (value_23).result, .symbol = (value_23).symbol, });
                                };

                                break :block_109 value_25;
                            };

                            state_changed_38 = true;
                        }

                        break :block_111 (if (state_changed_38) state_24 else operand_37);
                    };

                    _ = block_23: {
                        const operand_14 = (value_3).writer;
                        const operand_16 = block_15: {
                            break :block_15 value_4;
                        };
                        const operand_18 = block_17: {
                            break :block_17 value_7;
                        };
                        const operand_19 = @as(u64, 2);
                        const operand_20 = (value_26).err;
                        const operand_21 = (value_26).result;
                        const operand_22 = (zx_abi).zx_type_81{ .writer = operand_14, .expressions = operand_16, .value = operand_18, .count = operand_19, .err = operand_20, .result = operand_21, };

                        break :block_23 (try function_68(allocator, (&operand_22)));
                    };

                    break :block_112 state_1;
                } else state_1);
                const value_28: (zx_abi).value_zx_type_87_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = value_27;
                const value_29: u64 = (value_28).index;
                const value_30: (zx_abi).value_zx_type_87_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = block_7: {
                    break :block_7 @as((zx_abi).value_zx_type_87_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b, (zx_abi).value_zx_type_87_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b{ .index = (block_6: {
                        break :block_6 value_29;
                    } + @as(u64, 1)), .input = (value_28).input, });
                };

                break :block_125 value_30;
            };
        }

        break :block_126 {};
    };
}

fn function_75(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: (zx_abi).zx_type_35 = ((((&value_1)).body).expressions).*;
    const value_3: u64 = (try function_53(allocator, block_88: {
        const operand_86 = ((&value_2)).payloads;
        const operand_87 = ((in).frame).a;

        if ((operand_87 >= (operand_86).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_88 (operand_86)[@intCast(operand_87)];
    }));
    const value_4: u64 = (try function_53(allocator, block_85: {
        const operand_83 = ((&value_2)).scope_first;
        const operand_84 = value_3;

        if ((operand_84 >= (operand_83).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_85 (operand_83)[@intCast(operand_84)];
    }));
    const value_5: u64 = (try function_53(allocator, block_82: {
        const operand_80 = ((&value_2)).scope_count;
        const operand_81 = value_3;

        if ((operand_81 >= (operand_80).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_82 (operand_80)[@intCast(operand_81)];
    }));
    const value_6: *const (zx_abi).zx_type_44 = ((&value_1)).writer;

    _ = block_79: {
        const operand_71 = value_6;
        const operand_72 = @as((zx_abi).zx_type_63, .Restore);
        const operand_73 = (try function_39(allocator, value_6));
        const operand_74 = (try function_45(allocator, value_6));
        const operand_75 = (try function_46(allocator, value_6));
        const operand_76 = (zx_abi).zx_type_64{ .phase = operand_72, .a = operand_73, .b = operand_74, .c = operand_75, };
        const operand_77 = (&operand_76);
        const operand_78 = (zx_abi).zx_type_75{ .writer = operand_71, .frame = operand_77, };

        break :block_79 (try function_59(allocator, (&operand_78)));
    };

    _ = block_70: {
        const operand_65 = value_6;
        const operand_66 = (&value_2);
        const operand_67 = value_4;
        const operand_68 = value_5;
        const operand_69 = (zx_abi).zx_type_86{ .writer = operand_65, .expressions = operand_66, .first = operand_67, .count = operand_68, };

        break :block_70 (try function_74(allocator, (&operand_69)));
    };

    _ = block_64: {
        const operand_53 = value_6;
        const operand_54 = @as((zx_abi).zx_type_63, .Expression);
        const operand_58 = (try function_53(allocator, block_57: {
            const operand_55 = ((&value_2)).scope_results;
            const operand_56 = value_3;

            if ((operand_56 >= (operand_55).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_57 (operand_55)[@intCast(operand_56)];
        }));
        const operand_59 = (((in).frame).b + @as(u64, 1));
        const operand_60 = ((in).frame).c;
        const operand_61 = (zx_abi).zx_type_64{ .phase = operand_54, .a = operand_58, .b = operand_59, .c = operand_60, };
        const operand_62 = (&operand_61);
        const operand_63 = (zx_abi).zx_type_75{ .writer = operand_53, .frame = operand_62, };

        break :block_64 (try function_59(allocator, (&operand_63)));
    };

    _ = block_52: {
        const operand_9 = block_8: {
            const operand_2 = (&value_1);
            const operand_3 = ((in).frame).a;
            const operand_4 = value_4;
            const operand_5 = value_5;
            const operand_6 = (((in).frame).b + @as(u64, 1));
            const operand_7 = ((in).frame).c;

            break :block_8 (zx_abi).zx_type_89{ .program = operand_2, .owner = operand_3, .first = operand_4, .index = operand_5, .depth = operand_6, .flags = operand_7, };
        };

        var state_1: (zx_abi).value_zx_type_89_e7ee2282fdd535757d8592f2cf0af81242b05678d9aad142082f45af24e83ff3 = (zx_abi).value_zx_type_89_e7ee2282fdd535757d8592f2cf0af81242b05678d9aad142082f45af24e83ff3{ .depth = (operand_9).depth, .first = (operand_9).first, .flags = (operand_9).flags, .index = (operand_9).index, .owner = (operand_9).owner, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = ((((operand_9).program).body).control).block_count, .block_first = ((((operand_9).program).body).control).block_first, .branch_conditions = ((((operand_9).program).body).control).branch_conditions, .branch_no = ((((operand_9).program).body).control).branch_no, .branch_yes = ((((operand_9).program).body).control).branch_yes, .case_bodies = ((((operand_9).program).body).control).case_bodies, .case_values = ((((operand_9).program).body).control).case_values, .constant_symbols = ((((operand_9).program).body).control).constant_symbols, .constant_values = ((((operand_9).program).body).control).constant_values, .destructure_count = ((((operand_9).program).body).control).destructure_count, .destructure_first = ((((operand_9).program).body).control).destructure_first, .destructure_symbols = ((((operand_9).program).body).control).destructure_symbols, .destructure_values = ((((operand_9).program).body).control).destructure_values, .evaluations = ((((operand_9).program).body).control).evaluations, .parallel_count = ((((operand_9).program).body).control).parallel_count, .parallel_first = ((((operand_9).program).body).control).parallel_first, .parallel_symbols = ((((operand_9).program).body).control).parallel_symbols, .parallel_values = ((((operand_9).program).body).control).parallel_values, .results = ((((operand_9).program).body).control).results, .selection_count = ((((operand_9).program).body).control).selection_count, .selection_exhaustive = ((((operand_9).program).body).control).selection_exhaustive, .selection_first = ((((operand_9).program).body).control).selection_first, .selection_subjects = ((((operand_9).program).body).control).selection_subjects, .setter_slots = ((((operand_9).program).body).control).setter_slots, .setter_values = ((((operand_9).program).body).control).setter_values, .statement_kinds = ((((operand_9).program).body).control).statement_kinds, .statement_payloads = ((((operand_9).program).body).control).statement_payloads, .zx_origin = (((operand_9).program).body).control, }, .expressions = (((operand_9).program).body).expressions, .root = (((operand_9).program).body).root, .stores = (((operand_9).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_9).program).body).symbols).names, .ownership = ((((operand_9).program).body).symbols).ownership, .span_end = ((((operand_9).program).body).symbols).span_end, .span_start = ((((operand_9).program).body).symbols).span_start, .types = ((((operand_9).program).body).symbols).types, .zx_origin = (((operand_9).program).body).symbols, }, .zx_origin = ((operand_9).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = (((operand_9).program).functions).expressions, .native_concurrent = (((operand_9).program).functions).native_concurrent, .native_modules = (((operand_9).program).functions).native_modules, .stores = (((operand_9).program).functions).stores, .zx_origin = ((operand_9).program).functions, }, .output_type = ((operand_9).program).output_type, .table = ((operand_9).program).table, .transaction = ((operand_9).program).transaction, .writer = ((operand_9).program).writer, .zx_origin = (operand_9).program, }, .zx_origin = (&operand_9), };

        while (((state_1).index != @as(u64, 0))) {
            state_1 = block_51: {
                const value_9: (zx_abi).value_zx_type_89_e7ee2282fdd535757d8592f2cf0af81242b05678d9aad142082f45af24e83ff3 = state_1;
                const value_10: u64 = (value_9).index;
                const value_11: (zx_abi).value_zx_type_89_e7ee2282fdd535757d8592f2cf0af81242b05678d9aad142082f45af24e83ff3 = block_50: {
                    break :block_50 @as((zx_abi).value_zx_type_89_e7ee2282fdd535757d8592f2cf0af81242b05678d9aad142082f45af24e83ff3, (zx_abi).value_zx_type_89_e7ee2282fdd535757d8592f2cf0af81242b05678d9aad142082f45af24e83ff3{ .depth = (value_9).depth, .first = (value_9).first, .flags = (value_9).flags, .index = (block_49: {
                        break :block_49 value_10;
                    } - @as(u64, 1)), .owner = (value_9).owner, .program = (value_9).program, });
                };
                const value_12: u64 = ((value_11).first + (value_11).index);
                const value_13: *const (zx_abi).zx_type_35 = (((value_11).program).body).expressions;
                const value_14: ?u32 = block_48: {
                    const operand_46 = (block_44: {
                        break :block_44 value_13;
                    }).scope_symbols;
                    const operand_47 = block_45: {
                        break :block_45 value_12;
                    };

                    if ((operand_47 >= (operand_46).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_48 (operand_46)[@intCast(operand_47)];
                };
                const value_15: (zx_abi).value_zx_type_89_e7ee2282fdd535757d8592f2cf0af81242b05678d9aad142082f45af24e83ff3 = (if ((block_28: {
                    break :block_28 value_14;
                } != null)) block_43: {
                    _ = block_42: {
                        const operand_29 = ((value_11).program).writer;
                        const operand_30 = @as((zx_abi).zx_type_63, .ScopeDeclare);
                        const operand_34 = block_33: {
                            const operand_32 = block_31: {
                                break :block_31 value_14;
                            }.?;

                            break :block_33 (try function_53(allocator, operand_32));
                        };
                        const operand_35 = (value_11).owner;
                        const operand_36 = @as(u64, 0);
                        const operand_37 = (zx_abi).zx_type_64{ .phase = operand_30, .a = operand_34, .b = operand_35, .c = operand_36, };
                        const operand_38 = (&operand_37);
                        const operand_39 = (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .a = (operand_38).a, .b = (operand_38).b, .c = (operand_38).c, .phase = (operand_38).phase, .zx_origin = operand_38, };

                        var state_borrow_40: (zx_abi).zx_type_64 = undefined;

                        state_borrow_40 = (zx_abi).zx_type_64{ .a = (operand_39).a, .b = (operand_39).b, .c = (operand_39).c, .phase = (operand_39).phase, };

                        const operand_41 = (zx_abi).zx_type_75{ .writer = operand_29, .frame = ((operand_39).zx_origin orelse (&state_borrow_40)), };

                        break :block_42 (try function_59(allocator, (&operand_41)));
                    };

                    break :block_43 value_11;
                } else value_11);

                _ = block_27: {
                    const operand_10 = ((value_15).program).writer;
                    const operand_11 = @as((zx_abi).zx_type_63, .Expression);
                    const operand_19 = block_18: {
                        const operand_17 = block_16: {
                            const operand_14 = (block_12: {
                                break :block_12 value_13;
                            }).scope_values;
                            const operand_15 = block_13: {
                                break :block_13 value_12;
                            };

                            if ((operand_15 >= (operand_14).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_16 (operand_14)[@intCast(operand_15)];
                        };

                        break :block_18 (try function_53(allocator, operand_17));
                    };
                    const operand_20 = (value_15).depth;
                    const operand_21 = (value_15).flags;
                    const operand_22 = (zx_abi).zx_type_64{ .phase = operand_11, .a = operand_19, .b = operand_20, .c = operand_21, };
                    const operand_23 = (&operand_22);
                    const operand_24 = (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .a = (operand_23).a, .b = (operand_23).b, .c = (operand_23).c, .phase = (operand_23).phase, .zx_origin = operand_23, };

                    var state_borrow_25: (zx_abi).zx_type_64 = undefined;

                    state_borrow_25 = (zx_abi).zx_type_64{ .a = (operand_24).a, .b = (operand_24).b, .c = (operand_24).c, .phase = (operand_24).phase, };

                    const operand_26 = (zx_abi).zx_type_75{ .writer = operand_10, .frame = ((operand_24).zx_origin orelse (&state_borrow_25)), };

                    break :block_27 (try function_59(allocator, (&operand_26)));
                };

                break :block_51 value_15;
            };
        }

        break :block_52 {};
    };

    return true;
}

fn function_76(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: (zx_abi).zx_type_35 = ((((&value_1)).body).expressions).*;
    const value_3: u64 = (try function_53(allocator, block_88: {
        const operand_86 = ((&value_2)).payloads;
        const operand_87 = ((in).frame).a;

        if ((operand_87 >= (operand_86).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_88 (operand_86)[@intCast(operand_87)];
    }));
    const value_4: u64 = (try function_53(allocator, block_85: {
        const operand_83 = ((&value_2)).task_capture_first;
        const operand_84 = value_3;

        if ((operand_84 >= (operand_83).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_85 (operand_83)[@intCast(operand_84)];
    }));
    const value_5: u64 = (try function_53(allocator, block_82: {
        const operand_80 = ((&value_2)).task_capture_count;
        const operand_81 = value_3;

        if ((operand_81 >= (operand_80).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_82 (operand_80)[@intCast(operand_81)];
    }));
    const value_14: (zx_abi).zx_type_90 = block_79: {
        const operand_51 = block_50: {
            const operand_45 = (&value_1);
            const operand_46 = value_4;
            const operand_47 = value_5;
            const operand_48 = @as(u64, 0);
            const operand_49 = true;

            break :block_50 (zx_abi).zx_type_90{ .program = operand_45, .first = operand_46, .count = operand_47, .index = operand_48, .valid = operand_49, };
        };

        var state_44: (zx_abi).value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd = (zx_abi).value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd{ .count = (operand_51).count, .first = (operand_51).first, .index = (operand_51).index, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = ((((operand_51).program).body).control).block_count, .block_first = ((((operand_51).program).body).control).block_first, .branch_conditions = ((((operand_51).program).body).control).branch_conditions, .branch_no = ((((operand_51).program).body).control).branch_no, .branch_yes = ((((operand_51).program).body).control).branch_yes, .case_bodies = ((((operand_51).program).body).control).case_bodies, .case_values = ((((operand_51).program).body).control).case_values, .constant_symbols = ((((operand_51).program).body).control).constant_symbols, .constant_values = ((((operand_51).program).body).control).constant_values, .destructure_count = ((((operand_51).program).body).control).destructure_count, .destructure_first = ((((operand_51).program).body).control).destructure_first, .destructure_symbols = ((((operand_51).program).body).control).destructure_symbols, .destructure_values = ((((operand_51).program).body).control).destructure_values, .evaluations = ((((operand_51).program).body).control).evaluations, .parallel_count = ((((operand_51).program).body).control).parallel_count, .parallel_first = ((((operand_51).program).body).control).parallel_first, .parallel_symbols = ((((operand_51).program).body).control).parallel_symbols, .parallel_values = ((((operand_51).program).body).control).parallel_values, .results = ((((operand_51).program).body).control).results, .selection_count = ((((operand_51).program).body).control).selection_count, .selection_exhaustive = ((((operand_51).program).body).control).selection_exhaustive, .selection_first = ((((operand_51).program).body).control).selection_first, .selection_subjects = ((((operand_51).program).body).control).selection_subjects, .setter_slots = ((((operand_51).program).body).control).setter_slots, .setter_values = ((((operand_51).program).body).control).setter_values, .statement_kinds = ((((operand_51).program).body).control).statement_kinds, .statement_payloads = ((((operand_51).program).body).control).statement_payloads, .zx_origin = (((operand_51).program).body).control, }, .expressions = (((operand_51).program).body).expressions, .root = (((operand_51).program).body).root, .stores = (((operand_51).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_51).program).body).symbols).names, .ownership = ((((operand_51).program).body).symbols).ownership, .span_end = ((((operand_51).program).body).symbols).span_end, .span_start = ((((operand_51).program).body).symbols).span_start, .types = ((((operand_51).program).body).symbols).types, .zx_origin = (((operand_51).program).body).symbols, }, .zx_origin = ((operand_51).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = (((operand_51).program).functions).expressions, .native_concurrent = (((operand_51).program).functions).native_concurrent, .native_modules = (((operand_51).program).functions).native_modules, .stores = (((operand_51).program).functions).stores, .zx_origin = ((operand_51).program).functions, }, .output_type = ((operand_51).program).output_type, .table = ((operand_51).program).table, .transaction = ((operand_51).program).transaction, .writer = ((operand_51).program).writer, .zx_origin = (operand_51).program, }, .valid = (operand_51).valid, .zx_origin = (&operand_51), };

        while (((state_44).valid and ((state_44).index < (state_44).count))) {
            state_44 = block_66: {
                const value_8: u64 = block_65: {
                    const operand_64 = block_63: {
                        const operand_61 = ((((state_44).program).body).expressions).task_captures;
                        const operand_62 = ((state_44).first + (state_44).index);

                        if ((operand_62 >= (operand_61).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_63 (operand_61)[@intCast(operand_62)];
                    };

                    break :block_65 (try function_53(allocator, operand_64));
                };
                const value_9: (zx_abi).value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd = state_44;
                const value_10: (zx_abi).value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd = block_60: {
                    break :block_60 @as((zx_abi).value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd, (zx_abi).value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd{ .count = (value_9).count, .first = (value_9).first, .index = (value_9).index, .program = (value_9).program, .valid = block_59: {
                        const operand_58 = @as((zx_abi).zx_type_46, block_57: {
                            const operand_54 = ((state_44).program).writer;
                            const operand_56 = block_55: {
                                break :block_55 value_8;
                            };

                            break :block_57 .{ operand_54, operand_56, };
                        });

                        break :block_59 (try function_37(allocator, (&operand_58)));
                    }, });
                };
                const value_11: (zx_abi).value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd = value_10;
                const value_12: u64 = (value_11).index;
                const value_13: (zx_abi).value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd = block_53: {
                    break :block_53 @as((zx_abi).value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd, (zx_abi).value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd{ .count = (value_11).count, .first = (value_11).first, .index = (block_52: {
                        break :block_52 value_12;
                    } + @as(u64, 1)), .program = (value_11).program, .valid = (value_11).valid, });
                };

                break :block_66 value_13;
            };
        }

        break :block_79 block_78: {
            break :block_78 (if (((state_44).zx_origin != null)) ((state_44).zx_origin.?).* else block_77: {
                break :block_77 (zx_abi).zx_type_90{ .count = (state_44).count, .first = (state_44).first, .index = (state_44).index, .program = (if ((((state_44).program).zx_origin != null)) ((state_44).program).zx_origin.? else block_76: {
                    const operand_75 = (try (allocator).create((zx_abi).zx_type_65));

                    (operand_75).* = (zx_abi).zx_type_65{ .body = (if (((((state_44).program).body).zx_origin != null)) (((state_44).program).body).zx_origin.? else block_72: {
                        const operand_71 = (try (allocator).create((zx_abi).zx_type_61));

                        (operand_71).* = (zx_abi).zx_type_61{ .control = (if ((((((state_44).program).body).control).zx_origin != null)) ((((state_44).program).body).control).zx_origin.? else block_68: {
                            const operand_67 = (try (allocator).create((zx_abi).zx_type_17));

                            (operand_67).* = (zx_abi).zx_type_17{ .block_count = ((((state_44).program).body).control).block_count, .block_first = ((((state_44).program).body).control).block_first, .branch_conditions = ((((state_44).program).body).control).branch_conditions, .branch_no = ((((state_44).program).body).control).branch_no, .branch_yes = ((((state_44).program).body).control).branch_yes, .case_bodies = ((((state_44).program).body).control).case_bodies, .case_values = ((((state_44).program).body).control).case_values, .constant_symbols = ((((state_44).program).body).control).constant_symbols, .constant_values = ((((state_44).program).body).control).constant_values, .destructure_count = ((((state_44).program).body).control).destructure_count, .destructure_first = ((((state_44).program).body).control).destructure_first, .destructure_symbols = ((((state_44).program).body).control).destructure_symbols, .destructure_values = ((((state_44).program).body).control).destructure_values, .evaluations = ((((state_44).program).body).control).evaluations, .parallel_count = ((((state_44).program).body).control).parallel_count, .parallel_first = ((((state_44).program).body).control).parallel_first, .parallel_symbols = ((((state_44).program).body).control).parallel_symbols, .parallel_values = ((((state_44).program).body).control).parallel_values, .results = ((((state_44).program).body).control).results, .selection_count = ((((state_44).program).body).control).selection_count, .selection_exhaustive = ((((state_44).program).body).control).selection_exhaustive, .selection_first = ((((state_44).program).body).control).selection_first, .selection_subjects = ((((state_44).program).body).control).selection_subjects, .setter_slots = ((((state_44).program).body).control).setter_slots, .setter_values = ((((state_44).program).body).control).setter_values, .statement_kinds = ((((state_44).program).body).control).statement_kinds, .statement_payloads = ((((state_44).program).body).control).statement_payloads, };

                            break :block_68 @as(*const (zx_abi).zx_type_17, operand_67);
                        }), .expressions = (((state_44).program).body).expressions, .root = (((state_44).program).body).root, .stores = (((state_44).program).body).stores, .symbols = (if ((((((state_44).program).body).symbols).zx_origin != null)) ((((state_44).program).body).symbols).zx_origin.? else block_70: {
                            const operand_69 = (try (allocator).create((zx_abi).zx_type_60));

                            (operand_69).* = (zx_abi).zx_type_60{ .names = ((((state_44).program).body).symbols).names, .ownership = ((((state_44).program).body).symbols).ownership, .span_end = ((((state_44).program).body).symbols).span_end, .span_start = ((((state_44).program).body).symbols).span_start, .types = ((((state_44).program).body).symbols).types, };

                            break :block_70 @as(*const (zx_abi).zx_type_60, operand_69);
                        }), };

                        break :block_72 @as(*const (zx_abi).zx_type_61, operand_71);
                    }), .functions = (if (((((state_44).program).functions).zx_origin != null)) (((state_44).program).functions).zx_origin.? else block_74: {
                        const operand_73 = (try (allocator).create((zx_abi).zx_type_41));

                        (operand_73).* = (zx_abi).zx_type_41{ .expressions = (((state_44).program).functions).expressions, .native_concurrent = (((state_44).program).functions).native_concurrent, .native_modules = (((state_44).program).functions).native_modules, .stores = (((state_44).program).functions).stores, };

                        break :block_74 @as(*const (zx_abi).zx_type_41, operand_73);
                    }), .output_type = ((state_44).program).output_type, .table = ((state_44).program).table, .transaction = ((state_44).program).transaction, .writer = ((state_44).program).writer, };

                    break :block_76 @as(*const (zx_abi).zx_type_65, operand_75);
                }), .valid = (state_44).valid, };
            });
        };
    };

    if ((!((&value_14)).valid)) {
        return false;
    }

    const value_15: *const (zx_abi).zx_type_44 = ((&value_1)).writer;

    _ = block_43: {
        const operand_35 = value_15;
        const operand_36 = @as((zx_abi).zx_type_63, .Restore);
        const operand_37 = (try function_39(allocator, value_15));
        const operand_38 = (try function_45(allocator, value_15));
        const operand_39 = (try function_46(allocator, value_15));
        const operand_40 = (zx_abi).zx_type_64{ .phase = operand_36, .a = operand_37, .b = operand_38, .c = operand_39, };
        const operand_41 = (&operand_40);
        const operand_42 = (zx_abi).zx_type_75{ .writer = operand_35, .frame = operand_41, };

        break :block_43 (try function_59(allocator, (&operand_42)));
    };

    _ = (try function_64(allocator, (&value_1)));

    _ = block_34: {
        const operand_19 = block_18: {
            const operand_14 = (&value_1);
            const operand_15 = value_4;
            const operand_16 = value_5;
            const operand_17 = @as(u64, 0);

            break :block_18 (zx_abi).zx_type_91{ .program = operand_14, .first = operand_15, .count = operand_16, .index = operand_17, };
        };

        var state_13: (zx_abi).value_zx_type_91_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318 = (zx_abi).value_zx_type_91_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318{ .count = (operand_19).count, .first = (operand_19).first, .index = (operand_19).index, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = ((((operand_19).program).body).control).block_count, .block_first = ((((operand_19).program).body).control).block_first, .branch_conditions = ((((operand_19).program).body).control).branch_conditions, .branch_no = ((((operand_19).program).body).control).branch_no, .branch_yes = ((((operand_19).program).body).control).branch_yes, .case_bodies = ((((operand_19).program).body).control).case_bodies, .case_values = ((((operand_19).program).body).control).case_values, .constant_symbols = ((((operand_19).program).body).control).constant_symbols, .constant_values = ((((operand_19).program).body).control).constant_values, .destructure_count = ((((operand_19).program).body).control).destructure_count, .destructure_first = ((((operand_19).program).body).control).destructure_first, .destructure_symbols = ((((operand_19).program).body).control).destructure_symbols, .destructure_values = ((((operand_19).program).body).control).destructure_values, .evaluations = ((((operand_19).program).body).control).evaluations, .parallel_count = ((((operand_19).program).body).control).parallel_count, .parallel_first = ((((operand_19).program).body).control).parallel_first, .parallel_symbols = ((((operand_19).program).body).control).parallel_symbols, .parallel_values = ((((operand_19).program).body).control).parallel_values, .results = ((((operand_19).program).body).control).results, .selection_count = ((((operand_19).program).body).control).selection_count, .selection_exhaustive = ((((operand_19).program).body).control).selection_exhaustive, .selection_first = ((((operand_19).program).body).control).selection_first, .selection_subjects = ((((operand_19).program).body).control).selection_subjects, .setter_slots = ((((operand_19).program).body).control).setter_slots, .setter_values = ((((operand_19).program).body).control).setter_values, .statement_kinds = ((((operand_19).program).body).control).statement_kinds, .statement_payloads = ((((operand_19).program).body).control).statement_payloads, .zx_origin = (((operand_19).program).body).control, }, .expressions = (((operand_19).program).body).expressions, .root = (((operand_19).program).body).root, .stores = (((operand_19).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_19).program).body).symbols).names, .ownership = ((((operand_19).program).body).symbols).ownership, .span_end = ((((operand_19).program).body).symbols).span_end, .span_start = ((((operand_19).program).body).symbols).span_start, .types = ((((operand_19).program).body).symbols).types, .zx_origin = (((operand_19).program).body).symbols, }, .zx_origin = ((operand_19).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = (((operand_19).program).functions).expressions, .native_concurrent = (((operand_19).program).functions).native_concurrent, .native_modules = (((operand_19).program).functions).native_modules, .stores = (((operand_19).program).functions).stores, .zx_origin = ((operand_19).program).functions, }, .output_type = ((operand_19).program).output_type, .table = ((operand_19).program).table, .transaction = ((operand_19).program).transaction, .writer = ((operand_19).program).writer, .zx_origin = (operand_19).program, }, .zx_origin = (&operand_19), };

        while (((state_13).index < (state_13).count)) {
            state_13 = block_33: {
                _ = block_32: {
                    const operand_31 = @as((zx_abi).zx_type_47, block_30: {
                        const operand_22 = ((state_13).program).writer;
                        const operand_28 = block_27: {
                            const operand_26 = block_25: {
                                const operand_23 = ((((state_13).program).body).expressions).task_captures;
                                const operand_24 = ((state_13).first + (state_13).index);

                                if ((operand_24 >= (operand_23).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_25 (operand_23)[@intCast(operand_24)];
                            };

                            break :block_27 (try function_53(allocator, operand_26));
                        };
                        const operand_29 = true;

                        break :block_30 .{ operand_22, operand_28, operand_29, };
                    });

                    break :block_32 (try function_38(allocator, (&operand_31)));
                };

                const value_18: (zx_abi).value_zx_type_91_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318 = state_13;
                const value_19: u64 = (value_18).index;
                const value_20: (zx_abi).value_zx_type_91_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318 = block_21: {
                    break :block_21 @as((zx_abi).value_zx_type_91_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318, (zx_abi).value_zx_type_91_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318{ .count = (value_18).count, .first = (value_18).first, .index = (block_20: {
                        break :block_20 value_19;
                    } + @as(u64, 1)), .program = (value_18).program, });
                };

                break :block_33 value_20;
            };
        }

        break :block_34 {};
    };

    _ = block_12: {
        const operand_1 = value_15;
        const operand_2 = @as((zx_abi).zx_type_63, .Expression);
        const operand_6 = (try function_53(allocator, block_5: {
            const operand_3 = ((&value_2)).task_bodies;
            const operand_4 = value_3;

            if ((operand_4 >= (operand_3).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_5 (operand_3)[@intCast(operand_4)];
        }));
        const operand_7 = (((in).frame).b + @as(u64, 1));
        const operand_8 = (if (((((in).frame).c == @as(u64, 1)) or (((in).frame).c == @as(u64, 3)))) @as(u64, 3) else @as(u64, 2));
        const operand_9 = (zx_abi).zx_type_64{ .phase = operand_2, .a = operand_6, .b = operand_7, .c = operand_8, };
        const operand_10 = (&operand_9);
        const operand_11 = (zx_abi).zx_type_75{ .writer = operand_1, .frame = operand_10, };

        break :block_12 (try function_59(allocator, (&operand_11)));
    };

    return true;
}

fn function_77(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: (zx_abi).zx_type_35 = ((((&value_1)).body).expressions).*;
    const value_3: (zx_abi).zx_type_64 = ((in).frame).*;

    if (((((&value_3)).a >= @as(u64, (((&value_2)).kinds).len)) or (((&value_3)).b > @as(u64, 256)))) {
        return false;
    }

    const value_4: (zx_abi).zx_type_22 = block_96: {
        const operand_94 = ((&value_2)).kinds;
        const operand_95 = ((&value_3)).a;

        if ((operand_95 >= (operand_94).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_96 (operand_94)[@intCast(operand_95)];
    };
    const value_5: u64 = (try function_53(allocator, block_93: {
        const operand_91 = ((&value_2)).payloads;
        const operand_92 = ((&value_3)).a;

        if ((operand_92 >= (operand_91).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_93 (operand_91)[@intCast(operand_92)];
    }));

    if ((value_4 == @as((zx_abi).zx_type_22, .StoreGet))) {
        return (((&value_3)).c == @as(u64, 0));
    }

    if ((value_4 == @as((zx_abi).zx_type_22, .Reference))) {
        return block_90: {
            const operand_89 = @as((zx_abi).zx_type_46, block_88: {
                const operand_83 = ((&value_1)).writer;
                const operand_87 = (try function_53(allocator, block_86: {
                    const operand_84 = ((&value_2)).references;
                    const operand_85 = value_5;

                    if ((operand_85 >= (operand_84).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_86 (operand_84)[@intCast(operand_85)];
                }));

                break :block_88 .{ operand_83, operand_87, };
            });

            break :block_90 (try function_37(allocator, (&operand_89)));
        };
    }

    if ((value_4 == @as((zx_abi).zx_type_22, .OptionalValue))) {
        const value_6: u64 = (try function_53(allocator, block_19: {
            const operand_17 = ((&value_2)).optional_values;
            const operand_18 = value_5;

            if ((operand_18 >= (operand_17).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_19 (operand_17)[@intCast(operand_18)];
        }));

        if (((block_5: {
            const operand_3 = ((&value_2)).kinds;
            const operand_4 = value_6;

            if ((operand_4 >= (operand_3).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_5 (operand_3)[@intCast(operand_4)];
        } != @as((zx_abi).zx_type_22, .Reference)) or (!block_16: {
            const operand_15 = @as((zx_abi).zx_type_46, block_14: {
                const operand_6 = ((&value_1)).writer;
                const operand_13 = (try function_53(allocator, block_12: {
                    const operand_10 = ((&value_2)).references;
                    const operand_11 = (try function_53(allocator, block_9: {
                        const operand_7 = ((&value_2)).payloads;
                        const operand_8 = value_6;

                        if ((operand_8 >= (operand_7).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_9 (operand_7)[@intCast(operand_8)];
                    }));

                    if ((operand_11 >= (operand_10).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_12 (operand_10)[@intCast(operand_11)];
                }));

                break :block_14 .{ operand_6, operand_13, };
            });

            break :block_16 (try function_48(allocator, (&operand_15)));
        }))) {
            return false;
        }
    } else {
        if ((value_4 == @as((zx_abi).zx_type_22, .Call))) {
            if ((((((&value_3)).c == @as(u64, 1)) or (((&value_3)).c == @as(u64, 3))) and (block_28: {
                const operand_26 = ((&value_2)).call_store_count;
                const operand_27 = value_5;

                if ((operand_27 >= (operand_26).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_28 (operand_26)[@intCast(operand_27)];
            } != @as(u32, 0)))) {
                return false;
            }

            if (((((&value_3)).c >= @as(u64, 2)) and (!block_25: {
                const operand_23 = (((in).context).prepared).concurrent;
                const operand_24 = (try function_53(allocator, block_22: {
                    const operand_20 = ((&value_2)).call_functions;
                    const operand_21 = value_5;

                    if ((operand_21 >= (operand_20).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_22 (operand_20)[@intCast(operand_21)];
                }));

                if ((operand_24 >= (operand_23).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_25 (operand_23)[@intCast(operand_24)];
            }))) {
                return false;
            }
        } else {
            if ((value_4 == @as((zx_abi).zx_type_22, .Iteration))) {
                _ = block_49: {
                    const operand_41 = ((&value_1)).writer;
                    const operand_42 = @as((zx_abi).zx_type_63, .IterationCondition);
                    const operand_43 = ((&value_3)).a;
                    const operand_44 = ((&value_3)).b;
                    const operand_45 = ((&value_3)).c;
                    const operand_46 = (zx_abi).zx_type_64{ .phase = operand_42, .a = operand_43, .b = operand_44, .c = operand_45, };
                    const operand_47 = (&operand_46);
                    const operand_48 = (zx_abi).zx_type_75{ .writer = operand_41, .frame = operand_47, };

                    break :block_49 (try function_59(allocator, (&operand_48)));
                };

                _ = block_40: {
                    const operand_29 = ((&value_1)).writer;
                    const operand_30 = @as((zx_abi).zx_type_63, .Expression);
                    const operand_34 = (try function_53(allocator, block_33: {
                        const operand_31 = ((&value_2)).iteration_initials;
                        const operand_32 = value_5;

                        if ((operand_32 >= (operand_31).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_33 (operand_31)[@intCast(operand_32)];
                    }));
                    const operand_35 = (((&value_3)).b + @as(u64, 1));
                    const operand_36 = ((&value_3)).c;
                    const operand_37 = (zx_abi).zx_type_64{ .phase = operand_30, .a = operand_34, .b = operand_35, .c = operand_36, };
                    const operand_38 = (&operand_37);
                    const operand_39 = (zx_abi).zx_type_75{ .writer = operand_29, .frame = operand_38, };

                    break :block_40 (try function_59(allocator, (&operand_39)));
                };

                return true;
            } else {
                if ((value_4 == @as((zx_abi).zx_type_22, .Transform))) {
                    _ = block_82: {
                        const operand_74 = ((&value_1)).writer;
                        const operand_75 = @as((zx_abi).zx_type_63, .Transform);
                        const operand_76 = ((&value_3)).a;
                        const operand_77 = ((&value_3)).b;
                        const operand_78 = ((&value_3)).c;
                        const operand_79 = (zx_abi).zx_type_64{ .phase = operand_75, .a = operand_76, .b = operand_77, .c = operand_78, };
                        const operand_80 = (&operand_79);
                        const operand_81 = (zx_abi).zx_type_75{ .writer = operand_74, .frame = operand_80, };

                        break :block_82 (try function_59(allocator, (&operand_81)));
                    };

                    const value_7: ?u32 = block_73: {
                        const operand_71 = ((&value_2)).transform_initials;
                        const operand_72 = value_5;

                        if ((operand_72 >= (operand_71).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_73 (operand_71)[@intCast(operand_72)];
                    };

                    if ((value_7 != null)) {
                        _ = block_70: {
                            const operand_62 = ((&value_1)).writer;
                            const operand_63 = @as((zx_abi).zx_type_63, .Expression);
                            const operand_64 = (try function_53(allocator, value_7.?));
                            const operand_65 = (((&value_3)).b + @as(u64, 1));
                            const operand_66 = ((&value_3)).c;
                            const operand_67 = (zx_abi).zx_type_64{ .phase = operand_63, .a = operand_64, .b = operand_65, .c = operand_66, };
                            const operand_68 = (&operand_67);
                            const operand_69 = (zx_abi).zx_type_75{ .writer = operand_62, .frame = operand_68, };

                            break :block_70 (try function_59(allocator, (&operand_69)));
                        };
                    }

                    _ = block_61: {
                        const operand_50 = ((&value_1)).writer;
                        const operand_51 = @as((zx_abi).zx_type_63, .Expression);
                        const operand_55 = (try function_53(allocator, block_54: {
                            const operand_52 = ((&value_2)).transform_targets;
                            const operand_53 = value_5;

                            if ((operand_53 >= (operand_52).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_54 (operand_52)[@intCast(operand_53)];
                        }));
                        const operand_56 = (((&value_3)).b + @as(u64, 1));
                        const operand_57 = ((&value_3)).c;
                        const operand_58 = (zx_abi).zx_type_64{ .phase = operand_51, .a = operand_55, .b = operand_56, .c = operand_57, };
                        const operand_59 = (&operand_58);
                        const operand_60 = (zx_abi).zx_type_75{ .writer = operand_50, .frame = operand_59, };

                        break :block_61 (try function_59(allocator, (&operand_60)));
                    };

                    return true;
                }
            }
        }
    }

    return block_2: {
        const operand_1 = value_4;

        break :block_2 (if ((operand_1 == @as((zx_abi).zx_type_22, .Scope))) (try function_75(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Task))) (try function_76(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Binary))) (try function_72(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Conditional))) (try function_72(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Match))) (try function_73(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .ListUpdate))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Field))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .TupleField))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Index))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Length))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Some))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Capture))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .AwaitTask))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .CancelTask))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Parallel))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .OptionalValue))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Unary))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .List))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Tuple))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Template))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Object))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Call))) (try function_71(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_22, .ListOperation))) (try function_71(allocator, in)) else true)))))))))))))))))))))));
    };
}

fn function_78(allocator: ((std).mem).Allocator, in: u32) error{ }!(zx_abi).zx_type_95 {
    @setRuntimeSafety(true);

    _ = allocator;

    if (((in >= @as(u32, 2)) and (in <= @as(u32, 5)))) {
        return @as((zx_abi).zx_type_95, .Integer);
    }

    if (((in == @as(u32, 6)) or (in == @as(u32, 7)))) {
        return @as((zx_abi).zx_type_95, .Signed);
    }

    return (if (((in == @as(u32, 8)) or (in == @as(u32, 9)))) @as((zx_abi).zx_type_95, .Float) else @as((zx_abi).zx_type_95, .Other));
}

fn function_79(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_96) error{ IndexOutOfBounds, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_35 = ((in).expressions).*;
    const value_2: (zx_abi).zx_type_22 = block_65: {
        const operand_63 = ((&value_1)).kinds;
        const operand_64 = (in).left;

        if ((operand_64 >= (operand_63).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_65 (operand_63)[@intCast(operand_64)];
    };
    const value_3: (zx_abi).zx_type_22 = block_62: {
        const operand_60 = ((&value_1)).kinds;
        const operand_61 = (in).right;

        if ((operand_61 >= (operand_60).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_62 (operand_60)[@intCast(operand_61)];
    };
    const value_4: u64 = (try function_53(allocator, block_59: {
        const operand_57 = ((&value_1)).payloads;
        const operand_58 = (in).left;

        if ((operand_58 >= (operand_57).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_59 (operand_57)[@intCast(operand_58)];
    }));
    const value_5: u64 = (try function_53(allocator, block_56: {
        const operand_54 = ((&value_1)).payloads;
        const operand_55 = (in).right;

        if ((operand_55 >= (operand_54).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_56 (operand_54)[@intCast(operand_55)];
    }));

    if ((value_2 != value_3)) {
        return (((((value_2 == @as((zx_abi).zx_type_22, .Integer)) and (block_44: {
            const operand_42 = ((&value_1)).integers;
            const operand_43 = value_4;

            if ((operand_43 >= (operand_42).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_44 (operand_42)[@intCast(operand_43)];
        } == @as(u64, 0))) and (value_3 == @as((zx_abi).zx_type_22, .NegativeInteger))) and (block_47: {
            const operand_45 = ((&value_1)).negative_integers;
            const operand_46 = value_5;

            if ((operand_46 >= (operand_45).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_47 (operand_45)[@intCast(operand_46)];
        } == @as(u64, 0))) or ((((value_3 == @as((zx_abi).zx_type_22, .Integer)) and (block_50: {
            const operand_48 = ((&value_1)).integers;
            const operand_49 = value_5;

            if ((operand_49 >= (operand_48).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_50 (operand_48)[@intCast(operand_49)];
        } == @as(u64, 0))) and (value_2 == @as((zx_abi).zx_type_22, .NegativeInteger))) and (block_53: {
            const operand_51 = ((&value_1)).negative_integers;
            const operand_52 = value_4;

            if ((operand_52 >= (operand_51).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_53 (operand_51)[@intCast(operand_52)];
        } == @as(u64, 0))));
    }

    return block_41: {
        const operand_1 = value_2;

        break :block_41 (if ((operand_1 == @as((zx_abi).zx_type_22, .Integer))) (block_37: {
            const operand_35 = ((&value_1)).integers;
            const operand_36 = value_4;

            if ((operand_36 >= (operand_35).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_37 (operand_35)[@intCast(operand_36)];
        } == block_40: {
            const operand_38 = ((&value_1)).integers;
            const operand_39 = value_5;

            if ((operand_39 >= (operand_38).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_40 (operand_38)[@intCast(operand_39)];
        }) else (if ((operand_1 == @as((zx_abi).zx_type_22, .NegativeInteger))) (block_31: {
            const operand_29 = ((&value_1)).negative_integers;
            const operand_30 = value_4;

            if ((operand_30 >= (operand_29).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_31 (operand_29)[@intCast(operand_30)];
        } == block_34: {
            const operand_32 = ((&value_1)).negative_integers;
            const operand_33 = value_5;

            if ((operand_33 >= (operand_32).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_34 (operand_32)[@intCast(operand_33)];
        }) else (if ((operand_1 == @as((zx_abi).zx_type_22, .Boolean))) (block_25: {
            const operand_23 = ((&value_1)).booleans;
            const operand_24 = value_4;

            if ((operand_24 >= (operand_23).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_25 (operand_23)[@intCast(operand_24)];
        } == block_28: {
            const operand_26 = ((&value_1)).booleans;
            const operand_27 = value_5;

            if ((operand_27 >= (operand_26).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_28 (operand_26)[@intCast(operand_27)];
        }) else (if ((operand_1 == @as((zx_abi).zx_type_22, .String))) block_22: {
            const operand_20 = block_16: {
                const operand_14 = ((&value_1)).strings;
                const operand_15 = value_4;

                if ((operand_15 >= (operand_14).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_16 (operand_14)[@intCast(operand_15)];
            };
            const operand_21 = block_19: {
                const operand_17 = ((&value_1)).strings;
                const operand_18 = value_5;

                if ((operand_18 >= (operand_17).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_19 (operand_17)[@intCast(operand_18)];
            };

            break :block_22 ((std).mem).eql(u8, operand_20, operand_21);
        } else (if ((operand_1 == @as((zx_abi).zx_type_22, .EnumValue))) (block_10: {
            const operand_8 = ((&value_1)).enumerations;
            const operand_9 = value_4;

            if ((operand_9 >= (operand_8).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_10 (operand_8)[@intCast(operand_9)];
        } == block_13: {
            const operand_11 = ((&value_1)).enumerations;
            const operand_12 = value_5;

            if ((operand_12 >= (operand_11).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_13 (operand_11)[@intCast(operand_12)];
        }) else (if ((operand_1 == @as((zx_abi).zx_type_22, .ErrorValue))) (block_4: {
            const operand_2 = ((&value_1)).errors;
            const operand_3 = value_4;

            if ((operand_3 >= (operand_2).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_4 (operand_2)[@intCast(operand_3)];
        } == block_7: {
            const operand_5 = ((&value_1)).errors;
            const operand_6 = value_5;

            if ((operand_6 >= (operand_5).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_7 (operand_5)[@intCast(operand_6)];
        }) else false))))));
    };
}

fn function_80(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_97) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = ((in).program).*;
    const value_2: (zx_abi).zx_type_17 = ((((&value_1)).body).control).*;
    const value_3: (zx_abi).zx_type_35 = ((((&value_1)).body).expressions).*;
    const value_4: u32 = block_107: {
        const operand_105 = ((&value_3)).types;
        const operand_106 = (try function_53(allocator, block_104: {
            const operand_102 = ((&value_2)).selection_subjects;
            const operand_103 = (in).payload;

            if ((operand_103 >= (operand_102).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_104 (operand_102)[@intCast(operand_103)];
        }));

        if ((operand_106 >= (operand_105).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_107 (operand_105)[@intCast(operand_106)];
    };
    const value_5: (zx_abi).zx_type_49 = (try function_67(allocator, block_101: {
        const operand_99 = (((&value_1)).table).kinds;
        const operand_100 = (try function_53(allocator, value_4));

        if ((operand_100 >= (operand_99).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_101 (operand_99)[@intCast(operand_100)];
    }));
    const value_6: (zx_abi).zx_type_95 = (try function_78(allocator, value_4));

    if (((((((value_5 != @as((zx_abi).zx_type_49, .Enumeration)) and (value_5 != @as((zx_abi).zx_type_49, .ErrorSet))) and (value_6 != @as((zx_abi).zx_type_95, .Integer))) and (value_6 != @as((zx_abi).zx_type_95, .Signed))) and (value_4 != @as(u32, 1))) and (value_4 != @as(u32, 10)))) {
        return false;
    }

    const value_7: u64 = (try function_53(allocator, block_98: {
        const operand_96 = ((&value_2)).selection_first;
        const operand_97 = (in).payload;

        if ((operand_97 >= (operand_96).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_98 (operand_96)[@intCast(operand_97)];
    }));
    const value_8: u64 = (try function_53(allocator, block_95: {
        const operand_93 = ((&value_2)).selection_count;
        const operand_94 = (in).payload;

        if ((operand_94 >= (operand_93).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_95 (operand_93)[@intCast(operand_94)];
    }));
    const value_38: (zx_abi).zx_type_98 = block_92: {
        const operand_16 = block_15: {
            const operand_8 = (&value_1);
            const operand_9 = value_4;
            const operand_10 = value_7;
            const operand_11 = value_8;
            const operand_12 = @as(u64, 0);
            const operand_13 = false;
            const operand_14 = true;

            break :block_15 (zx_abi).zx_type_98{ .program = operand_8, .type_id = operand_9, .first = operand_10, .count = operand_11, .index = operand_12, .has_default = operand_13, .valid = operand_14, };
        };

        var state_7: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243{ .count = (operand_16).count, .first = (operand_16).first, .has_default = (operand_16).has_default, .index = (operand_16).index, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = ((((operand_16).program).body).control).block_count, .block_first = ((((operand_16).program).body).control).block_first, .branch_conditions = ((((operand_16).program).body).control).branch_conditions, .branch_no = ((((operand_16).program).body).control).branch_no, .branch_yes = ((((operand_16).program).body).control).branch_yes, .case_bodies = ((((operand_16).program).body).control).case_bodies, .case_values = ((((operand_16).program).body).control).case_values, .constant_symbols = ((((operand_16).program).body).control).constant_symbols, .constant_values = ((((operand_16).program).body).control).constant_values, .destructure_count = ((((operand_16).program).body).control).destructure_count, .destructure_first = ((((operand_16).program).body).control).destructure_first, .destructure_symbols = ((((operand_16).program).body).control).destructure_symbols, .destructure_values = ((((operand_16).program).body).control).destructure_values, .evaluations = ((((operand_16).program).body).control).evaluations, .parallel_count = ((((operand_16).program).body).control).parallel_count, .parallel_first = ((((operand_16).program).body).control).parallel_first, .parallel_symbols = ((((operand_16).program).body).control).parallel_symbols, .parallel_values = ((((operand_16).program).body).control).parallel_values, .results = ((((operand_16).program).body).control).results, .selection_count = ((((operand_16).program).body).control).selection_count, .selection_exhaustive = ((((operand_16).program).body).control).selection_exhaustive, .selection_first = ((((operand_16).program).body).control).selection_first, .selection_subjects = ((((operand_16).program).body).control).selection_subjects, .setter_slots = ((((operand_16).program).body).control).setter_slots, .setter_values = ((((operand_16).program).body).control).setter_values, .statement_kinds = ((((operand_16).program).body).control).statement_kinds, .statement_payloads = ((((operand_16).program).body).control).statement_payloads, .zx_origin = (((operand_16).program).body).control, }, .expressions = (((operand_16).program).body).expressions, .root = (((operand_16).program).body).root, .stores = (((operand_16).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_16).program).body).symbols).names, .ownership = ((((operand_16).program).body).symbols).ownership, .span_end = ((((operand_16).program).body).symbols).span_end, .span_start = ((((operand_16).program).body).symbols).span_start, .types = ((((operand_16).program).body).symbols).types, .zx_origin = (((operand_16).program).body).symbols, }, .zx_origin = ((operand_16).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = (((operand_16).program).functions).expressions, .native_concurrent = (((operand_16).program).functions).native_concurrent, .native_modules = (((operand_16).program).functions).native_modules, .stores = (((operand_16).program).functions).stores, .zx_origin = ((operand_16).program).functions, }, .output_type = ((operand_16).program).output_type, .table = ((operand_16).program).table, .transaction = ((operand_16).program).transaction, .writer = ((operand_16).program).writer, .zx_origin = (operand_16).program, }, .type_id = (operand_16).type_id, .valid = (operand_16).valid, .zx_origin = (&operand_16), };

        while (((state_7).valid and ((state_7).index < (state_7).count))) {
            state_7 = block_79: {
                const value_11: ?u32 = block_78: {
                    const operand_76 = ((((state_7).program).body).control).case_values;
                    const operand_77 = ((state_7).first + (state_7).index);

                    if ((operand_77 >= (operand_76).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_78 (operand_76)[@intCast(operand_77)];
                };
                const value_34: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = (if ((block_19: {
                    break :block_19 value_11;
                } == null)) block_22: {
                    const value_12: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = state_7;
                    const value_13: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = block_21: {
                        break :block_21 @as((zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243, (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243{ .count = (value_12).count, .first = (value_12).first, .has_default = (value_12).has_default, .index = (value_12).index, .program = (value_12).program, .type_id = (value_12).type_id, .valid = (!(state_7).has_default), });
                    };
                    const value_14: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = value_13;
                    const value_15: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = block_20: {
                        break :block_20 @as((zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243, (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243{ .count = (value_14).count, .first = (value_14).first, .has_default = true, .index = (value_14).index, .program = (value_14).program, .type_id = (value_14).type_id, .valid = (value_14).valid, });
                    };

                    break :block_22 value_15;
                } else block_75: {
                    const value_16: u64 = block_74: {
                        const operand_73 = block_72: {
                            break :block_72 value_11;
                        }.?;

                        break :block_74 (try function_53(allocator, operand_73));
                    };
                    const value_17: *const (zx_abi).zx_type_35 = (((state_7).program).body).expressions;
                    const value_33: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = (if (((block_23: {
                        break :block_23 value_16;
                    } >= @as(u64, ((block_24: {
                        break :block_24 value_17;
                    }).kinds).len)) or (block_29: {
                        const operand_27 = (block_25: {
                            break :block_25 value_17;
                        }).types;
                        const operand_28 = block_26: {
                            break :block_26 value_16;
                        };

                        if ((operand_28 >= (operand_27).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_29 (operand_27)[@intCast(operand_28)];
                    } != (state_7).type_id))) block_31: {
                        const value_18: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = state_7;
                        const value_19: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = block_30: {
                            break :block_30 @as((zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243, (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243{ .count = (value_18).count, .first = (value_18).first, .has_default = (value_18).has_default, .index = (value_18).index, .program = (value_18).program, .type_id = (value_18).type_id, .valid = false, });
                        };

                        break :block_31 value_19;
                    } else block_71: {
                        const value_20: bool = block_70: {
                            const operand_69 = block_68: {
                                const operand_66 = (block_64: {
                                    break :block_64 value_17;
                                }).kinds;
                                const operand_67 = block_65: {
                                    break :block_65 value_16;
                                };

                                if ((operand_67 >= (operand_66).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_68 (operand_66)[@intCast(operand_67)];
                            };

                            break :block_70 (if ((operand_69 == @as((zx_abi).zx_type_22, .Integer))) true else (if ((operand_69 == @as((zx_abi).zx_type_22, .NegativeInteger))) true else (if ((operand_69 == @as((zx_abi).zx_type_22, .String))) true else (if ((operand_69 == @as((zx_abi).zx_type_22, .Boolean))) true else (if ((operand_69 == @as((zx_abi).zx_type_22, .EnumValue))) true else (if ((operand_69 == @as((zx_abi).zx_type_22, .ErrorValue))) true else false))))));
                        };
                        const value_30: (zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = block_63: {
                            const operand_43 = block_42: {
                                const operand_35 = (state_7).program;
                                const operand_36 = (state_7).first;
                                const operand_37 = (state_7).index;
                                const operand_38 = block_39: {
                                    break :block_39 value_16;
                                };
                                const operand_40 = @as(u64, 0);
                                const operand_41 = false;

                                break :block_42 @as((zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3, (zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3{ .program = operand_35, .first = operand_36, .count = operand_37, .value = operand_38, .index = operand_40, .found = operand_41, });
                            };

                            var state_34: (zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = operand_43;

                            var state_changed_44 = false;

                            while (((!(state_34).found) and ((state_34).index < (state_34).count))) {
                                state_34 = block_61: {
                                    const value_23: ?u32 = block_60: {
                                        const operand_58 = ((((state_34).program).body).control).case_values;
                                        const operand_59 = ((state_34).first + (state_34).index);

                                        if ((operand_59 >= (operand_58).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_60 (operand_58)[@intCast(operand_59)];
                                    };
                                    const value_26: (zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = (if ((block_47: {
                                        break :block_47 value_23;
                                    } != null)) block_57: {
                                        const value_24: (zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = state_34;
                                        const value_25: (zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = block_56: {
                                            break :block_56 @as((zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3, (zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3{ .count = (value_24).count, .first = (value_24).first, .found = block_55: {
                                                const operand_48 = (((state_34).program).body).expressions;
                                                const operand_49 = (state_34).value;
                                                const operand_53 = block_52: {
                                                    const operand_51 = block_50: {
                                                        break :block_50 value_23;
                                                    }.?;

                                                    break :block_52 (try function_53(allocator, operand_51));
                                                };
                                                const operand_54 = (zx_abi).zx_type_96{ .expressions = operand_48, .left = operand_49, .right = operand_53, };

                                                break :block_55 (try function_79(allocator, (&operand_54)));
                                            }, .index = (value_24).index, .program = (value_24).program, .value = (value_24).value, });
                                        };

                                        break :block_57 value_25;
                                    } else state_34);
                                    const value_27: (zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = value_26;
                                    const value_28: u64 = (value_27).index;
                                    const value_29: (zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = block_46: {
                                        break :block_46 @as((zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3, (zx_abi).value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3{ .count = (value_27).count, .first = (value_27).first, .found = (value_27).found, .index = (block_45: {
                                            break :block_45 value_28;
                                        } + @as(u64, 1)), .program = (value_27).program, .value = (value_27).value, });
                                    };

                                    break :block_61 value_29;
                                };

                                state_changed_44 = true;
                            }

                            break :block_63 (if (state_changed_44) state_34 else operand_43);
                        };
                        const value_31: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = state_7;
                        const value_32: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = block_33: {
                            break :block_33 @as((zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243, (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243{ .count = (value_31).count, .first = (value_31).first, .has_default = (value_31).has_default, .index = (value_31).index, .program = (value_31).program, .type_id = (value_31).type_id, .valid = (block_32: {
                                break :block_32 value_20;
                            } and (!(value_30).found)), });
                        };

                        break :block_71 value_32;
                    });

                    break :block_75 value_33;
                });
                const value_35: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = value_34;
                const value_36: u64 = (value_35).index;
                const value_37: (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = block_18: {
                    break :block_18 @as((zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243, (zx_abi).value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243{ .count = (value_35).count, .first = (value_35).first, .has_default = (value_35).has_default, .index = (block_17: {
                        break :block_17 value_36;
                    } + @as(u64, 1)), .program = (value_35).program, .type_id = (value_35).type_id, .valid = (value_35).valid, });
                };

                break :block_79 value_37;
            };
        }

        break :block_92 block_91: {
            break :block_91 (if (((state_7).zx_origin != null)) ((state_7).zx_origin.?).* else block_90: {
                break :block_90 (zx_abi).zx_type_98{ .count = (state_7).count, .first = (state_7).first, .has_default = (state_7).has_default, .index = (state_7).index, .program = (if ((((state_7).program).zx_origin != null)) ((state_7).program).zx_origin.? else block_89: {
                    const operand_88 = (try (allocator).create((zx_abi).zx_type_65));

                    (operand_88).* = (zx_abi).zx_type_65{ .body = (if (((((state_7).program).body).zx_origin != null)) (((state_7).program).body).zx_origin.? else block_85: {
                        const operand_84 = (try (allocator).create((zx_abi).zx_type_61));

                        (operand_84).* = (zx_abi).zx_type_61{ .control = (if ((((((state_7).program).body).control).zx_origin != null)) ((((state_7).program).body).control).zx_origin.? else block_81: {
                            const operand_80 = (try (allocator).create((zx_abi).zx_type_17));

                            (operand_80).* = (zx_abi).zx_type_17{ .block_count = ((((state_7).program).body).control).block_count, .block_first = ((((state_7).program).body).control).block_first, .branch_conditions = ((((state_7).program).body).control).branch_conditions, .branch_no = ((((state_7).program).body).control).branch_no, .branch_yes = ((((state_7).program).body).control).branch_yes, .case_bodies = ((((state_7).program).body).control).case_bodies, .case_values = ((((state_7).program).body).control).case_values, .constant_symbols = ((((state_7).program).body).control).constant_symbols, .constant_values = ((((state_7).program).body).control).constant_values, .destructure_count = ((((state_7).program).body).control).destructure_count, .destructure_first = ((((state_7).program).body).control).destructure_first, .destructure_symbols = ((((state_7).program).body).control).destructure_symbols, .destructure_values = ((((state_7).program).body).control).destructure_values, .evaluations = ((((state_7).program).body).control).evaluations, .parallel_count = ((((state_7).program).body).control).parallel_count, .parallel_first = ((((state_7).program).body).control).parallel_first, .parallel_symbols = ((((state_7).program).body).control).parallel_symbols, .parallel_values = ((((state_7).program).body).control).parallel_values, .results = ((((state_7).program).body).control).results, .selection_count = ((((state_7).program).body).control).selection_count, .selection_exhaustive = ((((state_7).program).body).control).selection_exhaustive, .selection_first = ((((state_7).program).body).control).selection_first, .selection_subjects = ((((state_7).program).body).control).selection_subjects, .setter_slots = ((((state_7).program).body).control).setter_slots, .setter_values = ((((state_7).program).body).control).setter_values, .statement_kinds = ((((state_7).program).body).control).statement_kinds, .statement_payloads = ((((state_7).program).body).control).statement_payloads, };

                            break :block_81 @as(*const (zx_abi).zx_type_17, operand_80);
                        }), .expressions = (((state_7).program).body).expressions, .root = (((state_7).program).body).root, .stores = (((state_7).program).body).stores, .symbols = (if ((((((state_7).program).body).symbols).zx_origin != null)) ((((state_7).program).body).symbols).zx_origin.? else block_83: {
                            const operand_82 = (try (allocator).create((zx_abi).zx_type_60));

                            (operand_82).* = (zx_abi).zx_type_60{ .names = ((((state_7).program).body).symbols).names, .ownership = ((((state_7).program).body).symbols).ownership, .span_end = ((((state_7).program).body).symbols).span_end, .span_start = ((((state_7).program).body).symbols).span_start, .types = ((((state_7).program).body).symbols).types, };

                            break :block_83 @as(*const (zx_abi).zx_type_60, operand_82);
                        }), };

                        break :block_85 @as(*const (zx_abi).zx_type_61, operand_84);
                    }), .functions = (if (((((state_7).program).functions).zx_origin != null)) (((state_7).program).functions).zx_origin.? else block_87: {
                        const operand_86 = (try (allocator).create((zx_abi).zx_type_41));

                        (operand_86).* = (zx_abi).zx_type_41{ .expressions = (((state_7).program).functions).expressions, .native_concurrent = (((state_7).program).functions).native_concurrent, .native_modules = (((state_7).program).functions).native_modules, .stores = (((state_7).program).functions).stores, };

                        break :block_87 @as(*const (zx_abi).zx_type_41, operand_86);
                    }), .output_type = ((state_7).program).output_type, .table = ((state_7).program).table, .transaction = ((state_7).program).transaction, .writer = ((state_7).program).writer, };

                    break :block_89 @as(*const (zx_abi).zx_type_65, operand_88);
                }), .type_id = (state_7).type_id, .valid = (state_7).valid, };
            });
        };
    };
    const value_39: bool = ((((&value_38)).has_default or (((value_5 == @as((zx_abi).zx_type_49, .Enumeration)) or (value_5 == @as((zx_abi).zx_type_49, .ErrorSet))) and (value_8 == (try function_53(allocator, block_6: {
        const operand_4 = (((&value_1)).table).second;
        const operand_5 = (try function_53(allocator, value_4));

        if ((operand_5 >= (operand_4).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_6 (operand_4)[@intCast(operand_5)];
    }))))) or ((value_4 == @as(u32, 1)) and (value_8 == @as(u64, 2))));

    return (((&value_38)).valid and (block_3: {
        const operand_1 = ((&value_2)).selection_exhaustive;
        const operand_2 = (in).payload;

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    } == value_39));
}

fn function_81(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_2: (zx_abi).zx_type_17 = ((((&value_1)).body).control).*;

    if ((!block_58: {
        const operand_55 = (&value_1);
        const operand_56 = ((in).frame).a;
        const operand_57 = (zx_abi).zx_type_97{ .program = operand_55, .payload = operand_56, };

        break :block_58 (try function_80(allocator, (&operand_57)));
    })) {
        return false;
    }

    _ = block_54: {
        const operand_13 = block_12: {
            const operand_2 = (&value_1);
            const operand_3 = (try function_53(allocator, block_6: {
                const operand_4 = ((&value_2)).selection_first;
                const operand_5 = ((in).frame).a;

                if ((operand_5 >= (operand_4).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_6 (operand_4)[@intCast(operand_5)];
            }));
            const operand_7 = (try function_53(allocator, block_10: {
                const operand_8 = ((&value_2)).selection_count;
                const operand_9 = ((in).frame).a;

                if ((operand_9 >= (operand_8).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_10 (operand_8)[@intCast(operand_9)];
            }));
            const operand_11 = (((in).frame).b + @as(u64, 1));

            break :block_12 (zx_abi).zx_type_100{ .program = operand_2, .first = operand_3, .index = operand_7, .depth = operand_11, };
        };

        var state_1: (zx_abi).value_zx_type_100_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318 = (zx_abi).value_zx_type_100_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318{ .depth = (operand_13).depth, .first = (operand_13).first, .index = (operand_13).index, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = ((((operand_13).program).body).control).block_count, .block_first = ((((operand_13).program).body).control).block_first, .branch_conditions = ((((operand_13).program).body).control).branch_conditions, .branch_no = ((((operand_13).program).body).control).branch_no, .branch_yes = ((((operand_13).program).body).control).branch_yes, .case_bodies = ((((operand_13).program).body).control).case_bodies, .case_values = ((((operand_13).program).body).control).case_values, .constant_symbols = ((((operand_13).program).body).control).constant_symbols, .constant_values = ((((operand_13).program).body).control).constant_values, .destructure_count = ((((operand_13).program).body).control).destructure_count, .destructure_first = ((((operand_13).program).body).control).destructure_first, .destructure_symbols = ((((operand_13).program).body).control).destructure_symbols, .destructure_values = ((((operand_13).program).body).control).destructure_values, .evaluations = ((((operand_13).program).body).control).evaluations, .parallel_count = ((((operand_13).program).body).control).parallel_count, .parallel_first = ((((operand_13).program).body).control).parallel_first, .parallel_symbols = ((((operand_13).program).body).control).parallel_symbols, .parallel_values = ((((operand_13).program).body).control).parallel_values, .results = ((((operand_13).program).body).control).results, .selection_count = ((((operand_13).program).body).control).selection_count, .selection_exhaustive = ((((operand_13).program).body).control).selection_exhaustive, .selection_first = ((((operand_13).program).body).control).selection_first, .selection_subjects = ((((operand_13).program).body).control).selection_subjects, .setter_slots = ((((operand_13).program).body).control).setter_slots, .setter_values = ((((operand_13).program).body).control).setter_values, .statement_kinds = ((((operand_13).program).body).control).statement_kinds, .statement_payloads = ((((operand_13).program).body).control).statement_payloads, .zx_origin = (((operand_13).program).body).control, }, .expressions = (((operand_13).program).body).expressions, .root = (((operand_13).program).body).root, .stores = (((operand_13).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_13).program).body).symbols).names, .ownership = ((((operand_13).program).body).symbols).ownership, .span_end = ((((operand_13).program).body).symbols).span_end, .span_start = ((((operand_13).program).body).symbols).span_start, .types = ((((operand_13).program).body).symbols).types, .zx_origin = (((operand_13).program).body).symbols, }, .zx_origin = ((operand_13).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = (((operand_13).program).functions).expressions, .native_concurrent = (((operand_13).program).functions).native_concurrent, .native_modules = (((operand_13).program).functions).native_modules, .stores = (((operand_13).program).functions).stores, .zx_origin = ((operand_13).program).functions, }, .output_type = ((operand_13).program).output_type, .table = ((operand_13).program).table, .transaction = ((operand_13).program).transaction, .writer = ((operand_13).program).writer, .zx_origin = (operand_13).program, }, .zx_origin = (&operand_13), };

        while (((state_1).index != @as(u64, 0))) {
            state_1 = block_53: {
                const value_5: (zx_abi).value_zx_type_100_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318 = state_1;
                const value_6: u64 = (value_5).index;
                const value_7: (zx_abi).value_zx_type_100_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318 = block_52: {
                    break :block_52 @as((zx_abi).value_zx_type_100_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318, (zx_abi).value_zx_type_100_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318{ .depth = (value_5).depth, .first = (value_5).first, .index = (block_51: {
                        break :block_51 value_6;
                    } - @as(u64, 1)), .program = (value_5).program, });
                };
                const value_8: u64 = ((value_7).first + (value_7).index);
                const value_9: (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6 = (((value_7).program).body).control;

                _ = block_50: {
                    const operand_34 = ((value_7).program).writer;
                    const operand_35 = @as((zx_abi).zx_type_63, .Block);
                    const operand_42 = block_41: {
                        const operand_40 = block_39: {
                            const operand_37 = (value_9).case_bodies;
                            const operand_38 = block_36: {
                                break :block_36 value_8;
                            };

                            if ((operand_38 >= (operand_37).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_39 (operand_37)[@intCast(operand_38)];
                        };

                        break :block_41 (try function_53(allocator, operand_40));
                    };
                    const operand_43 = (value_7).depth;
                    const operand_44 = @as(u64, 0);
                    const operand_45 = (zx_abi).zx_type_64{ .phase = operand_35, .a = operand_42, .b = operand_43, .c = operand_44, };
                    const operand_46 = (&operand_45);
                    const operand_47 = (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .a = (operand_46).a, .b = (operand_46).b, .c = (operand_46).c, .phase = (operand_46).phase, .zx_origin = operand_46, };

                    var state_borrow_48: (zx_abi).zx_type_64 = undefined;

                    state_borrow_48 = (zx_abi).zx_type_64{ .a = (operand_47).a, .b = (operand_47).b, .c = (operand_47).c, .phase = (operand_47).phase, };

                    const operand_49 = (zx_abi).zx_type_75{ .writer = operand_34, .frame = ((operand_47).zx_origin orelse (&state_borrow_48)), };

                    break :block_50 (try function_59(allocator, (&operand_49)));
                };

                const value_10: ?u32 = block_33: {
                    const operand_31 = (value_9).case_values;
                    const operand_32 = block_30: {
                        break :block_30 value_8;
                    };

                    if ((operand_32 >= (operand_31).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_33 (operand_31)[@intCast(operand_32)];
                };
                const value_11: (zx_abi).value_zx_type_100_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318 = (if ((block_14: {
                    break :block_14 value_10;
                } != null)) block_29: {
                    _ = block_28: {
                        const operand_15 = ((value_7).program).writer;
                        const operand_16 = @as((zx_abi).zx_type_63, .Expression);
                        const operand_20 = block_19: {
                            const operand_18 = block_17: {
                                break :block_17 value_10;
                            }.?;

                            break :block_19 (try function_53(allocator, operand_18));
                        };
                        const operand_21 = @as(u64, 0);
                        const operand_22 = @as(u64, 0);
                        const operand_23 = (zx_abi).zx_type_64{ .phase = operand_16, .a = operand_20, .b = operand_21, .c = operand_22, };
                        const operand_24 = (&operand_23);
                        const operand_25 = (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .a = (operand_24).a, .b = (operand_24).b, .c = (operand_24).c, .phase = (operand_24).phase, .zx_origin = operand_24, };

                        var state_borrow_26: (zx_abi).zx_type_64 = undefined;

                        state_borrow_26 = (zx_abi).zx_type_64{ .a = (operand_25).a, .b = (operand_25).b, .c = (operand_25).c, .phase = (operand_25).phase, };

                        const operand_27 = (zx_abi).zx_type_75{ .writer = operand_15, .frame = ((operand_25).zx_origin orelse (&state_borrow_26)), };

                        break :block_28 (try function_59(allocator, (&operand_27)));
                    };

                    break :block_29 value_7;
                } else value_7);

                break :block_53 value_11;
            };
        }

        break :block_54 {};
    };

    return true;
}

fn function_82(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_68) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_64 = ((in).frame).*;
    const value_2: (zx_abi).zx_type_65 = (((in).context).program).*;
    const value_3: *const (zx_abi).zx_type_44 = ((&value_2)).writer;

    if ((((&value_1)).phase == @as((zx_abi).zx_type_63, .Restore))) {
        _ = block_42: {
            const operand_41 = @as((zx_abi).zx_type_46, block_40: {
                const operand_38 = value_3;
                const operand_39 = ((&value_1)).a;

                break :block_40 .{ operand_38, operand_39, };
            });

            break :block_42 (try function_40(allocator, (&operand_41)));
        };

        _ = block_37: {
            const operand_36 = @as((zx_abi).zx_type_48, block_35: {
                const operand_32 = value_3;
                const operand_33 = ((&value_1)).b;
                const operand_34 = ((&value_1)).c;

                break :block_35 .{ operand_32, operand_33, operand_34, };
            });

            break :block_37 (try function_47(allocator, (&operand_36)));
        };

        return true;
    }

    if ((((&value_1)).phase == @as((zx_abi).zx_type_63, .RestoreFacts))) {
        _ = block_31: {
            const operand_30 = @as((zx_abi).zx_type_48, block_29: {
                const operand_26 = value_3;
                const operand_27 = ((&value_1)).a;
                const operand_28 = ((&value_1)).b;

                break :block_29 .{ operand_26, operand_27, operand_28, };
            });

            break :block_31 (try function_47(allocator, (&operand_30)));
        };

        return true;
    }

    if ((((&value_1)).phase == @as((zx_abi).zx_type_63, .Assume))) {
        _ = block_25: {
            const operand_20 = value_3;
            const operand_21 = (((&value_2)).body).expressions;
            const operand_22 = ((&value_1)).a;
            const operand_23 = (((&value_1)).b != @as(u64, 0));
            const operand_24 = (zx_abi).zx_type_72{ .writer = operand_20, .expressions = operand_21, .condition = operand_22, .truth = operand_23, };

            break :block_25 (try function_56(allocator, (&operand_24)));
        };

        return true;
    }

    return block_19: {
        const operand_1 = ((&value_1)).phase;

        break :block_19 (if ((operand_1 == @as((zx_abi).zx_type_63, .Block))) (try function_62(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_63, .BlockNext))) (try function_62(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_63, .Expression))) (try function_77(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_63, .Declare))) block_18: {
            const operand_9 = (&value_2);
            const operand_10 = ((&value_1)).a;
            const operand_14 = block_13: {
                const operand_11 = ((((&value_2)).body).expressions).types;
                const operand_12 = ((&value_1)).b;

                if ((operand_12 >= (operand_11).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_13 (operand_11)[@intCast(operand_12)];
            };
            const operand_15 = @as(u64, 0);
            const operand_16 = @as((zx_abi).zx_type_69, .Ordinary);
            const operand_17 = (zx_abi).zx_type_79{ .program = operand_9, .symbol = operand_10, .type_id = operand_14, .owner = operand_15, .mode = operand_16, };

            break :block_18 (try function_65(allocator, (&operand_17)));
        } else (if ((operand_1 == @as((zx_abi).zx_type_63, .ScopeDeclare))) block_8: {
            const operand_2 = (&value_2);
            const operand_3 = ((&value_1)).a;
            const operand_4 = @as(u32, 0);
            const operand_5 = ((&value_1)).b;
            const operand_6 = @as((zx_abi).zx_type_69, .Scope);
            const operand_7 = (zx_abi).zx_type_79{ .program = operand_2, .symbol = operand_3, .type_id = operand_4, .owner = operand_5, .mode = operand_6, };

            break :block_8 (try function_65(allocator, (&operand_7)));
        } else (if ((operand_1 == @as((zx_abi).zx_type_63, .Destructure))) (try function_69(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_63, .Branch))) (try function_63(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_63, .BranchPost))) (try function_63(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_63, .Switch))) (try function_81(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_63, .IterationCondition))) (try function_66(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_63, .IterationBody))) (try function_66(allocator, in)) else (if ((operand_1 == @as((zx_abi).zx_type_63, .Transform))) (try function_66(allocator, in)) else false))))))))))));
    };
}

fn function_83(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ OutOfMemory, }!*const (zx_abi).zx_type_64 {
    @setRuntimeSafety(true);

    _ = (try function_31(allocator, in));

    const value_1: (zx_abi).zx_type_63 = block_9: {
        const operand_8 = (try function_33(allocator, in));

        break :block_9 (if ((operand_8 == @as(u64, 0))) @as((zx_abi).zx_type_63, .Block) else (if ((operand_8 == @as(u64, 1))) @as((zx_abi).zx_type_63, .BlockNext) else (if ((operand_8 == @as(u64, 2))) @as((zx_abi).zx_type_63, .Expression) else (if ((operand_8 == @as(u64, 3))) @as((zx_abi).zx_type_63, .Declare) else (if ((operand_8 == @as(u64, 4))) @as((zx_abi).zx_type_63, .ScopeDeclare) else (if ((operand_8 == @as(u64, 5))) @as((zx_abi).zx_type_63, .Destructure) else (if ((operand_8 == @as(u64, 6))) @as((zx_abi).zx_type_63, .Branch) else (if ((operand_8 == @as(u64, 7))) @as((zx_abi).zx_type_63, .BranchPost) else (if ((operand_8 == @as(u64, 8))) @as((zx_abi).zx_type_63, .Switch) else (if ((operand_8 == @as(u64, 9))) @as((zx_abi).zx_type_63, .Restore) else (if ((operand_8 == @as(u64, 10))) @as((zx_abi).zx_type_63, .RestoreFacts) else (if ((operand_8 == @as(u64, 11))) @as((zx_abi).zx_type_63, .Assume) else (if ((operand_8 == @as(u64, 12))) @as((zx_abi).zx_type_63, .IterationCondition) else (if ((operand_8 == @as(u64, 13))) @as((zx_abi).zx_type_63, .IterationBody) else (if ((operand_8 == @as(u64, 14))) @as((zx_abi).zx_type_63, .Transform) else @as((zx_abi).zx_type_63, .Invalid))))))))))))))));
    };

    return block_7: {
        const operand_1 = value_1;
        const operand_2 = (try function_34(allocator, in));
        const operand_3 = (try function_35(allocator, in));
        const operand_4 = (try function_36(allocator, in));

        break :block_7 block_6: {
            const operand_5 = (try (allocator).create((zx_abi).zx_type_64));

            (operand_5).* = @as((zx_abi).zx_type_64, (zx_abi).zx_type_64{ .phase = operand_1, .a = operand_2, .b = operand_3, .c = operand_4, });

            break :block_6 @as(*const (zx_abi).zx_type_64, operand_5);
        };
    };
}

fn function_83_value(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_44) error{ OutOfMemory, }!(zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 {
    @setRuntimeSafety(true);

    _ = block_27: {
        const operand_26 = in;

        break :block_27 (try function_31(allocator, operand_26));
    };

    const value_1: (zx_abi).zx_type_63 = block_25: {
        const operand_24 = block_23: {
            const operand_22 = in;

            break :block_23 (try function_33(allocator, operand_22));
        };

        break :block_25 (if ((operand_24 == @as(u64, 0))) @as((zx_abi).zx_type_63, .Block) else (if ((operand_24 == @as(u64, 1))) @as((zx_abi).zx_type_63, .BlockNext) else (if ((operand_24 == @as(u64, 2))) @as((zx_abi).zx_type_63, .Expression) else (if ((operand_24 == @as(u64, 3))) @as((zx_abi).zx_type_63, .Declare) else (if ((operand_24 == @as(u64, 4))) @as((zx_abi).zx_type_63, .ScopeDeclare) else (if ((operand_24 == @as(u64, 5))) @as((zx_abi).zx_type_63, .Destructure) else (if ((operand_24 == @as(u64, 6))) @as((zx_abi).zx_type_63, .Branch) else (if ((operand_24 == @as(u64, 7))) @as((zx_abi).zx_type_63, .BranchPost) else (if ((operand_24 == @as(u64, 8))) @as((zx_abi).zx_type_63, .Switch) else (if ((operand_24 == @as(u64, 9))) @as((zx_abi).zx_type_63, .Restore) else (if ((operand_24 == @as(u64, 10))) @as((zx_abi).zx_type_63, .RestoreFacts) else (if ((operand_24 == @as(u64, 11))) @as((zx_abi).zx_type_63, .Assume) else (if ((operand_24 == @as(u64, 12))) @as((zx_abi).zx_type_63, .IterationCondition) else (if ((operand_24 == @as(u64, 13))) @as((zx_abi).zx_type_63, .IterationBody) else (if ((operand_24 == @as(u64, 14))) @as((zx_abi).zx_type_63, .Transform) else @as((zx_abi).zx_type_63, .Invalid))))))))))))))));
    };

    return block_21: {
        const operand_10 = block_11: {
            break :block_11 value_1;
        };
        const operand_12 = block_14: {
            const operand_13 = in;

            break :block_14 (try function_34(allocator, operand_13));
        };
        const operand_15 = block_17: {
            const operand_16 = in;

            break :block_17 (try function_35(allocator, operand_16));
        };
        const operand_18 = block_20: {
            const operand_19 = in;

            break :block_20 (try function_36(allocator, operand_19));
        };

        break :block_21 @as((zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .phase = operand_10, .a = operand_12, .b = operand_15, .c = operand_18, });
    };
}

fn function_84(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_67) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_65 = ((in).program).*;

    if ((@as(u64, (((((&value_1)).body).symbols).names).len) == @as(u64, 0))) {
        return false;
    }

    _ = block_93: {
        const operand_92 = @as((zx_abi).zx_type_46, block_91: {
            const operand_89 = ((&value_1)).writer;
            const operand_90 = @as(u64, 0);

            break :block_91 .{ operand_89, operand_90, };
        });

        break :block_93 (try function_42(allocator, (&operand_92)));
    };

    _ = block_88: {
        const operand_87 = @as((zx_abi).zx_type_47, block_86: {
            const operand_83 = ((&value_1)).writer;
            const operand_84 = @as(u64, 0);
            const operand_85 = true;

            break :block_86 .{ operand_83, operand_84, operand_85, };
        });

        break :block_88 (try function_38(allocator, (&operand_87)));
    };

    const value_2: ?u32 = (((&value_1)).body).root;

    if ((value_2 != null)) {
        _ = block_82: {
            const operand_74 = ((&value_1)).writer;
            const operand_75 = @as((zx_abi).zx_type_63, .Block);
            const operand_76 = (try function_53(allocator, value_2.?));
            const operand_77 = @as(u64, 0);
            const operand_78 = @as(u64, 0);
            const operand_79 = (zx_abi).zx_type_64{ .phase = operand_75, .a = operand_76, .b = operand_77, .c = operand_78, };
            const operand_80 = (&operand_79);
            const operand_81 = (zx_abi).zx_type_75{ .writer = operand_74, .frame = operand_80, };

            break :block_82 (try function_59(allocator, (&operand_81)));
        };
    }

    const value_8: (zx_abi).zx_type_101 = block_73: {
        const operand_27 = block_26: {
            const operand_24 = in;
            const operand_25 = true;

            break :block_26 (zx_abi).zx_type_101{ .context = operand_24, .valid = operand_25, };
        };

        var state_23: (zx_abi).value_zx_type_101_764206224086badb1da5204a7f83d013e41cffd617e4e75d888ee7f948dc27df = (zx_abi).value_zx_type_101_764206224086badb1da5204a7f83d013e41cffd617e4e75d888ee7f948dc27df{ .context = (zx_abi).value_zx_type_67_5f65b2d9e9df88722a81205116d90af0a141df9477ec1782450f762a068fd184{ .prepared = (zx_abi).value_zx_type_66_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .concurrent = (((operand_27).context).prepared).concurrent, .pure = (((operand_27).context).prepared).pure, .returns = (((operand_27).context).prepared).returns, .zx_origin = ((operand_27).context).prepared, }, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = (((((operand_27).context).program).body).control).block_count, .block_first = (((((operand_27).context).program).body).control).block_first, .branch_conditions = (((((operand_27).context).program).body).control).branch_conditions, .branch_no = (((((operand_27).context).program).body).control).branch_no, .branch_yes = (((((operand_27).context).program).body).control).branch_yes, .case_bodies = (((((operand_27).context).program).body).control).case_bodies, .case_values = (((((operand_27).context).program).body).control).case_values, .constant_symbols = (((((operand_27).context).program).body).control).constant_symbols, .constant_values = (((((operand_27).context).program).body).control).constant_values, .destructure_count = (((((operand_27).context).program).body).control).destructure_count, .destructure_first = (((((operand_27).context).program).body).control).destructure_first, .destructure_symbols = (((((operand_27).context).program).body).control).destructure_symbols, .destructure_values = (((((operand_27).context).program).body).control).destructure_values, .evaluations = (((((operand_27).context).program).body).control).evaluations, .parallel_count = (((((operand_27).context).program).body).control).parallel_count, .parallel_first = (((((operand_27).context).program).body).control).parallel_first, .parallel_symbols = (((((operand_27).context).program).body).control).parallel_symbols, .parallel_values = (((((operand_27).context).program).body).control).parallel_values, .results = (((((operand_27).context).program).body).control).results, .selection_count = (((((operand_27).context).program).body).control).selection_count, .selection_exhaustive = (((((operand_27).context).program).body).control).selection_exhaustive, .selection_first = (((((operand_27).context).program).body).control).selection_first, .selection_subjects = (((((operand_27).context).program).body).control).selection_subjects, .setter_slots = (((((operand_27).context).program).body).control).setter_slots, .setter_values = (((((operand_27).context).program).body).control).setter_values, .statement_kinds = (((((operand_27).context).program).body).control).statement_kinds, .statement_payloads = (((((operand_27).context).program).body).control).statement_payloads, .zx_origin = ((((operand_27).context).program).body).control, }, .expressions = ((((operand_27).context).program).body).expressions, .root = ((((operand_27).context).program).body).root, .stores = ((((operand_27).context).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((((operand_27).context).program).body).symbols).names, .ownership = (((((operand_27).context).program).body).symbols).ownership, .span_end = (((((operand_27).context).program).body).symbols).span_end, .span_start = (((((operand_27).context).program).body).symbols).span_start, .types = (((((operand_27).context).program).body).symbols).types, .zx_origin = ((((operand_27).context).program).body).symbols, }, .zx_origin = (((operand_27).context).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = ((((operand_27).context).program).functions).expressions, .native_concurrent = ((((operand_27).context).program).functions).native_concurrent, .native_modules = ((((operand_27).context).program).functions).native_modules, .stores = ((((operand_27).context).program).functions).stores, .zx_origin = (((operand_27).context).program).functions, }, .output_type = (((operand_27).context).program).output_type, .table = (((operand_27).context).program).table, .transaction = (((operand_27).context).program).transaction, .writer = (((operand_27).context).program).writer, .zx_origin = ((operand_27).context).program, }, .zx_origin = (operand_27).context, }, .valid = (operand_27).valid, .zx_origin = (&operand_27), };

        while (((state_23).valid and (block_29: {
            const operand_28 = (((state_23).context).program).writer;

            break :block_29 (try function_32(allocator, operand_28));
        } != @as(u64, 0)))) {
            state_23 = block_56: {
                const value_5: (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_55: {
                    break :block_55 (try function_83_value(allocator, (((state_23).context).program).writer));
                };
                const value_6: (zx_abi).value_zx_type_101_764206224086badb1da5204a7f83d013e41cffd617e4e75d888ee7f948dc27df = state_23;
                const value_7: (zx_abi).value_zx_type_101_764206224086badb1da5204a7f83d013e41cffd617e4e75d888ee7f948dc27df = block_54: {
                    break :block_54 @as((zx_abi).value_zx_type_101_764206224086badb1da5204a7f83d013e41cffd617e4e75d888ee7f948dc27df, (zx_abi).value_zx_type_101_764206224086badb1da5204a7f83d013e41cffd617e4e75d888ee7f948dc27df{ .context = (value_6).context, .valid = block_53: {
                        const operand_30 = (state_23).context;

                        var state_borrow_31: (zx_abi).zx_type_66 = undefined;

                        state_borrow_31 = (zx_abi).zx_type_66{ .concurrent = ((operand_30).prepared).concurrent, .pure = ((operand_30).prepared).pure, .returns = ((operand_30).prepared).returns, };

                        var state_borrow_32: (zx_abi).zx_type_17 = undefined;

                        state_borrow_32 = (zx_abi).zx_type_17{ .block_count = ((((operand_30).program).body).control).block_count, .block_first = ((((operand_30).program).body).control).block_first, .branch_conditions = ((((operand_30).program).body).control).branch_conditions, .branch_no = ((((operand_30).program).body).control).branch_no, .branch_yes = ((((operand_30).program).body).control).branch_yes, .case_bodies = ((((operand_30).program).body).control).case_bodies, .case_values = ((((operand_30).program).body).control).case_values, .constant_symbols = ((((operand_30).program).body).control).constant_symbols, .constant_values = ((((operand_30).program).body).control).constant_values, .destructure_count = ((((operand_30).program).body).control).destructure_count, .destructure_first = ((((operand_30).program).body).control).destructure_first, .destructure_symbols = ((((operand_30).program).body).control).destructure_symbols, .destructure_values = ((((operand_30).program).body).control).destructure_values, .evaluations = ((((operand_30).program).body).control).evaluations, .parallel_count = ((((operand_30).program).body).control).parallel_count, .parallel_first = ((((operand_30).program).body).control).parallel_first, .parallel_symbols = ((((operand_30).program).body).control).parallel_symbols, .parallel_values = ((((operand_30).program).body).control).parallel_values, .results = ((((operand_30).program).body).control).results, .selection_count = ((((operand_30).program).body).control).selection_count, .selection_exhaustive = ((((operand_30).program).body).control).selection_exhaustive, .selection_first = ((((operand_30).program).body).control).selection_first, .selection_subjects = ((((operand_30).program).body).control).selection_subjects, .setter_slots = ((((operand_30).program).body).control).setter_slots, .setter_values = ((((operand_30).program).body).control).setter_values, .statement_kinds = ((((operand_30).program).body).control).statement_kinds, .statement_payloads = ((((operand_30).program).body).control).statement_payloads, };

                        var state_borrow_33: (zx_abi).zx_type_60 = undefined;

                        state_borrow_33 = (zx_abi).zx_type_60{ .names = ((((operand_30).program).body).symbols).names, .ownership = ((((operand_30).program).body).symbols).ownership, .span_end = ((((operand_30).program).body).symbols).span_end, .span_start = ((((operand_30).program).body).symbols).span_start, .types = ((((operand_30).program).body).symbols).types, };

                        var state_borrow_34: (zx_abi).zx_type_61 = undefined;

                        state_borrow_34 = (zx_abi).zx_type_61{ .control = (((((operand_30).program).body).control).zx_origin orelse (&state_borrow_32)), .expressions = (((operand_30).program).body).expressions, .root = (((operand_30).program).body).root, .stores = (((operand_30).program).body).stores, .symbols = (((((operand_30).program).body).symbols).zx_origin orelse (&state_borrow_33)), };

                        var state_borrow_35: (zx_abi).zx_type_41 = undefined;

                        state_borrow_35 = (zx_abi).zx_type_41{ .expressions = (((operand_30).program).functions).expressions, .native_concurrent = (((operand_30).program).functions).native_concurrent, .native_modules = (((operand_30).program).functions).native_modules, .stores = (((operand_30).program).functions).stores, };

                        var state_borrow_36: (zx_abi).zx_type_65 = undefined;

                        state_borrow_36 = (zx_abi).zx_type_65{ .body = ((((operand_30).program).body).zx_origin orelse (&state_borrow_34)), .functions = ((((operand_30).program).functions).zx_origin orelse (&state_borrow_35)), .output_type = ((operand_30).program).output_type, .table = ((operand_30).program).table, .transaction = ((operand_30).program).transaction, .writer = ((operand_30).program).writer, };

                        var state_borrow_37: (zx_abi).zx_type_67 = undefined;

                        state_borrow_37 = (zx_abi).zx_type_67{ .prepared = (((operand_30).prepared).zx_origin orelse (&state_borrow_31)), .program = (((operand_30).program).zx_origin orelse (&state_borrow_36)), };

                        const operand_38 = ((operand_30).zx_origin orelse (&state_borrow_37));
                        const operand_39 = value_5;

                        var state_borrow_40: (zx_abi).zx_type_64 = undefined;

                        state_borrow_40 = (zx_abi).zx_type_64{ .a = (operand_39).a, .b = (operand_39).b, .c = (operand_39).c, .phase = (operand_39).phase, };

                        const operand_41 = ((operand_39).zx_origin orelse (&state_borrow_40));
                        const operand_42 = (zx_abi).value_zx_type_67_5f65b2d9e9df88722a81205116d90af0a141df9477ec1782450f762a068fd184{ .prepared = (zx_abi).value_zx_type_66_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292{ .concurrent = ((operand_38).prepared).concurrent, .pure = ((operand_38).prepared).pure, .returns = ((operand_38).prepared).returns, .zx_origin = (operand_38).prepared, }, .program = (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = ((((operand_38).program).body).control).block_count, .block_first = ((((operand_38).program).body).control).block_first, .branch_conditions = ((((operand_38).program).body).control).branch_conditions, .branch_no = ((((operand_38).program).body).control).branch_no, .branch_yes = ((((operand_38).program).body).control).branch_yes, .case_bodies = ((((operand_38).program).body).control).case_bodies, .case_values = ((((operand_38).program).body).control).case_values, .constant_symbols = ((((operand_38).program).body).control).constant_symbols, .constant_values = ((((operand_38).program).body).control).constant_values, .destructure_count = ((((operand_38).program).body).control).destructure_count, .destructure_first = ((((operand_38).program).body).control).destructure_first, .destructure_symbols = ((((operand_38).program).body).control).destructure_symbols, .destructure_values = ((((operand_38).program).body).control).destructure_values, .evaluations = ((((operand_38).program).body).control).evaluations, .parallel_count = ((((operand_38).program).body).control).parallel_count, .parallel_first = ((((operand_38).program).body).control).parallel_first, .parallel_symbols = ((((operand_38).program).body).control).parallel_symbols, .parallel_values = ((((operand_38).program).body).control).parallel_values, .results = ((((operand_38).program).body).control).results, .selection_count = ((((operand_38).program).body).control).selection_count, .selection_exhaustive = ((((operand_38).program).body).control).selection_exhaustive, .selection_first = ((((operand_38).program).body).control).selection_first, .selection_subjects = ((((operand_38).program).body).control).selection_subjects, .setter_slots = ((((operand_38).program).body).control).setter_slots, .setter_values = ((((operand_38).program).body).control).setter_values, .statement_kinds = ((((operand_38).program).body).control).statement_kinds, .statement_payloads = ((((operand_38).program).body).control).statement_payloads, .zx_origin = (((operand_38).program).body).control, }, .expressions = (((operand_38).program).body).expressions, .root = (((operand_38).program).body).root, .stores = (((operand_38).program).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((((operand_38).program).body).symbols).names, .ownership = ((((operand_38).program).body).symbols).ownership, .span_end = ((((operand_38).program).body).symbols).span_end, .span_start = ((((operand_38).program).body).symbols).span_start, .types = ((((operand_38).program).body).symbols).types, .zx_origin = (((operand_38).program).body).symbols, }, .zx_origin = ((operand_38).program).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = (((operand_38).program).functions).expressions, .native_concurrent = (((operand_38).program).functions).native_concurrent, .native_modules = (((operand_38).program).functions).native_modules, .stores = (((operand_38).program).functions).stores, .zx_origin = ((operand_38).program).functions, }, .output_type = ((operand_38).program).output_type, .table = ((operand_38).program).table, .transaction = ((operand_38).program).transaction, .writer = ((operand_38).program).writer, .zx_origin = (operand_38).program, }, .zx_origin = operand_38, };

                        var state_borrow_43: (zx_abi).zx_type_66 = undefined;

                        state_borrow_43 = (zx_abi).zx_type_66{ .concurrent = ((operand_42).prepared).concurrent, .pure = ((operand_42).prepared).pure, .returns = ((operand_42).prepared).returns, };

                        var state_borrow_44: (zx_abi).zx_type_17 = undefined;

                        state_borrow_44 = (zx_abi).zx_type_17{ .block_count = ((((operand_42).program).body).control).block_count, .block_first = ((((operand_42).program).body).control).block_first, .branch_conditions = ((((operand_42).program).body).control).branch_conditions, .branch_no = ((((operand_42).program).body).control).branch_no, .branch_yes = ((((operand_42).program).body).control).branch_yes, .case_bodies = ((((operand_42).program).body).control).case_bodies, .case_values = ((((operand_42).program).body).control).case_values, .constant_symbols = ((((operand_42).program).body).control).constant_symbols, .constant_values = ((((operand_42).program).body).control).constant_values, .destructure_count = ((((operand_42).program).body).control).destructure_count, .destructure_first = ((((operand_42).program).body).control).destructure_first, .destructure_symbols = ((((operand_42).program).body).control).destructure_symbols, .destructure_values = ((((operand_42).program).body).control).destructure_values, .evaluations = ((((operand_42).program).body).control).evaluations, .parallel_count = ((((operand_42).program).body).control).parallel_count, .parallel_first = ((((operand_42).program).body).control).parallel_first, .parallel_symbols = ((((operand_42).program).body).control).parallel_symbols, .parallel_values = ((((operand_42).program).body).control).parallel_values, .results = ((((operand_42).program).body).control).results, .selection_count = ((((operand_42).program).body).control).selection_count, .selection_exhaustive = ((((operand_42).program).body).control).selection_exhaustive, .selection_first = ((((operand_42).program).body).control).selection_first, .selection_subjects = ((((operand_42).program).body).control).selection_subjects, .setter_slots = ((((operand_42).program).body).control).setter_slots, .setter_values = ((((operand_42).program).body).control).setter_values, .statement_kinds = ((((operand_42).program).body).control).statement_kinds, .statement_payloads = ((((operand_42).program).body).control).statement_payloads, };

                        var state_borrow_45: (zx_abi).zx_type_60 = undefined;

                        state_borrow_45 = (zx_abi).zx_type_60{ .names = ((((operand_42).program).body).symbols).names, .ownership = ((((operand_42).program).body).symbols).ownership, .span_end = ((((operand_42).program).body).symbols).span_end, .span_start = ((((operand_42).program).body).symbols).span_start, .types = ((((operand_42).program).body).symbols).types, };

                        var state_borrow_46: (zx_abi).zx_type_61 = undefined;

                        state_borrow_46 = (zx_abi).zx_type_61{ .control = (((((operand_42).program).body).control).zx_origin orelse (&state_borrow_44)), .expressions = (((operand_42).program).body).expressions, .root = (((operand_42).program).body).root, .stores = (((operand_42).program).body).stores, .symbols = (((((operand_42).program).body).symbols).zx_origin orelse (&state_borrow_45)), };

                        var state_borrow_47: (zx_abi).zx_type_41 = undefined;

                        state_borrow_47 = (zx_abi).zx_type_41{ .expressions = (((operand_42).program).functions).expressions, .native_concurrent = (((operand_42).program).functions).native_concurrent, .native_modules = (((operand_42).program).functions).native_modules, .stores = (((operand_42).program).functions).stores, };

                        var state_borrow_48: (zx_abi).zx_type_65 = undefined;

                        state_borrow_48 = (zx_abi).zx_type_65{ .body = ((((operand_42).program).body).zx_origin orelse (&state_borrow_46)), .functions = ((((operand_42).program).functions).zx_origin orelse (&state_borrow_47)), .output_type = ((operand_42).program).output_type, .table = ((operand_42).program).table, .transaction = ((operand_42).program).transaction, .writer = ((operand_42).program).writer, };

                        var state_borrow_49: (zx_abi).zx_type_67 = undefined;

                        state_borrow_49 = (zx_abi).zx_type_67{ .prepared = (((operand_42).prepared).zx_origin orelse (&state_borrow_43)), .program = (((operand_42).program).zx_origin orelse (&state_borrow_48)), };

                        const operand_50 = (zx_abi).value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .a = (operand_41).a, .b = (operand_41).b, .c = (operand_41).c, .phase = (operand_41).phase, .zx_origin = operand_41, };

                        var state_borrow_51: (zx_abi).zx_type_64 = undefined;

                        state_borrow_51 = (zx_abi).zx_type_64{ .a = (operand_50).a, .b = (operand_50).b, .c = (operand_50).c, .phase = (operand_50).phase, };

                        const operand_52 = (zx_abi).zx_type_68{ .context = ((operand_42).zx_origin orelse (&state_borrow_49)), .frame = ((operand_50).zx_origin orelse (&state_borrow_51)), };

                        break :block_53 (try function_82(allocator, (&operand_52)));
                    }, });
                };

                break :block_56 value_7;
            };
        }

        break :block_73 block_72: {
            break :block_72 (if (((state_23).zx_origin != null)) ((state_23).zx_origin.?).* else block_71: {
                break :block_71 (zx_abi).zx_type_101{ .context = (if ((((state_23).context).zx_origin != null)) ((state_23).context).zx_origin.? else block_70: {
                    const operand_69 = (try (allocator).create((zx_abi).zx_type_67));

                    (operand_69).* = (zx_abi).zx_type_67{ .prepared = (if (((((state_23).context).prepared).zx_origin != null)) (((state_23).context).prepared).zx_origin.? else block_58: {
                        const operand_57 = (try (allocator).create((zx_abi).zx_type_66));

                        (operand_57).* = (zx_abi).zx_type_66{ .concurrent = (((state_23).context).prepared).concurrent, .pure = (((state_23).context).prepared).pure, .returns = (((state_23).context).prepared).returns, };

                        break :block_58 @as(*const (zx_abi).zx_type_66, operand_57);
                    }), .program = (if (((((state_23).context).program).zx_origin != null)) (((state_23).context).program).zx_origin.? else block_68: {
                        const operand_67 = (try (allocator).create((zx_abi).zx_type_65));

                        (operand_67).* = (zx_abi).zx_type_65{ .body = (if ((((((state_23).context).program).body).zx_origin != null)) ((((state_23).context).program).body).zx_origin.? else block_64: {
                            const operand_63 = (try (allocator).create((zx_abi).zx_type_61));

                            (operand_63).* = (zx_abi).zx_type_61{ .control = (if (((((((state_23).context).program).body).control).zx_origin != null)) (((((state_23).context).program).body).control).zx_origin.? else block_60: {
                                const operand_59 = (try (allocator).create((zx_abi).zx_type_17));

                                (operand_59).* = (zx_abi).zx_type_17{ .block_count = (((((state_23).context).program).body).control).block_count, .block_first = (((((state_23).context).program).body).control).block_first, .branch_conditions = (((((state_23).context).program).body).control).branch_conditions, .branch_no = (((((state_23).context).program).body).control).branch_no, .branch_yes = (((((state_23).context).program).body).control).branch_yes, .case_bodies = (((((state_23).context).program).body).control).case_bodies, .case_values = (((((state_23).context).program).body).control).case_values, .constant_symbols = (((((state_23).context).program).body).control).constant_symbols, .constant_values = (((((state_23).context).program).body).control).constant_values, .destructure_count = (((((state_23).context).program).body).control).destructure_count, .destructure_first = (((((state_23).context).program).body).control).destructure_first, .destructure_symbols = (((((state_23).context).program).body).control).destructure_symbols, .destructure_values = (((((state_23).context).program).body).control).destructure_values, .evaluations = (((((state_23).context).program).body).control).evaluations, .parallel_count = (((((state_23).context).program).body).control).parallel_count, .parallel_first = (((((state_23).context).program).body).control).parallel_first, .parallel_symbols = (((((state_23).context).program).body).control).parallel_symbols, .parallel_values = (((((state_23).context).program).body).control).parallel_values, .results = (((((state_23).context).program).body).control).results, .selection_count = (((((state_23).context).program).body).control).selection_count, .selection_exhaustive = (((((state_23).context).program).body).control).selection_exhaustive, .selection_first = (((((state_23).context).program).body).control).selection_first, .selection_subjects = (((((state_23).context).program).body).control).selection_subjects, .setter_slots = (((((state_23).context).program).body).control).setter_slots, .setter_values = (((((state_23).context).program).body).control).setter_values, .statement_kinds = (((((state_23).context).program).body).control).statement_kinds, .statement_payloads = (((((state_23).context).program).body).control).statement_payloads, };

                                break :block_60 @as(*const (zx_abi).zx_type_17, operand_59);
                            }), .expressions = ((((state_23).context).program).body).expressions, .root = ((((state_23).context).program).body).root, .stores = ((((state_23).context).program).body).stores, .symbols = (if (((((((state_23).context).program).body).symbols).zx_origin != null)) (((((state_23).context).program).body).symbols).zx_origin.? else block_62: {
                                const operand_61 = (try (allocator).create((zx_abi).zx_type_60));

                                (operand_61).* = (zx_abi).zx_type_60{ .names = (((((state_23).context).program).body).symbols).names, .ownership = (((((state_23).context).program).body).symbols).ownership, .span_end = (((((state_23).context).program).body).symbols).span_end, .span_start = (((((state_23).context).program).body).symbols).span_start, .types = (((((state_23).context).program).body).symbols).types, };

                                break :block_62 @as(*const (zx_abi).zx_type_60, operand_61);
                            }), };

                            break :block_64 @as(*const (zx_abi).zx_type_61, operand_63);
                        }), .functions = (if ((((((state_23).context).program).functions).zx_origin != null)) ((((state_23).context).program).functions).zx_origin.? else block_66: {
                            const operand_65 = (try (allocator).create((zx_abi).zx_type_41));

                            (operand_65).* = (zx_abi).zx_type_41{ .expressions = ((((state_23).context).program).functions).expressions, .native_concurrent = ((((state_23).context).program).functions).native_concurrent, .native_modules = ((((state_23).context).program).functions).native_modules, .stores = ((((state_23).context).program).functions).stores, };

                            break :block_66 @as(*const (zx_abi).zx_type_41, operand_65);
                        }), .output_type = (((state_23).context).program).output_type, .table = (((state_23).context).program).table, .transaction = (((state_23).context).program).transaction, .writer = (((state_23).context).program).writer, };

                        break :block_68 @as(*const (zx_abi).zx_type_65, operand_67);
                    }), };

                    break :block_70 @as(*const (zx_abi).zx_type_67, operand_69);
                }), .valid = (state_23).valid, };
            });
        };
    };

    if ((!((&value_8)).valid)) {
        return false;
    }

    const value_16: (zx_abi).zx_type_102 = block_22: {
        const operand_10 = block_9: {
            const operand_5 = ((&value_1)).writer;
            const operand_6 = @as(u64, 0);
            const operand_7 = @as(u64, (((((&value_1)).body).symbols).names).len);
            const operand_8 = true;

            break :block_9 (zx_abi).zx_type_102{ .writer = operand_5, .index = operand_6, .count = operand_7, .valid = operand_8, };
        };

        var state_4: (zx_abi).value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = (zx_abi).value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (operand_10).count, .index = (operand_10).index, .valid = (operand_10).valid, .writer = (operand_10).writer, .zx_origin = (&operand_10), };

        while (((state_4).valid and ((state_4).index < (state_4).count))) {
            state_4 = block_19: {
                const value_11: (zx_abi).value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = state_4;
                const value_12: (zx_abi).value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_18: {
                    break :block_18 @as((zx_abi).value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (value_11).count, .index = (value_11).index, .valid = block_17: {
                        const operand_16 = @as((zx_abi).zx_type_46, block_15: {
                            const operand_13 = (state_4).writer;
                            const operand_14 = (state_4).index;

                            break :block_15 .{ operand_13, operand_14, };
                        });

                        break :block_17 (try function_41(allocator, (&operand_16)));
                    }, .writer = (value_11).writer, });
                };
                const value_13: (zx_abi).value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = value_12;
                const value_14: u64 = (value_13).index;
                const value_15: (zx_abi).value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = block_12: {
                    break :block_12 @as((zx_abi).value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165, (zx_abi).value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .count = (value_13).count, .index = (block_11: {
                        break :block_11 value_14;
                    } + @as(u64, 1)), .valid = (value_13).valid, .writer = (value_13).writer, });
                };

                break :block_19 value_15;
            };
        }

        break :block_22 block_21: {
            break :block_21 (if (((state_4).zx_origin != null)) ((state_4).zx_origin.?).* else block_20: {
                break :block_20 (zx_abi).zx_type_102{ .count = (state_4).count, .index = (state_4).index, .valid = (state_4).valid, .writer = (state_4).writer, };
            });
        };
    };

    return (((&value_16)).valid and ((((&value_1)).output_type == @as(u32, 0)) or ((value_2 != null) and block_3: {
        const operand_1 = ((in).prepared).returns;
        const operand_2 = (try function_53(allocator, value_2.?));

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    })));
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_65) error{ IndexOutOfBounds, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: (zx_abi).zx_type_66 = block_8: {
        const operand_5 = in;
        const operand_6 = (try function_29_value(allocator, (zx_abi).value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f{ .body = (zx_abi).value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640{ .control = (zx_abi).value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6{ .block_count = (((operand_5).body).control).block_count, .block_first = (((operand_5).body).control).block_first, .branch_conditions = (((operand_5).body).control).branch_conditions, .branch_no = (((operand_5).body).control).branch_no, .branch_yes = (((operand_5).body).control).branch_yes, .case_bodies = (((operand_5).body).control).case_bodies, .case_values = (((operand_5).body).control).case_values, .constant_symbols = (((operand_5).body).control).constant_symbols, .constant_values = (((operand_5).body).control).constant_values, .destructure_count = (((operand_5).body).control).destructure_count, .destructure_first = (((operand_5).body).control).destructure_first, .destructure_symbols = (((operand_5).body).control).destructure_symbols, .destructure_values = (((operand_5).body).control).destructure_values, .evaluations = (((operand_5).body).control).evaluations, .parallel_count = (((operand_5).body).control).parallel_count, .parallel_first = (((operand_5).body).control).parallel_first, .parallel_symbols = (((operand_5).body).control).parallel_symbols, .parallel_values = (((operand_5).body).control).parallel_values, .results = (((operand_5).body).control).results, .selection_count = (((operand_5).body).control).selection_count, .selection_exhaustive = (((operand_5).body).control).selection_exhaustive, .selection_first = (((operand_5).body).control).selection_first, .selection_subjects = (((operand_5).body).control).selection_subjects, .setter_slots = (((operand_5).body).control).setter_slots, .setter_values = (((operand_5).body).control).setter_values, .statement_kinds = (((operand_5).body).control).statement_kinds, .statement_payloads = (((operand_5).body).control).statement_payloads, .zx_origin = ((operand_5).body).control, }, .expressions = ((operand_5).body).expressions, .root = ((operand_5).body).root, .stores = ((operand_5).body).stores, .symbols = (zx_abi).value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = (((operand_5).body).symbols).names, .ownership = (((operand_5).body).symbols).ownership, .span_end = (((operand_5).body).symbols).span_end, .span_start = (((operand_5).body).symbols).span_start, .types = (((operand_5).body).symbols).types, .zx_origin = ((operand_5).body).symbols, }, .zx_origin = (operand_5).body, }, .functions = (zx_abi).value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165{ .expressions = ((operand_5).functions).expressions, .native_concurrent = ((operand_5).functions).native_concurrent, .native_modules = ((operand_5).functions).native_modules, .stores = ((operand_5).functions).stores, .zx_origin = (operand_5).functions, }, .output_type = (operand_5).output_type, .table = (operand_5).table, .transaction = (operand_5).transaction, .writer = (operand_5).writer, .zx_origin = operand_5, }));

        break :block_8 (if (((operand_6).zx_origin != null)) ((operand_6).zx_origin.?).* else block_7: {
            break :block_7 (zx_abi).zx_type_66{ .concurrent = (operand_6).concurrent, .pure = (operand_6).pure, .returns = (operand_6).returns, };
        });
    };
    const value_2: bool = block_4: {
        const operand_1 = in;
        const operand_2 = (&value_1);
        const operand_3 = (zx_abi).zx_type_67{ .program = operand_1, .prepared = operand_2, };

        break :block_4 (try function_84(allocator, (&operand_3)));
    };

    return value_2;
}

