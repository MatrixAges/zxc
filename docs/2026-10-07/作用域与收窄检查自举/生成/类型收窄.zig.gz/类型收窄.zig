const std = @import("std");

const zx_native_0 = @import("flow_state");

const zx_native_1 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .native_reference, };

const zx_shape_12 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_5, .@"2" = zx_shape_5, .@"3" = zx_shape_5, .@"4" = zx_shape_5, }, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_5, }, };

const zx_shape_14 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_5, .@"2" = zx_shape_1, }, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_11, .@"1" = zx_shape_5, .@"2" = zx_shape_5, }, };

const zx_shape_16 = .{ .kind = .scalar, };

const zx_shape_17 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_18 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_19 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .children = zx_shape_18, .field_names = zx_shape_19, .field_types = zx_shape_18, .first = zx_shape_18, .kinds = zx_shape_17, .labels = zx_shape_19, .names = zx_shape_19, .second = zx_shape_18, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .base = zx_shape_20, .delta = zx_shape_20, }, };

const zx_shape_22 = .{ .kind = .object, .fields = .{ .delta = zx_shape_1, .first = zx_shape_4, .kind = zx_shape_16, .label = zx_shape_10, .second = zx_shape_4, }, };

const zx_shape_23 = .{ .kind = .object, .fields = .{ .names = zx_shape_19, .types = zx_shape_18, }, };

const zx_shape_24 = .{ .kind = .object, .fields = .{ .children = zx_shape_18, .fields = zx_shape_23, .first = zx_shape_4, .kind = zx_shape_16, .label = zx_shape_10, .names = zx_shape_19, .second = zx_shape_4, }, };

const zx_shape_25 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .id = zx_shape_4, }, };

const zx_shape_26 = .{ .kind = .object, .fields = .{ .delta = zx_shape_20, .id = zx_shape_4, }, };

const zx_shape_27 = .{ .kind = .object, .fields = .{ .symbol = zx_shape_5, .table = zx_shape_20, .type_id = zx_shape_4, .writer = zx_shape_11, }, };

const zx_shape_28 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_27, }, };

const zx_shape_29 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_27, .@"1" = zx_shape_4, }, };

pub const input_shape = zx_shape_27;

pub const output_shape = zx_shape_4;

pub const Input = *const (zx_abi).zx_type_27;

pub const Output = u32;

fn function_0(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_12) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_0).push((in).@"0", (in).@"1", (in).@"2", (in).@"3", (in).@"4"));

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!void {
    const native_result = (zx_native_0).pop(in);

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).eventCount(in);

    _ = allocator;

    return native_result;
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).eventKind(in);

    _ = allocator;

    return native_result;
}

fn function_4(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).eventA(in);

    _ = allocator;

    return native_result;
}

fn function_5(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).eventB(in);

    _ = allocator;

    return native_result;
}

fn function_6(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).eventC(in);

    _ = allocator;

    return native_result;
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!bool {
    const native_result = (zx_native_0).active((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_14) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_0).setActive((in).@"0", (in).@"1", (in).@"2"));

    _ = allocator;

    return native_result;
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).activeMark(in);

    _ = allocator;

    return native_result;
}

fn function_10(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!void {
    const native_result = (zx_native_0).restoreActive((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_11(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!bool {
    const native_result = (zx_native_0).declared((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_12(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!void {
    const native_result = (zx_native_0).setDeclared((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_13(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!u64 {
    const native_result = (zx_native_0).owner((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_14(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_15) error{ }!void {
    const native_result = (zx_native_0).setOwner((in).@"0", (in).@"1", (in).@"2");

    _ = allocator;

    return native_result;
}

fn function_15(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).factMark(in);

    _ = allocator;

    return native_result;
}

fn function_16(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_11) error{ }!u64 {
    const native_result = (zx_native_0).captureMark(in);

    _ = allocator;

    return native_result;
}

fn function_17(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_15) error{ }!void {
    const native_result = (zx_native_0).restoreFacts((in).@"0", (in).@"1", (in).@"2");

    _ = allocator;

    return native_result;
}

fn function_18(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!bool {
    const native_result = (zx_native_0).contains((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_19(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_0).appendFact((in).@"0", (in).@"1"));

    _ = allocator;

    return native_result;
}

fn function_20(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_15) error{ OutOfMemory, }!void {
    const native_result = (try (zx_native_0).appendCapture((in).@"0", (in).@"1", (in).@"2"));

    _ = allocator;

    return native_result;
}

fn function_21(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!u64 {
    const native_result = (zx_native_0).captureError((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_22(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_13) error{ }!u64 {
    const native_result = (zx_native_0).captureResult((in).@"0", (in).@"1");

    _ = allocator;

    return native_result;
}

fn function_23(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_1).widen(in);

    _ = allocator;

    return native_result;
}

fn function_24(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_1).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_25(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_16 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_2: {
        const operand_1 = in;

        break :block_2 (if ((operand_1 == @as(u8, 0))) @as((zx_abi).zx_type_16, .Scalar) else (if ((operand_1 == @as(u8, 1))) @as((zx_abi).zx_type_16, .Object) else (if ((operand_1 == @as(u8, 2))) @as((zx_abi).zx_type_16, .Optional) else (if ((operand_1 == @as(u8, 3))) @as((zx_abi).zx_type_16, .List) else (if ((operand_1 == @as(u8, 4))) @as((zx_abi).zx_type_16, .Tuple) else (if ((operand_1 == @as(u8, 5))) @as((zx_abi).zx_type_16, .ErrorSet) else (if ((operand_1 == @as(u8, 6))) @as((zx_abi).zx_type_16, .Task) else (if ((operand_1 == @as(u8, 7))) @as((zx_abi).zx_type_16, .Enumeration) else @as((zx_abi).zx_type_16, .NativeReference)))))))));
    };
}

fn function_26(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_27) error{ IndexOutOfBounds, OutOfMemory, }!u32 {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_23(allocator, (in).type_id));

    return (if ((((try function_25(allocator, block_3: {
        const operand_1 = ((in).table).kinds;
        const operand_2 = value_1;

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    })) == @as((zx_abi).zx_type_16, .Optional)) and block_8: {
        const operand_7 = @as((zx_abi).zx_type_13, block_6: {
            const operand_4 = (in).writer;
            const operand_5 = (in).symbol;

            break :block_6 .{ operand_4, operand_5, };
        });

        break :block_8 (try function_18(allocator, (&operand_7)));
    })) block_11: {
        const operand_9 = ((in).table).first;
        const operand_10 = value_1;

        if ((operand_10 >= (operand_9).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_11 (operand_9)[@intCast(operand_10)];
    } else (in).type_id);
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_27) error{ IndexOutOfBounds, OutOfMemory, }!u32 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: u32 = (try function_26(allocator, in));

    return value_1;
}

