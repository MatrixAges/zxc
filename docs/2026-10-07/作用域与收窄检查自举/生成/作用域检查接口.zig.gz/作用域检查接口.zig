pub const zx_type_11 = enum { Evaluate, Constant, Parallel, Destructure, Branch, Switch, StoreSet, Result, };

pub const zx_type_17 = struct {
    block_count: []const u32,
    block_first: []const u32,
    branch_conditions: []const u32,
    branch_no: []const u32,
    branch_yes: []const u32,
    case_bodies: []const u32,
    case_values: []const ?u32,
    constant_symbols: []const u32,
    constant_values: []const u32,
    destructure_count: []const u32,
    destructure_first: []const u32,
    destructure_symbols: []const ?u32,
    destructure_values: []const u32,
    evaluations: []const u32,
    parallel_count: []const u32,
    parallel_first: []const u32,
    parallel_symbols: []const ?u32,
    parallel_values: []const u32,
    results: []const ?u32,
    selection_count: []const u32,
    selection_exhaustive: []const bool,
    selection_first: []const u32,
    selection_subjects: []const u32,
    setter_slots: []const u32,
    setter_values: []const u32,
    statement_kinds: []const zx_type_11,
    statement_payloads: []const u32,
};

pub const zx_type_18 = struct {
    control: *const zx_type_17,
    returns: []const bool,
    selection: u64,
};

pub const zx_type_19 = struct {
    all: bool,
    bodies: []const u32,
    end: u64,
    index: u64,
    returns: []const bool,
};

pub const zx_type_20 = struct {
    block: u64,
    control: *const zx_type_17,
    returns: []const bool,
};

pub const zx_type_21 = struct { []const bool, void, };

pub const zx_type_22 = enum { Integer, NegativeInteger, Float, String, Boolean, None, Unit, Some, Capture, Task, AwaitTask, CancelTask, Parallel, OptionalValue, EnumValue, ErrorValue, Reference, StoreGet, Field, Index, Length, List, Tuple, TupleField, Template, ListOperation, Transform, Scope, Iteration, ListUpdate, Call, Unary, Binary, Conditional, Match, Object, };

pub const zx_type_23 = enum { Push, Pop, Sort, Reverse, Splice, Concat, };

pub const zx_type_24 = enum { Map, Filter, Reduce, Every, Some, };

pub const zx_type_25 = enum { Negate, Not, };

pub const zx_type_26 = enum { Coalesce, Add, Subtract, Multiply, Divide, Remainder, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, };

pub const zx_type_35 = struct {
    awaits: []const u32,
    binary_left: []const u32,
    binary_operators: []const zx_type_26,
    binary_right: []const u32,
    booleans: []const bool,
    call_arguments: []const u32,
    call_functions: []const u32,
    call_store_count: []const u32,
    call_store_first: []const u32,
    call_stores: []const u32,
    cancellations: []const u32,
    captures: []const u32,
    collection_arguments: []const u32,
    collection_count: []const u32,
    collection_first: []const u32,
    collection_kinds: []const zx_type_23,
    collection_targets: []const u32,
    conditional_conditions: []const u32,
    conditional_no: []const u32,
    conditional_yes: []const u32,
    enumerations: []const u32,
    errors: []const u32,
    floats: []const f64,
    index_targets: []const u32,
    index_values: []const u32,
    integers: []const u64,
    iteration_bodies: []const u32,
    iteration_condition_parameters: []const u32,
    iteration_conditions: []const u32,
    iteration_initials: []const u32,
    iteration_parameters: []const u32,
    iteration_postconditions: []const bool,
    kinds: []const zx_type_22,
    lengths: []const u32,
    match_conditions: []const u32,
    match_count: []const u32,
    match_fallbacks: []const u32,
    match_first: []const u32,
    match_results: []const u32,
    match_subjects: []const ?u32,
    negative_integers: []const u64,
    object_count: []const u32,
    object_evaluation_count: []const u32,
    object_evaluation_first: []const u32,
    object_evaluation_values: []const u32,
    object_field_indices: []const u32,
    object_field_values: []const u32,
    object_first: []const u32,
    optional_values: []const u32,
    parallel_count: []const u32,
    parallel_fields: []const ?u32,
    parallel_first: []const u32,
    parallel_tasks: []const u32,
    payloads: []const u32,
    projection_indices: []const u32,
    projection_targets: []const u32,
    references: []const u32,
    scope_borrows: []const bool,
    scope_count: []const u32,
    scope_first: []const u32,
    scope_results: []const u32,
    scope_symbols: []const ?u32,
    scope_values: []const u32,
    sequence_count: []const u32,
    sequence_first: []const u32,
    sequence_items: []const u32,
    some: []const u32,
    span_end: []const u64,
    span_start: []const u64,
    stores: []const u32,
    strings: []const []const u8,
    task_bodies: []const u32,
    task_capture_count: []const u32,
    task_capture_first: []const u32,
    task_captures: []const u32,
    transform_bodies: []const u32,
    transform_count: []const u32,
    transform_first: []const u32,
    transform_initials: []const ?u32,
    transform_kinds: []const zx_type_24,
    transform_parameters: []const u32,
    transform_targets: []const u32,
    types: []const u32,
    unary_operands: []const u32,
    unary_operators: []const zx_type_25,
    update_indices: []const u32,
    update_targets: []const u32,
    update_values: []const u32,
};

pub const zx_type_36 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_35,
    limit: u64,
};

pub const zx_type_37 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_35,
    index: u64,
    limit: u64,
    valid: bool,
};

pub const zx_type_38 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_41 = struct {
    expressions: []const *const zx_type_35,
    native_concurrent: []const bool,
    native_modules: []const ?u32,
    stores: []const *const zx_type_38,
};

pub const zx_type_42 = struct {
    concurrent: bool,
    functions: *const zx_type_41,
};

pub const zx_type_43 = struct {
    concurrent: bool,
    functions: *const zx_type_41,
    index: u64,
    values: []const bool,
};

pub const zx_type_44 = opaque {};

pub const zx_type_45 = struct { *const zx_type_44, u64, u64, u64, u64, };

pub const zx_type_46 = struct { *const zx_type_44, u64, };

pub const zx_type_47 = struct { *const zx_type_44, u64, bool, };

pub const zx_type_48 = struct { *const zx_type_44, u64, u64, };

pub const zx_type_49 = enum { Scalar, Object, Optional, List, Tuple, ErrorSet, Task, Enumeration, NativeReference, };

pub const zx_type_51 = struct {
    children: []const u32,
    field_names: []const []const u8,
    field_types: []const u32,
    first: []const u32,
    kinds: []const u8,
    labels: []const []const u8,
    names: []const []const u8,
    second: []const u32,
};

pub const zx_type_52 = struct {
    base: *const zx_type_51,
    delta: *const zx_type_51,
};

pub const zx_type_53 = struct {
    delta: bool,
    first: u32,
    kind: zx_type_49,
    label: []const u8,
    second: u32,
};

pub const zx_type_54 = struct {
    names: []const []const u8,
    types: []const u32,
};

pub const zx_type_55 = struct {
    children: []const u32,
    fields: *const zx_type_54,
    first: u32,
    kind: zx_type_49,
    label: []const u8,
    names: []const []const u8,
    second: u32,
};

pub const zx_type_56 = struct {
    found: bool,
    id: u32,
};

pub const zx_type_57 = struct {
    delta: *const zx_type_51,
    id: u32,
};

pub const zx_type_58 = enum { Copy, Borrowed, Owned, };

pub const zx_type_60 = struct {
    names: []const []const u8,
    ownership: []const zx_type_58,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
};

pub const zx_type_61 = struct {
    control: *const zx_type_17,
    expressions: *const zx_type_35,
    root: ?u32,
    stores: *const zx_type_38,
    symbols: *const zx_type_60,
};

pub const zx_type_62 = struct {
    expressions: *const zx_type_35,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: *const zx_type_60,
};

pub const zx_type_63 = enum { Block, BlockNext, Expression, Declare, ScopeDeclare, Destructure, Branch, BranchPost, Switch, Restore, RestoreFacts, Assume, IterationCondition, IterationBody, Transform, Invalid, };

pub const zx_type_64 = struct {
    a: u64,
    b: u64,
    c: u64,
    phase: zx_type_63,
};

pub const zx_type_65 = struct {
    body: *const zx_type_61,
    functions: *const zx_type_41,
    output_type: u32,
    table: *const zx_type_51,
    transaction: bool,
    writer: *const zx_type_44,
};

pub const zx_type_66 = struct {
    concurrent: []const bool,
    pure: []const bool,
    returns: []const bool,
};

pub const zx_type_67 = struct {
    prepared: *const zx_type_66,
    program: *const zx_type_65,
};

pub const zx_type_68 = struct {
    context: *const zx_type_67,
    frame: *const zx_type_64,
};

pub const zx_type_69 = enum { Ordinary, Scope, Callback, };

pub const zx_type_70 = struct {
    expressions: *const zx_type_35,
    payload: u64,
    truth: bool,
    writer: *const zx_type_44,
};

pub const zx_type_71 = struct {
    count: u64,
    index: u64,
    symbol: u64,
    writer: *const zx_type_44,
};

pub const zx_type_72 = struct {
    condition: u64,
    expressions: *const zx_type_35,
    truth: bool,
    writer: *const zx_type_44,
};

pub const zx_type_73 = struct {
    expressions: *const zx_type_35,
    mark: u64,
    writer: *const zx_type_44,
};

pub const zx_type_74 = struct {
    context: *const zx_type_67,
    statement: u64,
};

pub const zx_type_75 = struct {
    frame: *const zx_type_64,
    writer: *const zx_type_44,
};

pub const zx_type_76 = struct {
    first: u64,
    index: u64,
    program: *const zx_type_65,
};

pub const zx_type_77 = struct {
    context: *const zx_type_67,
    first: u64,
    index: u64,
    valid: bool,
};

pub const zx_type_78 = struct {
    count: u64,
    index: u64,
    writer: *const zx_type_44,
};

pub const zx_type_79 = struct {
    mode: zx_type_69,
    owner: u64,
    program: *const zx_type_65,
    symbol: u64,
    type_id: u32,
};

pub const zx_type_80 = struct {
    count: u64,
    first: u64,
    index: u64,
    owner: u64,
    program: *const zx_type_65,
    valid: bool,
};

pub const zx_type_81 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_35,
    result: ?u32,
    value: u64,
    writer: *const zx_type_44,
};

pub const zx_type_82 = struct {
    count: u64,
    first: u64,
    index: u64,
    program: *const zx_type_65,
    type_first: u64,
    valid: bool,
};

pub const zx_type_83 = struct {
    count: u64,
    depth: u64,
    first: u64,
    flags: u64,
    values: []const u32,
    writer: *const zx_type_44,
};

pub const zx_type_84 = struct {
    index: u64,
    input: *const zx_type_83,
};

pub const zx_type_85 = struct {
    depth: u64,
    first: u64,
    flags: u64,
    index: u64,
    program: *const zx_type_65,
};

pub const zx_type_86 = struct {
    count: u64,
    expressions: *const zx_type_35,
    first: u64,
    writer: *const zx_type_44,
};

pub const zx_type_87 = struct {
    index: u64,
    input: *const zx_type_86,
};

pub const zx_type_88 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_35,
    first: u64,
    index: u64,
    result: ?u32,
    symbol: u32,
};

pub const zx_type_89 = struct {
    depth: u64,
    first: u64,
    flags: u64,
    index: u64,
    owner: u64,
    program: *const zx_type_65,
};

pub const zx_type_90 = struct {
    count: u64,
    first: u64,
    index: u64,
    program: *const zx_type_65,
    valid: bool,
};

pub const zx_type_91 = struct {
    count: u64,
    first: u64,
    index: u64,
    program: *const zx_type_65,
};

pub const zx_type_92 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_38,
};

pub const zx_type_93 = struct {
    expressions: *const zx_type_35,
    functions: *const zx_type_92,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_38,
    symbols: *const zx_type_60,
    table: *const zx_type_51,
};

pub const zx_type_94 = struct {
    context: *const zx_type_93,
    kind: zx_type_22,
    payload: u64,
    target: zx_type_49,
    type_id: u32,
};

pub const zx_type_95 = enum { Other, Integer, Signed, Float, };

pub const zx_type_96 = struct {
    expressions: *const zx_type_35,
    left: u64,
    right: u64,
};

pub const zx_type_97 = struct {
    payload: u64,
    program: *const zx_type_65,
};

pub const zx_type_98 = struct {
    count: u64,
    first: u64,
    has_default: bool,
    index: u64,
    program: *const zx_type_65,
    type_id: u32,
    valid: bool,
};

pub const zx_type_99 = struct {
    count: u64,
    first: u64,
    found: bool,
    index: u64,
    program: *const zx_type_65,
    value: u64,
};

pub const zx_type_100 = struct {
    depth: u64,
    first: u64,
    index: u64,
    program: *const zx_type_65,
};

pub const zx_type_101 = struct {
    context: *const zx_type_67,
    valid: bool,
};

pub const zx_type_102 = struct {
    count: u64,
    index: u64,
    valid: bool,
    writer: *const zx_type_44,
};

pub const zx_type_103 = struct { *const zx_type_65, };

pub const zx_type_104 = struct { *const zx_type_65, *const zx_type_66, };

pub const zx_type_105 = struct { *const zx_type_65, *const zx_type_66, bool, };

pub const value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6 = struct {
    block_count: []const u32,
    block_first: []const u32,
    branch_conditions: []const u32,
    branch_no: []const u32,
    branch_yes: []const u32,
    case_bodies: []const u32,
    case_values: []const ?u32,
    constant_symbols: []const u32,
    constant_values: []const u32,
    destructure_count: []const u32,
    destructure_first: []const u32,
    destructure_symbols: []const ?u32,
    destructure_values: []const u32,
    evaluations: []const u32,
    parallel_count: []const u32,
    parallel_first: []const u32,
    parallel_symbols: []const ?u32,
    parallel_values: []const u32,
    results: []const ?u32,
    selection_count: []const u32,
    selection_exhaustive: []const bool,
    selection_first: []const u32,
    selection_subjects: []const u32,
    setter_slots: []const u32,
    setter_values: []const u32,
    statement_kinds: []const zx_type_11,
    statement_payloads: []const u32,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_1d4617f2ee94b6ee6d7812fc3b855bb1a79abb755006e29d39c80817124613cf = struct {
    control: value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6,
    returns: []const bool,
    selection: u64,
    zx_origin: ?*const zx_type_18 = null,
};

pub const value_zx_type_19_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    all: bool,
    bodies: []const u32,
    end: u64,
    index: u64,
    returns: []const bool,
    zx_origin: ?*const zx_type_19 = null,
};

pub const value_zx_type_20_be9aceeda86ce7b31325b3ce00f596eb94f3ab60d8780a5c18400d8b002c8b2d = struct {
    block: u64,
    control: value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6,
    returns: []const bool,
    zx_origin: ?*const zx_type_20 = null,
};

pub const value_zx_type_21_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct { []const bool, void, ?*const zx_type_21, };

pub const value_zx_type_36_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_35,
    limit: u64,
    zx_origin: ?*const zx_type_36 = null,
};

pub const value_zx_type_37_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    allowed: []const bool,
    concurrent: bool,
    expressions: *const zx_type_35,
    index: u64,
    limit: u64,
    valid: bool,
    zx_origin: ?*const zx_type_37 = null,
};

pub const value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: []const *const zx_type_35,
    native_concurrent: []const bool,
    native_modules: []const ?u32,
    stores: []const *const zx_type_38,
    zx_origin: ?*const zx_type_41 = null,
};

pub const value_zx_type_42_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = struct {
    concurrent: bool,
    functions: value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_42 = null,
};

pub const value_zx_type_43_3a2d3372119d766901b9e73d1d1a1cb69e32e364aec8da316dab97f3e55fcf11 = struct {
    concurrent: bool,
    functions: value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    index: u64,
    values: []const bool,
    zx_origin: ?*const zx_type_43 = null,
};

pub const value_zx_type_52_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    base: *const zx_type_51,
    delta: *const zx_type_51,
    zx_origin: ?*const zx_type_52 = null,
};

pub const value_zx_type_53_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    delta: bool,
    first: u32,
    kind: zx_type_49,
    label: []const u8,
    second: u32,
    zx_origin: ?*const zx_type_53 = null,
};

pub const value_zx_type_54_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    names: []const []const u8,
    types: []const u32,
    zx_origin: ?*const zx_type_54 = null,
};

pub const value_zx_type_55_733f63291ddde64b1bc83a721ebf685a0d9d5fe955b56f62c3e2ecdaa3727384 = struct {
    children: []const u32,
    fields: value_zx_type_54_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814,
    first: u32,
    kind: zx_type_49,
    label: []const u8,
    names: []const []const u8,
    second: u32,
    zx_origin: ?*const zx_type_55 = null,
};

pub const value_zx_type_56_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    found: bool,
    id: u32,
    zx_origin: ?*const zx_type_56 = null,
};

pub const value_zx_type_57_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814 = struct {
    delta: *const zx_type_51,
    id: u32,
    zx_origin: ?*const zx_type_57 = null,
};

pub const value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce = struct {
    names: []const []const u8,
    ownership: []const zx_type_58,
    span_end: []const u64,
    span_start: []const u64,
    types: []const u32,
    zx_origin: ?*const zx_type_60 = null,
};

pub const value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640 = struct {
    control: value_zx_type_17_a8e8eead65b06ed94dc5b5088c64bf0c124b16d8a57e6573f484b7475c135de6,
    expressions: *const zx_type_35,
    root: ?u32,
    stores: *const zx_type_38,
    symbols: value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_61 = null,
};

pub const value_zx_type_62_f8987bbfb8a3b4162d366cbc6ad14f51f36f6a466cc5804b2277fc2c0ac814cf = struct {
    expressions: *const zx_type_35,
    predicate: u32,
    span_end: u64,
    span_start: u64,
    symbols: value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    zx_origin: ?*const zx_type_62 = null,
};

pub const value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    a: u64,
    b: u64,
    c: u64,
    phase: zx_type_63,
    zx_origin: ?*const zx_type_64 = null,
};

pub const value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f = struct {
    body: value_zx_type_61_3a917a1ced687d58870054e7f1c68ba84954bcc9814b4506d0fa685a95906640,
    functions: value_zx_type_41_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    output_type: u32,
    table: *const zx_type_51,
    transaction: bool,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_65 = null,
};

pub const value_zx_type_66_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    concurrent: []const bool,
    pure: []const bool,
    returns: []const bool,
    zx_origin: ?*const zx_type_66 = null,
};

pub const value_zx_type_67_5f65b2d9e9df88722a81205116d90af0a141df9477ec1782450f762a068fd184 = struct {
    prepared: value_zx_type_66_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    zx_origin: ?*const zx_type_67 = null,
};

pub const value_zx_type_68_f24cae134ef3ddeb68fff7b37fdbdece04c34bc1d9866585c92044c40677fdc3 = struct {
    context: value_zx_type_67_5f65b2d9e9df88722a81205116d90af0a141df9477ec1782450f762a068fd184,
    frame: value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_68 = null,
};

pub const value_zx_type_70_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    expressions: *const zx_type_35,
    payload: u64,
    truth: bool,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_70 = null,
};

pub const value_zx_type_71_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    index: u64,
    symbol: u64,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_71 = null,
};

pub const value_zx_type_72_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    condition: u64,
    expressions: *const zx_type_35,
    truth: bool,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_72 = null,
};

pub const value_zx_type_73_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expressions: *const zx_type_35,
    mark: u64,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_73 = null,
};

pub const value_zx_type_74_764206224086badb1da5204a7f83d013e41cffd617e4e75d888ee7f948dc27df = struct {
    context: value_zx_type_67_5f65b2d9e9df88722a81205116d90af0a141df9477ec1782450f762a068fd184,
    statement: u64,
    zx_origin: ?*const zx_type_74 = null,
};

pub const value_zx_type_75_9068dcb27588fc549cd15008d3bd15e507480c6631115fd15614e1d02077b29f = struct {
    frame: value_zx_type_64_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_75 = null,
};

pub const value_zx_type_76_3ff1fc137cb0ea39e5e3fd7523e3f74084231cb48987c7743bd8dc8f42923f32 = struct {
    first: u64,
    index: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    zx_origin: ?*const zx_type_76 = null,
};

pub const value_zx_type_77_4e932baaea7c935e05744a0824bcc81e955a3d02667f01567c1d0a9d7c5e1850 = struct {
    context: value_zx_type_67_5f65b2d9e9df88722a81205116d90af0a141df9477ec1782450f762a068fd184,
    first: u64,
    index: u64,
    valid: bool,
    zx_origin: ?*const zx_type_77 = null,
};

pub const value_zx_type_78_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    count: u64,
    index: u64,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_78 = null,
};

pub const value_zx_type_79_a4f4a3cbe7e16a9f83856f3d482a798c783b649aa703643a2ae36d23508ab939 = struct {
    mode: zx_type_69,
    owner: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    symbol: u64,
    type_id: u32,
    zx_origin: ?*const zx_type_79 = null,
};

pub const value_zx_type_80_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = struct {
    count: u64,
    first: u64,
    index: u64,
    owner: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    valid: bool,
    zx_origin: ?*const zx_type_80 = null,
};

pub const value_zx_type_81_c4908e37ceff181e77d7753834c2920f464a9450937419b99a46e510c2834d52 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_35,
    result: ?u32,
    value: u64,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_81 = null,
};

pub const value_zx_type_82_d8ca084113229bdb4430ee1b48c8bc90a9c0453c352db35a4f3652880e55dc67 = struct {
    count: u64,
    first: u64,
    index: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    type_first: u64,
    valid: bool,
    zx_origin: ?*const zx_type_82 = null,
};

pub const value_zx_type_83_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    count: u64,
    depth: u64,
    first: u64,
    flags: u64,
    values: []const u32,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_83 = null,
};

pub const value_zx_type_84_68bebc01d99f6879dc43b8e7adb1a3f45ef4366c6f107510d452df8f6f575699 = struct {
    index: u64,
    input: value_zx_type_83_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701,
    zx_origin: ?*const zx_type_84 = null,
};

pub const value_zx_type_85_31e15449bd18f804ffcfbc074a78d810e7463576437cf20dc181de102dcb6346 = struct {
    depth: u64,
    first: u64,
    flags: u64,
    index: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    zx_origin: ?*const zx_type_85 = null,
};

pub const value_zx_type_86_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    expressions: *const zx_type_35,
    first: u64,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_86 = null,
};

pub const value_zx_type_87_455ec73b9aeac5def17353be03fafb63798ca6f942034cf59d8714d7d36a663b = struct {
    index: u64,
    input: value_zx_type_86_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165,
    zx_origin: ?*const zx_type_87 = null,
};

pub const value_zx_type_88_7c4f8d63493c4259914ffe8055c54aac698d0b555fc3ce809c67a852092c9066 = struct {
    count: u64,
    err: ?u32,
    expressions: *const zx_type_35,
    first: u64,
    index: u64,
    result: ?u32,
    symbol: u32,
    zx_origin: ?*const zx_type_88 = null,
};

pub const value_zx_type_89_e7ee2282fdd535757d8592f2cf0af81242b05678d9aad142082f45af24e83ff3 = struct {
    depth: u64,
    first: u64,
    flags: u64,
    index: u64,
    owner: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    zx_origin: ?*const zx_type_89 = null,
};

pub const value_zx_type_90_249e492ab2e7cae29a8052d843591627eac3569d44ab7956efb53695607ed6cd = struct {
    count: u64,
    first: u64,
    index: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    valid: bool,
    zx_origin: ?*const zx_type_90 = null,
};

pub const value_zx_type_91_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318 = struct {
    count: u64,
    first: u64,
    index: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    zx_origin: ?*const zx_type_91 = null,
};

pub const value_zx_type_92_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    input_types: []const u32,
    output_types: []const u32,
    stores: []const *const zx_type_38,
    zx_origin: ?*const zx_type_92 = null,
};

pub const value_zx_type_93_036ad5518dc5a5ba35a63c381b0305a72b9d0f94aa5102b11167fa143df78d54 = struct {
    expressions: *const zx_type_35,
    functions: value_zx_type_92_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292,
    index: u64,
    orchestration: bool,
    stores: *const zx_type_38,
    symbols: value_zx_type_60_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce,
    table: *const zx_type_51,
    zx_origin: ?*const zx_type_93 = null,
};

pub const value_zx_type_94_188b1d9eed7e9c9fe25bced90f4d022d91053c1f50f95108b82876e0dd285590 = struct {
    context: value_zx_type_93_036ad5518dc5a5ba35a63c381b0305a72b9d0f94aa5102b11167fa143df78d54,
    kind: zx_type_22,
    payload: u64,
    target: zx_type_49,
    type_id: u32,
    zx_origin: ?*const zx_type_94 = null,
};

pub const value_zx_type_96_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292 = struct {
    expressions: *const zx_type_35,
    left: u64,
    right: u64,
    zx_origin: ?*const zx_type_96 = null,
};

pub const value_zx_type_97_52aa38970985c0af90ef2eb52b6423e591699535fad9b5aebfb09aeddf45c771 = struct {
    payload: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    zx_origin: ?*const zx_type_97 = null,
};

pub const value_zx_type_98_6fcd583ee2d966874a01dcc2cd45686dadd0702a7bb3aee2b6f8196fe7a83243 = struct {
    count: u64,
    first: u64,
    has_default: bool,
    index: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    type_id: u32,
    valid: bool,
    zx_origin: ?*const zx_type_98 = null,
};

pub const value_zx_type_99_25efec72eb6d47aa0c903b6b67278d23a46651ed126529165d3cfde4be4f87e3 = struct {
    count: u64,
    first: u64,
    found: bool,
    index: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    value: u64,
    zx_origin: ?*const zx_type_99 = null,
};

pub const value_zx_type_100_9fa6a0b7c14b57e5794c7f79f332698c046b7f9e1c215f9bec1227eff073c318 = struct {
    depth: u64,
    first: u64,
    index: u64,
    program: value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f,
    zx_origin: ?*const zx_type_100 = null,
};

pub const value_zx_type_101_764206224086badb1da5204a7f83d013e41cffd617e4e75d888ee7f948dc27df = struct {
    context: value_zx_type_67_5f65b2d9e9df88722a81205116d90af0a141df9477ec1782450f762a068fd184,
    valid: bool,
    zx_origin: ?*const zx_type_101 = null,
};

pub const value_zx_type_102_268ac4b4059d05d5a9982d9acb60fad8e26591753d205e05b9629059f7c70165 = struct {
    count: u64,
    index: u64,
    valid: bool,
    writer: *const zx_type_44,
    zx_origin: ?*const zx_type_102 = null,
};

pub const value_zx_type_103_3cc3661e7433be8b56da2745c65cdb5a3457b7e6122f478be537fe884ef8b79a = struct { value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f, ?*const zx_type_103, };

pub const value_zx_type_104_c793d49d476c2338193452c38878517af2511d2f25d595522ef316f2714b0a03 = struct { value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f, value_zx_type_66_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, ?*const zx_type_104, };

pub const value_zx_type_105_a3980cb8662db7a8cf067a21af0d659bd6d6a9ade9d0f1ded0989892689b6dfb = struct { value_zx_type_65_3244b0b03383a62b40f8b11c2f22591805bb9acf3bbf04f8e50f29012bca2c4f, value_zx_type_66_01b64116cded339e0425481afb235b18d36a68077b7c6c7e6676de6f82bf2292, bool, ?*const zx_type_105, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
    pub const @"zig:flow_state" = struct {
        pub const Writer = *const zx_type_44;
        pub const push = struct {
            pub const Input = *const zx_type_45;
            pub const Output = void;
            pub const InputValue = zx_type_45;
            pub const OutputValue = void;
        };
        pub const pop = struct {
            pub const Input = *const zx_type_44;
            pub const Output = void;
            pub const InputValue = zx_type_44;
            pub const OutputValue = void;
        };
        pub const eventCount = struct {
            pub const Input = *const zx_type_44;
            pub const Output = u64;
            pub const InputValue = zx_type_44;
            pub const OutputValue = u64;
        };
        pub const eventKind = struct {
            pub const Input = *const zx_type_44;
            pub const Output = u64;
            pub const InputValue = zx_type_44;
            pub const OutputValue = u64;
        };
        pub const eventA = struct {
            pub const Input = *const zx_type_44;
            pub const Output = u64;
            pub const InputValue = zx_type_44;
            pub const OutputValue = u64;
        };
        pub const eventB = struct {
            pub const Input = *const zx_type_44;
            pub const Output = u64;
            pub const InputValue = zx_type_44;
            pub const OutputValue = u64;
        };
        pub const eventC = struct {
            pub const Input = *const zx_type_44;
            pub const Output = u64;
            pub const InputValue = zx_type_44;
            pub const OutputValue = u64;
        };
        pub const active = struct {
            pub const Input = *const zx_type_46;
            pub const Output = bool;
            pub const InputValue = zx_type_46;
            pub const OutputValue = bool;
        };
        pub const setActive = struct {
            pub const Input = *const zx_type_47;
            pub const Output = void;
            pub const InputValue = zx_type_47;
            pub const OutputValue = void;
        };
        pub const activeMark = struct {
            pub const Input = *const zx_type_44;
            pub const Output = u64;
            pub const InputValue = zx_type_44;
            pub const OutputValue = u64;
        };
        pub const restoreActive = struct {
            pub const Input = *const zx_type_46;
            pub const Output = void;
            pub const InputValue = zx_type_46;
            pub const OutputValue = void;
        };
        pub const declared = struct {
            pub const Input = *const zx_type_46;
            pub const Output = bool;
            pub const InputValue = zx_type_46;
            pub const OutputValue = bool;
        };
        pub const setDeclared = struct {
            pub const Input = *const zx_type_46;
            pub const Output = void;
            pub const InputValue = zx_type_46;
            pub const OutputValue = void;
        };
        pub const owner = struct {
            pub const Input = *const zx_type_46;
            pub const Output = u64;
            pub const InputValue = zx_type_46;
            pub const OutputValue = u64;
        };
        pub const setOwner = struct {
            pub const Input = *const zx_type_48;
            pub const Output = void;
            pub const InputValue = zx_type_48;
            pub const OutputValue = void;
        };
        pub const factMark = struct {
            pub const Input = *const zx_type_44;
            pub const Output = u64;
            pub const InputValue = zx_type_44;
            pub const OutputValue = u64;
        };
        pub const captureMark = struct {
            pub const Input = *const zx_type_44;
            pub const Output = u64;
            pub const InputValue = zx_type_44;
            pub const OutputValue = u64;
        };
        pub const restoreFacts = struct {
            pub const Input = *const zx_type_48;
            pub const Output = void;
            pub const InputValue = zx_type_48;
            pub const OutputValue = void;
        };
        pub const contains = struct {
            pub const Input = *const zx_type_46;
            pub const Output = bool;
            pub const InputValue = zx_type_46;
            pub const OutputValue = bool;
        };
        pub const appendFact = struct {
            pub const Input = *const zx_type_46;
            pub const Output = void;
            pub const InputValue = zx_type_46;
            pub const OutputValue = void;
        };
        pub const appendCapture = struct {
            pub const Input = *const zx_type_48;
            pub const Output = void;
            pub const InputValue = zx_type_48;
            pub const OutputValue = void;
        };
        pub const captureError = struct {
            pub const Input = *const zx_type_46;
            pub const Output = u64;
            pub const InputValue = zx_type_46;
            pub const OutputValue = u64;
        };
        pub const captureResult = struct {
            pub const Input = *const zx_type_46;
            pub const Output = u64;
            pub const InputValue = zx_type_46;
            pub const OutputValue = u64;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
    pub const @"zig:flow_state" = struct {
        pub const Writer = zx_type_44;
    };
};

