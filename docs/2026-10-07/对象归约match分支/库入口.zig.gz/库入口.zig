const std = @import("std");

const zx_abi = @import("zxc_abi");

pub const Child = *const (zx_abi).zx_type_11;

pub const State = *const (zx_abi).zx_type_13;

pub const Input = *const (zx_abi).zx_type_15;

pub const Output = *const (zx_abi).zx_type_13;

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .object, .fields = .{ .value = zx_shape_5, }, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_13 = .{ .kind = .object, .fields = .{ .child = zx_shape_11, .count = zx_shape_5, .labels = zx_shape_12, .last = zx_shape_5, .text = zx_shape_10, .total = zx_shape_5, }, };

const zx_shape_14 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .seed = zx_shape_13, .steps = zx_shape_14, }, };

pub const input_shape = zx_shape_15;

pub const output_shape = zx_shape_13;

fn function_0(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_15) error{ OutOfMemory, }!*const (zx_abi).zx_type_13 {
    @setRuntimeSafety(true);

    return block_25: {
        const operand_1 = (in).steps;
        const operand_2 = (in).seed;

        var value_1: (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2 = (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2{ .child = (zx_abi).value_zx_type_11_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744{ .value = ((operand_2).child).value, .zx_origin = (operand_2).child, }, .count = (operand_2).count, .labels = (operand_2).labels, .last = (operand_2).last, .text = (operand_2).text, .total = (operand_2).total, .zx_origin = operand_2, };

        var state_changed_3 = false;

        for (operand_1) |value_2| {
            if ((block_19: {
                break :block_19 value_2;
            } == @as(u64, 0))) {
            } else {
                if ((@rem(block_12: {
                    break :block_12 value_2;
                }, @as(u64, 2)) == @as(u64, 0))) {
                    value_1 = block_18: {
                        const operand_13 = value_1;
                        const operand_14 = ((value_1).count + @as(u64, 1));
                        const operand_15 = (((value_1).total + (value_1).count) + block_16: {
                            break :block_16 value_2;
                        });
                        const operand_17 = (value_1).count;

                        break :block_18 @as((zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2, (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2{ .child = (operand_13).child, .count = operand_14, .labels = (operand_13).labels, .last = operand_17, .text = (operand_13).text, .total = operand_15, });
                    };

                    state_changed_3 = true;
                } else {
                    value_1 = block_11: {
                        const operand_4 = ((value_1).count + @as(u64, 1));
                        const operand_5 = (((value_1).total + (value_1).count) + block_6: {
                            break :block_6 value_2;
                        });
                        const operand_7 = (value_1).count;
                        const operand_8 = (value_1).labels;
                        const operand_9 = (value_1).text;
                        const operand_10 = (value_1).child;

                        break :block_11 @as((zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2, (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2{ .count = operand_4, .total = operand_5, .last = operand_7, .labels = operand_8, .text = operand_9, .child = operand_10, });
                    };

                    state_changed_3 = true;
                }
            }
        }

        break :block_25 (if (state_changed_3) block_24: {
            break :block_24 (if (((value_1).zx_origin != null)) (value_1).zx_origin.? else block_23: {
                const operand_22 = (try (allocator).create((zx_abi).zx_type_13));

                (operand_22).* = (zx_abi).zx_type_13{ .child = (if ((((value_1).child).zx_origin != null)) ((value_1).child).zx_origin.? else block_21: {
                    const operand_20 = (try (allocator).create((zx_abi).zx_type_11));

                    (operand_20).* = (zx_abi).zx_type_11{ .value = ((value_1).child).value, };

                    break :block_21 @as(*const (zx_abi).zx_type_11, operand_20);
                }), .count = (value_1).count, .labels = (value_1).labels, .last = (value_1).last, .text = (value_1).text, .total = (value_1).total, };

                break :block_23 @as(*const (zx_abi).zx_type_13, operand_22);
            });
        } else operand_2);
    };
}

fn function_0_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_15_e75fd8bd7ba4953908df45d7cb21dac97f86c37d2cbeb6384f0f32c728bafd68) error{ OutOfMemory, }!(zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_46: {
        const operand_26 = (in).steps;
        const operand_27 = (in).seed;

        var value_1: (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2 = operand_27;

        var state_changed_28 = false;

        for (operand_26) |value_2| {
            if ((block_44: {
                break :block_44 value_2;
            } == @as(u64, 0))) {
            } else {
                if ((@rem(block_37: {
                    break :block_37 value_2;
                }, @as(u64, 2)) == @as(u64, 0))) {
                    value_1 = block_43: {
                        const operand_38 = value_1;
                        const operand_39 = ((value_1).count + @as(u64, 1));
                        const operand_40 = (((value_1).total + (value_1).count) + block_41: {
                            break :block_41 value_2;
                        });
                        const operand_42 = (value_1).count;

                        break :block_43 @as((zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2, (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2{ .child = (operand_38).child, .count = operand_39, .labels = (operand_38).labels, .last = operand_42, .text = (operand_38).text, .total = operand_40, });
                    };

                    state_changed_28 = true;
                } else {
                    value_1 = block_36: {
                        const operand_29 = ((value_1).count + @as(u64, 1));
                        const operand_30 = (((value_1).total + (value_1).count) + block_31: {
                            break :block_31 value_2;
                        });
                        const operand_32 = (value_1).count;
                        const operand_33 = (value_1).labels;
                        const operand_34 = (value_1).text;
                        const operand_35 = (value_1).child;

                        break :block_36 @as((zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2, (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2{ .count = operand_29, .total = operand_30, .last = operand_32, .labels = operand_33, .text = operand_34, .child = operand_35, });
                    };

                    state_changed_28 = true;
                }
            }
        }

        break :block_46 (if (state_changed_28) block_45: {
            break :block_45 @as((zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2, value_1);
        } else operand_27);
    };
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_15) error{ OutOfMemory, }!*const (zx_abi).zx_type_13 {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();

    return block_25: {
        const operand_1 = (in).steps;
        const operand_2 = (in).seed;

        var value_1: (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2 = (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2{ .child = (zx_abi).value_zx_type_11_4f40a753d66cbdf2828707a9f642bbaf44febd927bbdba19d0f7279821ade744{ .value = ((operand_2).child).value, .zx_origin = (operand_2).child, }, .count = (operand_2).count, .labels = (operand_2).labels, .last = (operand_2).last, .text = (operand_2).text, .total = (operand_2).total, .zx_origin = operand_2, };

        var state_changed_3 = false;

        for (operand_1) |value_2| {
            if ((block_19: {
                break :block_19 value_2;
            } == @as(u64, 0))) {
            } else {
                if ((@rem(block_12: {
                    break :block_12 value_2;
                }, @as(u64, 2)) == @as(u64, 0))) {
                    value_1 = block_18: {
                        const operand_13 = value_1;
                        const operand_14 = ((value_1).count + @as(u64, 1));
                        const operand_15 = (((value_1).total + (value_1).count) + block_16: {
                            break :block_16 value_2;
                        });
                        const operand_17 = (value_1).count;

                        break :block_18 @as((zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2, (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2{ .child = (operand_13).child, .count = operand_14, .labels = (operand_13).labels, .last = operand_17, .text = (operand_13).text, .total = operand_15, });
                    };

                    state_changed_3 = true;
                } else {
                    value_1 = block_11: {
                        const operand_4 = ((value_1).count + @as(u64, 1));
                        const operand_5 = (((value_1).total + (value_1).count) + block_6: {
                            break :block_6 value_2;
                        });
                        const operand_7 = (value_1).count;
                        const operand_8 = (value_1).labels;
                        const operand_9 = (value_1).text;
                        const operand_10 = (value_1).child;

                        break :block_11 @as((zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2, (zx_abi).value_zx_type_13_35ddb6d0529dc7f822e63e150b14ec433bbe8f9a218bb1186d703bbdfb1f98b2{ .count = operand_4, .total = operand_5, .last = operand_7, .labels = operand_8, .text = operand_9, .child = operand_10, });
                    };

                    state_changed_3 = true;
                }
            }
        }

        break :block_25 (if (state_changed_3) block_24: {
            break :block_24 (if (((value_1).zx_origin != null)) (value_1).zx_origin.? else block_23: {
                const operand_22 = (try (allocator).create((zx_abi).zx_type_13));

                (operand_22).* = (zx_abi).zx_type_13{ .child = (if ((((value_1).child).zx_origin != null)) ((value_1).child).zx_origin.? else block_21: {
                    const operand_20 = (try (allocator).create((zx_abi).zx_type_11));

                    (operand_20).* = (zx_abi).zx_type_11{ .value = ((value_1).child).value, };

                    break :block_21 @as(*const (zx_abi).zx_type_11, operand_20);
                }), .count = (value_1).count, .labels = (value_1).labels, .last = (value_1).last, .text = (value_1).text, .total = (value_1).total, };

                break :block_23 @as(*const (zx_abi).zx_type_13, operand_22);
            });
        } else operand_2);
    };
}

