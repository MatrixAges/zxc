pub const zx_type_14 = struct {
    handles: []const []const u8,
    paths: []const []const u8,
    readable: []const bool,
    types: []const u32,
    writable: []const bool,
};

pub const zx_type_15 = struct {
    available: *const zx_type_14,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_14,
    slots: []const u32,
};

pub const zx_type_16 = struct {
    available: *const zx_type_14,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_14,
    slots: []const u32,
    valid: bool,
};

pub const zx_type_17 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
};

pub const zx_type_18 = struct { *const zx_type_15, };

pub const zx_type_19 = struct { *const zx_type_15, bool, };

pub const value_zx_type_15_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    available: *const zx_type_14,
    count: u64,
    first: u64,
    orchestration: bool,
    required: *const zx_type_14,
    slots: []const u32,
    zx_origin: ?*const zx_type_15 = null,
};

pub const value_zx_type_16_22fe918e18f9428f62efcc8e91e15b66c5ac26027d11257c6c444d8c51b7c4ca = struct {
    available: *const zx_type_14,
    count: u64,
    first: u64,
    index: u64,
    required: *const zx_type_14,
    slots: []const u32,
    valid: bool,
    zx_origin: ?*const zx_type_16 = null,
};

pub const value_zx_type_17_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = struct {
    first: u64,
    found: bool,
    id: u32,
    index: u64,
    limit: u64,
    slots: []const u32,
    zx_origin: ?*const zx_type_17 = null,
};

pub const value_zx_type_18_efdd75a5e607c61dffb07c66411d75c96f1f2b811307e711dcc2093faf9ae2b2 = struct { value_zx_type_15_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, ?*const zx_type_18, };

pub const value_zx_type_19_9102c782dc8c0eb3c4baee9f5b2d3320448d90aaddd79e535802fef289774189 = struct { value_zx_type_15_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, bool, ?*const zx_type_19, };

pub const native = struct {
    pub const @"zig:integers" = struct {
        pub const widen = struct {
            pub const Input = u32;
            pub const Output = u64;
            pub const InputValue = u32;
            pub const OutputValue = u64;
        };
        pub const narrow = struct {
            pub const Input = u64;
            pub const Output = u32;
            pub const InputValue = u64;
            pub const OutputValue = u32;
        };
    };
};

pub const layouts = struct {
    pub const @"zig:integers" = struct {
    };
};

