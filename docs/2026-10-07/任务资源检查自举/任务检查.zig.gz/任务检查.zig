const std = @import("std");

const zx_native_0 = @import("integers");

const zx_abi = @import("zxc_abi");

pub const requires_io = false;

pub const requires_process = false;

const zx_shape_0 = .{ .kind = .scalar, };

const zx_shape_1 = .{ .kind = .scalar, };

const zx_shape_2 = .{ .kind = .scalar, };

const zx_shape_3 = .{ .kind = .scalar, };

const zx_shape_4 = .{ .kind = .scalar, };

const zx_shape_5 = .{ .kind = .scalar, };

const zx_shape_6 = .{ .kind = .scalar, };

const zx_shape_7 = .{ .kind = .scalar, };

const zx_shape_8 = .{ .kind = .scalar, };

const zx_shape_9 = .{ .kind = .scalar, };

const zx_shape_10 = .{ .kind = .string, };

const zx_shape_11 = .{ .kind = .scalar, };

const zx_shape_12 = .{ .kind = .list, .child = zx_shape_2, };

const zx_shape_13 = .{ .kind = .list, .child = zx_shape_4, };

const zx_shape_14 = .{ .kind = .list, .child = zx_shape_10, };

const zx_shape_15 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .field_names = zx_shape_14, .field_types = zx_shape_13, .first = zx_shape_13, .kinds = zx_shape_12, .labels = zx_shape_14, .names = zx_shape_14, .second = zx_shape_13, }, };

const zx_shape_16 = .{ .kind = .object, .fields = .{ .base = zx_shape_15, .delta = zx_shape_15, }, };

const zx_shape_17 = .{ .kind = .object, .fields = .{ .delta = zx_shape_1, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .second = zx_shape_4, }, };

const zx_shape_18 = .{ .kind = .object, .fields = .{ .names = zx_shape_14, .types = zx_shape_13, }, };

const zx_shape_19 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .fields = zx_shape_18, .first = zx_shape_4, .kind = zx_shape_11, .label = zx_shape_10, .names = zx_shape_14, .second = zx_shape_4, }, };

const zx_shape_20 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .id = zx_shape_4, }, };

const zx_shape_21 = .{ .kind = .object, .fields = .{ .delta = zx_shape_15, .id = zx_shape_4, }, };

const zx_shape_22 = .{ .kind = .scalar, };

const zx_shape_23 = .{ .kind = .scalar, };

const zx_shape_24 = .{ .kind = .scalar, };

const zx_shape_25 = .{ .kind = .scalar, };

const zx_shape_26 = .{ .kind = .scalar, };

const zx_shape_27 = .{ .kind = .scalar, };

const zx_shape_28 = .{ .kind = .list, .child = zx_shape_27, };

const zx_shape_29 = .{ .kind = .optional, .child = zx_shape_4, };

const zx_shape_30 = .{ .kind = .list, .child = zx_shape_29, };

const zx_shape_31 = .{ .kind = .list, .child = zx_shape_1, };

const zx_shape_32 = .{ .kind = .object, .fields = .{ .block_count = zx_shape_13, .block_first = zx_shape_13, .branch_conditions = zx_shape_13, .branch_no = zx_shape_13, .branch_yes = zx_shape_13, .case_bodies = zx_shape_13, .case_values = zx_shape_30, .constant_symbols = zx_shape_13, .constant_values = zx_shape_13, .destructure_count = zx_shape_13, .destructure_first = zx_shape_13, .destructure_symbols = zx_shape_30, .destructure_values = zx_shape_13, .evaluations = zx_shape_13, .parallel_count = zx_shape_13, .parallel_first = zx_shape_13, .parallel_symbols = zx_shape_30, .parallel_values = zx_shape_13, .results = zx_shape_30, .selection_count = zx_shape_13, .selection_exhaustive = zx_shape_31, .selection_first = zx_shape_13, .selection_subjects = zx_shape_13, .setter_slots = zx_shape_13, .setter_values = zx_shape_13, .statement_kinds = zx_shape_28, .statement_payloads = zx_shape_13, }, };

const zx_shape_33 = .{ .kind = .list, .child = zx_shape_22, };

const zx_shape_34 = .{ .kind = .list, .child = zx_shape_5, };

const zx_shape_35 = .{ .kind = .list, .child = zx_shape_9, };

const zx_shape_36 = .{ .kind = .list, .child = zx_shape_23, };

const zx_shape_37 = .{ .kind = .list, .child = zx_shape_24, };

const zx_shape_38 = .{ .kind = .list, .child = zx_shape_25, };

const zx_shape_39 = .{ .kind = .list, .child = zx_shape_26, };

const zx_shape_40 = .{ .kind = .object, .fields = .{ .awaits = zx_shape_13, .binary_left = zx_shape_13, .binary_operators = zx_shape_39, .binary_right = zx_shape_13, .booleans = zx_shape_31, .call_arguments = zx_shape_13, .call_functions = zx_shape_13, .call_store_count = zx_shape_13, .call_store_first = zx_shape_13, .call_stores = zx_shape_13, .cancellations = zx_shape_13, .captures = zx_shape_13, .collection_arguments = zx_shape_13, .collection_count = zx_shape_13, .collection_first = zx_shape_13, .collection_kinds = zx_shape_36, .collection_targets = zx_shape_13, .conditional_conditions = zx_shape_13, .conditional_no = zx_shape_13, .conditional_yes = zx_shape_13, .enumerations = zx_shape_13, .errors = zx_shape_13, .floats = zx_shape_35, .index_targets = zx_shape_13, .index_values = zx_shape_13, .integers = zx_shape_34, .iteration_bodies = zx_shape_13, .iteration_condition_parameters = zx_shape_13, .iteration_conditions = zx_shape_13, .iteration_initials = zx_shape_13, .iteration_parameters = zx_shape_13, .iteration_postconditions = zx_shape_31, .kinds = zx_shape_33, .lengths = zx_shape_13, .match_conditions = zx_shape_13, .match_count = zx_shape_13, .match_fallbacks = zx_shape_13, .match_first = zx_shape_13, .match_results = zx_shape_13, .match_subjects = zx_shape_30, .negative_integers = zx_shape_34, .object_count = zx_shape_13, .object_evaluation_count = zx_shape_13, .object_evaluation_first = zx_shape_13, .object_evaluation_values = zx_shape_13, .object_field_indices = zx_shape_13, .object_field_values = zx_shape_13, .object_first = zx_shape_13, .optional_values = zx_shape_13, .parallel_count = zx_shape_13, .parallel_fields = zx_shape_30, .parallel_first = zx_shape_13, .parallel_tasks = zx_shape_13, .payloads = zx_shape_13, .projection_indices = zx_shape_13, .projection_targets = zx_shape_13, .references = zx_shape_13, .scope_borrows = zx_shape_31, .scope_count = zx_shape_13, .scope_first = zx_shape_13, .scope_results = zx_shape_13, .scope_symbols = zx_shape_30, .scope_values = zx_shape_13, .sequence_count = zx_shape_13, .sequence_first = zx_shape_13, .sequence_items = zx_shape_13, .some = zx_shape_13, .span_end = zx_shape_34, .span_start = zx_shape_34, .stores = zx_shape_13, .strings = zx_shape_14, .task_bodies = zx_shape_13, .task_capture_count = zx_shape_13, .task_capture_first = zx_shape_13, .task_captures = zx_shape_13, .transform_bodies = zx_shape_13, .transform_count = zx_shape_13, .transform_first = zx_shape_13, .transform_initials = zx_shape_30, .transform_kinds = zx_shape_37, .transform_parameters = zx_shape_13, .transform_targets = zx_shape_13, .types = zx_shape_13, .unary_operands = zx_shape_13, .unary_operators = zx_shape_38, .update_indices = zx_shape_13, .update_targets = zx_shape_13, .update_values = zx_shape_13, }, };

const zx_shape_41 = .{ .kind = .object, .fields = .{ .handles = zx_shape_14, .paths = zx_shape_14, .readable = zx_shape_31, .types = zx_shape_13, .writable = zx_shape_31, }, };

const zx_shape_42 = .{ .kind = .scalar, };

const zx_shape_43 = .{ .kind = .list, .child = zx_shape_42, };

const zx_shape_44 = .{ .kind = .object, .fields = .{ .names = zx_shape_14, .ownership = zx_shape_43, .span_end = zx_shape_34, .span_start = zx_shape_34, .types = zx_shape_13, }, };

const zx_shape_45 = .{ .kind = .object, .fields = .{ .control = zx_shape_32, .expressions = zx_shape_40, .root = zx_shape_29, .stores = zx_shape_41, .symbols = zx_shape_44, }, };

const zx_shape_46 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_40, .predicate = zx_shape_4, .span_end = zx_shape_5, .span_start = zx_shape_5, .symbols = zx_shape_44, }, };

const zx_shape_47 = .{ .kind = .object, .fields = .{ .body = zx_shape_45, .input_type = zx_shape_4, .output_type = zx_shape_4, .table = zx_shape_15, }, };

const zx_shape_48 = .{ .kind = .object, .fields = .{ .binding = zx_shape_5, .constants = zx_shape_13, .edge = zx_shape_5, .expressions = zx_shape_40, .index = zx_shape_5, .table = zx_shape_15, .uses = zx_shape_34, .valid = zx_shape_1, }, };

const zx_shape_49 = .{ .kind = .object, .fields = .{ .expressions = zx_shape_40, .index = zx_shape_5, .table = zx_shape_15, .uses = zx_shape_34, .valid = zx_shape_1, }, };

const zx_shape_50 = .{ .kind = .object, .fields = .{ .id = zx_shape_4, .tables = zx_shape_16, }, };

const zx_shape_51 = .{ .kind = .object, .fields = .{ .flags = zx_shape_31, .index = zx_shape_5, .native_references = zx_shape_1, .tables = zx_shape_16, }, };

const zx_shape_52 = .{ .kind = .object, .fields = .{ .children = zx_shape_13, .count = zx_shape_5, .flags = zx_shape_31, .found = zx_shape_1, .index = zx_shape_5, .offset = zx_shape_5, }, };

const zx_shape_53 = .{ .kind = .object, .fields = .{ .id = zx_shape_4, .native_references = zx_shape_1, .tables = zx_shape_16, }, };

const zx_shape_54 = .{ .kind = .object, .fields = .{ .found = zx_shape_1, .index = zx_shape_5, .limit = zx_shape_5, .tables = zx_shape_16, .target = zx_shape_11, }, };

const zx_shape_55 = .{ .kind = .object, .fields = .{ .first = zx_shape_5, .flags = zx_shape_31, .index = zx_shape_5, .limit = zx_shape_5, .native_references = zx_shape_1, .tables = zx_shape_16, }, };

const zx_shape_56 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_31, .@"1" = zx_shape_0, }, };

const zx_shape_57 = .{ .kind = .object, .fields = .{ .id = zx_shape_4, .native_references = zx_shape_1, .table = zx_shape_15, }, };

const zx_shape_58 = .{ .kind = .object, .fields = .{ .capture = zx_shape_5, .expressions = zx_shape_40, .index = zx_shape_5, .symbols = zx_shape_44, .table = zx_shape_15, .valid = zx_shape_1, }, };

const zx_shape_59 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_47, }, };

const zx_shape_60 = .{ .kind = .object, .fields = .{ .@"0" = zx_shape_47, .@"1" = zx_shape_1, }, };

pub const input_shape = zx_shape_47;

pub const output_shape = zx_shape_1;

pub const Input = *const (zx_abi).zx_type_47;

pub const Output = bool;

fn function_0(allocator: ((std).mem).Allocator, in: u32) error{ }!u64 {
    const native_result = (zx_native_0).widen(in);

    _ = allocator;

    return native_result;
}

fn function_1(allocator: ((std).mem).Allocator, in: u64) error{ IntegerOverflow, }!u32 {
    const native_result = (try (zx_native_0).narrow(in));

    _ = allocator;

    return native_result;
}

fn function_2(allocator: ((std).mem).Allocator, in: u8) error{ }!(zx_abi).zx_type_11 {
    @setRuntimeSafety(true);

    _ = allocator;

    return block_2: {
        const operand_1 = in;

        break :block_2 (if ((operand_1 == @as(u8, 0))) @as((zx_abi).zx_type_11, .Scalar) else (if ((operand_1 == @as(u8, 1))) @as((zx_abi).zx_type_11, .Object) else (if ((operand_1 == @as(u8, 2))) @as((zx_abi).zx_type_11, .Optional) else (if ((operand_1 == @as(u8, 3))) @as((zx_abi).zx_type_11, .List) else (if ((operand_1 == @as(u8, 4))) @as((zx_abi).zx_type_11, .Tuple) else (if ((operand_1 == @as(u8, 5))) @as((zx_abi).zx_type_11, .ErrorSet) else (if ((operand_1 == @as(u8, 6))) @as((zx_abi).zx_type_11, .Task) else (if ((operand_1 == @as(u8, 7))) @as((zx_abi).zx_type_11, .Enumeration) else @as((zx_abi).zx_type_11, .NativeReference)))))))));
    };
}

fn function_3(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_47) error{ IndexOutOfBounds, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_2: []const u64 = block_243: {
        const operand_240 = (((in).body).expressions).kinds;
        const operand_241 = (try (allocator).alloc(u64, (operand_240).len));

        for (operand_240, 0..) |_, index_242| {
            (operand_241)[index_242] = @as(u64, 0);
        }

        break :block_243 operand_241;
    };
    const value_67: (zx_abi).zx_type_48 = block_239: {
        const operand_38 = block_37: {
            const operand_29 = (in).table;
            const operand_30 = ((in).body).expressions;
            const operand_31 = (((in).body).control).constant_values;
            const operand_32 = value_2;
            const operand_33 = @as(u64, 0);
            const operand_34 = @as(u64, 0);
            const operand_35 = @as(u64, 0);
            const operand_36 = true;

            break :block_37 (zx_abi).zx_type_48{ .table = operand_29, .expressions = operand_30, .constants = operand_31, .uses = operand_32, .index = operand_33, .binding = operand_34, .edge = operand_35, .valid = operand_36, };
        };

        var state_items_39: []u64 = undefined;

        var state_items_started_40 = false;

        var state_28: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (operand_38).binding, .constants = (operand_38).constants, .edge = (operand_38).edge, .expressions = (zx_abi).value_zx_type_40_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = ((operand_38).expressions).awaits, .binary_left = ((operand_38).expressions).binary_left, .binary_operators = ((operand_38).expressions).binary_operators, .binary_right = ((operand_38).expressions).binary_right, .booleans = ((operand_38).expressions).booleans, .call_arguments = ((operand_38).expressions).call_arguments, .call_functions = ((operand_38).expressions).call_functions, .call_store_count = ((operand_38).expressions).call_store_count, .call_store_first = ((operand_38).expressions).call_store_first, .call_stores = ((operand_38).expressions).call_stores, .cancellations = ((operand_38).expressions).cancellations, .captures = ((operand_38).expressions).captures, .collection_arguments = ((operand_38).expressions).collection_arguments, .collection_count = ((operand_38).expressions).collection_count, .collection_first = ((operand_38).expressions).collection_first, .collection_kinds = ((operand_38).expressions).collection_kinds, .collection_targets = ((operand_38).expressions).collection_targets, .conditional_conditions = ((operand_38).expressions).conditional_conditions, .conditional_no = ((operand_38).expressions).conditional_no, .conditional_yes = ((operand_38).expressions).conditional_yes, .enumerations = ((operand_38).expressions).enumerations, .errors = ((operand_38).expressions).errors, .floats = ((operand_38).expressions).floats, .index_targets = ((operand_38).expressions).index_targets, .index_values = ((operand_38).expressions).index_values, .integers = ((operand_38).expressions).integers, .iteration_bodies = ((operand_38).expressions).iteration_bodies, .iteration_condition_parameters = ((operand_38).expressions).iteration_condition_parameters, .iteration_conditions = ((operand_38).expressions).iteration_conditions, .iteration_initials = ((operand_38).expressions).iteration_initials, .iteration_parameters = ((operand_38).expressions).iteration_parameters, .iteration_postconditions = ((operand_38).expressions).iteration_postconditions, .kinds = ((operand_38).expressions).kinds, .lengths = ((operand_38).expressions).lengths, .match_conditions = ((operand_38).expressions).match_conditions, .match_count = ((operand_38).expressions).match_count, .match_fallbacks = ((operand_38).expressions).match_fallbacks, .match_first = ((operand_38).expressions).match_first, .match_results = ((operand_38).expressions).match_results, .match_subjects = ((operand_38).expressions).match_subjects, .negative_integers = ((operand_38).expressions).negative_integers, .object_count = ((operand_38).expressions).object_count, .object_evaluation_count = ((operand_38).expressions).object_evaluation_count, .object_evaluation_first = ((operand_38).expressions).object_evaluation_first, .object_evaluation_values = ((operand_38).expressions).object_evaluation_values, .object_field_indices = ((operand_38).expressions).object_field_indices, .object_field_values = ((operand_38).expressions).object_field_values, .object_first = ((operand_38).expressions).object_first, .optional_values = ((operand_38).expressions).optional_values, .parallel_count = ((operand_38).expressions).parallel_count, .parallel_fields = ((operand_38).expressions).parallel_fields, .parallel_first = ((operand_38).expressions).parallel_first, .parallel_tasks = ((operand_38).expressions).parallel_tasks, .payloads = ((operand_38).expressions).payloads, .projection_indices = ((operand_38).expressions).projection_indices, .projection_targets = ((operand_38).expressions).projection_targets, .references = ((operand_38).expressions).references, .scope_borrows = ((operand_38).expressions).scope_borrows, .scope_count = ((operand_38).expressions).scope_count, .scope_first = ((operand_38).expressions).scope_first, .scope_results = ((operand_38).expressions).scope_results, .scope_symbols = ((operand_38).expressions).scope_symbols, .scope_values = ((operand_38).expressions).scope_values, .sequence_count = ((operand_38).expressions).sequence_count, .sequence_first = ((operand_38).expressions).sequence_first, .sequence_items = ((operand_38).expressions).sequence_items, .some = ((operand_38).expressions).some, .span_end = ((operand_38).expressions).span_end, .span_start = ((operand_38).expressions).span_start, .stores = ((operand_38).expressions).stores, .strings = ((operand_38).expressions).strings, .task_bodies = ((operand_38).expressions).task_bodies, .task_capture_count = ((operand_38).expressions).task_capture_count, .task_capture_first = ((operand_38).expressions).task_capture_first, .task_captures = ((operand_38).expressions).task_captures, .transform_bodies = ((operand_38).expressions).transform_bodies, .transform_count = ((operand_38).expressions).transform_count, .transform_first = ((operand_38).expressions).transform_first, .transform_initials = ((operand_38).expressions).transform_initials, .transform_kinds = ((operand_38).expressions).transform_kinds, .transform_parameters = ((operand_38).expressions).transform_parameters, .transform_targets = ((operand_38).expressions).transform_targets, .types = ((operand_38).expressions).types, .unary_operands = ((operand_38).expressions).unary_operands, .unary_operators = ((operand_38).expressions).unary_operators, .update_indices = ((operand_38).expressions).update_indices, .update_targets = ((operand_38).expressions).update_targets, .update_values = ((operand_38).expressions).update_values, .zx_origin = (operand_38).expressions, }, .index = (operand_38).index, .table = (operand_38).table, .uses = (operand_38).uses, .valid = (operand_38).valid, .zx_origin = (&operand_38), };

        while (((state_28).valid and (((state_28).index < @as(u64, (((state_28).expressions).kinds).len)) or ((state_28).binding < @as(u64, ((state_28).constants).len))))) {
            state_28 = block_234: {
                const value_66: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = (if (((state_28).index == @as(u64, (((state_28).expressions).kinds).len))) block_81: {
                    const value_5: u64 = block_80: {
                        const operand_79 = block_78: {
                            const operand_76 = (state_28).constants;
                            const operand_77 = (state_28).binding;

                            if ((operand_77 >= (operand_76).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_78 (operand_76)[@intCast(operand_77)];
                        };

                        break :block_80 (try function_0(allocator, operand_79));
                    };
                    const value_6: u64 = block_75: {
                        const operand_74 = block_73: {
                            const operand_71 = ((state_28).expressions).types;
                            const operand_72 = block_70: {
                                break :block_70 value_5;
                            };

                            if ((operand_72 >= (operand_71).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_73 (operand_71)[@intCast(operand_72)];
                        };

                        break :block_75 (try function_0(allocator, operand_74));
                    };
                    const value_14: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = (if ((block_48: {
                        const operand_47 = block_46: {
                            const operand_44 = ((state_28).table).kinds;
                            const operand_45 = block_43: {
                                break :block_43 value_6;
                            };

                            if ((operand_45 >= (operand_44).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_46 (operand_44)[@intCast(operand_45)];
                        };

                        break :block_48 (try function_2(allocator, operand_47));
                    } == @as((zx_abi).zx_type_11, .Task))) block_69: {
                        const value_7: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = state_28;
                        const value_8: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_68: {
                            break :block_68 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_7).binding, .constants = (value_7).constants, .edge = (value_7).edge, .expressions = (value_7).expressions, .index = (value_7).index, .table = (value_7).table, .uses = (value_7).uses, .valid = (block_67: {
                                const operand_65 = ((state_28).expressions).kinds;
                                const operand_66 = block_64: {
                                    break :block_64 value_5;
                                };

                                if ((operand_66 >= (operand_65).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_67 (operand_65)[@intCast(operand_66)];
                            } == @as((zx_abi).zx_type_22, .Task)), });
                        };
                        const value_9: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = value_8;
                        const value_10: []const u64 = (value_9).uses;
                        const value_11: u64 = block_63: {
                            break :block_63 value_5;
                        };
                        const value_12: u64 = block_62: {
                            const operand_60 = block_58: {
                                break :block_58 value_10;
                            };
                            const operand_61 = block_59: {
                                break :block_59 value_11;
                            };

                            if ((operand_61 >= (operand_60).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_62 (operand_60)[@intCast(operand_61)];
                        };
                        const value_13: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_57: {
                            break :block_57 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_9).binding, .constants = (value_9).constants, .edge = (value_9).edge, .expressions = (value_9).expressions, .index = (value_9).index, .table = (value_9).table, .uses = block_56: {
                                const operand_50 = block_49: {
                                    break :block_49 value_10;
                                };
                                const operand_52 = block_51: {
                                    break :block_51 value_11;
                                };

                                if ((operand_52 >= (operand_50).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_54 = (block_53: {
                                    break :block_53 value_12;
                                } + @as(u64, 1));

                                break :block_56 block_55: {
                                    if ((!state_items_started_40)) {
                                        state_items_39 = (try (allocator).dupe(u64, operand_50));

                                        state_items_started_40 = true;
                                    }

                                    (state_items_39)[@intCast(operand_52)] = operand_54;

                                    break :block_55 state_items_39;
                                };
                            }, .valid = (value_9).valid, });
                        };

                        break :block_69 value_13;
                    } else state_28);
                    const value_15: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = value_14;
                    const value_16: u64 = (value_15).binding;
                    const value_17: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_42: {
                        break :block_42 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (block_41: {
                            break :block_41 value_16;
                        } + @as(u64, 1)), .constants = (value_15).constants, .edge = (value_15).edge, .expressions = (value_15).expressions, .index = (value_15).index, .table = (value_15).table, .uses = (value_15).uses, .valid = (value_15).valid, });
                    };

                    break :block_81 value_17;
                } else block_233: {
                    const value_18: (zx_abi).zx_type_22 = block_232: {
                        const operand_230 = ((state_28).expressions).kinds;
                        const operand_231 = (state_28).index;

                        if ((operand_231 >= (operand_230).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_232 (operand_230)[@intCast(operand_231)];
                    };
                    const value_19: u64 = block_229: {
                        const operand_228 = block_227: {
                            const operand_225 = ((state_28).expressions).payloads;
                            const operand_226 = (state_28).index;

                            if ((operand_226 >= (operand_225).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_227 (operand_225)[@intCast(operand_226)];
                        };

                        break :block_229 (try function_0(allocator, operand_228));
                    };
                    const value_65: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = (if (((block_82: {
                        break :block_82 value_18;
                    } == @as((zx_abi).zx_type_22, .AwaitTask)) or (block_83: {
                        break :block_83 value_18;
                    } == @as((zx_abi).zx_type_22, .CancelTask)))) block_119: {
                        const value_20: u64 = block_118: {
                            const operand_117 = (if ((block_108: {
                                break :block_108 value_18;
                            } == @as((zx_abi).zx_type_22, .AwaitTask))) block_112: {
                                const operand_110 = ((state_28).expressions).awaits;
                                const operand_111 = block_109: {
                                    break :block_109 value_19;
                                };

                                if ((operand_111 >= (operand_110).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_112 (operand_110)[@intCast(operand_111)];
                            } else block_116: {
                                const operand_114 = ((state_28).expressions).cancellations;
                                const operand_115 = block_113: {
                                    break :block_113 value_19;
                                };

                                if ((operand_115 >= (operand_114).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_116 (operand_114)[@intCast(operand_115)];
                            });

                            break :block_118 (try function_0(allocator, operand_117));
                        };
                        const value_21: (zx_abi).zx_type_22 = block_107: {
                            const operand_105 = ((state_28).expressions).kinds;
                            const operand_106 = block_104: {
                                break :block_104 value_20;
                            };

                            if ((operand_106 >= (operand_105).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_107 (operand_105)[@intCast(operand_106)];
                        };
                        const value_22: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = state_28;
                        const value_23: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_103: {
                            break :block_103 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_22).binding, .constants = (value_22).constants, .edge = (value_22).edge, .expressions = (value_22).expressions, .index = (value_22).index, .table = (value_22).table, .uses = (value_22).uses, .valid = ((block_101: {
                                break :block_101 value_21;
                            } == @as((zx_abi).zx_type_22, .Task)) or (block_102: {
                                break :block_102 value_21;
                            } == @as((zx_abi).zx_type_22, .Reference))), });
                        };
                        const value_24: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = value_23;
                        const value_25: []const u64 = (value_24).uses;
                        const value_26: u64 = block_100: {
                            break :block_100 value_20;
                        };
                        const value_27: u64 = block_99: {
                            const operand_97 = block_95: {
                                break :block_95 value_25;
                            };
                            const operand_98 = block_96: {
                                break :block_96 value_26;
                            };

                            if ((operand_98 >= (operand_97).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_99 (operand_97)[@intCast(operand_98)];
                        };
                        const value_28: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_94: {
                            break :block_94 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_24).binding, .constants = (value_24).constants, .edge = (value_24).edge, .expressions = (value_24).expressions, .index = (value_24).index, .table = (value_24).table, .uses = block_93: {
                                const operand_87 = block_86: {
                                    break :block_86 value_25;
                                };
                                const operand_89 = block_88: {
                                    break :block_88 value_26;
                                };

                                if ((operand_89 >= (operand_87).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                const operand_91 = (block_90: {
                                    break :block_90 value_27;
                                } + @as(u64, 1));

                                break :block_93 block_92: {
                                    if ((!state_items_started_40)) {
                                        state_items_39 = (try (allocator).dupe(u64, operand_87));

                                        state_items_started_40 = true;
                                    }

                                    (state_items_39)[@intCast(operand_89)] = operand_91;

                                    break :block_92 state_items_39;
                                };
                            }, .valid = (value_24).valid, });
                        };
                        const value_29: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = value_28;
                        const value_30: u64 = (value_29).index;
                        const value_31: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_85: {
                            break :block_85 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_29).binding, .constants = (value_29).constants, .edge = (value_29).edge, .expressions = (value_29).expressions, .index = (block_84: {
                                break :block_84 value_30;
                            } + @as(u64, 1)), .table = (value_29).table, .uses = (value_29).uses, .valid = (value_29).valid, });
                        };

                        break :block_119 value_31;
                    } else block_224: {
                        const value_64: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = (if (((block_120: {
                            break :block_120 value_18;
                        } == @as((zx_abi).zx_type_22, .Parallel)) or (block_121: {
                            break :block_121 value_18;
                        } == @as((zx_abi).zx_type_22, .Scope)))) block_220: {
                            const value_32: bool = (block_219: {
                                break :block_219 value_18;
                            } == @as((zx_abi).zx_type_22, .Parallel));
                            const value_33: u64 = block_218: {
                                const operand_217 = (if (block_208: {
                                    break :block_208 value_32;
                                }) block_212: {
                                    const operand_210 = ((state_28).expressions).parallel_count;
                                    const operand_211 = block_209: {
                                        break :block_209 value_19;
                                    };

                                    if ((operand_211 >= (operand_210).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_212 (operand_210)[@intCast(operand_211)];
                                } else block_216: {
                                    const operand_214 = ((state_28).expressions).scope_count;
                                    const operand_215 = block_213: {
                                        break :block_213 value_19;
                                    };

                                    if ((operand_215 >= (operand_214).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_216 (operand_214)[@intCast(operand_215)];
                                });

                                break :block_218 (try function_0(allocator, operand_217));
                            };
                            const value_34: u64 = block_207: {
                                const operand_206 = (if (block_197: {
                                    break :block_197 value_32;
                                }) block_201: {
                                    const operand_199 = ((state_28).expressions).parallel_first;
                                    const operand_200 = block_198: {
                                        break :block_198 value_19;
                                    };

                                    if ((operand_200 >= (operand_199).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_201 (operand_199)[@intCast(operand_200)];
                                } else block_205: {
                                    const operand_203 = ((state_28).expressions).scope_first;
                                    const operand_204 = block_202: {
                                        break :block_202 value_19;
                                    };

                                    if ((operand_204 >= (operand_203).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_205 (operand_203)[@intCast(operand_204)];
                                });

                                break :block_207 (try function_0(allocator, operand_206));
                            };
                            const value_60: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = (if (((state_28).edge == block_122: {
                                break :block_122 value_33;
                            })) block_126: {
                                const value_35: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = state_28;
                                const value_36: u64 = (value_35).index;
                                const value_37: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_125: {
                                    break :block_125 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_35).binding, .constants = (value_35).constants, .edge = (value_35).edge, .expressions = (value_35).expressions, .index = (block_124: {
                                        break :block_124 value_36;
                                    } + @as(u64, 1)), .table = (value_35).table, .uses = (value_35).uses, .valid = (value_35).valid, });
                                };
                                const value_38: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = value_37;
                                const value_39: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_123: {
                                    break :block_123 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_38).binding, .constants = (value_38).constants, .edge = @as(u64, 0), .expressions = (value_38).expressions, .index = (value_38).index, .table = (value_38).table, .uses = (value_38).uses, .valid = (value_38).valid, });
                                };

                                break :block_126 value_39;
                            } else block_196: {
                                const value_40: u64 = (block_195: {
                                    break :block_195 value_34;
                                } + (state_28).edge);
                                const value_41: u64 = block_194: {
                                    const operand_193 = (if (block_184: {
                                        break :block_184 value_32;
                                    }) block_188: {
                                        const operand_186 = ((state_28).expressions).parallel_tasks;
                                        const operand_187 = block_185: {
                                            break :block_185 value_40;
                                        };

                                        if ((operand_187 >= (operand_186).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_188 (operand_186)[@intCast(operand_187)];
                                    } else block_192: {
                                        const operand_190 = ((state_28).expressions).scope_values;
                                        const operand_191 = block_189: {
                                            break :block_189 value_40;
                                        };

                                        if ((operand_191 >= (operand_190).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_192 (operand_190)[@intCast(operand_191)];
                                    });

                                    break :block_194 (try function_0(allocator, operand_193));
                                };
                                const value_42: u64 = block_183: {
                                    const operand_182 = block_181: {
                                        const operand_179 = ((state_28).expressions).types;
                                        const operand_180 = block_178: {
                                            break :block_178 value_41;
                                        };

                                        if ((operand_180 >= (operand_179).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_181 (operand_179)[@intCast(operand_180)];
                                    };

                                    break :block_183 (try function_0(allocator, operand_182));
                                };
                                const value_56: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = (if (block_129: {
                                    break :block_129 value_32;
                                }) block_145: {
                                    const value_43: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = state_28;
                                    const value_44: []const u64 = (value_43).uses;
                                    const value_45: u64 = block_144: {
                                        break :block_144 value_41;
                                    };
                                    const value_46: u64 = block_143: {
                                        const operand_141 = block_139: {
                                            break :block_139 value_44;
                                        };
                                        const operand_142 = block_140: {
                                            break :block_140 value_45;
                                        };

                                        if ((operand_142 >= (operand_141).len)) {
                                            return error.IndexOutOfBounds;
                                        }

                                        break :block_143 (operand_141)[@intCast(operand_142)];
                                    };
                                    const value_47: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_138: {
                                        break :block_138 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_43).binding, .constants = (value_43).constants, .edge = (value_43).edge, .expressions = (value_43).expressions, .index = (value_43).index, .table = (value_43).table, .uses = block_137: {
                                            const operand_131 = block_130: {
                                                break :block_130 value_44;
                                            };
                                            const operand_133 = block_132: {
                                                break :block_132 value_45;
                                            };

                                            if ((operand_133 >= (operand_131).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            const operand_135 = (block_134: {
                                                break :block_134 value_46;
                                            } + @as(u64, 1));

                                            break :block_137 block_136: {
                                                if ((!state_items_started_40)) {
                                                    state_items_39 = (try (allocator).dupe(u64, operand_131));

                                                    state_items_started_40 = true;
                                                }

                                                (state_items_39)[@intCast(operand_133)] = operand_135;

                                                break :block_136 state_items_39;
                                            };
                                        }, .valid = (value_43).valid, });
                                    };

                                    break :block_145 value_47;
                                } else block_177: {
                                    const value_55: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = (if ((block_151: {
                                        const operand_150 = block_149: {
                                            const operand_147 = ((state_28).table).kinds;
                                            const operand_148 = block_146: {
                                                break :block_146 value_42;
                                            };

                                            if ((operand_148 >= (operand_147).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            break :block_149 (operand_147)[@intCast(operand_148)];
                                        };

                                        break :block_151 (try function_2(allocator, operand_150));
                                    } == @as((zx_abi).zx_type_11, .Task))) block_176: {
                                        const value_48: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = state_28;
                                        const value_49: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_175: {
                                            break :block_175 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_48).binding, .constants = (value_48).constants, .edge = (value_48).edge, .expressions = (value_48).expressions, .index = (value_48).index, .table = (value_48).table, .uses = (value_48).uses, .valid = ((block_170: {
                                                const operand_168 = ((state_28).expressions).scope_symbols;
                                                const operand_169 = block_167: {
                                                    break :block_167 value_40;
                                                };

                                                if ((operand_169 >= (operand_168).len)) {
                                                    return error.IndexOutOfBounds;
                                                }

                                                break :block_170 (operand_168)[@intCast(operand_169)];
                                            } != null) and (block_174: {
                                                const operand_172 = ((state_28).expressions).kinds;
                                                const operand_173 = block_171: {
                                                    break :block_171 value_41;
                                                };

                                                if ((operand_173 >= (operand_172).len)) {
                                                    return error.IndexOutOfBounds;
                                                }

                                                break :block_174 (operand_172)[@intCast(operand_173)];
                                            } == @as((zx_abi).zx_type_22, .Task))), });
                                        };
                                        const value_50: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = value_49;
                                        const value_51: []const u64 = (value_50).uses;
                                        const value_52: u64 = block_166: {
                                            break :block_166 value_41;
                                        };
                                        const value_53: u64 = block_165: {
                                            const operand_163 = block_161: {
                                                break :block_161 value_51;
                                            };
                                            const operand_164 = block_162: {
                                                break :block_162 value_52;
                                            };

                                            if ((operand_164 >= (operand_163).len)) {
                                                return error.IndexOutOfBounds;
                                            }

                                            break :block_165 (operand_163)[@intCast(operand_164)];
                                        };
                                        const value_54: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_160: {
                                            break :block_160 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_50).binding, .constants = (value_50).constants, .edge = (value_50).edge, .expressions = (value_50).expressions, .index = (value_50).index, .table = (value_50).table, .uses = block_159: {
                                                const operand_153 = block_152: {
                                                    break :block_152 value_51;
                                                };
                                                const operand_155 = block_154: {
                                                    break :block_154 value_52;
                                                };

                                                if ((operand_155 >= (operand_153).len)) {
                                                    return error.IndexOutOfBounds;
                                                }

                                                const operand_157 = (block_156: {
                                                    break :block_156 value_53;
                                                } + @as(u64, 1));

                                                break :block_159 block_158: {
                                                    if ((!state_items_started_40)) {
                                                        state_items_39 = (try (allocator).dupe(u64, operand_153));

                                                        state_items_started_40 = true;
                                                    }

                                                    (state_items_39)[@intCast(operand_155)] = operand_157;

                                                    break :block_158 state_items_39;
                                                };
                                            }, .valid = (value_50).valid, });
                                        };

                                        break :block_176 value_54;
                                    } else state_28);

                                    break :block_177 value_55;
                                });
                                const value_57: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = value_56;
                                const value_58: u64 = (value_57).edge;
                                const value_59: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_128: {
                                    break :block_128 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_57).binding, .constants = (value_57).constants, .edge = (block_127: {
                                        break :block_127 value_58;
                                    } + @as(u64, 1)), .expressions = (value_57).expressions, .index = (value_57).index, .table = (value_57).table, .uses = (value_57).uses, .valid = (value_57).valid, });
                                };

                                break :block_196 value_59;
                            });

                            break :block_220 value_60;
                        } else block_223: {
                            const value_61: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = state_28;
                            const value_62: u64 = (value_61).index;
                            const value_63: (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde = block_222: {
                                break :block_222 @as((zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde, (zx_abi).value_zx_type_48_e7e3d5b5c54eb850a701ebe8fdd279a46a065040021f528aa8311605a7652fde{ .binding = (value_61).binding, .constants = (value_61).constants, .edge = (value_61).edge, .expressions = (value_61).expressions, .index = (block_221: {
                                    break :block_221 value_62;
                                } + @as(u64, 1)), .table = (value_61).table, .uses = (value_61).uses, .valid = (value_61).valid, });
                            };

                            break :block_223 value_63;
                        });

                        break :block_224 value_64;
                    });

                    break :block_233 value_65;
                });

                break :block_234 value_66;
            };
        }

        break :block_239 block_238: {
            break :block_238 (if (((state_28).zx_origin != null)) ((state_28).zx_origin.?).* else block_237: {
                break :block_237 (zx_abi).zx_type_48{ .binding = (state_28).binding, .constants = (state_28).constants, .edge = (state_28).edge, .expressions = (if ((((state_28).expressions).zx_origin != null)) ((state_28).expressions).zx_origin.? else block_236: {
                    const operand_235 = (try (allocator).create((zx_abi).zx_type_40));

                    (operand_235).* = (zx_abi).zx_type_40{ .awaits = ((state_28).expressions).awaits, .binary_left = ((state_28).expressions).binary_left, .binary_operators = ((state_28).expressions).binary_operators, .binary_right = ((state_28).expressions).binary_right, .booleans = ((state_28).expressions).booleans, .call_arguments = ((state_28).expressions).call_arguments, .call_functions = ((state_28).expressions).call_functions, .call_store_count = ((state_28).expressions).call_store_count, .call_store_first = ((state_28).expressions).call_store_first, .call_stores = ((state_28).expressions).call_stores, .cancellations = ((state_28).expressions).cancellations, .captures = ((state_28).expressions).captures, .collection_arguments = ((state_28).expressions).collection_arguments, .collection_count = ((state_28).expressions).collection_count, .collection_first = ((state_28).expressions).collection_first, .collection_kinds = ((state_28).expressions).collection_kinds, .collection_targets = ((state_28).expressions).collection_targets, .conditional_conditions = ((state_28).expressions).conditional_conditions, .conditional_no = ((state_28).expressions).conditional_no, .conditional_yes = ((state_28).expressions).conditional_yes, .enumerations = ((state_28).expressions).enumerations, .errors = ((state_28).expressions).errors, .floats = ((state_28).expressions).floats, .index_targets = ((state_28).expressions).index_targets, .index_values = ((state_28).expressions).index_values, .integers = ((state_28).expressions).integers, .iteration_bodies = ((state_28).expressions).iteration_bodies, .iteration_condition_parameters = ((state_28).expressions).iteration_condition_parameters, .iteration_conditions = ((state_28).expressions).iteration_conditions, .iteration_initials = ((state_28).expressions).iteration_initials, .iteration_parameters = ((state_28).expressions).iteration_parameters, .iteration_postconditions = ((state_28).expressions).iteration_postconditions, .kinds = ((state_28).expressions).kinds, .lengths = ((state_28).expressions).lengths, .match_conditions = ((state_28).expressions).match_conditions, .match_count = ((state_28).expressions).match_count, .match_fallbacks = ((state_28).expressions).match_fallbacks, .match_first = ((state_28).expressions).match_first, .match_results = ((state_28).expressions).match_results, .match_subjects = ((state_28).expressions).match_subjects, .negative_integers = ((state_28).expressions).negative_integers, .object_count = ((state_28).expressions).object_count, .object_evaluation_count = ((state_28).expressions).object_evaluation_count, .object_evaluation_first = ((state_28).expressions).object_evaluation_first, .object_evaluation_values = ((state_28).expressions).object_evaluation_values, .object_field_indices = ((state_28).expressions).object_field_indices, .object_field_values = ((state_28).expressions).object_field_values, .object_first = ((state_28).expressions).object_first, .optional_values = ((state_28).expressions).optional_values, .parallel_count = ((state_28).expressions).parallel_count, .parallel_fields = ((state_28).expressions).parallel_fields, .parallel_first = ((state_28).expressions).parallel_first, .parallel_tasks = ((state_28).expressions).parallel_tasks, .payloads = ((state_28).expressions).payloads, .projection_indices = ((state_28).expressions).projection_indices, .projection_targets = ((state_28).expressions).projection_targets, .references = ((state_28).expressions).references, .scope_borrows = ((state_28).expressions).scope_borrows, .scope_count = ((state_28).expressions).scope_count, .scope_first = ((state_28).expressions).scope_first, .scope_results = ((state_28).expressions).scope_results, .scope_symbols = ((state_28).expressions).scope_symbols, .scope_values = ((state_28).expressions).scope_values, .sequence_count = ((state_28).expressions).sequence_count, .sequence_first = ((state_28).expressions).sequence_first, .sequence_items = ((state_28).expressions).sequence_items, .some = ((state_28).expressions).some, .span_end = ((state_28).expressions).span_end, .span_start = ((state_28).expressions).span_start, .stores = ((state_28).expressions).stores, .strings = ((state_28).expressions).strings, .task_bodies = ((state_28).expressions).task_bodies, .task_capture_count = ((state_28).expressions).task_capture_count, .task_capture_first = ((state_28).expressions).task_capture_first, .task_captures = ((state_28).expressions).task_captures, .transform_bodies = ((state_28).expressions).transform_bodies, .transform_count = ((state_28).expressions).transform_count, .transform_first = ((state_28).expressions).transform_first, .transform_initials = ((state_28).expressions).transform_initials, .transform_kinds = ((state_28).expressions).transform_kinds, .transform_parameters = ((state_28).expressions).transform_parameters, .transform_targets = ((state_28).expressions).transform_targets, .types = ((state_28).expressions).types, .unary_operands = ((state_28).expressions).unary_operands, .unary_operators = ((state_28).expressions).unary_operators, .update_indices = ((state_28).expressions).update_indices, .update_targets = ((state_28).expressions).update_targets, .update_values = ((state_28).expressions).update_values, };

                    break :block_236 @as(*const (zx_abi).zx_type_40, operand_235);
                }), .index = (state_28).index, .table = (state_28).table, .uses = (state_28).uses, .valid = (state_28).valid, };
            });
        };
    };

    return block_27: {
        const operand_8 = block_7: {
            const operand_2 = (in).table;
            const operand_3 = ((in).body).expressions;
            const operand_4 = ((&value_67)).uses;
            const operand_5 = @as(u64, 0);
            const operand_6 = ((&value_67)).valid;

            break :block_7 (zx_abi).zx_type_49{ .table = operand_2, .expressions = operand_3, .uses = operand_4, .index = operand_5, .valid = operand_6, };
        };

        var state_1: (zx_abi).value_zx_type_49_7e27297e8215eff81a1f7cd904d56e049873bf478a284090758abea032ff11b7 = (zx_abi).value_zx_type_49_7e27297e8215eff81a1f7cd904d56e049873bf478a284090758abea032ff11b7{ .expressions = (zx_abi).value_zx_type_40_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = ((operand_8).expressions).awaits, .binary_left = ((operand_8).expressions).binary_left, .binary_operators = ((operand_8).expressions).binary_operators, .binary_right = ((operand_8).expressions).binary_right, .booleans = ((operand_8).expressions).booleans, .call_arguments = ((operand_8).expressions).call_arguments, .call_functions = ((operand_8).expressions).call_functions, .call_store_count = ((operand_8).expressions).call_store_count, .call_store_first = ((operand_8).expressions).call_store_first, .call_stores = ((operand_8).expressions).call_stores, .cancellations = ((operand_8).expressions).cancellations, .captures = ((operand_8).expressions).captures, .collection_arguments = ((operand_8).expressions).collection_arguments, .collection_count = ((operand_8).expressions).collection_count, .collection_first = ((operand_8).expressions).collection_first, .collection_kinds = ((operand_8).expressions).collection_kinds, .collection_targets = ((operand_8).expressions).collection_targets, .conditional_conditions = ((operand_8).expressions).conditional_conditions, .conditional_no = ((operand_8).expressions).conditional_no, .conditional_yes = ((operand_8).expressions).conditional_yes, .enumerations = ((operand_8).expressions).enumerations, .errors = ((operand_8).expressions).errors, .floats = ((operand_8).expressions).floats, .index_targets = ((operand_8).expressions).index_targets, .index_values = ((operand_8).expressions).index_values, .integers = ((operand_8).expressions).integers, .iteration_bodies = ((operand_8).expressions).iteration_bodies, .iteration_condition_parameters = ((operand_8).expressions).iteration_condition_parameters, .iteration_conditions = ((operand_8).expressions).iteration_conditions, .iteration_initials = ((operand_8).expressions).iteration_initials, .iteration_parameters = ((operand_8).expressions).iteration_parameters, .iteration_postconditions = ((operand_8).expressions).iteration_postconditions, .kinds = ((operand_8).expressions).kinds, .lengths = ((operand_8).expressions).lengths, .match_conditions = ((operand_8).expressions).match_conditions, .match_count = ((operand_8).expressions).match_count, .match_fallbacks = ((operand_8).expressions).match_fallbacks, .match_first = ((operand_8).expressions).match_first, .match_results = ((operand_8).expressions).match_results, .match_subjects = ((operand_8).expressions).match_subjects, .negative_integers = ((operand_8).expressions).negative_integers, .object_count = ((operand_8).expressions).object_count, .object_evaluation_count = ((operand_8).expressions).object_evaluation_count, .object_evaluation_first = ((operand_8).expressions).object_evaluation_first, .object_evaluation_values = ((operand_8).expressions).object_evaluation_values, .object_field_indices = ((operand_8).expressions).object_field_indices, .object_field_values = ((operand_8).expressions).object_field_values, .object_first = ((operand_8).expressions).object_first, .optional_values = ((operand_8).expressions).optional_values, .parallel_count = ((operand_8).expressions).parallel_count, .parallel_fields = ((operand_8).expressions).parallel_fields, .parallel_first = ((operand_8).expressions).parallel_first, .parallel_tasks = ((operand_8).expressions).parallel_tasks, .payloads = ((operand_8).expressions).payloads, .projection_indices = ((operand_8).expressions).projection_indices, .projection_targets = ((operand_8).expressions).projection_targets, .references = ((operand_8).expressions).references, .scope_borrows = ((operand_8).expressions).scope_borrows, .scope_count = ((operand_8).expressions).scope_count, .scope_first = ((operand_8).expressions).scope_first, .scope_results = ((operand_8).expressions).scope_results, .scope_symbols = ((operand_8).expressions).scope_symbols, .scope_values = ((operand_8).expressions).scope_values, .sequence_count = ((operand_8).expressions).sequence_count, .sequence_first = ((operand_8).expressions).sequence_first, .sequence_items = ((operand_8).expressions).sequence_items, .some = ((operand_8).expressions).some, .span_end = ((operand_8).expressions).span_end, .span_start = ((operand_8).expressions).span_start, .stores = ((operand_8).expressions).stores, .strings = ((operand_8).expressions).strings, .task_bodies = ((operand_8).expressions).task_bodies, .task_capture_count = ((operand_8).expressions).task_capture_count, .task_capture_first = ((operand_8).expressions).task_capture_first, .task_captures = ((operand_8).expressions).task_captures, .transform_bodies = ((operand_8).expressions).transform_bodies, .transform_count = ((operand_8).expressions).transform_count, .transform_first = ((operand_8).expressions).transform_first, .transform_initials = ((operand_8).expressions).transform_initials, .transform_kinds = ((operand_8).expressions).transform_kinds, .transform_parameters = ((operand_8).expressions).transform_parameters, .transform_targets = ((operand_8).expressions).transform_targets, .types = ((operand_8).expressions).types, .unary_operands = ((operand_8).expressions).unary_operands, .unary_operators = ((operand_8).expressions).unary_operators, .update_indices = ((operand_8).expressions).update_indices, .update_targets = ((operand_8).expressions).update_targets, .update_values = ((operand_8).expressions).update_values, .zx_origin = (operand_8).expressions, }, .index = (operand_8).index, .table = (operand_8).table, .uses = (operand_8).uses, .valid = (operand_8).valid, .zx_origin = (&operand_8), };

        while (((state_1).valid and ((state_1).index < @as(u64, (((state_1).expressions).kinds).len)))) {
            state_1 = block_26: {
                const value_70: u64 = block_25: {
                    const operand_24 = block_23: {
                        const operand_21 = ((state_1).expressions).types;
                        const operand_22 = (state_1).index;

                        if ((operand_22 >= (operand_21).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_23 (operand_21)[@intCast(operand_22)];
                    };

                    break :block_25 (try function_0(allocator, operand_24));
                };
                const value_71: (zx_abi).value_zx_type_49_7e27297e8215eff81a1f7cd904d56e049873bf478a284090758abea032ff11b7 = state_1;
                const value_72: (zx_abi).value_zx_type_49_7e27297e8215eff81a1f7cd904d56e049873bf478a284090758abea032ff11b7 = block_20: {
                    break :block_20 @as((zx_abi).value_zx_type_49_7e27297e8215eff81a1f7cd904d56e049873bf478a284090758abea032ff11b7, (zx_abi).value_zx_type_49_7e27297e8215eff81a1f7cd904d56e049873bf478a284090758abea032ff11b7{ .expressions = (value_71).expressions, .index = (value_71).index, .table = (value_71).table, .uses = (value_71).uses, .valid = ((block_16: {
                        const operand_15 = block_14: {
                            const operand_12 = ((state_1).table).kinds;
                            const operand_13 = block_11: {
                                break :block_11 value_70;
                            };

                            if ((operand_13 >= (operand_12).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_14 (operand_12)[@intCast(operand_13)];
                        };

                        break :block_16 (try function_2(allocator, operand_15));
                    } != @as((zx_abi).zx_type_11, .Task)) or (block_19: {
                        const operand_17 = (state_1).uses;
                        const operand_18 = (state_1).index;

                        if ((operand_18 >= (operand_17).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_19 (operand_17)[@intCast(operand_18)];
                    } == @as(u64, 1))), });
                };
                const value_73: (zx_abi).value_zx_type_49_7e27297e8215eff81a1f7cd904d56e049873bf478a284090758abea032ff11b7 = value_72;
                const value_74: u64 = (value_73).index;
                const value_75: (zx_abi).value_zx_type_49_7e27297e8215eff81a1f7cd904d56e049873bf478a284090758abea032ff11b7 = block_10: {
                    break :block_10 @as((zx_abi).value_zx_type_49_7e27297e8215eff81a1f7cd904d56e049873bf478a284090758abea032ff11b7, (zx_abi).value_zx_type_49_7e27297e8215eff81a1f7cd904d56e049873bf478a284090758abea032ff11b7{ .expressions = (value_73).expressions, .index = (block_9: {
                        break :block_9 value_74;
                    } + @as(u64, 1)), .table = (value_73).table, .uses = (value_73).uses, .valid = (value_73).valid, });
                };

                break :block_26 value_75;
            };
        }

        break :block_27 (state_1).valid;
    };
}

fn function_4(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_50) error{ IndexOutOfBounds, OutOfMemory, }!*const (zx_abi).zx_type_17 {
    @setRuntimeSafety(true);

    const value_1: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_2: u64 = (try function_0(allocator, (in).id));
    const value_3: bool = (value_2 >= value_1);
    const value_4: *const (zx_abi).zx_type_15 = (if (value_3) ((in).tables).delta else ((in).tables).base);
    const value_5: u64 = (if (value_3) (value_2 - value_1) else value_2);

    return block_20: {
        const operand_1 = (try function_2(allocator, block_4: {
            const operand_2 = (value_4).kinds;
            const operand_3 = value_5;

            if ((operand_3 >= (operand_2).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_4 (operand_2)[@intCast(operand_3)];
        }));
        const operand_5 = block_8: {
            const operand_6 = (value_4).first;
            const operand_7 = value_5;

            if ((operand_7 >= (operand_6).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_8 (operand_6)[@intCast(operand_7)];
        };
        const operand_9 = block_12: {
            const operand_10 = (value_4).second;
            const operand_11 = value_5;

            if ((operand_11 >= (operand_10).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_12 (operand_10)[@intCast(operand_11)];
        };
        const operand_13 = block_16: {
            const operand_14 = (value_4).labels;
            const operand_15 = value_5;

            if ((operand_15 >= (operand_14).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_16 (operand_14)[@intCast(operand_15)];
        };
        const operand_17 = value_3;

        break :block_20 block_19: {
            const operand_18 = (try (allocator).create((zx_abi).zx_type_17));

            (operand_18).* = @as((zx_abi).zx_type_17, (zx_abi).zx_type_17{ .kind = operand_1, .first = operand_5, .second = operand_9, .label = operand_13, .delta = operand_17, });

            break :block_19 @as(*const (zx_abi).zx_type_17, operand_18);
        };
    };
}

fn function_4_value(allocator: ((std).mem).Allocator, in: (zx_abi).value_zx_type_50_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec) error{ IndexOutOfBounds, OutOfMemory, }!(zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce {
    @setRuntimeSafety(true);

    const value_1: u64 = @as(u64, ((((in).tables).base).kinds).len);
    const value_2: u64 = block_58: {
        const operand_57 = (in).id;

        break :block_58 (try function_0(allocator, operand_57));
    };
    const value_3: bool = (block_55: {
        break :block_55 value_2;
    } >= block_56: {
        break :block_56 value_1;
    });
    const value_4: (zx_abi).zx_type_15 = (if (block_54: {
        break :block_54 value_3;
    }) (((in).tables).delta).* else (((in).tables).base).*);
    const value_5: u64 = (if (block_50: {
        break :block_50 value_3;
    }) (block_51: {
        break :block_51 value_2;
    } - block_52: {
        break :block_52 value_1;
    }) else block_53: {
        break :block_53 value_2;
    });

    return block_49: {
        const operand_21 = block_28: {
            const operand_27 = block_26: {
                const operand_24 = (block_22: {
                    break :block_22 (&value_4);
                }).kinds;
                const operand_25 = block_23: {
                    break :block_23 value_5;
                };

                if ((operand_25 >= (operand_24).len)) {
                    return error.IndexOutOfBounds;
                }

                break :block_26 (operand_24)[@intCast(operand_25)];
            };

            break :block_28 (try function_2(allocator, operand_27));
        };
        const operand_29 = block_34: {
            const operand_32 = (block_30: {
                break :block_30 (&value_4);
            }).first;
            const operand_33 = block_31: {
                break :block_31 value_5;
            };

            if ((operand_33 >= (operand_32).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_34 (operand_32)[@intCast(operand_33)];
        };
        const operand_35 = block_40: {
            const operand_38 = (block_36: {
                break :block_36 (&value_4);
            }).second;
            const operand_39 = block_37: {
                break :block_37 value_5;
            };

            if ((operand_39 >= (operand_38).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_40 (operand_38)[@intCast(operand_39)];
        };
        const operand_41 = block_46: {
            const operand_44 = (block_42: {
                break :block_42 (&value_4);
            }).labels;
            const operand_45 = block_43: {
                break :block_43 value_5;
            };

            if ((operand_45 >= (operand_44).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_46 (operand_44)[@intCast(operand_45)];
        };
        const operand_47 = block_48: {
            break :block_48 value_3;
        };

        break :block_49 @as((zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce, (zx_abi).value_zx_type_17_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .kind = operand_21, .first = operand_29, .second = operand_35, .label = operand_41, .delta = operand_47, });
    };
}

fn function_5(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_51) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_17 = block_32: {
        const operand_26 = (in).tables;
        const operand_27 = (try function_1(allocator, (in).index));
        const operand_28 = (zx_abi).zx_type_50{ .tables = operand_26, .id = operand_27, };
        const operand_29 = (&operand_28);
        const operand_30 = (try function_4_value(allocator, (zx_abi).value_zx_type_50_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec{ .id = (operand_29).id, .tables = (zx_abi).value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .base = ((operand_29).tables).base, .delta = ((operand_29).tables).delta, .zx_origin = (operand_29).tables, }, .zx_origin = operand_29, }));

        break :block_32 (if (((operand_30).zx_origin != null)) ((operand_30).zx_origin.?).* else block_31: {
            break :block_31 (zx_abi).zx_type_17{ .delta = (operand_30).delta, .first = (operand_30).first, .kind = (operand_30).kind, .label = (operand_30).label, .second = (operand_30).second, };
        });
    };
    const value_2: (zx_abi).zx_type_11 = ((&value_1)).kind;
    const value_3: (zx_abi).zx_type_11 = (if ((in).native_references) @as((zx_abi).zx_type_11, .NativeReference) else @as((zx_abi).zx_type_11, .List));

    if ((value_2 == value_3)) {
        return true;
    }

    if (((value_2 == @as((zx_abi).zx_type_11, .Optional)) or ((in).native_references and ((value_2 == @as((zx_abi).zx_type_11, .List)) or (value_2 == @as((zx_abi).zx_type_11, .Task)))))) {
        return block_25: {
            const operand_23 = (in).flags;
            const operand_24 = (try function_0(allocator, ((&value_1)).first));

            if ((operand_24 >= (operand_23).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_25 (operand_23)[@intCast(operand_24)];
        };
    }

    if (((value_2 != @as((zx_abi).zx_type_11, .Tuple)) and (value_2 != @as((zx_abi).zx_type_11, .Object)))) {
        return false;
    }

    const value_4: (zx_abi).zx_type_15 = (if (((&value_1)).delta) (((in).tables).delta).* else (((in).tables).base).*);
    const value_5: []const u32 = (if ((value_2 == @as((zx_abi).zx_type_11, .Tuple))) ((&value_4)).children else ((&value_4)).field_types);

    return block_22: {
        const operand_9 = block_8: {
            const operand_2 = (in).flags;
            const operand_3 = value_5;
            const operand_4 = (try function_0(allocator, ((&value_1)).first));
            const operand_5 = (try function_0(allocator, ((&value_1)).second));
            const operand_6 = @as(u64, 0);
            const operand_7 = false;

            break :block_8 (zx_abi).zx_type_52{ .flags = operand_2, .children = operand_3, .offset = operand_4, .count = operand_5, .index = operand_6, .found = operand_7, };
        };

        var state_1: (zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = (zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .children = (operand_9).children, .count = (operand_9).count, .flags = (operand_9).flags, .found = (operand_9).found, .index = (operand_9).index, .offset = (operand_9).offset, .zx_origin = (&operand_9), };

        while (((!(state_1).found) and ((state_1).index < (state_1).count))) {
            state_1 = block_21: {
                const value_8: (zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = state_1;
                const value_9: (zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_20: {
                    break :block_20 @as((zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .children = (value_8).children, .count = (value_8).count, .flags = (value_8).flags, .found = block_19: {
                        const operand_17 = (state_1).flags;
                        const operand_18 = block_16: {
                            const operand_15 = block_14: {
                                const operand_12 = (state_1).children;
                                const operand_13 = ((state_1).offset + (state_1).index);

                                if ((operand_13 >= (operand_12).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_14 (operand_12)[@intCast(operand_13)];
                            };

                            break :block_16 (try function_0(allocator, operand_15));
                        };

                        if ((operand_18 >= (operand_17).len)) {
                            return error.IndexOutOfBounds;
                        }

                        break :block_19 (operand_17)[@intCast(operand_18)];
                    }, .index = (value_8).index, .offset = (value_8).offset, });
                };
                const value_10: (zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = value_9;
                const value_11: u64 = (value_10).index;
                const value_12: (zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701 = block_11: {
                    break :block_11 @as((zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701, (zx_abi).value_zx_type_52_c49a07f0cb1fc4a63cf7628de04d8941b125bb18730256ca50477a6a29730701{ .children = (value_10).children, .count = (value_10).count, .flags = (value_10).flags, .found = (value_10).found, .index = (block_10: {
                        break :block_10 value_11;
                    } + @as(u64, 1)), .offset = (value_10).offset, });
                };

                break :block_21 value_12;
            };
        }

        break :block_22 (state_1).found;
    };
}

fn function_6(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_53) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    const value_1: u64 = (try function_0(allocator, (in).id));
    const value_2: (zx_abi).zx_type_11 = (if ((in).native_references) @as((zx_abi).zx_type_11, .NativeReference) else @as((zx_abi).zx_type_11, .List));

    if (((block_64: {
        const operand_58 = (in).tables;
        const operand_59 = (in).id;
        const operand_60 = (zx_abi).zx_type_50{ .tables = operand_58, .id = operand_59, };
        const operand_61 = (&operand_60);
        const operand_62 = (try function_4_value(allocator, (zx_abi).value_zx_type_50_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec{ .id = (operand_61).id, .tables = (zx_abi).value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .base = ((operand_61).tables).base, .delta = ((operand_61).tables).delta, .zx_origin = (operand_61).tables, }, .zx_origin = operand_61, }));

        break :block_64 (if (((operand_62).zx_origin != null)) ((operand_62).zx_origin.?).* else block_63: {
            break :block_63 (zx_abi).zx_type_17{ .delta = (operand_62).delta, .first = (operand_62).first, .kind = (operand_62).kind, .label = (operand_62).label, .second = (operand_62).second, };
        });
    }).kind == value_2)) {
        return true;
    }

    const value_10: (zx_abi).zx_type_54 = block_57: {
        const operand_42 = block_41: {
            const operand_36 = (in).tables;
            const operand_37 = value_1;
            const operand_38 = value_2;
            const operand_39 = @as(u64, 0);
            const operand_40 = false;

            break :block_41 (zx_abi).zx_type_54{ .tables = operand_36, .limit = operand_37, .target = operand_38, .index = operand_39, .found = operand_40, };
        };

        var state_35: (zx_abi).value_zx_type_54_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = (zx_abi).value_zx_type_54_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc{ .found = (operand_42).found, .index = (operand_42).index, .limit = (operand_42).limit, .tables = (zx_abi).value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .base = ((operand_42).tables).base, .delta = ((operand_42).tables).delta, .zx_origin = (operand_42).tables, }, .target = (operand_42).target, .zx_origin = (&operand_42), };

        while (((!(state_35).found) and ((state_35).index < (state_35).limit))) {
            state_35 = block_52: {
                const value_5: (zx_abi).value_zx_type_54_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = state_35;
                const value_6: (zx_abi).value_zx_type_54_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = block_51: {
                    break :block_51 @as((zx_abi).value_zx_type_54_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc, (zx_abi).value_zx_type_54_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc{ .found = ((block_50: {
                        break :block_50 (try function_4_value(allocator, block_49: {
                            const operand_45 = (state_35).tables;
                            const operand_46 = block_48: {
                                const operand_47 = (state_35).index;

                                break :block_48 (try function_1(allocator, operand_47));
                            };

                            break :block_49 @as((zx_abi).value_zx_type_50_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec, (zx_abi).value_zx_type_50_7c1fb3c3119eaae5cd4f1cb07357028eca5a8de092f6534ed4fdf3ca985575ec{ .tables = operand_45, .id = operand_46, });
                        }));
                    }).kind == (state_35).target), .index = (value_5).index, .limit = (value_5).limit, .tables = (value_5).tables, .target = (value_5).target, });
                };
                const value_7: (zx_abi).value_zx_type_54_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = value_6;
                const value_8: u64 = (value_7).index;
                const value_9: (zx_abi).value_zx_type_54_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc = block_44: {
                    break :block_44 @as((zx_abi).value_zx_type_54_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc, (zx_abi).value_zx_type_54_eae2123bf93423943f2172cdbbc64d8891f5c5aa82b7fb019a459ba0c881d5bc{ .found = (value_7).found, .index = (block_43: {
                        break :block_43 value_8;
                    } + @as(u64, 1)), .limit = (value_7).limit, .tables = (value_7).tables, .target = (value_7).target, });
                };

                break :block_52 value_9;
            };
        }

        break :block_57 block_56: {
            break :block_56 (if (((state_35).zx_origin != null)) ((state_35).zx_origin.?).* else block_55: {
                break :block_55 (zx_abi).zx_type_54{ .found = (state_35).found, .index = (state_35).index, .limit = (state_35).limit, .tables = (if ((((state_35).tables).zx_origin != null)) ((state_35).tables).zx_origin.? else block_54: {
                    const operand_53 = (try (allocator).create((zx_abi).zx_type_16));

                    (operand_53).* = (zx_abi).zx_type_16{ .base = ((state_35).tables).base, .delta = ((state_35).tables).delta, };

                    break :block_54 @as(*const (zx_abi).zx_type_16, operand_53);
                }), .target = (state_35).target, };
            });
        };
    };

    if ((!((&value_10)).found)) {
        return false;
    }

    const value_11: []const bool = @as([]const bool, (comptime (&[_]bool{})));

    return block_34: {
        const operand_9 = block_8: {
            const operand_2 = (in).tables;
            const operand_3 = @as(u64, 0);
            const operand_4 = (((&value_10)).index - @as(u64, 1));
            const operand_5 = (value_1 + @as(u64, 1));
            const operand_6 = value_11;
            const operand_7 = (in).native_references;

            break :block_8 (zx_abi).zx_type_55{ .tables = operand_2, .index = operand_3, .first = operand_4, .limit = operand_5, .flags = operand_6, .native_references = operand_7, };
        };

        var state_capacity_10: (std).ArrayList(bool) = .empty;

        var state_capacity_started_11 = false;

        defer (state_capacity_10).deinit(allocator);

        var state_1: (zx_abi).value_zx_type_55_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = (zx_abi).value_zx_type_55_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e{ .first = (operand_9).first, .flags = (operand_9).flags, .index = (operand_9).index, .limit = (operand_9).limit, .native_references = (operand_9).native_references, .tables = (zx_abi).value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .base = ((operand_9).tables).base, .delta = ((operand_9).tables).delta, .zx_origin = (operand_9).tables, }, .zx_origin = (&operand_9), };

        while (((state_1).index < (state_1).limit)) {
            state_1 = block_29: {
                const value_14: bool = (((state_1).index >= (state_1).first) and block_28: {
                    const operand_19 = (state_1).tables;

                    var state_borrow_20: (zx_abi).zx_type_16 = undefined;

                    state_borrow_20 = (zx_abi).zx_type_16{ .base = (operand_19).base, .delta = (operand_19).delta, };

                    const operand_21 = ((operand_19).zx_origin orelse (&state_borrow_20));
                    const operand_22 = (state_1).index;
                    const operand_23 = (state_1).flags;
                    const operand_24 = (state_1).native_references;
                    const operand_25 = (zx_abi).value_zx_type_16_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814{ .base = (operand_21).base, .delta = (operand_21).delta, .zx_origin = operand_21, };

                    var state_borrow_26: (zx_abi).zx_type_16 = undefined;

                    state_borrow_26 = (zx_abi).zx_type_16{ .base = (operand_25).base, .delta = (operand_25).delta, };

                    const operand_27 = (zx_abi).zx_type_51{ .tables = ((operand_25).zx_origin orelse (&state_borrow_26)), .index = operand_22, .flags = operand_23, .native_references = operand_24, };

                    break :block_28 (try function_5(allocator, (&operand_27)));
                });
                const value_15: (zx_abi).value_zx_type_55_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = state_1;
                const value_16: (zx_abi).value_zx_type_55_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = block_18: {
                    break :block_18 @as((zx_abi).value_zx_type_55_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e, (zx_abi).value_zx_type_55_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e{ .first = (value_15).first, .flags = (block_17: {
                        const operand_14 = (state_1).flags;
                        const operand_16 = block_15: {
                            break :block_15 value_14;
                        };

                        _ = (try ((std).math).add(usize, (operand_14).len, 1));

                        if ((!state_capacity_started_11)) {
                            (try (state_capacity_10).appendSlice(allocator, operand_14));

                            state_capacity_started_11 = true;
                        } else {
                            ((state_capacity_10).items).len = (operand_14).len;
                        }

                        (try (state_capacity_10).append(allocator, operand_16));

                        break :block_17 @as((zx_abi).value_zx_type_56_b5816fa2b3544d0ae53d8d80e4e8f16090caa096626dd61dae8a75a090525814, .{ (state_capacity_10).items, {}, null, });
                    }).@"0", .index = (value_15).index, .limit = (value_15).limit, .native_references = (value_15).native_references, .tables = (value_15).tables, });
                };
                const value_17: (zx_abi).value_zx_type_55_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = value_16;
                const value_18: u64 = (value_17).index;
                const value_19: (zx_abi).value_zx_type_55_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e = block_13: {
                    break :block_13 @as((zx_abi).value_zx_type_55_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e, (zx_abi).value_zx_type_55_6e5d8df28d3f9d3f54b015a56c712ed50d53e34e5758a188236df6cc77eaf77e{ .first = (value_17).first, .flags = (value_17).flags, .index = (block_12: {
                        break :block_12 value_18;
                    } + @as(u64, 1)), .limit = (value_17).limit, .native_references = (value_17).native_references, .tables = (value_17).tables, });
                };

                break :block_29 value_19;
            };
        }

        break :block_34 block_33: {
            const operand_31 = (state_1).flags;
            const operand_32 = block_30: {
                break :block_30 value_1;
            };

            if ((operand_32 >= (operand_31).len)) {
                return error.IndexOutOfBounds;
            }

            break :block_33 (operand_31)[@intCast(operand_32)];
        };
    };
}

fn function_7(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_57) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_15 = block_17: {
        const operand_9 = @as([]const u8, (comptime (&[_]u8{})));
        const operand_10 = @as([]const u32, (comptime (&[_]u32{})));
        const operand_11 = @as([]const u32, (comptime (&[_]u32{})));
        const operand_12 = @as([]const []const u8, (comptime (&[_][]const u8{})));
        const operand_13 = @as([]const u32, (comptime (&[_]u32{})));
        const operand_14 = @as([]const u32, (comptime (&[_]u32{})));
        const operand_15 = @as([]const []const u8, (comptime (&[_][]const u8{})));
        const operand_16 = @as([]const []const u8, (comptime (&[_][]const u8{})));

        break :block_17 (zx_abi).zx_type_15{ .kinds = operand_9, .first = operand_10, .second = operand_11, .labels = operand_12, .children = operand_13, .field_types = operand_14, .field_names = operand_15, .names = operand_16, };
    };

    return block_8: {
        const operand_1 = (in).table;
        const operand_2 = (&value_1);
        const operand_3 = (zx_abi).zx_type_16{ .base = operand_1, .delta = operand_2, };
        const operand_4 = (&operand_3);
        const operand_5 = (in).id;
        const operand_6 = (in).native_references;
        const operand_7 = (zx_abi).zx_type_53{ .tables = operand_4, .id = operand_5, .native_references = operand_6, };

        break :block_8 (try function_6(allocator, (&operand_7)));
    };
}

fn function_8(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_47) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    const value_1: (zx_abi).zx_type_40 = (((in).body).expressions).*;

    return block_76: {
        const operand_9 = block_8: {
            const operand_2 = (in).table;
            const operand_3 = ((in).body).symbols;
            const operand_4 = (&value_1);
            const operand_5 = @as(u64, 0);
            const operand_6 = @as(u64, 0);
            const operand_7 = true;

            break :block_8 (zx_abi).zx_type_58{ .table = operand_2, .symbols = operand_3, .expressions = operand_4, .index = operand_5, .capture = operand_6, .valid = operand_7, };
        };

        var state_1: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494{ .capture = (operand_9).capture, .expressions = (zx_abi).value_zx_type_40_8d0b6a4af8354250f4fc08836c3c65d4f5b0c168157d870e25ae9b53b7643788{ .awaits = ((operand_9).expressions).awaits, .binary_left = ((operand_9).expressions).binary_left, .binary_operators = ((operand_9).expressions).binary_operators, .binary_right = ((operand_9).expressions).binary_right, .booleans = ((operand_9).expressions).booleans, .call_arguments = ((operand_9).expressions).call_arguments, .call_functions = ((operand_9).expressions).call_functions, .call_store_count = ((operand_9).expressions).call_store_count, .call_store_first = ((operand_9).expressions).call_store_first, .call_stores = ((operand_9).expressions).call_stores, .cancellations = ((operand_9).expressions).cancellations, .captures = ((operand_9).expressions).captures, .collection_arguments = ((operand_9).expressions).collection_arguments, .collection_count = ((operand_9).expressions).collection_count, .collection_first = ((operand_9).expressions).collection_first, .collection_kinds = ((operand_9).expressions).collection_kinds, .collection_targets = ((operand_9).expressions).collection_targets, .conditional_conditions = ((operand_9).expressions).conditional_conditions, .conditional_no = ((operand_9).expressions).conditional_no, .conditional_yes = ((operand_9).expressions).conditional_yes, .enumerations = ((operand_9).expressions).enumerations, .errors = ((operand_9).expressions).errors, .floats = ((operand_9).expressions).floats, .index_targets = ((operand_9).expressions).index_targets, .index_values = ((operand_9).expressions).index_values, .integers = ((operand_9).expressions).integers, .iteration_bodies = ((operand_9).expressions).iteration_bodies, .iteration_condition_parameters = ((operand_9).expressions).iteration_condition_parameters, .iteration_conditions = ((operand_9).expressions).iteration_conditions, .iteration_initials = ((operand_9).expressions).iteration_initials, .iteration_parameters = ((operand_9).expressions).iteration_parameters, .iteration_postconditions = ((operand_9).expressions).iteration_postconditions, .kinds = ((operand_9).expressions).kinds, .lengths = ((operand_9).expressions).lengths, .match_conditions = ((operand_9).expressions).match_conditions, .match_count = ((operand_9).expressions).match_count, .match_fallbacks = ((operand_9).expressions).match_fallbacks, .match_first = ((operand_9).expressions).match_first, .match_results = ((operand_9).expressions).match_results, .match_subjects = ((operand_9).expressions).match_subjects, .negative_integers = ((operand_9).expressions).negative_integers, .object_count = ((operand_9).expressions).object_count, .object_evaluation_count = ((operand_9).expressions).object_evaluation_count, .object_evaluation_first = ((operand_9).expressions).object_evaluation_first, .object_evaluation_values = ((operand_9).expressions).object_evaluation_values, .object_field_indices = ((operand_9).expressions).object_field_indices, .object_field_values = ((operand_9).expressions).object_field_values, .object_first = ((operand_9).expressions).object_first, .optional_values = ((operand_9).expressions).optional_values, .parallel_count = ((operand_9).expressions).parallel_count, .parallel_fields = ((operand_9).expressions).parallel_fields, .parallel_first = ((operand_9).expressions).parallel_first, .parallel_tasks = ((operand_9).expressions).parallel_tasks, .payloads = ((operand_9).expressions).payloads, .projection_indices = ((operand_9).expressions).projection_indices, .projection_targets = ((operand_9).expressions).projection_targets, .references = ((operand_9).expressions).references, .scope_borrows = ((operand_9).expressions).scope_borrows, .scope_count = ((operand_9).expressions).scope_count, .scope_first = ((operand_9).expressions).scope_first, .scope_results = ((operand_9).expressions).scope_results, .scope_symbols = ((operand_9).expressions).scope_symbols, .scope_values = ((operand_9).expressions).scope_values, .sequence_count = ((operand_9).expressions).sequence_count, .sequence_first = ((operand_9).expressions).sequence_first, .sequence_items = ((operand_9).expressions).sequence_items, .some = ((operand_9).expressions).some, .span_end = ((operand_9).expressions).span_end, .span_start = ((operand_9).expressions).span_start, .stores = ((operand_9).expressions).stores, .strings = ((operand_9).expressions).strings, .task_bodies = ((operand_9).expressions).task_bodies, .task_capture_count = ((operand_9).expressions).task_capture_count, .task_capture_first = ((operand_9).expressions).task_capture_first, .task_captures = ((operand_9).expressions).task_captures, .transform_bodies = ((operand_9).expressions).transform_bodies, .transform_count = ((operand_9).expressions).transform_count, .transform_first = ((operand_9).expressions).transform_first, .transform_initials = ((operand_9).expressions).transform_initials, .transform_kinds = ((operand_9).expressions).transform_kinds, .transform_parameters = ((operand_9).expressions).transform_parameters, .transform_targets = ((operand_9).expressions).transform_targets, .types = ((operand_9).expressions).types, .unary_operands = ((operand_9).expressions).unary_operands, .unary_operators = ((operand_9).expressions).unary_operators, .update_indices = ((operand_9).expressions).update_indices, .update_targets = ((operand_9).expressions).update_targets, .update_values = ((operand_9).expressions).update_values, .zx_origin = (operand_9).expressions, }, .index = (operand_9).index, .symbols = (zx_abi).value_zx_type_44_2ddc8d81c21e68612e817c7293e54a7cb5f26a22cd74db770ee9bdcef0645bce{ .names = ((operand_9).symbols).names, .ownership = ((operand_9).symbols).ownership, .span_end = ((operand_9).symbols).span_end, .span_start = ((operand_9).symbols).span_start, .types = ((operand_9).symbols).types, .zx_origin = (operand_9).symbols, }, .table = (operand_9).table, .valid = (operand_9).valid, .zx_origin = (&operand_9), };

        while (((state_1).valid and ((state_1).index < @as(u64, (((state_1).expressions).kinds).len)))) {
            state_1 = block_75: {
                const value_26: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = (if ((block_12: {
                    const operand_10 = ((state_1).expressions).kinds;
                    const operand_11 = (state_1).index;

                    if ((operand_11 >= (operand_10).len)) {
                        return error.IndexOutOfBounds;
                    }

                    break :block_12 (operand_10)[@intCast(operand_11)];
                } != @as((zx_abi).zx_type_22, .Task))) block_15: {
                    const value_4: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = state_1;
                    const value_5: u64 = (value_4).index;
                    const value_6: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = block_14: {
                        break :block_14 @as((zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494, (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494{ .capture = (value_4).capture, .expressions = (value_4).expressions, .index = (block_13: {
                            break :block_13 value_5;
                        } + @as(u64, 1)), .symbols = (value_4).symbols, .table = (value_4).table, .valid = (value_4).valid, });
                    };

                    break :block_15 value_6;
                } else block_74: {
                    const value_7: u64 = block_73: {
                        const operand_72 = block_71: {
                            const operand_69 = ((state_1).expressions).payloads;
                            const operand_70 = (state_1).index;

                            if ((operand_70 >= (operand_69).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_71 (operand_69)[@intCast(operand_70)];
                        };

                        break :block_73 (try function_0(allocator, operand_72));
                    };
                    const value_8: u64 = block_68: {
                        const operand_67 = block_66: {
                            const operand_64 = ((state_1).expressions).task_capture_count;
                            const operand_65 = block_63: {
                                break :block_63 value_7;
                            };

                            if ((operand_65 >= (operand_64).len)) {
                                return error.IndexOutOfBounds;
                            }

                            break :block_66 (operand_64)[@intCast(operand_65)];
                        };

                        break :block_68 (try function_0(allocator, operand_67));
                    };
                    const value_12: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = (if (((state_1).capture == @as(u64, 0))) block_62: {
                        const value_9: u64 = block_61: {
                            const operand_60 = block_59: {
                                const operand_57 = ((state_1).expressions).task_bodies;
                                const operand_58 = block_56: {
                                    break :block_56 value_7;
                                };

                                if ((operand_58 >= (operand_57).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_59 (operand_57)[@intCast(operand_58)];
                            };

                            break :block_61 (try function_0(allocator, operand_60));
                        };
                        const value_10: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = state_1;
                        const value_11: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = block_55: {
                            break :block_55 @as((zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494, (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494{ .capture = (value_10).capture, .expressions = (value_10).expressions, .index = (value_10).index, .symbols = (value_10).symbols, .table = (value_10).table, .valid = (!block_54: {
                                const operand_46 = (state_1).table;
                                const operand_51 = block_50: {
                                    const operand_48 = ((state_1).expressions).types;
                                    const operand_49 = block_47: {
                                        break :block_47 value_9;
                                    };

                                    if ((operand_49 >= (operand_48).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_50 (operand_48)[@intCast(operand_49)];
                                };
                                const operand_52 = true;
                                const operand_53 = (zx_abi).zx_type_57{ .table = operand_46, .id = operand_51, .native_references = operand_52, };

                                break :block_54 (try function_7(allocator, (&operand_53)));
                            }), });
                        };

                        break :block_62 value_11;
                    } else state_1);
                    const value_25: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = (if (((value_12).capture < block_16: {
                        break :block_16 value_8;
                    })) block_41: {
                        const value_13: u64 = (block_40: {
                            const operand_39 = block_38: {
                                const operand_36 = ((value_12).expressions).task_capture_first;
                                const operand_37 = block_35: {
                                    break :block_35 value_7;
                                };

                                if ((operand_37 >= (operand_36).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_38 (operand_36)[@intCast(operand_37)];
                            };

                            break :block_40 (try function_0(allocator, operand_39));
                        } + (value_12).capture);
                        const value_14: u64 = block_34: {
                            const operand_33 = block_32: {
                                const operand_30 = ((value_12).expressions).task_captures;
                                const operand_31 = block_29: {
                                    break :block_29 value_13;
                                };

                                if ((operand_31 >= (operand_30).len)) {
                                    return error.IndexOutOfBounds;
                                }

                                break :block_32 (operand_30)[@intCast(operand_31)];
                            };

                            break :block_34 (try function_0(allocator, operand_33));
                        };
                        const value_15: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = value_12;
                        const value_16: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = block_28: {
                            break :block_28 @as((zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494, (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494{ .capture = (value_15).capture, .expressions = (value_15).expressions, .index = (value_15).index, .symbols = (value_15).symbols, .table = (value_15).table, .valid = ((value_12).valid and (!block_27: {
                                const operand_19 = (value_12).table;
                                const operand_24 = block_23: {
                                    const operand_21 = ((value_12).symbols).types;
                                    const operand_22 = block_20: {
                                        break :block_20 value_14;
                                    };

                                    if ((operand_22 >= (operand_21).len)) {
                                        return error.IndexOutOfBounds;
                                    }

                                    break :block_23 (operand_21)[@intCast(operand_22)];
                                };
                                const operand_25 = true;
                                const operand_26 = (zx_abi).zx_type_57{ .table = operand_19, .id = operand_24, .native_references = operand_25, };

                                break :block_27 (try function_7(allocator, (&operand_26)));
                            })), });
                        };
                        const value_17: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = value_16;
                        const value_18: u64 = (value_17).capture;
                        const value_19: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = block_18: {
                            break :block_18 @as((zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494, (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494{ .capture = (block_17: {
                                break :block_17 value_18;
                            } + @as(u64, 1)), .expressions = (value_17).expressions, .index = (value_17).index, .symbols = (value_17).symbols, .table = (value_17).table, .valid = (value_17).valid, });
                        };

                        break :block_41 value_19;
                    } else block_45: {
                        const value_20: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = value_12;
                        const value_21: u64 = (value_20).index;
                        const value_22: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = block_44: {
                            break :block_44 @as((zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494, (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494{ .capture = (value_20).capture, .expressions = (value_20).expressions, .index = (block_43: {
                                break :block_43 value_21;
                            } + @as(u64, 1)), .symbols = (value_20).symbols, .table = (value_20).table, .valid = (value_20).valid, });
                        };
                        const value_23: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = value_22;
                        const value_24: (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494 = block_42: {
                            break :block_42 @as((zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494, (zx_abi).value_zx_type_58_7f02ceb910a002ed41d524a7ae2c3d4c50f0272e1cc5dd04f709ac026b9c4494{ .capture = @as(u64, 0), .expressions = (value_23).expressions, .index = (value_23).index, .symbols = (value_23).symbols, .table = (value_23).table, .valid = (value_23).valid, });
                        };

                        break :block_45 value_24;
                    });

                    break :block_74 value_25;
                });

                break :block_75 value_26;
            };
        }

        break :block_76 (state_1).valid;
    };
}

fn function_9(allocator: ((std).mem).Allocator, in: *const (zx_abi).zx_type_47) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    if ((((try function_2(allocator, block_3: {
        const operand_1 = ((in).table).kinds;
        const operand_2 = (try function_0(allocator, (in).input_type));

        if ((operand_2 >= (operand_1).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_3 (operand_1)[@intCast(operand_2)];
    })) == @as((zx_abi).zx_type_11, .Task)) or ((try function_2(allocator, block_6: {
        const operand_4 = ((in).table).kinds;
        const operand_5 = (try function_0(allocator, (in).output_type));

        if ((operand_5 >= (operand_4).len)) {
            return error.IndexOutOfBounds;
        }

        break :block_6 (operand_4)[@intCast(operand_5)];
    })) == @as((zx_abi).zx_type_11, .Task)))) {
        return false;
    }

    return ((try function_8(allocator, in)) and (try function_3(allocator, in)));
}

pub fn execute(arena: *((std).heap).ArenaAllocator, in: *const (zx_abi).zx_type_47) error{ IndexOutOfBounds, IntegerOverflow, OutOfMemory, Overflow, }!bool {
    @setRuntimeSafety(true);

    const allocator = (arena).allocator();
    const value_1: bool = (try function_9(allocator, in));

    return value_1;
}

